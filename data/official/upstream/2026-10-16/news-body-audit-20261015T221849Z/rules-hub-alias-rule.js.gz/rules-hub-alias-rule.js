// 页面初始化时加载数据
document.addEventListener('DOMContentLoaded', function () {
    getRuleList();


});

function getRuleList() {
  const requestData = {
        pageNum: 1,
        pageSize: 1000
    };
    sendPostRequest('/xcx/gameRule/getGameRuleList', requestData)
        .then(data => {
            // console.log('POST 请求成功', data);
            if (data.code == 0) {
                renderRuleList(data.result);
            }
        })
        .catch(error => {
            console.error('There was an error:', error);
        });
}

function renderRuleList(list) {
    const container = document.getElementById('rules-list');
    container.innerHTML = '';

    list.forEach(item => {
        const itemElement = document.createElement('div');
        itemElement.className = 'rules-item';

        const contextElement = document.createElement('div');
        contextElement.className = 'rules-context'
        const btnElement = document.createElement('div');
        btnElement.className = 'download_btn'
        btnElement.textContent = '点击下载';

        btnElement.addEventListener('click', () => {
          window.open(item.ruleDocUrl, '_blank', 'noopener,noreferrer');
        });

        const nameElement = document.createElement('div');
        nameElement.className = 'rules-name'
        const timeElement = document.createElement('div');
        timeElement.className = 'time'
        timeElement.textContent = item.updateDate;

        const radioBox = document.createElement('span');
        radioBox.className = 'radio'
        const nameBox = document.createElement('span');
        nameBox.className = 'name'
        nameBox.textContent = item.ruleName;

        nameElement.appendChild(radioBox);
        nameElement.appendChild(nameBox);

        contextElement.appendChild(nameElement);
        contextElement.appendChild(timeElement);

        itemElement.appendChild(contextElement);
        itemElement.appendChild(btnElement);

        container.appendChild(itemElement);
    });
}
