from pathlib import Path
from urllib.request import Request,urlopen
from concurrent.futures import ThreadPoolExecutor
import datetime,gzip,hashlib,json
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(p.read_text())
manifest=load(root/'docs/audit/current-manifest.json');latest=next(d['after'] for d in reversed(manifest['laterSourceDeltas']) if d['kind']=='cn_cards')
registered={c['id']:c for c in load(root/latest['path'])['data']};cn16={c['id']:c for c in load(root/'data/official/upstream/2026-10-16/source-refresh-20261015T160523Z/card-catalog.zh-CN.json')['cards']}
assert registered[34765]['cardNo']=='UNL-212/219' and registered[34762]['cardNo']=='UNL-209/219'
rules=load(w/'current-cn-rule-directory-and-known-source-versions-v1.json');assert rules['unchangedKnownDocuments']==16 and rules['directory']['allDirectoryRowsFieldsNullsAndOrderExactlyPreviousRecordedVersion'] and not rules['directory']['newListedUrls']
url='https://lol-api.playloltcg.com/xcx/card/searchCardCraftWeb'
def fetch(id):
 body={'pageNum':1,'pageSize':100,'searchContent':registered[id]['cardName'],'cardCategoryList':[],'cardColorList':[],'rarityList':[],'productCodeList':[]};started=now()
 with urlopen(Request(url,json.dumps(body,ensure_ascii=False).encode(),{'Content-Type':'application/json','User-Agent':'Mozilla/5.0','Cache-Control':'no-cache'}),timeout=35) as response:raw=response.read();status=response.status;headers={k:v for k,v in response.headers.items() if k.lower() in {'date','etag','content-type','last-modified'}}
 doc=json.loads(raw);rows=doc['result']['list'];actual=next(c for c in rows if c['id']==id);assert len(rows)==doc['result']['total']==1
 path=w/f'current-{id}-complete-response-v1.json.gz'
 with path.open('xb') as f:f.write(gzip.compress(raw,mtime=0))
 result={'url':url,'request':body,'startedAtUtc':started,'receivedAtUtc':now(),'httpStatus':status,'responseHeaders':headers,'originalRawBytes':len(raw),'originalRawSha256':sha(raw),'original':str(path.relative_to(root)),'compressedSha256':sha(path.read_bytes()),'exactId':id,'region':'CN','language':'zh-CN','currentCompleteRow':actual,'allKeysValuesNullsAndQaExactLatestRegistered':actual==registered[id],'allKeysValuesNullsAndQaExactCn16':actual==cn16[id],'publicationOrEffectiveDateNotInferredFromFetch':True,'semanticCertification':False}
 with (w/f'{id}-source-intake-v1.json').open('x') as f:json.dump(result,f,ensure_ascii=False,indent=2)
 return result
with ThreadPoolExecutor(max_workers=2) as pool:rows=list(pool.map(fetch,[34765,34762]))
corpus=load(root/'docs/evidence/rules-reaudit-2026-10-11/official-corpus.json');core=next(d for d in rules['documents'] if d['id']=='DOC-01')
records=[r for r in corpus['records'] if r['id'].startswith('DOC-01-P029-') and '190.6' in r['text']]
assert records and core['sha256']=='d6fd7140f106f9b5b3dc0d5817fd040110fe870a6da9ee335ba7f4f70f892d11'
result={'atUtc':now(),'status':'CURRENT_EXACT_TWO_START_BATTLEFIELD_SOURCE_AND_CORE_IDENTITY_READBACK_ONLY','region':'CN','language':'zh-CN','applicableAsOf':'2026-10-22','adoptedCoreEffectiveDate':'2026-10-16','exactApiIds':[34765,34762],'allTwoCompleteRowsAndQaExactLatestRegistered':all(r['allKeysValuesNullsAndQaExactLatestRegistered'] for r in rows),'allTwoCompleteRowsAndQaExactCn16':all(r['allKeysValuesNullsAndQaExactCn16'] for r in rows),'latestRegisteredCardSource':latest,'currentCoreOriginalReadback':core,'currentRuleDirectoryAndAll16Versions':{'path':str((w/'current-cn-rule-directory-and-known-source-versions-v1.json').relative_to(root)),'sha256':sha((w/'current-cn-rule-directory-and-known-source-versions-v1.json').read_bytes())},'exactRuleBlocks190_6':[{**r,'textSha256':sha(r['text'].encode())} for r in records],'allOriginalSourceDatesGapsAndScopeRetained':True,'noGameplayImplementationOrRootTrackedSourceChanged':True,'currentPeerNotificationOnlyCheckAndFixedEarlyNativeMustPrecedeFrostImplementation':True,'wholePrintingOrFamilyCertification':False}
with (w/'two-exact-start-battlefield-source-and-core-readback-v1.json').open('x') as f:json.dump(result,f,ensure_ascii=False,indent=2)
print('Fresh CN34765/34762 full rows and QA:',result['allTwoCompleteRowsAndQaExactLatestRegistered'],'latest registered; core16 exact; no gameplay change.')
