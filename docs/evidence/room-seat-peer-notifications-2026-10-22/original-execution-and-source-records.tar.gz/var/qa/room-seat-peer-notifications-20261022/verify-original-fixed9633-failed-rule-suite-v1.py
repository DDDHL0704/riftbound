from pathlib import Path
import collections,datetime,gzip,hashlib,json,re,xml.etree.ElementTree as ET,zipfile
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
fixed='96334b9d9ef6fc15faf3d2eb265552482664cbd3';ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};load=lambda p:json.loads(p.read_text());sha=lambda raw:hashlib.sha256(raw).hexdigest()
artifact=load(w/'ci9633-failed-conformance-original-verification-v1.json');path=root/artifact['zipPath'];assert sha(path.read_bytes())==artifact['sha256']
def collect(path,current=False):
 cases=collections.Counter();methods=set();matrices=[];hashes={};outcomes=collections.Counter();failed=[];allFull=[]
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None
  if current:
   assert z.read('ci-rule-suite-commit.txt').decode().strip()==fixed
   assert 'ci-rules/summary.json' not in z.namelist()
   plan=json.loads(z.read('ci-rules/plan.json'));planned=[m for s in plan['shards'] for m in s['methods']];assert len(planned)==len(set(planned))==plan['discoveredMethods']==7671
  for name in z.namelist():
   if not name.endswith('/results.trx'):continue
   raw=z.read(name);hashes[name]=sha(raw);doc=ET.fromstring(raw);rows=doc.findall('.//t:UnitTestResult',ns);actual=set();defs={d.get('id'):d.find('t:TestMethod',ns).attrib for d in doc.findall('.//t:UnitTest',ns)}
   counter=doc.find('.//t:Counters',ns).attrib;assert int(counter['total'])==len(rows) and counter['notExecuted']=='0'
   assert sum(r.get('outcome')=='Passed' for r in rows)==int(counter['passed']) and sum(r.get('outcome')=='Failed' for r in rows)==int(counter['failed'])
   for row in rows:
    d=defs[row.get('testId')];method=d['className']+'.'+d['name'];methods.add(method);actual.add(method);cases[row.get('testName')]+=1;outcomes[row.get('outcome')]+=1
    if row.get('outcome')!='Passed':failed.append({'case':row.get('testName'),'outcome':row.get('outcome'),'detail':'\n'.join(row.itertext())})
    if method.startswith('Riftbound.ConformanceTests.FullGameEndToEndTests.'):
     assert row.get('outcome')=='Passed';allFull.append(row.get('testName'))
    for output in row.findall('.//t:StdOut',ns):
     for line in (output.text or '').splitlines():
      if line.startswith('PRECONSTRUCTED_MATRIX '):matrices.append(json.loads(line[len('PRECONSTRUCTED_MATRIX '):]))
   if current:assert actual==set(next(s['methods'] for s in plan['shards'] if s['name']==name.split('/')[-2]))
  if current:assert methods==set(planned)
 return cases,methods,matrices,hashes,outcomes,failed,allFull
current=collect(path,True);prior=load(root/'var/qa/late-seat-command-inputs-20261022/cibe0e-entire-full-independent-verification-v1.json');p=next(a for a in prior['artifacts'] if a['name']=='conformance-results');assert sha(Path(p['path']).read_bytes())==p['sha256'];before=collect(Path(p['path']))
assert sum(current[0].values())==13518 and len(current[1])==7671 and current[4]=={'Passed':13505,'Failed':13}
assert sum(before[0].values())==13497 and len(before[1])==7662 and before[4]=={'Passed':13497}
assert not(before[0]-current[0]) and before[1]<=current[1];added=current[0]-before[0];addedMethods=current[1]-before[1];assert sum(added.values())==21 and len(addedMethods)==9 and all('RoomSeatJournalTests.' in c for c in added)
expectedMethods=load(root/'var/qa/late-seat-command-inputs-20261022/final-current-atomic-room-seat-original-retention-v1.json')['newMethodNames'];assert addedMethods==set(expectedMethods)
assert len(current[5])==13 and {r['case'] for r in current[5]}=={r['case'] for r in artifact['failures']} and all('stored match requires authoritative state with recorded rule input identity' in r['detail'] for r in current[5])
assert len({m for m in current[1] if m.startswith('Riftbound.ConformanceTests.FullGameEndToEndTests.')})==143 and set(current[6])==set(before[6])
assert len(current[2])==1;matrix=current[2][0];assert (matrix['seed'],matrix['deckCount'],matrix['pairCount'])==(424242,11,110) and set(matrix['completed'])==set(prior['matrix']['completed']) and all(re.fullmatch('[0-9a-f]{64}',h) for h in matrix['completed'].values())
proof={'status':'FIXED9633_RULE_SUITE_FAILED_13_ORIGINAL_REAL_SQL_PRECONDITION_CASES_ALL_METHODS_CASES_FULL_GAMES_AND_MATRIX_PRESERVED','atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fixedCommit':fixed,'runId':39665645745,'artifact':artifact,'actualCases':13518,'actualMethods':7671,'actualOutcomes':dict(current[4]),'allOriginalBe0e13497CaseMultiset7662MethodsRetained':True,'onlyAdded21RoomSeatCasesNineMethods':dict(added),'all143FullGameMethodsAnd151FullGameCasesPassed':True,'matrix':matrix,'all110Pairs11DecksSeed424242Exact':True,'matrixTerminalHashesDifferentFromPrior':sum(matrix['completed'][k]!=prior['matrix']['completed'][k] for k in matrix['completed']),'allOriginal13FailedCaseIdentitiesAndFailureMessagesRetained':current[5],'trxSha256':current[3],'localSoleCheckHadNoDatabaseThereforeNotRealSqlValidation':True,'noGlobalFullSuccessClaim':True,'otherCiJobsMustBeReadAtTheirActualTerminal':True,'wholePrintingOrGoalComplete':False}
p=w/'ci9633-original-failed-rule-suite-independent-verification-v1.json';assert not p.exists();p.write_text(json.dumps(proof,ensure_ascii=False,indent=2));print('PASS independent original failure readback:13518/7671 actual 13505pass13fail;143full151cases,110pairs11decks424242 pass;all prior cases/methods retained; no full success claim.')
