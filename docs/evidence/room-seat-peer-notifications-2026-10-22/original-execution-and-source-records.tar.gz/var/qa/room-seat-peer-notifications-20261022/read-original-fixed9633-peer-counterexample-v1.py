from pathlib import Path
import ast,datetime,fcntl,gzip,hashlib,json,os,plistlib,re,resource,shutil,socket,subprocess
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;old=root/'var/qa/fixed9633-early-native-20261022'
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
source=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py';nodes=[n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),globals())
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
previous=load(old/'live-current-ci-main-owner-terminal-v2.json');room=previous['originalPartialPrefixRoom'];assert re.fullmatch('N27-RETARGET-[0-9A-F]{10}',room)
assert previous['ownPostgresSmartStopped'] and previous['allOriginal331AuditSevenTablesExactAtStop'] and previous['allOriginal66NativeSevenTablesExactAtStop']
assert len(previous['actualAuditRoomsAtStop'])==331 and len(previous['actualNativeRoomsAtStop'])==67
api=load(old/'fixed9633-api-gameplay-closure-frozen-inputs-v1.json');r=w/'independent-fixed9633-peer-counterexample-runtime-v1';assert not r.exists()
subprocess.run(['/bin/cp','-cR',api['runtimeRoot'],str(r)],check=True)
for suffix in ['.dll','.pdb']:shutil.copy2(w/'independent-fixed9633-peer-counterexample-source-v1/bin/Release/net10.0'/('IndependentFixed9633RoomSeatPeerCounterexampleV1'+suffix),r/('IndependentFixed9633RoomSeatPeerCounterexampleV1'+suffix))
frozen={str(p.relative_to(r)):sha(p) for p in r.rglob('*') if p.is_file()}
assert all(frozen[p]==h for p,h in api['runtimeFiles'].items())
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof={'status':'RUNNING_INDEPENDENT_READ_ONLY_ORIGINAL_FIXED9633_PEER_FAILURE','startedAtUtc':now(),'room':room,'fixedCommit':previous['fixedCommit'],'lockAtStart':observe_lock(),'runtimeFiles':frozen,'runtimeRoot':str(r)}
started=False;power=None;audit=native=before_audit=before_native=None
try:
 assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid
 sock.mkdir(exist_ok=True);subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'original-fixed9633-read-only-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 audit=rooms('riftbound_acceptance');native=rooms('riftbound_here_native');assert audit==previous['actualAuditRoomsAtStop'] and native==previous['actualNativeRoomsAtStop']
 before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',native)
 raw={table:json.loads(query('riftbound_here_native',f"select coalesce(json_agg(t order by row_to_json(t)::text),'[]'::json)::text from (select * from {table} where match_id='{room}')t")) for table in tables}
 raw_path=w/'original-fixed9633-peer-failure-all-seven-table-rows-v1.json.gz';raw_path.write_bytes(gzip.compress(json.dumps({'room':room,'originalRows':raw},ensure_ascii=False,indent=2).encode(),mtime=0));proof['actualOriginalSevenTableCounts']={t:len(v) for t,v in raw.items()};proof['originalSevenTableRowsSha256']=sha(raw_path)
 result=w/'independent-original-fixed9633-peer-counterexample-result-v1.json'
 args=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(r/'Riftbound.Api.deps.json'),'--runtimeconfig',str(r/'Riftbound.Api.runtimeconfig.json'),str(r/'IndependentFixed9633RoomSeatPeerCounterexampleV1.dll'),str(old),str(result)];proof['originalCommand']=args
 with (w/'independent-original-fixed9633-peer-counterexample-v1.log').open('xb') as log:code=subprocess.run(args,cwd=r,env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit',DOTNET_DbgEnableMiniDump='0'),stdout=log,stderr=subprocess.STDOUT,timeout=90).returncode
 proof['independentReaderExitCode']=code;assert code==0
 d=load(result);assert d['room']==room and d['commands']==3 and d['events']==2 and d['everyOriginalCommandReplayed']==3 and d['actualRuleInputs']==load(old/'fixed9633-api-actual-rule-inputs-v1.json')
 proof.update(status=d['status'],independentResultSha256=sha(result),readOnlyOriginalFrameAndAllThreeCommandsAndTwoAuthorityHistoriesAndThreePrivateViewsPass=True)
except BaseException as e:
 proof.update(status='FAILED_INDEPENDENT_READER_ORIGINAL_SQL_AND_SOURCE_RETAINED_NO_WRITER_RERUN',errorType=type(e).__name__,error=str(e));raise
finally:
 if started:
  if before_audit is not None:
   proof['allOriginal331AuditSevenTablesExact']=digests('riftbound_acceptance',audit)==before_audit;proof['allOriginal67NativeSevenTablesExact']=digests('riftbound_here_native',native)==before_native
   proof['actualAuditRoomsAtStop']=rooms('riftbound_acceptance');proof['actualNativeRoomsAtStop']=rooms('riftbound_here_native')
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None and power.poll() is None:power.terminate();power.wait(timeout=10)
 proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),all48FrozenReaderRuntimeFilesStable=all(sha(r/p)==h for p,h in frozen.items()),originalRoomSeedCommandsEventsAndAllDatabasesRetained=True)
 with (w/'independent-original-fixed9633-peer-counterexample-owner-terminal-v1.json').open('x') as f:json.dump(proof,f,indent=2)
 fcntl.flock(guard,fcntl.LOCK_UN)
print(proof['status'],flush=True)
