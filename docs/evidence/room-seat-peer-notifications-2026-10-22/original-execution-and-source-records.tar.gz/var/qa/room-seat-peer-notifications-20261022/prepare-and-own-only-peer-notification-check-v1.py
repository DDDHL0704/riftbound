from pathlib import Path
import ast,datetime,hashlib,json,os,plistlib,resource,subprocess
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
parent='96334b9d9ef6fc15faf3d2eb265552482664cbd3';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==parent
previous=load(root/'var/qa/late-seat-command-inputs-20261022/current-room-seat-frozen-runtime-inputs-v2.json')
names=set(previous['sourceInputHashes'])|{'tests/Riftbound.ConformanceTests/GameHubRoomSeatNotificationTests.cs'}
inputs={p:sha(root/p) for p in sorted(names)};modes={p:oct((root/p).stat().st_mode&0o777) for p in sorted(names)};assert len(inputs)==3337
changed={p for p in previous['sourceInputHashes'] if inputs[p]!=previous['sourceInputHashes'][p]}
assert changed=={'src/Riftbound.Api/Hubs/GameHub.cs','tests/Riftbound.NativeNetworkSmoke/Program.cs'},changed
network=load(w/'current-peer-notification-real-network-owner-terminal-v1.json');assert network['networkExitCode']==0 and network['allOriginal331AuditSevenTablesExact'] and network['allOriginal67NativeSevenTablesExact'] and network['ownPostgresSmartStopped']
baseline=load(root/'var/qa/late-seat-command-inputs-20261022/only-check-start-inputs-v1.json')
paths={k:{str(p.relative_to(root)):sha(p) for p in (root/folder).rglob('*') if p.is_file() and not str(p.relative_to(root)).startswith(baseline['excludedGeneratedOutputDirectory']+'/')} for k,folder in [('Conformance','tests/Riftbound.ConformanceTests/bin/Debug/net10.0'),('Native','clients/godot/.godot/mono/temp/bin/Debug')]}
assert len(paths['Conformance'])==1419 and len(paths['Native'])==23
assert set(paths['Conformance'])==set(baseline['actualConformanceRuntimeFileHashes']) and set(paths['Native'])==set(baseline['actualNativeRuntimeFileHashes'])
runtime=root/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0';reader=root/'var/qa/fixed9633-early-native-20261022/fixed9633-native-history-reader-runtime-v2/Fixed9633NativeHistoryReaderV2.dll'
actual=json.loads(subprocess.check_output(['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(runtime/'Riftbound.ConformanceTests.deps.json'),'--runtimeconfig',str(runtime/'Riftbound.ConformanceTests.runtimeconfig.json'),str(reader),'--loaded-inputs'],cwd=runtime,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0')))
assert Path(actual['baseDirectory'])==runtime and len(actual['assemblies'])==4
for a in actual['assemblies']:assert Path(a['path'])==runtime/(a['name']+'.dll') and a['sha256']==paths['Conformance'][str((runtime/(a['name']+'.dll')).relative_to(root))]
definition=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py';nodes=[n for n in ast.parse(definition.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='observe_lock'];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(definition),'exec'),globals())
start={'atUtc':now(),'baseCommit':parent,'includesDeclaredUncommittedChanges':True,'sourceInputCount':3337,'sourceInputHashes':inputs,'sourceInputModes':modes,'excludedGeneratedOutputDirectory':baseline['excludedGeneratedOutputDirectory'],'actualConformanceRuntimeFileCount':1419,'actualConformanceRuntimeFileHashes':paths['Conformance'],'actualNativeRuntimeFileCount':23,'actualNativeRuntimeFileHashes':paths['Native'],'actualLoadedDebugBaseFourAssembliesAndRuleInputs':actual,'originalBaselineTrx':'var/qa/late-seat-command-inputs-20261022/only-check-v1/check/results.trx','originalBaselineTrxWasSixFailuresAndNotRelabeled':True,'expectedCases':13379,'expectedMethods':7534,'onlyOneCheckForCoherentApiPeerNotificationBatch':True,'allOriginal1800ConformanceFiles143FullMethods110Pairs11DecksSeed424242VictoryAndReplayAssertionsRetained':True,'actualNetworkOriginal15AndNewPeerPushAlreadyPassed':True,'currentNetworkAndUiNotReclassifiedAsVisibleOrWindows':True,'lockAtStart':observe_lock()}
start['originalBaselineTrxSha256']=sha(root/start['originalBaselineTrx'])
with (w/'only-check-start-inputs-v1.json').open('x') as f:json.dump(start,f,indent=2)
output=w/'only-check-v1';terminal=w/'only-check-owner-terminal-v1.json';assert not output.exists() and not terminal.exists()
command=['python3','scripts/test-rules.py','check','--output',str(output)];proof={'startedAtUtc':now(),'command':command,'lockAtStart':start['lockAtStart'],'currentDebugRuleInputs':actual['actualRuleInputs']}
print('SOLE_PEER_NOTIFICATION_CHECK_STARTED_3337_SOURCE_INPUTS_1419_CONFORMANCE_23_NATIVE_STABLE',flush=True)
try:
 with (w/'only-check-console-v1.log').open('xb') as log:
  child=subprocess.Popen(command,cwd=root,stdout=log,stderr=subprocess.STDOUT);power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(child.pid)]);proof['exitCode']=child.wait();power.wait(timeout=10)
finally:
 proof.update(finishedAtUtc=now(),lockAtStop=observe_lock(),all3337SourceHashesAndModesStable=all(sha(root/p)==h and oct((root/p).stat().st_mode&0o777)==modes[p] for p,h in inputs.items()),all1419ConformanceRuntimeInputsStable=all(sha(root/p)==h for p,h in paths['Conformance'].items()),all23NativeDebugRuntimeInputsStable=all(sha(root/p)==h for p,h in paths['Native'].items()))
 with terminal.open('x') as f:json.dump(proof,f,indent=2)
print(json.dumps(proof),flush=True)
assert proof['exitCode']==0 and all(proof[k] for k in ['all3337SourceHashesAndModesStable','all1419ConformanceRuntimeInputsStable','all23NativeDebugRuntimeInputsStable'])
