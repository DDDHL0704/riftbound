from pathlib import Path
import collections,datetime,hashlib,json,subprocess,xml.etree.ElementTree as ET
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pin=lambda p:{'path':str(p.relative_to(root)),'sha256':sha(p)}
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def read(path):
 tree=ET.parse(path);defs={r.get('id'):r.find('t:TestMethod',ns).attrib for r in tree.findall('.//t:UnitTest',ns)};rows=tree.findall('.//t:UnitTestResult',ns)
 return rows,collections.Counter(r.get('testName') for r in rows),{defs[r.get('testId')]['className']+'.'+defs[r.get('testId')]['name'] for r in rows}
start=load(w/'only-check-start-inputs-v1.json');end=load(w/'only-check-owner-terminal-v1.json')
assert end['exitCode']==0 and all(end[k] for k in ['all3337SourceHashesAndModesStable','all1419ConformanceRuntimeInputsStable','all23NativeDebugRuntimeInputsStable'])
baseline=root/start['originalBaselineTrx'];assert sha(baseline)==start['originalBaselineTrxSha256']
trx=w/'only-check-v1/check/results.trx';rows,counts,methods=read(trx);oldrows,oldcounts,oldmethods=read(baseline)
assert (len(rows),len(methods),len(oldrows),len(oldmethods))==(13379,7534,13369,7530)
assert all(r.get('outcome')=='Passed' for r in rows) and not(oldcounts-counts) and oldmethods<=methods
added=counts-oldcounts;added_methods=methods-oldmethods;assert sum(added.values())==10 and len(added_methods)==4 and all('.RoomSeatPeer' in case for case in added)
focus,_,focusmethods=read(w/'all-hub-and-room-seat-focus-v2/focus/results.trx');assert len(focus)==307 and len(focusmethods)==256 and all(r.get('outcome')=='Passed' for r in focus)
assert set(added)=={r.get('testName') for r in focus if '.RoomSeatPeer' in r.get('testName')}
oldfailed=[r.get('testName') for r in oldrows if r.get('outcome')!='Passed'];assert len(oldfailed)==6
assert all(next(r for r in rows if r.get('testName')==name).get('outcome')=='Passed' for name in oldfailed)
frozen=load(w/'peer-notification-wip-api-and-network-frozen-inputs-v1.json');oldfiles=frozen['allOriginalConformanceTrackedFilesExactBaseCommit']
assert len(oldfiles)==1800 and all(sha(root/p)==h for p,h in oldfiles.items())
full={p:h for p,h in oldfiles.items() if Path(p).name.startswith('FullGameEndToEndTests')};assert len(full)==9
assert all((root/p).read_bytes()==subprocess.check_output(['git','show',start['baseCommit']+':'+p],cwd=root) for p in full)
assert all(sha(root/p)==h and oct((root/p).stat().st_mode&0o777)==start['sourceInputModes'][p] for p,h in start['sourceInputHashes'].items())
network=load(w/'current-peer-notification-real-network-owner-terminal-v1.json');independent=load(w/'independent-current-peer-network-result-v1.json');reader=load(w/'independent-current-peer-network-owner-terminal-v1.json')
assert network['networkExitCode']==0 and network['originalIdentityEvidence']['rejectedActions']==15 and network['originalIdentityEvidence']['leakedPrivateMessages']==0
assert independent['totals']=={'commands':3,'events':3,'authority':3,'snapshots':4,'prompts':4} and reader['allOriginal331AuditSevenTablesExact'] and reader['allOriginal69NativeSevenTablesExact'] and reader['ownPostgresSmartStopped']
result={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'SOLE_CHECK_ALL_PASS_ALL_ORIGINAL_CASES_METHODS_AND_3337_INPUTS_RETAINED','baseCommit':start['baseCommit'],'actualCases':len(rows),'actualMethods':len(methods),'outcomes':dict(collections.Counter(r.get('outcome') for r in rows)),'oldCaseCount':len(oldrows),'oldMethodCount':len(oldmethods),'oldExactCaseMultisetAndMethodsRetained':True,'oldSoleCheckOriginalSixFailuresRetainedNotRelabeled':oldfailed,'thoseSixIdentitiesNowPassInThisNewCheck':True,'newCases':10,'newMethods':4,'newCaseIdentities':sorted(added.elements()),'newMethodNames':sorted(added_methods),'finalFocusCases':307,'finalFocusMethods':256,'all1800OriginalConformanceTrackedFilesByteExact':True,'allNineOriginalFullGameSources':full,'all143OriginalPublicFullMethods110Pairs11Decks424242VictoryAndReplayAssertionsRetained':True,'currentAll143And110FixedFullNotClaimedByThisCheck':True,'actualDebugRuleInputs':start['actualLoadedDebugBaseFourAssembliesAndRuleInputs']['actualRuleInputs'],'actualWipReleaseRuleInputs':network['actualLoadedFourAssemblies']['actualRuleInputs'],'originalNativeNetwork15GuardsAndAssertionsByteExact':frozen['allOriginalNativeNetworkGuardsByteExactAfterRemovingOnlyNewInvocationAndNewMethod'],'newPeerWireRoomSnapshotRequests':0,'newPeerWireRoomCommandRetries':0,'independentTwoNetworkRoomsTotals':independent['totals'],'allOriginal331Audit69NativeSevenTablesRetained':True,'onlyCheckTrx':pin(trx),'originalBaselineTrx':pin(baseline),'all3337SourcesAndModes1419Conformance23NativeDebugInputsStable':True,'noSecondCheck':True,'newFixedFullCurrentNativeNormalScoreVisiblePairAndPhysicalWindows':'OPEN','wholePrintingOrGoalCertified':False}
with (w/'final-only-check-original-retention-v1.json').open('x') as f:json.dump(result,f,ensure_ascii=False,indent=2)
print('PASS solecheck13379/7534; original13369/7530 retained +10/4;307/256focus; all1800 old files,143/110/11/424242 retained; source/runtime stable; fixed full/products OPEN.')
