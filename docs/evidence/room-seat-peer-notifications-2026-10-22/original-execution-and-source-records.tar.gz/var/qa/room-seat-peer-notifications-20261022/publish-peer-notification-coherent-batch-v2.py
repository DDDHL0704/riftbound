from pathlib import Path
import copy,datetime,gzip,hashlib,io,json,re,tarfile
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
native=root/'var/qa/fixed9633-early-native-20261022';video=root/'var/qa/current-global-video-source-20261022';next_source=root/'var/qa/frost-controller-source-plan-20261022';older=root/'var/qa/late-seat-command-inputs-20261022'
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(path,value):
 with path.open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2)
def pin(path,role=None):
 d={'path':str(path.relative_to(root)),'sha256':sha(path)}
 if role:d['role']=role
 return d
final=load(w/'final-only-check-original-retention-v1.json');assert(final['actualCases'],final['actualMethods'],final['newCases'],final['newMethods'])==(13379,7534,10,4)
start=load(w/'only-check-start-inputs-v1.json');post=load(w/'final-after-ci13-fixture-correction-retention-v1.json');assert post['finalRealSqlFocusCases']==326 and post['finalRealSqlFocusMethods']==263 and all(sha(root/p)==h for p,h in post['final3337SourceInputHashes'].items())
assert {p for p,h in post['final3337SourceInputHashes'].items() if h!=start['sourceInputHashes'][p]}=={'tests/Riftbound.ConformanceTests/PostgresMatchRecoveryStoreSmokeTests.cs'}
network=load(w/'current-peer-notification-real-network-owner-terminal-v1.json');independent=load(w/'independent-current-peer-network-result-v1.json');reader=load(w/'independent-current-peer-network-owner-terminal-v1.json')
assert network['networkExitCode']==0 and independent['totals']=={'commands':3,'events':3,'authority':3,'snapshots':4,'prompts':4} and reader['allOriginal331AuditSevenTablesExact'] and reader['allOriginal69NativeSevenTablesExact'] and reader['ownPostgresSmartStopped']
issue=load(w/'confirmed-peer-notification-issue-publication-verification-v1.json');assert issue['issue']==87
prior=w/'prior-peer-notification-publication-v1';mp=root/'docs/audit/current-manifest.json';m=load(mp);rp=root/m['inputs']['reviews']['path'];reviews=load(rp)
for p in [mp,rp,root/'docs/PROJECT_STATUS.md']:assert gzip.decompress((prior/(p.name+'.gz')).read_bytes())==p.read_bytes()
oldm=copy.deepcopy(m);oldreviews=copy.deepcopy(reviews);assert(len(reviews['reviews']),len(m['reviewContexts']),len(m['acceptanceGates']),len(m['laterSourceDeltas']))==(162,77,250,7)
assert all(sha(root/ref['path'])==ref['sha256'] for c in m['reviewContexts'].values() for ref in c['implementation'])
baseline=root/'docs/evidence/room-seat-journal-inputs-2026-10-22/final-governance.json.gz';oldgov=json.loads(gzip.decompress(baseline.read_bytes()));assert oldgov['governanceValid'] and len(oldgov['remainingObligations'])==17114
identity='room-seat-peer-notifications-2026-10-22';doc='docs/ROOM_SEAT_PEER_NOTIFICATIONS_AUDIT_2026-10-22.md';ev=root/'docs/evidence/room-seat-peer-notifications-2026-10-22';ev.mkdir(exist_ok=True);assert not any(ev.iterdir())

# Retain only executed own payloads; framework/SDK dependencies stay in their
# measured immutable local runtimes and are not copied into this archive.
bits=w/'executed-own-reader-api-and-network-bits-v1';bits.mkdir();bit_rows=[]
executed=[('fixed9633-reader-v1',native/'fixed9633-native-history-reader-runtime-v1','Fixed9633NativeHistoryReaderV1'),('fixed9633-reader-v2',native/'fixed9633-native-history-reader-runtime-v2','Fixed9633NativeHistoryReaderV2'),('original-counterexample-reader',w/'independent-fixed9633-peer-counterexample-runtime-v1','IndependentFixed9633RoomSeatPeerCounterexampleV1'),('current-peer-network-reader',w/'independent-current-peer-network-runtime-v1','IndependentCurrentRoomSeatPeerNetworkV1'),('original-fixed9633-api',native/'fixed9633-api-gameplay-closure-runtime-v1','Riftbound.Api'),('current-wip-api',w/'peer-notification-wip-api-runtime-v1','Riftbound.Api'),('current-wip-net8-network',w/'peer-notification-wip-network-net8-runtime-v1','Riftbound.NativeNetworkSmoke')]
for label,folder,assembly in executed:
 for extension in ['.dll','.pdb']:
  original=folder/(assembly+extension);target=bits/(label+'-'+original.name);target.write_bytes(original.read_bytes());assert sha(original)==sha(target);bit_rows.append({'original':pin(original),'retained':pin(target)})
assert len(bit_rows)==14;write(w/'executed-own-reader-api-network-bit-retention-v1.json',{'atUtc':now(),'bits':bit_rows,'actualFourRuleAssemblyHashesMvidAndControlMetadataAlreadyMeasured':True,'sharedRulesAndFrameworkDependenciesRemainInImmutableLocalRuntimes':True})

# The full AX read is kept locally; publish only primary-page text before the
# unrelated public comment/recommendation tail, plus the original source pixels.
raw_ax=video/'official-video-expanded-primary-description.ax.txt';text=raw_ax.read_text();cut=text.find('container sections');primary=text if cut<0 else text[:text.rfind('\n',0,cut)]
assert 'Bring the Heat: Riftbound x K/DA Couture Collection Cards, Featuring Art by Fortiche' in primary and '2026年10月22日' in primary
primary_path=video/'official-video-primary-description-excerpt.ax.txt';primary_path.write_text(primary)
write(video/'published-primary-description-excerpt-retention.json',{'atUtc':now(),'originalLocal':pin(raw_ax),'primaryExcerpt':pin(primary_path),'exclusionReason':'PUBLIC_UNRELATED_COMMENT_AND_RECOMMENDATION_TAIL_NOT_NEEDED_IN_PUBLISHED_SOURCE_PACKAGE','allFiveExactPrintingGatesRemainOpen':True,'browserDisplayedDateNotConvertedToUtcOrGameEffectiveDate':True})

oldmap_path=root/'docs/evidence/room-seat-journal-inputs-2026-10-22/archive-map.json';oldmap=load(oldmap_path);old_by_sha={}
for row in oldmap['members']:old_by_sha.setdefault(row['sha256'],row)
members={};reuse=[];excluded=[];runtime_dirs={p.name for base in [w,native] for p in base.iterdir() if p.is_dir() and 'runtime' in p.name.lower()}
secret=re.compile(rb'(?i)(?:playerKey|reconnectToken)[\"\s]*[:=][\s\"]*((?:rt_|qa-)[a-z0-9_+/-]{16,})')
paths=[]
for base in [w,native,video,next_source]:paths.extend(p for p in base.rglob('*') if p.is_file())
for p in older.iterdir():
 if p.name.startswith(('cibe0e','exact-fixedbe0e')):paths.extend(p.rglob('*') if p.is_dir() else [p])
paths.extend(older/p for p in ['download-completed-fixedbe0e-nine-originals-v1.py','verify-completed-fixedbe0e-full-originals-v1.py'])
for p in sorted(set(paths)):
 if not p.is_file():continue
 parts=set(p.relative_to(root).parts);reason=None
 if runtime_dirs&parts or {'bin','obj','__pycache__'}&parts or any(part.endswith('.app') for part in parts):continue
 if p.name in {'mac-ci-artifact.zip','windows-ci-artifact.zip'}:continue
 if p.name.startswith('session-') and p.suffix=='.json':reason='CURRENT_PRIVATE_QA_AUTH_PROFILE_RETAINED_LOCALLY_NOT_PUBLISHED'
 if p==raw_ax:reason='UNRELATED_PUBLIC_COMMENT_TAIL_ORIGINAL_RETAINED_LOCALLY_PRIMARY_SOURCE_EXCERPT_PUBLISHED'
 if reason:excluded.append({'path':str(p.relative_to(root)),'sha256':sha(p),'bytes':p.stat().st_size,'reason':reason});continue
 raw=p.read_bytes();inspect=raw
 if p.suffix=='.gz':
  try:inspect=gzip.decompress(raw)
  except OSError:pass
 if p.suffix in {'.json','.log','.ndjson','.txt','.gz'}:assert not secret.search(inspect),p
 name=str(p.relative_to(root));digest=hashlib.sha256(raw).hexdigest()
 if digest in old_by_sha:reuse.append({'path':name,'sha256':digest,'existingArchiveMember':old_by_sha[digest]['path'],'existingArchiveMap':pin(oldmap_path)})
 else:members[name]=p
archive=ev/'original-execution-and-source-records.tar.gz';archive_rows=[]
with tarfile.open(archive,'w:gz',compresslevel=9) as tar:
 for name,p in sorted(members.items()):
  raw=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(raw);info.mode=p.stat().st_mode&0o777;info.mtime=0;tar.addfile(info,io.BytesIO(raw));archive_rows.append({'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
with tarfile.open(archive,'r:gz') as tar:
 assert set(tar.getnames())=={r['path'] for r in archive_rows}
 for row in archive_rows:
  raw=tar.extractfile(row['path']).read();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
write(ev/'archive-map.json',{'atUtc':now(),'archive':pin(archive),'members':archive_rows,'existingIdenticalOlderArchiveMembersNotDuplicated':reuse,'privateOrUnrelatedExclusionsRetainedLocally':excluded,'allBytesHashesAndClosedSetVerified':True,'applicationsInstallersSdksAndFrozenRuntimeDependenciesNotDuplicated':True})

copies={'final-original-test-and-input-retention.json':w/'final-only-check-original-retention-v1.json','original-fixed9633-peer-counterexample.json':w/'independent-original-fixed9633-peer-counterexample-result-v1.json','original-fixed9633-peer-counterexample-terminal.json':w/'independent-original-fixed9633-peer-counterexample-owner-terminal-v1.json','current-native-connection-wire-evidence.json':w/'current-peer-notification-real-network-owner-terminal-v1.json','independent-current-native-wire-history-and-replay.json':w/'independent-current-peer-network-result-v1.json','independent-current-native-wire-owner-terminal.json':w/'independent-current-peer-network-owner-terminal-v1.json','actual-source-runtime-inputs.json':w/'only-check-start-inputs-v1.json','preceding-fixedbe0e-complete-full.json':older/'cibe0e-entire-full-independent-verification-v1.json','original-fixed9633-native-default-main-boot.json':native/'current-native-headless-boot-verification.json','superseded-native-pair-and-installers-retirement.json':native/'superseded-fixed7a-native-pair-and-two-archives-retirement-v1.json','global-kda-video-bounded-source-observation.json':video/'official-video-bounded-source-observation.json','current-sixteen-cn-source-readback.json':next_source/'current-cn-rule-directory-and-known-source-versions-v1.json','current-two-start-field-source-readback.json':next_source/'two-exact-start-battlefield-source-and-core-readback-v1.json','confirmed-issue87-exact-publication.json':w/'confirmed-peer-notification-issue-publication-verification-v1.json','preceding-fixed9633-original-failed-rule-suite.json':w/'ci9633-original-failed-rule-suite-independent-verification-v1.json','final-real-sql-ci13-fixture-correction-and-inputs.json':w/'final-after-ci13-fixture-correction-retention-v1.json'}
for name,p in copies.items():(ev/name).write_bytes(p.read_bytes())
current_ci=w/'ci9633-entire-full-independent-verification-v1.json'
if current_ci.exists():(ev/'preceding-fixed9633-complete-full.json').write_bytes(current_ci.read_bytes())
corpus=load(root/m['inputs']['corpus']['path']);record=next(r for r in corpus['records'] if r['id']=='DOC-01-P101-B004')
source_manifest={'schemaVersion':1,'id':identity,'atUtc':now(),'region':'CN','language':'zh-CN','applicableAsOf':'2026-10-22','adoptedCoreEffectiveDate':'2026-10-16','sourceBaseCommit':start['baseCommit'],'declaredUncommittedProductionApiOnlyRepairAndExactSqlFixtureCalibration':True,'scope':'Successful room entry publishes fresh per-viewer snapshots/prompts to the existing seated peer, preserving caller behavior, stale-prompt rejection, private groups and all original history. Engineering transport contract, not a new printed card rule.','formatContextOnly':[{'id':record['id'],'textSha256':hashlib.sha256(record['text'].encode()).hexdigest(),'role':'TWO_PLAYER_FORMAT_CONTEXT_NOT_OFFICIAL_NETWORK_NOTIFICATION_REQUIREMENT'}],'actualDebugRuleInputs':final['actualDebugRuleInputs'],'actualWipReleaseRuleInputs':final['actualWipReleaseRuleInputs'],'actualInputBindings':pin(ev/'actual-source-runtime-inputs.json'),'archive':pin(archive),'archiveMap':pin(ev/'archive-map.json'),'onlyCheck':{'cases':13379,'methods':7534,'passed':13379,'failed':0,'skipped':0,'noSecondCheck':True,'inputBoundary':'BEFORE_SQL_FIXTURE_CALIBRATION_NO_DATABASE_CONNECTION'},'finalRealSqlFocus':{'cases':326,'methods':263,'passed':326,'original13TamperBranchesActuallyExecuted':True},'finalSourceInputBindings':pin(ev/'final-real-sql-ci13-fixture-correction-and-inputs.json'),'newCases':10,'newMethods':4,'all1800OriginalConformanceMethodsTheoryRowsAndAssertionsRetained1799FilesByteExactOnlyOneFixtureSetupCorrected':True,'allNineOriginalFullSources143Methods110Pairs11Decks424242ByteExact':True,'fullScopeRetained':{'printings':1740,'ruleBlocks':14293,'cnRows':1504,'enRows':1408,'enReported':1416,'enGap':8,'active':1035,'outsideActive':705,'cnDispositions':236,'cnNews':139,'sourceDeltas':7},'sourceAcquisitionBoundary':'Fresh current16 CN document versions and two related battlefield rows/QA, plus a bounded official K/DA video observation. Earlier whole-CN/EN observations retain their own exact acquisition times; no new whole-gallery or whole-source semantic certification.','allOriginalSourceDatesScopeNewsAndSevenDeltasUnchanged':True,'currentNativeConnectionLibraryWireGate':'PASS_ORIGINAL15_ZERO_LEAK_AND_NEW_PEER_PUSH_WITHOUT_REQUEST_OR_RETRY','currentActualCiExportedDefaultMainWholePairNormalScoreReplayVisibleAndWindows':'OPEN','newFixedFullExpectedCases':13528,'newFixedFullExpectedMethods':7675,'newFixedFullExpectedSqlCases':57,'expectedCountsNotExecutedFullEvidence':True,'issue':issue['url'],'semanticCoverageCertified':False}
write(ev/'source-manifest.json',source_manifest);sp=pin(ev/'source-manifest.json','source-manifest')
branches=[{'id':'peer-view-'+hashlib.sha256(case.encode()).hexdigest()[:20],'sourceRefs':['DOC-01-P101-B004'],'state':'RECORDED','sourceManifest':sp,'boundedCase':{'actualExecutedCase':case,'formatClauseIsContextOnly':True,'issue':issue['url']},'semanticReview':{'state':'BOUNDED_ENGINEERING_VIEW_FRESHNESS_AND_PRIVACY_NOT_CARD_RULE_CERTIFICATION'},'implementation':{'state':'SUCCESSFUL_ROOM_JOIN_REFRESHES_EACH_SEATED_PEER_THROUGH_OWN_PRIVATE_PLAYER_GROUP'},'testExecution':{'state':'FOCUS307_SOLE_CHECK13379_BEFORE_SQL_FIXTURE_CALIBRATION_THEN_FINAL_REAL_SQL326_ORIGINAL15_NETWORK_GUARDS_AND_INDEPENDENT_TWO_ROOM_HISTORY_REPLAY_PASS'},'fixedCommitCi':{'state':'PENDING_NEW_FIXED_FULL'},'productAcceptance':{'state':'OPEN_CURRENT_FIXED_DEFAULT_MAIN_PAIR_SCORE_REPLAY_VISIBLE_AND_PHYSICAL_WINDOWS'},'decision':{'state':'OPEN','reason':'Local API/connection-library evidence does not close fixed full or current native product gates.'},'wholePrintingCertified':False,'existingAcceptanceGateDependencies':['FIXED_CURRENT_CANDIDATE_FULL','VISIBLE_PAIRED_SQL_NETWORK_SCORE_REPLAY','USER_WINDOWS_RUNTIME']} for case in final['newCaseIdentities']]
assert len(branches)==10;assert all(g in {x['id'] for x in m['acceptanceGates']} for g in branches[0]['existingAcceptanceGateDependencies'])
write(ev/'ten-exact-peer-notification-behavior-branches.json',{'branches':branches})
m['reviewContexts'][identity]={'evidenceCommit':start['baseCommit'],'currentImplementationCommit':start['baseCommit'],'currentImplementationIncludesUncommittedChanges':True,'ciState':'PENDING','ciReceipts':[],'region':'CN','language':'zh-CN','applicableAsOf':'2026-10-22','adoptedCoreEffectiveDate':'2026-10-16','sourceManifest':sp,'implementation':[pin(root/'src/Riftbound.Api/Hubs/GameHub.cs','implementation')],'verificationSources':[pin(root/p,'verification-source') for p in ['tests/Riftbound.ConformanceTests/GameHubRoomSeatNotificationTests.cs','tests/Riftbound.NativeNetworkSmoke/Program.cs','tests/Riftbound.ConformanceTests/PostgresMatchRecoveryStoreSmokeTests.cs']],'branches':branches,'evidence':[pin(ev/name,role) for name,role in [('final-original-test-and-input-retention.json','focus-check-and-retention'),('original-fixed9633-peer-counterexample.json','original-failure'),('current-native-connection-wire-evidence.json','native-connection-library'),('independent-current-native-wire-history-and-replay.json','independent-sql-history-replay')]]}
reviews['reviews'].append({'id':identity,'scope':source_manifest['scope'],'subjects':[],'ruleRecords':['DOC-01-P101-B004'],'status':'BOUNDED_API_PEER_VIEW_FOCUS_SOLE_CHECK_REAL_NETWORK_INDEPENDENT_HISTORY_REPLAY_PASS_NEW_FIXED_FULL_AND_PRODUCTS_OPEN','sourceManifest':sp,'auditDocument':doc,'validation':{'newCases':10,'newMethods':4,'focusCases':307,'focusMethods':256,'onlyCheckCases':13379,'onlyCheckMethods':7534,'onlyCheckBeforeSqlFixtureCorrectionAndWithoutSqlConnection':True,'finalRealSqlFocusCases':326,'finalRealSqlFocusMethods':263,'original13SqlTamperCasesActuallyExecuted':True,'networkOriginalRejectedActions':15,'networkLeakedPrivateMessages':0,'newNetworkRooms':2,'sqlCommands':3,'sqlEvents':3,'authorityHistories':3,'privateSnapshots':4,'privatePrompts':4,'wholePrintingCertified':False},'exclusions':['Actual CI exported full default-Main pair, cold restart, ordinary score and full historical replay remain new-candidate product gates.','Visible native controls and paired windows, and physical Windows remain separate OPEN.','Old native41 history failure and fixed9633 peer failure remain original, not migrated or rewritten.','Frost issue84 is read-only planned, not implemented in this batch; all source gaps and original scope retained.']})
assert reviews['reviews'][:162]==oldreviews['reviews'] and all(m['reviewContexts'][k]==v for k,v in oldm['reviewContexts'].items()) and m['acceptanceGates']==oldm['acceptanceGates'] and m['laterSourceDeltas']==oldm['laterSourceDeltas']
assert(len(reviews['reviews']),len(m['reviewContexts']),len(m['acceptanceGates']))==(163,78,250)
rp.write_text(json.dumps(reviews,ensure_ascii=False,indent=2)+'\n');m['inputs']['reviews']['sha256']=sha(rp)
m['currentRoomSeatPeerViewInputChange']={'sourceManifest':sp,'auditDocument':doc,'issue':issue['url'],'onlyNewBoundedBranches':10,'all162OldReviews77OldContexts250GatesAndSevenDeltasExact':True,'original17114RemainingObligationIdsMustRemain':True,'expectedRemainingObligations':17124,'noSecondCheck':True,'newFixedFullAndCurrentNativeVisiblePairedAndPhysicalWindows':'OPEN','wholePrintingOrGoalComplete':False}
m['precedingFixedBe0eActualCompleteFullCiReadback']=pin(ev/'preceding-fixedbe0e-complete-full.json')
m['precedingFixed9633ActualFailedRuleSuiteReadback']=pin(ev/'preceding-fixed9633-original-failed-rule-suite.json')
m['currentRealSqlIdentityFixtureCalibration']=pin(ev/'final-real-sql-ci13-fixture-correction-and-inputs.json')
m['currentGlobalKdaOfficialVideoBoundedSourceReadback']={'evidence':pin(ev/'global-kda-video-bounded-source-observation.json'),'allFiveExistingExactPrintingApplicabilityGatesRemainOpen':True,'noNewPrintingUniverseOrEightRowGalleryGapMerge':True,'runtimeCatalogNotAdopted':True}
if current_ci.exists():m['precedingFixed9633ActualCompleteFullCiReadback']=pin(ev/'preceding-fixed9633-complete-full.json')
mp.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
write(ev/'publication-original-governance-object-retention.json',{'atUtc':now(),'allCompleteOldReviewContextGateAndDeltaObjectsExact':True,'oldReviews':162,'oldContexts':77,'oldGates':250,'oldDeltas':7,'originalObligationCount':17114,'newBranches':10,'expectedRemainingObligations':17124,'noExistingSourceOrImplementationContextRebindingNeeded':True,'originalCompleteManifestReviewsAndStatusInArchive':True,'baselineGovernance':pin(baseline),'semanticCoverageCertified':False})

document='''# 入房后对手私有视图更新的限定审查

本批地区CN、语言zh-CN、适用2026-10-22，核心仍为10-16生效版本。[来源与执行manifest](evidence/room-seat-peer-notifications-2026-10-22/source-manifest.json)限定工程通知行为；DOC-01-P101-B004只提供双人格式背景，不把网络通知虚构成官方卡牌规则。Goal active / NOT READY。

固定96334b9d已有真实入座日志和正确EMPTY回放，但第二人入房将tick1推进至tick2，GameHub只向调用者发送私有快照/提示，第一人仍用原tick1交牌而被PROMPT_EXPIRED拒绝。[#87](https://github.com/DDDHL0704/riftbound/issues/87)与#85原历史初态问题分开。原房N27-RETARGET-371369567B保留两条接受的ROOM_SEAT、一条原SUBMIT_DECK拒绝及两事件；八条原网络视图中A始终tick1、B为tick2，拒绝指令确用A实际收到的promptId。独立只读原七表、两权威历史/三快照/三提示、三个完整原前缀及严格回放通过：SQL有A的tick2视图，网络没有交付。原种子、初态和拒绝不重写，不重提或迁移旧局。

修复仅在API成功入房后刷新已入座对手。调用者仍走原消息路径，每名对手只通过自己的player私有组收到其快照/提示，保持服务端权威和过期提示拒绝。引擎、目录、Contracts、Persistence及官方运行输入源码与父提交一致，没有扩展DSL。实际Debug身份d35d95b6e61320c34548197006400d35769c1a858d90de2e747c90e8d33c5518和WIP Release7035a5a51abc2a8f4dd3e3ed7d35b62c3f59698b62f15406e202f35acc9a6567分别记录；两者不强行等同，也不把旧47e配对执行冒称本批新执行。

新增10例/4方法，先实际复现七个缺口，修复后九过一新夹具失败。该新夹具没有有效重连令牌，原守卫正确拒绝；改为真实入房、交牌和准备取得原私有手牌，保留失败源码和日志。随后全部Hub与身份边界等307例/256方法通过。唯一check时原1800份Conformance文件逐字保留；随后为闭合固定CI实测失败只校正其中一份SQL夹具的准备流程，其余1799份逐字相同。全部原方法、Theory行和原断言保留，九份完整对局源、143公共方法、110配对/十一牌组/424242及胜利回放断言不删改。

本批唯一check实际13379例/7534方法全部通过、零失败零跳过。原13369例/7530方法多重集合完整，只增10/4；旧check六失败按原结果保留，同六身份在本次新check通过，不回填历史状态。3337源/模式、1419Conformance和23原生Debug载荷在该check全过程稳定。该check未提供数据库连接，不能声称执行SQL分支；之后的SQL夹具调整不回填这个check输入和结果。最终输入有独立326例/263方法真实SQL focus，固定提交full仍需执行全部143方法与110配对，预计13528/7675及原57项SQL，预期数不充当执行结果。无第二check。

真实PostgreSQL原生连接库网络门禁保留原15越权拒绝、零泄露、socket丢失、认证恢复、错误令牌拒绝的完整原代码和断言，只追加一个独立双端房间。新房第一人tick1、双方tick2，未主动RequestSnapshot或重试动作；原网络恢复案例中的显式请求快照仍保留。两个新网络局共3服务端入座输入/3事件。独立只读原七表、3权威历史/4快照/4提示、每个原前缀与完整回放通过；原331审计/69原生七表不变，PG正常停止。

实际CI导出9633客户端A/B的373份DLL/PCK、严格签名和默认Main无窗口启动已核对，起止锁屏。但完整配对验收在生产连接库前缀阶段就被本缺口中止，尚未启动该完整对局的Godot双端，不能把启动或上述连接库门禁称为完整原生对局。后续固定候选默认Main配对、冷重启、正常8:0及完整历史回放继续提前补验；可见控件、可见双窗及Windows实机分别OPEN，不反复请求解锁。

父be0e CI39639479119实际11项success，九原ZIP独立13497例/7662方法，原7a13453/7657全留，只增44/5；143完整方法、110配对/11牌组/424242、56SQL和网络15/0通过。它不覆盖新入座第57项或本批通知修复。9633 CI39665645745规则任务实际失败，原ZIP独立核实13518例/7671方法，13505过、13失败、零跳过；原143完整方法/151完整对局用例及110配对/11牌组/424242均通过，但不构成全CI成功。13例同属原身份篡改Theory，在准备阶段仅写玩家元数据便尝试恢复，未生成现在必需的原ROOM_SEAT日志。真实PostgreSQL以原Debug载荷完整复现这13失败后，只将该夹具的两次元数据写改为生产MatchSession两次EnsurePlayerAsync入座，加三条两日志/命令种类/空回放初态断言，原13行、全部原断言和拒绝守卫逐字保留。最终含全部Hub、入座及该SQL类的326例/263方法全过，其中19个SQL类用例和13篡改分支均实连数据库到达原拒绝和registry断言；原331审计/69原生七表不变，无新持久局，PG正常停止。旧CI13失败、真实红测和唯一check原输入均保留，不重新标绿、不追加第二check；新固定full验证最终输入。其他9633任务按实际终态另核。所有历史失败与正常胜利断言保留。

本次新来源观察核对当前CN规则目录14项、全部16保留文档版本，均未换版，12次HTTP304，相同PDF不落重复副本。冰霜要塞34765和暮色玫瑰实验室34762完整行及QA与CN16和最近登记版本一致；190.6与191.5只作为下一有限族的只读来源准备，#84尚未改实现。其他全站观察继续引用其原取得时间，不假称本批又完成全站语义审查。

官网FAQ链接的Riftbound官方K/DA视频及可见说明页已实际核对并保留原截图/哈希。可见发布日期10月22日不推定UTC或游戏生效日期；近景小字仍不足以可靠确认五张精确印次，阿卡丽底部候选字样不视为已确认目录身份。五个既有精确印次/适用性门禁全部原样OPEN，不增加1740分母、不把五者等同八个英文缺口、不改变139中文新闻范围或运行目录。数值AX控件载入时变更曾导致一次非官方页面跳转，捕获守卫在保存图片前失败；保留原尝试，后续加官方标题/视频ID/暂停/时间验证。未下载视频或远程图片副本，无权限或安全设置变更，临时标签已关闭。

旧162审查、77上下文、250门禁和七源增量对象均完整原样，无实现绑定刷新。新增10限定行为至17124剩余义务，163审查/78上下文/250门禁/七增量，semanticCoverageCertified=false。旧7a A/B及两平台安装包在最新9633双端可用后按原哈希清理，834文件/链接、945969414逻辑字节，不推定物理回收；只留最新可用双端与每平台一包。be0e885份已验字节的重复SQL解压另清理，九原ZIP保留；本档案不复制应用、安装器、SDK或共享运行依赖。新固定full、当前产品及全部来源/卡牌/规则缺口继续OPEN。
'''
(root/doc).write_text(document)
status=root/'docs/PROJECT_STATUS.md';oldstatus=status.read_text();assert oldstatus.startswith('# 当前项目状态\n\n')
prefix='''2026-10-22 本批：[入房后对手私有视图更新](ROOM_SEAT_PEER_NOTIFICATIONS_AUDIT_2026-10-22.md)。固定9633原入座/回放已正确，但第二人入房推进tick后未推送前一玩家的新提示，首次交牌PROMPT_EXPIRED；原3输入/2事件、8网络视图及独立全原回放反例保留，#87独立追踪。API成功入房后按各对手私有player组刷新视图，不放宽校验或靠客户端刷新重试。

新增10/4，全部Hub等focus307/256、唯一check13379/7534全过零跳过，原13369/7530全留；3337/1419/23输入稳定，旧六失败不回填。check时原1800Conformance文件逐字相同；后续只校准一份SQL夹具的准备流程，其余1799份逐字相同，所有原方法/Theory行/断言及九份原完整源码、143完整方法/110配对/11牌组/424242保留。新固定full预期13528/7675、57SQL，尚按实际执行另核。原生连接库实际原15越权拒绝零泄露及原重连守卫全留，新双端无需刷新或重试即双方tick2。独立两个网络局3输入3事件、3历史4快照4提示和全原回放通过，原331审计69原生七表不变。

be0e整次11成功及13497/7662、56SQL独立核实。9633规则任务实际13518/7671、13505过13个SQL夹具准备失败；其143完整方法与110配对均过，不据此提升整次CI。真实数据库原13红测后只改夹具入座准备并添加断言，最终SQL/Hub/入座focus326/263全过，19个SQL类用例含全部13原篡改分支实际执行；唯一check在这次校准前且无数据库连接，不回填、不重跑，最终输入等待新full。9633客户端默认Main启动/373载荷通过，但完整对局在连接库前缀中止，未冒称Godot完整配对；新固定原生正常得分/回放、可见双端及Windows仍OPEN。当前16文档和两战场行未换版，#84只读准备；K/DA官方视频补充不提升五印次门禁。原162审查77上下文250门禁七增量全部原样，原17114义务全留加10至17124，163审查78上下文，语义false。仅最新可用双端及每平台一包，无新SDK/工作树/数据库。Goal active / NOT READY。

以下原批按原范围与当时终态保留。

'''
status.write_text('# 当前项目状态\n\n'+prefix+oldstatus[len('# 当前项目状态\n\n'):])
print('Published coherent API peer-notification evidence:163reviews78contexts250gates7deltas; expected17124; all162/77/250/7 old objects retained; fixed full/products OPEN.')
