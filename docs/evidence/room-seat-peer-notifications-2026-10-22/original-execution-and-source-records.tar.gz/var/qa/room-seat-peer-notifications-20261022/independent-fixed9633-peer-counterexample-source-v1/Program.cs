using System.IO.Compression;
using System.Reflection;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

if(args.Length!=2||File.Exists(args[1]))throw new Exception("Original fixed9633 work and unused readback required.");
var work=Path.GetFullPath(args[0]);var json=new JsonSerializerOptions(JsonSerializerDefaults.Web){WriteIndented=true};
using var terminal=JsonDocument.Parse(File.ReadAllText(Path.Combine(work,"live-current-ci-main-owner-terminal-v2.json")));
Check(terminal.RootElement.GetProperty("fixedCommit").GetString()=="96334b9d9ef6fc15faf3d2eb265552482664cbd3","Original fixed candidate only.");
var room=terminal.RootElement.GetProperty("originalPartialPrefixRoom").GetString()!;
var builder=new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
Check(builder.Host=="127.0.0.1"&&builder.Port==55486&&builder.Database=="riftbound_here_native"&&builder.Username=="codex_riftbound_audit","Only own original native database.");builder.Options="-c default_transaction_read_only=on";
await using var source=NpgsqlDataSource.Create(builder.ConnectionString);
var frame=await new PostgresMatchRecoveryStore(source).LoadAsync(room,default)??throw new Exception("Original SQL frame required.");
using var original=Read(Path.Combine(work,"actual-safe-native-main-v2/original-failed-prefix-without-reset.json.gz"));
Check(Same(original.RootElement,JsonSerializer.SerializeToElement(frame,json)),"Every original final frame field/null/omission equals current independent read.");
Check(frame.IsConsistent&&frame.ValidationErrors.Count==0&&frame.Commands.Count==3&&frame.Events.Count==2&&frame.OpeningSeed!=0&&frame.ReplayInitialState is{Status:"EMPTY",Seats.Count:0,Tick:0},"Original EMPTY opening, private seed, two registrations and rejected ordinary input retained.");
var a=frame.Commands[0].PlayerId;var b=frame.Commands[1].PlayerId;
for(var i=0;i<2;i++){
 var c=frame.Commands[i];var slot=i==0?"P1":"P2";var raw=c.RawCommand!.Value;
 Check(c.Accepted&&c.CommandType=="ROOM_SEAT"&&c.ClientIntentId=="room-seat:"+slot&&raw.EnumerateObject().Count()==3&&raw.GetProperty("playerId").GetString()==c.PlayerId&&raw.GetProperty("seat").GetString()==slot&&raw.GetProperty("cmdType").GetString()=="ROOM_SEAT"&&c.StartedTick==i&&c.CompletedTick==i+1&&c.StartedEventSequence==i&&c.CompletedEventSequence==i+1,"Literal original two server registrations, actors, schemas and one-step spans.");
}
var rejected=frame.Commands[2];var rejectedRaw=rejected.RawCommand!.Value;
Check(!rejected.Accepted&&rejected.CommandType=="SUBMIT_DECK"&&rejected.PlayerId==a&&rejected.StartedTick==2&&rejected.CompletedTick==2&&rejected.StartedEventSequence==2&&rejected.CompletedEventSequence==2&&rejectedRaw.GetProperty("snapshotTick").GetInt64()==1,"Original ordinary first action used the last delivered first-player tick1 and was rejected without state/event movement at actual tick2.");
var wire=new List<JsonElement>();
using(var zip=new GZipStream(File.OpenRead(Path.Combine(work,"actual-safe-native-prefix-v2/original-private-native-wire-snapshots-prompts.ndjson.gz")),CompressionMode.Decompress))
using(var reader=new StreamReader(zip))while(await reader.ReadLineAsync()is{}line){using var d=JsonDocument.Parse(line);wire.Add(d.RootElement.Clone());}
Check(wire.Count==8,"All eight original private wire messages retained.");
foreach(var actor in new[]{a,b})foreach(var kind in new[]{"Snapshot","Prompt"}){
 var rows=wire.Where(x=>x.GetProperty("actor").GetString()==actor&&x.GetProperty("kind").GetString()==kind).ToArray();Check(rows.Length==2,"Both original automatic view and explicit initial snapshot request retained.");
 foreach(var row in rows){var p=row.GetProperty("payload");Check(p.GetProperty(kind=="Snapshot"?"tick":"snapshotTick").GetInt64()==(actor==a?1:2),"Every original A view remains tick1 while every B view is tick2; no peer update was delivered.");
  if(kind=="Prompt"&&actor==a)Check(p.GetProperty("promptId").GetString()==rejectedRaw.GetProperty("promptId").GetString(),"Rejected original raw intent uses exactly its actually delivered private prompt, without fabricated input.");
  if(kind=="Snapshot")Check(p.GetProperty("players").EnumerateObject().Count()==(actor==a?1:2),"Original first-player view has one seat; the second-player view has both seats.");
 }
}
var states=new Dictionary<(long,long),MatchState>();var counts=new Dictionary<string,int>();
await using(var connection=await source.OpenConnectionAsync()){
 Check((string)(await new NpgsqlCommand("show transaction_read_only",connection).ExecuteScalarAsync())! =="on","Independent actual connection is read-only.");
 await using(var q=Query(connection,"select last_event_sequence,payload::text from state_snapshots where match_id=@room order by state_tick,last_event_sequence"))
 await using(var rows=await q.ExecuteReaderAsync())while(await rows.ReadAsync()){
  var text=rows.GetString(1);var state=JsonSerializer.Deserialize<MatchState>(text,json)!;Check(JsonNode.DeepEquals(JsonNode.Parse(text),JsonSerializer.SerializeToNode(state,json))&&state.RuleInputs==RuleInputIdentity.Current&&states.TryAdd((state.Tick,rows.GetInt64(0)),state),"All original authority fields/nulls/omissions and unique current inputs retained.");
 }
 Check(states.Count==2&&states[(1,1)].Seats.Count==1&&!states[(1,1)].Seats.ContainsKey(b)&&states[(2,2)].Seats.Count==2,"Exact two original authority histories; rejected input reuses tick/sequence2 under existing key.");
 foreach(var table in new[]{"snapshots","action_prompts"}){
  var keys=new HashSet<(string,long,long)>();await using var q=Query(connection,$"select player_id,last_event_sequence,payload::text from {table} where match_id=@room order by id");await using var rows=await q.ExecuteReaderAsync();
  while(await rows.ReadAsync()){
   var actor=rows.GetString(0);var text=rows.GetString(2);using var document=JsonDocument.Parse(text);var tick=document.RootElement.GetProperty(table=="snapshots"?"tick":"snapshotTick").GetInt64();var sequence=rows.GetInt64(1);Check(states.TryGetValue((tick,sequence),out var state)&&keys.Add((actor,tick,sequence))&&state.Seats.ContainsKey(actor),"Actual private viewer existed at that original state.");
   var typed=table=="snapshots"?JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<SnapshotDto>(text,json),json):JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<ActionPromptDto>(text,json),json);
   var projected=table=="snapshots"?JsonSerializer.SerializeToNode(ResolutionResult.BuildSnapshots(state!)[actor],json):JsonSerializer.SerializeToNode(ResolutionResult.BuildPrompts(state!)[actor],json);
   Check(JsonNode.DeepEquals(JsonNode.Parse(text),typed)&&JsonNode.DeepEquals(JsonNode.Parse(text),projected),"Complete private fields/nulls/omissions and projection exact for every retained original SQL view.");
  }
  Check(keys.SetEquals(new[]{(a,1L,1L),(a,2L,2L),(b,2L,2L)}),"SQL correctly retains current A tick2 even though original wire never delivered it; no invented B tick1.");counts[table]=keys.Count;
 }
}
var replay=new MatchSession(frame.ReplayInitialState!,new CoreRuleEngine(),NoopMatchJournal.Instance);
var method=typeof(MatchActionLogReplayer).GetMethod("ReplayCommandAsync",BindingFlags.Static|BindingFlags.NonPublic)!;var replayed=0;
foreach(var command in frame.Commands){
 var result=await(ValueTask<ResolutionResult>)method.Invoke(null,new object[]{replay,command,CancellationToken.None})!;
 Check(result.Accepted==command.Accepted&&result.ErrorMessage==command.ErrorMessage&&Same(JsonSerializer.SerializeToElement(result.State,json),JsonSerializer.SerializeToElement(states[(command.CompletedTick,command.CompletedEventSequence)],json)),"Every original server/client input replays to its exact accepted/error behavior and complete historical authority.");
 var events=frame.Events.Where(e=>e.Sequence>command.StartedEventSequence&&e.Sequence<=command.CompletedEventSequence).Select(e=>e.Event).ToArray();Check(Same(JsonSerializer.SerializeToElement(result.Events,json),JsonSerializer.SerializeToElement(events,json)),"Every original event payload exact, including the rejected input's empty span.");
 if(!command.Accepted)Check(result.ErrorCode==ErrorCodes.PromptExpired,"Independent original stale prompt validation remains enforced.");replayed++;
}
Check((await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame,new CoreRuleEngine(),default)).Count==0,"Complete original strict recovery/replay passes; peer notification is the separate confirmed gap.");
var output=new{status="CONFIRMED_FIXED9633_PEER_WIRE_TICK1_VS_DURABLE_TICK2_WITH_ALL_ORIGINAL_INPUT_HISTORY_AND_REPLAY_PASS",room,fixedCommit="96334b9d9ef6fc15faf3d2eb265552482664cbd3",commands=3,acceptedServerSeats=2,rejectedOriginalClientIntents=1,events=2,authorityHistories=states.Count,privateHistories=counts,everyOriginalCommandReplayed=replayed,allEightOriginalWireMessagesRetained=true,firstPlayerDeliveredTick=1,durableFirstPlayerTick=2,secondPlayerDeliveredTick=2,originalPrivateSeedAndEmptyOriginUnmodified=true,actualRuleInputs=RuleInputIdentity.Current,actualReadOnlyConnection=true,noWriterRerunOrOldMatchMigration=true,fullProductVisibleAndWindowsAcceptance=false};await File.WriteAllTextAsync(args[1],JsonSerializer.Serialize(output,json));Console.WriteLine(output.status);
NpgsqlCommand Query(NpgsqlConnection c,string sql){var q=new NpgsqlCommand(sql,c);q.Parameters.AddWithValue("room",room);return q;}
bool Same(JsonElement a,JsonElement b)=>JsonNode.DeepEquals(JsonNode.Parse(a.GetRawText()),JsonNode.Parse(b.GetRawText()));
static JsonDocument Read(string path){using var zip=new GZipStream(File.OpenRead(path),CompressionMode.Decompress);return JsonDocument.Parse(zip);}
static void Check(bool value,string reason){if(!value)throw new Exception(reason);}
