from pathlib import Path
import ast,collections,datetime,fcntl,gzip,hashlib,json,os,plistlib,resource,socket,subprocess,sys,xml.etree.ElementTree as ET
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
phase=sys.argv[1];assert phase in {'red','green'}
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on');now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text())
source=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py';nodes=[n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),globals())
start=load(w/'only-check-start-inputs-v1.json');source_inputs={p:sha(root/p) for p in start['sourceInputHashes']};changed={p for p,h in source_inputs.items() if h!=start['sourceInputHashes'][p]};fixture='tests/Riftbound.ConformanceTests/PostgresMatchRecoveryStoreSmokeTests.cs'
assert changed==(set() if phase=='red' else {fixture}),changed
if phase=='red':assert all(sha(root/p)==h for p,h in start['actualConformanceRuntimeFileHashes'].items())
previous=load(w/'independent-current-peer-network-owner-terminal-v1.json');assert previous['ownPostgresSmartStopped'] and len(previous['actualAuditRoomsAtStop'])==331 and len(previous['actualNativeRoomsAtStop'])==69
folder=w/('ci13-original-sql-fixture-'+phase+'-v1');folder.mkdir(exist_ok=False)
proof={'status':'STARTING_REAL_SQL_ORIGINAL_CI13_'+phase.upper(),'phase':phase,'startedAtUtc':now(),'sourceBaseCommit':start['baseCommit'],'sourceInputs':source_inputs,'changedAfterSoleCheck':sorted(changed),'originalSoleCheckNotRerunOrRelabeled':True,'actualDatabaseConnectionSuppliedToEveryTestProcess':True,'lockAtStart':observe_lock()}
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
started=False;power=None;audit=native=before_audit=before_native=None
try:
 assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid
 sock.mkdir(exist_ok=True);subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(folder/'postgres.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 audit=rooms('riftbound_acceptance');native=rooms('riftbound_here_native');assert audit==previous['actualAuditRoomsAtStop'] and native==previous['actualNativeRoomsAtStop']
 before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',native);proof.update(originalAuditSevenTables=before_audit,originalNativeSevenTables=before_native)
 env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit',DOTNET_DbgEnableMiniDump='0')
 dotnet='/Users/dinghaolin/.dotnet/dotnet'
 if phase=='red':command=[dotnet,'test','tests/Riftbound.ConformanceTests','--no-build','--no-restore','-v:q','--filter','FullyQualifiedName~PostgresRecoveryRefusesDifferentOrMissingInputsAcrossMetadataLogsAndViews','--logger','trx;LogFileName=results.trx','--results-directory',str(folder)]
 else:command=['python3','scripts/test-rules.py','focus','--match','PostgresMatchRecoveryStoreSmokeTests','--match','RoomSeatJournalTests','--match','GameHubJoinTests','--output',str(folder/'focus-run')]
 proof['actualCommand']=command
 with (folder/'console.log').open('xb') as log:code=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1800).returncode
 proof['exitCode']=code
 trx=folder/'results.trx' if phase=='red' else folder/'focus-run/focus/results.trx';ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};tree=ET.parse(trx);rows=tree.findall('.//t:UnitTestResult',ns);cases=[r.get('testName') for r in rows];proof.update(actualCases=len(rows),outcomes=dict(collections.Counter(r.get('outcome') for r in rows)),trxPath=str(trx.relative_to(root)),trxSha256=sha(trx))
 original=load(w/'ci9633-failed-conformance-original-verification-v1.json')['failures'];expected={r['case'] for r in original};actual13=[r for r in rows if 'PostgresRecoveryRefusesDifferentOrMissingInputsAcrossMetadataLogsAndViews(' in r.get('testName')];assert len(actual13)==13 and {r.get('testName') for r in actual13}==expected
 if phase=='red':
  assert code==1 and len(rows)==13 and all(r.get('outcome')=='Failed' for r in rows)
  assert all('stored match requires authoritative state with recorded rule input identity' in '\n'.join(r.itertext()) for r in rows)
 else:assert code==0 and all(r.get('outcome')=='Passed' for r in rows) and len(rows)>=325
 proof.update(status='PASS_REAL_SQL_ORIGINAL13_REPRODUCED' if phase=='red' else 'PASS_REAL_SQL_ALL13_ORIGINAL_TAMPER_BRANCHES_AND_ADJACENT_ROOM_HUB_TESTS',all13OriginalCiIdentitiesExact=True,all13HaveRealSqlConnection=True,noGuardOrAssertionRelaxed=True)
except BaseException as e:
 proof.update(status='FAILED_FOCUS_OR_INDEPENDENT_CHECK_ORIGINAL_HISTORY_RETAINED',errorType=type(e).__name__,error=str(e));raise
finally:
 if started:
  if before_audit is not None:
   proof['allOriginal331AuditSevenTablesExact']=digests('riftbound_acceptance',audit)==before_audit;proof['allOriginal69NativeSevenTablesExact']=digests('riftbound_here_native',native)==before_native;proof['allOriginalRoomsExactNoNewPersistentRoom']=rooms('riftbound_acceptance')==audit and rooms('riftbound_here_native')==native
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None and power.poll() is None:power.terminate();power.wait(timeout=10)
 proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),all3337SourceInputsStableDuringThisFocus=all(sha(root/p)==h for p,h in source_inputs.items()))
 with (w/('ci13-original-sql-fixture-'+phase+'-owner-terminal-v1.json')).open('x') as f:json.dump(proof,f,indent=2)
 fcntl.flock(guard,fcntl.LOCK_UN)
assert all(proof[k] for k in ['allOriginal331AuditSevenTablesExact','allOriginal69NativeSevenTablesExact','allOriginalRoomsExactNoNewPersistentRoom','ownPostgresSmartStopped','all3337SourceInputsStableDuringThisFocus'])
print(proof['status'],proof['actualCases'],proof['outcomes'],flush=True)
