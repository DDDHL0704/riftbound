from pathlib import Path
import datetime,gzip,hashlib,io,json,shutil,subprocess,tarfile
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
base='96334b9d9ef6fc15faf3d2eb265552482664cbd3';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==base
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text())
old=load(root/'var/qa/fixed9633-early-native-20261022/fixed9633-api-gameplay-closure-frozen-inputs-v1.json')
api_sources={p:sha(root/p) for p in old['allDeclaredApiGameplaySourceInputsExactFixedCommit']}
changed=[p for p,h in api_sources.items() if h!=old['allDeclaredApiGameplaySourceInputsExactFixedCommit'][p]];assert changed==['src/Riftbound.Api/Hubs/GameHub.cs'],changed
inputs={p:sha(root/p) for p in ['src/Riftbound.Api/Hubs/GameHub.cs','tests/Riftbound.NativeNetworkSmoke/Program.cs','tests/Riftbound.ConformanceTests/GameHubRoomSeatNotificationTests.cs']}
api=w/'peer-notification-wip-api-runtime-v1';assert not api.exists()
with (w/'build-peer-notification-wip-api-v1.log').open('xb') as log:subprocess.run(['/Users/dinghaolin/.dotnet/dotnet','publish','src/Riftbound.Api/Riftbound.Api.csproj','--configuration','Release','--no-restore','--nologo','--output',str(api)],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
assert all(sha(root/p)==h for p,h in api_sources.items()) and all(sha(root/p)==h for p,h in inputs.items())
files=lambda p:{str(f.relative_to(p)):sha(f) for f in p.rglob('*') if f.is_file()}
network=w/'peer-notification-wip-network-net8-runtime-v1';assert not network.exists();subprocess.run(['/bin/cp','-cR',str(root/'tests/Riftbound.NativeNetworkSmoke/bin/Release/net8.0'),str(network)],check=True)
assert (network/'Riftbound.NativeNetworkSmoke.dll').exists()
network_paths=['tests/Riftbound.NativeNetworkSmoke/Program.cs','tests/Riftbound.NativeNetworkSmoke/Riftbound.NativeNetworkSmoke.csproj','clients/godot/scripts/RiftboundGameHubClient.cs','clients/godot/scripts/SnapshotCardRef.cs','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json']
tracked=subprocess.check_output(['git','ls-tree','-r','--name-only',base,'src/Riftbound.Contracts'],cwd=root,text=True).splitlines();network_paths+=tracked
network_sources={p:sha(root/p) for p in network_paths if (root/p).is_file()}
original=subprocess.check_output(['git','show',base+':tests/Riftbound.NativeNetworkSmoke/Program.cs'],cwd=root,text=True)
current=(root/'tests/Riftbound.NativeNetworkSmoke/Program.cs').read_text();call='await VerifyRoomSeatPeerPushAsync(url, handle, key);\n'
assert current.count(call)==1;retained=current.replace(call,'');start=retained.index('static async Task VerifyRoomSeatPeerPushAsync(');end=retained.index('static async Task VerifyRoomIdentityBoundaryAsync(',start);retained=retained[:start]+retained[end:]
assert retained==original,'All original native projection,15 rejection, canonical identity, socket-loss, authenticated restore and invalid-token guards must remain exact.'
original_tests=subprocess.check_output(['git','ls-tree','-r','--name-only',base,'tests/Riftbound.ConformanceTests'],cwd=root,text=True).splitlines()
tests_retained={}
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive',base,'tests/Riftbound.ConformanceTests'],cwd=root)),mode='r:') as tar:
 for member in tar.getmembers():
  if member.isfile():
   raw=tar.extractfile(member).read();assert (root/member.name).read_bytes()==raw,member.name
   tests_retained[member.name]=hashlib.sha256(raw).hexdigest()
for p in inputs:
 original_path=w/('wip-source-'+Path(p).name+'.gz');original_path.write_bytes(gzip.compress((root/p).read_bytes(),mtime=0))
pub={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceBaseCommit':base,'status':'DECLARED_UNCOMMITTED_API_PEER_NOTIFICATION_WIP_NOT_FIXED_COMMIT_OR_CI_API','onlyChangedApiClosureSource':changed,'apiRuntimeRoot':str(api),'apiRuntimeFiles':files(api),'all251CurrentApiGameplayAndBuildSourceHashes':api_sources,'gameplayEngineCatalogContractsPersistenceAndOfficialInputsExactBaseCommit':True,'declaredThreeChangedOrNewSourceHashes':inputs,'networkRuntimeRoot':str(network),'networkRuntimeFiles':files(network),'networkSourceHashes':network_sources,'allOriginalNativeNetworkGuardsByteExactAfterRemovingOnlyNewInvocationAndNewMethod':True,'allOriginalConformanceTrackedFilesExactBaseCommit':tests_retained,'newConformanceSourceOnly':'tests/Riftbound.ConformanceTests/GameHubRoomSeatNotificationTests.cs','currentFixedCiAndVisibleAndWindowsAcceptance':'OPEN'}
with (w/'peer-notification-wip-api-and-network-frozen-inputs-v1.json').open('x') as f:json.dump(pub,f,indent=2)
print('Frozen WIP API',len(pub['apiRuntimeFiles']),'files, net8 network',len(pub['networkRuntimeFiles']),'files;',len(tests_retained),'old Conformance files byte exact; all original network guards retained.')
