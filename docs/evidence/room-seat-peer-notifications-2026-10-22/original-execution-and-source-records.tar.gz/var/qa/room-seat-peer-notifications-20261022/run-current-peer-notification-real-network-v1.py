from pathlib import Path
import ast,datetime,fcntl,gzip,hashlib,json,os,plistlib,resource,shutil,socket,subprocess,time,urllib.request
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;old=root/'var/qa/fixed9633-early-native-20261022'
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
source=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py';nodes=[n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),globals())
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
pub=load(w/'peer-notification-wip-api-and-network-frozen-inputs-v1.json');previous=load(w/'independent-original-fixed9633-peer-counterexample-owner-terminal-v1.json');assert previous['ownPostgresSmartStopped'] and previous['allOriginal331AuditSevenTablesExact'] and previous['allOriginal67NativeSevenTablesExact']
api_runtime=Path(pub['apiRuntimeRoot']);network=Path(pub['networkRuntimeRoot']);reader=old/'fixed9633-native-history-reader-runtime-v2/Fixed9633NativeHistoryReaderV2.dll'
metadata=['--depsfile',str(api_runtime/'Riftbound.Api.deps.json'),'--runtimeconfig',str(api_runtime/'Riftbound.Api.runtimeconfig.json')]
measurement=json.loads(subprocess.check_output(['/Users/dinghaolin/.dotnet/dotnet','exec',*metadata,str(reader),'--loaded-inputs'],cwd=api_runtime,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0')))
assert Path(measurement['baseDirectory'])==api_runtime and len(measurement['assemblies'])==4
for a in measurement['assemblies']:assert Path(a['path'])==api_runtime/(a['name']+'.dll') and a['sha256']==pub['apiRuntimeFiles'][a['name']+'.dll']
frame_runtime=w/'peer-notification-wip-read-only-frame-runtime-v1';assert not frame_runtime.exists();subprocess.run(['/bin/cp','-cR',str(api_runtime),str(frame_runtime)],check=True);shutil.copy2(old/'fixed9633-native-helpers-runtime-v1/FixedNativeFrameExport.dll',frame_runtime/'FixedNativeFrameExport.dll')
frozen_frames={str(p.relative_to(frame_runtime)):sha(p) for p in frame_runtime.rglob('*') if p.is_file()}
def frozen():
 assert all(sha(api_runtime/p)==h for p,h in pub['apiRuntimeFiles'].items()) and all(sha(network/p)==h for p,h in pub['networkRuntimeFiles'].items())
 assert all(sha(root/p)==h for p,h in pub['all251CurrentApiGameplayAndBuildSourceHashes'].items()) and all(sha(root/p)==h for p,h in pub['networkSourceHashes'].items())
 assert all(sha(frame_runtime/p)==h for p,h in frozen_frames.items())
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof={'status':'RUNNING_CURRENT_DECLARED_WIP_REAL_POSTGRES_NATIVE_NETWORK_ORIGINAL15_AND_NEW_PEER_PUSH','startedAtUtc':now(),'sourceBaseCommit':pub['sourceBaseCommit'],'actualLoadedFourAssemblies':measurement,'notFixedCommitOrCiAcceptance':True,'lockAtStart':observe_lock(),'visibleOrPhysicalWindows':False}
started=False;api=power=None;audit=native=before_audit=before_native=None
try:
 frozen();assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid
 sock.mkdir(exist_ok=True);subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'current-peer-network-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 audit=rooms('riftbound_acceptance');native=rooms('riftbound_here_native');assert audit==previous['actualAuditRoomsAtStop'] and len(audit)==331 and native==previous['actualNativeRoomsAtStop'] and len(native)==67
 before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',native)
 env=dict(os.environ,ASPNETCORE_ENVIRONMENT='Production',ASPNETCORE_URLS='http://127.0.0.1:15847',ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit',DOTNET_DbgEnableMiniDump='0');env.pop('DOTNET_STARTUP_HOOKS',None)
 with (w/'current-peer-network-api-v1.log').open('xb') as log:api=subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet',str(api_runtime/'Riftbound.Api.dll')],cwd=api_runtime,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 until=time.monotonic()+25
 while True:
  assert api.poll() is None and time.monotonic()<until
  try:
   with urllib.request.urlopen('http://127.0.0.1:15847/health',timeout=.5) as response:health=json.load(response)
   assert health['persistenceMode']=='postgres' and health['environment']=='Production';break
  except OSError:time.sleep(.1)
 assert set(subprocess.check_output(['/usr/sbin/lsof','-tiTCP:15847','-sTCP:LISTEN'],text=True).splitlines())=={str(api.pid)};proof.update(ownedApiPid=api.pid,actualHealth=health)
 print('CURRENT_WIP_REAL_POSTGRES_API_READY_ORIGINAL_AND_NEW_NETWORK_GATE',flush=True)
 log_path=w/'current-peer-network-original15-and-peer-push-v1.log'
 with log_path.open('xb') as log:code=subprocess.run(['/Users/dinghaolin/.dotnet/dotnet',str(network/'Riftbound.NativeNetworkSmoke.dll')],cwd=network,env=dict(os.environ,RIFTBOUND_SERVER_URL='http://127.0.0.1:15847',DOTNET_DbgEnableMiniDump='0'),stdout=log,stderr=subprocess.STDOUT,timeout=100).returncode
 proof['networkExitCode']=code;assert code==0
 text=log_path.read_text();identity=json.loads(next(line.removeprefix('NATIVE_ROOM_IDENTITY_EVIDENCE ') for line in text.splitlines() if line.startswith('NATIVE_ROOM_IDENTITY_EVIDENCE ')));peer=json.loads(next(line.removeprefix('NATIVE_ROOM_SEAT_PEER_EVIDENCE ') for line in text.splitlines() if line.startswith('NATIVE_ROOM_SEAT_PEER_EVIDENCE ')))
 assert identity['rejectedActions']==15 and identity['leakedPrivateMessages']==0 and identity['validReconnectTokenWasSupplied']
 assert peer['firstPlayerOriginalTick']==1 and peer['firstPlayerRefreshedTick']==peer['secondPlayerTick']==2 and peer['privateViewers']==2 and peer['explicitSnapshotRequests']==peer['commandRetries']==peer['wrongViewerMessages']==0
 assert 'Native network recovery passed: socket loss, authenticated room restore, fresh snapshot, rejected-token guard.' in text
 added=set(rooms('riftbound_here_native'))-set(native);assert added=={identity['room'],peer['room']}
 frames=[]
 for room in sorted(added):
  expected=2 if room==peer['room'] else 1;target=w/('current-peer-network-'+('peer' if expected==2 else 'original')+'-actual-frame-v1.json.gz')
  args=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(frame_runtime/'Riftbound.Api.deps.json'),'--runtimeconfig',str(frame_runtime/'Riftbound.Api.runtimeconfig.json'),str(frame_runtime/'FixedNativeFrameExport.dll'),room,str(target)]
  result=json.loads(subprocess.check_output(args,cwd=frame_runtime,env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit;Options=-c default_transaction_read_only=on',DOTNET_DbgEnableMiniDump='0')))
  assert result['actualRuleInputs']==measurement['actualRuleInputs'];frame=json.loads(gzip.decompress(target.read_bytes()));assert frame['isConsistent'] and not frame['validationErrors'] and len(frame['commands'])==len(frame['events'])==expected and all(c['accepted'] and c['commandType']=='ROOM_SEAT' for c in frame['commands'])
  raw={table:json.loads(query('riftbound_here_native',f"select coalesce(json_agg(t order by row_to_json(t)::text),'[]'::json)::text from (select * from {table} where match_id='{room}')t")) for table in tables}
  raw_path=w/('current-peer-network-'+('peer' if expected==2 else 'original')+'-all-seven-table-rows-v1.json.gz');raw_path.write_bytes(gzip.compress(json.dumps({'room':room,'originalRows':raw},ensure_ascii=False,indent=2).encode(),mtime=0));frames.append({'room':room,'serverSeatCommands':expected,'originalFrameSha256':sha(target),'originalSevenTableRowsSha256':sha(raw_path),'sevenTableCounts':{t:len(v) for t,v in raw.items()}})
 proof.update(status='PASS_CURRENT_WIP_REAL_POSTGRES_ORIGINAL15_IDENTITY_NETWORK_RECOVERY_AND_TWO_PEER_PUSH_WITHOUT_REFRESH_OR_RETRY',originalIdentityEvidence=identity,newPeerEvidence=peer,newOriginalRooms=frames,actualNetworkLogSha256=sha(log_path),allOriginalNativeNetworkGuardsRetained=True)
except BaseException as e:
 proof.update(status='FAILED_CURRENT_WIP_REAL_NETWORK_ALL_ORIGINALS_AND_NEW_ROOMS_RETAINED',errorType=type(e).__name__,error=str(e));raise
finally:
 if api is not None and api.poll() is None:api.terminate();api.wait(timeout=25)
 proof['ownApiStopped']=api is None or api.poll() is not None
 if started:
  if before_audit is not None:
   proof['allOriginal331AuditSevenTablesExact']=digests('riftbound_acceptance',audit)==before_audit;proof['allOriginal67NativeSevenTablesExact']=digests('riftbound_here_native',native)==before_native
   proof['actualAuditRoomsAtStop']=rooms('riftbound_acceptance');proof['actualNativeRoomsAtStop']=rooms('riftbound_here_native')
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None and power.poll() is None:power.terminate();power.wait(timeout=10)
 frozen();proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),allFrozenApiNetworkAndFrameReaderInputsStable=True)
 with (w/'current-peer-notification-real-network-owner-terminal-v1.json').open('x') as f:json.dump(proof,f,indent=2)
 fcntl.flock(guard,fcntl.LOCK_UN)
print(proof['status'],flush=True)
