from pathlib import Path
import datetime, hashlib, json

root = Path('/Users/dinghaolin/MyProjects/riftbound')
w = Path(__file__).resolve().parent
old = root / 'var/qa/fixed7a-early-native-20261021'
fixed = '96334b9d9ef6fc15faf3d2eb265552482664cbd3'
source = old / 'fixed7a-native-history-reader-source-v2/Program.cs'
s = source.read_text()
changes = []

def replace(before, after):
    global s
    assert s.count(before) == 1, before[:160]
    s = s.replace(before, after)
    changes.append({'before': before, 'after': after})

replace('using System.IO.Compression;', 'using System.IO.Compression;\nusing System.Reflection;')
replace('Check(args.Length==2,', '''if(args.SequenceEqual(new[]{"--loaded-inputs"})){
 var assemblies=new[]{typeof(CoreRuleEngine).Assembly,typeof(GameCommand).Assembly,typeof(Riftbound.CardCatalog.OfficialCardCatalog).Assembly,typeof(PostgresMatchJournal).Assembly};
 Console.WriteLine(JsonSerializer.Serialize(new{baseDirectory=AppContext.BaseDirectory,actualRuleInputs=RuleInputIdentity.Current,hasRoomSeatReplay=typeof(MatchSession).GetMethod("ReplayRoomSeatAsync",BindingFlags.Instance|BindingFlags.NonPublic)is not null,hasAtomicSeatCommit=typeof(IMatchPlayerStore).GetMethod("CommitRoomSeatAsync")is not null,assemblies=assemblies.Select(a=>new{name=a.GetName().Name,path=a.Location,mvid=a.ManifestModule.ModuleVersionId,sha256=Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(a.Location))).ToLowerInvariant()})},new JsonSerializerOptions(JsonSerializerDefaults.Web)));return;
}
Check(args.Length==2,''')
replace('var n=entry.GetProperty("acceptedCommands").GetInt32();', 'var originalClientPrefix=entry.GetProperty("acceptedCommands").GetInt32();var n=originalClientPrefix+2;')
replace('frame.ReplayInitialState is{Tick:0,CardObjects.Count:0}', 'frame.ReplayInitialState is{Tick:0,Status:"EMPTY",Seats.Count:0,CardObjects.Count:0}')
replace('prefix.RootElement.GetArrayLength()==n&&', 'prefix.RootElement.GetArrayLength()==originalClientPrefix&&')
replace('for(var i=0;i<frame.Commands.Count;i++){\n if(i>=n&&i<n+3)continue;\n var row=i<n?prefix.RootElement[i]:continuation.RootElement[i-n-3];', '''var serverSeats=frame.Commands.Where(c=>c.CommandType=="ROOM_SEAT").ToArray();
Check(serverSeats.Length==2&&serverSeats.Select(c=>c.PlayerId).SequenceEqual(actors)&&frame.Commands[0]==serverSeats[0],"Both literal original server registrations are retained in temporal order; the first input creates the first player from EMPTY.");
for(var i=0;i<2;i++){
 var c=serverSeats[i];var slot=i==0?"P1":"P2";var raw=c.RawCommand!.Value;
 Check(c.Accepted&&c.ErrorMessage is null&&c.ClientIntentId=="room-seat:"+slot&&raw.EnumerateObject().Count()==3&&raw.GetProperty("cmdType").GetString()=="ROOM_SEAT"&&raw.GetProperty("playerId").GetString()==actors[i]&&raw.GetProperty("seat").GetString()==slot&&c.CompletedTick==c.StartedTick+1&&c.CompletedEventSequence==c.StartedEventSequence+1,"Independent literal server actor, reserved intent, exact raw schema, seat and original one-tick/one-event span.");
 var e=frame.Events.Single(e=>e.Sequence>c.StartedEventSequence&&e.Sequence<=c.CompletedEventSequence);var payload=JsonSerializer.SerializeToElement(e.Event.Payload,json);
 Check(e.Event.Kind=="PLAYER_SEATED"&&payload.EnumerateObject().Count()==2&&payload.GetProperty("playerId").GetString()==actors[i]&&payload.GetProperty("seat").GetString()==slot,"Independent literal two-field public registration event; credentials are absent.");
}
var originalClientIndex=0;
for(var i=0;i<frame.Commands.Count;i++){
 if(i>=n&&i<n+3)continue;
 if(frame.Commands[i].CommandType=="ROOM_SEAT")continue;
 var row=i<n?prefix.RootElement[originalClientIndex++]:continuation.RootElement[i-n-3];''')
replace('Check(frame.Commands.All(c=>c.PlayerId==c.PlayerId.Trim().ToLowerInvariant()),', 'Check(originalClientIndex==originalClientPrefix,"No original client input is omitted or replaced by an internal registration.");\nCheck(frame.Commands.All(c=>c.PlayerId==c.PlayerId.Trim().ToLowerInvariant()),')
replace('var expectedPrivate=latestPrivateAtEachTick.SelectMany(c=>actors.Select(p=>(c.CompletedTick,c.CompletedEventSequence,p))).ToHashSet();', 'var expectedPrivate=latestPrivateAtEachTick.SelectMany(c=>states[(c.CompletedTick,c.CompletedEventSequence)].Seats.Keys.Select(p=>(c.CompletedTick,c.CompletedEventSequence,p))).ToHashSet();')
replace('var other=actor==a?b:a;foreach(var id in state!.PlayerZones[other].Hand.Concat(state.PlayerZones[other].MainDeck))', 'foreach(var other in state!.Seats.Keys.Where(p=>p!=actor))foreach(var id in state.PlayerZones[other].Hand.Concat(state.PlayerZones[other].MainDeck))')
replace('Check(keys.SetEquals(expectedPrivate),"Both viewers retain the exact latest original event sequence at every tick, matching the independently checked existing private-row key; all authoritative same-tick histories remain separate.");', 'Check(keys.SetEquals(expectedPrivate),"Every viewer who actually existed at that original tick retains the exact latest original event sequence under the independently checked private-row key; all authority histories remain separate and later players have no fabricated earlier view.");')
replace('var keptCommand=frame.Commands[n];', '''var firstSeatState=states[(serverSeats[0].CompletedTick,serverSeats[0].CompletedEventSequence)];
Check(firstSeatState.Seats.Count==1&&firstSeatState.Seats.TryGetValue(a,out var firstSlot)&&firstSlot=="P1"&&!firstSeatState.PlayerZones.ContainsKey(b),"The original first-player-only history remains first-player-only, never synthesized from final seats.");
var keptCommand=frame.Commands[n];''')
replace('var raw=command.RawCommand!.Value;var intent=GameCommandJsonMapper.Map(raw);\n var replayedStep=intent switch {', '''var raw=command.RawCommand!.Value;
 ResolutionResult replayedStep;
 if(command.CommandType=="ROOM_SEAT"){
  var method=typeof(MatchSession).GetMethod("ReplayRoomSeatAsync",BindingFlags.Instance|BindingFlags.NonPublic)??throw new Exception("Original server input replay required.");
  replayedStep=await (ValueTask<ResolutionResult>)method.Invoke(replaySession,new object[]{command,CancellationToken.None})!;
 }else{
 var intent=GameCommandJsonMapper.Map(raw);
 replayedStep=intent switch {''')
replace('_=>await replaySession.SubmitAsync(command.PlayerId,command.ClientIntentId,intent,raw,default)};', '_=>await replaySession.SubmitAsync(command.PlayerId,command.ClientIntentId,intent,raw,default)};\n }')
replace('originalPrefix=n,gatewayContinuationCommands=17', 'originalPrefix=n,originalClientPrefix,serverSeatCommands=2,gatewayContinuationCommands=17')
s = s.replace('7a334e7c1cab701d9506b6cf94f3f3a86d316ef8', fixed).replace('fixed7a','fixed9633').replace('Fixed7a','Fixed9633').replace('FIXED7A','FIXED9633').replace('-v3','-v1')
reader=w/'fixed9633-native-history-reader-source-v1';reader.mkdir()
(reader/'Program.cs').write_text(s,encoding='utf-8')
project=(old/'fixed7a-native-history-reader-source-v2/probe.csproj').read_text().replace('Fixed7aNativeHistoryReaderV2','Fixed9633NativeHistoryReaderV1').replace(str(old/'fixed7a-api-gameplay-closure-runtime-v1'),str(w/'fixed9633-api-gameplay-closure-runtime-v1'))
(reader/'probe.csproj').write_text(project)
builder=(old/'build-frozen-fixed7a-native-helpers-v1.py').read_text().replace('7a334e7c1cab701d9506b6cf94f3f3a86d316ef8',fixed).replace('fixed7a','fixed9633').replace('Fixed7a','Fixed9633').replace('FIXED7A','FIXED9633')
start=builder.index("reader=w/");end=builder.index("with (w/'build-",start)
builder=builder[:start]+"reader=w/'fixed9633-native-history-reader-source-v1';assert (reader/'Program.cs').is_file() and (reader/'probe.csproj').is_file()\n"+builder[end:]
with (w/'build-frozen-fixed9633-native-helpers-v1.py').open('x') as f:f.write(builder)
with (w/'native-reader-original-assertion-calibration-v1.json').open('x') as f:
 json.dump({'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'originalSource':str(source),'originalSourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'currentSourceSha256':hashlib.sha256((reader/'Program.cs').read_bytes()).hexdigest(),'exactSequentialChanges':changes,'fixedPathAndCommitRebinding':'fixed7a -> fixed9633, original v3 outputs -> new v1','originalClientIntentsNativeThreeActionsNormalSeventeenScoreCommandsSeedAndOriginalWinReplayChecksRetained':True,'serverSeatCountIsAdditionalNotReplacement':2,'firstHistoricalSinglePlayerAndEmptyOriginChecked':True,'privateViewerMembershipMeasuredAtOriginalStateNotFinalRoster':True},f,ensure_ascii=False,indent=2)
print('Prepared fixed9633 original-history reader and finite room-seat calibration:',len(changes),'exact replacements.')
