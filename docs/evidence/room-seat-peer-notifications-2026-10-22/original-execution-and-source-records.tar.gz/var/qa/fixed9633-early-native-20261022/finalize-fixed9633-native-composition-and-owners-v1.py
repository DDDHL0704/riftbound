from pathlib import Path
import ast, datetime, hashlib, json, os, subprocess

root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
fixed='96334b9d9ef6fc15faf3d2eb265552482664cbd3'
pub=load(w/'fixed9633-native-helper-and-network-frozen-v1.json')
native=load(w/'native-app-inputs.json');reader=load(w/'fixed9633-native-history-reader-frozen-v1.json')
assert native['fixedCommit']==pub['fixedCommit']==fixed
assert load(w/'current-native-headless-boot-verification.json')['status']=='CURRENT_FIXED_DEFAULT_MAIN_HEADLESS_BOOT_PASS'
records=[]
for label,folder,key in [('api',pub['apiRuntimeRoot'],'runtimeFiles'),('helpers',pub['helperRuntimeRoot'],'helperRuntimeFiles'),('reader',reader['runtimeRoot'],None)]:
    r=Path(folder);expected=reader['runtimeFiles'] if key is None else pub[key]
    assert all(sha(r/p)==h for p,h in expected.items())
    assert all(not (r/p).is_symlink() for p in expected if p.endswith(('.deps.json','.runtimeconfig.json')))
    args=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(r/'Riftbound.Api.deps.json'),'--runtimeconfig',str(r/'Riftbound.Api.runtimeconfig.json'),str(Path(reader['runtimeRoot'])/'Fixed9633NativeHistoryReaderV1.dll'),'--loaded-inputs']
    actual=json.loads(subprocess.check_output(args,cwd=r,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0')))
    assert Path(actual['baseDirectory'])==r and actual['actualRuleInputs']==pub['actualRuleInputs']
    assert actual['hasRoomSeatReplay'] and actual['hasAtomicSeatCommit'] and len(actual['assemblies'])==4
    for a in actual['assemblies']:
        assert Path(a['path'])==r/(a['name']+'.dll') and a['sha256']==expected[a['name']+'.dll'] and a['mvid']
    assert all(sha(r/p)==h for p,h in expected.items())
    records.append({'runtime':label,'command':args,'actual':actual,'allFrozenRuntimeFilesBeforeAndAfterExact':True})
measurement=w/'fixed9633-actual-loaded-path-sha-mvid-and-input-identity-v1.json'
with measurement.open('x') as f:json.dump({'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fixedCommit':fixed,'status':'PASS','records':records},f,indent=2)
pub.update(status='CURRENT_FIXED9633_API_AND_ACTUAL_CI_NATIVE_FROZEN_NO_VISIBLE_OR_WINDOWS_CLAIM',baseCommit=fixed,fixedCiRun=39665645745,nativeApps=native['apps'],ciManagedAndPckPayloads=native['ciManagedAndPckPayloads'],nativeMain373PayloadsAreActualCiExports=True,physicalWindowsAndVisibleAcceptance='OPEN',actualCurrentApiIdentitySeparatelyMeasured=True,allApiHelpersReaderMetadataPhysicalAndLoadedFourAssemblyPathsShaMvidMeasured=True,actualLoaderMeasurement=str(measurement),actualLoaderMeasurementSha256=sha(measurement))
with (w/'frozen-fixed9633-native-composition-v1.json').open('x') as f:json.dump(pub,f,indent=2)

old=root/'var/qa/fixed7a-early-native-20261021'
s=(old/'run-fixed7a-ci-main-pair-v2.py').read_text().replace('fixed7a','fixed9633').replace('Fixed7a','Fixed9633').replace('FIXED7A','FIXED9633').replace('current7a','current9633').replace('39615500598','39665645745').replace('-v3','-v1')
before="previous=load(w/'live-current-ci-main-owner-terminal-v2.json')\nassert previous['error']=='Ordinary fresh prefix failed; its original room, seed and accepted history remain retained' and previous['ownPostgresSmartStopped'] and len(previous['actualAuditRoomsAtStop'])==300 and len(previous['actualNativeRoomsAtStop'])==63\nassert previous['allOriginal300AuditSevenTablesExactAtStop'] and previous['allOriginal62NativeSevenTablesExactAtStop']"
after="previous=load(root/'var/qa/late-seat-command-inputs-20261022/corrected-original-private-opening-real-sql-owner-terminal-v2.json')\nassert previous['ownPostgresSmartStopped'] and len(previous['actualAuditRoomsAtStop'])==331 and len(previous['actualNativeRoomsAtStop'])==66\nassert previous['allOriginal330AuditSevenTablesExactAtStop'] and previous['allOriginal66NativeSevenTablesExactAtStop']"
assert s.count(before)==1;s=s.replace(before,after)
s=s.replace('original300','original331').replace('allOriginal300','allOriginal331').replace('Audit63Native','Audit66Native').replace('original331Audit63','original331Audit66').replace('allOriginal63Native','allOriginal66Native').replace('audit63-native','audit66-native').replace('==300','==331').replace('==63','==66')
before="entry=load(prefix/'pending-original-native-prefix-receipt.json');room=entry['room'];n=entry['acceptedCommands'];a,b=entry['players'];proof.update(room=room,originalGatewayPrefixCommands=n);"
after="entry=load(prefix/'pending-original-native-prefix-receipt.json');room=entry['room'];client_n=entry['acceptedCommands'];n=client_n+2;a,b=entry['players'];proof.update(room=room,originalGatewayPrefixCommands=client_n,originalServerSeatCommands=2,originalJournalPrefixCommands=n);"
assert s.count(before)==1;s=s.replace(before,after)
before="initial=export('before-ci-native-cold-reconnect-original-frame-v1');assert len(initial['commands'])==n"
after=before+"\n registrations=[c for c in initial['commands'] if c['commandType']=='ROOM_SEAT'];assert len(registrations)==2 and [c['playerId'] for c in registrations]==[a,b] and all(c['accepted'] for c in registrations)\n assert initial['replayInitialState']['status']=='EMPTY' and not initial['replayInitialState']['seats'] and initial['openingSeed']!=0"
assert s.count(before)==1;s=s.replace(before,after)
ast.parse(s)
with (w/'run-fixed9633-ci-main-pair-v1.py').open('x') as f:f.write(s)
s=(old/'run-independent-fixed7a-native-history-v2.py').read_text().replace('fixed7a','fixed9633').replace('Fixed7a','Fixed9633').replace('FIXED7A','FIXED9633').replace('-v3','-v1').replace('reader-frozen-v2','reader-frozen-v1').replace('HistoryReaderV2','HistoryReaderV1')
assert "ready['originalGatewayPrefixCommands'] + 20" in s
s=s.replace("ready['originalGatewayPrefixCommands'] + 20","ready['originalGatewayPrefixCommands'] + 22")
ast.parse(s)
with (w/'run-independent-fixed9633-native-history-v1.py').open('x') as f:f.write(s)
print('Frozen fixed9633 composition; actual four-assembly loaded identity',pub['actualRuleInputs']['identitySha256'],'at all three runtime directories. Owners prepared with331audit/66native baseline, two additional server records, all original client actions.')
