from pathlib import Path
import ast,datetime,hashlib,json,os,shutil,subprocess
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prior=load(w/'live-current-ci-main-owner-terminal-v1.json')
assert prior['ownPostgresSmartStopped'] and prior['allOriginal331AuditSevenTablesExactAtStop'] and prior['allOriginal66NativeSevenTablesExactAtStop']
assert len(prior['actualAuditRoomsAtStop'])==331 and len(prior['actualNativeRoomsAtStop'])==66 and 'originalPartialPrefixRoom' not in prior
profiles=[]
for role in ['a','b']:
    src=root/'var/qa/fixed7a-early-native-20261021'/('session-'+role+'.json');dst=w/('session-'+role+'.json')
    o=load(src);assert all(isinstance(o[k],str) and o[k] for k in ['handle','playerKey','roomId','reconnectToken'])
    assert not dst.exists();shutil.copy2(src,dst);os.chmod(dst,0o600);assert sha(src)==sha(dst)
    profiles.append({'role':role,'originalPrivateProfile':str(src),'originalSha256':sha(src),'currentPrivateProfile':str(dst),'sourceProfileUnchanged':True,'authIdentityReusedOnlyNewJoinDoesNotMigrateOrReconnectOldMatch':True})
with (w/'original-owned-qa-profile-intake-v1.json').open('x') as f:json.dump({'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'profiles':profiles,'credentialsNotPrintedOrCommitted':True,'priorAttemptHadNoNewRoomAndAllOldSevenTablesExact':True},f,indent=2)
reader=load(w/'fixed9633-native-history-reader-frozen-v1.json');r=w/'fixed9633-native-history-reader-source-v2';r.mkdir()
s=(w/'fixed9633-native-history-reader-source-v1/Program.cs').read_text().replace('-v1','-v2');(r/'Program.cs').write_text(s)
(r/'probe.csproj').write_text((w/'fixed9633-native-history-reader-source-v1/probe.csproj').read_text().replace('Fixed9633NativeHistoryReaderV1','Fixed9633NativeHistoryReaderV2'))
with (w/'build-fixed9633-native-history-reader-v2.log').open('xb') as f:subprocess.run(['/Users/dinghaolin/.dotnet/dotnet','build',str(r/'probe.csproj'),'--configuration','Release','--nologo'],cwd=r,stdout=f,stderr=subprocess.STDOUT,check=True)
api=load(w/'fixed9633-api-gameplay-closure-frozen-inputs-v1.json');rr=w/'fixed9633-native-history-reader-runtime-v2';subprocess.run(['/bin/cp','-cR',api['runtimeRoot'],str(rr)],check=True)
for suffix in ['.dll','.pdb']:shutil.copy2(r/'bin/Release/net10.0'/('Fixed9633NativeHistoryReaderV2'+suffix),rr/('Fixed9633NativeHistoryReaderV2'+suffix))
files=lambda p:{str(f.relative_to(p)):sha(f) for f in p.rglob('*') if f.is_file()}
with (w/'fixed9633-native-history-reader-frozen-v2.json').open('x') as f:json.dump({'runtimeRoot':str(rr),'runtimeFiles':files(rr),'assembly':'Fixed9633NativeHistoryReaderV2','sourceHashes':{str(p.relative_to(w)):sha(p) for p in r.iterdir() if p.is_file()},'previousReaderAllAssertionsUnchangedOnlyNewUnusedOutputPathsAndAssemblyName':True,'exactActualApiRuleInputs':reader['exactActualApiRuleInputs']},f,indent=2)
s=(w/'run-fixed9633-ci-main-pair-v2.py').read_text().replace('-v1','-v2').replace('frozen-fixed9633-native-composition-v2.json','frozen-fixed9633-native-composition-v1.json')
s=s.replace("frozen();assert subprocess.run", "frozen();assert all((w/('session-'+role+'.json')).is_file() for role in ['a','b']);assert subprocess.run")
ast.parse(s)
with (w/'run-fixed9633-ci-main-pair-v3.py').open('x') as f:f.write(s)
s=(w/'run-independent-fixed9633-native-history-v1.py').read_text().replace('-v1','-v2').replace('frozen-fixed9633-native-composition-v2.json','frozen-fixed9633-native-composition-v1.json').replace('HistoryReaderV1','HistoryReaderV2')
ast.parse(s)
with (w/'run-independent-fixed9633-native-history-v2.py').open('x') as f:f.write(s)
print('Existing two private QA auth profiles retained and copied0600; new v2 evidence paths and unchanged finite original reader assertions prepared. Prior no-room startup failure remains intact.')
