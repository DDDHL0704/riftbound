import ast
import collections
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import plistlib
import socket
import subprocess
import time
import urllib.request
import uuid

os.umask(0o077)
work = Path(__file__).resolve().parent
root = work.parents[2]
fixed = '48e7ff8702dc43a1b5a3991365d87068506ae137'
pg = Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin')
cluster = root / 'var/qa/permanent-play-here-base-20261017/postgres'
sock = Path('/tmp/rft-here-family-20261018-55486')
old = work.parent / 'graveyard-source-fixed-candidate-20261020'
prior = json.loads((old / 'visible-native-api-owner-v1.json').read_text())
publication = json.loads((work / 'fixed-api-publication-v1.json').read_text())
apps = json.loads((work / 'native-app-inputs.json').read_text())
reader = json.loads((work / 'native-frame-reader-publication-v1.json').read_text())
assert publication['fixedCommit'] == apps['fixedCommit'] == reader['fixedCommit'] == fixed
assert reader['actualRuleInputs'] == publication['actualRuleInputs']
assert prior['ownPostgresSmartStopped'] and prior['allOriginal192AuditSevenTablesUnchanged']
assert prior['allOriginal39NativeSevenTablesUnchanged'] and len(prior['allNativeRoomsAfter']) == 40
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
write = lambda p, d: p.write_text(json.dumps(d, indent=2) + '\n')
read_env = dict(os.environ, PGOPTIONS='-c default_transaction_read_only=on')
tables = ['matches', 'match_players', 'command_log', 'game_events', 'state_snapshots', 'snapshots', 'action_prompts']
guard_source = old / 'run-visible-native-api-v1.py'
guard_ast = ast.parse(guard_source.read_text())
functions = [n for n in guard_ast.body if isinstance(n, ast.FunctionDef) and n.name in {'query', 'rooms', 'digests', 'observe_lock'}]
assert len(functions) == 4
exec(compile(ast.Module(body=functions, type_ignores=[]), str(guard_source), 'exec'), globals())
out = work / 'actual-default-main-offline-retry-owner-v1.json'
assert not out.exists()
proof = {'status': 'STARTING_EXISTING_DATABASE_BASELINE_BEFORE_NATIVE_OFFLINE_LAUNCH',
         'startedAtUtc': now(), 'fixedCommit': fixed, 'ciRun': 39365877913,
         'actualRuleInputs': publication['actualRuleInputs'], 'ownRunnerPid': os.getpid(),
         'readOnlyBaselineGuardSource': str(guard_source), 'guardSourceSha256': sha(guard_source),
         'guardFunctions': [n.name for n in functions], 'clients': [],
         'noNewDatabaseOrOldMatchMigration': True,
         'headlessDefaultMainIsNotVisibleControlsOrWindows': True}
power = api = None
started = False
processes = []
baseline = None

def closed_port():
    with socket.socket() as s:
        s.settimeout(.5)
        return s.connect_ex(('127.0.0.1', 15847)) != 0

def verify_inputs():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == fixed
    assert all(sha(root / p) == h for p, h in publication['sourceInputHashes'].items())
    assert all(sha(work / 'fixed-api' / p) == h for p, h in publication['apiRuntimeHashes'].items())
    for row in apps['apps']:
        assert all(sha(Path(row['app']) / p) == h for p, h in apps['ciManagedAndPckPayloads'].items())

def launch_native(label, flag):
    app = work / ('Riftbound-' + label.upper() + '.app')
    profile = work / ('session-' + label + '.json')
    assert not profile.exists()
    write(profile, {'handle': 'qa48offline-' + label, 'roomId': 'RB-48E7FF',
                    'playerKey': 'pk_' + uuid.uuid4().hex + uuid.uuid4().hex,
                    'reconnectToken': None, 'lastDeckId': None, 'serverUrl': 'http://127.0.0.1:15847'})
    args = [str(app / 'Contents/MacOS/符文战场'), '--headless', '--max-fps', '60', '--quit-after', '3600', '--',
            '--riftbound-server=http://127.0.0.1:15847', '--riftbound-session-file=' + str(profile),
            '--riftbound-smoke-auto-ready', flag]
    log = work / ('offline-retry-client-' + label + '.log')
    with log.open('xb') as stream:
        child = subprocess.Popen(args, cwd='/tmp', stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    processes.append(child)
    proof['clients'].append({'label': label, 'pid': child.pid, 'startedAtUtc': now(), 'log': log.name,
                             'args': args, 'sameServerProfilePreexistedBeforeProcess': True,
                             'profilePathOnlyCredentialsNeverPublished': str(profile), 'oneProcessNoRestart': True})
    write(out, proof)
    return child

try:
    verify_inputs()
    assert subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), 'status'], capture_output=True).returncode == 3
    assert closed_port()
    proof['lockAtStart'] = observe_lock()
    power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())])
    proof['boundIdleSleepAssertionPid'] = power.pid
    write(out, proof)
    sock.mkdir(exist_ok=True)
    subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-l', str(work / 'offline-retry-postgres-v1.log'),
                    '-o', f'-p 55486 -h 127.0.0.1 -k {sock}', '-w', 'start'], capture_output=True, check=True)
    started = True
    assert rooms('riftbound_acceptance') == prior['priorAuditRooms']
    assert rooms('riftbound_here_native') == prior['allNativeRoomsAfter']
    assert digests('riftbound_acceptance', prior['priorAuditRooms']) == prior['priorAuditSevenTables']
    assert digests('riftbound_here_native', prior['priorNativeRooms']) == prior['priorNativeSevenTables']
    baseline = {'auditRooms': rooms('riftbound_acceptance'), 'nativeRooms': rooms('riftbound_here_native')}
    baseline['auditSevenTables'] = digests('riftbound_acceptance', baseline['auditRooms'])
    baseline['nativeSevenTables'] = digests('riftbound_here_native', baseline['nativeRooms'])
    write(work / 'before-offline-native-192-audit-40-native-seven-table-baseline-v1.json', baseline)
    proof.update(status='BASELINE_VERIFIED_API_RELEASE_HELD_FOR_ACTUAL_NATIVE_OFFLINE_START',
                 original192Audit39NativeSevenTablesMatchPreviousReceipts=True,
                 priorAll40NativeRoomsFrozenBeforeNewCandidate=True)
    assert closed_port()
    b = launch_native('b', '--riftbound-smoke-auto-join-public-match')
    proof['offlineBarrierStartAtUtc'] = now()
    time.sleep(2)
    assert b.poll() is None and closed_port()
    proof.update(offlineBarrierReleaseAtUtc=now(), apiPortClosedForFirstTwoSecondsOfSameNativeB=True)
    with (work / 'offline-retry-api-v1.log').open('xb') as stream:
        api = subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet', str(work / 'fixed-api/Riftbound.Api.dll')],
                               cwd=work / 'fixed-api', stdout=stream, stderr=subprocess.STDOUT, start_new_session=True,
                               env=dict(os.environ, ASPNETCORE_ENVIRONMENT='Production', ASPNETCORE_URLS='http://127.0.0.1:15847',
                                        ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit'))
    proof.update(ownApiPid=api.pid, apiProcessStartedAtUtc=now())
    for attempt in range(100):
        assert api.poll() is None and b.poll() is None
        try:
            with urllib.request.urlopen('http://127.0.0.1:15847/health', timeout=.5) as response:
                health = json.load(response)
            assert health['persistenceMode'] == 'postgres' and health['environment'] == 'Production'
            break
        except OSError:
            time.sleep(.05)
    else:
        raise AssertionError('Exact published API not ready inside native public-join retry window.')
    assert set(subprocess.check_output(['/usr/sbin/lsof', '-tiTCP:15847', '-sTCP:LISTEN'], text=True).splitlines()) == {str(api.pid)}
    with urllib.request.urlopen('http://127.0.0.1:15847/matches', timeout=2) as response:
        assert json.load(response) == []
    proof['ownApiHealth'] = health
    a = launch_native('a', '--riftbound-smoke-auto-public-match')
    proof.update(status='ACTUAL_EXPORTED_DEFAULT_MAIN_PAIR_RUNNING_NO_UI_DEPENDENCY', apiReadyAtUtc=now())
    write(out, proof)
    print('ACTUAL_NEW_EXPORTED_MAIN_OFFLINE_THEN_ONLINE_PAIR_RUNNING', b.pid, a.pid, flush=True)
    deadline = time.monotonic() + 100
    while any(child.poll() is None for child in processes):
        assert api.poll() is None and time.monotonic() < deadline
        time.sleep(.25)
    for child, record in zip(processes, proof['clients']):
        record['normalQuitAfterReturnCode'] = child.returncode
        record['logSha256'] = sha(work / record['log'])
        assert child.returncode == 0
    b_log = (work / 'offline-retry-client-b.log').read_text()
    a_log = (work / 'offline-retry-client-a.log').read_text()
    failure = b_log.index('Unable to load preconstructed decks:')
    loaded = b_log.index('Preconstructed decks loaded: 11.')
    assert failure < loaded and b_log.count('Client booted. Waiting for server authority.') == 1
    assert 'Auto smoke: joining public match ' in b_log and 'Public match joined:' in b_log
    assert 'Public match created:' in a_log
    for raw in [b_log, a_log]:
        assert 'SubmitDeck receipt accepted=True' in raw and 'Ready receipt accepted=True' in raw
        assert not any(marker in raw for marker in ['Unhandled exception', 'SCRIPT ERROR:', 'ERROR:'])
    added = sorted(set(rooms('riftbound_here_native')) - set(baseline['nativeRooms']))
    assert len(added) == 1
    room = added[0]
    proof['newNativeRoom'] = room
    env = dict(os.environ, RIFTBOUND_FIXED_ACCEPTANCE_ROOT=str(work),
               ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit')
    frame_path = work / 'offline-retry-original-real-native-frame-v1.json.gz'
    with (work / 'offline-retry-original-frame-full-replay-reader-v1.log').open('xb') as stream:
        subprocess.run(['/Users/dinghaolin/.dotnet/dotnet', str(work / 'native-frame-reader/bin/Release/net10.0/probe.dll'),
                        'native-frame', room, str(frame_path)], cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT, check=True, timeout=90)
    frame = json.loads(gzip.decompress(frame_path.read_bytes()))
    counts = collections.Counter(c['commandType'] for c in frame['commands'])
    assert counts == {'SUBMIT_DECK': 2, 'READY': 2}
    assert all(c['accepted'] and c['ruleInputs'] == publication['actualRuleInputs'] for c in frame['commands'])
    assert {c['playerId'] for c in frame['commands']} == {'qa48offline-a', 'qa48offline-b'}
    assert frame['authoritativeState']['ruleInputs'] == publication['actualRuleInputs']
    assert frame['openingSeed'] != 0 and frame['isConsistent']
    proof.update(status='PASS_ACTUAL_EXPORTED_MAIN_SAME_PROCESS_OFFLINE_TO_ONLINE_DECK_RETRY_REAL_SQL_FULL_REPLAY',
                 actualCommands=len(frame['commands']), actualEvents=len(frame['events']), commandTypeCounts=dict(counts),
                 nativeBInitialDeckFetchFailedThenLoadedElevenWithinSameProcess=True,
                 bothActualNativeClientsSubmittedDeckAndReadied=True,
                 originalFrameSha256=sha(frame_path), originalFrameFullReplayPassed=True,
                 noSurrenderInjectedStateOldMigrationOrCredentialExposure=True,
                 visibleNativeControlsAndNewCandidateFullAndPhysicalWindows='OPEN')
except BaseException as error:
    proof.update(status='FAILED_OR_INTERRUPTED_ORIGINAL_PREFIX_RETAINED', errorType=type(error).__name__, errorMessage=str(error))
    raise
finally:
    for child in processes:
        if child.poll() is None:
            child.terminate()
            child.wait(timeout=15)
    if api is not None and api.poll() is None:
        api.terminate()
        proof['ownApiGracefulStopExitCode'] = api.wait(timeout=30)
    if started:
        if baseline is not None:
            proof['original192AuditRoomsExact'] = rooms('riftbound_acceptance') == baseline['auditRooms']
            proof['allOriginal192AuditSevenTablesExact'] = digests('riftbound_acceptance', baseline['auditRooms']) == baseline['auditSevenTables']
            proof['allOriginal40NativeSevenTablesExact'] = digests('riftbound_here_native', baseline['nativeRooms']) == baseline['nativeSevenTables']
            proof['nativeRoomsAfter'] = rooms('riftbound_here_native')
        verify_inputs()
        proof['sourceAndFrozenApiAnd373NativePayloadsStillExact'] = True
        proof['ownPostgresSmartStopped'] = subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-m', 'smart', '-w', '-t', '20', 'stop'], capture_output=True).returncode == 0
    if power is not None:
        if power.poll() is None:
            power.terminate()
            power.wait(timeout=10)
        proof['boundIdleSleepAssertionEnded'] = power.poll() is not None
    proof.update(finishedAtUtc=now(), lockAtEnd=observe_lock(), originalDatabaseRetained=True)
    write(out, proof)
print(proof['status'], proof.get('actualCommands'), proof.get('actualEvents'), flush=True)
