import ast
import datetime
import hashlib
import json
import os
from pathlib import Path
import plistlib
import socket
import subprocess
import time
import urllib.request

os.umask(0o077)
work = Path(__file__).resolve().parent
root = work.parents[2]
pg = Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin')
cluster = root / 'var/qa/permanent-play-here-base-20261017/postgres'
sock = Path('/tmp/rft-here-family-20261018-55486')
publication = json.loads((work / 'fixed-api-publication-v1.json').read_text())
headless = json.loads((work / 'actual-default-main-offline-retry-owner-v1.json').read_text())
baseline = json.loads((work / 'before-offline-native-192-audit-40-native-seven-table-baseline-v1.json').read_text())
assert headless['status'].startswith('PASS_ACTUAL_EXPORTED_MAIN_SAME_PROCESS_OFFLINE_TO_ONLINE')
assert headless['allOriginal192AuditSevenTablesExact'] and headless['allOriginal40NativeSevenTablesExact']
assert headless['ownPostgresSmartStopped'] and len(headless['nativeRoomsAfter']) == 41
room = headless['newNativeRoom']
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
write = lambda p, d: p.write_text(json.dumps(d, indent=2) + '\n')
read_env = dict(os.environ, PGOPTIONS='-c default_transaction_read_only=on')
tables = ['matches', 'match_players', 'command_log', 'game_events', 'state_snapshots', 'snapshots', 'action_prompts']
guard_source = work.parent / 'graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes = [n for n in ast.parse(guard_source.read_text()).body if isinstance(n, ast.FunctionDef)
         and n.name in {'query', 'rooms', 'digests', 'observe_lock'}]
assert len(nodes) == 4
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(guard_source), 'exec'), globals())
out = work / 'visible-current-api-owner-v1.json'
ready = work / 'visible-current-api-ready-v1.json'
stop = work / 'visible-current-api-stop-v1.json'
restart = work / 'visible-current-api-restart-request-v1.json'
assert not any(p.exists() for p in [out, ready, stop, restart])
proof = {'status': 'STARTING_ORIGINAL_CURRENT_NATIVE_ROOM_API', 'startedAtUtc': now(),
         'fixedCommit': publication['fixedCommit'], 'actualRuleInputs': publication['actualRuleInputs'],
         'allowedExistingCurrentNativeRoom': room, 'ownRunnerPid': os.getpid(),
         'noNewDatabaseRoomOrOldMigration': True, 'ownedApiProcesses': [], 'restartRequestsHandled': 0,
         'guardSourceSha256': sha(guard_source), 'apiRunningIsNotProductAcceptance': True}
api = power = None
started = False

def verify_inputs():
    assert all(sha(root / p) == h for p, h in publication['sourceInputHashes'].items())
    assert all(sha(work / 'fixed-api' / p) == h for p, h in publication['apiRuntimeHashes'].items())

def start_api(index):
    global api
    log = work / ('visible-current-api-' + str(index) + '.log')
    with log.open('xb') as stream:
        api = subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet', str(work / 'fixed-api/Riftbound.Api.dll')],
                               cwd=work / 'fixed-api', stdout=stream, stderr=subprocess.STDOUT, start_new_session=True,
                               env=dict(os.environ, ASPNETCORE_ENVIRONMENT='Production', ASPNETCORE_URLS='http://127.0.0.1:15847',
                                        ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit'))
    for attempt in range(150):
        assert api.poll() is None
        try:
            with urllib.request.urlopen('http://127.0.0.1:15847/health', timeout=.5) as response:
                health = json.load(response)
            assert health['persistenceMode'] == 'postgres' and health['environment'] == 'Production'
            assert set(subprocess.check_output(['/usr/sbin/lsof', '-tiTCP:15847', '-sTCP:LISTEN'], text=True).splitlines()) == {str(api.pid)}
            proof['ownedApiProcesses'].append({'pid': api.pid, 'index': index, 'log': log.name, 'readyAtUtc': now(), 'health': health})
            return
        except OSError:
            time.sleep(.1)
    raise AssertionError('Own exact current production API not ready.')

try:
    verify_inputs()
    assert subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), 'status'], capture_output=True).returncode == 3
    with socket.socket() as guard:
        assert guard.connect_ex(('127.0.0.1', 15847)) != 0
    power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())])
    proof.update(boundIdleSleepAssertionPid=power.pid, lockAtStart=observe_lock())
    write(out, proof)
    sock.mkdir(exist_ok=True)
    subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-l', str(work / 'visible-current-postgres-v1.log'),
                    '-o', f'-p 55486 -h 127.0.0.1 -k {sock}', '-w', 'start'], capture_output=True, check=True)
    started = True
    assert rooms('riftbound_acceptance') == baseline['auditRooms'] and rooms('riftbound_here_native') == headless['nativeRoomsAfter']
    assert digests('riftbound_acceptance', baseline['auditRooms']) == baseline['auditSevenTables']
    assert digests('riftbound_here_native', baseline['nativeRooms']) == baseline['nativeSevenTables']
    proof.update(original192AuditAnd40NativeSevenTablesExactBeforeApi=True,
                 currentRoomSevenTablesAtStart=digests('riftbound_here_native', [room]))
    start_api(0)
    proof['status'] = 'OWN_CURRENT_FIXED_PRODUCTION_API_READY_CONTINUING_ORIGINAL_HEADLESS_ROOM'
    write(out, proof)
    write(ready, {'atUtc': now(), 'fixedCommit': publication['fixedCommit'], 'actualRuleInputs': publication['actualRuleInputs'],
                  'apiPid': api.pid, 'room': room, 'url': 'http://127.0.0.1:15847', 'realDatabase': 'riftbound_here_native'})
    print('CURRENT_FIXED_PRODUCTION_API_READY_ORIGINAL_ROOM', room, api.pid, flush=True)
    deadline = time.monotonic() + 5400
    while not stop.exists():
        assert api.poll() is None and time.monotonic() < deadline
        if restart.exists() and proof['restartRequestsHandled'] == 0:
            verify_inputs()
            api.terminate()
            code = api.wait(timeout=30)
            assert code == 0
            proof['ownedApiProcesses'][-1]['gracefulColdStopExitCode'] = code
            start_api(1)
            proof['restartRequestsHandled'] = 1
            write(work / 'visible-current-api-restart-complete-v1.json', {'atUtc': now(), 'fixedCommit': publication['fixedCommit'],
                  'newApiPid': api.pid, 'originalApiPid': proof['ownedApiProcesses'][0]['pid'],
                  'actualRuleInputs': publication['actualRuleInputs'], 'room': room})
            write(out, proof)
            print('CURRENT_FIXED_API_COLD_RESTART_READY', api.pid, flush=True)
        time.sleep(.5)
    proof['status'] = 'OWN_CURRENT_API_STOP_REQUESTED_PENDING_ORIGINAL_ROW_VERIFICATION'
finally:
    if api is not None and api.poll() is None:
        api.terminate()
        proof['ownApiGracefulStopExitCode'] = api.wait(timeout=30)
    if started:
        proof['allOriginal192AuditRoomsExact'] = rooms('riftbound_acceptance') == baseline['auditRooms']
        proof['allOriginal192AuditSevenTablesExact'] = digests('riftbound_acceptance', baseline['auditRooms']) == baseline['auditSevenTables']
        proof['allOriginal40NativeSevenTablesExact'] = digests('riftbound_here_native', baseline['nativeRooms']) == baseline['nativeSevenTables']
        proof['all41NativeRoomIdsUnchanged'] = rooms('riftbound_here_native') == headless['nativeRoomsAfter']
        verify_inputs()
        proof['all3303SourcesAndFrozenApiStillExact'] = True
        proof['ownPostgresSmartStopped'] = subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-m', 'smart', '-w', '-t', '20', 'stop'], capture_output=True).returncode == 0
    if power is not None:
        if power.poll() is None:
            power.terminate()
            power.wait(timeout=10)
        proof['boundIdleSleepAssertionEnded'] = power.poll() is not None
    proof.update(finishedAtUtc=now(), lockAtEnd=observe_lock(), originalDatabaseRetained=True)
    write(out, proof)
