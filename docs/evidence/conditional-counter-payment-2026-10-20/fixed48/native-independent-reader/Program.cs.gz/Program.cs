using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.CardCatalog;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;
var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
try
{
    Check(args.Length == 1, "Exact evidence root required.");
    var work = Path.GetFullPath(args[0]); var visible = Path.Combine(work, "native-visible-v1");
    var receipt = Path.Combine(visible, "independent-original-native-score-history-v1.json");
    Check(!File.Exists(receipt), "Fresh receipt required.");
    var settings = new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
    Check(settings.Host == "127.0.0.1" && settings.Port == 55486 && settings.Database == "riftbound_here_native"
        && settings.Username == "codex_riftbound_audit", "Existing actual native database required.");
    settings.Options = "-c default_transaction_read_only=on";
    await using var source = NpgsqlDataSource.Create(settings.ConnectionString);
    var originalFrames = new Dictionary<string, MatchRecoveryFrame>();
    var hashes = new Dictionary<string, string>();
    foreach (var filename in new[] { "../offline-retry-original-real-native-frame-v1.json.gz", "05-before-first-visible-mulligan-original-frame.json.gz", "07-before-api-cold-restart-original-frame.json.gz", "09-after-api-cold-restart-original-frame.json.gz", "17-final-normal-eight-score-original-frame.json.gz" })
    {
        var bytes = File.ReadAllBytes(Path.Combine(visible, filename));
        hashes.Add(filename, Convert.ToHexStringLower(SHA256.HashData(bytes)));
        await using var zip = new GZipStream(new MemoryStream(bytes), CompressionMode.Decompress);
        var raw = await JsonNode.ParseAsync(zip) ?? throw new Exception("Original frame required.");
        var frame = raw.Deserialize<MatchRecoveryFrame>(json)!;
        Check(JsonNode.DeepEquals(raw, JsonSerializer.SerializeToNode(frame, json)), "Every original frame field/null preserved.");
        Check(frame.IsConsistent && frame.RoomId == "RB-B67RVX" && frame.ReplayInitialState is { Tick: 0 } blank && blank.CardObjects.Count == 0
            && frame.OpeningSeed != 0 && frame.AuthoritativeState!.RuleInputs == RuleInputIdentity.Current,
            "Original blank opening, original nonzero private seed and fixed implementation identity required.");
        Check((await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame, new CoreRuleEngine(), default)).Count == 0, "Each original full action/event/state replay must pass.");
        originalFrames.Add(filename, frame);
    }
    var final = originalFrames["17-final-normal-eight-score-original-frame.json.gz"];
    var actual = await new PostgresMatchRecoveryStore(source).LoadAsync("RB-B67RVX", default) ?? throw new Exception("Actual original room missing.");
    Check(JsonNode.DeepEquals(JsonSerializer.SerializeToNode(final, json), JsonSerializer.SerializeToNode(actual, json)), "All saved final fields/nulls/commands/events/private views/prompts match actual database.");
    Check(final.Commands.Count == 29 && final.Events.Count == 215 && final.Commands.All(c => c.Accepted && c.RuleInputs == RuleInputIdentity.Current), "All original 29 commands accepted and 215 events at exact fixed input identity.");
    Check(final.Commands.All(c => c.CommandType is not "SURRENDER" and not "DEV_SEED_SCENARIO"), "No surrender or injected state.");
    var expectedCommands = new Dictionary<string, int> { ["SUBMIT_DECK"] = 2, ["READY"] = 2, ["MULLIGAN"] = 2, ["TAP_RUNE"] = 2, ["PLAY_CARD"] = 1, ["MOVE_UNIT"] = 1, ["PASS_FOCUS"] = 2, ["END_TURN"] = 17 };
    var actualCommands = final.Commands.GroupBy(c => c.CommandType).ToDictionary(g => g.Key, g => g.Count());
    Check(actualCommands.Count == expectedCommands.Count && expectedCommands.All(p => actualCommands.GetValueOrDefault(p.Key) == p.Value), "Independent exact ordinary native command types and counts, no hidden replacement path.");
    var played = (PlayCardCommand)GameCommandJsonMapper.Map(final.Commands.Single(c => c.CommandType == CommandTypes.PlayCard).RawCommand!.Value);
    Check(played.CardNo == "OGN·103/298" && played.Destination == "BASE" && played.TargetObjectIds.Count == 0, "Actual native OGN103 student play at base without target or alternative command.");
    var moved = (MoveUnitCommand)GameCommandJsonMapper.Map(final.Commands.Single(c => c.CommandType == CommandTypes.MoveUnit).RawCommand!.Value);
    Check(moved.SourceObjectId == played.SourceObjectId && moved.Destination == "BATTLEFIELD:qa48offline-b-BATTLEFIELD-OGN-277-298-01", "Same actual native unit moved to the original OGN277 battlefield.");
    var state = final.AuthoritativeState!;
    Check(state.Status == MatchStatuses.Finished && state.WinnerPlayerId == "qa48offline-b" && state.PlayerScores["qa48offline-b"] == 8 && state.PlayerScores["qa48offline-a"] == 0
        && state.TurnNumber == 18 && state.Tick == 28 && state.StackItems.Count == 0 && state.TriggerQueue.Count == 0
        && state.PendingPayment is null && state.PendingCardChoice is null, "Independent fixed expected final result and no pending work.");
    var scores = final.Events.Where(e => e.Event.Kind == "SCORE_GAINED").ToArray();
    Check(scores.Length == 8, "Exactly eight scoring events required.");
    for (var i = 0; i < scores.Length; i++)
    {
        var payload = JsonSerializer.SerializeToElement(scores[i].Event.Payload);
        Check(payload.GetProperty("playerId").GetString() == "qa48offline-b" && payload.GetProperty("amount").GetInt32() == 1
            && payload.GetProperty("score").GetInt32() == i + 1
            && payload.GetProperty("reason").GetString() == (i == 0 ? "BATTLEFIELD_CONQUERED_SCORE" : "BATTLEFIELD_HELD_SCORE"), "One conquest and seven holding points, in original order.");
    }
    Check(final.Events.Count(e => e.Event.Kind == "MATCH_WON") == 1 && final.Events.Last().Event.Kind == "MATCH_WON"
        && !final.Events.Any(e => e.Event.Kind.Contains("SURRENDER", StringComparison.Ordinal) || e.Event.Kind.Contains("BURNOUT", StringComparison.Ordinal)), "Single normal score victory, no surrender/burnout result.");
    var catalog = await OfficialCardCatalog.LoadDefaultAsync(); var deckChecks = 0;
    foreach (var c in final.Commands.Where(c => c.CommandType == CommandTypes.SubmitDeck))
    {
        var deck = (SubmitDeckCommand)GameCommandJsonMapper.Map(c.RawCommand!.Value);
        foreach (var format in new[] { OfficialDeckFormat.CoreRules, OfficialDeckFormat.ChinaStandard20260724 })
        { Check(OfficialDeckValidator.Validate(new(deck.LegendCardNo, deck.ChampionCardNo, deck.MainDeck, deck.RuneDeck, deck.Battlefields), catalog, format).IsValid, "Actual submitted deck must be legal in named format."); deckChecks++; }
    }
    Check(deckChecks == 4, "Two actual decks checked in both exact named formats.");
    foreach (var phase in originalFrames.Values)
    {
        Check(phase.OpeningSeed == final.OpeningSeed, "Same original private opening seed throughout.");
        Check(JsonNode.DeepEquals(JsonSerializer.SerializeToNode(phase.Commands, json), JsonSerializer.SerializeToNode(final.Commands.Take(phase.Commands.Count).ToArray(), json))
            && JsonNode.DeepEquals(JsonSerializer.SerializeToNode(phase.Events, json), JsonSerializer.SerializeToNode(final.Events.Take(phase.Events.Count).ToArray(), json)), "Original pre/post-reconnect history remains exact immutable prefix of final game.");
    }
    var history = new Dictionary<string, int>(); var matched = new HashSet<string>();
    var historyPath = Path.Combine(visible, "actual-original-native-historical-payloads-v1.ndjson.gz");
    Check(!File.Exists(historyPath), "Fresh exact historical export required.");
    await using (var output = new StreamWriter(new GZipStream(File.Create(historyPath), CompressionLevel.SmallestSize)))
    await using (var connection = await source.OpenConnectionAsync())
    {
        Check((string)(await new NpgsqlCommand("show transaction_read_only", connection).ExecuteScalarAsync())! == "on", "Database-enforced read-only independent connection.");
        foreach (var table in new[] { "state_snapshots", "snapshots", "action_prompts" })
        {
            await using var query = new NpgsqlCommand($"select id,payload::text from {table} where match_id=@room order by id", connection);
            query.Parameters.AddWithValue("room", "RB-B67RVX"); await using var rows = await query.ExecuteReaderAsync(); var count = 0;
            while (await rows.ReadAsync())
            {
                var raw = rows.GetString(1); var original = JsonNode.Parse(raw);
                var typed = table switch { "state_snapshots" => JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<MatchState>(raw, json), json),
                    "snapshots" => JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<SnapshotDto>(raw, json), json),
                    _ => JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<ActionPromptDto>(raw, json), json) };
                Check(JsonNode.DeepEquals(original, typed), "Every historical state/private snapshot/prompt retains all original fields and nulls."); count++;
                await output.WriteLineAsync(JsonSerializer.Serialize(new { table, id = rows.GetValue(0).ToString(), payload = original }));
                if (table == "state_snapshots") foreach (var phase in originalFrames)
                    if (JsonNode.DeepEquals(original, JsonSerializer.SerializeToNode(phase.Value.AuthoritativeState, json))) matched.Add(phase.Key);
            }
            Check(count > 0, "Real historical rows required."); history.Add(table, count);
        }
    }
    Check(matched.Count == 5, "All five saved original checkpoint states match actual historical rows, including both sides of API restart.");
    foreach (var pair in hashes) Check(Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(Path.Combine(visible, pair.Key)))) == pair.Value, "Original evidence not rewritten.");
    await File.WriteAllTextAsync(receipt, JsonSerializer.Serialize(new { status = "PASS_INDEPENDENT_ACTUAL_NATIVE_DATABASE_NORMAL_SCORE_AND_ALL_ORIGINAL_REPLAYS",
        observedAtUtc = DateTimeOffset.UtcNow, fixedCommit = "48e7ff8702dc43a1b5a3991365d87068506ae137", actualRuleInputs = RuleInputIdentity.Current,
        room = "RB-B67RVX", acceptedCommands = 29, events = 215, finalTurn = 18, finalTick = 28, winner = "qa48offline-b", scoreB = 8, scoreA = 0,
        scoreReasons = new { conquest = 1, holding = 7 }, originalNonZeroPrivateSeedPreserved = true, wholeFrameExact = true,
        allFiveFullOriginalReplaysPass = true, allFiveOriginalPrefixesUnchanged = true, allFiveHistoricalCheckpointsMatched = true,
        actualHistoricalPayloads = history, originalFrameHashes = hashes,
        historicalExportSha256 = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(historyPath))),
        actualDatabaseEnforcedReadOnly = true, twoActualDecksIndependentlyLegalInBothNamedFormats = true,
        wholeCardOrWindowsOrAll110PairingsCertifiedByThisSingleNativeGame = false }, json));
    Console.WriteLine("PASS_INDEPENDENT_ACTUAL_NATIVE_DATABASE_NORMAL_SCORE_AND_ALL_ORIGINAL_REPLAYS");
}
catch (Exception error) { Console.Error.WriteLine(error); Environment.ExitCode = 1; }
static void Check(bool value, string reason) { if (!value) throw new Exception(reason); }
