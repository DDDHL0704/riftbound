using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.CardCatalog;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
if (args.Length != 1) throw new Exception("Exact current fixed evidence root required.");
var work = Path.GetFullPath(args[0]);
var receipt = Path.Combine(work, "offline-retry-independent-actual-database-readback-v1.json");
Check(!File.Exists(receipt), "Fresh independent receipt required.");
var settings = new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
Check(settings.Host == "127.0.0.1" && settings.Port == 55486 && settings.Database == "riftbound_here_native"
    && settings.Username == "codex_riftbound_audit", "Existing dedicated original native database only.");
settings.Options = "-c default_transaction_read_only=on";
await using var source = NpgsqlDataSource.Create(settings.ConnectionString);
var framePath = Path.Combine(work, "offline-retry-original-real-native-frame-v1.json.gz");
var originalBytes = File.ReadAllBytes(framePath);
await using var compressed = new GZipStream(new MemoryStream(originalBytes), CompressionMode.Decompress);
var rawFrame = await JsonNode.ParseAsync(compressed) ?? throw new Exception("Original saved frame required.");
var saved = rawFrame.Deserialize<MatchRecoveryFrame>(json)!;
Check(JsonNode.DeepEquals(rawFrame, JsonSerializer.SerializeToNode(saved, json)), "Every original saved field and null retained.");
var actual = await new PostgresMatchRecoveryStore(source).LoadAsync(saved.RoomId, default)
    ?? throw new Exception("Original actual room required.");
Check(JsonNode.DeepEquals(rawFrame, JsonSerializer.SerializeToNode(actual, json)), "Every saved field/null/command/event/private view matches actual database.");
Check(actual.IsConsistent && actual.OpeningSeed != 0 && actual.ReplayInitialState is { Tick: 0 } blank && blank.CardObjects.Count == 0,
    "Original ordinary opening and nonzero private seed; no injected fixture.");
Check(actual.AuthoritativeState is { } && actual.AuthoritativeState.RuleInputs == RuleInputIdentity.Current,
    "Exact actual fixed current input identity required.");
Check(actual.AuthoritativeState!.Status == MatchStatuses.InProgress
    && actual.AuthoritativeState.Phase == MatchPhases.Mulligan && actual.Commands.Count == 4,
    "Exact bounded two-client deck/ready checkpoint, without advancing the game.");
Check(actual.Commands.All(c => c.Accepted && c.RuleInputs == RuleInputIdentity.Current), "All four actual commands accepted at exact input identity.");
foreach (var player in new[] { "qa48offline-a", "qa48offline-b" })
{
    var commands = actual.Commands.Where(c => c.PlayerId == player).ToArray();
    Check(commands.Length == 2 && commands[0].CommandType == CommandTypes.SubmitDeck && commands[1].CommandType == CommandTypes.Ready,
        "Each actual native player submitted its deck then readied exactly once.");
}
Check(actual.Commands.Select(c => c.PlayerId).Distinct().Count() == 2, "Exactly the two bounded actual native identities.");
Check(!actual.Events.Any(e => e.Event.Kind.Contains("SURRENDER", StringComparison.Ordinal) || e.Event.Kind == "MATCH_WON"),
    "No surrender, score completion or substituted acceptance scenario.");
Check((await MatchActionLogReplayer.ValidateRecoveryFrameAsync(actual, new CoreRuleEngine(), default)).Count == 0,
    "Actual original full action/event/state replay required.");
var catalog = await OfficialCardCatalog.LoadDefaultAsync();
var deckChecks = 0;
foreach (var command in actual.Commands.Where(c => c.CommandType == CommandTypes.SubmitDeck))
{
    var deck = (SubmitDeckCommand)GameCommandJsonMapper.Map(command.RawCommand!.Value);
    foreach (var format in new[] { OfficialDeckFormat.CoreRules, OfficialDeckFormat.ChinaStandard20260724 })
    {
        Check(OfficialDeckValidator.Validate(new(deck.LegendCardNo, deck.ChampionCardNo, deck.MainDeck, deck.RuneDeck, deck.Battlefields), catalog, format).IsValid,
            "Each actual selected native deck legal under the exact named format.");
        deckChecks++;
    }
}
Check(deckChecks == 4, "Two actual decks checked in both exact named formats.");
var historyPath = Path.Combine(work, "offline-retry-actual-original-historical-payloads-v1.ndjson.gz");
Check(!File.Exists(historyPath), "Fresh exact historical export required.");
var counts = new Dictionary<string, int>();
var matchedFinalState = false;
await using (var writer = new StreamWriter(new GZipStream(File.Create(historyPath), CompressionLevel.SmallestSize)))
await using (var connection = await source.OpenConnectionAsync())
{
    Check((string)(await new NpgsqlCommand("show transaction_read_only", connection).ExecuteScalarAsync())! == "on", "Database-enforced independent read-only connection.");
    foreach (var table in new[] { "state_snapshots", "snapshots", "action_prompts" })
    {
        await using var query = new NpgsqlCommand($"select id,payload::text from {table} where match_id=@room order by id", connection);
        query.Parameters.AddWithValue("room", saved.RoomId);
        await using var rows = await query.ExecuteReaderAsync();
        var count = 0;
        while (await rows.ReadAsync())
        {
            var text = rows.GetString(1);
            var original = JsonNode.Parse(text);
            var typed = table switch {
                "state_snapshots" => JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<MatchState>(text, json), json),
                "snapshots" => JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<SnapshotDto>(text, json), json),
                _ => JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<ActionPromptDto>(text, json), json) };
            Check(JsonNode.DeepEquals(original, typed), "Every actual historical state/private view/prompt retains all original fields/nulls.");
            if (table == "state_snapshots" && JsonNode.DeepEquals(original, JsonSerializer.SerializeToNode(saved.AuthoritativeState, json))) matchedFinalState = true;
            await writer.WriteLineAsync(JsonSerializer.Serialize(new { table, id = rows.GetValue(0).ToString(), payload = original }));
            count++;
        }
        Check(count > 0, "Actual original historical rows required for each table.");
        counts.Add(table, count);
    }
}
Check(matchedFinalState, "Actual final original state is present in real historical rows.");
Check(File.ReadAllBytes(framePath).SequenceEqual(originalBytes), "Original native frame was not rewritten.");
await File.WriteAllTextAsync(receipt, JsonSerializer.Serialize(new {
    status = "PASS_INDEPENDENT_ACTUAL_OFFLINE_RETRY_TWO_NATIVE_DECKS_ALL_ORIGINAL_FIELDS_HISTORIES_AND_FULL_REPLAY",
    atUtc = DateTimeOffset.UtcNow, fixedCommit = "48e7ff8702dc43a1b5a3991365d87068506ae137", room = saved.RoomId,
    actualRuleInputs = RuleInputIdentity.Current, commands = actual.Commands.Count, events = actual.Events.Count,
    originalFrameSha256 = Convert.ToHexStringLower(SHA256.HashData(originalBytes)), actualHistoricalRows = counts,
    actualDeckChecks = deckChecks, noDatabaseOrHistoryMutation = true,
    visibleControlsNormalScoreGameAndPhysicalWindowsCertified = false }, json));
Console.WriteLine("INDEPENDENT_ACTUAL_NATIVE_OFFLINE_RETRY_READONLY_FULL_ORIGINAL_REPLAY_PASS");
static void Check(bool condition, string message) { if (!condition) throw new Exception(message); }
