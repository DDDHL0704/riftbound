import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

os.umask(0o077)
work = Path(__file__).resolve().parent
root = work.parents[2]
fixed = '48e7ff8702dc43a1b5a3991365d87068506ae137'
previous = root / 'var/qa/native-offline-deck-retry-20261020'
source_inputs = json.loads((previous / 'only-check-start-inputs-v1.json').read_text())['sourceInputHashes']
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
write = lambda p, d: p.write_text(json.dumps(d, indent=2) + '\n')
output = work / 'fixed-api-publication-v1.json'
assert not output.exists() and not (work / 'fixed-api').exists()
proof = {'startedAtUtc': now(), 'fixedCommit': fixed, 'status': 'BUILDING_FIXED_API',
         'sourceInputCount': len(source_inputs), 'sourceInputHashes': source_inputs,
         'noNewCheckoutDatabaseSdkOrGodotProjectBuild': True,
         'conformanceCheckNativeMainNotClaimed': True}
power = child = None

def verify():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == fixed
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root)
    assert all(sha(root / p) == h for p, h in source_inputs.items())

try:
    verify()
    power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())])
    proof.update(ownRunnerPid=os.getpid(), idleSleepAssertionPid=power.pid)
    write(output, proof)
    log = work / 'fixed-api-publish-v1.log'
    with log.open('xb') as stream:
        child = subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet', 'publish', 'src/Riftbound.Api/Riftbound.Api.csproj',
                                  '-c', 'Release', '-o', str(work / 'fixed-api'), '-v:q', '--nologo'],
                                 cwd=root, stdout=stream, stderr=subprocess.STDOUT)
        code = child.wait(timeout=300)
    proof.update(publishExitCode=code, publishLogSha256=sha(log))
    assert code == 0
    api = work / 'fixed-api'
    for name in ['card-catalog.zh-CN.json', 'armaments.json', 'rule-input-scope.json']:
        assert sha(api / 'data/official' / name) == sha(root / 'data/official' / name)
    probe = root / 'var/qa/destruction-graveyard-implementation-20261020/identity-probe/bin/Debug/net10.0/probe.dll'
    actual = json.loads(subprocess.check_output(['/Users/dinghaolin/.dotnet/dotnet', str(probe), str(api)], cwd=api, text=True))
    verify()
    proof.update(status='PASS_FIXED_API_PUBLISHED_ACTUAL_RULE_INPUTS_READ',
                 actualRuleInputs=actual['actualRuleInputs'], actualCoreModules=actual['modules'],
                 apiRuntimeHashes={str(p.relative_to(api)): sha(p) for p in api.rglob('*') if p.is_file()},
                 sourceInputsUnchanged=True, actualNewNativeRetryAndVisibleAndWindows='OPEN')
except BaseException as error:
    proof.update(status='FAILED_PUBLICATION_RETAINED', errorType=type(error).__name__, errorMessage=str(error))
    raise
finally:
    if child is not None and child.poll() is None:
        child.terminate()
        child.wait(timeout=30)
    if power is not None:
        if power.poll() is None:
            power.terminate()
            power.wait(timeout=10)
        proof['boundIdleSleepAssertionEnded'] = power.poll() is not None
    proof['finishedAtUtc'] = now()
    write(output, proof)
print(proof['status'], fixed, proof.get('actualRuleInputs', {}).get('fingerprint', ''), flush=True)
