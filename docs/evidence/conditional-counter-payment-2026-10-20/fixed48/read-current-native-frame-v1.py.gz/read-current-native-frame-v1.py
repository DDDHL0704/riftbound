import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

work = Path(__file__).resolve().parent
assert len(sys.argv) == 2 and re.fullmatch(r'[0-9]{2}-[a-z0-9-]+', sys.argv[1])
ready = json.loads((work / 'visible-current-api-ready-v1.json').read_text())
publication = json.loads((work / 'native-frame-reader-publication-v1.json').read_text())
binary = work / 'native-frame-reader/bin/Release/net10.0'
assert all(hashlib.sha256((binary / p).read_bytes()).hexdigest() == h for p, h in publication['runtimeHashes'].items())
target = work / 'native-visible-v1' / (sys.argv[1] + '.json.gz')
log = target.parent / (sys.argv[1] + '-reader.json')
assert not target.exists() and not log.exists()
with log.open('xb') as stream:
    subprocess.run(['/Users/dinghaolin/.dotnet/dotnet', str(binary / 'probe.dll'), 'native-frame', ready['room'], str(target)],
                   cwd=work, env=dict(os.environ, RIFTBOUND_FIXED_ACCEPTANCE_ROOT=str(work),
                   ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit'),
                   stdout=stream, stderr=subprocess.STDOUT, check=True, timeout=90)
receipt = json.loads(log.read_text())
assert receipt['actualRuleInputs'] == ready['actualRuleInputs']
print(receipt['status'], receipt['room'], receipt['commands'], receipt['events'], receipt['stateHash'])
