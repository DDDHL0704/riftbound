import datetime,hashlib,json,os,pathlib,plistlib,subprocess,sys
work=pathlib.Path(__file__).resolve().parent;root=work.parents[2]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(path,value):
 with path.open('x') as stream:stream.write(json.dumps(value,indent=2)+'\n')
def observe_lock():
 raw=plistlib.loads(subprocess.check_output(['/usr/sbin/ioreg','-n','Root','-d','1','-a']))
 return {'atUtc':now(),'roots':[{'rootLocked':x.get('IOConsoleLocked'),'sessions':[s['CGSSessionScreenIsLocked'] for s in x.get('IOConsoleUsers',[]) if 'CGSSessionScreenIsLocked' in s]} for x in (raw if isinstance(raw,list) else [raw])],'missingValuesUnknown':True}
focus=json.loads((work/'current32-including-eight-ordinary-focus-verification-v1.json').read_text())
assert focus['cases']==32 and focus['allOutcomesPassed'] and len(focus['ordinaryPassedCases'])==8
source_runtime=root/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0'
assert sha(source_runtime/'Riftbound.Engine.dll')==focus['engineModuleSha256']=='653ba2efd6dad59f5489ea7b8e48053ff494b3b1b682156ecd52641399b00f30'
sql=json.loads((work/'frozen-sql-publication-inputs-v2.json').read_text())
assert all(sha(root/p)==h for p,h in sql['sourceInputHashes'].items())
assert not (work/'only-check').exists()
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','--','src','clients/godot','tests','scripts','.github','data','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json','NuGet.Config'],cwd=root,text=True).splitlines()
inputs={p:sha(root/p) for p in sorted(set(paths)) if (root/p).is_file() and not {'bin','obj','.godot'}&set(pathlib.Path(p).parts)}
assert inputs==sql['sourceInputHashes'] and len(inputs)==3308
runtime={str(p.relative_to(root)):sha(p) for p in sorted(source_runtime.rglob('*')) if p.is_file() and (p.suffix in {'.dll','.pdb'} or p.name.endswith(('.deps.json','.runtimeconfig.json')) or p.is_relative_to(source_runtime/'data') or p.is_relative_to(source_runtime/'Fixtures'))}
start={'recordedAtUtc':now(),'parentCommit':'48e7ff8702dc43a1b5a3991365d87068506ae137','sourceInputHashes':inputs,'actualConformanceRuntimeFileHashes':runtime,'sourceInputCount':len(inputs),'actualConformanceRuntimeFileCount':len(runtime),'onlyOneCheckForThisBatch':True,'prior32CasesAndBothAffectedOriginalFullGamesPassed':True,'actualSqlFrozenSeparateRuntime':True,'localSqlAndNewFixedFullNativeWindowsSeparate':True,'lockAtStart':observe_lock()}
write(work/'only-check-start-inputs-v1.json',start)
power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
code=None
try:
 env=dict(os.environ);env.pop('ConnectionStrings__Riftbound',None)
 with (work/'only-check-runner-v1.log').open('x') as log:
  code=subprocess.run(['python3',str(root/'scripts/test-rules.py'),'check','--jobs','3','--output',str(work/'only-check')],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
finally:
 if power.poll() is None:power.terminate();power.wait(timeout=10)
 source_changes=[p for p,h in inputs.items() if not (root/p).is_file() or sha(root/p)!=h]
 runtime_changes=[p for p,h in runtime.items() if not (root/p).is_file() or sha(root/p)!=h]
 write(work/'only-check-terminal-integrity-v1.json',{'finishedAtUtc':now(),'checkExitCode':code,'inputManifestSha256':sha(work/'only-check-start-inputs-v1.json'),'changedSourceInputs':source_changes,'changedConformanceRuntimeFiles':runtime_changes,'allDeclaredInputsAndRuntimeFilesStable':not source_changes and not runtime_changes,'lockAtEnd':observe_lock(),'boundIdleSleepAssertionEnded':power.poll() is not None,'noSecondCheck':True})
assert not source_changes and not runtime_changes
print('SOLE_CHECK_FINISHED_WITH_STABLE_INPUTS_AND_RUNTIME_EXIT_'+str(code),flush=True)
sys.exit(code if code is not None else 1)
