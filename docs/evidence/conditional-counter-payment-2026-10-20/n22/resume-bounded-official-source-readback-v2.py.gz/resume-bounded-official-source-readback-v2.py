import datetime
import gzip
import hashlib
import json
from pathlib import Path
import urllib.parse
import urllib.request

work = Path(__file__).resolve().parent
root = work.parents[2]
original = work / 'bounded-current-official-source-readback-v1.json'
manifest = json.loads(original.read_text())
assert manifest['errorType'] == 'UnicodeEncodeError'
assert [r['label'] for r in manifest['records']] == ['exact-printing-name-complete-response', 'complete-current-rules-directory', 'DOC-01']
manifest['originalV1RequestPathEncodingFailure'] = {'manifest': str(original.relative_to(root)),
    'sha256': hashlib.sha256(original.read_bytes()).hexdigest(), 'errorType': manifest.pop('errorType'),
    'errorMessage': manifest.pop('errorMessage'), 'scope': 'Chinese URL path not percent-encoded; DOC13 HTTP request never sent. Completed card/directory/core receipts retained and not reacquired.'}
manifest['resumeStartedAtUtc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
out = work / 'bounded-current-official-source-readback-v2.json'
assert not out.exists()

def fetch(label, url):
    parts = urllib.parse.urlsplit(url)
    encoded = urllib.parse.urlunsplit((parts.scheme, parts.netloc, urllib.parse.quote(parts.path, safe='/%'), parts.query, parts.fragment))
    started = now()
    with urllib.request.urlopen(urllib.request.Request(encoded, headers={'User-Agent': 'RiftboundRulesAudit/1.0'}), timeout=60) as response:
        raw = response.read()
        record = {'label': label, 'url': url, 'encodedRequestUrl': encoded, 'resolvedUrl': response.url,
                  'requestedAtUtc': started, 'receivedAtUtc': now(), 'httpStatus': response.status,
                  'httpDate': response.headers.get('Date'), 'contentType': response.headers.get('Content-Type'),
                  'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'region': 'CN', 'language': 'zh-CN'}
    manifest['records'].append(record)
    return raw, record

try:
    source = next(s for s in json.loads((root / 'data/official/rule-input-scope.json').read_text())['adoptedSources'] if s['id'] == 'DOC-13')
    raw, record = fetch('DOC-13', source['url'])
    previous = root / 'var/qa/cn-effective-20261016/whole-rule-source-readback/CN/DOC-13.pdf'
    record.update(expectedAdoptedSha256=source['sha256'], versionDate=source['versionDate'], effectiveDate=source.get('effectiveDate'),
                  unchanged=hashlib.sha256(raw).hexdigest() == source['sha256'], existingOriginalPdf=str(previous.relative_to(root)),
                  existingOriginalPdfSha256=hashlib.sha256(previous.read_bytes()).hexdigest())
    if not record['unchanged']:
        target = work / 'DOC-13-new-source-version.pdf'
        target.write_bytes(raw)
        record['newSourceVersionRetainedNotAdopted'] = str(target.relative_to(root))
    else:
        assert raw == previous.read_bytes()
        record['sameOriginalPdfReusedNoDuplicateSeventeenMbDownloadRetained'] = True
    card = json.loads(gzip.decompress((work / 'current-card-name-complete-response-v1.json.gz').read_bytes()))['result']['list'][0]
    raw, record = fetch('actual-current-exact-card-face', card['frontImage'])
    target = work / 'current-exact-sfd136-card-face.png'
    assert not target.exists()
    target.write_bytes(raw)
    record.update(actualImage=str(target.relative_to(root)), exactApiId=33226, exactRawCardNo=card['cardNo'], cardFaceNotYetVisuallyInspected=True)
    assert all(r.get('allReturnedRawRowsExactToPriorSource', True) and r.get('entireResultExactToPriorDirectory', True)
               and r.get('unchanged', True) for r in manifest['records'])
    manifest.update(status='PASS_BOUNDED_CURRENT_PRIMARY_SOURCES_UNCHANGED_VISUAL_AND_SEMANTIC_REVIEW_PENDING',
                    allPriorSourceVersionsAndSixDeltasPreserved=True)
except BaseException as error:
    manifest.update(status='RESUME_FAILED_OR_CHANGED_SOURCE_REQUIRES_SEPARATE_INTAKE', errorType=type(error).__name__, errorMessage=str(error))
    raise
finally:
    manifest['finishedAtUtc'] = now()
    out.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print(manifest['status'], 'five exact current official source identities', flush=True)
