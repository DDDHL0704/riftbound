import ast
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import plistlib
import subprocess

os.umask(0o077)
work = Path(__file__).resolve().parent
root = work.parents[2]
runtime = work / 'sql-runtime'
pg = Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin')
cluster = root / 'var/qa/permanent-play-here-base-20261017/postgres'
sock = Path('/tmp/rft-here-family-20261018-55486')
dotnet = '/Users/dinghaolin/.dotnet/dotnet'
tables = ['matches', 'match_players', 'command_log', 'game_events', 'state_snapshots', 'snapshots', 'action_prompts']
read_env = dict(os.environ, PGOPTIONS='-c default_transaction_read_only=on')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
publication_path = work / 'frozen-sql-publication-inputs-v1.json'
publication = json.loads(publication_path.read_text())
output = work / 'real-sql-verification-v1.json'
assert not output.exists()
guard_source = work.parent / 'graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes = [n for n in ast.parse(guard_source.read_text()).body if isinstance(n, ast.FunctionDef)
         and n.name in {'query', 'rooms', 'digests', 'observe_lock'}]
assert len(nodes) == 4
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(guard_source), 'exec'), globals())

def write(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)

def frozen():
    assert all(sha(runtime / p) == h for p, h in publication['runtimeFiles'].items())
    assert all(sha(root / p) == h for p, h in publication['sourceInputHashes'].items())
    assert all(sha(work / p) == h for p, h in publication['readerSourceHashes'].items())
    assert json.loads(subprocess.check_output(publication['readerCommand'] + ['identity-print'], cwd=runtime, text=True)) == publication['actualRuleInputs']

frozen()
guard = (root / 'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a')
fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
proof = {'status': 'RUNNING_NOT_ACCEPTANCE', 'startedAtUtc': now(), 'baseCommit': publication['baseCommit'],
         'includesUncommittedImplementation': True, 'actualRuleInputs': publication['actualRuleInputs'],
         'publicationSha256': sha(publication_path), 'runnerSourceSha256': sha(Path(__file__)),
         'guardFunctionSourceSha256': sha(guard_source), 'lockAtStart': observe_lock(),
         'scope': 'Eight new ordinary conditional-counter branches; actual dispatcher partition45of46, not full SQL or fixed CI acceptance.',
         'visibleNativeAndPhysicalWindows': 'OPEN', 'notAFixed48Binary': True}
write(output, proof)
started = False
power = process = None
audit = native = None
try:
    assert subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), 'status'], capture_output=True).returncode == 3
    power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())])
    proof.update(ownRunnerPid=os.getpid(), boundIdleSleepAssertionPid=power.pid)
    sock.mkdir(exist_ok=True)
    subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-l', str(work / 'own-postgres-v1.log'),
                    '-o', f'-p 55486 -h 127.0.0.1 -k {sock}', '-w', 'start'], check=True, capture_output=True)
    started = True
    audit = rooms('riftbound_acceptance'); native = rooms('riftbound_here_native')
    assert len(audit) == 192 and len(native) == 41, 'Reconcile actual original room baseline before writing.'
    before_audit = digests('riftbound_acceptance', audit)
    before_native = digests('riftbound_here_native', native)
    baseline = {'atUtc': now(), 'auditRooms': audit, 'nativeRooms': native,
                'auditSevenTables': before_audit, 'nativeSevenTables': before_native,
                'originalDatabaseRetained': True, 'actualPostgresVersion': query('riftbound_acceptance', 'select version()')}
    write(work / 'before-192-audit-41-native-sql-baseline-v1.json', baseline)
    proof.update(originalAuditRoomCount=192, originalNativeRoomCount=41)
    write(output, proof)
    evidence = work / 'actual-sql-partition-v1'
    env = dict(os.environ, ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit',
               RIFTBOUND_POSTGRES_EVIDENCE=str(evidence))
    env.pop('GITHUB_SHA', None)

    def run(arguments, filename):
        global process
        with (work / filename).open('x') as log:
            process = subprocess.Popen(arguments, cwd=runtime, env=env, stdout=log, stderr=subprocess.STDOUT)
            proof['ownAcceptancePid'] = process.pid; write(output, proof)
            code = process.wait(timeout=5400)
        assert code == 0, (code, filename)

    run([dotnet, str(runtime / 'Riftbound.PostgresAcceptance.dll'), '--ci-partition', '45', '46'], 'actual-sql-writer-v1.log')
    partition_path = evidence / 'partition-receipt.json'
    partition = json.loads(partition_path.read_text())
    assert partition['status'] == 'REAL_POSTGRES_PARTITION_COMPLETE' and partition['fixedCommit'] is None
    assert partition['partitionIndex'] == 45 and partition['partitionCount'] == 46
    assert len(partition['orderedDefaultCases']) == 46 and partition['expectedCases'] == partition['completedCases'] == ['conditional-counter-payment']
    assert partition['actualRuleInputs'] == publication['actualRuleInputs']
    for item in partition['runtimeAssemblies']:
        assert publication['runtimeFiles'][item['file']] == item['sha256']
    for item in partition['outputFiles']:
        path = evidence / item['path']
        assert path.stat().st_size == item['bytes'] and sha(path) == item['sha256']
    folder = evidence / 'conditional-counter-payment'
    receipt_path = folder / 'receipt.json'
    receipt = json.loads(receipt_path.read_text()); rows = receipt['results']
    assert receipt['status'] == 'REAL_POSTGRES_ORIGINAL_CONDITIONAL_COUNTER_EIGHT_BRANCHES_COLD_REPLAY_PASS'
    assert len(rows) == 8 and {(x['format'], x['profile']) for x in rows} == {
        (f, p) for f in ['CoreRules', 'ChinaStandard20260724'] for p in ['BASE_PAY', 'BASE_DECLINE', 'ECHO_PAY_BOTH', 'ECHO_PAY_THEN_DECLINE']}
    assert all(x['originalOpeningCommands'] == 32 and x['originalBlankSeed'] == 0
               and x['actualRuleInputs'] == publication['actualRuleInputs'] and x['originalFullReplayMatched']
               and x['bothOriginalPrivateViewsAndPromptsExact'] and x['noStateSeedOrAcceptedHistoryInjection']
               and x['atomicRejections'] == (8 if x['profile'].startswith('ECHO_') else 4) for x in rows)
    current = rooms('riftbound_acceptance'); added = sorted(set(current) - set(audit))
    assert len(current) == 200 and added == sorted(x['room'] for x in rows)
    assert rooms('riftbound_here_native') == native
    assert digests('riftbound_acceptance', audit) == before_audit and digests('riftbound_here_native', native) == before_native
    before_read = digests('riftbound_acceptance', current)
    write(work / 'after-eight-writers-before-readonly-baseline-v1.json', {
        'atUtc': now(), 'auditRooms': current, 'nativeRooms': native, 'auditSevenTables': before_read,
        'nativeSevenTables': before_native, 'newOriginalRooms': added, 'originalPartitionReceiptSha256': sha(partition_path)})
    proof.update(writerComplete=True, originalEightRooms=added, originalPartitionReceiptSha256=sha(partition_path))
    write(output, proof)
    run(publication['readerCommand'] + ['independent-readonly', str(folder)], 'independent-actual-sql-reader-v1.log')
    reader = json.loads((work / 'independent-actual-sql-reader-v1.log').read_text())
    assert reader['status'] == 'PASS_INDEPENDENT_READONLY_REAL_POSTGRES_EIGHT_CONDITIONAL_COUNTER_ORIGINALS'
    assert len(reader['checks']) == 8 and reader['actualRuleInputs'] == publication['actualRuleInputs']
    assert rooms('riftbound_acceptance') == current and rooms('riftbound_here_native') == native
    assert digests('riftbound_acceptance', current) == before_read and digests('riftbound_here_native', native) == before_native
    write(work / 'independent-actual-sql-readonly-result-v1.json', reader)
    proof.update(status='PASS_REAL_SQL_EIGHT_ORIGINAL_CONDITIONAL_COUNTER_BRANCHES_AND_INDEPENDENT_READONLY_FULL_REPLAY',
                 branches=8, commands=sum(x['commands'] for x in rows), events=sum(x['events'] for x in rows),
                 coldRestores=sum(x['coldRestores'] for x in rows), originalNextCommandsMatched=sum(x['originalNextCommandsMatched'] for x in rows),
                 atomicRejections=sum(x['atomicRejections'] for x in rows), originalReceiptSha256=sha(receipt_path),
                 allOriginal192AuditAnd41NativeSevenTablesExact=True, independentAll200AuditAnd41NativeSevenTablesUnchanged=True,
                 originalNewRoomSevenTables=digests('riftbound_acceptance', added),
                 originalFrameHashes={p.name: sha(p) for p in folder.glob('*.json.gz')})
except BaseException as error:
    proof.update(status='FAILED_OR_INTERRUPTED_ORIGINAL_HISTORY_RETAINED', errorType=type(error).__name__, errorMessage=str(error))
    raise
finally:
    if process is not None and process.poll() is None:
        process.terminate(); process.wait(timeout=30)
    if started:
        if audit is not None and 'before_audit' in globals():
            proof['allPriorAuditSevenTablesStillExactAtStop'] = digests('riftbound_acceptance', audit) == before_audit
            proof['allPriorNativeSevenTablesStillExactAtStop'] = digests('riftbound_here_native', native) == before_native
        proof['ownPostgresSmartStopped'] = subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-m', 'smart', '-w', '-t', '20', 'stop'], capture_output=True).returncode == 0
    if power is not None:
        if power.poll() is None:
            power.terminate(); power.wait(timeout=10)
        proof['boundIdleSleepAssertionEnded'] = power.poll() is not None
    frozen()
    proof.update(finishedAtUtc=now(), lockAtEnd=observe_lock(), all3308Sources89FrozenRuntimeAndReaderSourcesExact=True,
                 originalDatabaseRetained=cluster.exists())
    write(output, proof)
    fcntl.flock(guard, fcntl.LOCK_UN)
print(proof['status'], flush=True)
