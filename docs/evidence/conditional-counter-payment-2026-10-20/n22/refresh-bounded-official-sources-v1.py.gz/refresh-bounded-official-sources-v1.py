import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import urllib.request

os.umask(0o077)
work = Path(__file__).resolve().parent
root = work.parents[2]
previous = root / 'var/qa/typed-stack-consumer-source-readback-20261020'
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
hash_bytes = lambda b: hashlib.sha256(b).hexdigest()
canonical = lambda obj: json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
manifest = {'startedAtUtc': now(), 'region': 'CN', 'language': 'zh-CN', 'applicabilityDate': '2026-10-20',
            'adoptedCoreEffectiveDate': '2026-10-16', 'exactPrinting': 'SFD·136/221', 'exactApiId': 33226,
            'parentWholePrintingObligationId': 'CARD:SFD-136/221', 'singlePrintingPublishedAt': None,
            'singlePrintingEffectiveAtIndependentlyVerified': None, 'records': [],
            'wholeCardOrFamilyCertification': False, 'noRuntimeCatalogAuthorityAdoption': True}
out = work / 'bounded-current-official-source-readback-v1.json'
assert not out.exists()

def fetch(label, url, payload=None):
    started = now()
    request = urllib.request.Request(url, data=None if payload is None else json.dumps(payload, ensure_ascii=False).encode(),
                                     headers={'User-Agent': 'RiftboundRulesAudit/1.0', 'Accept': '*/*',
                                              **({'Content-Type': 'application/json'} if payload is not None else {})})
    with urllib.request.urlopen(request, timeout=60) as response:
        raw = response.read()
        record = {'label': label, 'url': url, 'resolvedUrl': response.url, 'requestedAtUtc': started,
                  'receivedAtUtc': now(), 'httpStatus': response.status, 'httpDate': response.headers.get('Date'),
                  'contentType': response.headers.get('Content-Type'), 'bytes': len(raw), 'sha256': hash_bytes(raw),
                  'region': 'CN', 'language': 'zh-CN'}
    if payload is not None:
        record['request'] = payload
    manifest['records'].append(record)
    return raw, record

try:
    payload = {'pageNum': 1, 'pageSize': 100, 'searchContent': '强买强卖', 'cardCategoryList': [],
               'cardColorList': [], 'rarityList': [], 'productCodeList': []}
    raw, record = fetch('exact-printing-name-complete-response', 'https://lol-api.playloltcg.com/xcx/card/searchCardCraftWeb', payload)
    target = work / 'current-card-name-complete-response-v1.json.gz'
    target.write_bytes(gzip.compress(raw, mtime=0))
    record['completeResponse'] = str(target.relative_to(root))
    response = json.loads(raw)
    assert response['code'] == 0 and response['result']['total'] == len(response['result']['list']) == 1
    card = response['result']['list'][0]
    old = json.loads(gzip.decompress((previous / 'card-name-05-complete-response-v1.json.gz').read_bytes()))['result']['list'][0]
    assert card['id'] == 33226 and card['cardNo'] == 'SFD·136/221'
    record.update(allReturnedRawRowsExactToPriorSource=card == old, canonicalWholeRowSha256=hash_bytes(canonical(card)),
                  independentlyRetainedPriorCompleteResponseSha256=hash_bytes(gzip.decompress((previous / 'card-name-05-complete-response-v1.json.gz').read_bytes())))
    raw, record = fetch('complete-current-rules-directory', 'https://lol-api.playloltcg.com/xcx/gameRule/getGameRuleList', {'pageNum': 1, 'pageSize': 1000})
    target = work / 'current-rules-directory-complete-response-v1.json.gz'
    target.write_bytes(gzip.compress(raw, mtime=0))
    record['completeResponse'] = str(target.relative_to(root))
    directory = json.loads(raw)
    previous_directory = json.loads(gzip.decompress((previous / 'rules-directory-complete-response-v1.json.gz').read_bytes()))
    assert directory['code'] == 0
    record.update(entireResultExactToPriorDirectory=directory['result'] == previous_directory['result'])
    sources = json.loads((root / 'data/official/rule-input-scope.json').read_text())['adoptedSources']
    for source_id in ['DOC-01', 'DOC-13']:
        source = next(s for s in sources if s['id'] == source_id)
        raw, record = fetch(source_id, source['url'])
        old_pdf = root / 'var/qa/cn-effective-20261016/whole-rule-source-readback/CN' / (source_id + '.pdf')
        record.update(expectedAdoptedSha256=source['sha256'], versionDate=source['versionDate'],
                      effectiveDate=source.get('effectiveDate'), unchanged=hash_bytes(raw) == source['sha256'],
                      existingOriginalPdf=str(old_pdf.relative_to(root)), existingOriginalPdfSha256=hash_bytes(old_pdf.read_bytes()))
        if record['unchanged']:
            assert hash_bytes(old_pdf.read_bytes()) == hash_bytes(raw)
            record['sameOriginalPdfReusedNoDuplicateFortyMbDownloadRetained'] = True
        else:
            changed = work / (source_id + '-new-source-version.pdf')
            changed.write_bytes(raw)
            record['newSourceVersionRetainedNotAdopted'] = str(changed.relative_to(root))
    raw, record = fetch('actual-current-exact-card-face', card['frontImage'])
    image = work / 'current-exact-sfd136-card-face.png'
    image.write_bytes(raw)
    record.update(actualImage=str(image.relative_to(root)), exactApiId=33226, exactRawCardNo=card['cardNo'],
                  cardFaceNotYetVisuallyInspected=True)
    assert all(r.get('allReturnedRawRowsExactToPriorSource', True) and r.get('entireResultExactToPriorDirectory', True)
               and r.get('unchanged', True) for r in manifest['records'])
    manifest.update(status='PASS_BOUNDED_CURRENT_PRIMARY_SOURCES_UNCHANGED_VISUAL_AND_SEMANTIC_REVIEW_PENDING',
                    allPriorSourceVersionsAndSixDeltasPreserved=True)
except BaseException as error:
    manifest.update(status='SOURCE_READBACK_FAILED_OR_VERSION_CHANGE_REQUIRES_SEPARATE_INTAKE',
                    errorType=type(error).__name__, errorMessage=str(error))
    raise
finally:
    manifest['finishedAtUtc'] = now()
    out.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print(manifest['status'], 'exact API33226/SFD136', len(manifest['records']), flush=True)
