import copy
import datetime
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import zipfile

work = Path(__file__).resolve().parent
root = work.parents[2]
fixed = root / 'var/qa/native-offline-deck-retry-fixed-48e7ff87-20261020'
previous = root / 'var/qa/native-offline-deck-retry-20261020'
evidence = root / 'docs/evidence/conditional-counter-payment-2026-10-20'
identity = 'conditional-counter-target-controller-mana-and-printed-echo-2026-10-20'
base = '48e7ff8702dc43a1b5a3991365d87068506ae137'
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def pin(path, role=None):
    return {'path': str(path.relative_to(root)), 'sha256': sha(path), 'role': role or path.stem}


assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == base
assert not evidence.exists()
check = load(work / 'only-check-retention-and-disposition-v1.json')
assert check['totalCases'] == check['passed'] == 13139 and check['failed'] == check['skipped'] == 0
assert check['allOriginalCaseMultisetAndMethodsRetained'] and check['allSourceAndRuntimeInputsStableThroughTerminal']
focus = load(work / 'post-wording-current35-focus-independent-readback-v1.json')
assert focus['cases'] == 35 and focus['methods'] == 14 and focus['allActualOutcomesPassed']
sql = load(work / 'real-sql-verification-v3.json')
assert sql['status'] == 'PASS_REAL_SQL_EIGHT_ORIGINAL_CONDITIONAL_COUNTER_BRANCHES_AND_INDEPENDENT_READONLY_FULL_REPLAY'
assert sql['branches'] == 8 and sql['commands'] == 316 and sql['events'] == 1312
assert sql['ownPostgresSmartStopped'] and sql['boundIdleSleepAssertionEnded']
assert sql['allOriginal201AuditAnd42NativeSevenTablesExact'] and sql['independentAll209AuditAnd42NativeSevenTablesUnchanged']
publication = load(work / 'frozen-sql-publication-inputs-v3.json')
assert all(sha(root / p) == h for p, h in publication['sourceInputHashes'].items())
assert all(sha(work / 'sql-runtime-v3' / p) == h for p, h in publication['runtimeFiles'].items())
assert sql['actualRuleInputs'] == publication['actualRuleInputs']
native = load(work / 'native-current-source-audit-closure-v1.json')
assert native['acceptedCommands'] == 71 and native['events'] == 452 and native['actualNativeButtonCommands'] == 4
assert native['ownApiGracefulExitCode'] == 0 and native['ownPostgresSmartStopped']
matrix = load(work / 'bounded-five-branch-case-matrix-v1.json')
assert len(matrix['branches']) == 5 and len(matrix['actualCases']) == 32
manifest_path = root / 'docs/audit/current-manifest.json'
reviews_path = root / 'docs/evidence/rules-reaudit-2026-10-11/review-decisions.json'
prior, old_reviews = load(manifest_path), load(reviews_path)
assert len(prior['reviewContexts']) == 59 and len(prior['acceptanceGates']) == 237 and len(old_reviews['reviews']) == 144
prior_ids = set(load(root / 'docs/evidence/native-offline-deck-retry-2026-10-20/remaining-obligation-ids.json'))
assert len(prior_ids) == 16911
for path, name in [(manifest_path, 'prior-original-current-manifest.json.gz'),
                   (reviews_path, 'prior-original-review-decisions.json.gz')]:
    target = work / name
    assert not target.exists()
    target.write_bytes(gzip.compress(path.read_bytes(), mtime=0))

# Re-scan the actual terminal bytes. Never publish a RUNNING receipt or a private auth profile.
profiles = [fixed / 'session-a.json', fixed / 'session-b.json',
            work / 'actual-native-payment-prefix-v1/session-native-a.json',
            work / 'actual-native-payment-prefix-v1/session-native-b.json']
secrets = [load(path)[key].encode() for path in profiles for key in ['playerKey', 'reconnectToken']]
assert len(secrets) == 8 and all(len(value) > 10 for value in secrets)
raw = {'.json', '.jsonl', '.ndjson', '.gz', '.zip', '.png', '.jpg', '.jpeg', '.webp'}
text = {'.py', '.cs', '.csproj', '.trx', '.log', '.md', '.c', '.txt', '.yml', '.yaml'}
excluded_dirs = {'bin', 'obj', '__pycache__', 'sql-runtime', 'sql-runtime-v2', 'sql-runtime-v3',
                 'native-current-api-capsule', 'fixed-api', 'native-current'}
archive = []


def archive_file(path, group, directory):
    relative = path.relative_to(directory)
    if (any(part in excluded_dirs or part.endswith('.app') for part in relative.parts)
            or path in profiles or path.name.endswith(('.deps.json', '.runtimeconfig.json'))
            or path.name in {'current-core-complete-layout-text-v1.txt.gz', 'canonical-archive-precheck-v1.json'}
            or path.suffix not in raw | text):
        return
    original = path.read_bytes()
    if path.suffix == '.gz':
        blocks = [gzip.decompress(original)]
    elif path.suffix == '.zip':
        with zipfile.ZipFile(path) as zipped:
            assert zipped.testzip() is None
            blocks = [zipped.read(name) for name in zipped.namelist() if not name.endswith('/')]
    else:
        blocks = [original]
    assert not any(value in block for value in secrets for block in blocks), str(relative)
    compressed = path.suffix in text
    target = evidence / group / relative
    if compressed:
        target = target.with_name(target.name + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    assert not target.exists()
    if compressed:
        target.write_bytes(gzip.compress(original, mtime=0))
    else:
        os.link(path, target)
    assert (gzip.decompress(target.read_bytes()) if compressed else target.read_bytes()) == original
    assert target.stat().st_size < 10 * 2**20
    archive.append({'originalPath': str(path.relative_to(root)), 'originalSha256': sha(path),
                    'originalBytes': len(original), 'canonical': pin(target), 'gzipOriginalBytes': compressed,
                    'samePhysicalFileHardlinked': not compressed})


for directory, group in [(work, 'n22'), (fixed, 'fixed48')]:
    for path in sorted(directory.rglob('*')):
        if path.is_file():
            archive_file(path, group, directory)
for name in ['nine-a-full-ci-terminal-independent-original-readback-v1.json',
             'verify-nine-a-terminal-original-ci-v1.py', 'nine-a-terminal-jobs-v1.json', 'nine-a-terminal-artifacts-v1.json']:
    archive_file(previous / name, 'prior9a', previous)
existing = {sha(path) for path in (root / 'docs/evidence/native-offline-deck-retry-2026-10-20').rglob('*') if path.is_file()}
for path in sorted((previous / 'ci-originals').glob('39352144607-*.zip')):
    if sha(path) not in existing:
        archive_file(path, 'prior9a', previous)
write(evidence / 'archive-map.json', {'records': archive, 'originalBytesAndHashesVerified': True,
      'allEightPrivateProfileValuesScannedWithoutDisclosure': True, 'fourPrivateAuthProfilesExcluded': True,
      'installPackagesRuntimeSdkDatabaseAndUnneededExtractionCacheExcluded': True,
      'sourceSnapshotsFailuresOriginalTraceTrxAndRequiredFrozenRuntimeRetained': True})


def archived(name, role=None, group='n22'):
    return pin(evidence / group / name, role)


source_pin = archived('bounded-current-official-source-readback-v2.json', 'current-official-source-readback')
visual_pin = archived('current-source-exact-visual-semantic-scope-v2.json', 'exact-current-source-visual-review')
check_pin = archived('only-check-retention-and-disposition-v1.json', 'historical-sole-check13139')
focus_pin = archived('post-wording-current35-focus-independent-readback-v1.json', 'current-post-wording-focus35')
sql_pin = archived('real-sql-verification-v3.json', 'current-release-eight-real-sql-and-independent-replay')
reader_pin = archived('independent-actual-sql-readonly-result-v3.json', 'current-real-sql-independent-original-reader')
native_pin = archived('native-current-source-audit-closure-v1.json', 'pre-wording-mixed-version-native-source-audit')
wording_pin = archived('post-sole-check-native-wording-source-change-v1.json', 'two-post-check-presentation-source-corrections')
matrix_pin = archived('bounded-five-branch-case-matrix-v1.json', 'bounded-actual32-case-five-branch-matrix')
retention_pin = archived('original1859-tests-tools-five-command-fixture-and-nine-fullgames-retention-v2.json', 'all-original-tests-fixture-fullgames-retained')
security_pin = archived('native-signalr-current-artifact-dependency-version-finding-v1.json', 'separate-native-dependency-finding')
fixed_rules_pin = archived('current48-original-rules13256-and-sql3-independent-readback-v1.json', 'fixed48-original-rules-and-sql3', 'fixed48')
fixed_native_paths = list((evidence / 'fixed48/native-visible-v1').glob('*acceptance*.json'))
assert len(fixed_native_paths) == 1
fixed_native_pin = pin(fixed_native_paths[0], 'preceding-fixed48-visible-native-score-and-replay')
fixed_offline_pin = archived('actual-default-main-offline-retry-owner-v1.json', 'fixed48-real-default-main-offline-retry', 'fixed48')
fixed_network_pin = archived('current48-original-network-content-independent-readback-v1.json', 'fixed48-original-native-network', 'fixed48')
prior_full_pin = archived('nine-a-full-ci-terminal-independent-original-readback-v1.json', 'prior9a-original-full-ci-terminal', 'prior9a')
impl = ['src/Riftbound.Engine/CardBehaviorRegistry.cs', 'src/Riftbound.Engine/CoreRuleEngine.cs',
        'src/Riftbound.Engine/CoreRuleEngine.Repeats.cs', 'src/Riftbound.Engine/CoreRuleEngine.ConditionalCounterPayment.cs',
        'src/Riftbound.Engine/MatchSession.cs', 'clients/godot/scripts/ui/MatchPhasePresentation.cs']
verification = ['tests/Riftbound.ConformanceTests/ConditionalCounterPaymentTests.cs',
    'tests/Riftbound.ConformanceTests/ConditionalCounterPaymentOpeningTests.cs',
    'tests/Riftbound.ConformanceTests/ConformanceFixtureRunnerTests.cs',
    'tests/Riftbound.ConformanceTests/ConformanceFixtureShapeTests.cs',
    'tests/Riftbound.ConformanceTests/Fixtures/conditional-counter-openings.json',
    'tests/Riftbound.ConformanceTests/Fixtures/p2-preflight-play-hard-bargain-counter-spell-decline-pay.fixture.json',
    'tests/Riftbound.PostgresAcceptance/ConditionalCounterPaymentSqlAcceptance.cs',
    'tests/Riftbound.PostgresAcceptance/Program.cs', 'tests/Riftbound.PostgresAcceptance/Riftbound.PostgresAcceptance.csproj',
    'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json', 'scripts/tests/test_sql_ci_gate.py']
payment_refs = ['CN-d6fd7140f106f9b5-P089-B016', 'CN-d6fd7140f106f9b5-P089-B017',
                'CN-d6fd7140f106f9b5-P089-B018', 'CN-d6fd7140f106f9b5-P089-B019',
                'CN-d6fd7140f106f9b5-P110-B018', 'CN-d6fd7140f106f9b5-P110-B019', 'CN-d6fd7140f106f9b5-P110-B020']
echo_refs = ['CN-d6fd7140f106f9b5-P122-B' + str(i).zfill(3) for i in range(17, 26)]
echo_refs += ['CN-d6fd7140f106f9b5-P123-B' + str(i).zfill(3) for i in range(2, 7)]
refs = ['SFD-136/221'] + payment_refs + echo_refs
source_manifest = {
    'recordedAtUtc': now(), 'region': 'CN', 'language': 'zh-CN', 'applicabilityObservedAt': '2026-10-20',
    'adoptedCoreEffectiveDate': '2026-10-16', 'exactPrinting': 'SFD·136/221', 'exactApiId': 33226,
    'parentWholePrintingObligation': 'CARD:SFD-136/221', 'printingPublishedAt': None, 'printingEffectiveAtIndependentlyVerified': None,
    'scope': 'Conditional target-current-controller two-mana resolution payment, printed Echo and their bounded native wording only.',
    'sourceAuthorityReadback': source_pin, 'sourceVisualSemanticReview': visual_pin, 'exactPrintingAndClauseRefs': refs,
    'baseCommit': base, 'includesUncommittedImplementation': True,
    'implementation': [pin(root / p, 'implementation') for p in impl],
    'verificationSources': [pin(root / p, 'verification') for p in verification],
    'soleCheckHistoricalInputEvidence': check_pin, 'soleCheckIncludesLaterTwoPresentationEdits': False,
    'postCheckPresentationEdits': wording_pin, 'currentFocused35': focus_pin,
    'historicalDebugRuleInputs': check['actualConformanceDebugRuleInputs'],
    'preWordingReleaseRuleInputs': load(work / 'real-sql-verification-v2.json')['actualRuleInputs'],
    'currentActualReleaseRuleInputs': publication['actualRuleInputs'],
    'currentEightActualSqlBranches': sql_pin, 'currentSqlIndependentOriginalReader': reader_pin,
    'preWordingMixedVersionNativeSourceAudit': native_pin, 'sourceAuditNativeClientCommit': base,
    'sourceAuditNativeBackendIdentity': native['actualBackendIdentity'],
    'sourceAuditIsCurrentFixedCandidateAcceptance': False, 'currentBehaviorMatrix': matrix_pin,
    'originalTestAndFixtureRetention': retention_pin, 'newSqlIdentity': 'conditional-counter-payment',
    'original45SqlIdsAndOrderRetainedNew46thOnlyAppended': True,
    'precedingFixed48VisibleNative': fixed_native_pin, 'precedingFixed48DefaultOfflineRetry': fixed_offline_pin,
    'precedingFixed48PartialCi': fixed_rules_pin, 'precedingFixed48Network': fixed_network_pin,
    'precedingFixed48CiSql0AndWholeTerminal': 'PENDING_AT_THIS_PUBLICATION_SEE_ORIGINAL_SNAPSHOTS',
    'priorFixedNineAFullCi': prior_full_pin, 'newCandidateFixedFull': 'PENDING_AFTER_COMMIT',
    'currentFixedNativeControlsPairedReconnectNormalScoreReplay': 'OPEN', 'physicalWindows': 'OPEN',
    'separateNativeDependencyFinding': security_pin, 'separateDependencyIssue': 'https://github.com/DDDHL0704/riftbound/issues/73',
    'dependencyFindingIsOfficialGameSourceDelta': False, 'sixOriginalGameSourceDeltasUnchanged': True,
    'sourceUniverseAndAllOriginalGapsRetained': True, 'wholePrintingOrFamilyOrGlobalSemanticsCertified': False,
    'noOldDevelopmentMatchMigrationOrDslExpansion': True,
    'onlyLatestUsableNativePairAndOnePackagePerOs': True, 'noNewGodotSdkWholeCheckoutOrDatabase': True}
write(evidence / 'source-manifest.json', source_manifest)
manifest_pin = pin(evidence / 'source-manifest.json', 'source-manifest')
document_path = root / 'docs/CONDITIONAL_COUNTER_PAYMENT_AUDIT_2026-10-20.md'
assert not document_path.exists()
document = (work / 'conditional-counter-payment-audit-final-draft-v1.md').read_text()
assert '@' not in document
document_path.write_text(document)
reviews = copy.deepcopy(old_reviews)
reviews['reviews'].append({'id': identity, 'scope': source_manifest['scope'] + ' CN/zh-CN, observed2026-10-20, core effective2026-10-16.',
    'status': 'LIMITED32_CURRENT_FOCUS35_HISTORICAL_SOLECHECK13139_SQL8_PASS_NEW_FIXEDFULL_NATIVE_WINDOWS_OPEN',
    'subjects': ['SFD-136/221'], 'ruleRecords': payment_refs + echo_refs, 'pendingRuleRecords': [],
    'sourceManifest': manifest_pin, 'auditDocument': str(document_path.relative_to(root)),
    'validation': {'boundedCurrentCases': 32, 'currentFocusCases': 35, 'soleCheckHistoricalCases': 13139,
                   'ordinaryRealSqlBranches': 8, 'originalFullGamesInCurrentFocus': 2, 'allMeaningfulSourceTestsRetained': True},
    'exclusions': ['WHOLE_PRINTING_AND_OTHER_FAMILY_CONSUMERS', 'CURRENT_FIXED_FULL',
                   'CURRENT_FIXED_NATIVE_CONTROLS_PAIRED_RECONNECT_SCORE_REPLAY', 'PHYSICAL_WINDOWS',
                   'SEPARATE_NATIVE_DEPENDENCY_PATCH_AND_RUNTIME_APPLICABILITY', 'ALL_ORIGINAL_SOURCE_GAPS']})
reviews_path.write_text(json.dumps(reviews, ensure_ascii=False, indent=2) + '\n')
spec = importlib.util.spec_from_file_location('governance', root / 'scripts/audit/check-project-governance.py')
checker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checker)
revision = checker.digest(checker.gameplay_inputs(root))
manifest = copy.deepcopy(prior)
rebindings = []
prior_manifest_pin = archived('prior-original-current-manifest.json.gz', 'prior-entire-current-manifest')
for key, context in manifest['reviewContexts'].items():
    changes = []
    for field in ['implementation', 'verificationSources']:
        for ref in context.get(field, []):
            actual = sha(root / ref['path'])
            if actual != ref['sha256']:
                changes.append({'field': field, 'path': ref['path'], 'previousSha256': ref['sha256'], 'currentSha256': actual})
                ref['sha256'] = actual
    old_metadata = {field: context.get(field) for field in ['currentInputRevision', 'currentImplementationCommit',
                    'currentImplementationIncludesUncommittedChanges', 'ciState']}
    context.setdefault('implementationPinUpdates', []).append({'batch': identity, 'changes': changes,
        'previousCurrentMetadata': old_metadata, 'previousEntireContextPreservedIn': prior_manifest_pin,
        'scope': 'Finite conditional counter and corresponding presentation/source/test changes; original scopes, source versions and evidence retained.'})
    context.update(currentInputRevision=revision, currentImplementationCommit=base,
                   currentImplementationIncludesUncommittedChanges=True, ciState='PENDING',
                   revalidationReason='Conditional target-controller payment and native wording; exact new fixed full/product still required.')
    rebindings.append({'review': key, 'previousEntireContextSha256': checker.digest(prior['reviewContexts'][key]), 'changedPins': changes})
branches = []
scopes = [
    'Normal declaration has no fake mode; actual target spell current controller decides at resolution independently of physical ownership.',
    'Explicit two-mana payment, decline with enough mana, inability and immediate existing rune/reaction-resource actions.',
    'Printed two-mana Echo repeats separate targets/payments, rechecks resources and no longer-live targets; eight original ordinary openings.',
    'Wrong player, stale choice, forged free/multi-choice payment reject atomically; six independently expected recovery mutations reject.',
    'Actual pre-edit native first-pay/second-decline flow exposed phase, action and step wording gaps; current fixed native wording acceptance remains open.']
for index, row in enumerate(matrix['branches']):
    branches.append({'id': row['id'], 'sourceRefs': ['SFD-136/221'] + (echo_refs + payment_refs if index == 2 else payment_refs),
        'sourceManifest': manifest_pin, 'state': 'RECORDED', 'branchScope': scopes[index],
        'decision': {'state': 'OPEN', 'reason': 'Bounded source/implementation/current focus and real SQL only; current fixed full and native/physical product obligations remain.'},
        'semanticReview': 'LIMITED_CURRENT_CN_EXACT_PRINTING_AND_CLAUSES', 'implementation': 'FINITE_SHARED_EXISTING_RULE_CHOICE_FLOW',
        'testExecution': 'CURRENT32_PAYMENT_CASES_PLUS_BOTH_ORIGINAL_FULL_GAMES_AND_SHAPE_PASS' if index != 4 else 'PRE_EDIT_NATIVE_SOURCE_AUDIT_CURRENT_NATIVE_COMPILED_ACCEPTANCE_OPEN',
        'ordinaryRealSql': sql_pin, 'actualTestMatrix': matrix_pin, 'actualCaseKeys': row['caseKeys'],
        'actualMethodNames': row['methodNames'], 'fixedCommitCi': 'PENDING_NEW_FIXED_FULL',
        'productAcceptance': 'OPEN_CURRENT_FIXED_NATIVE_AND_PHYSICAL_WINDOWS', 'wholePrintingCertified': False,
        'remaining': ['NEW_FIXED_FULL_ALL_METHODS_THEORIES143_FULL_METHODS110_PAIRS_SEEDS_AND46_SQL_IDENTITIES',
                      'VISIBLE_CURRENT_FIXED_CONTROLS_PAIRED_SQL_RECONNECT_NORMAL_SCORE_FULL_REPLAY',
                      'PHYSICAL_WINDOWS', 'WHOLE_PRINTING_AND_OTHER_CONSUMERS', 'ALL_SOURCE_VERSION_AND_DATE_GAPS']})
manifest['inputs']['reviews'] = pin(reviews_path, prior['inputs']['reviews'].get('role', 'reviews'))
manifest['reviewContexts'][identity] = {'evidenceCommit': base, 'currentImplementationCommit': base,
    'currentImplementationIncludesUncommittedChanges': True,
    'evidenceCommitScope': 'Base48 plus declared conditional-counter implementation/tests/presentation. Historical sole check63e, pre-wording Release19d and current Release713 are distinct actual identities.',
    'currentInputRevision': revision, 'ciState': 'PENDING', 'ciReceipts': [], 'region': 'CN', 'language': 'zh-CN',
    'applicableAsOf': '2026-10-20', 'adoptedCoreEffectiveDate': '2026-10-16', 'sourceManifest': manifest_pin,
    'implementation': source_manifest['implementation'], 'verificationSources': source_manifest['verificationSources'],
    'evidence': [source_pin, visual_pin, check_pin, focus_pin, sql_pin, reader_pin, native_pin, wording_pin, matrix_pin, retention_pin],
    'branches': branches}
for gate in manifest['acceptanceGates']:
    if gate['id'] == 'NATIVE_OFFLINE_START_SAME_SERVER_DECK_RETRY_NEW_FIXED_NATIVE_FULL_AND_WINDOWS':
        gate['postCommitFixed48BoundedReadback'] = {'fixedCommit': base, 'actualDefaultMainOfflineRetry': fixed_offline_pin,
            'actualVisibleNativeNormalScoreAndOriginalReplay': fixed_native_pin,
            'partialOriginalFixedCi': fixed_rules_pin, 'originalNetwork': fixed_network_pin,
            'wholeFixedCiSql0StillPendingAtPublication': True, 'physicalWindowsStillOpen': True,
            'currentN22ImplementationNotCovered': True, 'allOriginalGateRequirementsRetained': True}
manifest['acceptanceGates'].extend([
    {'id': 'CONDITIONAL_COUNTER_PAYMENT_CURRENT_FIXED_FULL_NATIVE_PAIRED_RECONNECT_SCORE_REPLAY_AND_WINDOWS',
     'state': 'OPEN', 'region': 'CN', 'language': 'zh-CN', 'sourceManifest': manifest_pin,
     'requirement': 'On one new fixed candidate close full original/current suite, all46SQL identities/network, actual native current payment wording and pay/decline/repeat controls, visible paired realDB reconnect, normal score end/full original replay, plus independent physical Windows. Historical/mixed-version source audits do not substitute.',
     'semanticReview': 'BOUNDED_SOURCE_BRANCHES_ONLY', 'implementation': 'CURRENT_SHARED_FLOW_AND_WORDING',
     'testExecution': 'CURRENT_FOCUS35_AND_SQL8_PASS_HISTORICAL_SOLECHECK13139_RETAINED',
     'fixedCommitCi': 'PENDING', 'productAcceptance': 'OPEN', 'wholePrintingCertified': False},
    {'id': 'NATIVE_SIGNALR_COMMON_CVE_2026_70159_ACTUAL_DEPENDENCY_PATCH_RUNTIME_AND_NETWORK_ACCEPTANCE',
     'state': 'OPEN', 'region': 'CROSS_PLATFORM', 'sourceManifest': security_pin,
     'requirement': 'Independently resolve actual native Common8.0.0 affected-version finding against publisher GHSA-334f-vvp4-7g6p, runtime/server/stateful-reconnect applicability and an appropriate patched dependency. Do not suppress audit. Require fixed artifact dependency readback, original auth/hidden-information negative guards, normal real reconnect and current native/Windows acceptance. No blanket exploit or immunity claim.',
     'issue': 'https://github.com/DDDHL0704/riftbound/issues/73', 'semanticReview': 'SEPARATE_SOFTWARE_DEPENDENCY_NOT_OFFICIAL_GAME_SOURCE',
     'implementation': 'OPEN', 'testExecution': 'EXACT_MAC_AND_WINDOWS_DEPENDENCY_VERSIONS_AND_PRIMARY_SOURCE_ONLY',
     'fixedCommitCi': 'OPEN', 'productAcceptance': 'OPEN', 'wholePrintingCertified': False}])
manifest['currentConditionalCounterPaymentInputChange'] = manifest_pin
manifest['currentConditionalCounterPaymentWordingSourceAudit'] = native_pin
manifest['currentFixed48BoundedNativeAndPartialCiReadback'] = {'fixedCommit': base, 'sourceManifest': manifest_pin,
    'visibleNative': fixed_native_pin, 'defaultOfflineRetry': fixed_offline_pin, 'partialCi': fixed_rules_pin,
    'wholeCiSql0StillPendingAtPublication': True, 'doesNotCoverCurrentN22': True}
manifest['currentNativeSignalrDependencyFinding'] = security_pin
result = checker.current_audit(root, manifest)
assert result['governanceValid'], result['errors']
new_ids = {row['id'] for row in result['remainingObligations']}
assert prior_ids <= new_ids and len(new_ids - prior_ids) == 7 and len(new_ids) == 16918
assert reviews['reviews'][:-1] == old_reviews['reviews'] and manifest['laterSourceDeltas'] == prior['laterSourceDeltas']
for old_gate, new_gate in zip(prior['acceptanceGates'], manifest['acceptanceGates']):
    assert all(new_gate[key] == value for key, value in old_gate.items())
assert len(manifest['reviewContexts']) == 60 and len(manifest['acceptanceGates']) == 239
manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
write(evidence / 'remaining-obligation-ids.json', sorted(new_ids))
write(evidence / 'current-context-rebindings.json', {'priorEntireManifest': prior_manifest_pin,
      'allPrior59ContextsAndOriginalScopesSourceEvidencePreserved': True, 'newInputRevision': revision,
      'changedContexts': [row for row in rebindings if row['changedPins']]})
write(evidence / 'unified-obligation-retention.json', {'priorReviews': 144, 'currentReviews': 145,
      'priorContexts': 59, 'currentContexts': 60, 'priorGates': 237, 'currentGates': 239,
      'priorRemainingObligations': 16911, 'currentRemainingObligations': 16918,
      'allOriginalIdsRetained': True, 'newIds': sorted(new_ids - prior_ids),
      'allOriginal237GateKeyValues144ReviewsSixSourceDeltasPreserved': True,
      'allOriginal1740Printings14293RuleBlocksEn8GapsAndCn236DispositionsRemain': True,
      'noGameSourceDeltaAddedForSeparateDependencyFinding': True, 'semanticCoverageCertified': False})
compact = {key: value for key, value in result.items() if key not in ['inputManifest', 'reviewView', 'remainingObligations', 'laterSourceDeltas']}
compact['remainingObligationCount'] = len(new_ids)
write(evidence / 'governance-validation.json', compact)
status_path = root / 'docs/PROJECT_STATUS.md'
status = status_path.read_text()
marker = '# 当前项目状态\n\n'
assert status.startswith(marker)
lead = (work / 'project-status-lead-final-draft-v1.md').read_text()
status_path.write_text(marker + lead + '\n' + status[len(marker):])
assert all(sha(root / p) == h for p, h in publication['sourceInputHashes'].items())
print(json.dumps({'status': 'PUBLISHED_BOUNDED_CONDITIONAL_COUNTER_AND_CURRENT_SQL_NO_WHOLE_CERTIFICATION',
      'reviews': 145, 'contexts': 60, 'gates': 239, 'remaining': len(new_ids), 'archiveRecords': len(archive),
      'currentReleaseIdentity': publication['actualRuleInputs']['identitySha256'], 'newFixedFullNativeWindowsOpen': True}))
