import ast,datetime,fcntl,hashlib,json,os,plistlib,subprocess
from pathlib import Path
os.umask(0o077)
work=Path(__file__).resolve().parent;root=work.parents[2]
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres'
sock=Path('/tmp/rft-here-family-20261018-55486');tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts']
read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
guard_source=work.parent/'graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes=[n for n in ast.parse(guard_source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}]
assert len(nodes)==4;exec(compile(ast.Module(body=nodes,type_ignores=[]),str(guard_source),'exec'),globals())
publication=json.loads((work/'frozen-sql-publication-inputs-v1.json').read_text());baseline=json.loads((work/'before-192-audit-41-native-sql-baseline-v1.json').read_text())
runtime=work/'sql-runtime';reader=runtime/'conditional-counter-independent-reader-v2.dll';assert not reader.exists();reader.write_bytes((work/'sql-independent-reader-v2/bin/Release/net10.0/probe.dll').read_bytes())
cmd=publication['readerCommand'][:-1]+[str(reader)];assert json.loads(subprocess.check_output(cmd+['identity-print'],cwd=runtime,text=True))==publication['actualRuleInputs']
out=work/'original-failed-sql-independent-readback-owner-v1.json';assert not out.exists()
proof={'status':'RUNNING_ORIGINAL_FAILED_WRITER_READONLY_AUDIT','atUtc':now(),'actualRuleInputs':publication['actualRuleInputs'],'writerAndOriginal89RuntimeFilesRetained':True,'lockAtStart':observe_lock(),'readerSourceSha256':sha(work/'sql-independent-reader-v2/Program.cs'),'readerDllSha256':sha(reader)}
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
started=False;power=None
try:
 assert all(sha(runtime/p)==h for p,h in publication['runtimeFiles'].items())
 assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof.update(ownPid=os.getpid(),boundPowerPid=power.pid)
 subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(work/'own-postgres-failure-readback-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 current=rooms('riftbound_acceptance');native=rooms('riftbound_here_native');added=sorted(set(current)-set(baseline['auditRooms']))
 assert len(current)==193 and len(added)==1 and added[0].startswith('postgres-conditional-counter-') and native==baseline['nativeRooms']
 assert digests('riftbound_acceptance',baseline['auditRooms'])==baseline['auditSevenTables'] and digests('riftbound_here_native',native)==baseline['nativeSevenTables']
 before=digests('riftbound_acceptance',current)
 export=work/'original-failed-first-sql-base-pay-40commands-frame-v1.json.gz'
 env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit')
 with (work/'original-failed-first-sql-independent-reader-v1.log').open('x') as log:
  result=subprocess.run(cmd+['independent-original-failure',added[0],str(export)],cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT)
 assert result.returncode==0,result.returncode
 read=json.loads((work/'original-failed-first-sql-independent-reader-v1.log').read_text());assert read['status']=='PASS_INDEPENDENT_READONLY_ORIGINAL_FAILED_SQL_WRITER_BASE_PAYMENT' and len(read['checks'])==1
 assert read['checks'][0]['commands']==40 and read['checks'][0]['allOriginalFieldsNullsAndPrivateHistoryMatch'] and read['checks'][0]['fullOriginalReplayMatched']
 assert digests('riftbound_acceptance',current)==before and rooms('riftbound_acceptance')==current and rooms('riftbound_here_native')==native and digests('riftbound_here_native',native)==baseline['nativeSevenTables']
 (work/'original-failed-first-sql-independent-reader-result-v1.json').write_text(json.dumps(read,indent=2)+'\n')
 proof.update(status='PASS_ORIGINAL_FAILED_SQL_WRITER40_COMMAND_HISTORY_INDEPENDENT_READONLY_FULL_REPLAY',originalRoom=added[0],originalFrame=str(export.relative_to(root)),originalFrameSha256=sha(export),all193Audit41NativeSevenTablesUnchanged=True,originalCommands=40,originalEvents=read['checks'][0]['events'],actualHistoricalPayloads=read['checks'][0]['actualHistoricalPayloads'],notAnEngineBehaviorFailure=True)
except BaseException as error:
 proof.update(status='FAILED_ORIGINAL_READBACK_RETAINED',errorType=type(error).__name__,errorMessage=str(error));raise
finally:
 if started:proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None:
  if power.poll() is None:power.terminate();power.wait(timeout=10)
  proof['boundIdleSleepAssertionEnded']=power.poll() is not None
 proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),originalDatabaseRetained=True)
 out.write_text(json.dumps(proof,indent=2)+'\n');fcntl.flock(guard,fcntl.LOCK_UN)
print(proof['status'],flush=True)
