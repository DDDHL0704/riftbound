import ast,datetime,fcntl,hashlib,json,os,plistlib,socket,subprocess,time,urllib.request
from pathlib import Path
os.umask(0o077)
work=Path(__file__).resolve().parent;root=work.parents[2]
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
guard_source=work.parent/'graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes=[n for n in ast.parse(guard_source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}]
assert len(nodes)==4;exec(compile(ast.Module(body=nodes,type_ignores=[]),str(guard_source),'exec'),globals())
publication=json.loads((work/'native-current-api-capsule-publication-v1.json').read_text());helper=json.loads((work/'native-prefix-publication-v1.json').read_text())
prior=json.loads((work/'after-eight-writers-before-readonly-baseline-v2.json').read_text());rt=work/'native-current-api-capsule';prefix=work/'native-payment-prefix/bin/Release/net10.0'
f48=work.parent/'native-offline-deck-retry-fixed-48e7ff87-20261020';apps=json.loads((f48/'native-app-inputs.json').read_text())
out=work/'native-current-source-audit-owner-v1.json';ready=work/'native-current-source-audit-ready-v1.json';stop=work/'native-current-source-audit-stop-v1.json';evidence=work/'actual-native-payment-prefix-v1'
assert not any(p.exists() for p in [out,ready,stop,evidence])
def write(path,value):
 temp=path.with_suffix('.tmp');temp.write_text(json.dumps(value,indent=2)+'\n');temp.replace(path)
def frozen():
 assert all(sha(root/p)==h for p,h in publication['sourceInputHashes'].items())
 assert all(sha(rt/p)==h for p,h in publication['apiRuntimeHashes'].items())
 assert all(sha(root/p)==h for p,h in helper['sourceFiles'].items())
 assert all(sha(prefix/p)==h for p,h in helper['runtimeFiles'].items())
 for row in apps['apps']:assert all(sha(Path(row['app'])/p)==h for p,h in apps['ciManagedAndPckPayloads'].items())
frozen();guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof={'status':'STARTING_FROZEN_CURRENT_RULES_AND_EXISTING_NATIVE_BEFORE_FIX_SOURCE_AUDIT','startedAtUtc':now(),'actualBackendRuleInputs':publication['actualRuleInputs'],
 'nativeClientCommit':apps['fixedCommit'],'currentEngineIncludesUncommittedChanges':True,'oldApiContainerSourceUnchangedFixed48':True,
 'currentExistingNativeAndCurrentEngineSourceAuditIsNotNewFixedCandidateAcceptance':True,'noNewDatabaseCheckoutSdkOrAppPackage':True,'lockAtStart':observe_lock()}
write(out,proof);started=False;api=power=driver=None;baseline=None
try:
 assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket() as port:assert port.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof.update(ownRunnerPid=os.getpid(),boundPowerPid=power.pid)
 subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(work/'native-current-source-audit-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 assert rooms('riftbound_acceptance')==prior['auditRooms'] and rooms('riftbound_here_native')==prior['nativeRooms'] and len(prior['auditRooms'])==201 and len(prior['nativeRooms'])==41
 assert digests('riftbound_acceptance',prior['auditRooms'])==prior['auditSevenTables'] and digests('riftbound_here_native',prior['nativeRooms'])==prior['nativeSevenTables']
 baseline={'atUtc':now(),'auditRooms':prior['auditRooms'],'nativeRooms':prior['nativeRooms'],'auditSevenTables':prior['auditSevenTables'],'nativeSevenTables':prior['nativeSevenTables']}
 write(work/'native-current-source-audit-original201-audit41-native-baseline-v1.json',baseline)
 with (work/'native-current-source-audit-api-v1.log').open('xb') as log:
  api=subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet',str(rt/'Riftbound.Api.dll')],cwd=rt,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,
   env=dict(os.environ,ASPNETCORE_ENVIRONMENT='Production',ASPNETCORE_URLS='http://127.0.0.1:15847',ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit'))
 for attempt in range(150):
  assert api.poll() is None
  try:
   with urllib.request.urlopen('http://127.0.0.1:15847/health',timeout=.5) as response:health=json.load(response)
   assert health['persistenceMode']=='postgres' and health['environment']=='Production';break
  except OSError:time.sleep(.1)
 else:raise AssertionError('Own frozen current source-audit API not ready.')
 assert set(subprocess.check_output(['/usr/sbin/lsof','-tiTCP:15847','-sTCP:LISTEN'],text=True).splitlines())=={str(api.pid)}
 proof.update(ownApiPid=api.pid,actualHealth=health,status='FROZEN_API_READY_RUNNING_ORIGINAL_NATIVE_GATEWAY_PREFIX');write(out,proof)
 with (work/'native-current-prefix-writer-v1.log').open('x') as log:
  driver=subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet',str(prefix/'probe.dll'),'http://127.0.0.1:15847',str(evidence),str(f48)],cwd=prefix,stdout=log,stderr=subprocess.STDOUT)
  code=driver.wait(timeout=780)
 assert code==0,('native prefix rejected',code)
 receipt=json.loads((evidence/'pending-original-native-prefix-receipt.json').read_text());room=receipt['room']
 added=sorted(set(rooms('riftbound_here_native'))-set(prior['nativeRooms']));assert added==[room]
 assert digests('riftbound_acceptance',prior['auditRooms'])==prior['auditSevenTables'] and digests('riftbound_here_native',prior['nativeRooms'])==prior['nativeSevenTables']
 proof.update(status='CURRENT_RULES_REAL_NATIVE_PREFIX_PAYMENT_PENDING_READY_FOR_VISIBLE_SOURCE_CAPTURE',room=room,
  acceptedPrefixCommands=receipt['acceptedCommands'],actualPrefixTick=receipt['actualTick'],actualPrefixTurn=receipt['actualTurn'],
  all201PriorAudit41NativeSevenTablesExactAfterPrefix=True,visibleCaptureAndControlExecution='OPEN')
 write(out,proof);write(ready,{'atUtc':now(),'apiPid':api.pid,'room':room,'players':receipt['players'],
  'actualBackendRuleInputs':publication['actualRuleInputs'],'existingNativeClientCommit':apps['fixedCommit'],
  'actualPrefixReceipt':str((evidence/'pending-original-native-prefix-receipt.json').relative_to(root)),
  'sourceAuditNotNewFixedCandidateProductAcceptance':True})
 print('CURRENT_RULES_NATIVE_PAYMENT_SOURCE_AUDIT_READY',room,flush=True)
 deadline=time.monotonic()+5400
 while not stop.exists():assert api.poll() is None and time.monotonic()<deadline;time.sleep(.5)
 proof['status']='SOURCE_AUDIT_STOP_REQUESTED_ORIGINAL_HISTORY_RETAINED'
except BaseException as error:
 proof.update(status='FAILED_OR_INTERRUPTED_SOURCE_AUDIT_ORIGINAL_PREFIX_RETAINED',errorType=type(error).__name__,errorMessage=str(error));raise
finally:
 if driver is not None and driver.poll() is None:driver.terminate();driver.wait(timeout=30)
 if api is not None and api.poll() is None:api.terminate();proof['ownApiGracefulStopExitCode']=api.wait(timeout=30)
 if started:
  if baseline is not None:
   proof['allOriginal201AuditSevenTablesExact']=digests('riftbound_acceptance',baseline['auditRooms'])==baseline['auditSevenTables']
   proof['allOriginal41NativeSevenTablesExact']=digests('riftbound_here_native',baseline['nativeRooms'])==baseline['nativeSevenTables']
   proof['allNativeRoomIdsAfter']=rooms('riftbound_here_native')
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None:
  if power.poll() is None:power.terminate();power.wait(timeout=10)
  proof['boundIdleSleepAssertionEnded']=power.poll() is not None
 frozen();proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),all3308SourceAndFrozenRuntimeInputsExact=True,originalDatabaseRetained=True)
 write(out,proof);fcntl.flock(guard,fcntl.LOCK_UN)
