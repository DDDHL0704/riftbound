using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using Riftbound.CardCatalog;
using Riftbound.Contracts;
using Riftbound.Engine;

if (args.Length != 1) throw new Exception("Exact fresh discovery directory required.");
var work = Path.GetFullPath(args[0]);
var output = Path.Combine(work, "ordinary-opening-exploration-v1.json.gz");
if (File.Exists(output)) throw new Exception("Do not overwrite original exploratory history.");
var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
var catalog = await OfficialCardCatalog.LoadDefaultAsync();
var decks = PreconstructedDeckCatalog.Build(catalog, OfficialDeckFormat.ChinaStandard20260724);
var a = WithThree(decks.Single(d => d.Id == "jhin-lowcurve").Decklist, "UNL-061/219");
var b = WithThree(decks.Single(d => d.Id == "vex-response").Decklist, "SFD·136/221");
foreach (var deck in new[] { a, b })
foreach (var format in new[] { OfficialDeckFormat.CoreRules, OfficialDeckFormat.ChinaStandard20260724 })
{
    var valid = OfficialDeckValidator.Validate(deck, catalog, format);
    Check(valid.IsValid, "Actual new deck invalid: " + string.Join(';', valid.Errors));
}
var initial = MatchReplayInitialStateBuilder.FromSeats("conditional-counter-opening-explorer-v1",
    new Dictionary<string, string> { ["P1"] = "P1", ["P2"] = "P2" });
Check(initial.Tick == 0 && initial.Seed == 0 && initial.CardObjects.Count == 0, "Fresh ordinary blank seed0 only.");
await using var journal = new Journal(Path.Combine(work, "ordinary-opening-exploration-original-journal-v1.ndjson.gz"));
var engine = new CoreRuleEngine();
var session = new MatchSession(initial, engine, journal, NoopMatchPlayerStore.Instance,
    new MatchSessionOptions(AllowLegacyReadyWithoutDeck: false, DeckFormat: OfficialDeckFormat.ChinaStandard20260724));
var state = initial;
await Submit("P1", new SubmitDeckCommand(a.LegendCardNo, a.ChampionCardNo, a.MainDeck, a.RuneDeck, a.Battlefields));
await Submit("P2", new SubmitDeckCommand(b.LegendCardNo, b.ChampionCardNo, b.MainDeck, b.RuneDeck, b.Battlefields));
await Submit("P1", new ReadyCommand());
await Submit("P2", new ReadyCommand());
await Submit("P1", new MulliganCommand([]));
await Submit("P2", new MulliganCommand([]));
for (var i = 0; i < 70; i++)
{
    if (state.ActivePlayerId == "P1" && state.TurnNumber >= 7
        && Hand("P1", "UNL-061/219").Length >= 2 && Hand("P2", "SFD·136/221").Length >= 1) break;
    await Submit(state.ActivePlayerId, new EndTurnCommand());
}
Check(state.ActivePlayerId == "P1" && Hand("P1", "UNL-061/219").Length >= 2 && Hand("P2", "SFD·136/221").Length >= 1,
    "Bounded ordinary draw sequence must supply actual cards.");
var targets = Hand("P1", "UNL-061/219").Take(2).ToArray();
var counter = Hand("P2", "SFD·136/221")[0];
var runesA = Runes("P1").Take(8).ToArray();
Check(runesA.Length == 8, "Eight actual ready runes required.");
foreach (var rune in runesA) await Submit("P1", new TapRuneCommand(rune));
foreach (var target in targets) await Submit("P1", new PlayCardCommand(target, "UNL-061/219", []));
Check(state.StackItems.Count == 2 && state.RunePools["P1"].Mana == 4 && state.RunePools["P1"].TotalPower == 0,
    "Two actual two-mana draw spells, no power, leave four target-controller mana.");
while (state.PriorityPlayerId != "P2") await Submit(state.PriorityPlayerId!, new PassPriorityCommand());
var runesB = Runes("P2").Take(4).ToArray();
Check(runesB.Length == 4, "Four actual reaction resource runes required.");
foreach (var rune in runesB) await Submit("P2", new TapRuneCommand(rune));
Check(state.RunePools["P2"].Mana == 4 && state.RunePools["P2"].TotalPower == 0 && state.PriorityPlayerId == "P2",
    "Actual off-turn reaction rune skills fund the prospective counter.");
var commands = journal.Entries.Select(e => new RecoveredCommand(e.PlayerId, e.ClientIntentId, e.CommandType, e.RawCommand,
    e.StartedTick, e.CompletedTick, e.StartedEventSequence, e.CompletedEventSequence, e.Accepted, e.ErrorMessage)
    { RuleInputs = e.RuleInputs }).ToArray();
var events = journal.Entries.SelectMany(e => e.Events.Select((ev, i) => new RecoveredEvent(e.StartedEventSequence + i + 1, e.CompletedTick, i, ev))).ToArray();
var replay = await MatchActionLogReplayer.VerifyFinalStateAsync(initial, commands, state, engine, default, events);
Check(replay.IsMatch, "Original exploratory replay failed: " + string.Join(';', replay.Errors));
await using (var file = new FileStream(output, FileMode.CreateNew))
await using (var compressed = new GZipStream(file, CompressionLevel.SmallestSize))
    await JsonSerializer.SerializeAsync(compressed, new { initial, state, commands, events, actualRuleInputs = state.RuleInputs,
        originalBlankSeed = 0, noAcceptedHistoryRewrite = true, noGameplayStateInjection = true }, json);
var intents = journal.Entries.Select((e, i) => new {
    originalExplorationCommandIndex = i, playerId = e.PlayerId,
    rawCommand = JsonSerializer.SerializeToElement(GameCommandJsonMapper.Map(e.RawCommand!.Value),
        GameCommandJsonMapper.Map(e.RawCommand!.Value).GetType(), json) }).ToArray();
var recipe = new { schemaVersion = 1, status = "NEW_TEST_INTENTS_DERIVED_FROM_RETAINED_EXPLORATION_NOT_REWRITTEN_ACCEPTED_HISTORY",
    region = "CN", language = "zh-CN", rulesBaseline = "2026-10-16", parentCommit = "48e7ff8702dc43a1b5a3991365d87068506ae137",
    originalExplorationSha256 = Convert.ToHexStringLower(SHA256.HashData(await File.ReadAllBytesAsync(output))),
    originalBlankSeed = 0, openingIntents = intents, sourceObjectId = counter,
    targetStackItemIds = state.StackItems.Select(s => s.StackItemId).ToArray(), targetSourceObjectIds = targets,
    expectedPrefixCommands = commands.Length, expectedPrefixTurn = state.TurnNumber,
    expectedP1Mana = 4, expectedP2Mana = 4, expectedTotalPowerEach = 0,
    validatedFormats = new[] { "CoreRules", "ChinaStandard20260724" } };
var recipePath = Path.Combine(work, "conditional-counter-new-opening-intents-v1.json");
Check(!File.Exists(recipePath), "Fresh derived test-intent recipe required.");
await File.WriteAllTextAsync(recipePath, JsonSerializer.Serialize(recipe, json));
Console.WriteLine(JsonSerializer.Serialize(new { status = "PASS_NEW_ORDINARY_BLANK_OPENING_TWO_LEGAL_DECKS_ACTUAL_SPELLS_AND_RUNE_RESOURCES_FULL_REPLAY",
    commands = commands.Length, events = events.Length, turn = state.TurnNumber, source = counter, targetStackItems = recipe.targetStackItemIds,
    recipePath, exactRuleInputs = state.RuleInputs }, json));

string[] Hand(string player, string no) => state.PlayerZones[player].Hand.Where(id => state.CardObjects[id].CardNo == no).ToArray();
string[] Runes(string player) => state.PlayerZones[player].Base.Where(id => state.CardObjects[id].Tags.Contains(CardObjectTags.RuneCard)
    && !state.CardObjects[id].IsExhausted).ToArray();
async Task Submit(string player, GameCommand command)
{
    var fields = JsonSerializer.SerializeToNode(command, command.GetType(), json)!.AsObject();
    fields["promptId"] = session.PromptFor(player).PromptId; fields["snapshotTick"] = state.Tick;
    var raw = JsonSerializer.SerializeToElement(fields, json); var intent = "new-conditional-prefix-" + journal.Entries.Count;
    var result = command switch {
        SubmitDeckCommand deck => await session.SubmitDeckAsync(player, intent, deck, raw, default),
        ReadyCommand => await session.ReadyAsync(player, intent, raw, default),
        _ => await session.SubmitAsync(player, intent, command, raw, default) };
    Check(result.Accepted, "Actual prefix command failed: " + command.CmdType + " " + result.ErrorMessage);
    state = result.State;
}
static OfficialDecklist WithThree(OfficialDecklist source, string spell)
{
    var main = source.MainDeck.ToList();
    for (var i = 0; i < 3; i++) main.RemoveAt(main.FindIndex(c => c != source.ChampionCardNo && c != spell));
    return source with { MainDeck = Enumerable.Repeat(spell, 3).Concat(main).ToArray() };
}
static void Check(bool condition, string message) { if (!condition) throw new Exception(message); }
sealed class Journal(string path) : IMatchJournal, IAsyncDisposable
{
    private readonly StreamWriter writer = new(new GZipStream(
        new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.Read), CompressionLevel.SmallestSize));
    public List<MatchJournalEntry> Entries { get; } = [];
    public async ValueTask RecordAsync(MatchJournalEntry entry, CancellationToken token)
    {
        Entries.Add(entry);
        await writer.WriteLineAsync(JsonSerializer.Serialize(entry, new JsonSerializerOptions(JsonSerializerDefaults.Web)));
        await writer.FlushAsync();
    }
    public ValueTask DisposeAsync() => writer.DisposeAsync();
}
