using Riftbound.Contracts;
using Riftbound.Engine;
using Xunit;

namespace Riftbound.ConformanceTests;

// Current CN SFD136 and DOC01 445.2/740.4/820: the target controller,
// rather than the caster, makes each optional payment while resolving.
public sealed class ConditionalCounterPaymentTests
{
    private const string Card = "SFD·136/221";

    [Fact]
    public async Task NormalDeclarationDoesNotChooseTheOpponentsPaymentInAdvance()
    {
        var initial = Position(2);
        var command = new PlayCardCommand("C", Card, ["S1"]);
        var result = await new CoreRuleEngine().ResolveAsync(initial,
            new("ordinary-declaration", "P1", CommandTypes.PlayCard), command, default);
        Assert.True(result.Accepted, result.ErrorMessage);
        Assert.Equal(3, result.State.StackItems.Count);
        Assert.Null(result.State.PendingRuleChoice);
        Assert.Equal(2, result.State.RunePools["P2"].Mana);
    }

    [Fact]
    public async Task TargetControllerCanPayAtResolutionAndKeepItsOriginalSpell()
    {
        var initial = Position(2);
        var driver = new StandbyDefendObserverTests.Driver(initial);
        await driver.Act("P1", new PlayCardCommand("C", Card, ["S1"], Mode: DeclaredMode()));
        await ResolveCounter(driver);
        var pending = Assert.IsType<RuleChoiceContinuation>(driver.State.PendingRuleChoice);
        Assert.Equal("P2", pending.Request.PlayerId);
        Assert.Equal(2, pending.Request.ManaCost);
        Assert.Contains(pending.Request.Options, o => o.Id == "DECLINE");
        Assert.Contains(pending.Request.Options, o => o.Id == "SPEND_MANA:2");
        Assert.DoesNotContain(driver.Events(), e => e.Event.Kind == "STACK_ITEM_COUNTERED");
        await Decide(driver, "SPEND_MANA:2");
        Assert.Null(driver.State.PendingRuleChoice);
        Assert.Equal(0, driver.State.RunePools["P2"].Mana);
        Assert.Equal(["S1", "S2"], driver.State.StackItems.Select(i => i.StackItemId));
        Assert.Empty(driver.State.PlayerZones["P2"].Graveyard);
        Assert.Equal(["C"], driver.State.PlayerZones["P1"].Graveyard);
        Assert.Single(driver.Events(), e => e.Event.Kind == "COST_PAID"
            && Equals(e.Event.Payload.GetValueOrDefault("playerId"), "P2")
            && Equals(e.Event.Payload.GetValueOrDefault("mana"), 2));
        await RideTheWindCurrentMovementTests.Replay(initial, driver);
    }

    [Fact]
    public async Task PrintedEchoOffersTwoIndependentTargetControllerPayments()
    {
        var initial = Position(4);
        var mode = DeclaredMode();
        var command = new PlayCardCommand("C", Card, ["S1"], Mode: mode,
            OptionalCosts: ["ECHO"], RepeatChoices: [new(mode, ["S2"])]);
        var engine = new CoreRuleEngine();
        var quote = engine.PreviewPlayCard(initial, "P1", PlayCostPreviewTests.Request(initial, command));
        Assert.True(quote.CanPay, quote.Message);
        var driver = new StandbyDefendObserverTests.Driver(initial);
        await driver.Act("P1", command);
        await ResolveCounter(driver);
        Assert.Equal("P2", driver.State.PendingRuleChoice!.Request.PlayerId);
        await Decide(driver, "SPEND_MANA:2");
        var second = Assert.IsType<RuleChoiceContinuation>(driver.State.PendingRuleChoice);
        Assert.Equal("P2", second.Request.PlayerId);
        Assert.Equal(2, second.Request.Preview!.RunePools["P2"].Mana);
        await Decide(driver, "SPEND_MANA:2");
        Assert.Null(driver.State.PendingRuleChoice);
        Assert.Equal(0, driver.State.RunePools["P2"].Mana);
        Assert.Equal(["S1", "S2"], driver.State.StackItems.Select(i => i.StackItemId));
        Assert.Equal(["C"], driver.State.PlayerZones["P1"].Graveyard);
        Assert.Equal(1, driver.State.PlayerCardsPlayedThisTurn["P1"]);
        Assert.Equal(2, driver.Events().Count(e => e.Event.Kind == "SPELL_EXECUTION_COMPLETED"));
        Assert.DoesNotContain(driver.Events(), e => e.Event.Kind == "STACK_ITEM_COUNTERED");
        await RideTheWindCurrentMovementTests.Replay(initial, driver);
    }

    private static MatchState Position(int targetMana)
    {
        var initial = OfficialCounterRepeatTests.Position(Card);
        return initial with { RunePools = new Dictionary<string, RunePool>(initial.RunePools)
            { ["P2"] = new(targetMana, 0) } };
    }

    private static string DeclaredMode()
    {
        Assert.True(CardBehaviorRegistry.TryGetByCardNo(Card, out var definition));
        return definition.Mode;
    }

    private static async Task ResolveCounter(StandbyDefendObserverTests.Driver driver)
    {
        for (var i = 0; i < 4 && driver.State.PendingRuleChoice is null
            && driver.State.StackItems.Any(s => s.SourceObjectId == "C"); i++)
            await driver.Act(driver.State.PriorityPlayerId!, new PassPriorityCommand());
    }

    private static Task Decide(StandbyDefendObserverTests.Driver driver, string option)
    {
        var pending = Assert.IsType<RuleChoiceContinuation>(driver.State.PendingRuleChoice);
        return driver.Act(pending.Request.PlayerId,
            new PayCostCommand(pending.Request.Id, "RULE_REPLACEMENT", [option]));
    }
}
