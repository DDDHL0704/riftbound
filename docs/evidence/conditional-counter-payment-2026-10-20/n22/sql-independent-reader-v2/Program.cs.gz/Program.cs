using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.CardCatalog;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
if (args.SequenceEqual(["identity-print"])) { Console.WriteLine(JsonSerializer.Serialize(RuleInputIdentity.Current, json)); return; }
var failedWriterOriginal = args.Length == 3 && args[0] == "independent-original-failure";
Check(failedWriterOriginal || args.Length == 2 && args[0] == "independent-readonly", "Original eight-branch output path or explicit original failed-writer room and fresh export path required.");
var folder = Path.GetFullPath(args[1]);
var settings = new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
Check(settings.Host == "127.0.0.1" && settings.Port == 55486 && settings.Database == "riftbound_acceptance"
    && settings.Username == "codex_riftbound_audit", "Existing dedicated original database required.");
settings.Options = "-c default_transaction_read_only=on";
await using var source = NpgsqlDataSource.Create(settings.ConnectionString);
var catalog = await OfficialCardCatalog.LoadDefaultAsync();
using var recipe = JsonDocument.Parse(File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "Fixtures/conditional-counter-openings.json")));
var opening = recipe.RootElement.GetProperty("openingIntents").EnumerateArray().ToArray();
Check(opening.Length == 32, "Exact retained new-intent recipe required.");
var counter = recipe.RootElement.GetProperty("sourceObjectId").GetString()!;
var targets = recipe.RootElement.GetProperty("targetStackItemIds").EnumerateArray().Select(v => v.GetString()!).ToArray();
var spellSources = recipe.RootElement.GetProperty("targetSourceObjectIds").EnumerateArray().Select(v => v.GetString()!).ToArray();
var checks = new List<object>();
foreach (var format in failedWriterOriginal ? new[] { "CoreRules" } : ["CoreRules", "ChinaStandard20260724"])
foreach (var profile in failedWriterOriginal ? new[] { "BASE_PAY" } : ["BASE_PAY", "BASE_DECLINE", "ECHO_PAY_BOTH", "ECHO_PAY_THEN_DECLINE"])
{
    var path = failedWriterOriginal ? Path.GetFullPath(args[2]) : Path.Combine(folder, $"conditional-counter-{format}-{profile}-original-frame.json.gz");
    if (failedWriterOriginal)
    {
        var saved = await new PostgresMatchRecoveryStore(source).LoadAsync(args[1], default) ?? throw new Exception("Original failed writer room required.");
        await using var target = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None);
        await using var compressed = new GZipStream(target, CompressionLevel.SmallestSize);
        await JsonSerializer.SerializeAsync(compressed, saved, json);
    }
    var bytes = File.ReadAllBytes(path); var hash = Convert.ToHexStringLower(SHA256.HashData(bytes));
    await using var zip = new GZipStream(new MemoryStream(bytes), CompressionMode.Decompress);
    var raw = await JsonNode.ParseAsync(zip) ?? throw new Exception("Original SQL frame required.");
    var original = raw.Deserialize<MatchRecoveryFrame>(json)!;
    Check(JsonNode.DeepEquals(raw, JsonSerializer.SerializeToNode(original, json)), "Every original frame field and null survives typed read exactly.");
    var frame = await new PostgresMatchRecoveryStore(source).LoadAsync(original.RoomId, default) ?? throw new Exception("Actual original database frame required.");
    Check(JsonNode.DeepEquals(raw, JsonSerializer.SerializeToNode(frame, json)), "Original saved fields/nulls/commands/events/private views/prompts equal actual SQL.");
    var expectedCommands = profile switch { "BASE_PAY" => 40, "BASE_DECLINE" => 38, "ECHO_PAY_BOTH" => 41, _ => 39 };
    var state = frame.AuthoritativeState!;
    Check(frame.IsConsistent && frame.OpeningSeed == 0 && frame.ReplayInitialState is { Tick: 0, Seed: 0 } blank
        && blank.CardObjects.Count == 0 && frame.Commands.Count == expectedCommands
        && frame.Commands.All(c => c.Accepted && c.RuleInputs == RuleInputIdentity.Current)
        && state.RuleInputs == RuleInputIdentity.Current, "Actual blank seed, original accepted command count and runtime identity.");
    Check(frame.Commands.Count(c => c.CommandType == CommandTypes.SubmitDeck) == 2
        && frame.Commands.All(c => c.CommandType != "SURRENDER" && c.CommandType != "DEV_SEED_SCENARIO"), "Two actual deck submissions without injected state or surrender.");
    for (var i = 0; i < opening.Length; i++)
    {
        var command = frame.Commands[i]; var expected = GameCommandJsonMapper.Map(opening[i].GetProperty("rawCommand"));
        var actual = GameCommandJsonMapper.Map(command.RawCommand!.Value);
        Check(command.PlayerId == opening[i].GetProperty("playerId").GetString()
            && JsonNode.DeepEquals(JsonSerializer.SerializeToNode(expected, expected.GetType(), json), JsonSerializer.SerializeToNode(actual, actual.GetType(), json)),
            "Every original typed opening intent retains exact actor, order and payload; only fresh transport prompt/tick was bound.");
    }
    foreach (var command in frame.Commands.Where(c => c.CommandType == CommandTypes.SubmitDeck))
    {
        var deck = (SubmitDeckCommand)GameCommandJsonMapper.Map(command.RawCommand!.Value);
        foreach (var f in new[] { OfficialDeckFormat.CoreRules, OfficialDeckFormat.ChinaStandard20260724 })
            Check(OfficialDeckValidator.Validate(new(deck.LegendCardNo, deck.ChampionCardNo, deck.MainDeck, deck.RuneDeck, deck.Battlefields), catalog, f).IsValid,
                "Both actual original decks independently legal in both declared formats.");
    }
    var echo = profile.StartsWith("ECHO_", StringComparison.Ordinal);
    var declaration = (PlayCardCommand)GameCommandJsonMapper.Map(frame.Commands[32].RawCommand!.Value);
    Check(frame.Commands[32].PlayerId == "P2" && declaration.SourceObjectId == counter && declaration.CardNo == "SFD·136/221"
        && string.IsNullOrEmpty(declaration.Mode) && declaration.TargetObjectIds.SequenceEqual([targets[0]])
        && (echo ? declaration.OptionalCosts!.SequenceEqual(["ECHO"]) && declaration.RepeatChoices!.Single().TargetObjectIds.SequenceEqual([targets[1]])
            : declaration.OptionalCosts is not { Count: > 0 }), "Actual normal declaration and independently declared printed repeat target.");
    var payments = frame.Commands.Where(c => c.CommandType == CommandTypes.PayCost).ToArray();
    var expectedChoices = profile switch { "BASE_DECLINE" => new[] { "DECLINE" }, "ECHO_PAY_BOTH" => ["SPEND_MANA:2", "SPEND_MANA:2"],
        "ECHO_PAY_THEN_DECLINE" => ["SPEND_MANA:2", "DECLINE"], _ => ["SPEND_MANA:2"] };
    Check(payments.All(p => p.PlayerId == "P1") && payments.Select(p => ((PayCostCommand)GameCommandJsonMapper.Map(p.RawCommand!.Value)).PaymentChoiceIds!.Single())
        .SequenceEqual(expectedChoices), "Every original target-controller choice is explicit, ordered and independent.");
    var counterEvents = frame.Events.Where(e => e.Event.Kind == "STACK_ITEM_COUNTERED").ToArray();
    var expectedCounter = profile == "BASE_DECLINE" ? targets[0] : targets[1];
    Check(profile is "BASE_PAY" or "ECHO_PAY_BOTH" ? counterEvents.Length == 0
        : counterEvents.Length == 1 && Payload(counterEvents[0]).GetProperty("stackItemId").GetString() == expectedCounter,
        "The refused execution counters exactly the declared target.");
    var costEvents = frame.Events.Where(e => e.Event.Kind == "COST_PAID"
        && Payload(e).TryGetProperty("reason", out var reason) && reason.GetString() == "COUNTER_TARGET_MANA_PAYMENT").ToArray();
    Check(costEvents.Length == expectedChoices.Count(c => c == "SPEND_MANA:2")
        && costEvents.All(e => Payload(e).GetProperty("mana").GetInt32() == 2 && Payload(e).GetProperty("power").GetInt32() == 0
            && Payload(e).GetProperty("playerId").GetString() == "P1"), "Every accepted payment spends two mana and no power from the actual target controller.");
    Check(state.Status == MatchStatuses.InProgress && state.StackItems.Count == 0 && state.TriggerQueue.Count == 0
        && state.PendingRuleChoice is null && state.PendingPayment is null && state.PendingEffectPlay is null
        && state.RunePools["P1"].Mana == (profile == "BASE_DECLINE" ? 4 : profile == "ECHO_PAY_BOTH" ? 0 : 2)
        && state.RunePools["P2"].Mana == (echo ? 0 : 2) && state.RunePools["P1"].TotalPower == 0 && state.RunePools["P2"].TotalPower == 0
        && state.PlayerZones["P2"].Graveyard.Contains(counter) && spellSources.All(s => state.PlayerZones["P1"].Graveyard.Contains(s)),
        "Actual final resources, physical spell destinations and empty pending flows match the explicit original decisions.");
    var history = new Dictionary<string, int>(); var originalPendingStates = 0; var originalSecondPaymentStates = 0;
    await using (var connection = await source.OpenConnectionAsync())
    {
        Check((string)(await new NpgsqlCommand("show transaction_read_only", connection).ExecuteScalarAsync())! == "on", "Actual database enforces independent read-only transactions.");
        foreach (var table in new[] { "state_snapshots", "snapshots", "action_prompts" })
        {
            await using var command = new NpgsqlCommand($"select payload::text from {table} where match_id=@room order by id", connection);
            command.Parameters.AddWithValue("room", frame.RoomId); await using var rows = await command.ExecuteReaderAsync(); var count = 0;
            while (await rows.ReadAsync())
            {
                var payload = rows.GetString(0); var originalPayload = JsonNode.Parse(payload);
                var roundtrip = table switch {
                    "state_snapshots" => JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<MatchState>(payload, json), json),
                    "snapshots" => JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<SnapshotDto>(payload, json), json),
                    _ => JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<ActionPromptDto>(payload, json), json) };
                Check(JsonNode.DeepEquals(originalPayload, roundtrip), "Every historical original state/private view/prompt field and null survives typed read exactly."); count++;
                if (table == "state_snapshots" && JsonSerializer.Deserialize<MatchState>(payload, json)!.PendingRuleChoice is { } pending)
                {
                    Check(pending.Request.PlayerId == "P1" && pending.Request.ManaCost == 2 && pending.Request.PowerCost == 0
                        && pending.Request.Kind == "COUNTER_TARGET_MANA_PAYMENT" && pending.Request.Options.Any(o => o.Id == "SPEND_MANA:2")
                        && !pending.Request.Options.Any(o => o.Id == "SPEND_MANA:0"), "Persisted original prompt independently preserves payer, exact optional cost and authorized choices.");
                    originalPendingStates++;
                    if (pending.Answers.Count == 1)
                    { Check(pending.Answers[0].OptionId == "SPEND_MANA:2" && pending.Request.Preview!.RunePools["P1"].Mana == 2,
                        "Actual persisted second repeat decision retains the first accepted payment and preview resources."); originalSecondPaymentStates++; }
                }
            }
            Check(count > 0, "Actual original historical payload rows required."); history[table] = count;
        }
    }
    Check(history["state_snapshots"] == expectedCommands && originalPendingStates == (echo ? 2 : 1)
        && originalSecondPaymentStates == (echo ? 1 : 0), "Every actual accepted state and both original repeat payment checkpoints are retained.");
    var errors = await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame, new CoreRuleEngine(), default);
    Check(errors.Count == 0, "Independent full original SQL action/event/state replay: " + string.Join(';', errors));
    Check(Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(path))) == hash, "Original saved frame remains byte exact.");
    checks.Add(new { room = frame.RoomId, format, profile, commands = frame.Commands.Count, events = frame.Events.Count,
        originalFrameSha256 = hash, actualHistoricalPayloads = history, originalPendingStates, originalSecondPaymentStates,
        allOriginalFieldsNullsAndPrivateHistoryMatch = true, original32IntentPayloadsAndActorsExact = true, fullOriginalReplayMatched = true });
}
Console.WriteLine(JsonSerializer.Serialize(new { status = failedWriterOriginal ? "PASS_INDEPENDENT_READONLY_ORIGINAL_FAILED_SQL_WRITER_BASE_PAYMENT" : "PASS_INDEPENDENT_READONLY_REAL_POSTGRES_EIGHT_CONDITIONAL_COUNTER_ORIGINALS",
    actualRuleInputs = RuleInputIdentity.Current, checks, noNewGameplayStateSeedOrHistoryRewrite = true,
    completeGameOrWholeCardCertification = false, visibleNativeAndPhysicalWindows = "OPEN" }, json));
static JsonElement Payload(RecoveredEvent e) => JsonSerializer.SerializeToElement(e.Event.Payload);
static void Check(bool condition, string message) { if (!condition) throw new Exception(message); }
