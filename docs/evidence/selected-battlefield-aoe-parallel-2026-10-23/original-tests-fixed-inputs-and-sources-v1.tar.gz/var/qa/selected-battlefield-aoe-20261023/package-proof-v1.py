from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,tarfile,io,subprocess,xml.etree.ElementTree as E
R=Path.cwd();Q=R/'var/qa/selected-battlefield-aoe-20261023';D=R/'docs/evidence/selected-battlefield-aoe-parallel-2026-10-23';D.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
frozen=json.load((Q/'frozen-inputs-v3.json').open())
for p,h in frozen['ruleInputs'].items():assert sha((R/p).read_bytes())==h
runs=[]
for path,total,passed,failed in [('focus-v1',30,0,30),('focus-v2',30,4,26),('adjacent-v2',60,60,0),('focus-and-adjacent-v3',92,64,28)]:
 t=E.parse(Q/path/'focus/results.trx');c=t.find('.//t:Counters',ns).attrib;assert[c['total'],c['passed'],c['failed'],c['notExecuted']]==[str(total),str(passed),str(failed),'0']
 cases=[{'name':x.get('testName'),'outcome':x.get('outcome'),'failure':x.find('.//t:Message',ns).text if x.find('.//t:Message',ns)is not None else None}for x in t.findall('.//t:UnitTestResult',ns)]
 assert all('SelectedBattlefieldAreaDamageTests'in x['name']for x in cases if x['outcome']!='Passed')
 plan=json.load((Q/path/'plan.json').open());runs.append({'path':path,'counters':c,'plan':plan,'testCases':cases})
assert runs[1]['plan']['testAssemblySha256']==runs[2]['plan']['testAssemblySha256']
assembly=R/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0/Riftbound.ConformanceTests.dll';assert runs[-1]['plan']['testAssemblySha256']==sha(assembly.read_bytes())
source='tests/Riftbound.ConformanceTests/SelectedBattlefieldAreaDamageTests.cs';assert(Q/'focus-and-adjacent-v3/test-source.cs').read_bytes()==(R/source).read_bytes()
proof=json.load((Q/'verified-results-v3.json').open());assert len(proof)==32 and sum(x['commands']for x in proof)==84 and sum(x['events']for x in proof)==231 and sum(x['accepted']for x in proof)==78
actual=[];histories=[]
for version,count,commands,events in [('v1',30,30,0),('v2',30,78,212),('v3',32,84,231)]:
 xs=[]
 for p in sorted((Q/('original-'+version)).glob('*.json.gz')):
  x=json.load(gzip.open(p,'rt'));assert len(x['commands'])==len(x['entries'])==len(x['states'])==x['originalPrefixReplayCount'];assert x['initial']['seed']==424242
  assert [e for item in x['entries']for e in item['events']]==[e['event']for e in x['events']]
  for c0 in x['commands']:
   if c0['ruleInputs']not in actual:actual.append(c0['ruleInputs'])
  xs.append(x)
 assert len(xs)==count and sum(len(x['commands'])for x in xs)==commands and sum(len(x['events'])for x in xs)==events
 histories.append({'version':version,'cases':count,'commands':commands,'events':events,'originalPrefixReplays':commands,'accepted':sum(c['accepted']for x in xs for c in x['commands'])})
assert len(actual)==1
receiptPath=R/'var/qa/draven-battle-multi-source-20261023/applied-n53-overlay-v1.json';receipt=json.load(receiptPath.open());peer=Path(receipt['overlaySource']);assert sha(peer.read_bytes())==receipt['overlaySha256'];oldReceipt=Path(receipt['parentReceipt']);old=json.load(oldReceipt.open());oldPeer=Path(old['overlaySource']);assert sha(oldPeer.read_bytes())==old['overlaySha256']
sourceDirs=[Q/'sources-v1',R/'var/qa/battlefield-aoe-source-scope-20261023/sources-v1',R/'var/qa/void-gate-untargeted-damage-20261023/sources-v1']
for root in sourceDirs:
 for p in root.glob('current-*-original-v1.json.gz'):
  x=json.load(gzip.open(p,'rt'));assert sha(x['originalUtf8'].encode())==x['rawSha256']
extra=[source,'docs/SELECTED_BATTLEFIELD_AOE_PARALLEL_2026-10-23.md','tests/Riftbound.ConformanceTests/CurrentVoidGateErratumTests.cs','tests/Riftbound.ConformanceTests/CurrentControllerDamageBonusTests.cs','tests/Riftbound.ConformanceTests/ConformanceFixtureRunnerTests.cs','src/Riftbound.Engine/CardBehaviorRegistry.cs','src/Riftbound.Engine/BattlefieldStaticAbilitySpecRules.cs']
paths=[(str(p.relative_to(R)),p)for root in [Q]+sourceDirs[1:]for p in root.rglob('*')if p.is_file()]+[(x,R/x)for x in extra]+[('inputs/n53-exact-main-overlay-after71-green-v1.tar.gz',peer),('inputs/applied-n53-overlay-v1.json',receiptPath),('inputs/peer-fixed-n52-first45-v1.tar.gz',oldPeer),('inputs/applied-peer-fixed-n52-first45-v1.json',oldReceipt)]
assert len(paths)==len(set(n for n,p in paths));archive=D/'original-tests-fixed-inputs-and-sources-v1.tar.gz';members=[]
with archive.open('xb')as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as t:
   for name,p in sorted(paths):
    b=p.read_bytes();i=tarfile.TarInfo(name);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b));members.append({'path':name,'bytes':len(b),'sha256':sha(b)})
with tarfile.open(archive,'r:gz')as t:
 for m in members:
  b=t.extractfile(m['path']).read();assert len(b)==m['bytes']and sha(b)==m['sha256']
manifest={'status':'SOURCE_RED_CROSS_BATTLEFIELD_DAMAGE_MISSING_GLOBAL_LOCAL_BONUSES_AND_FIELDLESS_MOVEMENT','atUtc':datetime.now(timezone.utc).isoformat(),'baseCommit':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'region':'CN','language':'zh-CN','peerOverlay':receipt,'frozenSpecifiedInputs':frozen,'all29SpecifiedInputsUnchanged':True,'actualRuleInputs':actual[0],'testAssemblySha256':sha(assembly.read_bytes()),'source':{'path':source,'sha256':sha((R/source).read_bytes())},'runs':runs,'originalHistories':histories,'finalCaseResults':proof,'v2V3OriginalHistoryParity':json.load((Q/'v2-v3-original-history-parity.json').open()),'newCases':32,'newPassedControls':4,'newSourceFailures':22,'newProtocolProbeRejections':6,'protocolRejectionsAreNotIndependentSourceDefects':True,'newCommands':84,'newAccepted':78,'newRejected':6,'newEvents':231,'newOriginalPrefixReplays':84,'adjacentCasesPassed':60,'cases':92,'passed':64,'failed':28,'skipped':0,'sourceRuntimeAndNextProtocol':json.load((Q/'source-runtime-and-protocol-boundaries-v1.json').open()),'noSharedRuntimeChanges':True,'noExtraCheckOrFull':True,'noDatabaseExecution':True,'wholePrintingCertified':False,'backendGoalComplete':False,'archive':{'path':str(archive.relative_to(R)),'sha256':sha(archive.read_bytes()),'members':members}}
with(D/'source-and-red-test-manifest.json').open('x')as f:json.dump(manifest,f,ensure_ascii=False,indent=2)
print('Verified',len(members),'members,',archive.stat().st_size,'bytes;32new4green22sourceRED6protocolREJECT;60adjacentPASS;84prefixes')
