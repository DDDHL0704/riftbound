from pathlib import Path
import gzip,json,hashlib,xml.etree.ElementTree as E
q=Path(__file__).parent;ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
p=q/'focus-and-adjacent-v3/focus/results.trx'
if p.exists():
 t=E.parse(p);print('COUNTERS',t.find('.//t:Counters',ns).attrib)
f=json.loads((q/'frozen-inputs-v3.json').read_text());print('frozen_matches',all(hashlib.sha256(Path(k).read_bytes()).hexdigest()==v for k,v in f['ruleInputs'].items()))
rows=[]
for p in sorted((q/'original-v3').glob('*.gz')):
 d=json.loads(gzip.decompress(p.read_bytes())); es=[x['event'] for x in d['events']]; damage={e['payload']['targetObjectId']:e['payload']['damage']for e in es if e['kind']=='DAMAGE_APPLIED'and e['payload'].get('sourceObjectId')=='SPELL'}
 rows.append({'caseId':d['caseId'],'kind':d['kind'],'card':d['card'],'gate':d['gate'],'annie':d['annie'],'field':d['field'],'commands':len(d['commands']),'accepted':sum(c['accepted'] for c in d['commands']),'events':len(es),'originalPrefixReplays':d['originalPrefixReplayCount'],'damage':damage,'p1UnitLocation':d['states'][-1]['objectLocations']['P1-BASE'],'failure':d['failure']})
 print(d['caseId'],len(d['commands']),len(es),damage,d['failure'])
 if not d['gate']and not d['annie']and d['field']=='A':
  prompt=d['prompts'][0]['beforePrompts'][0]
  for c in prompt['candidates']:
   if c['action']=='PLAY_CARD':
    for s in c['metadata']['sourceRequirements']:
     if s['sourceObjectId']=='SPELL':print('PROMPT',d['card'],{k:s.get(k)for k in ['minTargetCount','maxTargetCount','targetScope','targetChoicesByIndex','destinationChoices','legalTargetSelections']})
print('TOTAL',len(rows),'commands',sum(x['commands']for x in rows),'events',sum(x['events']for x in rows))
if len(rows)==32:
 with(q/'verified-results-v3.json').open('x')as f:json.dump(rows,f,ensure_ascii=False,indent=2)
