using System.Text.Json;
using System.Text.Json.Nodes;
using Riftbound.Contracts;
using Riftbound.Engine;

if(args.Length!=1||File.Exists(args[0]))throw new Exception("Fresh diagnostic only; no database or network.");
var room="readonly-revealed-hand-order-diagnostic";
var state=new MatchState(room,0,5,"P1",new Dictionary<string,string>{{"P1","P1"},{"P2","P2"}},status:MatchStatuses.InProgress,readyPlayerIds:["P1","P2"],turnPlayerId:"P1",phase:MatchPhases.Main,timingState:TimingStates.NeutralOpen,
    playerZones:new Dictionary<string,PlayerZones>{{"P1",PlayerZones.Empty with {Hand=["C"],Battlefields=["BF"]}},{"P2",PlayerZones.Empty with {Hand=["U","SPELL"]}}},
    cardObjects:new Dictionary<string,CardObjectState>{
        ["C"]=new("C",cardNo:"UNL-139/219",tags:[CardObjectTags.SpellCard],ownerId:"P1",controllerId:"P1"),
        ["BF"]=new("BF",cardNo:"OGN·296/298",tags:["CARD_TYPE:BATTLEFIELD"],ownerId:"P1",controllerId:"P1"),
        ["U"]=new("U",cardNo:"SFD·125/221",tags:[CardObjectTags.UnitCard],ownerId:"P2",controllerId:"P2"),
        ["SPELL"]=new("SPELL",cardNo:"UNL-200/219",tags:[CardObjectTags.SpellCard],ownerId:"P2",controllerId:"P2")},
    objectLocations:new Dictionary<string,ObjectLocationState>{{"C",new("P1","HAND")},{"BF",new("P1","BATTLEFIELD","BF")},{"U",new("P2","HAND")},{"SPELL",new("P2","HAND")}},
    playerScores:new Dictionary<string,int>{{"P1",0},{"P2",0}},runePools:new Dictionary<string,RunePool>{{"P1",new(2,2)},{"P2",RunePool.Empty}});
var initial=state;var engine=new CoreRuleEngine();
foreach(var command in new GameCommand[]{new PlayCardCommand("C","UNL-139/219",["BF"]),new PassPriorityCommand(),new PassPriorityCommand()})
{
    var player=command is PlayCardCommand?"P1":state.PriorityPlayerId!;
    var result=await engine.ResolveAsync(state,new("hand-order-"+state.Tick,player,command.CmdType),command,default);
    if(!result.Accepted)throw new Exception(result.ErrorMessage);state=result.State;
}
if(state.PendingEffectPlay?.RevealedHand is not {Choosing:true}){await File.WriteAllTextAsync(args[0]+".precondition-failure.json",JsonSerializer.Serialize(state,new JsonSerializerOptions(JsonSerializerDefaults.Web){WriteIndented=true}));throw new Exception("Actual engine revealed selection required.");}
var original=JsonSerializer.SerializeToNode(state)!;var changed=Reorder(original);var restored=changed.Deserialize<MatchState>()!;
var snapshots=ResolutionResult.BuildSnapshots(state);var prompts=ResolutionResult.BuildPrompts(state);var coldSnapshots=ResolutionResult.BuildSnapshots(restored);var coldPrompts=ResolutionResult.BuildPrompts(restored);
var views=state.Seats.Keys.ToDictionary(id=>id,id=>new RecoveredPlayerView(id,state.Tick,0,snapshots[id],state.Tick,0,prompts[id]));
var before=MatchRecoveryValidator.Validate(room,0,[],[],views,state,state.Tick);var after=MatchRecoveryValidator.Validate(room,0,[],[],views,restored,restored.Tick);
var json=new JsonSerializerOptions(JsonSerializerDefaults.Web){WriteIndented=true};
await File.WriteAllTextAsync(args[0],JsonSerializer.Serialize(new{status="READONLY_ADJACENT_HAND_ORDER_DIAGNOSTIC_NOT_FIX_OR_CERTIFICATION",actualRuleInputs=RuleInputIdentity.Current,allJsonValuesIdentical=JsonNode.DeepEquals(original,changed),originalHash=MatchStateHasher.Hash(state),restoredHash=MatchStateHasher.Hash(restored),beforeErrors=before,afterErrors=after,snapshotsEqual=Same(snapshots,coldSnapshots),promptsEqual=Same(prompts,coldPrompts),originalHandKeys=state.PendingEffectPlay.RevealedHand.Cards.Keys,coldHandKeys=restored.PendingEffectPlay!.RevealedHand!.Cards.Keys,originalPrompt=prompts["P1"],coldPrompt=coldPrompts["P1"],initialState=initial,originalState=state,oldHistoryAndDatabasesNotReadOrWritten=true},json));
Console.WriteLine($"ADJACENT_HAND_ORDER before={before.Count} after={after.Count}; values={JsonNode.DeepEquals(original,changed)} hash={MatchStateHasher.Hash(state)==MatchStateHasher.Hash(restored)} snapshots={Same(snapshots,coldSnapshots)} prompts={Same(prompts,coldPrompts)}");
bool Same<T>(T a,T b)=>JsonNode.DeepEquals(JsonSerializer.SerializeToNode(a),JsonSerializer.SerializeToNode(b));
static JsonNode Reorder(JsonNode node)=>node is JsonObject obj?new JsonObject(obj.Reverse().Select(p=>KeyValuePair.Create(p.Key,p.Value is null?null:Reorder(p.Value)))):node is JsonArray array?new JsonArray(array.Select(v=>v is null?null:Reorder(v)).ToArray()):node.DeepClone();
