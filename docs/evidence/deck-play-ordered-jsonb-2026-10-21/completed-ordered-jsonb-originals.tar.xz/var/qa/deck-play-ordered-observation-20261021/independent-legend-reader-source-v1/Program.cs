using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

Check(args.Length==2&&!File.Exists(args[1]),"Exact evidence directory and fresh independent output required.");
var work=Path.GetFullPath(args[0]);var output=Path.GetFullPath(args[1]);var json=new JsonSerializerOptions(JsonSerializerDefaults.Web){WriteIndented=true};
var settings=new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));Check(settings.Host=="127.0.0.1"&&settings.Port==55486&&settings.Database=="riftbound_acceptance"&&settings.Username=="codex_riftbound_audit","Only own audit database.");settings.Options="-c default_transaction_read_only=on";await using var source=NpgsqlDataSource.Create(settings.ConnectionString);
var results=new List<object>();var rooms=new List<string>();var totalStates=0;var totalSnapshots=0;var totalPrompts=0;var totalCommands=0;var totalEvents=0;var rejections=0;
foreach(var branch in new[]{"legend-first","battlefield-first"})
{
    var directory=Path.Combine(work,"candlelit-legend-pending",branch);using var receipt=JsonDocument.Parse(File.ReadAllText(Path.Combine(directory,"receipt.json")));var room=receipt.RootElement.GetProperty("room").GetString()!;rooms.Add(room);
    var initial=JsonSerializer.Deserialize<MatchState>(File.ReadAllText(Path.Combine(directory,"explicit-original-controlled-initial.json")),json)!;
    var frame=await new PostgresMatchRecoveryStore(source).LoadAsync(room,default)??throw new Exception("Real retained SQL frame required.");using var original=Read(Path.Combine(directory,"final-original-frame.json.gz"));
    Check(Same(original.RootElement,JsonSerializer.SerializeToElement(frame,json)),"Every original final SQL frame field/null/omission equals the actual independent read.");
    Check(frame.IsConsistent&&frame.Commands.Count==receipt.RootElement.GetProperty("commands").GetInt32()&&frame.Events.Count==receipt.RootElement.GetProperty("events").GetInt32()&&initial.RoomId==room&&initial.Tick==0&&initial.RuleInputs==RuleInputIdentity.Current&&frame.AuthoritativeState!.RuleInputs==RuleInputIdentity.Current,"Exact controlled initial and current frozen identity.");
    Check(frame.ReplayInitialState is {Tick:0,CardObjects.Count:0}&&!Same(JsonSerializer.SerializeToElement(initial,json),JsonSerializer.SerializeToElement(frame.ReplayInitialState,json)),"Original blank replay metadata remains separate; explicit original controlled initial is supplied only to the independent replay.");
    using var intents=JsonDocument.Parse(File.ReadAllText(Path.Combine(directory,"all-original-accepted-intents.json")));Check(intents.RootElement.GetArrayLength()==frame.Commands.Count,"All original intents retained.");
    for(var i=0;i<frame.Commands.Count;i++)Check(frame.Commands[i].Accepted&&frame.Commands[i].RuleInputs==RuleInputIdentity.Current&&frame.Commands[i].PlayerId==intents.RootElement[i].GetProperty("actor").GetString()&&Same(frame.Commands[i].RawCommand!.Value,intents.RootElement[i].GetProperty("rawCommand")),"Every actor/full raw command and identity equals the original accepted input.");
    var states=new Dictionary<(long,long),MatchState>();var counts=new Dictionary<string,int>();
    await using(var connection=await source.OpenConnectionAsync())
    {
        Check((string)(await new NpgsqlCommand("show transaction_read_only",connection).ExecuteScalarAsync())! =="on","Actual read-only SQL session.");
        await using(var q=new NpgsqlCommand("select last_event_sequence,payload::text from state_snapshots where match_id=@room order by id",connection))
        {
            q.Parameters.AddWithValue("room",room);await using var rows=await q.ExecuteReaderAsync();
            while(await rows.ReadAsync())
            {
                var raw=rows.GetString(1);var state=JsonSerializer.Deserialize<MatchState>(raw,json)!;
                Check(JsonNode.DeepEquals(JsonNode.Parse(raw),JsonSerializer.SerializeToNode(state,json))&&state.RuleInputs==RuleInputIdentity.Current&&states.TryAdd((state.Tick,rows.GetInt64(0)),state),"All original authority fields/nulls, current identity and tick/event-sequence identity survive independent read.");
                foreach(var item in state.StackItems.Where(i=>i.InsightContext?.Kind=="CONQUEST_LOOK"))Check(item.ControllerId=="P1"&&item.SourceObjectId=="BF"&&item.InsightContext is {Count:2,BattlefieldObjectId:"BF",ControllerId:"P1"}&&item.InsightContext.SourceGeneration==state.CardObjects["BF"].ObjectGeneration&&state.CardObjects["BF"].OwnerId=="P2","Literal captured conqueror, printed source/count/generation, and distinct battlefield owner.");
                if(state.PendingCardChoice is {ChoiceWindow:"INSIGHT"} choice)Check(choice.PlayerId=="P1"&&choice.RequiredCount==0&&choice.MaxCount==2&&choice.LegalObjectIds.SequenceEqual(branch=="legend-first"?new[]{"DRAW3","DRAW2"}:new[]{"DRAW1","DRAW2"}),"Literal private original top pair for this selected resolution order.");
                if(state.PendingCardChoice is {ChoiceWindow:"DECK_PLAY_SELECTION"} selection)Check(selection.PlayerId=="P1"&&selection.LegalObjectIds.SequenceEqual(branch=="legend-first"?new[]{"DRAW1","DRAW2"}:new[]{"DRAW2","DRAW1"})&&state.StackItems.Last().DeckPlaySequence!.Viewed["P1"].Select(c=>c.ObjectId).SequenceEqual(selection.ContextObjectIds),"Literal public reveal and array order at the original selection.");
                var tree=JsonNode.Parse(raw)!;foreach(var row in tree["stackItems"]!.AsArray().Where(n=>n?["deckPlaySequence"] is not null))foreach(var captured in row!["deckPlaySequence"]!["viewed"]!.AsObject())Check(captured.Value is JsonArray,"Every actual SQL ordered capture is a JSON array.");
            }
        }
        Check(states.Count==frame.Commands.Count&&frame.Commands.All(c=>states.ContainsKey((c.CompletedTick,c.CompletedEventSequence))),"Each accepted command retains its exact authoritative historical row.");
        var latest=frame.Commands.GroupBy(c=>c.CompletedTick).Select(g=>g.OrderBy(c=>c.CompletedEventSequence).Last()).ToArray();var expected=latest.SelectMany(c=>new[]{"P1","P2"}.Select(p=>(c.CompletedTick,c.CompletedEventSequence,p))).ToHashSet();
        foreach(var table in new[]{"snapshots","action_prompts"})
        {
            var column=table=="snapshots"?"snapshot_tick":"prompt_tick";await using(var constraint=new NpgsqlCommand($"select pg_get_constraintdef(oid) from pg_constraint where conrelid='{table}'::regclass and contype='u'",connection))Check((string)(await constraint.ExecuteScalarAsync())! ==$"UNIQUE (match_id, player_id, {column})","Actual existing private storage key is viewer/tick.");
            await using var q=new NpgsqlCommand($"select player_id,last_event_sequence,payload::text from {table} where match_id=@room order by id",connection);q.Parameters.AddWithValue("room",room);await using var rows=await q.ExecuteReaderAsync();var actual=new HashSet<(long,long,string)>();
            while(await rows.ReadAsync())
            {
                var actor=rows.GetString(0);var sequence=rows.GetInt64(1);var raw=rows.GetString(2);using var doc=JsonDocument.Parse(raw);var tick=doc.RootElement.GetProperty(table=="snapshots"?"tick":"snapshotTick").GetInt64();Check(states.TryGetValue((tick,sequence),out var state)&&actual.Add((tick,sequence,actor)),"Each private original row binds its original authority, sequence, tick and viewer.");
                var typed=table=="snapshots"?JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<SnapshotDto>(raw,json),json):JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<ActionPromptDto>(raw,json),json);Check(JsonNode.DeepEquals(JsonNode.Parse(raw),typed),"Every private field/null and conditional omission survives typed read.");
                var projection=table=="snapshots"?JsonSerializer.SerializeToNode(ResolutionResult.BuildSnapshots(state!)[actor],json):JsonSerializer.SerializeToNode(ResolutionResult.BuildPrompts(state!)[actor],json);Check(JsonNode.DeepEquals(JsonNode.Parse(raw),projection),"Every original private value equals its exact historical state projection.");
                var other=actor=="P1"?"P2":"P1";var revealed=state!.PendingCardChoice?.ChoiceWindow=="DECK_PLAY_SELECTION"?new[]{"DRAW1","DRAW2"}:Array.Empty<string>();foreach(var id in state.PlayerZones[other].MainDeck.Concat(state.PlayerZones[other].Hand).Except(revealed))Check(!raw.Contains("\""+id+"\"",StringComparison.Ordinal),"Independent literal check: opponent hidden object identity absent except the currently public original legend reveal.");Check(!doc.RootElement.TryGetProperty("openingSeed",out _),"Private opening seed not exposed.");
            }
            Check(actual.SetEquals(expected),"Both players retain exactly the latest original projection at each tick according to the actual existing key; no missing historical authority.");counts[table]=actual.Count;
        }
    }
    foreach(var pair in states)
    {
        var commands=frame.Commands.Where(c=>c.CompletedEventSequence<=pair.Key.Item2).ToArray();var events=frame.Events.Where(e=>e.EventSequence<=pair.Key.Item2).ToArray();
        var verified=await MatchActionLogReplayer.VerifyFinalStateAsync(initial,commands,pair.Value,new CoreRuleEngine(),default,events);Check(verified.IsMatch,"Every original authority history independently replays from its exact original controlled initial: "+string.Join(';',verified.Errors));
    }
    using var captured=Read(Path.Combine(directory,"all-pending-confirmed-before-look-original-frame.json.gz"));var capturedFrame=captured.RootElement.Deserialize<MatchRecoveryFrame>(json)!;var capturedState=capturedFrame.AuthoritativeState!;
    Check(capturedState.CardObjects["LEGEND"].IsExhausted&&capturedState.PendingCardChoice is null&&capturedState.PriorityPlayerId=="P1"&&capturedState.StackItems.Count==2&&capturedState.StackItems.Single(i=>i.SourceObjectId=="LEGEND").TriggerCost is {Source.ObjectId:"LEGEND",Source.Generation:0},"Literal original source cost confirms both pending abilities before either LOOK or REVEAL.");
    Check(capturedState.StackItems.Last().SourceObjectId==(branch=="legend-first"?"LEGEND":"BF")&&frame.Commands.Take(capturedFrame.Commands.Count).Select(c=>c.ClientIntentId).SequenceEqual(capturedFrame.Commands.Select(c=>c.ClientIntentId)),"Selected resolution order and exact original accepted prefix retained.");
    using var revealedOriginal=Read(Path.Combine(directory,"legend-public-selection-original-frame.json.gz"));var revealedFrame=revealedOriginal.RootElement.Deserialize<MatchRecoveryFrame>(json)!;var revealedState=revealedFrame.AuthoritativeState!;var item=revealedState.StackItems.Last();var context=item.DeckPlaySequence!;
    var literal=branch=="legend-first"?new[]{"DRAW1","DRAW2"}:new[]{"DRAW2","DRAW1"};Check(context.Viewed["P1"].Select(c=>c.ObjectId).SequenceEqual(literal),"Literal non-sorted original revealed order is an array in actual JSONB.");
    foreach(var mutation in new[]{"order","duplicate","generation","outside"})
    {
        var changed=mutation switch {"order"=>context.Viewed["P1"].Reverse().ToArray(),"duplicate"=>new[]{context.Viewed["P1"][0],context.Viewed["P1"][0]},"generation"=>new[]{context.Viewed["P1"][0] with {Generation=99},context.Viewed["P1"][1]},_=>new[]{new ObjectBinding("DRAW3",0),context.Viewed["P1"][1]}};
        var forged=revealedState with {StackItems=revealedState.StackItems.Take(revealedState.StackItems.Count-1).Append(item with {DeckPlaySequence=context with {Viewed=new Dictionary<string,IReadOnlyList<ObjectBinding>>(context.Viewed){["P1"]=changed}}}).ToArray()};
        Check(MatchRecoveryValidator.Validate(room,revealedFrame.LastEventSequence,revealedFrame.Commands,revealedFrame.Events,revealedFrame.PlayerViews,forged,revealedFrame.CurrentTick).Count>0,"Independent ordered capture mutation rejected: "+mutation);rejections++;
    }
    var final=frame.AuthoritativeState!;var selected=branch=="legend-first"?"DRAW1":"DRAW2";
    Check(final.Status==MatchStatuses.InProgress&&final.PlayerScores["P1"]==1&&final.PlayerScores["P2"]==0&&final.PlayerZones["P1"].Base.Contains(selected)&&final.PlayerZones["P1"].MainDeck.SequenceEqual(branch=="legend-first"?new[]{"DRAW2","DRAW3"}:new[]{"DRAW3","DRAW1"}),"Literal distinct final original card and deck for each chosen resolution order.");
    Check(final.RunePools["P1"].Mana==16&&final.RunePools["P1"].Power==10&&final.RngCursor==initial.RngCursor&&final.StackItems.Count==0&&final.PendingCardChoice is null&&final.PendingEffectPlay is null,"Printed four mana and zero power, no extra RNG or residual permission.");
    Check(frame.Events.Count(e=>e.Event.Kind=="CARDS_REVEALED")==1&&frame.Events.All(e=>e.Event.Kind is not("CARD_DRAWN" or "MAIN_DECK_BURNED_OUT")),"Exactly the original legend public reveal; battlefield LOOK causes no extra draw/reveal/burnout.");
    totalStates+=states.Count;totalSnapshots+=counts["snapshots"];totalPrompts+=counts["action_prompts"];totalCommands+=frame.Commands.Count;totalEvents+=frame.Events.Count;results.Add(new{branch,room,commands=frame.Commands.Count,events=frame.Events.Count,states=states.Count,snapshots=counts["snapshots"],prompts=counts["action_prompts"],allFieldsAndAllOriginalHistoricalReplaysExact=true});
}
await File.WriteAllTextAsync(output,JsonSerializer.Serialize(new{status="PASS_INDEPENDENT_CURRENT_CN16_BOTH_LEGEND_PENDING_ORDERS_ALL_SQL_HISTORY_PRIVATE_FIELDS_AND_EVERY_EXPLICIT_INITIAL_REPLAY",rooms,cases=2,commands=totalCommands,events=totalEvents,authoritativeHistoricalStates=totalStates,privateSnapshots=totalSnapshots,privatePrompts=totalPrompts,independentStructuralRejections=rejections,actualRuleInputs=RuleInputIdentity.Current,results,actualReadOnlyConnection=true,originalBlankReplayMetadataNotRewritten=true,visibleNormalOpeningWindowsOrWholePrintingAcceptance=false},json));
Console.WriteLine($"LEGEND_CURRENT_INDEPENDENT_PASS {totalCommands} commands {totalEvents} events {totalStates} states {totalSnapshots} snapshots {totalPrompts} prompts {rejections} structural rejects");
bool Same(JsonElement left,JsonElement right)=>JsonNode.DeepEquals(JsonNode.Parse(left.GetRawText()),JsonNode.Parse(right.GetRawText()));
static JsonDocument Read(string path){using var zip=new GZipStream(File.OpenRead(path),CompressionMode.Decompress);return JsonDocument.Parse(zip);}
static void Check(bool value,string message){if(!value)throw new Exception(message);}
