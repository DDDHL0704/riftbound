from pathlib import Path
import collections,datetime,hashlib,json,xml.etree.ElementTree as ET

w=Path(__file__).resolve().parent;root=w.parents[2];load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
owner=load(w/'only-check-owner-terminal-v1.json');start=load(w/'only-check-start-inputs-v1.json');summary=load(w/'only-check-v1/summary.json');plan=load(w/'only-check-v1/plan.json')
assert owner['exitCode']==0 and owner['status']=='CHECK_PROCESS_EXIT_ZERO_INDEPENDENT_PARITY_STILL_REQUIRED'
for field in ['all3321SourceHashesUnchanged','allSourceModesUnchanged','allConformanceInputPayloadsUnchanged','all23NativePayloadsUnchanged','boundIdleAssertionEnded']:assert owner[field],field
assert summary['status']=='PASSED' and summary['total']==13230 and plan['discoveredMethods']==7645
assert sum(len(s['methods']) for s in plan['shards'])==7504
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def read(path):
 tree=ET.parse(path);defs={d.attrib['id']:d.find('t:TestMethod',ns).attrib for d in tree.findall('.//t:UnitTest',ns)};cases=collections.Counter();methods=set()
 for row in tree.findall('.//t:UnitTestResult',ns):
  assert row.attrib['outcome']=='Passed';d=defs[row.attrib['testId']];cases[row.attrib['testName']]+=1;methods.add(d['className']+'.'+d['name'])
 counters=tree.find('.//t:Counters',ns).attrib;assert int(counters['total'])==int(counters['passed'])==sum(cases.values()) and counters['failed']=='0' and counters['notExecuted']=='0'
 return cases,methods
baseline=root/start['originalBaselineTrx'];current=w/'only-check-v1/check/results.trx';before_cases,before_methods=read(baseline);cases,methods=read(current)
assert sum(before_cases.values())==13219 and len(before_methods)==7501 and not before_cases-cases and before_methods<=methods
added=cases-before_cases;added_methods=methods-before_methods;assert sum(added.values())==11 and len(added_methods)==3 and all('.DeckPlayObservationOrderTests.' in name for name in added)
assert sum(cases.values())==13230 and len(methods)==7504 and methods=={m for shard in plan['shards'] for m in shard['methods']}
assert len(start['sourceInputHashes'])==3321 and all(sha(root/p)==h for p,h in start['sourceInputHashes'].items())
assert all(oct((root/p).stat().st_mode&0o777)==mode for p,mode in start['sourceInputModes'].items())
retention=load(w/'original-full-tests-sql-and-focus-union-retention-v1.json');assert retention['originalFullMethods']==143 and retention['allFullGameSources'] and retention['original110Pairs11Decks424242Retained']
before=load(w/'before-ordered-observation-change-v1.json')['originalSqlCases'];after=load(root/'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json');assert len(before['cases'])==49 and after['cases'][:49]==before['cases'] and len(after['cases'])==50
result={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'CHECK_AND_EXACT_CASE_METHOD_PARITY_PASS','oldCasesPreserved':True,'oldMethodsPreserved':True,'frozenInputsUnchanged':True,'failed':0,'skipped':0,'profile':'check','baseCommit':start['baseCommit'],'actualCases':13230,'actualMethods':7504,'fullDiscoveryMethodsNotExecutedCount':7645,'allOriginal13219CaseNameCountMultisetAnd7501MethodsPreserved':True,'newCases':11,'newMethods':3,'addedCases':list(added.elements()),'addedMethods':sorted(added_methods),'allOriginalMethodsTheoryRows143FullMethodsNineSources110Pairs11Decks424242VictoryReplayAssertionsRetained':True,'fullGamePrivacyAssertionOnlyAdaptsOrderedBindingLookup':True,'allOriginal49SqlExecutionIdentitiesAndOrderRetainedOnly50thAppended':True,'all3321SourceHashesAndModes1419ConformanceAnd23NativeInputsStableThroughoutCheck':True,'baselineTrxSha256':sha(baseline),'actualTrxSha256':sha(current),'actualTestAssemblySha256':plan['testAssemblySha256'],'onlyOneCheckForCoherentBatch':True,'summary':summary,'owner':owner,'fixedCommitFullCurrentVisibleAndPhysicalWindows':'OPEN','wholePrintingOrAuditCertified':False}
with (w/'check-original-case-method-and-input-retention-v1.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print('PASS solecheck13230/7504; original13219/7501 exact retained+11/3; source/runtime stable;143full/110pairs/11decks/424242/assertions;49old SQL plus50th')
