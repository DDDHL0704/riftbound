from pathlib import Path
import copy,datetime,gzip,hashlib,json,re,tarfile

root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(path,value):
 with path.open('x') as stream:json.dump(value,stream,ensure_ascii=False,indent=2);stream.write('\n')
def pin(path,role=None):
 result={'path':str(path.relative_to(root)),'sha256':sha(path)}
 if role:result['role']=role
 return result
check=load(w/'check-original-case-method-and-input-retention-v1.json');sql=load(w/'actual-two-ordered-legend-sql-owner-terminal-v1.json');reader=load(w/'independent-two-ordered-legend-all-history-v1.json');source=load(w/'current-ordered-deck-play-source-review-and-finite-scope-v1.json');frozen=load(w/'current-ordered-sql-frozen-inputs-v1.json')
assert check['status']=='CHECK_AND_EXACT_CASE_METHOD_PARITY_PASS' and check['actualCases']==13230 and check['actualMethods']==7504
assert sql['status'].startswith('PASS_CURRENT_CN16_TWO_LEGEND_') and sql['commands']==reader['commands']==26 and sql['events']==reader['events']==78 and sql['ownPostgresSmartStopped']
assert sql['allOriginal250AuditSevenTablesExactAtStop'] and sql['allOriginal54NativeSevenTablesExactAtStop'] and reader['authoritativeHistoricalStates']==26 and reader['privateSnapshots']==reader['privatePrompts']==52
assert all(sha(root/p)==h for p,h in frozen['sourceInputHashes'].items())
mp=root/'docs/audit/current-manifest.json';manifest=load(mp);rp=root/manifest['inputs']['reviews']['path'];reviews=load(rp)
assert len(reviews['reviews'])==152 and len(manifest['reviewContexts'])==67 and len(manifest['acceptanceGates'])==245 and len(manifest['laterSourceDeltas'])==7
old_manifest=copy.deepcopy(manifest);old_reviews=copy.deepcopy(reviews)
for path in [mp,rp,root/'docs/PROJECT_STATUS.md']:
 assert gzip.decompress((w/'prior-ordered-publication-governance-v1'/(path.name+'.gz')).read_bytes())==path.read_bytes()
ev=root/'docs/evidence/deck-play-ordered-jsonb-2026-10-21';ev.mkdir(exist_ok=False)
standalone={
 'check-original-case-method-and-input-retention.json':'check-original-case-method-and-input-retention-v1.json',
 'focus-original-methods-and-assertion-retention.json':'original-full-tests-sql-and-focus-union-retention-v1.json',
 'real-sql-both-legend-orders-terminal.json':'actual-two-ordered-legend-sql-owner-terminal-v1.json',
 'independent-both-orders-all-historical-replays.json':'independent-two-ordered-legend-all-history-v1.json',
 'current-source-finite-scope-review.json':'current-ordered-deck-play-source-review-and-finite-scope-v1.json',
 'finite-current-consumers-no-old-migration.json':'finite-current-deck-play-consumer-and-no-migration-inventory-v1.json',
 'prior-c2-full-independent-verification.json':'ci-c2-entire-full-independent-verification-v2.json',
 'prior-c2-original-terminal-hash-comparison.json':'ci-c2-vs-f470-original-terminal-hash-comparison-v1.json',
 'completed-duplicate-sql-extraction-retirement.json':'completed-ci-extraction-exact-original-retention-before-retirement-v1.json',
 'completed-helper-staging-retirement.json':'completed-bounded-helper-generated-staging-retirement-v1.json',
 'next-hand-presentation-finding.json':'next-revealed-hand-exact-finding-and-source-disposition-v1.json',
 'next-hand-presentation-original-diagnostic.json':'next-adjacent-revealed-hand-order-original-diagnostic-v2.json'}
for name,rel in standalone.items():(ev/name).write_bytes((w/rel).read_bytes())
focus=load(w/'original-full-tests-sql-and-focus-union-retention-v1.json');focus.update(newMethodNames=check['addedMethods'],newConformanceCases=11,newConformanceMethods=3,wholePrintingCertified=False)
write(ev/'focus-executed-distinct-scope.json',focus)
stale=load(w/'old-context-current-input-staleness-exact-audit-v1.json')['exactSevenContextsRequireOnlyCurrentInputRefresh'];assert len(stale)==7
delta={'atUtc':now(),'status':'SEVEN_CURRENT_INPUT_BINDINGS_ONLY_REFRESH_OLD_EVIDENCE_AND_SCOPE_RETAINED','records':[{'id':x['id'],'changedCurrentImplementationInputs':x['changedCurrentImplementationInputs']} for x in stale],'originalComplete67ContextsAnd152Reviews':{'localOriginalPath':str((w/'prior-ordered-publication-governance-v1').relative_to(root)),'retainedAsExactArchiveMembers':True},'oldReviewSourceDatesScopesAndEvidenceNotRelabeled':True,'newFixedFullAndCurrentProductStillOpen':True}
write(ev/'seven-context-current-input-refresh.json',delta)
members=[];excluded=[]
for path in sorted(w.rglob('*')):
 if not path.is_file():continue
 parts=path.relative_to(w).parts
 if {'bin','obj'}&set(parts) or any('-runtime-' in part for part in parts[:-1]):continue
 raw=path.read_bytes()
 try:decoded=gzip.decompress(raw) if path.suffix=='.gz' else raw
 except (OSError,EOFError):decoded=raw
 if re.search(rb'"(?:playerKey|reconnectToken|sessionToken|password)"\s*:\s*"[^"\s]+"',decoded,re.I):
  excluded.append({'path':str(path.relative_to(root)),'sha256':sha(path),'bytes':len(raw),'reason':'credential-bearing operational original retained locally'});continue
 members.append(path)
old=w.parent/'fixed-39eacb2e-candlelit-pending-20261021'
for name in ['legend-pending-additional-source-review-preflight-v1.json','legend-current-spiritforged-faq-original-readback-v1.json','current-ogins-and-spiritforged-errata-original-readback-v1.json']:
 members.append(old/name)
for name in ['DOC-13-p4.png','DOC-13-p5.png']:members.append(old/'current-rule-full-pages-v1'/name)
archive=ev/'completed-ordered-jsonb-originals.tar.xz';rows=[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in members];assert len({x['path'] for x in rows})==len(rows)
with tarfile.open(archive,'x:xz',preset=6) as tar:
 for path in members:tar.add(path,arcname=str(path.relative_to(root)),recursive=False)
with tarfile.open(archive,'r:xz') as tar:
 assert {p.name for p in tar.getmembers()}=={r['path'] for r in rows}
 for row in rows:
  raw=tar.extractfile(row['path']).read();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
write(ev/'archive-map.json',{'atUtc':now(),'archive':pin(archive),'members':rows,'explicitOperationalExclusionsRetainedLocally':excluded,'allMemberBytesHashesAndClosedSetVerified':True,'runtimeAppsInstallersAndExistingPrimaryPdfOriginalsReferencedLocallyNotDuplicated':True,'adjacentHandPresentationDiagnosisIsSeparateOpenFindingNotCurrentFixCertification':True})
implementation=[pin(root/p,'implementation') for p in ['src/Riftbound.Engine/CoreRuleEngine.DeckPlaySequence.cs','src/Riftbound.Engine/CoreRuleEngine.EffectPlay.cs','src/Riftbound.Engine/MatchRecovery.cs','src/Riftbound.Engine/CoreRuleEngine.DeckObservation.cs']]
verification=[pin(root/p,'verification-source') for p in ['tests/Riftbound.ConformanceTests/DeckPlayObservationOrderTests.cs','tests/Riftbound.ConformanceTests/OfficialReinforcementsTests.cs','tests/Riftbound.ConformanceTests/EndDeckPlayTests.cs','tests/Riftbound.ConformanceTests/FullGameEndToEndTests.cs','tests/Riftbound.PostgresAcceptance/CandlelitLegendPendingSqlAcceptance.cs','tests/Riftbound.PostgresAcceptance/Program.cs','tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json','scripts/tests/test_sql_ci_gate.py']]
sm={'atUtc':now(),'status':'BOUNDED_CN16_ORDERED_DECK_PLAY_JSONB_FIX_AND_TWO_PENDING_ORDERS_CHECK_PASS_FIXED_FULL_PRODUCT_OPEN','region':'CN','language':'zh-CN','observedAsOf':'2026-10-21','adoptedCoreEffectiveDate':'2026-10-16','exactSourceReview':source,'ledgerFormattingOnlyRawPhysicalPrintingsPreserved':load(w/'publication-exact-source-and-gate-preflight-v1.json')['formattingOnlyNoVariantSetDenominatorMerges'],'officialSourceIntakes':[load(w/'current-shared-ordered-source-intake-v1.json'),load(w/'current-supplemental-sequence-source-intake-v1.json')],'baseCommit':frozen['parentCommit'],'implementationIncludesDeclaredUncommittedChanges':True,'actualRuleInputs':reader['actualRuleInputs'],'implementation':implementation,'verificationSources':verification,'allOriginal49SqlIdsAndOrderRetained':True,'only50thSqlIdentityAdded':'candlelit-legend-pending','allOriginal152ReviewObjectsAndOldSemanticScopesRetained':True,'sevenCurrentInputBindingsOnlyRefreshed':pin(ev/'seven-context-current-input-refresh.json'),'archive':pin(archive),'wholePrintingCertified':False,'fixedCommitFullVisibleHardwarePairAndPhysicalWindows':'OPEN','noOldDevelopmentMatchMigration':True}
write(ev/'source-manifest.json',sm);sp=pin(ev/'source-manifest.json','source-manifest')
identity='deck-play-ordered-jsonb-current-cn16-2026-10-21';assert identity not in manifest['reviewContexts']
subjects=[x['printing'].replace('·','-').upper() for x in source['exactApiPrintingIdentities']];rule_ids=source['ruleRecords']
reviews['reviews'].append({'id':identity,'scope':'Only ordered observed bindings across ten finite DeckPlaySequence consumers and two exact Candlelit291/Reksai187 controlled pending orders in current CN16; original semantic scopes and whole-printing/final-product obligations remain open.','subjects':subjects,'ruleRecords':rule_ids,'pendingRuleRecords':[],'status':'BOUNDED_ORDER_CAPTURE_AND_SQL2_26_78_INDEPENDENT_EVERY_HISTORY_CHECK13230_PASS_FIXED_FULL_PRODUCT_OPEN','sourceManifest':sp,'auditDocument':'docs/DECK_PLAY_ORDERED_JSONB_AUDIT_2026-10-21.md','validation':{'newConformanceCases':11,'newConformanceMethods':3,'distinctFocusCases':275,'distinctFocusMethods':123,'checkCases':13230,'checkMethods':7504,'sqlCommands':26,'sqlEvents':78,'sqlColdRecoveries':26,'allOriginal49SqlIdsAnd143FullMethodsRetained':True,'wholeCardCertification':False},'exclusions':['Full semantics of all ten consumers, copies, indirect consumers and all source gaps','Current fixed complete CI and corresponding visible paired native controls, SQL/reconnect/normal score/full replay and physical Windows','Adjacent revealed-hand viewedCards presentation and independent source-provenance finding remains separate OPEN']})
branches=[]
for bid,scope in [('ORDERED_DECK_OBSERVATION_IDENTITY_GENERATION_JSONB','Ordered bindings retain exact observation order and generations under unordered JSON object serialization; negative cases still reject.'),('CANDLELIT_REKSAI_CN16_LEGEND_FIRST','Both original pending abilities confirm source exhaust before legend first reveal/play then original battlefield private look/order.'),('CANDLELIT_REKSAI_CN16_BATTLEFIELD_FIRST','Both original pending abilities confirm source exhaust before original battlefield reverse order then actual JSONB cold reveal/play of the new first original card.')]:
 branches.append({'id':bid,'state':'RECORDED','scope':scope,'sourceRefs':subjects+rule_ids,'sourceManifest':sp,'semanticReview':{'state':'BOUNDED_CURRENT_SOURCE_ORDER_AND_TWO_PENDING_ORDER_BRANCHES','wholeClauseOrPrintingCertified':False},'implementation':{'state':'EXISTING_FINITE_SHARED_CONTEXT_NOW_USES_ORDERED_IDENTITY_GENERATION_BINDINGS'},'testExecution':{'state':'ACTUAL_FOCUS_SQL_COLD_DEDUP_INDEPENDENT_ALL_HISTORY_AND_REPLAY_PASS'},'fixedCommitCi':{'state':'PENDING_NEW_FIXED_FULL'},'productAcceptance':{'state':'OPEN'},'decision':{'state':'OPEN','reason':'Bounded tests do not close fixed full, all semantics or candidate product obligations.'},'wholePrintingCertified':False,'existingAcceptanceGateDependencies':['DECK_OBSERVATION_FAMILY_ALL_APPLICABLE_CONSUMERS','FIXED_CURRENT_CANDIDATE_FULL','USER_WINDOWS_RUNTIME']})
manifest['reviewContexts'][identity]={'evidenceCommit':frozen['parentCommit'],'currentImplementationCommit':frozen['parentCommit'],'currentImplementationIncludesUncommittedChanges':True,'ciState':'PENDING','ciReceipts':[],'region':'CN','language':'zh-CN','applicableAsOf':'2026-10-21','adoptedCoreEffectiveDate':'2026-10-16','sourceManifest':sp,'implementation':implementation,'verificationSources':verification,'evidence':[pin(ev/'focus-executed-distinct-scope.json','focus'),pin(ev/'check-original-case-method-and-input-retention.json','check'),pin(ev/'real-sql-both-legend-orders-terminal.json','sql'),pin(ev/'independent-both-orders-all-historical-replays.json','independent-sql')],'branches':branches}
for row in stale:
 context=manifest['reviewContexts'][row['id']];assert context==row['oldContext']
 for change in row['changedCurrentImplementationInputs']:
  matches=[p for p in context['implementation'] if p['path']==change['path']];assert len(matches)==1 and matches[0]['sha256']==change['beforeSha256'];matches[0]['sha256']=change['afterSha256']
 context.update(currentImplementationCommit=frozen['parentCommit'],currentImplementationIncludesUncommittedChanges=True,ciState='PENDING',currentOrderedObservationInputRefresh=pin(ev/'seven-context-current-input-refresh.json','current-input-refresh'))
gate=next(g for g in manifest['acceptanceGates'] if g['id']=='DECK_OBSERVATION_FAMILY');gate['currentAdjacentRevealedHandPresentationObservation']=pin(ev/'next-hand-presentation-finding.json','separate-open-presentation-finding');gate['currentAdjacentFindingBoundary']='Only controlled offline viewedCards order differs; state/snapshot/selection/structural recovery remain valid. Real SQL/current source adoption/visible and fixed verification remain OPEN. See issue79.'
manifest['currentOrderedDeckPlayJsonbInputChange']=sp;manifest['precedingFixedC2ActualCompleteFullCiReadback']=pin(ev/'prior-c2-full-independent-verification.json','prior-fixed-full')
assert reviews['reviews'][:152]==old_reviews['reviews'] and all(manifest['reviewContexts'][k]==v for k,v in old_manifest['reviewContexts'].items() if k not in {x['id'] for x in stale})
assert all(g==old_manifest['acceptanceGates'][i] for i,g in enumerate(manifest['acceptanceGates']) if g['id']!='DECK_OBSERVATION_FAMILY')
for key,value in old_manifest['acceptanceGates'][next(i for i,g in enumerate(old_manifest['acceptanceGates']) if g['id']=='DECK_OBSERVATION_FAMILY')].items():assert gate[key]==value
assert manifest['certificationScope']==old_manifest['certificationScope'] and manifest['laterSourceDeltas']==old_manifest['laterSourceDeltas'] and manifest['cardCoverageManifest']==old_manifest['cardCoverageManifest']
rp.write_text(json.dumps(reviews,ensure_ascii=False,indent=2)+'\n');manifest['inputs']['reviews']['sha256']=sha(rp);mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
text=(w/'ordered-deck-play-audit-draft-v1.md').read_text().replace('{{SOLE_CHECK_RESULT}}','唯一一次 check 实际通过 13,230 例 / 7,504 个执行方法，零失败、零跳过。原13,219例名称/次数多重集合和7,501方法全部保留，只增加11例/3方法；3,321源文件与模式、1,419份Conformance及23份原生运行载荷全程稳定。全发现7,645方法不是本地check执行数；新固定full另行执行。').replace('{{GOVERNANCE_RESULT}}','本批153审查/68上下文/245门禁/七来源增量。原152完整审查对象不变，60个未受影响上下文原样保留；七上下文只刷新当前源码绑定，原完整对象、来源日期、范围、旧测试/CI证据在归档中保留，新候选仍待full。244其他门禁原值不变，既有观察族门禁只追加独立OPEN的手牌展示稳定性发现，不新建同义门禁或提升原状态。统一义务原16952身份完整保留，只追加三条限定行为至16955。')
assert '{{' not in text;doc=root/'docs/DECK_PLAY_ORDERED_JSONB_AUDIT_2026-10-21.md';assert not doc.exists();doc.write_text(text)
status=root/'docs/PROJECT_STATUS.md';old_status=status.read_text();prefix='# 当前项目状态\n\n';assert old_status.startswith(prefix)
lead='2026-10-21 本批：[有序牌堆观察与JSONB恢复](DECK_PLAY_ORDERED_JSONB_AUDIT_2026-10-21.md)。共享上下文以有序身份/代际数组保存观察记录，原11命令28事件失败局与等值同哈希诊断保留，无旧局迁移；十个精确消费者、原权限/费用/独立安全检查保留。新增11例/3方法，去重275/123定向及原圣殿完整胜利回放、74工具通过；唯一check13230/7504全过，原13219/7501全部保留，3321源/模式、1419Conformance及23原生载荷稳定。原143完整方法/110配对/十一牌组/424242和全部胜利回放断言、原49 SQL身份/顺序保留，追加第50项。\n\n两真实SQL顺序26命令78事件26冷恢复、12直接/12结构拒绝；独立26历史/双方52快照52提示所有字段及逐个原历史回放、八独立结构拒绝通过。原250审计/54原生七表不变，新两局保留至252，服务正常停止；其他原型边界独立。原始官网十一精确行/三主PDF与目录重新取得，SFD187既知原始/有效文案差异保留；原适用日期和全部来源缺口不变。153审查68上下文245门禁7增量，原152审查完整不变，60上下文原样、七当前输入绑定单独刷新，原完整对象/证据保留；原16952义务身份保留并新增三行为至16955。展示手牌只发现离线提示列表换序，状态/选择/结构仍有效，另记原观察族OPEN，不混入本批认证。\n\n前C2 CI39510792920实际11项success，独立13368/7642、原143/110/十一牌组/424242、48 SQL全输出及网络15拒绝零泄露；全部原13363/7640保留，仅增5/2。39e/f059各自完整CI与本批新固定full、可见硬件双端/Windows及全量语义仍OPEN。仍仅最新可用39e A/B与每平台一包，已核验原件后清退328个重复解压文件5474114逻辑字节，不推定物理回收，无新SDK/checkout/数据库。Goal active / NOT READY。\n\n以下原批次按原范围与实际终态保留。\n\n'
status.write_text(prefix+lead+old_status[len(prefix):])
write(ev/'publication-original-obligation-retention.json',{'atUtc':now(),'status':'BOUNDED_ORDERED_JSONB_RECORDS_PUBLISHED_NOT_GOAL_COMPLETION','allOriginal152ReviewObjectsExact':True,'unaffected60ContextsExact':True,'sevenCurrentImplementationInputOnlyRefreshes':delta['records'],'all244OtherGatesExactAndExistingObservationGateFieldsRetained':True,'original16952ObligationIdsMustRemain':True,'expectedNewObligations':3,'allSourceDatesScopesSourceDeltasAndCoverageUnchanged':True,'sourceManifest':sp,'archiveMembers':len(rows),'archiveBytes':archive.stat().st_size})
print('Published153 reviews68contexts245gates; original152 reviews/60contexts unchanged;seven input-only refreshes; +3 bounded branches; archive',len(rows),archive.stat().st_size)
