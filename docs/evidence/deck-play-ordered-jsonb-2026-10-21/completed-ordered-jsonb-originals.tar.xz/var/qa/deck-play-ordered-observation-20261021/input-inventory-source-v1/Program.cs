using System.IO.Compression;
using System.Reflection;
using System.Text.Json;
using System.Text.Json.Nodes;
using Riftbound.CardCatalog;
using Riftbound.Engine;

if(args.Length!=2||File.Exists(args[0]))throw new Exception("Fresh inventory output and unchanged original failed JSONB frame required.");
var rows=new List<object>();var consumers=new HashSet<string>(StringComparer.Ordinal);var catalog=await OfficialCardCatalog.LoadDefaultAsync();
foreach(var behavior in CardBehaviorRegistry.GetAll().Where(b=>b.DeckPlayKind.Length>0))
{
    consumers.Add(behavior.CardNo);rows.Add(new{cardNo=behavior.CardNo,kind=behavior.DeckPlayKind,origin="registered effect",behavior.EffectKind});
}
var core=typeof(CoreRuleEngine);var methods=new[]{"EndSpec","AttackDeckPlaySpec","LegendConquestDefinition"}.ToDictionary(n=>n,n=>core.GetMethod(n,BindingFlags.Static|BindingFlags.NonPublic)??throw new Exception(n));
foreach(var card in catalog.Cards)
    foreach(var pair in methods)
    {
        var result=pair.Value.Invoke(null,new object?[]{card.CardNo});if(result is null)continue;
        var kind=pair.Key=="LegendConquestDefinition"?(string)result.GetType().GetField("Item1")!.GetValue(result)!:JsonSerializer.SerializeToNode(result)!["Kind"]!.GetValue<string>();
        if(pair.Key=="EndSpec"&&kind!=TriggerKinds.TurnEndRevealUntilUnit||pair.Key=="LegendConquestDefinition"&&kind!="EXHAUST_DECK_PLAY")continue;
        consumers.Add(card.CardNo);rows.Add(new{cardNo=card.CardNo,kind,origin=pair.Key});
    }
foreach(var ability in P4ActivatedAbilityCatalog.GetAll().Where(a=>a.Kind==ActivatedAbilityKinds.DestroyFriendlyUnitLookTopPlayPowerPlusOneRecycleRest))
{
    consumers.Add(ability.SourceCardNo);rows.Add(new{cardNo=ability.SourceCardNo,kind="SINGLE_PRIVATE_LIMITED_UNIT_PLAY",origin=ability.AbilityId});
}
var decks=PreconstructedDeckCatalog.Build(catalog);var allPairs=decks.SelectMany(a=>decks.Where(b=>a.Id!=b.Id).Select(b=>a.Id+"-vs-"+b.Id)).ToArray();
var affected=decks.Where(d=>d.Decklist.MainDeck.Append(d.Decklist.LegendCardNo).Append(d.Decklist.ChampionCardNo).Any(consumers.Contains)).Select(d=>d.Id).ToHashSet();
var affectedPairs=decks.SelectMany(a=>decks.Where(b=>a.Id!=b.Id&&(affected.Contains(a.Id)||affected.Contains(b.Id))).Select(b=>a.Id+"-vs-"+b.Id)).ToArray();
if(decks.Count!=11||allPairs.Length!=110)throw new Exception("Original universe changed.");
using var zip=new GZipStream(File.OpenRead(args[1]),CompressionMode.Decompress);using var failed=JsonDocument.Parse(zip);
var rejection="";
try{failed.RootElement.GetProperty("authoritativeState").Deserialize<MatchState>(new JsonSerializerOptions(JsonSerializerDefaults.Web));throw new Exception("Old unordered representation was unexpectedly accepted.");}
catch(JsonException e){rejection=e.GetType().Name;}
await File.WriteAllTextAsync(args[0],JsonSerializer.Serialize(new{status="FINITE_CURRENT_DECK_PLAY_CONSUMER_INPUT_INVENTORY_AND_OLD_UNORDERED_SCHEMA_REJECTION",actualRuleInputs=RuleInputIdentity.Current,rows,exactConsumers=consumers.Order().ToArray(),originalDecks=decks.Select(d=>new{d.Id,matchingConsumers=d.Decklist.MainDeck.Append(d.Decklist.LegendCardNo).Append(d.Decklist.ChampionCardNo).Where(consumers.Contains).Distinct().ToArray()}),allOriginal110Pairs=allPairs,affectedOriginalPairIds=affectedPairs,oldUnorderedFrameRejectedWithoutMigration=rejection,originalFrameOnlyRead=true,wholePrintingCertification=false},new JsonSerializerOptions(JsonSerializerDefaults.Web){WriteIndented=true}));
Console.WriteLine($"FINITE_DECK_PLAY_INPUTS {consumers.Count} exact consumers; {affectedPairs.Length} affected original directions; old unordered frame rejected {rejection}");
