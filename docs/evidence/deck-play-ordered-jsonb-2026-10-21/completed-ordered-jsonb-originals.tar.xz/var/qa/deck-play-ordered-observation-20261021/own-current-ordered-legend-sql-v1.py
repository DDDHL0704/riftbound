import ast,datetime,fcntl,hashlib,json,os,plistlib,resource,socket,subprocess
from pathlib import Path

resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();load=lambda p:json.loads(p.read_text())
definition=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes=[n for n in ast.parse(definition.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}]
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(definition),'exec'),globals())
pub=load(w/'current-ordered-sql-frozen-inputs-v1.json');runtime=Path(pub['runtimeRoot']);reader=load(w/'independent-legend-reader-frozen-inputs-v2.json');rr=Path(reader['runtimeRoot'])
prior=load(root/'var/qa/fixed-39eacb2e-candlelit-pending-20261021/actual-two-legend-pending-prototype-owner-terminal-v3.json');assert prior['ownPostgresSmartStopped']
def frozen():
 for directory,files in [(runtime,pub['runtimeFiles']),(rr,reader['runtimeFiles'])]:assert all(sha(directory/p)==h for p,h in files.items())
 assert all(sha(root/p)==h and oct((root/p).stat().st_mode&0o777)==pub['sourceInputModes'][p] for p,h in pub['sourceInputHashes'].items())
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
terminal=w/'actual-two-ordered-legend-sql-owner-terminal-v1.json';assert not terminal.exists()
proof={'status':'RUNNING_CURRENT_ORDERED_LEGEND_REAL_SQL_AND_INDEPENDENT_READBACK','startedAtUtc':now(),'parentCommit':pub['parentCommit'],'actualRuleInputs':reader['actualRuleInputs'],'includesDeclaredUncommittedChanges':True,'lockAtStart':observe_lock(),'oldJsonbFailureRetainedWithoutMigration':True}
power=writer=independent=None;started=False;audit=native=None;before_audit=before_native=None
try:
 frozen();assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid
 sock.mkdir(exist_ok=True);subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'ordered-legend-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 audit=rooms('riftbound_acceptance');native=rooms('riftbound_here_native')
 assert audit==prior['actualAuditRoomsAtStop'] and len(audit)==250 and native==prior['actualNativeRoomsAtStop'] and len(native)==54
 before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',native)
 (w/'original250-audit54-native-seven-table-baseline-v1.json').write_text(json.dumps({'atUtc':now(),'auditRooms':audit,'nativeRooms':native,'auditSevenTables':before_audit,'nativeSevenTables':before_native},indent=2)+'\n')
 output=w/'actual-two-ordered-legend-sql-v1';assert not output.exists()
 command=['/Users/dinghaolin/.dotnet/dotnet',str(runtime/'Riftbound.PostgresAcceptance.dll'),'--candlelit-legend-pending-only'];proof['writerCommand']=command
 env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit',RIFTBOUND_POSTGRES_EVIDENCE=str(output),DOTNET_DbgEnableMiniDump='0')
 with (w/'actual-two-ordered-legend-sql-writer-v1.log').open('xb') as log:
  writer=subprocess.Popen(command,cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT);proof['writerExitCode']=writer.wait(timeout=540);assert proof['writerExitCode']==0
 receipts=[load(output/'candlelit-legend-pending'/b/'receipt.json') for b in ['legend-first','battlefield-first']]
 assert all(c['status'].startswith('REAL_SQL_CURRENT_LEGEND_') and c['actualRuleInputs']==reader['actualRuleInputs'] and c['commands']==c['coldRecoveries'] for c in receipts)
 added={c['room'] for c in receipts};assert len(added)==2 and set(rooms('riftbound_acceptance'))==set(audit)|added and rooms('riftbound_here_native')==native
 proof.update(writerCases=2,commands=sum(c['commands'] for c in receipts),events=sum(c['events'] for c in receipts),coldRecoveries=sum(c['coldRecoveries'] for c in receipts),directAtomicRejections=sum(c['directAtomicRejections'] for c in receipts),writerIndependentStructuralRejections=sum(c['independentStructuralRejections'] for c in receipts),newRooms=sorted(added))
 print('CURRENT_REAL_JSONB_TWO_ORDERS_WRITER_PASS',proof['commands'],proof['events'],flush=True)
 command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(rr/'Riftbound.PostgresAcceptance.deps.json'),'--runtimeconfig',str(rr/'Riftbound.PostgresAcceptance.runtimeconfig.json'),str(rr/'CurrentOrderedLegendIndependentSqlReaderV2.dll'),str(output),str(w/'independent-two-ordered-legend-all-history-v1.json')];proof['independentReadOnlyCommand']=command
 with (w/'independent-two-ordered-legend-all-history-v1.log').open('xb') as log:
  independent=subprocess.Popen(command,cwd=rr,env=env,stdout=log,stderr=subprocess.STDOUT);proof['independentExitCode']=independent.wait(timeout=600);assert proof['independentExitCode']==0
 actual=load(w/'independent-two-ordered-legend-all-history-v1.json');assert actual['actualReadOnlyConnection'] and set(actual['rooms'])==added and actual['commands']==proof['commands'] and actual['events']==proof['events'] and actual['authoritativeHistoricalStates']==proof['commands']
 proof.update(status='PASS_CURRENT_CN16_TWO_LEGEND_PENDING_ORDERS_REAL_JSONB_COLD_DEDUP_INDEPENDENT_ALL_HISTORY_AND_EVERY_ORIGINAL_REPLAY',independentReadback=actual)
except BaseException as e:
 proof.update(status='FAILED_OR_INTERRUPTED_CURRENT_ORDERED_LEGEND_SQL_ORIGINALS_AND_ROOMS_RETAINED',errorType=type(e).__name__,error=str(e));raise
finally:
 for process in [writer,independent]:
  if process is not None and process.poll() is None:process.terminate();process.wait(timeout=20)
 if started:
  if before_audit is not None:
   proof['allOriginal250AuditSevenTablesExactAtStop']=digests('riftbound_acceptance',audit)==before_audit;proof['allOriginal54NativeSevenTablesExactAtStop']=digests('riftbound_here_native',native)==before_native;proof['actualAuditRoomsAtStop']=rooms('riftbound_acceptance');proof['actualNativeRoomsAtStop']=rooms('riftbound_here_native')
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None:
  if power.poll() is None:power.terminate();power.wait(timeout=10)
  proof['boundIdleAssertionEnded']=power.poll() is not None
 frozen();proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),frozenRuntimeAndAll3321SourceInputsStable=True);terminal.write_text(json.dumps(proof,indent=2)+'\n');fcntl.flock(guard,fcntl.LOCK_UN)
print(proof['status'],flush=True)
assert proof['allOriginal250AuditSevenTablesExactAtStop'] and proof['allOriginal54NativeSevenTablesExactAtStop'] and proof['ownPostgresSmartStopped']
