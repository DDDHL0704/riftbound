from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,tarfile,io,subprocess,xml.etree.ElementTree as E
R=Path.cwd();Q=R/'var/qa/void-gate-untargeted-damage-20261023';D=R/'docs/evidence/void-gate-untargeted-damage-parallel-2026-10-23';D.mkdir(parents=True,exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest();ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
frozen=json.load((Q/'frozen-inputs-v1.json').open())
for p,h in frozen['ruleInputs'].items():assert sha((R/p).read_bytes())==h
r=E.parse(Q/'focus-and-adjacent-v1/focus/results.trx');c=r.find('.//t:Counters',ns).attrib;assert c['total']=='19'and c['passed']=='13'and c['failed']=='6'and c['notExecuted']=='0'
cases=[{'name':x.get('testName'),'outcome':x.get('outcome'),'failure':x.find('.//t:Message',ns).text if x.find('.//t:Message',ns)is not None else None}for x in r.findall('.//t:UnitTestResult',ns)];assert all('VoidGateUntargetedDamageTests'in x['name']for x in cases if x['outcome']!='Passed')
assembly=R/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0/Riftbound.ConformanceTests.dll';plan=json.load((Q/'focus-and-adjacent-v1/plan.json').open());assert plan['testAssemblySha256']==sha(assembly.read_bytes())
source='tests/Riftbound.ConformanceTests/VoidGateUntargetedDamageTests.cs';assert(Q/'focus-and-adjacent-v1/test-source.cs').read_bytes()==(R/source).read_bytes();proof=json.load((Q/'verified-results-v1.json').open());assert len(proof)==12 and sum(x['commands']for x in proof)==40 and sum(x['events']for x in proof)==168
actual=[]
for p in sorted((Q/'original-v1').glob('*.json.gz')):
 x=json.load(gzip.open(p,'rt'));assert len(x['commands'])==len(x['entries'])==len(x['states'])==x['originalPrefixReplayCount'];assert all(c['accepted']for c in x['commands']);assert x['initial']['seed']==424242
 assert [e for item in x['entries']for e in item['events']]==[e['event']for e in x['events']]
 assert (x['failure']is not None)==x['localBonus']
 for c0 in x['commands']:
  if c0['ruleInputs']not in actual:actual.append(c0['ruleInputs'])
assert len(actual)==1
receiptPath=R/'var/qa/draven-battle-multi-source-20261023/applied-n53-overlay-v1.json';receipt=json.load(receiptPath.open());peer=Path(receipt['overlaySource']);assert sha(peer.read_bytes())==receipt['overlaySha256'];oldReceipt=Path(receipt['parentReceipt']);old=json.load(oldReceipt.open());oldPeer=Path(old['overlaySource']);assert sha(oldPeer.read_bytes())==old['overlaySha256']
for p in (Q/'sources-v1').glob('current-*-original-v1.json.gz'):
 x=json.load(gzip.open(p,'rt'));assert sha(x['originalUtf8'].encode())==x['rawSha256']
extra=[source,'docs/VOID_GATE_UNTARGETED_DAMAGE_PARALLEL_2026-10-23.md','tests/Riftbound.ConformanceTests/CurrentVoidGateErratumTests.cs','src/Riftbound.Engine/CardBehaviorRegistry.cs','src/Riftbound.Engine/BattlefieldStaticAbilitySpecRules.cs']
paths=[(str(p.relative_to(R)),p)for p in Q.rglob('*')if p.is_file()]+[(x,R/x)for x in extra]+[('inputs/n53-exact-main-overlay-after71-green-v1.tar.gz',peer),('inputs/applied-n53-overlay-v1.json',receiptPath),('inputs/peer-fixed-n52-first45-v1.tar.gz',oldPeer),('inputs/applied-peer-fixed-n52-first45-v1.json',oldReceipt)]
archive=D/'original-tests-fixed-inputs-and-sources-v1.tar.gz';members=[]
with archive.open('xb')as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as t:
   for name,p in sorted(paths):
    b=p.read_bytes();i=tarfile.TarInfo(name);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b));members.append({'path':name,'bytes':len(b),'sha256':sha(b)})
with tarfile.open(archive,'r:gz')as t:
 for m in members:
  b=t.extractfile(m['path']).read();assert len(b)==m['bytes']and sha(b)==m['sha256']
manifest={'status':'SOURCE_RED_VOID_GATE_LOCAL_BONUS_MISSING_IN_THREE_UNTARGETED_SPELL_CONSUMERS','atUtc':datetime.now(timezone.utc).isoformat(),'baseCommit':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'region':'CN','language':'zh-CN','peerOverlay':receipt,'frozenSpecifiedInputs':frozen,'all27SpecifiedInputsUnchanged':True,'actualRuleInputs':actual[0],'testAssemblySha256':sha(assembly.read_bytes()),'source':{'path':source,'sha256':sha((R/source).read_bytes())},'originalRun':{'counters':c,'methods':plan['shards'][0]['methods'],'testCases':cases},'originalHistories':proof,'newCases':12,'newPassedControls':6,'newSourceFailures':6,'newCommands':40,'newAccepted':40,'newEvents':168,'newOriginalPrefixReplays':40,'adjacentCasesPassed':7,'cases':19,'passed':13,'failed':6,'skipped':0,'sources':json.load((Q/'sources-v1/extra-rows.json').open()),'resolverBindings':json.load((Q/'actual-resolver-call-sites-v1.json').open()),'globalAnnieBonusAlreadyAppliedOnce':True,'annieStaysAliveInBase':True,'noSharedRuntimeChanges':True,'noExtraCheckOrFull':True,'noDatabaseExecution':True,'wholePrintingCertified':False,'backendGoalComplete':False,'archive':{'path':str(archive.relative_to(R)),'sha256':sha(archive.read_bytes()),'members':members}}
with(D/'source-and-red-test-manifest.json').open('x')as f:json.dump(manifest,f,ensure_ascii=False,indent=2)
print('Verified',len(members),'members,',archive.stat().st_size,'bytes;6 controls passed6sourcefailed+7adjacentpass;40prefixes')
