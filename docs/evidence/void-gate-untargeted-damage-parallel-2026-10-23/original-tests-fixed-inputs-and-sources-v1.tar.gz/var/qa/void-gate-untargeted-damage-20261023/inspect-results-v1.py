from pathlib import Path
import gzip,json,xml.etree.ElementTree as E
Q=Path(__file__).parent;p=Q/'focus-and-adjacent-v1/focus/results.trx';ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
if not p.exists():print('RUNNING');raise SystemExit
r=E.parse(p);print('COUNTERS',r.find('.//t:Counters',ns).attrib);proof=[]
for p in sorted((Q/'original-v1').glob('*.json.gz')):
 x=json.load(gzip.open(p,'rt'));es=[e['event']for e in x['events']];d={e['payload']['targetObjectId']:e['payload']['damage']for e in es if e['kind']=='DAMAGE_APPLIED'and e['payload'].get('sourceObjectId')=='SPELL'}
 assert x['originalPrefixReplayCount']==len(x['commands'])==len(x['entries'])==len(x['states']) and all(c['accepted']for c in x['commands'])
 base={'OGN·133/298':1,'OGN·123/298':12,'OGN·127/298':2}[x['spell']];globalDamage=base+int(x['annie']);actual=d['P2-A1'];expected=globalDamage+int(x['localBonus'])
 assert actual==globalDamage and d['P2-A2']==globalDamage
 if x['spell']=='OGN·127/298':assert set(d)=={'P2-A1','P2-A2'}
 else:assert set(d)=={'P2-A1','P2-A2','P2-B','P1-C'}and d['P2-B']==globalDamage and d['P1-C']==globalDamage
 assert (x['failure']is not None)==x['localBonus']
 if x['localBonus']:assert ('Expected: '+str(expected)+'\nActual:   '+str(actual))in x['failure']
 proof.append({'caseId':x['caseId'],'spell':x['spell'],'localBonus':x['localBonus'],'annie':x['annie'],'baseDamage':base,'actualDamage':d,'expectedAtAAndC':expected,'expectedAtB':0 if x['spell']=='OGN·127/298'else globalDamage,'commands':len(x['commands']),'events':len(es),'originalPrefixReplays':x['originalPrefixReplayCount'],'failure':x['failure']})
assert len(proof)==12
print('TOTALS',sum(x['commands']for x in proof),sum(x['events']for x in proof));print('ROWS',[(x['spell'],x['localBonus'],x['annie'],x['actualDamage'])for x in proof])
with(Q/'verified-results-v1.json').open('x')as f:json.dump(proof,f,ensure_ascii=False,indent=2)
