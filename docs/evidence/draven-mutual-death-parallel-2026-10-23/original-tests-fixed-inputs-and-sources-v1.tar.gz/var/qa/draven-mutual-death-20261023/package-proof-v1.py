from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,tarfile,io,subprocess,xml.etree.ElementTree as E
R=Path.cwd();Q=R/'var/qa/draven-mutual-death-20261023';D=R/'docs/evidence/draven-mutual-death-parallel-2026-10-23';D.mkdir(parents=True,exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest();ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
frozen=json.load((Q/'frozen-inputs-v1.json').open())
for p,h in frozen['ruleInputs'].items():assert sha((R/p).read_bytes())==h
r=E.parse(Q/'focus-and-adjacent-v1/focus/results.trx');c=r.find('.//t:Counters',ns).attrib;assert c['total']=='49'and c['passed']=='33'and c['failed']=='16'and c['notExecuted']=='0'
cases=[{'name':x.get('testName'),'outcome':x.get('outcome'),'failure':x.find('.//t:Message',ns).text if x.find('.//t:Message',ns)is not None else None}for x in r.findall('.//t:UnitTestResult',ns)];assert all('DravenMutualDeathScoreTests'in x['name']for x in cases if x['outcome']!='Passed')
assembly=R/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0/Riftbound.ConformanceTests.dll';plan=json.load((Q/'focus-and-adjacent-v1/plan.json').open());assert plan['testAssemblySha256']==sha(assembly.read_bytes())
source='tests/Riftbound.ConformanceTests/DravenMutualDeathScoreTests.cs';assert(Q/'focus-and-adjacent-v1/test-source.cs').read_bytes()==(R/source).read_bytes()
proof=[];actual=[]
for p in sorted((Q/'original-v1').glob('*.json.gz')):
 x=json.load(gzip.open(p,'rt'));assert len(x['commands'])==len(x['entries'])==len(x['states'])==x['originalPrefixReplayCount']==4;assert all(c['accepted']for c in x['commands']);assert x['initial']['seed']==424242
 es=[e for item in x['entries']for e in item['events']];assert es==[e['event']for e in x['events']];ds=[e for e in es if e['kind']=='UNIT_DESTROYED'];assert len(ds)==2 and len(es)==15;assert not any(e['kind']=='SCORE_GAINED'for e in es)
 s=x['states'][-1]
 for player in ['P1','P2']:assert player+'-DRAVEN'in s['playerZones'][player]['graveyard']and s['cardObjects'][player+'-DRAVEN']['objectGeneration']>0
 assert 'Expected: '+('1'if x['initialScore']==7 else'2')+'\nActual:   0'in x['failure']
 proof.append({'caseId':x['caseId'],'p1Card':x['p1Card'],'p2Card':x['p2Card'],'turnPlayer':x['turnPlayer'],'initialScore':x['initialScore'],'commands':4,'events':15,'originalPrefixReplays':4,'actualDeaths':2,'actualDeathScores':0,'laterOrderAndVictoryAssertionsReached':False,'failure':x['failure'],'sha256':sha(p.read_bytes())})
 for c0 in x['commands']:
  if c0['ruleInputs']not in actual:actual.append(c0['ruleInputs'])
assert len(proof)==16 and len(actual)==1
receiptPath=R/'var/qa/draven-battle-multi-source-20261023/applied-n53-overlay-v1.json';receipt=json.load(receiptPath.open());peer=Path(receipt['overlaySource']);assert sha(peer.read_bytes())==receipt['overlaySha256'];oldReceipt=Path(receipt['parentReceipt']);old=json.load(oldReceipt.open());oldPeer=Path(old['overlaySource']);assert sha(oldPeer.read_bytes())==old['overlaySha256']
binding=json.load((Q/'source-bindings-v1.json').open())
for p in binding['originalResponses']:
 f=R/p['path'];assert sha(f.read_bytes())==p['sha256'];j=json.load(gzip.open(f,'rt'));assert sha(j['originalUtf8'].encode())==p['bodySha256']
extra=[source,'src/Riftbound.Engine/CoreRuleEngine.DravenBattleDeathScore.cs','docs/DRAVEN_MUTUAL_DEATH_PARALLEL_2026-10-23.md','tests/Riftbound.ConformanceTests/MultiControllerTriggerOrderingTests.cs','tests/Riftbound.ConformanceTests/DeathObserverAuditTests.cs','var/qa/draven-battle-death-score-20261023/current-sfd-judge-faq-http-v1.json','var/qa/draven-battle-win-score-20261023/current-core304-http-original-v1.json']+[x['path']for x in binding['originalResponses']]
paths=[(str(p.relative_to(R)),p)for p in Q.rglob('*')if p.is_file()]+[(x,R/x)for x in extra]+[('inputs/n53-exact-main-overlay-after71-green-v1.tar.gz',peer),('inputs/applied-n53-overlay-v1.json',receiptPath),('inputs/peer-fixed-n52-first45-v1.tar.gz',oldPeer),('inputs/applied-peer-fixed-n52-first45-v1.json',oldReceipt)]
archive=D/'original-tests-fixed-inputs-and-sources-v1.tar.gz';members=[]
with archive.open('xb')as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as t:
   for name,p in sorted(paths):
    b=p.read_bytes();i=tarfile.TarInfo(name);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b));members.append({'path':name,'bytes':len(b),'sha256':sha(b)})
with tarfile.open(archive,'r:gz')as t:
 for m in members:
  b=t.extractfile(m['path']).read();assert len(b)==m['bytes']and sha(b)==m['sha256']
manifest={'status':'SOURCE_RED_BOTH_DRAVEN_DEATH_SKILLS_MISSING','atUtc':datetime.now(timezone.utc).isoformat(),'baseCommit':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'region':'CN','language':'zh-CN','peerOverlay':receipt,'frozenSpecifiedInputs':frozen,'all26SpecifiedInputsUnchanged':True,'actualRuleInputs':actual[0],'testAssemblySha256':sha(assembly.read_bytes()),'source':{'path':source,'sha256':sha((R/source).read_bytes())},'originalRun':{'counters':c,'methods':plan['shards'][0]['methods'],'testCases':cases},'originalHistories':proof,'newCases':16,'newSourceFailures':16,'newCommands':64,'newAccepted':64,'newEvents':240,'newOriginalPrefixReplays':64,'actualDeaths':32,'crossControllerOrderAndWinningExpectationsNotReached':True,'adjacentCasesPassed':33,'cases':49,'passed':33,'failed':16,'skipped':0,'sources':binding,'expectedOrderInferredFromExactClauses':['383.3.d.1','340.1','323.1'],'deathTaskTimingStillOpen':True,'noExtraCheckOrFull':True,'noDatabaseExecution':True,'wholePrintingCertified':False,'backendGoalComplete':False,'archive':{'path':str(archive.relative_to(R)),'sha256':sha(archive.read_bytes()),'members':members}}
with(D/'source-and-red-test-manifest.json').open('x')as f:json.dump(manifest,f,ensure_ascii=False,indent=2)
print('Verified',len(members),'members,',archive.stat().st_size,'bytes;16 source failures,33 adjacent passed;64 prefixes')
