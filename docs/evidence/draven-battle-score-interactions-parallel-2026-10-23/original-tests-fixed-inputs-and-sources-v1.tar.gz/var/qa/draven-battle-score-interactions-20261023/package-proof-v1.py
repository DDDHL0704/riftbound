from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,tarfile,io,subprocess,xml.etree.ElementTree as E
R=Path.cwd();Q=R/'var/qa/draven-battle-score-interactions-20261023';D=R/'docs/evidence/draven-battle-score-interactions-parallel-2026-10-23';D.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def trx(path):
 r=E.parse(path);defs={d.get('id'):d.find('t:TestMethod',ns).attrib for d in r.findall('.//t:UnitTest',ns)}
 return {'sha256':sha(path.read_bytes()),'counters':r.find('.//t:Counters',ns).attrib,'cases':[{'name':x.get('testName'),'method':defs[x.get('testId')]['className']+'.'+defs[x.get('testId')]['name'],'outcome':x.get('outcome'),'failure':x.find('.//t:Message',ns).text if x.find('.//t:Message',ns)is not None else None}for x in r.findall('.//t:UnitTestResult',ns)]}
runs={k:trx(Q/k/'focus/results.trx')for k in ['focus-v2','adjacent-v1']}
for k,total,passed,failed in [('focus-v2',12,0,12),('adjacent-v1',35,25,10)]:
 c=runs[k]['counters'];assert c['total']==str(total)and c['passed']==str(passed)and c['failed']==str(failed)and c['notExecuted']=='0'
life=[c for c in runs['adjacent-v1']['cases']if '.FinalConquestScoreLifecycleTests.'in c['method']];assert len(life)==17 and all(c['outcome']=='Passed'for c in life)
receiptPath=R/'var/qa/battle-win-combined-20261023/applied-peer-fixed-n52-first45-v1.json';receipt=json.load(receiptPath.open());peer=Path(receipt['overlaySource']);assert sha(peer.read_bytes())==receipt['overlaySha256']
for f in receipt['files']:assert sha((R/f['path']).read_bytes())==f['afterSha256']
proof=[];ruleInputs=[]
for folder,count,cmds,evs in [('original-v2',12,96,380),('original-existing-score-v1',18,78,286)]:
 batch=[]
 for p in sorted((Q/folder).glob('*.json.gz')):
  a=json.loads(gzip.decompress(p.read_bytes()));assert a['originalPrefixReplayCount']==len(a['commands'])==len(a['entries'])==len(a['states']);assert a['initial']['seed']==424242 and all(c['accepted']for c in a['commands'])
  events=[e for entry in a['entries']for e in entry['events']];assert events==[e['event']for e in a['events']]
  if folder=='original-v2':
   assert a['failure']
   if a['scenario']=='three-battles-two-turns':assert sum(c['commandType']=='DECLARE_BATTLE'for c in a['commands'])==3 and sum(c['commandType']=='END_TURN'for c in a['commands'])==2 and a['states'][-1]['turnNumber']==7
   if a['scenario'].startswith('return-'):assert sum(c['commandType']=='PLAY_CARD'for c in a['commands'])==1 and 'SOURCE'in a['states'][-1]['playerZones']['P1']['hand']
   if a['scenario']=='illegal-counter':assert not any(c['commandType']=='PLAY_CARD'for c in a['commands'])
  for c in a['commands']:
   if c['ruleInputs']not in ruleInputs:ruleInputs.append(c['ruleInputs'])
  batch.append({'caseId':a['caseId'],'path':str(p.relative_to(R)),'commands':len(a['commands']),'events':len(events),'originalPrefixReplays':a['originalPrefixReplayCount'],'sha256':sha(p.read_bytes()),'failure':a.get('failure')})
 assert len(batch)==count and sum(x['commands']for x in batch)==cmds and sum(x['events']for x in batch)==evs;proof+=batch
assert len(ruleInputs)==1
assembly=R/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0/Riftbound.ConformanceTests.dll'
for run in ['focus-v2','adjacent-v1']:assert json.load((Q/run/'plan.json').open())['testAssemblySha256']==sha(assembly.read_bytes())
for p in Q.rglob('current-*-original-v1.json.gz'):
 a=json.loads(gzip.decompress(p.read_bytes()));assert sha(a['originalUtf8'].encode())==a['rawSha256']
source='tests/Riftbound.ConformanceTests/DravenBattleWinScoreInteractionTests.cs'
assert (Q/'focus-v2/test-source.cs').read_bytes()==(R/source).read_bytes()
extra=[source,'src/Riftbound.Engine/CoreRuleEngine.DravenBattleWinScore.cs','tests/Riftbound.ConformanceTests/OfficialDravenBattleWinScoreTests.cs','docs/DRAVEN_BATTLE_SCORE_INTERACTIONS_PARALLEL_2026-10-23.md','var/qa/draven-battle-win-score-20261023/current-core304-http-original-v1.json']
paths=[(str(p.relative_to(R)),p)for p in Q.rglob('*')if p.is_file()]+[(x,R/x)for x in extra]+[('inputs/peer-fixed-n52-first45-v1.tar.gz',peer),('inputs/applied-peer-fixed-n52-first45-v1.json',receiptPath)]
archive=D/'original-tests-fixed-inputs-and-sources-v1.tar.gz';members=[]
with archive.open('xb')as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as tar:
   for name,p in sorted(paths):
    data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data));members.append({'path':name,'bytes':len(data),'sha256':sha(data)})
with tarfile.open(archive,'r:gz')as tar:
 for m in members:
  data=tar.extractfile(m['path']).read();assert len(data)==m['bytes']and sha(data)==m['sha256']
manifest={'status':'SOURCE_RED_N53_SCORE_CONSUMER_STILL_UNWIRED','atUtc':datetime.now(timezone.utc).isoformat(),'baseCommit':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'region':'CN','language':'zh-CN','coreEffectiveDate':'2026-10-16','peerOverlay':receipt,'all19SharedInputsUnchanged':True,'actualRuleInputs':ruleInputs[0],'actualTestAssemblySha256':sha(assembly.read_bytes()),'source':{'path':source,'sha256':sha((R/source).read_bytes())},'originalRuns':runs,'originalHistories':proof,'newCases':12,'newMethods':4,'newOriginalPrefixReplays':96,'newOriginalEvents':380,'existingScoreCases':18,'existingScoreOriginalPrefixReplays':78,'existingScoreOriginalEvents':286,'adjacentLifecyclePassed':17,'seed':424242,'freshCompleteSourceRows':json.load((Q/'sources-v1/extra-rows.json').open()),'counterCoverage':'The 2 illegal-counter tests stop at missing score-skill precondition. No counter submission or invariant coverage yet. No current legal counter asserted.','originalCompileFailure':'CS9124 preserved with original source; ordinary constructor resolves it.','sharedConsumerCommit':'36f7195f7ce16402236d0b8e905d70c97dc96217','onlyNewTestAndScopedEvidenceToCommit':True,'noExtraCheckOrFull':True,'noDatabaseExecution':True,'fullGameAcceptanceDeferredUntilIntegration':True,'notApiOrColdRecoveryOrGlobalCertification':True,'allEarlierSourcesTestsSeedsAndFailuresPreserved':True,'backendGoalComplete':False,'sharedIntegrationOwner':'01a16770-8c1b-7da2-872b-a8ec5ae77413','parallelThread':'01a16771-220b-7e83-91c6-44acf6dfe4b0','archive':{'path':str(archive.relative_to(R)),'sha256':sha(archive.read_bytes()),'members':members}}
with(D/'source-and-red-test-manifest.json').open('x')as f:json.dump(manifest,f,ensure_ascii=False,indent=2)
print(manifest['status'],len(members),'members',archive.stat().st_size,'bytes;new12 source failures,adjacent25pass10fail;174 prefixes')
