# -*- coding: utf-8 -*-
from pathlib import Path
import collections, datetime, gzip, hashlib, json, re, subprocess, types, xml.etree.ElementTree as ET, zipfile
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
fixed='f248d7774aca8776d288bb5d702e0b545b116a7e';run_id=39866108629
load=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
downloads=load(w/'cif248d777-all-nine-original-artifacts-receipt-v1.json')
assert downloads['fixedCommit']==fixed and downloads['runId']==run_id and len(downloads['jobs'])==11 and all(s=='success' for s in downloads['jobs'].values())
artifacts={a['name']:a for a in downloads['artifacts']};assert len(artifacts)==9
for a in artifacts.values():
 b=Path(a['path']).read_bytes();assert len(b)==a['bytes'] and sha(b)==a['sha256'] and 'sha256:'+sha(b)==a['backendDigest']
 with zipfile.ZipFile(a['path']) as z:assert z.testzip() is None
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def collect(path,current=False):
 cases=collections.Counter();methods=set();matrices=[];hashes={};outcomes=collections.Counter()
 with zipfile.ZipFile(path) as z:
  if current:
   assert z.read('ci-rule-suite-commit.txt').decode().strip()==fixed
   plan=json.loads(z.read('ci-rules/plan.json'));summary=json.loads(z.read('ci-rules/summary.json'))
   assert summary['profile']=='full' and summary['status']=='PASSED' and summary['total']==13787
   planned=[m for s in plan['shards'] for m in s['methods']];assert len(planned)==len(set(planned))==plan['discoveredMethods']==7743
  for name in z.namelist():
   if not name.endswith('/results.trx'):continue
   raw=z.read(name);hashes[name]=sha(raw);doc=ET.fromstring(raw);actual=set()
   definitions={d.get('id'):d.find('t:TestMethod',ns).attrib for d in doc.findall('.//t:UnitTest',ns)}
   for row in doc.findall('.//t:UnitTestResult',ns):
    outcome=row.get('outcome');outcomes[outcome]+=1;assert outcome=='Passed'
    definition=definitions[row.get('testId')];method=definition['className']+'.'+definition['name'];methods.add(method);actual.add(method);cases[row.get('testName')]+=1
    for output in row.findall('.//t:StdOut',ns):
     for line in (output.text or '').splitlines():
      if line.startswith('PRECONSTRUCTED_MATRIX '):matrices.append(json.loads(line[len('PRECONSTRUCTED_MATRIX '):]))
   if current:
    counters=doc.find('.//t:Counters',ns).attrib;assert int(counters['total'])==int(counters['passed']) and counters['failed']=='0' and counters['notExecuted']=='0'
    assert actual==set(next(s['methods'] for s in plan['shards'] if s['name']==name.split('/')[-2]))
  if current:assert methods==set(planned) and sum(cases.values())==13787
 return cases,methods,matrices,hashes,outcomes
current=collect(Path(artifacts['conformance-results']['path']),True)
prior_path=root/'var/qa/fixeda68bf-early-native-20261023/cia68bf-entire-full-independent-verification-v1.json';prior=load(prior_path)
oldartifact=next(a for a in prior['artifacts'] if a['name']=='conformance-results');assert sha(Path(oldartifact['path']).read_bytes())==oldartifact['sha256']
before=collect(Path(oldartifact['path']))
assert sum(before[0].values())==13782 and len(before[1])==7741 and before[4]=={'Passed':13782}
assert not(before[0]-current[0]) and before[1]<=current[1]
added=current[0]-before[0];added_methods=current[1]-before[1]
prep=json.loads(subprocess.check_output(['git','show',fixed+':docs/evidence/zero-printed-power-prompt-current-cn16-2026-10-23/five-exact-branches-and-existing-rule-identities.json'],cwd=root))
assert added==collections.Counter(c['actualExecutedCase'] for c in prep['cases']) and sum(added.values())==5 and added_methods==set(prep['newMethods']) and len(added_methods)==2
assert len(current[2])==1;matrix=current[2][0]
decks=json.loads(gzip.decompress((root/'var/qa/graveyard-source-fixed-candidate-20261020/native-visible-v1/live-api-eleven-preconstructed-decks-original.json.gz').read_bytes()))
ids=[d['id'] for d in decks];pairs={a+'-vs-'+b for a in ids for b in ids if a!=b}
assert len(ids)==11 and matrix['seed']==424242 and matrix['deckCount']==11 and matrix['pairCount']==110 and set(matrix['completed'])==pairs==set(prior['matrix']['completed']) and all(re.fullmatch('[0-9a-f]{64}',h) for h in matrix['completed'].values())
full={m for m in current[1] if '.FullGameEndToEndTests.' in m};assert len(full)==143 and full=={m for m in before[1] if '.FullGameEndToEndTests.' in m}
assert sum(n for name,n in current[0].items() if '.FullGameEndToEndTests.' in name)==151
source_paths=subprocess.check_output(['git','ls-tree','-r','--name-only',fixed,'tests/Riftbound.ConformanceTests'],cwd=root,text=True).splitlines();full_sources={}
for name in source_paths:
 if 'FullGameEndToEndTests' not in name:continue
 old=subprocess.check_output(['git','show',prior['fixedCommit']+':'+name],cwd=root);new=subprocess.check_output(['git','show',fixed+':'+name],cwd=root);assert old==new;full_sources[name]=sha(new)
assert len(full_sources)==9
stage=w/'cif248d777-independent-sql-members-v1';stage.mkdir();members=[]
for index in range(4):
 target=stage/str(index);target.mkdir()
 with zipfile.ZipFile(artifacts['postgres-partition-'+str(index)]['path']) as z:
  for name in z.namelist():
   assert not Path(name).is_absolute() and '..' not in Path(name).parts
   if name.endswith('/'):continue
   p=target/name;p.parent.mkdir(parents=True,exist_ok=True);raw=z.read(name)
   with p.open('xb') as f:f.write(raw)
   members.append({'partition':index,'originalZipMember':name,'path':str(p.relative_to(root)),'bytes':len(raw),'sha256':sha(raw)})
manifest=w/'exact-fixedf248d777-sql-manifest-original-v1.json';manifest.write_bytes(subprocess.check_output(['git','show',fixed+':tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'],cwd=root))
old_manifest=json.loads(subprocess.check_output(['git','show',prior['fixedCommit']+':tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'],cwd=root))
assert len(old_manifest['cases'])==62 and load(manifest)==old_manifest
gate_source=subprocess.check_output(['git','show',fixed+':scripts/sql-ci-gate.py'],cwd=root);gate_path=w/'exact-fixedf248d777-sql-ci-gate-original-v1.py';gate_path.write_bytes(gate_source)
module=types.ModuleType('exact_fixedf248d777_sql_gate');exec(compile(gate_source,str(gate_path),'exec'),module.__dict__)
sql=module.verify(fixed,manifest,stage,dict.fromkeys(['scope','postgres_partitions','native_network'],'success'));assert sql['caseCount']==62
with zipfile.ZipFile(artifacts['postgres-results']['path']) as z:assert json.loads(z.read('result.json'))==sql
with zipfile.ZipFile(artifacts['full-verification-gate']['path']) as z:
 gate=json.loads(z.read('result.json'));assert gate['commit']==fixed and gate['status']=='FIXED_COMMIT_FULL_CHILD_JOBS_ALL_SUCCEEDED' and all(s=='success' for s in gate['jobs'].values())
with zipfile.ZipFile(artifacts['verification-scope']['path']) as z:
 decision=json.loads(z.read('decision.json'));governance=json.loads(z.read('governance.json'))
 assert decision['headSha']==fixed and decision['full'] is True and governance['governanceValid'] and not governance['semanticCoverageCertified'] and governance['errors']==[] and governance['currentReviewCount']==169 and len(governance['remainingObligations'])==17390
with zipfile.ZipFile(artifacts['native-network-results']['path']) as z:
 assert z.read('commit.txt').decode().strip()==fixed;log=z.read('native-network.log').decode()
 wire=next(json.loads(l[len('NATIVE_ROOM_IDENTITY_EVIDENCE '):]) for l in log.splitlines() if l.startswith('NATIVE_ROOM_IDENTITY_EVIDENCE '))
 peer=next(json.loads(l[len('NATIVE_ROOM_SEAT_PEER_EVIDENCE '):]) for l in log.splitlines() if l.startswith('NATIVE_ROOM_SEAT_PEER_EVIDENCE '))
 assert wire['rejectedActions']==15 and wire['leakedPrivateMessages']==0 and wire['validReconnectTokenWasSupplied']
 assert peer['firstPlayerOriginalTick']==1 and peer['firstPlayerRefreshedTick']==peer['secondPlayerTick']==2 and peer['privateViewers']==2 and peer['explicitSnapshotRequests']==peer['commandRetries']==peer['wrongViewerMessages']==0 and peer['originalOnePlayerViewRetained'] and peer['bothPrivateViewersRefreshed'] and peer['reconnectTokensAndPlayerKeysAbsentFromPrivateViews']
 assert 'Native canonical room identity passed:' in log and 'Native network recovery passed: socket loss, authenticated room restore, fresh snapshot, rejected-token guard.' in log
member_manifest=w/'cif248d777-original-sql-zip-members-v1.json.gz';member_manifest.write_bytes(gzip.compress(json.dumps(members,indent=2).encode(),mtime=0))
result={'atUtc':now(),'status':'FIXEDF248D777_ALL11_SUCCESS13787_CASES7743_METHODS_INDEPENDENT62_SQL_ALL_ORIGINAL5_ZERO_POWER_PROMPT_CASES_AND_NETWORK_VERIFIED','fixedCommit':fixed,'runId':run_id,'jobs':downloads['jobs'],'actualCases':13787,'actualMethods':7743,'actualOutcomes':dict(current[4]),'original13782Cases7741MethodsExactRetainedPlus5Cases2Methods':True,'priorActualCompleteEvidenceSha256':sha(prior_path.read_bytes()),'addedCaseNames':sorted(added.elements()),'addedMethodNames':sorted(added_methods),'exact5PreparationSha256':sha(subprocess.check_output(['git','show',fixed+':docs/evidence/zero-printed-power-prompt-current-cn16-2026-10-23/five-exact-branches-and-existing-rule-identities.json'],cwd=root)),'fullGameMethods':143,'fullGameCases':151,'matrix':matrix,'allNineOriginalFullGameSourcesByteExact':full_sources,'allOriginal110PairIds11Decks424242AndVictoryReplayAssertionsRetained':True,'trxSha256':current[3],'sql':sql,'allOriginal62SqlCaseObjectsAndOrderExact':True,'originalNetwork':wire,'newPeerViews':peer,'artifacts':downloads['artifacts'],'scopeDecision':decision,'originalSqlZipMembers':str(member_manifest.relative_to(root)),'exactTargetSqlGateSourceSha256':sha(gate_source),'soleN48CheckActually13638Cases7602MethodsPassed':True,'newExact5ZeroPrintedPowerPromptCasesActuallyPresent':True,'boundedHeadlessCurrentMainAndRealDatabaseEvidenceSeparate':True,'visibleHardwarePairAndPhysicalWindowsRemainSeparate':True,'wholePrintingOrGoalCertified':False}
output=w/'cif248d777-entire-full-independent-verification-v1.json';assert not output.exists();output.write_text(json.dumps(result,indent=2))
assert {str(p.relative_to(root)) for p in stage.rglob('*') if p.is_file()}=={m['path'] for m in members}
for row in members:
 p=root/row['path'];assert len(p.read_bytes())==row['bytes'] and sha(p.read_bytes())==row['sha256']
 with zipfile.ZipFile(artifacts['postgres-partition-'+str(row['partition'])]['path']) as z:assert p.read_bytes()==z.read(row['originalZipMember'])
 p.unlink()
for p in sorted([p for p in stage.rglob('*') if p.is_dir()],key=lambda p:len(p.parts),reverse=True):p.rmdir()
stage.rmdir()
(w/'cif248d777-verified-duplicate-sql-extraction-retirement-v1.json').write_text(json.dumps({'atUtc':now(),'files':len(members),'logicalBytes':sum(r['bytes'] for r in members),'allOriginalNineZipsAndMemberHashesRetained':True,'onlyVerifiedTemporaryIndependentExtractionRemoved':True,'physicalApfsBytesNotInferred':True},indent=2))
print('PASS fixedf248d777 actual13787/7743; all original13782/7741 plus exact5/23;143full151cases110pairs11decks424242;62SQL;original15network0leaks;all11success. OS hardware/Windows and full audit remain OPEN.',flush=True)
