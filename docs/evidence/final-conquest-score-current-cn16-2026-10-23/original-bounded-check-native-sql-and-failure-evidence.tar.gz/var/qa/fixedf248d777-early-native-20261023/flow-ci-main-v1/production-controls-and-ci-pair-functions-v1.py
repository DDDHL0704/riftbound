def local_stable():
 assert all(sha(root/p)==h for p,h in local_inputs['sourceHashes'].items())
 assert all(sha(root/'clients/godot/.godot/mono/temp/bin/Debug'/p)==h for p,h in local_inputs['nativeManagedRuntimeFiles'].items())

def checkpoint(name,value):
 with(evidence/name).open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2)

def count():
 assert room is not None and re.fullmatch('N48-ZERO-[0-9A-F]{10}',room)
 return int(query('riftbound_here_native',"select count(*) from command_log where match_id='"+room+"'"))

def save_rows(name):
 data={t:json.loads(query('riftbound_here_native',f"select coalesce(json_agg(t order by row_to_json(t)::text),'[]'::json)::text from(select * from {t} where match_id='{room}')t")) for t in tables}
 p=evidence/name;assert not p.exists();p.write_bytes(gzip.compress(json.dumps({'room':room,'originalRows':data},ensure_ascii=False,indent=2).encode(),mtime=0));return dict(path=str(p),sha256=sha(p),counts={t:len(v)for t,v in data.items()})

def launch(role,label,action=None,capture=False):
 app=Path(next(a['app']for a in pub['nativeApps']if a['label']==role));subprocess.run(['codesign','--verify','--deep','--strict',str(app)],check=True,capture_output=True)
 log=w/(label+'-original-native-console.log');png=w/(label+'-actual-own-viewport.png')
 args=[str(app/'Contents/MacOS/符文战场'),'--resolution','1280x720','--max-fps','30','--quit-after','3000','--','--riftbound-server=http://127.0.0.1:15847','--riftbound-session-file='+str(profiles/('session-'+role+'.json')),'--riftbound-smoke-connect-only']
 if action:args+=['--riftbound-smoke-ui-action='+action,'--riftbound-smoke-ui-submit']
 if capture:args+=['--riftbound-visual-screenshot='+str(png),'--riftbound-visual-screenshot-min-table-cards=0']
 env=dict(os.environ,DOTNET_DbgEnableMiniDump='0');env.pop('DOTNET_STARTUP_HOOKS',None)
 master,slave=pty.openpty();sink=log.open('xb',buffering=0)
 p=subprocess.Popen(args,cwd='/tmp',env=env,stdin=subprocess.DEVNULL,stdout=slave,stderr=slave,start_new_session=True);os.close(slave)
 def drain():
  try:
   while True:
    try:block=os.read(master,65536)
    except OSError as error:
     if error.errno==errno.EIO:break
     raise
    if not block:break
    sink.write(block)
  finally:os.close(master);sink.close()
 pump=threading.Thread(target=drain,daemon=True);pumps[p.pid]=pump;pump.start()
 record=dict(role=role,label=label,pid=p.pid,actualCommand=args,log=log.name,action=action,nonHeadless=True,ownViewportNotOsDesktopOrHardwareInput=True,all373CiPayloadsAndSignatureVerified=True)
 proof['ownedNativeProcesses'].append(record);item=(p,record,log);clients.append(item)
 if capture:current['viewportImages'].append(dict(role=role,stage=label,path=str(png)))
 return item

def stop(item):
 p,record,log=item;p.terminate();wait_exit(item,20)
 assert 'Termination requested; exiting through Godot.'in log.read_text(errors='replace')

def cold(stage,before):
 pair=[launch(role,stage+'-'+role,capture=True)for role in ['a','b']]
 native_wait(lambda:all(all(log_count(t[2],k)>=1 for k in ['Joined','Snapshot','Prompt'])for t in pair),'Both actual current Main initial private views',45,[t[0]for t in pair])
 native_wait(lambda:all((w/(stage+'-'+r+'-actual-own-viewport.png')).exists() and 'Visual screenshot saved:'in t[2].read_text(errors='replace')for r,t in zip(['a','b'],pair)),'Both actual GPU own viewports',45,[t[0]for t in pair])
 counts=[{k:log_count(t[2],k)for k in ['Joined','Snapshot','Prompt']}for t in pair];pid=api.pid
 assert set(subprocess.check_output(['/usr/sbin/lsof','-tiTCP:15847','-sTCP:LISTEN'],text=True).splitlines())=={str(pid)}
 api.kill();api.wait(timeout=10);assert api.returncode==-9;start_api(len(proof['ownedApiProcesses'])+1)
 native_wait(lambda:all(all(log_count(t[2],k)>counts[i][k]for k in counts[i])for i,t in enumerate(pair)),'Same current nonheadless pair recovers original stage',50,[t[0]for t in pair])
 after=export(stage+'-after-same-pair-cold-original-frame')
 assert all(after[k]==before[k]for k in ['commands','events','authoritativeState','openingSeed','replayInitialState'])
 for t in pair:stop(t)
 for row in current['viewportImages']:
  if row['stage'].startswith(stage+'-'):
   p=Path(row['path']);assert p.read_bytes().startswith(b'\x89PNG\r\n\x1a\n');row.update(sha256=sha(p),bytes=p.stat().st_size,actualPixelsNeedSeparateVisualRead=True)
 current['coldRestores'].append(dict(stage=stage,killedOwnApiPid=pid,sameNativePids=[t[0].pid for t in pair],wholeOriginalStateHistoryOpeningAndEmptyExact=True,lock=observe_lock()))
 print('CURRENT_NONHEADLESS_PAIRED_COLD',branch,stage,flush=True);return after

def native(action,actor,label,before):
 old=len(before['commands']);role='a'if actor==a else'b';action_dir=w/(label+'-actual-production-controls');action_dir.mkdir()
 candidate=next(c for c in before['playerViews'][actor]['prompt']['candidates']if c['action']==action and c['enabled'])
 action_label='不响应 · 让过'if action=='PASS_PRIORITY'else candidate['label']
 plan=dict(fixedCommit=pub['fixedCommit'],room=room,action=action,actionLabel=action_label,originalActor=actor,originalPromptId=before['playerViews'][actor]['prompt']['promptId'],originalSnapshotTick=before['authoritativeState']['tick'],choiceCount=1,optionalCostLabels=([choice['label']for requirement in candidate['metadata']['sourceRequirements']if requirement['sourceObjectId']=='PARENT'for choice in requirement.get('optionalCostChoices',[])if choice['id']=='ECHO']if branch=='flow-echo'and action=='PLAY_CARD'else[]))
 (action_dir/'original-server-action-plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2))
 local_stable();args=[str(sdk),'--path',str(root/'clients/godot'),'--resolution','1280x720','--max-fps','30','--quit-after','3000',str(control_scene),'--','--riftbound-server=http://127.0.0.1:15847','--riftbound-session-file='+str(profiles/('session-'+role+'.json')),'--riftbound-smoke-connect-only','--qa-action-folder='+str(action_dir)]
 log=action_dir/'actual-production-main-original-console.log';master,slave=pty.openpty();sink=log.open('xb',buffering=0);env=dict(os.environ,DOTNET_DbgEnableMiniDump='0');env.pop('DOTNET_STARTUP_HOOKS',None)
 p=subprocess.Popen(args,cwd='/tmp',env=env,stdin=subprocess.DEVNULL,stdout=slave,stderr=slave,start_new_session=True);os.close(slave)
 def drain():
  try:
   while True:
    try:block=os.read(master,65536)
    except OSError as error:
     if error.errno==errno.EIO:break
     raise
    if not block:break
    sink.write(block)
  finally:os.close(master);sink.close()
 pump=threading.Thread(target=drain,daemon=True);pumps[p.pid]=pump;pump.start()
 record=dict(role=role,label=label,pid=p.pid,actualCommand=args,log=str(log),action=action,nonHeadless=True,localSingleExistingSdkExact3374SourcesAnd23DebugPayloads=True,ciExportedEntryNotClaimed=True,actualProductionButtonsNotOsHardware=True)
 proof['ownedNativeProcesses'].append(record);item=(p,record,log);clients.append(item)
 native_wait(lambda:count()==old+1,'Exactly one original production control request '+action,55,[p])
 after=export(label+'-after-native-original-frame');command=after['commands'][-1]
 assert command['accepted'], 'Original actual native request was rejected: '+str(command.get('errorMessage'))
 native_wait(lambda:(action_dir/'actual-production-buttons-submitted.json').exists() and log_count(log,'Snapshot')>=2 and log_count(log,'Prompt')>=2,'Actual native submission and fresh views',25,[p])
 (action_dir/'actual-owner-post-command-views-verified.json').write_text(json.dumps(dict(originalCommandIndex=old,originalCompletedTick=command['completedTick'],frameConsistent=True)))
 wait_exit(item,15);local_stable()
 terminal=load(action_dir/'actual-production-main-controls-terminal.json');assert terminal['productionMainScript']=='res://scripts/Main.cs' and terminal['displayDriver']!='headless'
 assert after['commands'][:old]==before['commands'] and after['events'][:len(before['events'])]==before['events']
 raw=command['rawCommand'];assert command['playerId']==actor and command['commandType']==raw['cmdType']==action and raw['snapshotTick']==before['authoritativeState']['tick'] and raw['promptId']
 current['nativeCommands'].append(dict(index=old,action=action,actor=actor,completeOriginalCommand=command,productionButtonSignals=terminal['buttonSignals'],originalConsole=str(log),originalConsoleSha256=sha(log),localSdkAndCiPairEvidenceSeparatelyBound=True))
 print('ACTUAL_PRODUCTION_MAIN_CONTROL_ACCEPTED',branch,old,action,flush=True);return after
