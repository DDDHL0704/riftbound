import ast,datetime,errno,fcntl,gzip,hashlib,json,os,plistlib,pty,re,resource,socket,subprocess,threading,time,urllib.request
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');home=Path(__file__).resolve().parent;candidate=home.parent
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
functions=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py';native_functions=root/'var/qa/fixed55fdb-early-native-20261022/lab-ci-pair-v1/controlled-lab-native-owner-functions-v1.py';control_functions=home/'production-controls-and-ci-pair-functions-v1.py'
for source,names in [(functions,{'query','rooms','digests','observe_lock'}),(native_functions,{'frozen','start_api','export','native_wait','log_count','wait_exit'}),(control_functions,{'local_stable','checkpoint','count','save_rows','launch','stop','cold','native'})]:
 for node in ast.parse(source.read_text()).body:
  if isinstance(node,ast.FunctionDef)and node.name in names:
   body=ast.get_source_segment(source.read_text(),node).replace('live-controlled-lab-api-','live-current-f248-zero-api-');exec(compile(body,str(source),'exec'),globals())
pub=load(candidate/'frozen-fixedf248d777-native-composition-v1.json');assert pub['fixedCommit']=='f248d7774aca8776d288bb5d702e0b545b116a7e'and pub['actualRuleInputs']['identitySha256']=='18b1e240a29f0eab44071cd4ee2de16a428db660f1a1a632ecf18c875e4c9d74'
api_runtime=Path(pub['apiRuntimeRoot']);helpers=Path(pub['helperRuntimeRoot']);driver_dll=home/'gateway-preparation-source-v1/bin/Release/net10.0/FixedF248ZeroPowerPrepareV1.dll';original_profiles=root/'var/qa/fixed5edb1-early-native-20261023/ordinary-ci-pair-v1';local_inputs=load(candidate/'current-fixed-production-native-source3374-payload23-v1.json');assert len(local_inputs['sourceHashes'])==3374 and len(local_inputs['nativeManagedRuntimeFiles'])==23
sdk=Path('/Users/dinghaolin/.local/share/riftbound-tools/godot-4.7.2/Godot_mono.app/Contents/MacOS/Godot');controls=root/'var/qa/fixeda68bf-early-native-20261023/flow-ci-main-v1';control_source=controls/'actual-current-main-controls-v2.gd';control_scene=controls/'actual-current-main-controls-v2.tscn'
own_inputs={str(p):sha(p)for p in [Path(__file__),functions,native_functions,control_functions,driver_dll,driver_dll.with_suffix('.pdb'),home/'gateway-preparation-source-v1/Program.cs',home/'gateway-preparation-source-v1/probe.csproj',control_source,control_scene,sdk]}
terminal=home/'current-zero-prompt-four-live-original-rooms-owner-terminal-v1.json';assert not terminal.exists();guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a+');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof=dict(status='RUNNING_CURRENT_FIXED_ZERO_PROMPT_NATIVE_CI_AND_SDK_REAL_POSTGRES',startedAtUtc=now(),fixedCommit=pub['fixedCommit'],fixedCiRun=pub['fixedCiRun'],actualRuleInputs=pub['actualRuleInputs'],ownInputHashes=own_inputs,ownedApiProcesses=[],ownedNativeProcesses=[],branches=[],lockAtStart=observe_lock(),controlledDevPositionsNotOrdinaryOpening=True,ciExportDefaultMainAndSdkProductionButtonsRemainSeparate=True,doesNotCertifyOsHardwareOrPhysicalWindows=True,oneLiveProcessPerActor=True)
api=driver=power=None;clients=[];pumps={};started=False;room=None;audit=prior_native=before_audit=before_native=None;w=profiles=evidence=None
try:
 frozen();local_stable();assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket()as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid;sock.mkdir(exist_ok=True)
 subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(home/'owned-current-zero-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 audit=rooms('riftbound_acceptance');prior_native=rooms('riftbound_here_native');assert len(audit)==422 and len(prior_native)==111;before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',prior_native)
 for branch,scenario,generic in [('normal-ci','normal',True),('normal-native','normal',False),('flow','flow',False),('flow-echo','flow-echo',False)]:
  w=home/branch;w.mkdir();evidence=w/'original-native-records';evidence.mkdir();profiles=w/'original-controlled-prefix';room=None;start_api(len(proof['ownedApiProcesses'])+1);old_rooms=set(rooms('riftbound_here_native'))
  args=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(helpers/'Fixed708OriginalBandleTreeScoreV1.deps.json'),'--runtimeconfig',str(helpers/'Fixed708OriginalBandleTreeScoreV1.runtimeconfig.json'),str(driver_dll),str(profiles),str(original_profiles),scenario]
  with(w/'original-explicit-gateway-preparation.log').open('xb')as f:driver=subprocess.Popen(args,cwd=helpers,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0'));code=driver.wait(timeout=95)
  added=set(rooms('riftbound_here_native'))-old_rooms
  if len(added)==1:room=next(iter(added))
  assert code==0 and len(added)==1,'Original partial room retained; no reset or resubmission.'
  entry=load(profiles/'lightning-rush-original-entry-v1.json');assert entry['room']==room;a,b=entry['players'];first=export('initial-three-original-frame');assert len(first['commands'])==3 and[c['commandType']for c in first['commands']]==['ROOM_SEAT','ROOM_SEAT','DEV_SEED_SCENARIO:lightning-rush-'+scenario]
  assert first['openingSeed']!=0 and first['replayInitialState']['status']=='EMPTY'and not first['replayInitialState']['seats'];requirement=next(r for c in first['playerViews'][a]['prompt']['candidates']if c['action']=='PLAY_CARD'for r in c['metadata']['sourceRequirements']if r['sourceObjectId']=='PARENT');assert requirement['printedPowerCost']==0 and not requirement['printedPowerChoices']and not any(c['id'].startswith('PRINTED_POWER:')for c in requirement['optionalCostChoices'])
  current=dict(branch=branch,scenario=scenario,room=room,players=[a,b],coldRestores=[],nativeCommands=[],ciGenericOriginalSubmissions=[],viewportImages=[],initialOriginalRows=save_rows('initial-all-seven-original-tables.json.gz'));proof['branches'].append(current)
  frame=cold('before-parent',first)
  if generic:
   old_count=len(frame['commands']);pair=[launch('a','actual-ci-default-main-generic-play',action='PLAY_CARD'),launch('b','actual-ci-default-main-generic-play-waiter')];native_wait(lambda:count()==old_count+1,'Current fixed exported default Main must submit exactly one request',55,[t[0]for t in pair]);after=export('actual-ci-default-main-generic-play-original-frame');command=after['commands'][-1];assert command['accepted']and command['playerId']==a and command['commandType']=='PLAY_CARD'and not any(c.startswith('PRINTED_POWER:')for c in(command['rawCommand'].get('optionalCosts')or[]));native_wait(lambda:log_count(pair[0][2],'Snapshot')>=2 and log_count(pair[0][2],'Prompt')>=2,'Actual CI default Main has accepted request and fresh server views',25,[t[0]for t in pair]);current['ciGenericOriginalSubmissions'].append(dict(originalCommand=command,sourceRoute='ACTUAL_CURRENT_CI_EXPORTED_DEFAULT_MAIN_EXISTING_GENERIC_SMOKE_NOT_OS_HARDWARE'))
   for item in pair:stop(item)
   frame=after
  else:frame=native('PLAY_CARD',a,'play-parent',frame)
  expected_mana=3 if scenario=='flow-echo'else 2 if scenario=='flow'else 1;expected_power=1 if scenario.startswith('flow')else 0;pool=frame['authoritativeState']['runePools'][a];assert pool['mana']==30-expected_mana and pool['power']==30-expected_power and frame['commands'][-1]['rawCommand']['sourceObjectId']=='PARENT';current['actualPaidCost']=dict(mana=expected_mana,genericPower=expected_power,printedPower=0)
  step=0
  while frame['authoritativeState']['stackItems']:
   state=frame['authoritativeState'];choice=state.get('pendingCardChoice')
   if choice:
    assert choice['playerId']==a;frame=native('CHOOSE_CARDS',a,'choose-original-card-'+str(step),frame)
   else:
    actor=state['priorityPlayerId'];assert actor in [a,b];frame=native('PASS_PRIORITY',actor,'parent-pass-'+str(step),frame)
   step+=1;assert step<=8
  state=frame['authoritativeState'];own=state['playerZones'][a];echo=scenario=='flow-echo';flow=scenario.startswith('flow');assert not state.get('pendingCardChoice')and len(frame['commands'])==(8 if echo else 7)and all(c['accepted']for c in frame['commands']);assert len(own['mainDeck'])==(1 if echo else 4)and len(own['hand'])==(2 if echo else 1)and len(own['graveyard'])==(4 if echo else 2 if flow else 3);assert 'PARENT'in own['banished'if flow else'graveyard']and state['cardObjects']['PARENT']['objectGeneration']==2
  frame=cold('completed-original-spell',frame);current.update(status='PASS_CURRENT_FIXED_BOUNDED_LIVE_ZERO_PROMPT_COST_AND_NATIVE_CONTROLS_INDEPENDENT_ORIGINAL_READBACK_PENDING',commands=len(frame['commands']),events=len(frame['events']),finalOriginalRows=save_rows('final-all-seven-original-tables.json.gz'))
  api.terminate();api.wait(timeout=25);assert api.returncode==0
 assert len(set(rooms('riftbound_here_native'))-set(prior_native))==4;proof['status']='PASS_FOUR_FRESH_CURRENT_FIXED_ORIGINAL_NATIVE_ROOMS_CI_GENERIC_ZERO_PROMPT_AND_PRODUCTION_CONTROLS_INDEPENDENT_READBACK_PENDING'
except BaseException as error:
 proof.update(status='FAILED_CURRENT_ZERO_PROMPT_NATIVE_OWNER_OR_PRODUCT_ORIGINALS_RETAINED',errorType=type(error).__name__,error=str(error));raise
finally:
 if driver is not None and driver.poll()is None:driver.terminate();driver.wait(timeout=20)
 for p,record,log in clients:
  if p.poll()is None:p.terminate();p.wait(timeout=20);record['onlyOwnFailureCleanup']=True
  pumps[p.pid].join(timeout=10);record.update(exitCode=p.returncode,logSha256=sha(log),ptyFullyDrained=not pumps[p.pid].is_alive())
 if started and room is not None:
  try:export('owner-final-retained-original-frame')
  except BaseException as error:proof['finalFrameExportError']=type(error).__name__
 if api is not None and api.poll()is None:api.terminate();api.wait(timeout=25)
 proof['ownApiStopped']=api is None or api.poll()is not None
 if started:
  if before_audit is not None:proof.update(all422AuditSevenTablesExact=digests('riftbound_acceptance',audit)==before_audit,allOriginal111NativeSevenTablesExact=digests('riftbound_here_native',prior_native)==before_native,actualAuditRoomsAtStop=rooms('riftbound_acceptance'),actualNativeRoomsAtStop=rooms('riftbound_here_native'))
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None and power.poll()is None:power.terminate();power.wait(timeout=10)
 proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),allOwnInputsStable=all(sha(Path(p))==h for p,h in own_inputs.items()),local3374SourceInputs=local_inputs['sourceHashes'],local23NativeRuntimeInputs=local_inputs['nativeManagedRuntimeFiles']);frozen();local_stable()
 with terminal.open('x')as f:json.dump(proof,f,ensure_ascii=False,indent=2)
 fcntl.flock(guard,fcntl.LOCK_UN)
assert all(proof[k]for k in ['ownApiStopped','ownPostgresSmartStopped','all422AuditSevenTablesExact','allOriginal111NativeSevenTablesExact','allOwnInputsStable'])
print(proof['status'],flush=True)
