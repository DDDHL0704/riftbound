using System.Collections.Concurrent;
using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.Json.Serialization;
using Microsoft.AspNetCore.SignalR.Client;
using Microsoft.Extensions.DependencyInjection;
using Riftbound.Contracts;

Check(args.Length==3,"Fresh output, existing own QA profiles and finite Lightning Rush branch.");
var output=Path.GetFullPath(args[0]);var originals=Path.GetFullPath(args[1]);var branch=args[2];
Check(branch is "normal" or "flow" or "flow-empty" or "flow-echo" or "observed" or "flow-counter" or "flow-return-counter" or "flow-control","Only the eight current, explicit, finite scenarios.");
Check(!Directory.Exists(output),"Never overwrite any original room or profile.");Directory.CreateDirectory(output);
using var deadline=new CancellationTokenSource(TimeSpan.FromSeconds(80));var ct=deadline.Token;
var json=new JsonSerializerOptions(JsonSerializerDefaults.Web){WriteIndented=true};
using var http=new HttpClient();using var health=JsonDocument.Parse(await http.GetStringAsync("http://127.0.0.1:15847/health",ct));
Check(health.RootElement.GetProperty("environment").GetString()=="Development"&&health.RootElement.GetProperty("persistenceMode").GetString()=="postgres","Declared Development and actual PostgreSQL.");
var room="N48-ZERO-"+Guid.NewGuid().ToString("N")[..10].ToUpperInvariant();
using var trace=new StreamWriter(new GZipStream(new FileStream(Path.Combine(output,"original-private-controlled-wire.ndjson.gz"),FileMode.CreateNew),CompressionLevel.SmallestSize));
var profiles=new[]{"a","b"}.Select(r=>JsonNode.Parse(File.ReadAllText(Path.Combine(originals,"session-"+r+".json")))!).ToArray();
await using var a=new Side(profiles[0],"a",room,output,trace);await using var b=new Side(profiles[1],"b",room,output,trace);var sides=new[]{a,b};
foreach(var side in sides)await side.Connect();
await Until(()=>sides.All(s=>s.Snapshot.GetProperty("players").EnumerateObject().Count()==2),"Both original lobby seat views.");
var tick=a.Snapshot.GetProperty("tick").GetInt64();var scenario="lightning-rush-"+branch;
var seedIntent="n48-explicit-development-position-"+Guid.NewGuid().ToString("N");
await a.Hub.InvokeAsync("SeedScenario",room,a.Actor,scenario,seedIntent,ct);
await Until(()=>sides.All(s=>s.Snapshot.GetProperty("tick").GetInt64()>tick)&&a.Enabled("PLAY_CARD"),"Original seed recorded before any native gameplay submission.");
await File.WriteAllTextAsync(Path.Combine(output,"lightning-rush-original-entry-v1.json"),JsonSerializer.Serialize(new{status="ORIGINAL_TWO_SEATS_EXPLICIT_DEV_SEED_READY_BEFORE_ANY_NATIVE_GAMEPLAY",room,branch,scenario,seedIntent,players=sides.Select(s=>s.Actor).ToArray(),expectedOriginalJournalCommands=3,noGatewayGameplaySubmitted=true,originalEmptyAndOpeningSeedRetained=true,controlledPositionNotOrdinaryOpening=true},json),ct);
Console.WriteLine("PREPARED_CURRENT_LIGHTNING_RUSH "+branch+" original3 ready");
async Task Until(Func<bool> condition,string reason){while(!condition()){foreach(var s in sides)s.CheckErrors();await Task.Delay(20,ct);}foreach(var s in sides)s.CheckErrors();}
static void Check(bool value,string reason){if(!value)throw new Exception(reason);}

sealed class Side : IAsyncDisposable
{
    readonly ConcurrentQueue<string> errors = new(); readonly object gate = new();
    JsonElement snapshot, prompt; string? token;
    public string Actor { get; }
    public HubConnection Hub { get; }
    public JsonElement Snapshot { get { lock (gate) return snapshot; } }
    public JsonElement Prompt { get { lock (gate) return prompt; } }
    readonly JsonNode profile; readonly string role, room, output; readonly StreamWriter trace;
    public Side(JsonNode profile, string role, string room, string output, StreamWriter trace)
    {
        this.profile = profile; this.role = role; this.room = room; this.output = output; this.trace = trace; Actor = profile["handle"]!.GetValue<string>();
        Hub = new HubConnectionBuilder().WithUrl("http://127.0.0.1:15847/hubs/game")
            .AddJsonProtocol(o => { o.PayloadSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase; o.PayloadSerializerOptions.Converters.Add(new JsonStringEnumConverter()); }).Build();
        Hub.On<WsServerMessage>("Joined", m => Receive("Joined", m));
        Hub.On<WsServerMessage>("Snapshot", m => Receive("Snapshot", m));
        Hub.On<WsServerMessage>("Prompt", m => Receive("Prompt", m));
        Hub.On<WsServerMessage>("Events", m => Receive("Events", m));
        Hub.On<WsServerMessage>("Error", m => Receive("Error", m));
    }
    void Receive(string kind, WsServerMessage m)
    {
        if (m.Payload is not JsonElement payload) return;
        lock (gate)
        {
            if (kind == "Joined")
            {
                token = payload.GetProperty("reconnectToken").GetString();
                var current = new JsonObject { ["handle"] = Actor, ["playerKey"] = profile["playerKey"]!.GetValue<string>(), ["roomId"] = m.RoomId,
                    ["reconnectToken"] = token, ["lastDeckId"] = profile["lastDeckId"]!.GetValue<string>(), ["serverUrl"] = "http://127.0.0.1:15847" };
                var path = Path.Combine(output, "session-" + role + ".json");
                File.WriteAllText(path, current.ToJsonString(new JsonSerializerOptions { WriteIndented = true }));
                if (!OperatingSystem.IsWindows()) File.SetUnixFileMode(path, UnixFileMode.UserRead | UnixFileMode.UserWrite);
            }
            else if (kind == "Snapshot") snapshot = payload.Clone();
            else if (kind == "Prompt") prompt = payload.Clone();
            else if (kind == "Error") errors.Enqueue(payload.GetProperty("code").GetString() ?? "UNKNOWN");
            if (kind != "Joined") lock (trace) { trace.WriteLine(JsonSerializer.Serialize(new { actor = Actor, kind, payload })); trace.Flush(); }
        }
    }
    public async Task Connect()
    {
        using var limit = new CancellationTokenSource(TimeSpan.FromSeconds(20));
        await Hub.StartAsync(limit.Token);
        var auth = await Hub.InvokeAsync<AuthResultDto>("Authenticate", Actor, profile["playerKey"]!.GetValue<string>(), limit.Token);
        if (!auth.Authenticated) throw new Exception("Existing own auth rejected.");
        await Hub.InvokeAsync("JoinRoom", room, Actor, (string?)null, limit.Token);
        while (token is null || Snapshot.ValueKind != JsonValueKind.Object || Prompt.ValueKind != JsonValueKind.Object) { CheckErrors(); await Task.Delay(20, limit.Token); }
    }
    public bool Enabled(string action) => Prompt.ValueKind == JsonValueKind.Object && Prompt.GetProperty("actionable").GetBoolean()
        && Prompt.GetProperty("candidates").EnumerateArray().Any(c => c.GetProperty("action").GetString() == action && c.GetProperty("enabled").GetBoolean());
    public void CheckErrors() { if (errors.TryPeek(out var error)) throw new Exception("Actual controlled preparation error " + error); }
    public ValueTask DisposeAsync() => Hub.DisposeAsync();
}
