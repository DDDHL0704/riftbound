import ast,datetime,errno,fcntl,gzip,hashlib,json,os,plistlib,pty,re,resource,socket,subprocess,threading,time,urllib.request
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');n=Path(__file__).resolve().parent;w=n/'ordinary-ci-pair-v1';w.mkdir();home=w
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486');tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
functions=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py';base_functions=root/'var/qa/fixed55fdb-early-native-20261022/lab-ci-pair-v1/controlled-lab-native-owner-functions-v1.py';control_functions=n/'flow-ci-main-v1/production-controls-and-ci-pair-functions-v1.py'
for source,names in [(functions,{'query','rooms','digests','observe_lock'}),(base_functions,{'frozen','start_api','export','native_wait','log_count','wait_exit'}),(control_functions,{'checkpoint','save_rows','launch','stop','cold','native','local_stable'})]:
 for node in ast.parse(source.read_text()).body:
  if isinstance(node,ast.FunctionDef)and node.name in names:
   body=ast.get_source_segment(source.read_text(),node)
   if node.name=='start_api':body=body.replace("'Development'","'Production'")
   exec(compile(body,str(source),'exec'),globals())
pub=load(n/'frozen-fixedf248d777-native-composition-v1.json');api_runtime=Path(pub['apiRuntimeRoot']);helpers=Path(pub['helperRuntimeRoot']);profiles=w;evidence=w/'original-native-records';evidence.mkdir()
local_inputs=load(n/'current-fixed-production-native-source3374-payload23-v1.json');sdk=Path('/Users/dinghaolin/.local/share/riftbound-tools/godot-4.7.2/Godot_mono.app/Contents/MacOS/Godot');control_scene=root/'var/qa/fixeda68bf-early-native-20261023/flow-ci-main-v1/actual-current-main-controls-v2.tscn'
previous=load(n/'flow-ci-main-v1/independent-four-originals-readonly-owner-terminal-v1.json');assert previous['status'].startswith('PASS_CURRENT_F248_INDEPENDENT_')and previous['ownPostgresSmartStopped']and previous['all422AuditSevenTablesExact']and previous['all115NativeSevenTablesExact']
original_profiles=root/'var/qa/fixed5edb1-early-native-20261023/ordinary-ci-pair-v1'
for role in ['a','b']:(w/('session-'+role+'.json')).write_bytes((original_profiles/('session-'+role+'.json')).read_bytes())
own_inputs={str(p):sha(p)for p in [Path(__file__),functions,base_functions,control_functions,control_scene,root/'var/qa/fixeda68bf-early-native-20261023/flow-ci-main-v1/actual-current-main-controls-v2.gd',sdk]}
def count():
 assert re.fullmatch('N27-RETARGET-[0-9A-F]{10}',room)
 return int(query('riftbound_here_native',"select count(*) from command_log where match_id='"+room+"'"))
def run_driver(args,log,timeout):
 global driver
 with(w/log).open('xb')as output:driver=subprocess.Popen(args,cwd=helpers,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0'),stdout=output,stderr=subprocess.STDOUT);code=driver.wait(timeout=timeout)
 assert code==0,'Original driver failed; original journal, room and private profiles retained.'
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof=dict(status='RUNNING_CURRENT_ORDINARY_OPENING_NATIVE_CONTROLS_SCORE_EIGHT_AND_NETWORK',startedAtUtc=now(),fixedCommit=pub['fixedCommit'],fixedCiRun=pub['fixedCiRun'],actualRuleInputs=pub['actualRuleInputs'],ownInputHashes=own_inputs,ownedApiProcesses=[],ownedNativeProcesses=[],lockAtStart=observe_lock(),ordinaryOpeningNoDevSeedOrHistoryRewrite=True,sourceNativeControlsAndCiPairGpuViewsSeparatelyBound=True,hardwareAndPhysicalWindowsOpen=True)
current=dict(branch='ordinary',coldRestores=[],nativeCommands=[],viewportImages=[]);proof['ordinaryNative']=current;branch='ordinary';api=driver=power=None;clients=[];pumps={};started=False;room=None;audit=prior_native=before_audit=before_native=None
try:
 frozen();local_stable();assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket()as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid;sock.mkdir(exist_ok=True)
 subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'owned-current-ordinary-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 audit=rooms('riftbound_acceptance');prior_native=rooms('riftbound_here_native');assert audit==previous['actualAuditRoomsAtStop']and prior_native==previous['actualNativeRoomsAtStop']and len(audit)==422 and len(prior_native)==115
 before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',prior_native);start_api(1)
 prefix=w/'original-ordinary-prefix';run_driver(['/Users/dinghaolin/.dotnet/dotnet',str(helpers/'Fixed564SafeNativeReversalPrefix.dll'),'http://127.0.0.1:15847',str(prefix),str(w)],'original-ordinary-prefix-driver-console-v1.log',780)
 entry=load(prefix/'pending-original-native-prefix-receipt.json');room=entry['room'];a,b=entry['players'];journal_count=entry['acceptedCommands']+2;current.update(room=room,players=[a,b]);first=export('initial-ordinary-original-prefix')
 assert len(first['commands'])==journal_count and all(c['accepted']for c in first['commands'])and not any(c['commandType'].startswith('DEV_')for c in first['commands'])
 assert[c['playerId']for c in first['commands'][:2]]==[a,b]and all(c['commandType']=='ROOM_SEAT'for c in first['commands'][:2])and first['openingSeed']!=0 and first['replayInitialState']['status']=='EMPTY'and not first['replayInitialState']['seats']
 current['initialOriginalRows']=save_rows('initial-ordinary-all-seven-original-tables.json.gz');frame=cold('ordinary-pending-control-choice',first)
 frame=native('PAY_COST',b,'ordinary-native-keep',frame);assert frame['commands'][-1]['rawCommand']['paymentChoiceIds']==['KEEP_ALL']
 for i in range(2):
  actor=frame['authoritativeState']['priorityPlayerId'];assert actor in[a,b];frame=native('PASS_PRIORITY',actor,'ordinary-native-priority-'+str(i),frame)
 assert len(frame['commands'])==journal_count+3 and not frame['authoritativeState']['stackItems']and frame['authoritativeState']['pendingPayment']is None
 frame=cold('ordinary-after-original-native-controls',frame);state=frame['authoritativeState'];supported={'OGN·275/298','OGN·277/298','OGN·278/298'}
 all_fields=[id for z in state['playerZones'].values()for id in z['battlefields']];own_fields=[id for id in state['playerZones'][a]['battlefields']if state['cardObjects'][id]['cardNo']in supported]
 assert len(all_fields)==2 and len(own_fields)==1 and all(state['cardObjects'][id]['cardNo']in supported for id in all_fields)and state['cardObjects'][own_fields[0]]['ownerId']==a
 field_card=state['cardObjects'][own_fields[0]]['cardNo'];destination='BATTLEFIELD:'+own_fields[0];gateway=29 if field_card=='OGN·275/298' else 17
 score_dll=root/'var/qa/fixed68ba1-early-native-20261022/same-original275-score-source-v1/bin/Release/net10.0/Fixed68ba1SameOriginal275ScoreV1.dll'if field_card=='OGN·275/298'else root/'var/qa/fixed267ab-early-native-20261022/executed-own-native-readers-and-drivers-v1/Fixed267abSameOriginal277ScoreV1.dll'if field_card=='OGN·277/298'else helpers/'Fixed708OriginalBandleTreeScoreV1.dll'
 assert score_dll.is_file();own_inputs[str(score_dll)]=sha(score_dll);score=w/'original-normal-score-continuation'
 run_driver(['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(helpers/'Fixed708OriginalBandleTreeScoreV1.deps.json'),'--runtimeconfig',str(helpers/'Fixed708OriginalBandleTreeScoreV1.runtimeconfig.json'),str(score_dll),'http://127.0.0.1:15847',str(score),str(w),str(prefix/'pending-original-native-prefix-receipt.json'),str(evidence/'ordinary-after-original-native-controls-after-same-pair-cold-original-frame.json.gz'),destination],'original-normal-score-driver-console-v1.log',330)
 score_receipt=load(score/'normal-original-score-continuation-receipt.json');assert score_receipt['winningScore']==8 and score_receipt['continuationCommands']==gateway
 final=export('final-original-normal-eight-zero-score');state=final['authoritativeState'];assert state['status']=='FINISHED'and state['winnerPlayerId']==a and state['playerScores']=={a:8,b:0}and len(final['commands'])==journal_count+3+gateway
 assert final['commands'][:journal_count+3]==frame['commands']and final['events'][:len(frame['events'])]==frame['events']and final['openingSeed']==first['openingSeed']and final['replayInitialState']==first['replayInitialState']and all(c['commandType']!='SURRENDER'and c['accepted']for c in final['commands'])
 final=cold('ordinary-final-normal-eight-zero',final);current['finalOriginalRows']=save_rows('final-ordinary-all-seven-original-tables.json.gz')
 proof.update(room=room,players=[a,b],originalGatewayPrefixCommands=entry['acceptedCommands'],originalServerSeatCommands=2,originalJournalPrefixCommands=journal_count,nativeAcceptedGameplayCommands=3,totalCommands=len(final['commands']),events=len(final['events']),winningScore=8,losingScore=0,finalTurn=state['turnNumber'],actualScoreFieldCardNo=field_card,actualOriginalLegalScoreDestination=destination,normalGatewayCommands=gateway,originalNormalGatewayCommands=17,heldSkillPriorityPasses=gateway-17,rawFinalFrame=str(evidence/'final-original-normal-eight-zero-score.json.gz'),originalScoreIntentFile=str(score/'all-original-normal-score-continuation-intents.json'))
 network_before=rooms('riftbound_here_native');network_log=w/'actual-current-network-smoke-original-v1.log';network_env=dict(os.environ,RIFTBOUND_SERVER_URL='http://127.0.0.1:15847',DOTNET_DbgEnableMiniDump='0')
 with network_log.open('xb')as output:driver=subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet',str(Path(pub['networkRuntimeRoot'])/'Riftbound.NativeNetworkSmoke.dll')],cwd=Path(pub['networkRuntimeRoot']),env=network_env,stdout=output,stderr=subprocess.STDOUT);network_code=driver.wait(timeout=90)
 assert network_code==0;text=network_log.read_text();wire=json.loads(next(line[len('NATIVE_ROOM_IDENTITY_EVIDENCE '):]for line in text.splitlines()if line.startswith('NATIVE_ROOM_IDENTITY_EVIDENCE ')));peer=json.loads(next(line[len('NATIVE_ROOM_SEAT_PEER_EVIDENCE '):]for line in text.splitlines()if line.startswith('NATIVE_ROOM_SEAT_PEER_EVIDENCE ')))
 assert wire['rejectedActions']==15 and wire['leakedPrivateMessages']==0 and wire['validReconnectTokenWasSupplied']and peer['firstPlayerOriginalTick']==1 and peer['firstPlayerRefreshedTick']==peer['secondPlayerTick']==2 and peer['privateViewers']==2 and peer['explicitSnapshotRequests']==peer['commandRetries']==peer['wrongViewerMessages']==0
 assert set(rooms('riftbound_here_native'))-set(network_before)=={wire['room'],peer['room']};proof.update(networkOriginalEvidence=wire,newPeerWireEvidence=peer,networkLogSha256=sha(network_log),twoSeparateNewNetworkRooms=[wire['room'],peer['room']])
 proof['status']='PASS_CURRENT_ORDINARY_NORMAL_SCORE_EIGHT_ZERO_THREE_PRODUCTION_CONTROL_INPUTS_THREE_CI_PAIR_GPU_COLD_STAGES_NETWORK15_REJECTIONS_ZERO_LEAKS_INDEPENDENT_ORIGINAL_READBACK_PENDING';print(proof['status'],flush=True)
except BaseException as error:
 proof.update(status='FAILED_CURRENT_ORDINARY_ORIGINAL_ROOM_RETAINED',errorType=type(error).__name__,error=str(error));raise
finally:
 if driver is not None and driver.poll()is None:driver.terminate();driver.wait(timeout=20)
 for p,record,log in clients:
  if p.poll()is None:p.terminate();p.wait(timeout=20);record['onlyOwnFailureCleanup']=True
  pumps[p.pid].join(timeout=10);record.update(exitCode=p.returncode,logSha256=sha(log),ptyFullyDrained=not pumps[p.pid].is_alive())
 if started and room is not None:
  try:export('owner-final-original-ordinary-frame')
  except BaseException as error:proof['finalFrameExportError']=type(error).__name__
 if api is not None and api.poll()is None:api.terminate();api.wait(timeout=25)
 proof['ownApiStopped']=api is None or api.poll()is not None
 if started:
  if before_audit is not None:proof.update(all422AuditSevenTablesExact=digests('riftbound_acceptance',audit)==before_audit,all115PriorNativeSevenTablesExact=digests('riftbound_here_native',prior_native)==before_native,actualAuditRoomsAtStop=rooms('riftbound_acceptance'),actualNativeRoomsAtStop=rooms('riftbound_here_native'))
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None and power.poll()is None:power.terminate();power.wait(timeout=10)
 frozen();local_stable();proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),allOwnInputsStable=all(sha(Path(p))==h for p,h in own_inputs.items()))
 with(w/'current-ordinary-score-network-owner-terminal-v1.json').open('x')as output:json.dump(proof,output,ensure_ascii=False,indent=2)
 fcntl.flock(guard,fcntl.LOCK_UN)
assert all(proof[k]for k in ['ownApiStopped','ownPostgresSmartStopped','all422AuditSevenTablesExact','all115PriorNativeSevenTablesExact','allOwnInputsStable'])
