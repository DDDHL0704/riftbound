from pathlib import Path
import datetime,gzip,hashlib,io,json,os,plistlib,subprocess,tempfile,zipfile
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;old=root/'var/qa/fixeda68bf-early-native-20261023';fixed='f248d7774aca8776d288bb5d702e0b545b116a7e';run=39866108629;load=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def api(s):
 raw=subprocess.check_output(['gh','api',s],cwd=root,timeout=45);return raw,json.loads(raw)
def write(p,v):
 with p.open('x')as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==fixed
raw_jobs,jobs=api('repos/DDDHL0704/riftbound/actions/runs/'+str(run)+'/jobs?per_page=100');raw_art,art=api('repos/DDDHL0704/riftbound/actions/runs/'+str(run)+'/artifacts?per_page=100')
for name in ['desktop (macos-latest)','desktop (windows-latest)']:assert next(j for j in jobs['jobs']if j['name']==name)['conclusion']=='success'
items={a['name']:a for a in art['artifacts']};assert {'native-macos-latest','native-windows-latest'}<=items.keys();folder=w/'native-current';assert not folder.exists();folder.mkdir()
for name,data in [('native-jobs-original-v1.json.gz',raw_jobs),('native-artifacts-original-v1.json.gz',raw_art)]:
 p=w/name;assert not p.exists();p.write_bytes(gzip.compress(data,mtime=0))
receipts=[]
for platform,name,filename in [('mac','native-macos-latest','mac-ci-artifact.zip'),('windows','native-windows-latest','windows-ci-artifact.zip')]:
 a=items[name];assert a['workflow_run']['head_sha']==fixed and not a['expired'];out=folder/filename;attempts=[]
 for index in range(1,4):
  part=folder/(filename+'.transport-'+str(index)+'.part')
  with part.open('xb')as stream:p=subprocess.run(['gh','api','repos/DDDHL0704/riftbound/actions/artifacts/'+str(a['id'])+'/zip'],cwd=root,stdout=stream,stderr=subprocess.PIPE,timeout=150)
  raw=part.read_bytes();valid=p.returncode==0 and len(raw)==a['size_in_bytes']and'sha256:'+sha(raw)==a['digest'];attempts.append(dict(attempt=index,exitCode=p.returncode,bytes=len(raw),sha256=sha(raw),stderrSha256=sha(p.stderr),validBackendSizeAndSha256=valid))
  if valid:part.rename(out);break
 else:raise RuntimeError('Backend artifact transport mismatch: '+name)
 with zipfile.ZipFile(out)as z:
  assert z.testzip()is None
  entries=[dict(name=i.filename,bytes=i.file_size,crc32=f'{i.CRC:08x}')for i in z.infolist()]
  for i in z.infolist():
   assert not Path(i.filename).is_absolute()and'..'not in Path(i.filename).parts
   if not i.is_dir()and i.filename.startswith('ci-logs/'):
    target=folder/'ci-logs'/platform/Path(i.filename).name;target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists();target.write_bytes(z.read(i))
 receipts.append(dict(name=name,id=a['id'],filename=filename,actualBytes=len(raw),actualSha256=sha(raw),backendDigest=a['digest'],allOuterZipCrcVerified=True,entries=entries,downloadAttempts=attempts));print('VERIFIED_CURRENT_ORIGINAL_INSTALLER',platform,len(raw),flush=True)
write(w/'current-fixed-native-download-original-result-v1.json',dict(atUtc=now(),status='CURRENT_TWO_PLATFORM_ORIGINAL_INSTALLERS_BACKEND_SIZE_SHA256_CRC_VERIFIED',fixedCommit=fixed,runId=run,artifacts=receipts,noSdkTemplateDatabaseOrWorktreeCopy=True,physicalWindows='OPEN'))
platform_proof=[];original_files=None;payloads=None;old_manifest=load(old/'native-app-inputs.json');payload_paths=set(old_manifest['ciManagedAndPckPayloads']);assert len(payload_paths)==373
for platform,filename in [('mac','mac-ci-artifact.zip'),('windows','windows-ci-artifact.zip')]:
 outer=folder/filename
 with zipfile.ZipFile(outer)as z:
  inner_name=next(i for i in z.namelist()if i.endswith('.zip'));inner_raw=z.read(inner_name)
 with zipfile.ZipFile(io.BytesIO(inner_raw))as inner:
  assert inner.testzip()is None
  names=inner.namelist();assert all(not Path(name).is_absolute()and'..'not in Path(name).parts for name in names)
  if platform=='mac':
   prefix=next(name.split('Contents/',1)[0]for name in names if name.endswith('Contents/Info.plist'));original_files={name[len(prefix):]:sha(inner.read(name))for name in names if not name.endswith('/')};assert len(original_files)==415 and payload_paths<=original_files.keys();payloads={p:original_files[p]for p in sorted(payload_paths)}
   with tempfile.TemporaryDirectory(prefix='current-verified-mac-inner-',dir=w)as temp:
    temp=Path(temp);original=temp/'original-inner.zip';original.write_bytes(inner_raw);dest=temp/'unpacked';subprocess.run(['/usr/bin/ditto','-x','-k',str(original),str(dest)],check=True)
    apps=list(dest.glob('*.app'));assert len(apps)==1;app=w/'Riftbound-A.app';assert not app.exists();apps[0].rename(app)
   actual={str(p.relative_to(app)):sha(p.read_bytes())for p in app.rglob('*')if p.is_file()};assert actual==original_files
  boot=(folder/'ci-logs'/platform/'exported-boot.log').read_text(errors='replace');lifecycle=(folder/'ci-logs'/platform/'rune-table-lifecycle.log').read_text(errors='replace');assert 'Client booted.'in boot and'Official catalog loaded: 1037 cards.'in boot and'ERROR:'not in boot and'ERROR:'not in lifecycle and'passed'in lifecycle.lower()
  platform_proof.append(dict(platform=platform,outerSha256=sha(outer.read_bytes()),innerMember=inner_name,innerSha256=sha(inner_raw),innerCrcVerified=True,innerEntries=len(names),bootLogSha256=sha((folder/'ci-logs'/platform/'exported-boot.log').read_bytes()),lifecycleLogSha256=sha((folder/'ci-logs'/platform/'rune-table-lifecycle.log').read_bytes()),fixedCommit=fixed,fixedCiRun=run,physicalWindowsNotClaimed=True))
app_a=w/'Riftbound-A.app';app_b=w/'Riftbound-B.app';assert not app_b.exists();subprocess.run(['/bin/cp','-cR',str(app_a),str(app_b)],check=True);apps=[]
for role,app in [('a',app_a),('b',app_b)]:
 before={str(p.relative_to(app)):sha(p.read_bytes())for p in app.rglob('*')if p.is_file()};assert before==original_files
 source=(old/('qa-launcher-'+role+'.c')).read_text().replace(str(old),str(w));launcher_source=w/('qa-launcher-'+role+'.c');assert not launcher_source.exists();launcher_source.write_text(source)
 binary=app/'Contents/MacOS/riftbound-qa-launcher';subprocess.run(['/usr/bin/clang','-O2',str(launcher_source),'-o',str(binary)],check=True,capture_output=True)
 info=app/'Contents/Info.plist';value=plistlib.loads(info.read_bytes());value.update(CFBundleIdentifier='com.riftbound.qa.current-'+fixed[:8]+'.'+role,CFBundleExecutable='riftbound-qa-launcher',CFBundleName='Riftbound-'+role.upper(),CFBundleDisplayName='Riftbound-'+role.upper());info.write_bytes(plistlib.dumps(value,fmt=plistlib.FMT_XML))
 for target in [app/'Contents/MacOS/符文战场',app]:subprocess.run(['/usr/bin/codesign','--force','--sign','-',str(target)],check=True,capture_output=True)
 subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict',str(app)],check=True,capture_output=True)
 assert all(sha((app/p).read_bytes())==h for p,h in payloads.items());after={str(p.relative_to(app)):sha(p.read_bytes())for p in app.rglob('*')if p.is_file()};changed=sorted(p for p in before if before[p]!=after.get(p));added=sorted(after.keys()-before.keys());assert set(changed)=={'Contents/Info.plist','Contents/_CodeSignature/CodeResources','Contents/MacOS/符文战场'}and added==['Contents/MacOS/riftbound-qa-launcher']
 apps.append(dict(label=role,app=str(app),bundleId=value['CFBundleIdentifier'],all373CiManagedAndPckFilesExact=True,deepStrictAdHocSignatureVerified=True,changedNativeOrBundleFiles=changed,addedLauncher=added,launcherSourceSha256=sha(launcher_source.read_bytes()),profilePath=str(w/('session-'+role+'.json')),launcherPath=str(binary)))
write(w/'native-app-inputs.json',dict(recordedAtUtc=now(),fixedCommit=fixed,runId=run,originalInnerZipCrcVerified=True,originalPackageFiles=original_files,ciManagedAndPckPayloads=payloads,apps=apps,platformArchiveAndLogProof=platform_proof,notYetVisibleAcceptance=True,localVisibleBootNotYetExecuted=True,supersededFixedA68bfPairWillBeRetiredOnlyAfterNewUsabilityVerification=True,physicalWindows='OPEN',noPermanentInnerZipOrUnpackedDuplicateRetained=True,singleExistingSdkAndTemplatesReused=True))
print('CURRENT_FIXED_CI_PAIR_PREPARED373_EXACT_PAYLOADS_EACH_CODESIGN_STRICT_OLD_PAIR_NOT_YET_REMOVED',fixed,flush=True)
