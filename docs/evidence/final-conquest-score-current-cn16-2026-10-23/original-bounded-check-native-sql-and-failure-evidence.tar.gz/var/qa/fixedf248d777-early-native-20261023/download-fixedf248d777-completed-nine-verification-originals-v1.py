from pathlib import Path
import subprocess,json,hashlib,zipfile,datetime
w=Path(__file__).resolve().parent
fixed="f248d7774aca8776d288bb5d702e0b545b116a7e";run=39866108629
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
status=json.loads(subprocess.check_output(["gh","run","view",str(run),"--json","databaseId,headSha,status,conclusion,jobs,url"],text=True))
assert status["headSha"]==fixed and status["databaseId"]==run
jobs={j["name"]:j["conclusion"]for j in status["jobs"]}
assert status["status"]=="completed"and status["conclusion"]=="success"and len(jobs)==11 and all(x=="success"for x in jobs.values()),"Entire fixed CI must actually succeed before artifact closure."
metadata=json.loads(subprocess.check_output(["gh","api",f"repos/DDDHL0704/riftbound/actions/runs/{run}/artifacts"],text=True))
expected={"conformance-results","verification-scope","native-network-results","postgres-results","full-verification-gate"}|{f"postgres-partition-{i}"for i in range(4)}
artifacts={a["name"]:a for a in metadata["artifacts"]if a["name"]in expected}
assert set(artifacts)==expected and len(artifacts)==9
stage=w/"cif248d777-complete-originals-v1";stage.mkdir(exist_ok=True)
status_path=w/"cif248d777-complete-run-original-v1.json";meta_path=w/"cif248d777-complete-artifact-metadata-original-v1.json"
for p,d in [(status_path,status),(meta_path,metadata)]:
 if p.exists():assert json.loads(p.read_text())==d
 else:p.write_text(json.dumps(d,indent=2))
receipts=[]
for name,a in sorted(artifacts.items()):
 assert not a["expired"]and a["digest"].startswith("sha256:")and a["workflow_run"]["head_sha"]==fixed
 target=stage/(name+".zip");attempts=[]
 if target.exists():attempts.append(dict(mode="REUSE_SAME_ORIGINAL_REVERIFIED_NO_DUPLICATE_DOWNLOAD"))
 else:
  with target.open("xb")as out:subprocess.run(["gh","api",f"repos/DDDHL0704/riftbound/actions/artifacts/{a['id']}/zip"],stdout=out,check=True)
  attempts.append(dict(mode="ACTUAL_ORIGINAL_BACKEND_ARTIFACT_DOWNLOAD"))
 assert target.stat().st_size==a["size_in_bytes"]and "sha256:"+sha(target)==a["digest"]
 with zipfile.ZipFile(target)as z:assert z.testzip()is None
 receipts.append(dict(name=name,id=a["id"],path=str(target),bytes=target.stat().st_size,sha256=sha(target),backendDigest=a["digest"],allZipCrcVerified=True,attempts=attempts))
 print("ORIGINAL_FIXED_VERIFICATION_ZIP",name,target.stat().st_size,flush=True)
receipt=w/"cif248d777-all-nine-original-artifacts-receipt-v1.json";assert not receipt.exists()
receipt.write_text(json.dumps(dict(status="ACTUAL_ALL11_SUCCESS_NINE_VERIFICATION_ORIGINALS_BACKEND_SIZE_SHA256_CRC_VERIFIED",atUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),fixedCommit=fixed,runId=run,metadataReceipts=[str(status_path),str(meta_path)],jobs=jobs,artifacts=receipts,latestTwoNativeInstallersAlreadyVerifiedNotDownloadedAgain=True),indent=2))
