from pathlib import Path
import ast,datetime,fcntl,hashlib,json,os,plistlib,resource,subprocess
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');home=Path(__file__).resolve().parent;scope=home/'flow-ci-main-v1';load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486');tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
functions=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
for node in ast.parse(functions.read_text()).body:
 if isinstance(node,ast.FunctionDef)and node.name in {'query','rooms','digests','observe_lock'}:exec(compile(ast.get_source_segment(functions.read_text(),node),str(functions),'exec'),globals())
pub=load(home/'frozen-fixedf248d777-native-composition-v1.json');local=load(home/'current-fixed-production-native-source3374-payload23-v1.json');reader=home/'zero-native-independent-reader-source-v1/bin/Release/net10.0/IndependentCurrentZeroPowerNativeV1.dll';project=reader.parents[3]
own={str(p):sha(p)for p in [Path(__file__),functions,reader,reader.with_suffix('.pdb'),project/'Program.cs',project/'probe.csproj']};helper=Path(pub['helperRuntimeRoot']);api=Path(pub['apiRuntimeRoot'])
def frozen():
 assert all(sha(api/p)==h for p,h in pub['runtimeFiles'].items())and all(sha(helper/p)==h for p,h in pub['helperRuntimeFiles'].items())
 assert all(sha(root/p)==h for p,h in local['sourceHashes'].items())and all(sha(root/'clients/godot/.godot/mono/temp/bin/Debug'/p)==h for p,h in local['nativeManagedRuntimeFiles'].items())
 assert all(sha(Path(a['app'])/p)==h for a in pub['nativeApps']for p,h in pub['ciManagedAndPckPayloads'].items())
frozen();guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a+');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB);terminal=scope/'independent-four-originals-readonly-owner-terminal-v1.json';output=scope/'independent-four-originals-readonly-result-v1.json';assert not terminal.exists()and not output.exists();proof=dict(status='RUNNING_CURRENT_F248_INDEPENDENT_ORIGINALS_READONLY',startedAtUtc=now(),fixedCommit=pub['fixedCommit'],actualRuleInputs=pub['actualRuleInputs'],ownInputHashes=own,lockAtStart=observe_lock());started=False;before_audit=before_native=None;power=None
try:
 assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3;power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(scope/'independent-current-zero-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],check=True,capture_output=True);started=True
 audit=rooms('riftbound_acceptance');native=rooms('riftbound_here_native');assert len(audit)==422 and len(native)==115;before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',native)
 command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(helper/'Riftbound.Api.deps.json'),'--runtimeconfig',str(helper/'Riftbound.Api.runtimeconfig.json'),str(reader),str(scope),str(output)];proof['actualCommand']=command
 env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit;Options=-c default_transaction_read_only=on',DOTNET_DbgEnableMiniDump='0');env.pop('DOTNET_STARTUP_HOOKS',None)
 with(scope/'independent-four-originals-readonly-original-console-v1.log').open('xb')as log:r=subprocess.run(command,cwd=helper,env=env,stdout=log,stderr=subprocess.STDOUT)
 proof['exitCode']=r.returncode;assert r.returncode==0
 result=load(output);actual=result['actualLoadedFourAssemblies'];assert actual['actualRuleInputs']==pub['actualRuleInputs']and Path(actual['baseDirectory'])==helper
 for a in actual['assemblies']:assert Path(a['path'])==helper/(a['name']+'.dll')and a['sha256']==pub['helperRuntimeFiles'][a['name']+'.dll']and a['mvid']
 proof.update(status='PASS_CURRENT_F248_INDEPENDENT_FOUR_ORIGINALS_READONLY29_PREFIXES62_EVENTS54_PRIVATE16_NATIVE1_CI8_COLD',resultPath=str(output),resultSha256=sha(output),totals=result['totals'])
except BaseException as error:proof.update(status='FAILED_CURRENT_F248_INDEPENDENT_ORIGINALS_OR_READER_ORIGINAL_OUTPUT_RETAINED',errorType=type(error).__name__,error=str(error));raise
finally:
 if started:
  if before_audit is not None:proof.update(all422AuditSevenTablesExact=digests('riftbound_acceptance',audit)==before_audit,all115NativeSevenTablesExact=digests('riftbound_here_native',native)==before_native,actualAuditRoomsAtStop=rooms('riftbound_acceptance'),actualNativeRoomsAtStop=rooms('riftbound_here_native'))
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None and power.poll()is None:power.terminate();power.wait(timeout=10)
 proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),allOwnInputsStable=all(sha(Path(p))==h for p,h in own.items()));frozen()
 with terminal.open('x')as f:json.dump(proof,f,ensure_ascii=False,indent=2)
 fcntl.flock(guard,fcntl.LOCK_UN)
assert all(proof[k]for k in ['all422AuditSevenTablesExact','all115NativeSevenTablesExact','ownPostgresSmartStopped','allOwnInputsStable']);print(proof['status'],flush=True)
