from pathlib import Path
import datetime,hashlib,io,json,shutil,subprocess,tarfile
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;old=root/'var/qa/fixeda68bf-early-native-20261023';load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
boot=load(w/'current-native-headless-boot-and-sigterm-verification-v1.json');assert boot['fixedCommit']=='f248d7774aca8776d288bb5d702e0b545b116a7e'and len(boot['records'])==2 and all(r['naturalExitCode']==0 and r['sigtermGuardPassed']for r in boot['records'])
new=load(w/'native-app-inputs.json');prior=load(old/'native-app-inputs.json');api=load(old/'fixeda68bf-api-gameplay-closure-frozen-inputs-v1.json');full=load(old/'cia68bf-entire-full-independent-verification-v1.json');assert len(full['jobs'])==11 and set(full['jobs'].values())=={'success'}
for a in new['apps']:
 app=Path(a['app']);assert all(sha(app/p)==h for p,h in new['ciManagedAndPckPayloads'].items());subprocess.run(['codesign','--verify','--deep','--strict',str(app)],check=True,capture_output=True)
old_apps=[Path(a['app'])for a in prior['apps']];lines=subprocess.check_output(['ps','-axo','pid=,command='],text=True).splitlines()
assert not any(any(line.strip().split(None,1)[1].startswith(str(app)+'/')for app in old_apps)for line in lines if len(line.strip().split(None,1))==2),'An old exact app still has a live process; preserve it.'
# Preserve the small original failing owned modules/PCK, without retaining old SDK/framework/app copies.
selected=[]
for name in ['Riftbound.Engine','Riftbound.Contracts','Riftbound.CardCatalog','Riftbound.Persistence']:
 for ext in ['.dll','.pdb']:
  p=Path(api['runtimeRoot'])/(name+ext)
  if p.exists():assert sha(p)==api['runtimeFiles'][p.name];selected.append(p)
for p,h in prior['ciManagedAndPckPayloads'].items():
 if Path(p).name in {'Riftbound.GodotClient.dll','Riftbound.GodotClient.pdb','Riftbound.Contracts.dll','Riftbound.Contracts.pdb','符文战场.pck'}:
  path=old_apps[0]/p;assert sha(path)==h;selected.append(path)
assert any(p.name=='Riftbound.Engine.dll'for p in selected)and any(p.suffix=='.pck'for p in selected)
archive=w/'preceding-a68bf-original-failure-owned-modules-and-pck-v1.tar.gz';assert archive.exists();rows=[]
with tarfile.open(archive,'r:gz')as t:
 canonical={}
 for member in t.getmembers():
  raw=t.extractfile(member).read();canonical[hashlib.sha256(raw).hexdigest()]=member.name
 for p in selected:
  h=sha(p);assert h in canonical;raw=t.extractfile(canonical[h]).read();assert raw==p.read_bytes();rows.append(dict(originalPath=str(p.relative_to(root)),bytes=len(raw),sha256=h,archiveMember=canonical[h]))
 assert set(canonical.values())=={r['archiveMember']for r in rows}
assert archive.stat().st_size==17480864 and archive.stat().st_size<20_000_000
retired=[]
for app in old_apps:
 assert app.parent==old and app.is_dir()and not app.is_symlink();assert all(sha(app/p)==h for p,h in prior['ciManagedAndPckPayloads'].items());files=[dict(path=str(p.relative_to(app)),bytes=p.stat().st_size,sha256=sha(p))for p in app.rglob('*')if p.is_file()];retired.append(dict(path=str(app),kind='PRECEDING_COMPLETED_QA_APP',logicalBytes=sum(f['bytes']for f in files),allOriginalFiles=files));subprocess.run(['/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister','-u',str(app)],capture_output=True,check=True);shutil.rmtree(app);assert not app.exists()
previous_download=load(old/'current-fixed-native-download-original-result-v1.json')
for a in previous_download['artifacts']:
 p=old/'native-current'/a['filename'];assert p.is_file()and sha(p)==a['actualSha256']and p.stat().st_size==a['actualBytes'];retired.append(dict(path=str(p),kind='PRECEDING_NATIVE_INSTALLER_OUTER_ZIP',logicalBytes=p.stat().st_size,sha256=sha(p)));p.unlink();assert not p.exists()
for a in new['apps']:subprocess.run(['/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister','-f',a['app']],capture_output=True,check=True)
proof=dict(atUtc=now(),status='RETIRED_ONLY_PRECEDING_A68BF_TWO_COMPLETED_APPS_AND_TWO_NATIVE_INSTALLERS_AFTER_CURRENT_F248_USABLE',fixedCommit=new['fixedCommit'],precedingCommit=prior['fixedCommit'],retired=retired,retiredLogicalBytes=sum(r['logicalBytes']for r in retired),physicalApfsFreedBytesNotInferred=True,smallOriginalFailedOwnedModulesAndPckArchive=dict(path=str(archive),sha256=sha(archive),bytes=archive.stat().st_size,originalRows=rows),notClaimingOldCompleteNativeRuntimeOrInstallersStillRetained=True,oldApiAndHelpersAndAllSourceTestsOriginalLogsCiVerificationZipsAndDatabasesUntouched=True,onlyLatestUsableNativePairAndOneInstallerPerOsRemain=True,singleSdkAndTemplateUnchanged=True,wholePrintingOrGoalCertified=False)
p=w/'retire-only-preceding-a68bf-pair-and-two-installers-v1.json';assert not p.exists();p.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');print('RETIRED_ONLY_OLD_PAIR_AND_TWO_INSTALLERS_LOGICAL_BYTES',proof['retiredLogicalBytes'],'SMALL_FAILED_OWN_MODULES_ARCHIVE',archive.stat().st_size,flush=True)
