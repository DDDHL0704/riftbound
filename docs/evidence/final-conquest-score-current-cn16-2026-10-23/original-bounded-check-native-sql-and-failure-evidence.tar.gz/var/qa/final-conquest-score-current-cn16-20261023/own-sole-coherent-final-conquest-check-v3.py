from pathlib import Path
import collections,datetime,gzip,hashlib,json,os,resource,subprocess,xml.etree.ElementTree as E
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();base='f248d7774aca8776d288bb5d702e0b545b116a7e'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==base
positive=load(w/'final-source-boundaries-and-six-original-full-games-focus-v6/summary.json');assert positive['status']=='PASSED'and positive['total']==102
# A later independent reader receipt is selected explicitly at execution time.
accepted_reader=os.environ.get('RIFTBOUND_ACCEPTED_INDEPENDENT_SQL_RECEIPT');assert accepted_reader
independent=load(Path(accepted_reader));assert independent['status'].startswith('PASS_INDEPENDENT_SEVEN_ORIGINAL_SQL_ROOMS49_PREFIXES91_EACH_PRIVATE_ONE_COORDINATED_REFUSAL')and independent['all436AuditSevenTablesExact']and independent['all118NativeSevenTablesExact']and independent['ownPostgresSmartStopped']
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def rows(path):
 doc=E.parse(path);defs={d.get('id'):d.find('t:TestMethod',ns).attrib for d in doc.findall('.//t:UnitTest',ns)}
 return [dict(name=r.get('testName'),method=defs[r.get('testId')]['className']+'.'+defs[r.get('testId')]['name'],outcome=r.get('outcome'))for r in doc.findall('.//t:UnitTestResult',ns)]
baseline=rows(root/'var/qa/zero-printed-power-prompt-current-cn16-20261023/sole-check-v1/check/results.trx');assert len(baseline)==13638 and len({r['method']for r in baseline})==7602 and all(r['outcome']=='Passed'for r in baseline)
focus=rows(w/'final-source-boundaries-and-six-original-full-games-focus-v6/focus/results.trx');assert len(focus)==102 and len({r['method']for r in focus})==81 and all(r['outcome']=='Passed'for r in focus)
new=[r for r in focus if '.FinalConquestPointTests.'in r['method']or '.FinalConquestScoreLifecycleTests.'in r['method']];assert len(new)==20 and len({r['method']for r in new})==13
full=[r for r in focus if '.FullGameEndToEndTests.'in r['method']];assert len(full)==6
native=load(root/'var/qa/fixedf248d777-early-native-20261023/current-fixed-production-native-source3374-payload23-v1.json');pins={p:dict(sha256=sha(root/p),mode=oct((root/p).stat().st_mode&0o777))for p in native['sourceHashes']};changed=[p for p,h in native['sourceHashes'].items()if pins[p]['sha256']!=h]
expected={'scripts/tests/test_sql_ci_gate.py','src/Riftbound.Engine/CoreRuleEngine.BattlefieldReplacement.cs','src/Riftbound.Engine/CoreRuleEngine.cs','src/Riftbound.Engine/MatchSession.cs','tests/Riftbound.PostgresAcceptance/Program.cs','tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'};assert set(changed)==expected
added=['src/Riftbound.Engine/MatchSession.FinalConquestScenario.cs','tests/Riftbound.ConformanceTests/FinalConquestPointTests.cs','tests/Riftbound.ConformanceTests/FinalConquestScoreLifecycleTests.cs','tests/Riftbound.PostgresAcceptance/FinalConquestScoreSqlAcceptance.cs']
for p in added:assert p not in pins;pins[p]=dict(sha256=sha(root/p),mode=oct((root/p).stat().st_mode&0o777))
assert len(pins)==3378
original={p:h for p,h in native['sourceHashes'].items()if p.startswith('tests/Riftbound.ConformanceTests/')};assert len(original)==1820 and all(sha(root/p)==h for p,h in original.items())
old_start=json.loads(gzip.decompress((root/'var/qa/zero-printed-power-prompt-current-cn16-20261023/sole-check-start-inputs-v1.json.gz').read_bytes()));full_sources=old_start['allNineFullGameSourceHashes'];assert len(full_sources)==9 and all(sha(root/p)==h for p,h in full_sources.items())
prior_sql=json.loads(subprocess.check_output(['git','show',base+':tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'],cwd=root));sql=load(root/'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json');assert len(prior_sql['cases'])==62 and sql['cases'][:62]==prior_sql['cases']and sql['cases'][62:]==[{'id':'final-conquest-score','sourceType':'FinalConquestScoreSqlAcceptance'}]
runtime={}
for label,folder in [('Conformance',root/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0'),('Native',root/'clients/godot/.godot/mono/temp/bin/Debug')]:runtime[label]={str(p.relative_to(root)):sha(p)for p in folder.rglob('*')if p.is_file()and '/net10.0/var/qa/'not in str(p)}
folder=root/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0';command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(folder/'Riftbound.ConformanceTests.deps.json'),'--runtimeconfig',str(folder/'Riftbound.ConformanceTests.runtimeconfig.json'),str(root/'var/qa/fixed267ab-early-native-20261022/executed-own-native-readers-and-drivers-v1/IndependentFixed267abControlledLabV1.dll'),'--loaded-inputs'];measurement=json.loads(subprocess.check_output(command,cwd=folder,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0')));assert Path(measurement['baseDirectory'])==folder and len(measurement['assemblies'])==4
for a in measurement['assemblies']:assert sha(Path(a['path']))==a['sha256']and a['mvid']
assert measurement['actualRuleInputs']==independent['actualRuleInputs']
start=dict(atUtc=now(),baseCommit=base,all3378SourceHashesAndModes=pins,all1820OriginalConformanceFiles=original,changedOriginalSourceInputs=changed,allOriginalConformanceFilesByteExact=True,allNineFullGameSourceHashes=full_sources,all143OriginalCompleteMethods151Cases110Pairs11DecksSeed424242AndVictoryReplayAssertionsRetained=True,actualFourLoadedAssemblies=measurement,actualRuntimeInputs=runtime,baselineCaseNames=sorted(r['name']for r in baseline),newCaseNames=sorted(r['name']for r in new),exactSixEarlyFullMethods=sorted(r['method']for r in full),acceptedIndependentSqlReceipt=dict(path=accepted_reader,sha256=sha(Path(accepted_reader))),allOriginal62SqlObjectsAndOrderRetained=True,expectedCheckCases=13658,expectedCheckMethods=7615,expectedDiscoveryMethods=7756,expectedNextFixedFullCases=13807,newCases=20,newMethods=13,noDatabaseConnectionForThisCheck=True,wholeCardOrGoalCertified=False)
manifest=w/'sole-check-start-inputs-v1.json.gz';assert not manifest.exists();manifest.write_bytes(gzip.compress(json.dumps(start,indent=2).encode(),mtime=0));out=w/'sole-check-v1';assert not out.exists();args=['python3','scripts/test-rules.py','check','--output',str(out)];env=dict(os.environ);env.pop('ConnectionStrings__Riftbound',None)
proof=dict(status='RUNNING_SOLE_COHERENT_FINAL_CONQUEST_SCORE_CHECK',startedAtUtc=now(),baseCommit=base,actualCommand=args,sourceInputs=len(pins),runtimeInputCounts={k:len(v)for k,v in runtime.items()},startManifestSha256=sha(manifest));print('SOLE_CHECK_STARTED_EXPECT13658_CASES7615_METHODS_3378_SOURCES',flush=True)
try:
 with(w/'sole-check-original-console-v1.log').open('xb')as log:
  process=subprocess.Popen(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  with(w/'sole-check-running-owner-v1.json').open('x')as output:json.dump(dict(proof,ownerPid=os.getpid(),runnerPid=process.pid),output,indent=2)
  power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(process.pid)]);proof['exitCode']=process.wait();power.wait(timeout=10)
 if proof['exitCode']==0:
  summary=load(out/'summary.json');plan=load(out/'plan.json');actual=rows(out/'check/results.trx');assert summary['status']=='PASSED'and summary['total']==13658 and len(actual)==13658
  assert collections.Counter(r['name']for r in actual)==collections.Counter(r['name']for r in baseline)+collections.Counter(r['name']for r in new)
  assert all(r['outcome']=='Passed'for r in actual)and plan['discoveredMethods']==7756 and len(plan['shards'][0]['methods'])==7615
  proof.update(status='PASS_SOLE_COHERENT_FINAL_CONQUEST_SCORE_CHECK13658_CASES7615_METHODS',summary=summary,allOriginal13638CheckCases7602MethodsRetainedPlus20Cases13MethodsOnly=True,trxSha256=sha(out/'check/results.trx'))
 else:proof['status']='FAILED_SOLE_COHERENT_FINAL_CONQUEST_SCORE_CHECK_ORIGINALS_RETAINED'
finally:
 proof.update(finishedAtUtc=now(),all3378SourceHashesAndModesStable=all(sha(root/p)==v['sha256']and oct((root/p).stat().st_mode&0o777)==v['mode']for p,v in pins.items()),allCapturedConformanceAndNativeRuntimeInputsStable=all(sha(root/p)==h for group in runtime.values()for p,h in group.items()))
 with(w/'sole-check-owner-terminal-v1.json').open('x')as output:json.dump(proof,output,indent=2)
print(proof['status'],flush=True);assert proof['exitCode']==0 and proof['all3378SourceHashesAndModesStable']and proof['allCapturedConformanceAndNativeRuntimeInputsStable']
