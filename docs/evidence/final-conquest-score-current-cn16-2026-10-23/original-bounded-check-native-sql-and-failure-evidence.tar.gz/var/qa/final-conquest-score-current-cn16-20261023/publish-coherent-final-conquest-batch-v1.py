from pathlib import Path
import collections, copy, datetime, gzip, hashlib, io, json, subprocess, tarfile
import xml.etree.ElementTree as E

root = Path('/Users/dinghaolin/MyProjects/riftbound')
w = Path(__file__).resolve().parent
n = root / 'var/qa/fixedf248d777-early-native-20261023'
base = 'f248d7774aca8776d288bb5d702e0b545b116a7e'
identity = 'final-conquest-score-current-cn16-2026-10-23'
ev = root / 'docs/evidence' / identity
stage = w / 'publication-evidence-staged-v1'
document = 'docs/FINAL_CONQUEST_SCORE_CURRENT_CN16_AUDIT_2026-10-23.md'
mp = root / 'docs/audit/current-manifest.json'
load = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()

def pin(p, role=None):
    target = ev / p.relative_to(stage) if stage in p.parents else p
    result = dict(path=target.relative_to(root).as_posix(), sha256=sha(p))
    if role:
        result['role'] = role
    return result

def write(p, value):
    with p.open('x') as output:
        json.dump(value, output, ensure_ascii=False, indent=2)
        output.write('\n')

def test_rows(p):
    ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
    doc = E.parse(p)
    methods = {r.get('id'): r.find('t:TestMethod', ns).attrib for r in doc.findall('.//t:UnitTest', ns)}
    return [dict(name=r.get('testName'), method=methods[r.get('testId')]['className'] + '.' + methods[r.get('testId')]['name'], outcome=r.get('outcome')) for r in doc.findall('.//t:UnitTestResult', ns)]

assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == base
check = load(w / 'sole-check-owner-terminal-v1.json')
assert check['status'] == 'PASS_SOLE_COHERENT_FINAL_CONQUEST_SCORE_CHECK13658_CASES7615_METHODS'
assert check['exitCode'] == 0 and check['all3378SourceHashesAndModesStable'] and check['allCapturedConformanceAndNativeRuntimeInputsStable']
start = json.loads(gzip.decompress((w / 'sole-check-start-inputs-v1.json.gz').read_bytes()))
assert len(start['all3378SourceHashesAndModes']) == 3378
assert all(sha(root / p) == v['sha256'] and oct((root / p).stat().st_mode & 0o777) == v['mode'] for p, v in start['all3378SourceHashesAndModes'].items())
assert all(sha(root / p) == digest for group in start['actualRuntimeInputs'].values() for p, digest in group.items())
assert len(start['all1820OriginalConformanceFiles']) == 1820 and start['allOriginalConformanceFilesByteExact']
assert len(start['allNineFullGameSourceHashes']) == 9 and start['all143OriginalCompleteMethods151Cases110Pairs11DecksSeed424242AndVictoryReplayAssertionsRetained']
prep = load(w / 'twenty-exact-executed-branches-and-existing-source-identities-v1.json')
support = load(w / 'nineteen-current-score-source-records-and-twelve-existing-printing-identities-v1.json')
assert len(prep['cases']) == 20 and len(prep['newMethods']) == 13 and len(prep['sourceRuleRecords']) == 23
assert len(support['exactSupportingPrintingSubjects']) == 12
focus = load(w / 'final-source-boundaries-and-six-original-full-games-focus-v6/summary.json')
actual_focus = test_rows(w / 'final-source-boundaries-and-six-original-full-games-focus-v6/focus/results.trx')
assert focus['status'] == 'PASSED' and focus['total'] == len(actual_focus) == 102
assert all(r['outcome'] == 'Passed' for r in actual_focus) and len({r['method'] for r in actual_focus}) == 81
assert collections.Counter(c['actualExecutedCase'] for c in prep['cases']) == collections.Counter(start['newCaseNames'])
original_games = sorted(r['method'] for r in actual_focus if '.FullGameEndToEndTests.' in r['method'])
assert len(original_games) == 6 and original_games == start['exactSixEarlyFullMethods']
reader = load(w / 'current-stable-order-source-v2/independent-seven-sql-originals-readonly-owner-terminal-v3.json')
sql = load(w / 'current-stable-order-source-v2/real-sql-seven-original-rooms-owner-terminal-v1.json')
expected_sql = dict(commands=49, events=129, authority=49, snapshots=91, prompts=91, prefixReplays=49, actualForgeryRefusals=1)
assert reader['status'].startswith('PASS_INDEPENDENT_SEVEN_ORIGINAL_SQL_ROOMS49_PREFIXES91_EACH_PRIVATE_ONE_COORDINATED_REFUSAL')
assert reader['totals'] == expected_sql and reader['all436AuditSevenTablesExact'] and reader['all118NativeSevenTablesExact'] and reader['ownPostgresSmartStopped']
assert reader['actualRuleInputs'] == start['actualFourLoadedAssemblies']['actualRuleInputs']
assert reader['actualRuleInputs']['identitySha256'] == '2ba9066ff521e4814999b08f3ed9a994c17ba07a5a70a0d406a04675d6290f5f'
assert sql['exitCode'] == reader['exitCode'] == 0 and sql['acceptedOriginalInputs'] == sql['coldRecoveries'] == 49
prior_native = load(n / 'fixedf248d777-seven-original-rooms-early-native-bounded-closure-v1.json')
assert prior_native['fixedCommit'] == base and prior_native['newRealRooms'] == 7
assert prior_native['originalCommands'] == prior_native['originalAcceptedCommands'] == prior_native['originalAuthorityHistories'] == prior_native['originalPrefixesActuallyReplayed'] == 112
assert prior_native['originalEvents'] == 596 and prior_native['originalPrivateSnapshots'] == prior_native['originalPrivatePrompts'] == 213
assert prior_native['productionSdkMainButtonCommandSubmissions'] == 19 and prior_native['ciDefaultMainPairedGpuSameProcessColdStages'] == 11
assert prior_native['actualRuleInputs']['identitySha256'] == '18b1e240a29f0eab44071cd4ee2de16a428db660f1a1a632ecf18c875e4c9d74'
m = load(mp)
old = copy.deepcopy(m)
rp = root / m['inputs']['reviews']['path']
reviews = load(rp)
old_reviews = copy.deepcopy(reviews)
binding = load(w / 'current84-context-input-change-plan-before-publication-v1.json')
assert sha(mp) == binding['manifestSha256'] and sha(rp) == binding['reviewsSha256'] and len(binding['changes']) == 55
assert (len(reviews['reviews']), len(m['reviewContexts']), len(m['acceptanceGates']), len(m['laterSourceDeltas'])) == (169, 84, 270, 7)
archived = json.loads(gzip.decompress((w / 'all-original84-complete-contexts-before-final-conquest-input-refresh-v1.json.gz').read_bytes()))
assert archived == old['reviewContexts'] and not m['semanticCoverageCertified']
old_status = subprocess.check_output(['git', 'show', base + ':docs/PROJECT_STATUS.md'], cwd=root).decode()
assert (root / 'docs/PROJECT_STATUS.md').read_text() == old_status
assert not ev.exists() and not stage.exists() and not (root / document).exists()

ci = n / 'cif248d777-entire-full-independent-verification-v1.json'
prior_ci_text = '前固定f248完整CI39866108629仍按发布时实际状态单列；子任务成功不代替整次通过。'
copies = {
    'sole-check-owner-terminal.json': w / 'sole-check-owner-terminal-v1.json',
    'sole-check-start-inputs.json.gz': w / 'sole-check-start-inputs-v1.json.gz',
    'twenty-exact-branches-and-existing-rule-identities.json': w / 'twenty-exact-executed-branches-and-existing-source-identities-v1.json',
    'current-core-and-directory-readback.json': w / 'current-official-rule-refresh-before-conquest-change-v1.json',
    'current-original-rule-directory.json.gz': w / 'current-rule-directory-original-v1.json.gz',
    'current-twelve-exact-printing-full-rows-and-qa.json': w / 'current-twelve-exact-printing-source-readback-v1.json',
    'current-twelve-original-printing-queries.json.gz': w / 'current-twelve-exact-card-source-original-queries-v1.json.gz',
    'all-original84-complete-contexts.json.gz': w / 'all-original84-complete-contexts-before-final-conquest-input-refresh-v1.json.gz',
    'original-score-red-execution-and-runtime-v1.json': w / 'original-red-confirmed-and-executed-inputs-v1.json',
    'original-score-red-execution-and-runtime-corrected-trx-reference-v2.json': w / 'original-red-confirmed-and-executed-inputs-v2.json',
    'original-jsonb-prompt-order-red-confirmation.json': w / 'original-jsonb-prompt-order-red-confirmation-v1.json',
    'current-sql-seven-original-rooms-owner-terminal.json': w / 'current-stable-order-source-v2/real-sql-seven-original-rooms-owner-terminal-v1.json',
    'independent-current-seven-sql-originals-readonly-owner-terminal.json': w / 'current-stable-order-source-v2/independent-seven-sql-originals-readonly-owner-terminal-v3.json',
    'independent-current-seven-sql-originals-readonly-result.json': w / 'current-stable-order-source-v2/independent-seven-sql-originals-readonly-result-v3.json',
    'first-versus-subsequent-burnout-source-boundary.json': w / 'first-vs-subsequent-burnout-source-boundary-disposition-v1.json',
    'eleven-existing-consumer-static-test-scope-not-certification.json': w / 'eleven-existing-consumer-static-scope-before-next-family-v1.json',
    'separate-first-burnout-next-family-counterexample.json': w / 'first-burnout-cleanup-next-family-preparation/original-counterexample-v1/source-directed-first-burnout-cleanup-counterexample-v1.json',
    'preceding-fixed-f248-seven-original-rooms-bounded-locked-native.json': n / 'fixedf248d777-seven-original-rooms-early-native-bounded-closure-v1.json',
    'preceding-fixed-f248-current-native-composition.json': n / 'frozen-fixedf248d777-native-composition-v1.json',
    'preceding-fixed-f248-retired-only-old-pair-and-installers.json': n / 'retire-only-preceding-a68bf-pair-and-two-installers-v1.json',
}
if ci.exists():
    completed = load(ci)
    assert completed['fixedCommit'] == base and completed['runId'] == 39866108629 and completed['actualCases'] == 13787 and completed['actualMethods'] == 7743
    assert completed['sql']['caseCount'] == 62 and len(completed['jobs']) == 11 and set(completed['jobs'].values()) == {'success'}
    copies['preceding-fixed-f248-entire-full-independent.json'] = ci
    prior_ci_text = '前固定f248完整CI39866108629实际11项成功，九原ZIP独立13787例/7743方法/62SQL，原143完整方法151例/110配对11牌组424242全部保留。'
else:
    observed = json.loads(subprocess.check_output(['gh', 'run', 'view', '39866108629', '--json', 'status,conclusion,headSha,jobs,url'], cwd=root))
    assert observed['headSha'] == base and not any(j['conclusion'] in {'failure', 'cancelled', 'timed_out', 'action_required'} for j in observed['jobs'])
    write(w / 'preceding-fixed-f248-ci-observation-at-publication-v1.json', dict(atUtc=now(), status='ACTUAL_OBSERVATION_NOT_INDEPENDENT_COMPLETE_FULL_CERTIFICATION', fixedCommit=base, runId=39866108629, actualRunStatus=observed['status'], actualRunConclusion=observed['conclusion'], jobs={j['name']: dict(status=j['status'], conclusion=j['conclusion']) for j in observed['jobs']}, url=observed['url'], doesNotCertifyFull=True))
    copies['preceding-fixed-f248-ci-observation.json'] = w / 'preceding-fixed-f248-ci-observation-at-publication-v1.json'
prior_text = prior_ci_text + '\n\n前固定f248锁屏自身GPU双端11阶段、22原画面中7张选定实际阅读、19条SDK生产Main提交及1条CI通用冒烟分别归因；7新原局112接受/596事件/112权威/213双私有记录和全部112原前缀独立回放通过。普通原局80输入531事件、48回合正常8:0；15网络拒绝零泄露与对端入座1→2更新通过。实际Release RIF18b与本批Debug2ba分开，桌面硬件键鼠和Windows实机仍OPEN，原失败不回填。'
retention = dict(atUtc=now(), status='PASS_BOUNDED_FINAL_CONQUEST_AND_EXACT_PRIVATE_PROMPT_ORDER_ALL_ORIGINAL_RETENTION', baseCommit=base, newCases=20, newMethods=13, focusedCases=102, focusedMethods=81, exactSixOriginalCompleteMethods=original_games, soleCheckCases=13658, soleCheckMethods=7615, allPrior13638CheckCases7602MethodsRetainedPlus20Cases13MethodsOnly=True, all3378SourcesModesAndCapturedRuntimeInputsStable=True, all1820OriginalConformanceFilesByteExact=True, allNineFullGameSourceHashes=start['allNineFullGameSourceHashes'], all143OriginalMethods151Cases110Pairs11DecksSeed424242VictoryReplayAssertionsRetained=True, originalScoreAndJsonbRedFailuresAndTestSetupFailuresRetained=True, actualDebugRuleInputs=reader['actualRuleInputs'], originalE81SevenRoomsRemainFailedProjectionNotRewritten=True, current2baSevenRoomsIndependentOriginalSql=expected_sql, allOriginal62SqlCaseObjectsAndOrderRetainedPlusOne=True, expectedNextFixedFullCases=13807, expectedNextFixedFullMethods=7756, expectedSqlCases=63, firstBurnoutCleanupIssue98StillOpen=True, currentFixedFullAndProducts='OPEN', wholePrintingOrGoalCertified=False)
write(w / 'final-original-retention-v1.json', retention)
copies['original-test-source-and-execution-retention.json'] = w / 'final-original-retention-v1.json'

# Build and verify one bounded payload outside tracked sources before publication.
stage.mkdir()
for name, p in copies.items():
    (stage / name).write_bytes(p.read_bytes())
paths = {p for folder in (w, n) for p in folder.rglob('*') if p.is_file() and stage not in p.parents}
def generated(p):
    return any(part in {'obj', '__pycache__', '.godot', 'native-current', 'publication-evidence-staged-v1'} or part.endswith('.app') or 'complete-originals-v1' in part for part in p.parts)
def private_name(p):
    return p.suffix == '.env' or p.name.startswith('session-') or any('profile' in part.lower() for part in p.parts)
def own_module(p):
    return p.suffix in {'.dll', '.pdb'} and (p.name.startswith(('Riftbound.', 'Independent', 'FirstBurnout')) or 'Native' in p.name)
def framework_or_generated_runtime(p):
    return ('bin' in p.parts or any('runtime-v1' in part or 'sql-runtime-before-prompt-order-fix-v1' in part for part in p.parts)) and not own_module(p)
secrets = set()
def collect(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if key.lower().replace('_', '') in {'playerkey', 'reconnecttoken', 'accesstoken', 'authorization', 'sessiontoken', 'connectiontoken'} and isinstance(item, str) and len(item) >= 16:
                secrets.add(item.encode())
            else:
                collect(item)
    elif isinstance(value, list):
        for item in value:
            collect(item)
    elif isinstance(value, str) and value.lstrip().startswith(('{', '[')):
        try:
            collect(json.loads(value))
        except (ValueError, RecursionError):
            pass
for p in paths:
    if generated(p) or framework_or_generated_runtime(p):
        continue
    if p.name.endswith(('.json', '.json.gz', '.ndjson', '.ndjson.gz', '.jsonl.gz')):
        try:
            raw = gzip.decompress(p.read_bytes()) if p.suffix == '.gz' else p.read_bytes()
            if '.ndjson' in p.name or '.jsonl' in p.name:
                for line in raw.decode().splitlines():
                    if line.strip():
                        collect(json.loads(line))
            else:
                collect(json.loads(raw))
        except (OSError, ValueError, UnicodeDecodeError):
            pass
for name in copies:
    raw = (stage / name).read_bytes()
    inspect = gzip.decompress(raw) if name.endswith('.gz') else raw
    assert not any(secret in inspect for secret in secrets), ('Readable evidence contains authentication values', name)
canonical = {sha(stage / name): dict(externalEvidencePath=pin(stage / name)['path']) for name in copies}
mapping, members, excluded = [], {}, []
for p in sorted(paths):
    name = p.relative_to(root).as_posix()
    reason = 'GENERATED_APP_INSTALLER_SDK_OR_FRAMEWORK_NOT_DUPLICATED' if generated(p) or framework_or_generated_runtime(p) else None
    if private_name(p):
        reason = 'PRIVATE_QA_SESSION_LOCAL_ONLY'
    if p.suffix in {'.zip', '.pdf'}:
        reason = 'EXISTING_INSTALLER_OR_OFFICIAL_SOURCE_NOT_DUPLICATED'
    if reason:
        excluded.append(dict(path=name, bytes=p.stat().st_size, reason=reason))
        continue
    raw = p.read_bytes()
    try:
        inspect = gzip.decompress(raw) if p.suffix == '.gz' else raw
    except (OSError, EOFError):
        inspect = raw
    digest = hashlib.sha256(raw).hexdigest()
    if any(secret in inspect for secret in secrets):
        excluded.append(dict(path=name, bytes=len(raw), sha256=digest, reason='PRIVATE_AUTH_VALUES_LOCAL_ONLY'))
        continue
    target = canonical.get(digest)
    if target is None:
        target = dict(archiveMember=name)
        canonical[digest] = target
        members[name] = p
    mapping.append(dict(path=name, bytes=len(raw), sha256=digest, **target))
archive = stage / 'original-bounded-check-native-sql-and-failure-evidence.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=9) as bundle:
    for name, p in sorted(members.items()):
        raw = p.read_bytes()
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(raw), p.stat().st_mode & 0o777, 0
        bundle.addfile(info, io.BytesIO(raw))
assert archive.stat().st_size < 80_000_000
with tarfile.open(archive, 'r:gz') as bundle:
    assert set(bundle.getnames()) == set(members)
    for item in mapping:
        target = stage / Path(item['externalEvidencePath']).relative_to(ev.relative_to(root)) if 'externalEvidencePath' in item else None
        raw = target.read_bytes() if target else bundle.extractfile(item['archiveMember']).read()
        assert len(raw) == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256']
write(stage / 'archive-map.json', dict(atUtc=now(), archive=pin(archive), originalPathsWithExactCanonicalPayload=mapping, localOnlyExclusions=excluded, allMemberBytesHashesClosedSetVerified=True, equalPayloadStoredOnceIncludingReadableCopies=True, originalAuthValuesStayLocal=True, noAdditionalAppInstallerSdkDatabaseOrWorktree=True))

implementation = [pin(root / p, 'implementation') for p in ['src/Riftbound.Engine/CoreRuleEngine.cs', 'src/Riftbound.Engine/CoreRuleEngine.BattlefieldReplacement.cs', 'src/Riftbound.Engine/MatchSession.cs', 'src/Riftbound.Engine/MatchSession.FinalConquestScenario.cs']]
verification = [pin(root / p, 'verification-source') for p in ['tests/Riftbound.ConformanceTests/FinalConquestPointTests.cs', 'tests/Riftbound.ConformanceTests/FinalConquestScoreLifecycleTests.cs', 'tests/Riftbound.PostgresAcceptance/FinalConquestScoreSqlAcceptance.cs', 'tests/Riftbound.PostgresAcceptance/Program.cs', 'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json', 'scripts/tests/test_sql_ci_gate.py']]
subjects = [row['existingPrintingId'] for row in support['exactSupportingPrintingSubjects']]
source = load(w / 'current-official-rule-refresh-before-conquest-change-v1.json')
scope = 'Current CN16 final conquest point action and draw replacement, actual score threshold, first/subsequent scoring markers, combat/noncombat callers, hold/direct-point exemptions and Brush return; exact private DECLARE_BATTLE candidate order survives JSONB player dictionary reordering. First-burnout cleanup issue98 and whole draw/cleanup/card families remain open.'
sm = dict(schemaVersion=1, id=identity, atUtc=now(), region='CN', language='zh-CN', applicableAsOf='2026-10-23', adoptedCoreEffectiveDate='2026-10-16', baseCommit=base, issues=prep['issues'], scope=scope, exactPrintings=subjects, individualPrintingDatesRemainNull=support['exactSupportingPrintingSubjects'], currentCore=source['core'], currentKnownDirectory=source['directory'], sourceRuleRecords=prep['sourceRuleRecords'], implementation=implementation, verificationSources=verification, actualDebugRuleInputs=reader['actualRuleInputs'], currentSql=expected_sql, sourceUniverse1740And14293AndRuntime1037Unchanged=True, sourceVersionDeltasUnchanged=7, soleCheckCases=13658, soleCheckMethods=7615, focusCases=102, focusMethods=81, sixOriginalFullGameMethods=original_games, newCases=20, newMethods=13, expectedNextFixedFullCases=13807, expectedNextFixedFullMethods=7756, expectedSqlCases=63, expectedRemainingObligations=17411, priorFixedNativeRuleInputs=prior_native['actualRuleInputs'], priorFixedNativeDoesNotCertifyChangedInputs=True, nextFirstBurnoutCleanupIssue='https://github.com/DDDHL0704/riftbound/issues/98', firstBurnoutOriginalCounterexampleRetained=True, newFixedFullAndNativeProducts='OPEN', wholePrintingCertified=False, semanticCoverageCertified=False, archive=pin(archive), archiveMap=pin(stage / 'archive-map.json'))
sm['separateElevenExistingConsumerTestScopePreparationNotCertification'] = pin(stage / 'eleven-existing-consumer-static-test-scope-not-certification.json')
write(stage / 'source-manifest.json', sm)
sp = pin(stage / 'source-manifest.json', 'source-manifest')
branches = [dict(id=c['id'], sourceRefs=c['exactPrintingSubjects'] + c['existingCanonicalRuleIds'], sourceManifest=sp, state='RECORDED', boundedCase=dict(actualExecutedCase=c['actualExecutedCase'], method=c['method']), semanticReview=dict(state=c['semanticScope']), implementation=dict(state='SHARED_SCORE_AND_STABLE_PUBLIC_BATTLEFIELD_ENUMERATION'), testExecution=dict(state='ACTUAL_20NEW_102FOCUS_SIX_ORIGINAL_GAMES_AND_SOLE13658_CHECK_PASS'), fixedCommitCi=dict(state='PENDING_NEW_FIXED_FULL'), productAcceptance=dict(state='OPEN_NEW_FIXED_MAIN_AND_REQUIRED_PRODUCTS'), decision=dict(state='OPEN', reason='Bounded executed behavior; fixed full/current products and separate first-burnout cleanup remain open.'), wholePrintingCertified=False) for c in prep['cases']]
write(stage / 'twenty-exact-behavior-branches.json', dict(branches=branches))
refreshed = []
for name, context in m['reviewContexts'].items():
    changes = []
    for ref in context['implementation']:
        digest = sha(root / ref['path'])
        if digest != ref['sha256']:
            assert ref['path'] in {'src/Riftbound.Engine/CoreRuleEngine.cs', 'src/Riftbound.Engine/MatchSession.cs'}
            changes.append(dict(path=ref['path'], before=ref['sha256'], after=digest))
            ref['sha256'] = digest
    if changes:
        refreshed.append(dict(id=name, changes=changes, oldCompleteContext=old['reviewContexts'][name]))
        context.update(currentImplementationCommit=base, currentImplementationIncludesUncommittedChanges=True, ciState='PENDING', currentFinalConquestScoreInputRefresh=dict(sourceManifest=sp, onlyCurrentInputPinsNotWholeSemanticCertification=True, allPriorEvidenceAndOptionalVerificationReferencesRetained=True, newFixedFullAndProducts='OPEN'))
assert len(refreshed) == 55 and {item['id'] for item in refreshed} == {item['id'] for item in binding['changes']}
for name, original in old['reviewContexts'].items():
    current = m['reviewContexts'][name]
    assert current.get('verificationSources') == original.get('verificationSources') and ('verificationSources' in current) == ('verificationSources' in original)
    if name not in {item['id'] for item in refreshed}:
        assert current == original
(stage / 'fifty-five-input-refreshes-complete-old-contexts.json.gz').write_bytes(gzip.compress(json.dumps(refreshed, ensure_ascii=False, indent=2).encode(), mtime=0))
m['reviewContexts'][identity] = dict(evidenceCommit=base, currentImplementationCommit=base, currentImplementationIncludesUncommittedChanges=True, ciState='PENDING', ciReceipts=[], region='CN', language='zh-CN', applicableAsOf='2026-10-23', adoptedCoreEffectiveDate='2026-10-16', sourceManifest=sp, implementation=implementation, verificationSources=verification, branches=branches, evidence=[pin(stage / 'original-test-source-and-execution-retention.json', 'focus-check-and-retention'), pin(stage / 'independent-current-seven-sql-originals-readonly-owner-terminal.json', 'independent-real-sql'), pin(stage / 'preceding-fixed-f248-seven-original-rooms-bounded-locked-native.json', 'prior-fixed-native-only')])
reviews['reviews'].append(dict(id=identity, scope=scope, subjects=subjects, ruleRecords=[r['existingCanonicalId'] for r in prep['sourceRuleRecords']], status='BOUNDED_FINAL_CONQUEST_DRAW_AND_EXACT_PRIVATE_PROMPT_ORDER_PASS_NEW_FULL_PRODUCTS_OPEN', sourceManifest=sp, auditDocument=document, validation=dict(newCases=20, newMethods=13, soleCheckCases=13658, soleCheckMethods=7615, focusedCases=102, focusedMethods=81, originalFullGameMethods=6, wholeCardCertification=False), exclusions=['Entire draw/cleanup family and first-burnout issue98 remain open', 'Distinct GLOBAL printings and all whole printings remain uncertified', 'Prior fixed f248 Release18b native proofs do not certify new Debug2ba', 'New fixed full/current products, OS hardware input and physical Windows remain separate', 'All original failures, source dates, accepted histories and private seeds retained']))
gate = dict(id='FINAL_CONQUEST_DRAW_CURRENT_FIXED_MAIN_AND_PRODUCTS', state='OPEN', requirement='Independently verify the new fixed full original suite/63 SQL cases and actual default Main final-conquest draw/win/Brush/combat branches, paired current recovery, network reconnect, ordinary score finish and complete original replay. Keep actual SDK production submissions, CI GPU own viewports, OS hardware input and physical Windows independently attributed; first-burnout cleanup issue98 remains open.', scope=scope, sourceManifest=sp, issues=prep['issues'], semanticReview='BOUNDED', implementation='SHARED_SCORE_AND_STABLE_PRIVATE_CHOICES', testExecution='20NEW_102FOCUS_SIX_ORIGINAL_GAMES_SOLE_CHECK13658', fixedCommitCi='OPEN_NEW_FIXED_FULL', productAcceptance='OPEN_CURRENT_MAIN_PAIR_NETWORK_SCORE_REPLAY_OS_HARDWARE_AND_WINDOWS', wholePrintingCertified=False)
assert gate['id'] not in {g['id'] for g in m['acceptanceGates']}
m['acceptanceGates'].append(gate)
assert reviews['reviews'][:-1] == old_reviews['reviews'] and m['acceptanceGates'][:-1] == old['acceptanceGates'] and m['laterSourceDeltas'] == old['laterSourceDeltas'] and m['certificationScope'] == old['certificationScope']
review_bytes = (json.dumps(reviews, ensure_ascii=False, indent=2) + '\n').encode()
m['inputs']['reviews']['sha256'] = hashlib.sha256(review_bytes).hexdigest()
coverage = load(root / old['cardCoverageManifest']['path'])
old_coverage = copy.deepcopy(coverage)
coverage.update(previousCurrentScopedReviewDecisionsBeforeFinalConquestScore=old_coverage['currentScopedReviewDecisions'], currentScopedReviewDecisions=m['inputs']['reviews'], currentFinalConquestScoreScopedSourceManifest=sp)
assert all(coverage[k] == value for k, value in old_coverage.items() if k != 'currentScopedReviewDecisions')
write(stage / 'source-coverage.json', coverage)
m['cardCoverageManifest'] = pin(stage / 'source-coverage.json', 'current-card-coverage')
m['currentFinalConquestScoreAndPrivatePromptOrderInputChange'] = dict(sourceManifest=sp, auditDocument=document, issues=prep['issues'], newBoundedBehaviorBranches=20, newProductGate=1, all169OldReviews84ContextIdentities270GatesSevenDeltasRetained=True, all84CompleteOldContextsArchived55InputRefreshes29WholeObjectsExact=True, allOldOptionalVerificationSourcePresenceAndValuesExact=True, noCatalogOrSourceUniverseChange=True, allOriginal17390ObligationIdsRetained=True, expectedRemainingObligations=17411, newFixedFullAndProducts='OPEN', firstBurnoutCleanupIssue98StillOpen=True, wholePrintingOrGoalComplete=False)
m['precedingFixedF248BoundedLockedGpuPairControlsScoreNetworkOriginalReplay'] = pin(stage / 'preceding-fixed-f248-seven-original-rooms-bounded-locked-native.json')
ci_name = 'preceding-fixed-f248-entire-full-independent.json' if ci.exists() else 'preceding-fixed-f248-ci-observation.json'
m['precedingFixedF248ActualCompleteFullCiReadback' if ci.exists() else 'precedingFixedF248ObservedCiBeforeFinalConquestPublication'] = pin(stage / ci_name)
assert (len(reviews['reviews']), len(m['reviewContexts']), len(m['acceptanceGates']), len(m['laterSourceDeltas'])) == (170, 85, 271, 7)
assert all(m['inputs'][key] == old['inputs'][key] for key in old['inputs'] if key != 'reviews')
write(stage / 'publication-governance-retention.json', dict(atUtc=now(), oldReviews=169, oldContexts=84, oldGates=270, oldDeltas=7, oldRemainingIds=17390, newBehaviorBranches=20, newGate=1, currentRemainingObligations=17411, currentReviews=170, currentContexts=85, currentGates=271, completeOldContextsArchived=84, refreshedCurrentImplementationPins=55, otherWholeContextsUnchanged=29, allOldReviewsGatesDeltasScopeOptionalVerificationReferencesAndSourceDatesRetained=True, noCardLedgerIndexOrRuntimeCatalogChange=True, semanticCoverageCertified=False))
audit_text = (w / 'final-audit-prose-prepared-v1.md').read_text().replace('{{PRIOR_F248_CI_AND_NATIVE}}', prior_text)
status_text = (w / 'final-status-prose-prepared-v1.md').read_text().replace('{{PRIOR_F248_CI_AND_NATIVE}}', prior_text)
audit_text = audit_text.replace('本批唯一check的实际结果见单独收据（目标13658例/7615方法，原13638/7602加20/13）。', '本批唯一check13658例/7615方法全过，实际用例多重集严格等于原13638/7602加20/13。').replace('本批拟新增20限定行为及1产品门禁至170/85/271/17411，以实际治理检查为准。', '本批新增20限定行为及1产品门禁至170/85/271/17411；发布后再由独立治理检查复核。')
status_text = status_text.replace('唯一check实际结果另存，目标13658/7615，', '唯一check13658/7615实际全过，').replace('预计治理170审查85上下文271门禁7差异17411义务，', '治理170审查85上下文271门禁7差异17411义务，').replace('；以实际治理检查为准。', '；发布后独立治理检查复核。')
assert '{{' not in audit_text and '{{' not in status_text
heading = '# 当前项目状态\n\n'
assert old_status.startswith(heading) and sha(mp) == binding['manifestSha256'] and sha(rp) == binding['reviewsSha256']
stage.rename(ev)
rp.write_bytes(review_bytes)
mp.write_text(json.dumps(m, ensure_ascii=False, indent=2) + '\n')
(root / document).write_text(audit_text)
(root / 'docs/PROJECT_STATUS.md').write_text(heading + status_text + old_status[len(heading):])
print('PUBLISHED_N49_20NEW13METHODS102FOCUS81METHODS_SIX_ORIGINAL_GAMES_CHECK13658_7615_170REVIEWS85CONTEXTS271GATES7DELTAS17411OBLIGATIONS', flush=True)
