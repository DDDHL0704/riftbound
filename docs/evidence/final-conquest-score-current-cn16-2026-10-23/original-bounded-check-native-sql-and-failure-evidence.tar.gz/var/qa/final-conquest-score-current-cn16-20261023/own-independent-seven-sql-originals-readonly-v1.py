from pathlib import Path
import ast,datetime,fcntl,hashlib,json,os,plistlib,resource,subprocess
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486');tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
functions=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
for node in ast.parse(functions.read_text()).body:
 if isinstance(node,ast.FunctionDef)and node.name in {'query','rooms','digests','observe_lock'}:exec(compile(ast.get_source_segment(functions.read_text(),node),str(functions),'exec'),globals())
previous=load(w/'real-sql-seven-original-rooms-owner-terminal-v1.json');runtime=root/'tests/Riftbound.PostgresAcceptance/bin/Debug/net10.0';project=w/'independent-original-sql-reader-source-v1';reader=project/'bin/Release/net10.0/IndependentFinalConquestSqlOriginalsV1.dll';terminal=w/'independent-seven-sql-originals-readonly-owner-terminal-v1.json';result=w/'independent-seven-sql-originals-readonly-result-v1.json';assert not terminal.exists()and not result.exists();own={str(p):sha(p)for p in [Path(__file__),functions,project/'Program.cs',project/'probe.csproj',reader,reader.with_suffix('.pdb')]}
def stable():
 assert {str(p.relative_to(runtime)):sha(p)for p in runtime.rglob('*')if p.is_file()}==previous['runtimeInputHashes']
 assert all(sha(Path(p))==h for p,h in own.items())
proof=dict(status='RUNNING_INDEPENDENT_SEVEN_ORIGINAL_CONQUEST_SQL_ROOMS_READONLY',startedAtUtc=now(),baseCommit=previous['baseCommit'],actualRuleInputs=previous['actualLoadedFourAssemblies']['actualRuleInputs'],ownInputHashes=own,lockAtStart=observe_lock());guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a+');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB);started=False;power=None;before_audit=before_native=None
try:
 stable();assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid
 subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'independent-conquest-readonly-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 audit=rooms('riftbound_acceptance');native=rooms('riftbound_here_native');assert audit==previous['actualAuditRoomsAtStop']and native==previous['actualNativeRoomsAtStop']and len(audit)==429 and len(native)==118;before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',native)
 command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(runtime/'Riftbound.PostgresAcceptance.deps.json'),'--runtimeconfig',str(runtime/'Riftbound.PostgresAcceptance.runtimeconfig.json'),str(reader),str(w),str(result)];proof['actualCommand']=command
 env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit;Options=-c default_transaction_read_only=on',DOTNET_DbgEnableMiniDump='0');env.pop('DOTNET_STARTUP_HOOKS',None)
 with(w/'independent-seven-sql-originals-readonly-original-console-v1.log').open('xb')as log:r=subprocess.run(command,cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
 proof['exitCode']=r.returncode;assert r.returncode==0,'Original reader failure retained; no source or game oracle weakened.'
 d=load(result);actual=d['actualLoadedFourAssemblies'];assert actual['actualRuleInputs']==proof['actualRuleInputs']and Path(actual['baseDirectory'])==runtime
 for a in actual['assemblies']:assert Path(a['path'])==runtime/(a['name']+'.dll')and a['sha256']==previous['runtimeInputHashes'][a['name']+'.dll']and a['mvid']
 proof.update(status='PASS_INDEPENDENT_SEVEN_ORIGINAL_SQL_ROOMS49_PREFIXES91_EACH_PRIVATE_ONE_COORDINATED_REFUSAL_READONLY',resultPath=str(result),resultSha256=sha(result),totals=d['totals'])
except BaseException as error:proof.update(status='FAILED_INDEPENDENT_SQL_READER_ORIGINAL_OUTPUTS_AND_INPUTS_RETAINED',errorType=type(error).__name__,error=str(error));raise
finally:
 if started:
  if before_audit is not None:proof.update(all429AuditSevenTablesExact=digests('riftbound_acceptance',audit)==before_audit,all118NativeSevenTablesExact=digests('riftbound_here_native',native)==before_native,actualAuditRoomsAtStop=rooms('riftbound_acceptance'),actualNativeRoomsAtStop=rooms('riftbound_here_native'))
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None and power.poll()is None:power.terminate();power.wait(timeout=10)
 stable();proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),allExecutedSqlRuntimeAndOwnReaderInputsStable=True)
 with terminal.open('x')as f:json.dump(proof,f,ensure_ascii=False,indent=2)
 fcntl.flock(guard,fcntl.LOCK_UN)
assert all(proof[k]for k in ['all429AuditSevenTablesExact','all118NativeSevenTablesExact','ownPostgresSmartStopped','allExecutedSqlRuntimeAndOwnReaderInputsStable']);print(proof['status'],flush=True)
