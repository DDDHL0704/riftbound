from pathlib import Path
import argparse, datetime, gzip, hashlib, json, os, shutil, stat, subprocess

root = Path('/Users/dinghaolin/MyProjects/riftbound')
w = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
parser = argparse.ArgumentParser()
parser.add_argument('--phase', choices=['pilot', 'remaining'], required=True)
args = parser.parse_args()
plan = json.loads((w / 'large-official-pdf-exact-payload-cow-sharing-plan-v1.json').read_text())
captured = json.loads(gzip.decompress((w / 'sole-check-start-inputs-v1.json.gz').read_bytes()))
protected = set(captured['all3378SourceHashesAndModes'])
for group in captured['actualRuntimeInputs'].values():
    protected.update(group)
pilot = w / 'official-pdf-cow-sharing-pilot-terminal-v1.json'
completed = set()
if args.phase == 'remaining':
    previous = json.loads(pilot.read_text())
    assert previous['status'] == 'PASS_IDENTICAL_OFFICIAL_PDF_COW_SHARED_ORIGINAL_PATHS_BYTES_AND_RECORDED_DATES_RETAINED'
    assert previous['observedAvailableByteChange'] > 20_000_000
    completed = {item['path'] for item in previous['files']}
receipt = w / ('official-pdf-cow-sharing-' + args.phase + '-terminal-v1.json')
assert not receipt.exists()
entries = [(group, p) for group in plan['groups'] for p in group['destinations'] if p not in completed]
if args.phase == 'pilot':
    entries = entries[:5]
assert entries
for group, name in entries:
    assert name.startswith('var/qa/') and name not in protected and group['canonical'].startswith('var/qa/')
    assert name.endswith('.pdf') and Path(name) != Path(group['canonical'])

def metadata(p):
    item = p.stat()
    return dict(bytes=item.st_size, mode=stat.S_IMODE(item.st_mode), uid=item.st_uid, gid=item.st_gid,
                atimeNs=item.st_atime_ns, mtimeNs=item.st_mtime_ns,
                birthtimeObserved=getattr(item, 'st_birthtime', None), flags=getattr(item, 'st_flags', 0))

def xattrs(p):
    return {key: os.getxattr(p, key, follow_symlinks=False) for key in os.listxattr(p, follow_symlinks=False)}

def available():
    item = os.statvfs(root)
    return item.f_bavail * item.f_frsize

proof = dict(status='RUNNING_IDENTICAL_OFFICIAL_PDF_COW_SHARING', startedAtUtc=now(), phase=args.phase,
             planSha256=sha(w / 'large-official-pdf-exact-payload-cow-sharing-plan-v1.json'),
             originalPathsRetained=True, acquisitionDateRecordsNotModified=True,
             noCapturedSourceOrRuntimePathSelected=True, availableBytesBefore=available(), files=[])
try:
    for group, name in entries:
        source, target = root / group['canonical'], root / name
        assert source.is_file() and target.is_file() and not source.is_symlink() and not target.is_symlink()
        assert source.stat().st_dev == target.stat().st_dev
        before = metadata(target)
        old_xattrs = xattrs(target)
        assert before['uid'] == os.getuid() and before['flags'] == 0
        assert sha(source) == sha(target) == group['sha256'] and before['bytes'] == group['bytes']
        temp = target.with_name('.codex-cow-' + str(os.getpid()) + '-' + target.name)
        assert not temp.exists()
        try:
            subprocess.run(['/bin/cp', '-c', '-p', str(source), str(temp)], check=True, capture_output=True)
            shutil.copystat(target, temp, follow_symlinks=False)
            for key in os.listxattr(temp, follow_symlinks=False):
                if key not in old_xattrs:
                    os.removexattr(temp, key, follow_symlinks=False)
            for key, value in old_xattrs.items():
                os.setxattr(temp, key, value, follow_symlinks=False)
            # Reading the old source can update atime; preserve the observation taken before hashing.
            os.utime(temp, ns=(before['atimeNs'], before['mtimeNs']), follow_symlinks=False)
            prepared = metadata(temp)
            assert all(prepared[key] == before[key] for key in ['bytes', 'mode', 'uid', 'gid', 'mtimeNs', 'flags'])
            assert sha(temp) == group['sha256'] and xattrs(temp) == old_xattrs
            os.replace(temp, target)
            after = metadata(target)
            assert sha(target) == group['sha256'] and xattrs(target) == old_xattrs
            assert all(after[key] == before[key] for key in ['bytes', 'mode', 'uid', 'gid', 'mtimeNs', 'flags'])
            proof['files'].append(dict(path=name, sharedFrom=group['canonical'], sha256=group['sha256'], before=before, after=after,
                                       exactPayloadAndModeOwnerMtimeXattrsRetained=True,
                                       filesystemBirthtimeIsObservedSeparatelyFromOfficialAcquisitionReceipts=True))
        finally:
            if temp.exists():
                temp.unlink()
    proof['status'] = 'PASS_IDENTICAL_OFFICIAL_PDF_COW_SHARED_ORIGINAL_PATHS_BYTES_AND_RECORDED_DATES_RETAINED'
except BaseException as error:
    proof.update(status='FAILED_PDF_COW_SHARING_ORIGINAL_PAYLOADS_RETAINED', errorType=type(error).__name__, error=str(error))
    raise
finally:
    proof.update(finishedAtUtc=now(), availableBytesAfter=available())
    proof['observedAvailableByteChange'] = proof['availableBytesAfter'] - proof['availableBytesBefore']
    with receipt.open('x') as output:
        json.dump(proof, output, indent=2)
print(proof['status'], 'files', len(proof['files']), 'observedAvailableByteChange', proof['observedAvailableByteChange'], flush=True)
