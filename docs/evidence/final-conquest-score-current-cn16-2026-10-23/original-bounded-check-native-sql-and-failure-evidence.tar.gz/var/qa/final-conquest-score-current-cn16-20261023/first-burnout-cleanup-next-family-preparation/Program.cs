using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using Riftbound.CardCatalog;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
var output = Path.GetFullPath(args.Single());
Directory.CreateDirectory(output);
var files = new[] { typeof(CoreRuleEngine).Assembly, typeof(GameCommand).Assembly, typeof(OfficialCardCatalog).Assembly, typeof(PostgresMatchRecoveryStore).Assembly };
var loaded = new { baseDirectory = AppContext.BaseDirectory, actualRuleInputs = RuleInputIdentity.Current,
    assemblies = files.Select(a => new { name = a.GetName().Name, path = a.Location, mvid = a.ManifestModule.ModuleVersionId,
        sha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(a.Location))).ToLowerInvariant() }).ToArray() };
var cards = new[] { "H1", "H2", "H3", "DRAW1", "DRAW2", "DRAW3" }.ToDictionary(id => id,
    id => new CardObjectState(id, cardNo: "OGN·004/298", tags: [CardObjectTags.SpellCard], ownerId: "P1", controllerId: "P1"));
cards["UNIT"] = new("UNIT", cardNo: "SFD·125/221", power: 4, tags: [CardObjectTags.UnitCard], ownerId: "P1", controllerId: "P1");
cards["BF"] = new("BF", cardNo: "OGN·296/298", tags: [P6TokenFactoryCatalog.BattlefieldCardTag], ownerId: "P2");
cards["OTHER"] = new("OTHER", cardNo: "OGN·280/298", tags: [P6TokenFactoryCatalog.BattlefieldCardTag], ownerId: "P1");
var initial = new MatchState(roomId: "first-burnout-cleanup-source-counterexample", tick: 0, turnNumber: 5,
    activePlayerId: "P1", seats: new Dictionary<string, string> { ["P1"] = "P1", ["P2"] = "P2" },
    status: MatchStatuses.InProgress, readyPlayerIds: ["P1", "P2"], turnPlayerId: "P1", phase: MatchPhases.Main,
    timingState: TimingStates.NeutralOpen,
    playerZones: new Dictionary<string, PlayerZones> {
        ["P1"] = PlayerZones.Empty with { Base = ["UNIT"], Battlefields = ["OTHER"], Hand = ["H1", "H2", "H3"], Graveyard = ["DRAW1", "DRAW2", "DRAW3"] },
        ["P2"] = PlayerZones.Empty with { Battlefields = ["BF"] } },
    cardObjects: cards, playerScores: new Dictionary<string, int> { ["P1"] = 7, ["P2"] = 7 },
    runePools: new Dictionary<string, RunePool> { ["P1"] = RunePool.Empty, ["P2"] = RunePool.Empty });
var journal = new Journal(); var session = new MatchSession(initial, new CoreRuleEngine(), journal); var state = initial;
foreach (var (actor, command) in new (string, GameCommand)[] {
    ("P1", new MoveUnitCommand("UNIT", "BASE", "BATTLEFIELD:BF", [])), ("P1", new PassFocusCommand()), ("P2", new PassFocusCommand()) })
{
    var prompt = session.PromptFor(actor); var raw = JsonSerializer.SerializeToNode(command, command.GetType(), json)!.AsObject();
    raw["promptId"] = prompt.PromptId; raw["snapshotTick"] = state.Tick;
    var result = await session.SubmitAsync(actor, "original-" + journal.Entries.Count, command, JsonSerializer.SerializeToElement(raw, json), default);
    if (!result.Accepted) throw new InvalidOperationException(result.ErrorMessage);
    state = result.State;
}
var commands = journal.Entries.Select(e => new RecoveredCommand(e.PlayerId, e.ClientIntentId, e.CommandType, e.RawCommand,
    e.StartedTick, e.CompletedTick, e.StartedEventSequence, e.CompletedEventSequence, e.Accepted, e.ErrorMessage) { RuleInputs = e.RuleInputs }).ToArray();
var events = journal.Entries.SelectMany(e => e.Events.Select((ev, i) => new RecoveredEvent(e.StartedEventSequence + i + 1, e.CompletedTick, i, ev))).ToArray();
var replay = await MatchActionLogReplayer.VerifyFinalStateAsync(initial, commands, state, new CoreRuleEngine(), default, events);
if (!replay.IsMatch) throw new InvalidOperationException(string.Join("; ", replay.Errors));
var actualHand = state.PlayerZones["P1"].Hand.Count; var actualDeck = state.PlayerZones["P1"].MainDeck.Count;
var burnouts = events.Count(e => e.Event.Kind == "BURNOUT_APPLIED");
var complete = actualHand == 4 && actualDeck == 2;
var resultFile = Path.Combine(output, "source-directed-first-burnout-cleanup-counterexample-v1.json");
if (File.Exists(resultFile)) throw new InvalidOperationException("Do not replace a source-directed counterexample.");
await File.WriteAllTextAsync(resultFile, JsonSerializer.Serialize(new { status = complete ? "SOURCE_ORACLE_PASSED" : "REPRODUCED_FIRST_BURNOUT_WIN_STOPS_ORIGINAL_REPLACEMENT_DRAW",
    expectedHand = 4, actualHand, expectedRemainingDeck = 2, actualRemainingDeck = actualDeck, actualBurnouts = burnouts,
    actualOpponentScore = state.PlayerScores["P2"], actualWinner = state.WinnerPlayerId, originalAcceptedCommands = commands.Length,
    originalReplayMatchesActualState = replay.IsMatch, actualLoadedFourAssemblies = loaded,
    primaryCoreSha256 = "d6fd7140f106f9b5b3dc0d5817fd040110fe870a6da9ee335ba7f4f70f892d11",
    exactClauseAnchors = new[] { "303.1", "321", "414.4.c", "432.2.d", "432.3.c", "432.3.c.1", "474" },
    controlledPositionNotOrdinaryOpening = true, noRootSourceBinOrSqlMutation = true, notFullDrawFamilyCertification = true }, json));
await using (var file = new FileStream(Path.Combine(output, "all-original-inputs-states-events-first-burnout-v1.json.gz"), FileMode.CreateNew))
await using (var zip = new GZipStream(file, CompressionLevel.SmallestSize))
    await JsonSerializer.SerializeAsync(zip, new { initial, commands, events, final = state, journal.Entries }, json);
Console.WriteLine(complete ? "SOURCE_ORACLE_PASS" : $"SOURCE_ORACLE_RED first burnout1, opponent8, expected hand4/deck2, actual hand{actualHand}/deck{actualDeck}; original three-command replay exact.");
Environment.ExitCode = complete ? 0 : 1;
sealed class Journal : IMatchJournal
{
    internal List<MatchJournalEntry> Entries { get; } = [];
    public ValueTask RecordAsync(MatchJournalEntry entry, CancellationToken token) { Entries.Add(entry); return ValueTask.CompletedTask; }
}
