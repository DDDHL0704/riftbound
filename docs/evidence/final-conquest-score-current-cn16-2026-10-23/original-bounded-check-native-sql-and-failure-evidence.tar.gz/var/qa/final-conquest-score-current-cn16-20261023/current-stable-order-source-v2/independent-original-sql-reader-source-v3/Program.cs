using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.CardCatalog;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
var modules = new[] { typeof(CoreRuleEngine).Assembly, typeof(GameCommand).Assembly, typeof(OfficialCardCatalog).Assembly, typeof(PostgresMatchRecoveryStore).Assembly };
var loaded = new { baseDirectory = AppContext.BaseDirectory, actualRuleInputs = RuleInputIdentity.Current,
    assemblies = modules.Select(a => new { name = a.GetName().Name, path = a.Location, mvid = a.ManifestModule.ModuleVersionId,
        sha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(a.Location))).ToLowerInvariant() }).ToArray() };
if (args is ["--loaded-inputs"]) { Console.WriteLine(JsonSerializer.Serialize(loaded, json)); return; }
Check(args.Length == 2 && !File.Exists(args[1]), "Original completed owner directory and unused result required.");
var home = Path.GetFullPath(args[0]);
using var owner = JsonDocument.Parse(File.ReadAllText(Path.Combine(home, "real-sql-seven-original-rooms-owner-terminal-v1.json")));
var top = owner.RootElement;
Check(top.GetProperty("status").GetString()!.StartsWith("PASS_FINAL_CONQUEST_SEVEN_ORIGINAL_REAL_SQL_ROOMS", StringComparison.Ordinal)
    && Same(top.GetProperty("actualLoadedFourAssemblies").GetProperty("actualRuleInputs"), JsonSerializer.SerializeToElement(RuleInputIdentity.Current, json)), "Original successful writer and actually loaded input identity.");
var settings = new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
Check(settings.Host == "127.0.0.1" && settings.Port == 55486 && settings.Database == "riftbound_acceptance"
    && settings.Username == "codex_riftbound_audit", "Only the actual owned acceptance database.");
settings.Options = "-c default_transaction_read_only=on";
await using var source = NpgsqlDataSource.Create(settings.ConnectionString);
await using var connection = await source.OpenConnectionAsync();
Check((string)(await new NpgsqlCommand("show transaction_read_only", connection).ExecuteScalarAsync())! == "on", "Actually read-only SQL connection.");
var counts = new Dictionary<string, int> { ["commands"] = 0, ["events"] = 0, ["authority"] = 0, ["snapshots"] = 0, ["prompts"] = 0, ["prefixReplays"] = 0, ["actualForgeryRefusals"] = 0 };
var outcomes = new List<object>(); var seenBranches = new HashSet<string>();
foreach (var receipt in top.GetProperty("receipts").EnumerateArray())
{
    var branch = receipt.GetProperty("branch").GetString()!; Check(seenBranches.Add(branch), "Every original branch occurs exactly once.");
    var room = receipt.GetProperty("room").GetString()!; var scenario = receipt.GetProperty("scenario").GetString()!;
    var folder = Path.Combine(home, "real-sql-seven-original-rooms-v1/final-conquest-score", branch);
    var corrupt = branch == "reject-forged-score";
    using var savedFrame = Read(Path.Combine(folder, "original-final-frame.json.gz"));
    var frame = savedFrame.RootElement.Deserialize<MatchRecoveryFrame>(json)!;
    using var savedRows = Read(Path.Combine(folder, "original-final-seven-tables.json.gz")); var originalRows = savedRows.RootElement;
    var live = (await new PostgresMatchRecoveryStore(source).LoadAsync(room, default))!;
    using var corruptRows = corrupt ? Read(Path.Combine(folder, "actual-corrupt-seven-tables.json.gz")) : null;
    using var corruptFrame = corrupt ? Read(Path.Combine(folder, "actual-corrupt-frame.json.gz")) : null;
    Check(Same(JsonSerializer.SerializeToElement(live, json), corrupt ? corruptFrame!.RootElement : savedFrame.RootElement), "Every actual current frame field, null and omission equals its original retained frame.");
    Check(frame.IsConsistent && frame.OpeningSeed != 0 && frame.ReplayInitialState is { Tick: 0, Status: "EMPTY", Seats.Count: 0, CardObjects.Count: 0 }
        && frame.Commands.All(c => c.Accepted && c.RuleInputs == RuleInputIdentity.Current), "Original EMPTY opening, private seed, all accepted inputs and current identity.");
    Check(frame.OpeningSeed == live.OpeningSeed && Same(JsonSerializer.SerializeToElement(frame.Commands, json), JsonSerializer.SerializeToElement(live.Commands, json))
        && Same(JsonSerializer.SerializeToElement(frame.Events, json), JsonSerializer.SerializeToElement(live.Events, json)), "Even deliberately corrupted rooms retain every original accepted input, event and private seed.");
    var expectedTypes = new List<string> { "ROOM_SEAT", "ROOM_SEAT", "DEV_SEED_SCENARIO:" + scenario, "MOVE_UNIT", "PASS_FOCUS", "PASS_FOCUS" };
    if (branch == "draw-hold") expectedTypes.AddRange(["END_TURN", "END_TURN"]);
    if (branch.StartsWith("brush", StringComparison.Ordinal)) expectedTypes.Add("CHOOSE_CARDS");
    if (branch == "brush-return") expectedTypes.AddRange(["PASS_PRIORITY", "PASS_PRIORITY"]);
    if (branch == "combat") expectedTypes.Add("DECLARE_BATTLE");
    Check(frame.Commands.Select(c => c.CommandType).SequenceEqual(expectedTypes), "Independent literal complete command sequence, with no skipped natural stage or repeated unavailable damage input.");
    for (var i = 0; i < 2; i++) {
        var c = frame.Commands[i]; var raw = c.RawCommand!.Value; var actor = i == 0 ? "alice" : "bob"; var seat = i == 0 ? "P1" : "P2";
        Check(c.PlayerId == actor && c.ClientIntentId == "room-seat:" + seat && raw.EnumerateObject().Count() == 3
            && raw.GetProperty("playerId").GetString() == actor && raw.GetProperty("seat").GetString() == seat
            && raw.GetProperty("cmdType").GetString() == "ROOM_SEAT", "Literal server identities and reserved atomic seat inputs, without credentials in the public raw schema.");
    }
    var states = new Dictionary<(long Tick, long Seq), MatchState>();
    foreach (var table in new[] { "matches", "match_players", "command_log", "game_events", "state_snapshots", "snapshots", "action_prompts" })
    {
        await using var q = new NpgsqlCommand($"select coalesce(json_agg(t order by row_to_json(t)::text),'[]'::json)::text from (select * from {table} where match_id=@room)t", connection);
        q.Parameters.AddWithValue("room", room); using var actual = JsonDocument.Parse((string)(await q.ExecuteScalarAsync())!);
        Check(Same(actual.RootElement, (corrupt ? corruptRows!.RootElement : originalRows).GetProperty(table)), "All actual seven-table fields, nulls and omissions equal their own original captured bytes: " + table);
        if (corrupt && table is "matches" or "match_players" or "command_log" or "game_events")
            Check(Same(actual.RootElement, originalRows.GetProperty(table)), "Deliberate coordinated payload corruption never rewrites original game inputs, events or room/credential metadata.");
        if (table == "state_snapshots") foreach (var row in originalRows.GetProperty(table).EnumerateArray()) {
            var payload = row.GetProperty("payload"); var state = payload.Deserialize<MatchState>(json)!;
            Check(Same(payload, JsonSerializer.SerializeToElement(state, json)) && state.RuleInputs == RuleInputIdentity.Current
                && states.TryAdd((state.Tick, row.GetProperty("last_event_sequence").GetInt64()), state), "Every complete original authority value and unique original checkpoint.");
        }
    }
    Check(states.Count == frame.Commands.Count && frame.Commands.All(c => states.ContainsKey((c.CompletedTick, c.CompletedEventSequence))), "Every accepted original input has its independently stored original authority history.");
    foreach (var (command, index) in frame.Commands.Select((c, i) => (c, i)))
    {
        var state = states[(command.CompletedTick, command.CompletedEventSequence)];
        using var cold = Read(Path.Combine(folder, $"prefix-{index + 1:D2}-original-frame.json.gz"));
        Check(Same(cold.RootElement.GetProperty("authoritativeState"), JsonSerializer.SerializeToElement(state, json))
            && Same(cold.RootElement.GetProperty("commands"), JsonSerializer.SerializeToElement(frame.Commands.Take(index + 1), json)), "Every original recorded cold checkpoint has its entire exact original state and command prefix.");
        var events = frame.Events.Where(e => e.Sequence <= command.CompletedEventSequence).ToArray();
        var replay = await MatchActionLogReplayer.VerifyFinalStateAsync(frame.ReplayInitialState!, frame.Commands.Take(index + 1).ToArray(), state, new CoreRuleEngine(), default, events);
        Check(replay.IsMatch, "Every complete original prefix actually replays: " + string.Join("; ", replay.Errors)); counts["prefixReplays"]++;
        if (index >= 3) {
            using var input = JsonDocument.Parse(File.ReadAllText(Path.Combine(folder, $"input-{index:D2}-original-command.json")));
            using var prompt = JsonDocument.Parse(File.ReadAllText(Path.Combine(folder, $"input-{index:D2}-original-prompt.json")));
            Check(Same(input.RootElement, command.RawCommand!.Value)
                && input.RootElement.GetProperty("snapshotTick").GetInt64() == command.StartedTick
                && input.RootElement.GetProperty("promptId").GetString() == prompt.RootElement.GetProperty("promptId").GetString(), "Each actual gameplay raw intent retains every original field and its original private prompt/tick stamp.");
        }
    }
    foreach (var table in new[] { "snapshots", "action_prompts" }) foreach (var row in originalRows.GetProperty(table).EnumerateArray())
    {
        var actor = row.GetProperty("player_id").GetString()!; var payload = row.GetProperty("payload");
        var tick = row.GetProperty(table == "snapshots" ? "snapshot_tick" : "prompt_tick").GetInt64(); var seq = row.GetProperty("last_event_sequence").GetInt64(); var state = states[(tick, seq)];
        Check(state.Seats.ContainsKey(actor), "Only an actually existing historical viewer has a private row.");
        var typed = table == "snapshots" ? JsonSerializer.SerializeToElement(payload.Deserialize<SnapshotDto>(json), json) : JsonSerializer.SerializeToElement(payload.Deserialize<ActionPromptDto>(json), json);
        var projected = table == "snapshots" ? JsonSerializer.SerializeToElement(ResolutionResult.BuildSnapshots(state)[actor], json) : JsonSerializer.SerializeToElement(ResolutionResult.BuildPrompts(state)[actor], json);
        if (!Same(payload, typed) || !Same(payload, projected)) {
            var diagnostic = new { branch, room, table, actor, tick, seq, typedEqual = Same(payload, typed), projectedEqual = Same(payload, projected), original = payload, typed, projected };
            await File.WriteAllTextAsync(args[1] + ".first-complete-private-difference.json", JsonSerializer.Serialize(diagnostic, json));
        }
        Check(Same(payload, typed), $"Every complete typed original private field, omission and null: {branch}/{table}/{actor}/{tick}/{seq}.");
        Check(Same(payload, projected), $"Every complete original private projection value: {branch}/{table}/{actor}/{tick}/{seq}.");
        Check(!payload.TryGetProperty("openingSeed", out _) && !payload.TryGetProperty("reconnectToken", out _) && !payload.TryGetProperty("playerKey", out _), "No seed or credential fields appear in private game projections.");
        var text = payload.GetRawText();
        foreach (var enemy in state.Seats.Keys.Where(p => p != actor)) foreach (var id in state.PlayerZones[enemy].Hand.Concat(state.PlayerZones[enemy].MainDeck))
            Check(!text.Contains(JsonSerializer.Serialize(id), StringComparison.Ordinal), "Independent literal opponent hand/deck identity boundary, without preview exceptions.");
    }
    var final = frame.AuthoritativeState!; var won = branch is "win" or "draw-hold";
    Check(final.PlayerScores["alice"] == (won ? 8 : 7) && final.PlayerScores["bob"] == (branch == "burnout" ? 1 : 0)
        && final.Status == (won ? MatchStatuses.Finished : MatchStatuses.InProgress) && final.WinnerPlayerId == (won ? "alice" : null), "Independent literal actual final scores and winner, including hold exemption and burnout opponent point.");
    Check(final.PlayerZones["alice"].Hand.Count == (branch == "win" ? 0 : 1)
        && final.PlayerZones["alice"].MainDeck.Count == (branch == "win" ? 3 : 2), "Independent actual draw, not an invented score point.");
    Check(frame.Events.Count(e => e.Event.Kind == "BATTLEFIELD_SCORE_REPLACED_BY_DRAW") == (branch == "win" ? 0 : 1)
        && frame.Events.All(e => e.Event.Kind is not ("PLAYER_SURRENDERED" or "MATCH_SURRENDERED")), "One exact replacement except the all-field win; no surrender.");
    if (branch == "burnout") Check(final.RngCursor == 1 && final.PlayerZones["alice"].Graveyard.Count == 0
        && frame.Events.Count(e => e.Event.Kind == "BURNOUT_APPLIED") == 1, "Literal original recycle, RNG advance and single burnout.");
    if (branch.StartsWith("brush", StringComparison.Ordinal)) Check(final.CardObjects["BF"].CardNo == (branch == "brush-return" ? "OGN·282/298" : "UNL·T03")
        && final.PlayerZones["bob"].Banished.Count == (branch == "brush-return" ? 0 : 1), "Physical Brush restore/decline and original owner exile link, without retroactive extra draw.");
    if (branch == "combat") Check(final.PlayerZones["bob"].Graveyard.Contains("DEFENDER"), "Actual printed combat defeat remains in its physical owner's graveyard.");
    Check((await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame, new CoreRuleEngine(), default)).Count == 0, "Complete original recovery-frame replay remains strict.");
    if (corrupt) {
        Check(live.AuthoritativeState!.PlayerScores["alice"] == 8 && final.PlayerScores["alice"] == 7
            && live.AuthoritativeState.UntilEndOfTurnEffects.Contains(BattlefieldTaskMarkers.ScoreGainedThisTurn("OTHER", "alice")), "The actual coordinated SQL attack differs from the retained original result.");
        Check((await MatchActionLogReplayer.ValidateRecoveryFrameAsync(live, new CoreRuleEngine(), default)).Count > 0, "Actual coordinated forgery fails unchanged original action-log audit.");
        var refused = false; try { await new InMemoryMatchSessionRegistry(new CoreRuleEngine(), new PostgresMatchJournal(source), new PostgresMatchRecoveryStore(source), new PostgresMatchPlayerStore(source)).GetOrCreateAsync(room, default); }
        catch (MatchSessionException e) when (e.Code == ErrorCodes.RecoveryInconsistent) { refused = true; }
        Check(refused, "A separately instantiated actual read-only registry refuses the original corrupt room."); counts["actualForgeryRefusals"]++;
    }
    counts["commands"] += frame.Commands.Count; counts["events"] += frame.Events.Count; counts["authority"] += states.Count;
    counts["snapshots"] += originalRows.GetProperty("snapshots").GetArrayLength(); counts["prompts"] += originalRows.GetProperty("action_prompts").GetArrayLength();
    outcomes.Add(new { branch, room, originalCommands = frame.Commands.Count, originalEvents = frame.Events.Count, actualCorruptionStillRetained = corrupt });
    Console.WriteLine("INDEPENDENT_ORIGINAL_FINAL_CONQUEST_PASS " + branch);
}
Check(seenBranches.SetEquals(new[] { "draw-hold", "win", "burnout", "brush-decline", "brush-return", "combat", "reject-forged-score" })
    && counts["commands"] == 49 && counts["authority"] == 49 && counts["snapshots"] == 91 && counts["prompts"] == 91
    && counts["prefixReplays"] == 49 && counts["actualForgeryRefusals"] == 1, "Exact original seven-room input/private/replay coverage, without hiding the actual corrupt room.");
await File.WriteAllTextAsync(args[1], JsonSerializer.Serialize(new { status = "PASS_INDEPENDENT_FINAL_CONQUEST_SEVEN_ORIGINAL_SQL_ROOMS49_PREFIXES91_EACH_PRIVATE_ONE_COORDINATED_REFUSAL", actualReadOnlyConnection = true,
    actualLoadedFourAssemblies = loaded, totals = counts, rooms = outcomes, allOriginalFieldsNullsOmissionsAndSeedsRetained = true, controlledPositionsNotOrdinaryOpenings = true,
    nativeControlsFixedCiWholePrintingsAndWindowsRemainSeparate = true }, json));
static JsonDocument Read(string path) { using var stream = new GZipStream(File.OpenRead(path), CompressionMode.Decompress); return JsonDocument.Parse(stream); }
static bool Same(JsonElement a, JsonElement b) => JsonNode.DeepEquals(JsonNode.Parse(a.GetRawText()), JsonNode.Parse(b.GetRawText()));
static void Check(bool value, string reason) { if (!value) throw new InvalidOperationException(reason); }
