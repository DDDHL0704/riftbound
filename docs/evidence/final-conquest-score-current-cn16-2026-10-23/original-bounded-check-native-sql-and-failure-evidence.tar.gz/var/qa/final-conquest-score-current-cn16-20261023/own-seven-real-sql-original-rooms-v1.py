from pathlib import Path
import ast,datetime,fcntl,hashlib,json,os,plistlib,resource,socket,subprocess
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
functions=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
for node in ast.parse(functions.read_text()).body:
 if isinstance(node,ast.FunctionDef)and node.name in {'query','rooms','digests','observe_lock'}:exec(compile(ast.get_source_segment(functions.read_text(),node),str(functions),'exec'),globals())
runtime=root/'tests/Riftbound.PostgresAcceptance/bin/Debug/net10.0';output=w/'real-sql-seven-original-rooms-v1';terminal=w/'real-sql-seven-original-rooms-owner-terminal-v1.json';assert not output.exists()and not terminal.exists()
runtime_hashes={str(p.relative_to(runtime)):sha(p)for p in runtime.rglob('*')if p.is_file()}
def source_hashes():
 paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z','--','src','tests','scripts','data','clients/godot'],cwd=root).split(b'\0')
 return {p.decode():sha(root/p.decode())for p in paths if p and(root/p.decode()).is_file()}
sources=source_hashes();own={str(p):sha(p)for p in [Path(__file__),functions]}
def stable():
 assert source_hashes()==sources
 assert {str(p.relative_to(runtime)):sha(p)for p in runtime.rglob('*')if p.is_file()}==runtime_hashes
 assert all(sha(Path(p))==h for p,h in own.items())
measurement_command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(runtime/'Riftbound.PostgresAcceptance.deps.json'),'--runtimeconfig',str(runtime/'Riftbound.PostgresAcceptance.runtimeconfig.json'),str(root/'var/qa/fixed267ab-early-native-20261022/executed-own-native-readers-and-drivers-v1/IndependentFixed267abControlledLabV1.dll'),'--loaded-inputs']
measured=json.loads(subprocess.check_output(measurement_command,cwd=runtime,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0')))
assert Path(measured['baseDirectory'])==runtime and len(measured['assemblies'])==4
for a in measured['assemblies']:assert Path(a['path'])==runtime/(a['name']+'.dll')and a['sha256']==runtime_hashes[a['name']+'.dll']and a['mvid']
proof=dict(status='RUNNING_FINAL_CONQUEST_REAL_SQL_SEVEN_FINITE_ORIGINAL_ROOMS',startedAtUtc=now(),baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),actualLoadedFourAssemblies=measured,runtimeInputHashes=runtime_hashes,sourceInputHashes=sources,ownInputHashes=own,lockAtStart=observe_lock(),onlyFreshOwnedDatabaseRoomsMayChange=True)
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a+');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB);started=False;power=None;before_audit=before_native=None
try:
 stable();assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket()as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid;sock.mkdir(exist_ok=True)
 subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'own-current-final-conquest-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 audit=rooms('riftbound_acceptance');native=rooms('riftbound_here_native');assert len(audit)==422 and len(native)==118
 before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',native)
 command=['/Users/dinghaolin/.dotnet/dotnet',str(runtime/'Riftbound.PostgresAcceptance.dll'),'--final-conquest-score-only'];proof['actualCommand']=command
 env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit',RIFTBOUND_POSTGRES_EVIDENCE=str(output),DOTNET_DbgEnableMiniDump='0');env.pop('DOTNET_STARTUP_HOOKS',None)
 with(w/'real-sql-seven-original-rooms-original-console-v1.log').open('xb')as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1800)
 proof['exitCode']=r.returncode;assert r.returncode==0,'Keep the exact original partial rooms, log and executed inputs; no silent rerun.'
 receipts=[load(p)for p in(output/'final-conquest-score').glob('*/receipt.json')];expected={'draw-hold','win','burnout','brush-decline','brush-return','combat','reject-forged-score'}
 assert len(receipts)==7 and {r['branch']for r in receipts}==expected
 assert all(r['actualRuleInputs']==measured['actualRuleInputs']and r['originalAcceptedInputs']==r['coldRecoveries']and r['originalPrivateSeed']!=0 and r['noAcceptedHistoryRewrite']for r in receipts)
 new=set(rooms('riftbound_acceptance'))-set(audit);assert new=={r['room']for r in receipts}
 proof.update(status='PASS_FINAL_CONQUEST_SEVEN_ORIGINAL_REAL_SQL_ROOMS_EVERY_ACCEPTED_PREFIX_COLD_REPLAY_ONE_COORDINATED_FORGERY_REFUSED_INDEPENDENT_READER_PENDING',receipts=receipts,newOriginalRooms=sorted(new),acceptedOriginalInputs=sum(r['originalAcceptedInputs']for r in receipts),coldRecoveries=sum(r['coldRecoveries']for r in receipts),coordinatedTamperRefusals=sum(r['deliberateCoordinatedForgeryRejected']for r in receipts),sourceCatalogAndMeaningfulFailureEvidenceRemainSeparate=True)
except BaseException as error:proof.update(status='FAILED_FINAL_CONQUEST_SQL_ORIGINAL_PARTIAL_ROOMS_OUTPUTS_INPUTS_RETAINED',errorType=type(error).__name__,error=str(error));raise
finally:
 if started:
  if before_audit is not None:proof.update(allOriginal422AuditSevenTablesExact=digests('riftbound_acceptance',audit)==before_audit,all118NativeSevenTablesExact=digests('riftbound_here_native',native)==before_native,actualAuditRoomsAtStop=rooms('riftbound_acceptance'),actualNativeRoomsAtStop=rooms('riftbound_here_native'))
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None and power.poll()is None:power.terminate();power.wait(timeout=10)
 stable();proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),allSourceRuntimeAndOwnInputsStable=True)
 with terminal.open('x')as f:json.dump(proof,f,ensure_ascii=False,indent=2)
 fcntl.flock(guard,fcntl.LOCK_UN)
assert all(proof[k]for k in ['allOriginal422AuditSevenTablesExact','all118NativeSevenTablesExact','ownPostgresSmartStopped','allSourceRuntimeAndOwnInputsStable']);print(proof['status'],flush=True)
