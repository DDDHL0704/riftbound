from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen
import ast
import gzip
import hashlib
import html.parser
import json

ROOT=Path('/Users/dinghaolin/MyProjects/riftbound')
Q=Path(__file__).resolve().parent
OLD=ROOT/'docs/evidence/source-round-2026-10-21/originals/news-reparsed-v2/all-current-news-original-readback-v2.json'
IDS={'CN-NEWS-55b818df90047879','CN-NEWS-170222472b44ce17','CN-NEWS-dffe0ec68d88b953'}
old={r['id']:r for r in json.loads(OLD.read_text()) if r['id'] in IDS}
namespace={'html':html,'sha':lambda b:hashlib.sha256(b).hexdigest()}
dependencies=[]
for path,names in [(ROOT/'var/qa/cn-effective-20261016/news/parse-articles-v3.py',{'Article'}),
                   (ROOT/'var/qa/source-round-20261021/reparse-retained-news-originals-readonly-v2.py',{'LiteralRoot','extract'})]:
    definitions=[n for n in ast.parse(path.read_text()).body if isinstance(n,(ast.ClassDef,ast.FunctionDef))and n.name in names]
    assert len(definitions)==len(names)
    exec(compile(ast.Module(body=definitions,type_ignores=[]),str(path),'exec'),namespace)
    source=path.read_bytes()
    with(Q/(path.name+'.source')).open('xb')as f:f.write(source)
    dependencies.append({'path':str(path),'sha256':hashlib.sha256(source).hexdigest()})
now=lambda:datetime.now(timezone.utc).isoformat()


def acquire(item):
    label,url,body=item
    record={'id':label,'url':url,'request':body,'startedAtUtc':now(),'semanticCoverageCertified':False}
    headers={'User-Agent':'Mozilla/5.0 Riftbound source audit'}
    if body is not None:headers['Content-Type']='application/json'
    try:
        try:
            response=urlopen(Request(url,data=None if body is None else json.dumps(body,ensure_ascii=False).encode(),headers=headers),timeout=25)
        except HTTPError as error:response=error
        with response:
            raw=response.read();record.update(httpStatus=response.status,resolvedUrl=response.url,responseHeaders=dict(response.headers),receivedAtUtc=now())
        packed=gzip.compress(raw,mtime=0);name=label+('.html.gz'if body is None else '.json.gz')
        with(Q/name).open('xb')as f:f.write(packed)
        record.update(archivePath=name,rawBytes=len(raw),rawSha256=hashlib.sha256(raw).hexdigest(),archiveSha256=hashlib.sha256(packed).hexdigest())
        if response.status!=200:record['sourceStatus']='HTTP_ERROR_RESPONSE_PRESERVED'
        elif body is None:
            parsed=namespace['extract'](raw);record.update(parsed)
            prior=old[label]
            record['comparisonWith20261021']={k:parsed[k]==prior[k]for k in ['literalRootSha256','bodyTextSha256','images','links']}
            record['sourceStatus']='COMPLETE_ARTICLE_ROOT_OBSERVED'
        else:
            parsed=json.loads(raw);assert parsed['code']==0
            record.update(reportedTotal=parsed['result']['total'],rows=parsed['result']['list'],sourceStatus='FILTERED_OFFICIAL_API_OBSERVATION_ONLY')
    except Exception as error:record.update(error=type(error).__name__+': '+str(error),failedAtUtc=now())
    with(Q/(label+'.receipt.json')).open('x')as f:json.dump(record,f,ensure_ascii=False,indent=2)
    print(label,record.get('httpStatus'),record.get('sourceStatus'),record.get('error',''),flush=True)
    return record


items=[(r['id'],r['url'],None)for r in old.values()]
params=dict(pageNum=1,pageSize=100,searchContent='狂暴之心',cardCategoryList=[],cardColorList=[],rarityList=[],productCodeList=[])
items.append(('kennen-filtered-api','https://lol-api.playloltcg.com/xcx/card/searchCardCraftWeb',params))
with ThreadPoolExecutor(max_workers=2)as pool:results=list(pool.map(acquire,items))
summary={'parserDependencies':dependencies,'priorIndexSha256':hashlib.sha256(OLD.read_bytes()).hexdigest(),'records':[{k:r.get(k)for k in ['id','httpStatus','sourceStatus','comparisonWith20261021','reportedTotal','error']}for r in results],'semanticCoverageCertified':False}
with(Q/'refresh-summary.json').open('x')as f:json.dump(summary,f,ensure_ascii=False,indent=2)
