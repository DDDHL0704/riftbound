using System.Reflection.Metadata;
using System.Reflection.Metadata.Ecma335;
using System.Reflection.PortableExecutable;
using System.Security.Cryptography;
using System.Text.Json;
Check(args.Length == 3 && !File.Exists(args[2]), "Two actual runtime directories and new result required.");
var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true }; var results = new List<object>();
foreach (var name in new[] { "Riftbound.Contracts", "Riftbound.CardCatalog", "Riftbound.Engine", "Riftbound.Persistence" })
{
    var beforePath = Path.Combine(args[0], name + ".dll"); var afterPath = Path.Combine(args[1], name + ".dll");
    var before = Read(beforePath); var after = Read(afterPath);
    Check(before.Methods.SequenceEqual(after.Methods) && before.Types.SequenceEqual(after.Types), "Exact method names/flags/signatures/IL/local signatures/exception regions/type rows changed: " + name);
    results.Add(new { assembly = name, beforePath, afterPath, beforeFileSha256 = Hash(File.ReadAllBytes(beforePath)), afterFileSha256 = Hash(File.ReadAllBytes(afterPath)),
        beforeMvid = before.Mvid, afterMvid = after.Mvid, beforeInformationalVersion = before.Version, afterInformationalVersion = after.Version,
        actualMethods = before.Methods.Length, actualTypes = before.Types.Length, exactMethodBodyAndTypeRowsEqual = true });
}
await File.WriteAllTextAsync(args[2], JsonSerializer.Serialize(new { status = "PASS_FOUR_ASSEMBLIES_EXACT_METHOD_BODIES_SIGNATURES_EXCEPTION_REGIONS_AND_TYPE_ROWS_INFORMATIONAL_VERSION_AND_MVID_DIFFER",
    actualAssemblies = results, bounds = "Source and executable method-body comparison only; does not equate complete PE files, MVIDs, RuleInputIdentity or recovery compatibility. Fresh matching-identity SQL remains required." }, json));
static (string Mvid, string? Version, string[] Methods, string[] Types) Read(string path)
{
    using var stream = File.OpenRead(path); using var pe = new PEReader(stream); var metadata = pe.GetMetadataReader(); var methods = new List<string>(); var types = new List<string>();
    foreach (var handle in metadata.TypeDefinitions)
    {
        var type = metadata.GetTypeDefinition(handle); types.Add(string.Join('|', MetadataTokens.GetToken(handle), metadata.GetString(type.Namespace), metadata.GetString(type.Name), (int)type.Attributes, MetadataTokens.GetToken(type.BaseType), type.GetMethods().Count, type.GetFields().Count));
    }
    foreach (var handle in metadata.MethodDefinitions)
    {
        var method = metadata.GetMethodDefinition(handle); var body = method.RelativeVirtualAddress == 0 ? null : pe.GetMethodBody(method.RelativeVirtualAddress);
        var localSignature = body is null || body.LocalSignature.IsNil ? "" : Convert.ToHexString(metadata.GetBlobBytes(metadata.GetStandaloneSignature(body.LocalSignature).Signature));
        var exceptions = body is null ? "" : string.Join(';', body.ExceptionRegions.Select(e => string.Join(',', (int)e.Kind, e.TryOffset, e.TryLength, e.HandlerOffset, e.HandlerLength, e.FilterOffset, MetadataTokens.GetToken(e.CatchType))));
        methods.Add(string.Join('|', MetadataTokens.GetToken(handle), metadata.GetString(method.Name), (int)method.Attributes, (int)method.ImplAttributes,
            Convert.ToHexString(metadata.GetBlobBytes(method.Signature)), body?.MaxStack.ToString() ?? "", body?.LocalVariablesInitialized.ToString() ?? "",
            body is null ? "" : Convert.ToHexString(body.GetILBytes() ?? []), localSignature, exceptions));
    }
    // Read the actual assembly informational-version attribute by its stable compiler blob prefix.
    string? version = null;
    foreach (var handle in metadata.GetAssemblyDefinition().GetCustomAttributes())
    {
        var attribute = metadata.GetCustomAttribute(handle); var bytes = metadata.GetBlobBytes(attribute.Value); var text = System.Text.Encoding.UTF8.GetString(bytes);
        var match = System.Text.RegularExpressions.Regex.Match(text, @"1\.0\.0\+[0-9a-f]{40}"); if (match.Success) version = match.Value;
    }
    return (metadata.GetGuid(metadata.GetModuleDefinition().Mvid).ToString(), version, methods.ToArray(), types.ToArray());
}
static string Hash(byte[] bytes) => Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant();
static void Check(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
