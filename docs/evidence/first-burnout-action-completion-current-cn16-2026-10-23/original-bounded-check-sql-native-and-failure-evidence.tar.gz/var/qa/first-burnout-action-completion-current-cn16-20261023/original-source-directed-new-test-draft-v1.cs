using Riftbound.Contracts;
using Riftbound.Engine;
using Xunit;

namespace Riftbound.ConformanceTests;

// CN core effective 2026-10-16: 303.1, 414.4.c, 432.2.d,
// 432.3.c.1 and 474 distinguish completing a first burnout from immediate subsequent victory.
public sealed class BurnoutActionCompletionTests
{
    [Theory]
    [InlineData(7, 7, true)]
    [InlineData(8, 8, true)]
    [InlineData(9, 8, false)]
    [InlineData(7, 6, false)]
    public async Task AFirstRecyclableBurnoutCompletesTheOriginalDrawBeforeNormalVictory(
        int ownScore, int opponentScore, bool opponentWins)
    {
        var baseState = ConquestLifecycleRegressionTests.State("OGN·296/298");
        var initial = baseState with {
            RngCursor = 9,
            PlayerScores = new Dictionary<string, int> { ["P1"] = ownScore, ["P2"] = opponentScore },
            PlayerZones = new Dictionary<string, PlayerZones>(baseState.PlayerZones) {
                ["P1"] = baseState.PlayerZones["P1"] with {
                    MainDeck = [], Graveyard = ["DRAW1", "DRAW2", "DRAW3"],
                    Battlefields = baseState.PlayerZones["P1"].Battlefields.Append("OTHER").ToArray() } },
            CardObjects = new Dictionary<string, CardObjectState>(baseState.CardObjects) {
                ["OTHER"] = new("OTHER", cardNo: "OGN·280/298", ownerId: "P1",
                    tags: [P6TokenFactoryCatalog.BattlefieldCardTag]) },
            ObjectLocations = new Dictionary<string, ObjectLocationState>(baseState.ObjectLocations) {
                ["OTHER"] = new("P1", "BATTLEFIELD", "OTHER") } };
        var driver = new StandbyDefendObserverTests.Driver(initial);
        await driver.Act("P1", new MoveUnitCommand("UNIT", "BASE", "BATTLEFIELD:BF", []));
        await driver.Act("P1", new PassFocusCommand());
        var result = await driver.Act("P2", new PassFocusCommand());

        Assert.Equal(4, driver.State.PlayerZones["P1"].Hand.Count);
        Assert.Equal(initial.PlayerZones["P1"].Hand, driver.State.PlayerZones["P1"].Hand.Take(3));
        Assert.Contains(driver.State.PlayerZones["P1"].Hand[^1], new[] { "DRAW1", "DRAW2", "DRAW3" });
        Assert.Equal(2, driver.State.PlayerZones["P1"].MainDeck.Count);
        Assert.Empty(driver.State.PlayerZones["P1"].Graveyard);
        Assert.Equal(10, driver.State.RngCursor);
        Assert.Equal(ownScore, driver.State.PlayerScores["P1"]);
        Assert.Equal(opponentScore+1, driver.State.PlayerScores["P2"]);
        Assert.Equal(opponentWins ? "P2" : null, driver.State.WinnerPlayerId);
        Assert.Equal(opponentWins ? MatchStatuses.Finished : MatchStatuses.InProgress, driver.State.Status);
        Assert.Equal("P1", driver.State.CardObjects["BF"].ControllerId);
        Assert.Contains(BattlefieldTaskMarkers.ScoreGainedThisTurn("BF", "P1"), driver.State.UntilEndOfTurnEffects);
        Assert.Single(result.Events, e => e.Kind == "BURNOUT_APPLIED");
        Assert.Equal(1, Assert.Single(result.Events, e => e.Kind == "CARD_DRAWN").Payload["count"]);
        var kinds = result.Events.Select(e => e.Kind).ToList();
        Assert.True(kinds.IndexOf("BURNOUT_APPLIED") < kinds.IndexOf("CARD_DRAWN"));
        if (opponentWins)
        {
            Assert.Single(result.Events, e => e.Kind == "MATCH_WON");
            Assert.True(kinds.IndexOf("CARD_DRAWN") < kinds.IndexOf("MATCH_WON"));
        }
        else Assert.DoesNotContain(result.Events, e => e.Kind == "MATCH_WON");
        await RideTheWindCurrentMovementTests.Replay(initial, driver);
    }
}
