using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.CardCatalog;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
var modules = new[] { typeof(CoreRuleEngine).Assembly, typeof(GameCommand).Assembly, typeof(OfficialCardCatalog).Assembly, typeof(PostgresMatchRecoveryStore).Assembly };
var loaded = new { baseDirectory = AppContext.BaseDirectory, actualRuleInputs = RuleInputIdentity.Current,
    assemblies = modules.Select(a => new { name = a.GetName().Name, path = a.Location, mvid = a.ManifestModule.ModuleVersionId,
        sha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(a.Location))).ToLowerInvariant() }).ToArray() };
if (args is ["--loaded-inputs"]) { Console.WriteLine(JsonSerializer.Serialize(loaded, json)); return; }
Check(args.Length == 2 && !File.Exists(args[1]), "Original completed owner directory and unused result required.");
var home = Path.GetFullPath(args[0]);
using var owner = JsonDocument.Parse(File.ReadAllText(Path.Combine(home, "real-sql-six-burnout-original-rooms-owner-terminal-v2.json")));
var top = owner.RootElement;
Check(top.GetProperty("status").GetString()!.StartsWith("PASS_FIRST_BURNOUT_ACTION_COMPLETION_SIX_ORIGINAL_REAL_SQL_ROOMS", StringComparison.Ordinal)
    && Same(top.GetProperty("actualLoadedFourAssemblies").GetProperty("actualRuleInputs"), JsonSerializer.SerializeToElement(RuleInputIdentity.Current, json)), "Original successful writer and actually loaded input identity.");
var settings = new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
Check(settings.Host == "127.0.0.1" && settings.Port == 55486 && settings.Database == "riftbound_acceptance"
    && settings.Username == "codex_riftbound_audit", "Only the actual owned acceptance database.");
settings.Options = "-c default_transaction_read_only=on";
await using var source = NpgsqlDataSource.Create(settings.ConnectionString);
await using var connection = await source.OpenConnectionAsync();
Check((string)(await new NpgsqlCommand("show transaction_read_only", connection).ExecuteScalarAsync())! == "on", "Actually read-only SQL connection.");
var counts = new Dictionary<string, int> { ["commands"] = 0, ["events"] = 0, ["authority"] = 0, ["snapshots"] = 0, ["prompts"] = 0, ["prefixReplays"] = 0, ["actualForgeryRefusals"] = 0 };
var outcomes = new List<object>(); var seenBranches = new HashSet<string>();
foreach (var receipt in top.GetProperty("receipts").EnumerateArray())
{
    var branch = receipt.GetProperty("branch").GetString()!; Check(seenBranches.Add(branch), "Every original branch occurs exactly once.");
    var room = receipt.GetProperty("room").GetString()!; var scenario = receipt.GetProperty("scenario").GetString()!;
    var folder = Path.Combine(home, "real-sql-six-burnout-original-rooms-v2/burnout-action-completion", branch);
    var corrupt = branch == "reject-forged-draw";
    using var savedFrame = Read(Path.Combine(folder, "original-final-frame.json.gz"));
    var frame = savedFrame.RootElement.Deserialize<MatchRecoveryFrame>(json)!;
    using var savedRows = Read(Path.Combine(folder, "original-final-seven-tables.json.gz")); var originalRows = savedRows.RootElement;
    var live = (await new PostgresMatchRecoveryStore(source).LoadAsync(room, default))!;
    using var corruptRows = corrupt ? Read(Path.Combine(folder, "actual-corrupt-seven-tables.json.gz")) : null;
    using var corruptFrame = corrupt ? Read(Path.Combine(folder, "actual-corrupt-frame.json.gz")) : null;
    Check(Same(JsonSerializer.SerializeToElement(live, json), corrupt ? corruptFrame!.RootElement : savedFrame.RootElement), "Every actual current frame field, null and omission equals its original retained frame.");
    Check(frame.IsConsistent && frame.OpeningSeed != 0 && frame.ReplayInitialState is { Tick: 0, Status: "EMPTY", Seats.Count: 0, CardObjects.Count: 0 }
        && frame.Commands.All(c => c.Accepted && c.RuleInputs == RuleInputIdentity.Current), "Original EMPTY opening, private seed, all accepted inputs and current identity.");
    Check(frame.OpeningSeed == live.OpeningSeed && Same(JsonSerializer.SerializeToElement(frame.Commands, json), JsonSerializer.SerializeToElement(live.Commands, json))
        && Same(JsonSerializer.SerializeToElement(frame.Events, json), JsonSerializer.SerializeToElement(live.Events, json)), "Even deliberately corrupted rooms retain every original accepted input, event and private seed.");
    var expectedTypes = new List<string> { "ROOM_SEAT", "ROOM_SEAT", "DEV_SEED_SCENARIO:" + scenario };
    expectedTypes.AddRange(branch is "conquest" or "reject-forged-draw"
        ? ["MOVE_UNIT", "PASS_FOCUS", "PASS_FOCUS"]
        : branch == "hwei" ? ["MOVE_UNIT", "PASS_PRIORITY", "PASS_PRIORITY", "CHOOSE_HAND_CARDS"]
        : ["PLAY_CARD", "PASS_PRIORITY", "PASS_PRIORITY"]);
    Check(frame.Commands.Select(c => c.CommandType).SequenceEqual(expectedTypes), "Independent literal complete command sequence, with no skipped natural stage or repeated unavailable damage input.");
    for (var i = 0; i < 2; i++) {
        var c = frame.Commands[i]; var raw = c.RawCommand!.Value; var actor = i == 0 ? "alice" : "bob"; var seat = i == 0 ? "P1" : "P2";
        Check(c.PlayerId == actor && c.ClientIntentId == "room-seat:" + seat && raw.EnumerateObject().Count() == 3
            && raw.GetProperty("playerId").GetString() == actor && raw.GetProperty("seat").GetString() == seat
            && raw.GetProperty("cmdType").GetString() == "ROOM_SEAT", "Literal server identities and reserved atomic seat inputs, without credentials in the public raw schema.");
    }
    var states = new Dictionary<(long Tick, long Seq), MatchState>();
    foreach (var table in new[] { "matches", "match_players", "command_log", "game_events", "state_snapshots", "snapshots", "action_prompts" })
    {
        await using var q = new NpgsqlCommand($"select coalesce(json_agg(t order by row_to_json(t)::text),'[]'::json)::text from (select * from {table} where match_id=@room)t", connection);
        q.Parameters.AddWithValue("room", room); using var actual = JsonDocument.Parse((string)(await q.ExecuteScalarAsync())!);
        Check(Same(actual.RootElement, (corrupt ? corruptRows!.RootElement : originalRows).GetProperty(table)), "All actual seven-table fields, nulls and omissions equal their own original captured bytes: " + table);
        if (corrupt && table is "matches" or "match_players" or "command_log" or "game_events")
            Check(Same(actual.RootElement, originalRows.GetProperty(table)), "Deliberate coordinated payload corruption never rewrites original game inputs, events or room/credential metadata.");
        if (table == "state_snapshots") foreach (var row in originalRows.GetProperty(table).EnumerateArray()) {
            var payload = row.GetProperty("payload"); var state = payload.Deserialize<MatchState>(json)!;
            Check(Same(payload, JsonSerializer.SerializeToElement(state, json)) && state.RuleInputs == RuleInputIdentity.Current
                && states.TryAdd((state.Tick, row.GetProperty("last_event_sequence").GetInt64()), state), "Every complete original authority value and unique original checkpoint.");
        }
    }
    Check(states.Count == frame.Commands.Count && frame.Commands.All(c => states.ContainsKey((c.CompletedTick, c.CompletedEventSequence))), "Every accepted original input has its independently stored original authority history.");
    foreach (var (command, index) in frame.Commands.Select((c, i) => (c, i)))
    {
        var state = states[(command.CompletedTick, command.CompletedEventSequence)];
        using var cold = Read(Path.Combine(folder, $"prefix-{index + 1:D2}-original-frame.json.gz"));
        Check(Same(cold.RootElement.GetProperty("authoritativeState"), JsonSerializer.SerializeToElement(state, json))
            && Same(cold.RootElement.GetProperty("commands"), JsonSerializer.SerializeToElement(frame.Commands.Take(index + 1), json)), "Every original recorded cold checkpoint has its entire exact original state and command prefix.");
        var events = frame.Events.Where(e => e.Sequence <= command.CompletedEventSequence).ToArray();
        var replay = await MatchActionLogReplayer.VerifyFinalStateAsync(frame.ReplayInitialState!, frame.Commands.Take(index + 1).ToArray(), state, new CoreRuleEngine(), default, events);
        Check(replay.IsMatch, "Every complete original prefix actually replays: " + string.Join("; ", replay.Errors)); counts["prefixReplays"]++;
        if (index >= 3) {
            using var input = JsonDocument.Parse(File.ReadAllText(Path.Combine(folder, $"input-{index:D2}-original-command.json")));
            using var prompt = JsonDocument.Parse(File.ReadAllText(Path.Combine(folder, $"input-{index:D2}-original-prompt.json")));
            Check(Same(input.RootElement, command.RawCommand!.Value)
                && input.RootElement.GetProperty("snapshotTick").GetInt64() == command.StartedTick
                && input.RootElement.GetProperty("promptId").GetString() == prompt.RootElement.GetProperty("promptId").GetString(), "Each actual gameplay raw intent retains every original field and its original private prompt/tick stamp.");
        }
    }
    foreach (var table in new[] { "snapshots", "action_prompts" }) foreach (var row in originalRows.GetProperty(table).EnumerateArray())
    {
        var actor = row.GetProperty("player_id").GetString()!; var payload = row.GetProperty("payload");
        var tick = row.GetProperty(table == "snapshots" ? "snapshot_tick" : "prompt_tick").GetInt64(); var seq = row.GetProperty("last_event_sequence").GetInt64(); var state = states[(tick, seq)];
        Check(state.Seats.ContainsKey(actor), "Only an actually existing historical viewer has a private row.");
        var typed = table == "snapshots" ? JsonSerializer.SerializeToElement(payload.Deserialize<SnapshotDto>(json), json) : JsonSerializer.SerializeToElement(payload.Deserialize<ActionPromptDto>(json), json);
        var projected = table == "snapshots" ? JsonSerializer.SerializeToElement(ResolutionResult.BuildSnapshots(state)[actor], json) : JsonSerializer.SerializeToElement(ResolutionResult.BuildPrompts(state)[actor], json);
        if (!Same(payload, typed) || !Same(payload, projected)) {
            var diagnostic = new { branch, room, table, actor, tick, seq, typedEqual = Same(payload, typed), projectedEqual = Same(payload, projected), original = payload, typed, projected };
            await File.WriteAllTextAsync(args[1] + ".first-complete-private-difference.json", JsonSerializer.Serialize(diagnostic, json));
        }
        Check(Same(payload, typed), $"Every complete typed original private field, omission and null: {branch}/{table}/{actor}/{tick}/{seq}.");
        Check(Same(payload, projected), $"Every complete original private projection value: {branch}/{table}/{actor}/{tick}/{seq}.");
        Check(!payload.TryGetProperty("openingSeed", out _) && !payload.TryGetProperty("reconnectToken", out _) && !payload.TryGetProperty("playerKey", out _), "No seed or credential fields appear in private game projections.");
        var text = payload.GetRawText();
        foreach (var enemy in state.Seats.Keys.Where(p => p != actor)) foreach (var id in state.PlayerZones[enemy].Hand.Concat(state.PlayerZones[enemy].MainDeck))
            Check(!text.Contains(JsonSerializer.Serialize(id), StringComparison.Ordinal), "Independent literal opponent hand/deck identity boundary, without preview exceptions.");
    }
    var final = frame.AuthoritativeState!; var tie = branch == "portal-tie";
    Check(final.PlayerScores["alice"] == (branch is "conquest" or "reject-forged-draw" ? 7 : tie ? 8 : 0)
        && final.PlayerScores["bob"] == (branch == "second-burnout" ? 9 : 8)
        && final.Status == (tie ? MatchStatuses.InProgress : MatchStatuses.Finished)
        && final.WinnerPlayerId == (tie ? null : "bob"), "Literal independent scores, ties and first versus subsequent burnout victory.");
    Check(final.PlayerZones["alice"].Hand.Count == (branch == "draw-two" ? 2 : 1)
        && final.PlayerZones["alice"].MainDeck.Count == (branch is "conquest" or "reject-forged-draw" or "hwei" ? 2 : branch == "draw-two" ? 1 : 0),
        "Independently expected physical cards and remaining deck, including a partial draw before immediate victory.");
    var kinds = frame.Events.Select(e => e.Event.Kind).ToList();
    Check(kinds.Count(k => k == "BURNOUT_APPLIED") == (branch is "second-burnout" or "portal-tie" ? 2 : 1)
        && kinds.Count(k => k == "MATCH_WON") == (tie ? 0 : 1)
        && frame.Commands.All(c => c.CommandType != "SURRENDER"), "Independent original burnout/winner multiplicities and no surrender.");
    var draws = frame.Events.Where(e => e.Event.Kind == "CARD_DRAWN").Select(e => JsonSerializer.SerializeToElement(e.Event.Payload, json)).ToArray();
    Check(draws.Length == (tie ? 2 : 1) && draws.All(e => e.GetProperty("count").GetInt32() == (branch == "draw-two" ? 2 : 1))
        && draws.Select(e => e.GetProperty("playerId").GetString()).SequenceEqual(tie ? ["alice", "bob"] : ["alice"]),
        "Exact draw event presence, count and every original recipient, including the single draw2 event.");
    if (!tie) Check(kinds.IndexOf("CARD_DRAWN") < kinds.IndexOf("MATCH_WON"), "Actual drawing, including an immediate-win partial draw, happens before the terminal event.");
    if (branch is "conquest" or "reject-forged-draw") Check(final.RngCursor == 1
        && final.CardObjects["BF"].ControllerId == "alice"
        && kinds.Count(k => k == "BATTLEFIELD_SCORE_REPLACED_BY_DRAW") == 1,
        "Actual first recyclable conquest keeps the original control transition, RNG advance and scoring replacement.");
    if (branch == "hwei") {
        var suspended = states.Values.Single(state => state.PendingHandChoice is not null);
        Check(suspended.Status == MatchStatuses.InProgress && suspended.WinnerPlayerId is null
            && suspended.PlayerScores["bob"] == 8 && suspended.PlayerZones["alice"].Hand.Count == 2
            && suspended.PendingHandChoice!.DrawCount == 0 && suspended.PendingHandChoice.RequiredCount == 1,
            "The actually persisted parent remains pending after first burnout at8, without inventing another draw.");
        Check(final.PlayerZones["alice"].Hand.SequenceEqual(["HAND"]) && final.PendingHandChoice is null
            && kinds.Count(k => k == "HAND_CHOICE_RESOLVED") == 1
            && kinds.IndexOf("HAND_CHOICE_RESOLVED") < kinds.IndexOf("MATCH_WON"), "The mandatory discard physically completes before cleanup victory.");
    }
    if (tie) Check(final.PlayerZones["bob"].Hand.SequenceEqual(["P2-REFILL"])
        && kinds.Count(k => k == "CARD_DRAWN") == 2, "Both actual recipients draw before a tied parent's cleanup.");
    Check((await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame, new CoreRuleEngine(), default)).Count == 0, "Complete original recovery-frame replay remains strict.");
    if (corrupt) {
        Check(live.IsConsistent && live.ValidationErrors.Count == 0
            && live.AuthoritativeState!.PlayerZones["alice"].Hand.Count == 0
            && live.AuthoritativeState.PlayerZones["alice"].MainDeck.Count == 3
            && final.PlayerZones["alice"].Hand.Count == 1 && final.PlayerZones["alice"].MainDeck.Count == 2,
            "The real coordinated skipped-draw attack is structurally consistent yet differs from the unchanged original action history.");
        Check((await MatchActionLogReplayer.ValidateRecoveryFrameAsync(live, new CoreRuleEngine(), default)).Count > 0, "Actual coordinated forgery fails unchanged original action-log audit.");
        var refused = false; try { await new InMemoryMatchSessionRegistry(new CoreRuleEngine(), new PostgresMatchJournal(source), new PostgresMatchRecoveryStore(source), new PostgresMatchPlayerStore(source)).GetOrCreateAsync(room, default); }
        catch (MatchSessionException e) when (e.Code == ErrorCodes.RecoveryInconsistent) { refused = true; }
        Check(refused, "A separately instantiated actual read-only registry refuses the original corrupt room."); counts["actualForgeryRefusals"]++;
    }
    counts["commands"] += frame.Commands.Count; counts["events"] += frame.Events.Count; counts["authority"] += states.Count;
    counts["snapshots"] += originalRows.GetProperty("snapshots").GetArrayLength(); counts["prompts"] += originalRows.GetProperty("action_prompts").GetArrayLength();
    outcomes.Add(new { branch, room, originalCommands = frame.Commands.Count, originalEvents = frame.Events.Count, actualCorruptionStillRetained = corrupt });
    Console.WriteLine("INDEPENDENT_ORIGINAL_FIRST_BURNOUT_PASS " + branch);
}
Check(seenBranches.SetEquals(new[] { "conquest", "draw-two", "second-burnout", "hwei", "portal-tie", "reject-forged-draw" })
    && counts["commands"] == 37 && counts["authority"] == 37 && counts["snapshots"] == 68 && counts["prompts"] == 68
    && counts["prefixReplays"] == 37 && counts["actualForgeryRefusals"] == 1,
    "All six original rooms,37 complete prefixes,68 each private histories and the actual coordinated refusal remain present.");
await File.WriteAllTextAsync(args[1], JsonSerializer.Serialize(new { status = "PASS_INDEPENDENT_FIRST_BURNOUT_SIX_ORIGINAL_SQL_ROOMS37_PREFIXES68_EACH_PRIVATE_ONE_COORDINATED_REFUSAL", actualReadOnlyConnection = true,
    actualLoadedFourAssemblies = loaded, totals = counts, rooms = outcomes, allOriginalFieldsNullsOmissionsAndSeedsRetained = true, controlledPositionsNotOrdinaryOpenings = true,
    nativeControlsFixedCiWholePrintingsAndWindowsRemainSeparate = true }, json));
static JsonDocument Read(string path) { using var stream = new GZipStream(File.OpenRead(path), CompressionMode.Decompress); return JsonDocument.Parse(stream); }
static bool Same(JsonElement a, JsonElement b) => JsonNode.DeepEquals(JsonNode.Parse(a.GetRawText()), JsonNode.Parse(b.GetRawText()));
static void Check(bool value, string reason) { if (!value) throw new InvalidOperationException(reason); }
