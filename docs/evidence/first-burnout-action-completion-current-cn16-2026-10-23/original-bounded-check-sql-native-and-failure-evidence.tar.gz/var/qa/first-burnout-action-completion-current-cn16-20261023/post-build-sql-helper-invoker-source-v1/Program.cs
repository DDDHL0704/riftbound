using System.Reflection;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.Text.Json;
using Npgsql;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.CardCatalog;
using Riftbound.Persistence;
var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
var assemblies = new[] { typeof(CoreRuleEngine).Assembly, typeof(GameCommand).Assembly, typeof(OfficialCardCatalog).Assembly, typeof(PostgresMatchJournal).Assembly };
var loaded = new { baseDirectory = AppContext.BaseDirectory, actualRuleInputs = RuleInputIdentity.Current,
    assemblies = assemblies.Select(a => new { name = a.GetName().Name, path = a.Location, mvid = a.ManifestModule.ModuleVersionId,
        informationalVersion = a.GetCustomAttribute<AssemblyInformationalVersionAttribute>()?.InformationalVersion,
        sha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(a.Location))).ToLowerInvariant() }).ToArray() };
if (args is ["--loaded-inputs"]) { Console.WriteLine(JsonSerializer.Serialize(loaded, json)); return; }
if (args.Length != 2) throw new InvalidOperationException("Exact existing SQL helper assembly and new scoped output directory required.");
var output = Path.GetFullPath(args[1]); if (Directory.Exists(output)) throw new InvalidOperationException("Do not overwrite prior SQL evidence.");
var settings = new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
if (settings.Host != "127.0.0.1" || settings.Port != 55486 || settings.Database != "riftbound_acceptance" || settings.Username != "codex_riftbound_audit")
    throw new InvalidOperationException("Only dedicated loopback acceptance SQL.");
var helper = AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.GetFullPath(args[0]));
var type = helper.GetType("BurnoutActionCompletionSqlAcceptance", throwOnError: true)!;
var run = type.GetMethod("RunAsync", BindingFlags.Static | BindingFlags.Public)!;
await using var source = NpgsqlDataSource.Create(settings.ConnectionString);
await (Task)run.Invoke(null, [source, output])!;
await File.WriteAllTextAsync(Path.Combine(Path.GetDirectoryName(output)!, "actual-post-build-sql-invoker-loaded-inputs-v1.json"), JsonSerializer.Serialize(new {
    actualLoadedFourAssemblies = loaded, actualHelperPath = helper.Location, actualHelperMvid = helper.ManifestModule.ModuleVersionId,
    actualHelperSha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(helper.Location))).ToLowerInvariant(),
    onlyExactExistingFiniteSqlHelperInvoked = true, noSourceBinOrOldRoomRewrite = true }, json));
