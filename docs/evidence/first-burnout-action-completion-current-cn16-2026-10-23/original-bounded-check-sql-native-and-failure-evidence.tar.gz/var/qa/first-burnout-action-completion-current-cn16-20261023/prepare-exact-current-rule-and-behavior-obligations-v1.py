from pathlib import Path
import collections,copy,datetime,gzip,hashlib,json,re,subprocess,xml.etree.ElementTree as E
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
m=load(root/'docs/audit/current-manifest.json');rules=load(root/m['inputs']['rules']['path']);corpus=load(root/m['inputs']['corpus']['path']);cards=load(root/m['inputs']['cards']['path'])
ri={r['id']:r for r in rules['records']};ci={r['id']:r for r in cards['records']}
core=next(d for d in corpus['documents']if d['id']=='DOC-01');assert core['sha256']=='d6fd7140f106f9b5b3dc0d5817fd040110fe870a6da9ee335ba7f4f70f892d11'
anchors={'303.1','319.5','320','320.1','321','321.1','322','323.1','323.4','414.4.c','432.1','432.2','432.2.a','432.2.b','432.2.c','432.2.d','432.3','432.3.a','432.3.b','432.3.c','432.3.c.1','474','474.1','474.2'}
records=[]
for r in corpus['records']:
 if r['document']!='DOC-01'or not(anchors&set(r.get('clauseAnchors',[]))):continue
 identity='CN-'+core['sha256'][:16]+'-'+r['id'].split('-',2)[2]
 assert ri[identity]['sourceRecord']==r['id']and ri[identity]['textHash']==hashlib.sha256(json.dumps(r['text'],ensure_ascii=False,sort_keys=True).encode()).hexdigest()
 records.append(dict(existingCanonicalId=identity,sourceRecord=copy.deepcopy(r),originalLedgerTextHash=ri[identity]['textHash']))
assert anchors <= {a for r in records for a in r['sourceRecord']['clauseAnchors']}
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};doc=E.parse(w/'final-parent-boundaries-and-nine-original-games-focus-v7/focus/results.trx');defs={d.get('id'):d.find('t:TestMethod',ns).attrib for d in doc.findall('.//t:UnitTest',ns)};cases=[]
refs=[r['existingCanonicalId']for r in records]
for r in doc.findall('.//t:UnitTestResult',ns):
 d=defs[r.get('testId')];method=d['className']+'.'+d['name'];name=r.get('testName')
 if '.BurnoutActionCompletionTests.'not in method and not method.endswith('.InsightRepeatTests.AFirstRecyclableBurnoutWaitsForEveryPaidEchoExecutionBeforeNormalVictory'):continue
 assert r.get('outcome')=='Passed'
 subjects=['OGN-083/298']
 if 'AConquestBelow'in method or 'AFirstRecyclableBurnoutCompletesTheOriginalDraw'in method:subjects=['OGN-296/298','OGN-280/298','SFD-125/221']
 elif 'ParentsRequiredDiscard'in method:subjects=['UNL-080/219','OGN-083/298']
 elif 'BothPlayersFirstBurnouts'in method:subjects=['OGN-071/298']
 elif '.InsightRepeatTests.'in method:subjects=['VEN-056']
 assert all(s in ci for s in subjects)
 cases.append(dict(id='CN16-FIRST-BURNOUT-'+hashlib.sha256(name.encode()).hexdigest()[:16].upper(),actualExecutedCase=name,method=method,exactPrintingSubjects=subjects,existingCanonicalRuleIds=refs,semanticScope='BOUNDED_FIRST_BURNOUT_ACTION_AND_PARENT_COMPLETION',wholePrintingCertified=False,printedModeOwnershipNotCertified='BothPlayersFirstBurnouts'in method,grantedEchoContextNotPrintedInherentEcho='.InsightRepeatTests.'in method))
assert len(cases)==12 and len({c['method']for c in cases})==7
calls=[]
for path in sorted((root/'src/Riftbound.Engine').glob('CoreRuleEngine*.cs')):
 s=path.read_text()
 for found in re.finditer(r'\bApplyDrawToPlayer\s*\(',s):
  line=s.count('\n',0,found.start())+1
  if re.search(r'private static DrawApplicationResult\s+$',s[max(0,found.start()-80):found.start()]):continue
  start=s.index('(',found.start());depth=1;end=start+1
  while depth:
   if s[end]=='(':depth+=1
   elif s[end]==')':depth-=1
   end+=1
  statement=s[found.start():end]
  classification='DEFERRED_PARENT'if 'deferNormalVictory: true'in statement else 'MIXED_DIRECT_AND_PARENT_CALLER_SCOPE'if 'deferNormalVictory: deferNormalVictory'in statement else 'DIRECT_DEFAULT_BOUNDARY'
  calls.append(dict(path=path.relative_to(root).as_posix(),sha256=sha(path),line=line,originalStatement=statement,classification=classification,semanticConsumerAndExactPrintingBranchMapping='OPEN_REQUIRES_EXACT_CURRENT_BRANCH_REVIEW',passingAdjacentTestsNotWholeCallerCertification=True))
assert len(calls)==35 and collections.Counter(c['classification']for c in calls)=={'DEFERRED_PARENT':26,'MIXED_DIRECT_AND_PARENT_CALLER_SCOPE':2,'DIRECT_DEFAULT_BOUNDARY':7}
output=dict(atUtc=now(),region='CN',language='zh-CN',applicableAsOf='2026-10-23',adoptedCoreEffectiveDate='2026-10-16',corePublishedDate='2026-10-10',coreSource=core,coreEffectiveDateExplicitlyFromAdoptedScopeNotNullCorpusMetadata=True,issue='https://github.com/DDDHL0704/riftbound/issues/98',sourceRuleRecords=records,cases=cases,callSites=calls,newExecutedCases=12,newMethods=7,sourceUniverse1740And14293AndSevenDeltasRetained=True,additionalOpenSharedCallerMappingAndUnprovenInnerCleanupCandidates=True,semanticCoverageCertified=False)
with(w/'twelve-exact-executed-branches-and-35-static-caller-obligations-v1.json').open('x')as f:json.dump(output,f,ensure_ascii=False,indent=2)
with(w/'all-original85-complete-contexts-before-first-burnout-input-refresh-v1.json.gz').open('xb')as f:f.write(gzip.compress(json.dumps(m['reviewContexts'],ensure_ascii=False,indent=2).encode(),mtime=0))
changes=[]
for name,context in m['reviewContexts'].items():
 rows=[dict(path=r['path'],before=r['sha256'],after=sha(root/r['path']))for r in context['implementation']if sha(root/r['path'])!=r['sha256']]
 if rows:changes.append(dict(id=name,changes=rows))
with(w/'current85-context-input-change-plan-before-publication-v1.json').open('x')as f:json.dump(dict(atUtc=now(),manifestSha256=sha(root/'docs/audit/current-manifest.json'),reviewsSha256=m['inputs']['reviews']['sha256'],changes=changes,allCompleteOldContextsRetained=True,noSemanticReviewPromotion=True),f,indent=2)
print(json.dumps(dict(exactCurrentRuleRecords=len(records),newCases=len(cases),newMethods=7,currentStaticCallerCounts=dict(collections.Counter(c['classification']for c in calls)),existingContextsNeedingInputPinRefresh=len(changes),otherCompleteContextsUnchanged=85-len(changes))))
