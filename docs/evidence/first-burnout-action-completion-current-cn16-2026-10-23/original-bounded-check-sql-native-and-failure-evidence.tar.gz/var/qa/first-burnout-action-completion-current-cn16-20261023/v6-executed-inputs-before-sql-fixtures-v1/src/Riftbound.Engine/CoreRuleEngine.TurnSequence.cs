using Riftbound.Contracts;

namespace Riftbound.Engine;

// Captured when the ability triggers. Its controller and battlefield do not follow
// later source control changes, movement, or departure (CN 390–392).
public sealed record HeldTriggerContext(string CardNo, string BattlefieldObjectId, string Kind,
    int Amount = 0, long SourceGeneration = 0,
    [property: System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull)]
    int? RequiredExactOtherFriendlyBattlefieldUnits = null,
    [property: System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull)]
    RuleTextInstanceBinding? Origin = null,
    [property: System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull)]
    string? RuleTextInstanceId = null);
public sealed record DelayedResourceGain(string Id, string ControllerId, string SourceObjectId,
    string SourceCardNo, string BattlefieldObjectId, int DueTurn, int Power);

public sealed partial class CoreRuleEngine
{
    private static ResolutionResult ResolveTurnStart(MatchState state, bool advanceTick = true)
    {
        var next = state with { Tick = state.Tick + (advanceTick ? 1 : 0), Phase = MatchPhases.TurnStart,
            TurnStartStep = state.TurnStartStep ?? "READY", ActivePlayerId = state.TurnPlayerId };
        return new(true, null, next, [new("TURN_START_BEGAN", "开始回合流程",
            new Dictionary<string, object?> { ["turnPlayerId"] = state.TurnPlayerId })],
            ResolutionResult.BuildSnapshots(next), BuildCorePrompts(next));
    }

    private static bool TurnSequenceBlocked(MatchState state) => state.StackItems.Count > 0
        || state.TriggerQueue.Any(IsImmediateTrigger) || state.PendingPayment is not null
        || state.PendingHandChoice is not null || state.PendingCardChoice is not null || state.PendingEffectPlay is not null;

    private static ResolutionResult AdvanceTurnStartSequence(ResolutionResult result)
    {
        if (!result.Accepted) return result;
        var state = result.State;
        var events = result.Events.ToList();
        while (state.Status == MatchStatuses.InProgress && state.TurnStartStep is not null && !TurnSequenceBlocked(state))
        {
            var stepStart = state;
            var stepEventIndex = events.Count;
            var player = state.TurnPlayerId;
            var zones = NormalizeZonesForSeats(state);
            var cards = state.CardObjects.ToDictionary(e => e.Key, e => e.Value, StringComparer.Ordinal);
            switch (state.TurnStartStep)
            {
                case "READY":
                    events.AddRange(ReadyTurnPlayerObjectsAtTurnStart(zones, cards, player).Events);
                    state = state with { CardObjects = cards, TurnStartStep = "START" };
                    break;
                case "START":
                    state = state with { PlayerScores = NormalizeScoresForSeats(state), TurnStartStep = "SCORE" };
                    state = QueueEphemeralStartAbilities(state, events);
                    state = QueueBattlefieldStartAbilities(state, events);
                    state = QueueBeginningDrawAbilities(state, events);
                    state = QueueBeginningRecycleAbilities(state, events);
                    break;
                case "SCORE":
                    var firstScore = ApplyBattlefieldFirstTurnScore(state, player);
                    events.AddRange(firstScore.Events);
                    state = state with { PlayerScores = firstScore.PlayerScores, WinnerPlayerId = firstScore.WinnerPlayerId,
                        UntilEndOfTurnEffects = firstScore.UntilEndOfTurnEffects };
                    if (state.WinnerPlayerId is null)
                    {
                        // Capture before scoring changes anything. Prevented/replaced scoring still causes Hold.
                        var heldFields = zones.Values.SelectMany(z => z.Battlefields).Distinct(StringComparer.Ordinal)
                            .Where(id => cards.TryGetValue(id, out var card) && IsBattlefieldCardObject(card)
                                && EffectiveFieldControllerId(zones, id, card) == player
                                && !BattlefieldScoredThisTurn(state.UntilEndOfTurnEffects, id, player)).ToArray();
                        var heldScore = ApplyBattlefieldHeldScoresAtTurnStart(state, zones, cards, player);
                        events.AddRange(heldScore.Events);
                        state = state with { PlayerScores = heldScore.PlayerScores, WinnerPlayerId = heldScore.WinnerPlayerId,
                            UntilEndOfTurnEffects = heldScore.UntilEndOfTurnEffects, PlayerZones = zones, CardObjects = cards };
                        if (state.WinnerPlayerId is null)
                            state = QueueHeldAbilities(state, heldFields, events);
                    }
                    state = state with { TurnStartStep = "CHANNEL", Status = state.WinnerPlayerId is null ? state.Status : MatchStatuses.Finished };
                    break;
                case "CHANNEL":
                    var own = zones[player];
                    var runes = TakeControlledRuneDeckPrefix(cards, player, own.RuneDeck, RuneCallCount(state));
                    zones[player] = own with { RuneDeck = own.RuneDeck.Skip(runes.Length).ToArray(), Base = own.Base.Concat(runes).ToArray() };
                    var locations = ReconcileObjectLocations(state.ObjectLocations, zones);
                    foreach (var id in runes) locations[id] = new(player, MoveUnitBaseZone);
                    events.Add(new("RUNES_CALLED", $"召出 {runes.Length} 张符文", new Dictionary<string, object?> { ["playerId"] = player, ["count"] = runes.Length }));
                    state = state with { PlayerZones = zones, ObjectLocations = locations, TurnStartStep = "DRAW" };
                    break;
                case "DRAW":
                    var draw = DrawCards(state, player, zones[player], 1);
                    zones[player] = zones[player] with { MainDeck = draw.MainDeck, Graveyard = draw.Graveyard,
                        Hand = zones[player].Hand.Concat(draw.DrawnCards).ToArray() };
                    events.AddRange(BuildTurnStartEvents(state, 0, draw, []).Where(e => e.Kind is not
                        ("TURN_START_BEGAN" or "RUNES_CALLED" or "RUNE_POOL_CLEARED" or "MAIN_PHASE_BEGAN")));
                    state = state with { PlayerZones = zones, PlayerScores = draw.PlayerScores, RngCursor = draw.RngCursor,
                        WinnerPlayerId = draw.WinnerPlayerId, Status = draw.WinnerPlayerId is null ? state.Status : MatchStatuses.Finished,
                        ObjectLocations = ReconcileObjectLocations(state.ObjectLocations, zones), TurnStartStep = "MAIN" };
                    break;
                case "MAIN":
                    var pools = ClearRunePools(state).ToDictionary(e => e.Key, e => e.Value, StringComparer.Ordinal);
                    events.Add(new("RUNE_POOL_CLEARED", "所有玩家的符文池已清空", new Dictionary<string, object?> { ["playerIds"] = state.Seats.Keys.Order().ToArray() }));
                    events.Add(new("MAIN_PHASE_BEGAN", "进入主阶段", new Dictionary<string, object?> { ["turnPlayerId"] = player }));
                    var due = state.DelayedResourceGains.Where(d => d.ControllerId == player && d.DueTurn <= state.TurnNumber).ToArray();
                    foreach (var delayed in due)
                    {
                        var pool = pools.GetValueOrDefault(delayed.ControllerId, RunePool.Empty);
                        pools[delayed.ControllerId] = pool with { Power = pool.Power + delayed.Power };
                        events.Add(new("POWER_GAINED", "延迟资源技能获得符能", new Dictionary<string, object?> {
                            ["playerId"] = delayed.ControllerId, ["sourceObjectId"] = delayed.SourceObjectId,
                            ["sourceCardNo"] = delayed.SourceCardNo, ["triggerId"] = delayed.Id,
                            ["generatedPower"] = delayed.Power, ["power"] = delayed.Power, ["resourceLifecycle"] = "rune-pool" }));
                    }
                    state = state with { RunePools = pools, DelayedResourceGains = state.DelayedResourceGains.Except(due).ToArray(),
TurnStartStep = null, Phase = MatchPhases.Main,
                        TimingState = TimingStates.NeutralOpen, ActivePlayerId = player, PriorityPlayerId = null,
                        PassedPriorityPlayerIds = [], FocusPlayerId = null };
                    var advance = AdvancePendingBattlefieldTasksAfterStateChange(state, player, result.State);
                    state = advance.State; events.AddRange(advance.Events);
                    break;
                default: throw new InvalidOperationException($"Unknown turn-start continuation: {state.TurnStartStep}");
            }
            var collected = RecordDeathObservers(stepStart, RecordDrawTriggers(stepStart, QueueBattlefieldReturnTriggers(new(true, null, state, events.Skip(stepEventIndex).ToArray(), ResolutionResult.BuildSnapshots(state), BuildCorePrompts(state)))));
            events.RemoveRange(stepEventIndex, events.Count - stepEventIndex); events.AddRange(collected.Events);
            var published = PrepareTriggerConfirmation(PublishPendingTriggers(collected with { Events = [] }));
            state = published.State; events.AddRange(published.Events);
        }
        return result with { State = state, Events = events, Snapshots = ResolutionResult.BuildSnapshots(state), Prompts = BuildCorePrompts(state) };
    }
}
