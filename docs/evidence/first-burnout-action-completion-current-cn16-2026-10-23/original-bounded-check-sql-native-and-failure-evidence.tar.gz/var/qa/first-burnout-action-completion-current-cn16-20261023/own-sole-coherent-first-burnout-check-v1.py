from pathlib import Path
import collections,datetime,gzip,hashlib,json,os,resource,subprocess,xml.etree.ElementTree as E
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def rows(path):
 doc=E.parse(path);defs={d.get('id'):d.find('t:TestMethod',ns).attrib for d in doc.findall('.//t:UnitTest',ns)}
 return [dict(name=r.get('testName'),method=defs[r.get('testId')]['className']+'.'+defs[r.get('testId')]['name'],outcome=r.get('outcome'))for r in doc.findall('.//t:UnitTestResult',ns)]
old_home=root/'var/qa/final-conquest-score-current-cn16-20261023'
baseline=rows(old_home/'sole-check-v1/check/results.trx');assert len(baseline)==13658 and len({r['method']for r in baseline})==7615 and all(r['outcome']=='Passed'for r in baseline)
focus=rows(w/'final-parent-boundaries-and-nine-original-games-focus-v7/focus/results.trx');assert len(focus)==402 and len({r['method']for r in focus})==209 and all(r['outcome']=='Passed'for r in focus)
new=[r for r in focus if '.BurnoutActionCompletionTests.'in r['method']or r['method'].endswith('.InsightRepeatTests.AFirstRecyclableBurnoutWaitsForEveryPaidEchoExecutionBeforeNormalVictory')];assert len(new)==12 and len({r['method']for r in new})==7
full=sorted({r['method']for r in focus if '.FullGameEndToEndTests.'in r['method']});assert len(full)==9
independent=load(w/'independent-six-burnout-sql-originals-readonly-owner-terminal-v1.json');assert independent['status'].startswith('PASS_INDEPENDENT_SIX_ORIGINAL_BURNOUT_SQL_ROOMS37_PREFIXES68_EACH_PRIVATE_ONE_COORDINATED_REFUSAL_READONLY')
assert independent['exitCode']==0 and independent['all442AuditSevenTablesExact']and independent['all127NativeSevenTablesExact']and independent['ownPostgresSmartStopped']
# Root Web work is owned by another user task. This local rule check pins all actual .NET/rule/test/tool inputs; fixed full will include the actual combined commit and all unknown paths.
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z','--','src','tests','scripts','data','clients/godot','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json'],cwd=root).split(b'\0')
pins={p.decode():dict(sha256=sha(root/p.decode()),mode=oct((root/p.decode()).stat().st_mode&0o777))for p in paths if p and(root/p.decode()).is_file()}
original=json.loads(gzip.decompress((w/'all-existing-conformance-files-before-first-burnout-test-v1.json.gz').read_bytes()))
# The original snapshot's shape is checked below; preserve every file except the one explicitly source-calibrated original Insight assertion.
if 'files'in original:original=original['files']
if 'allExistingConformanceFiles'in original:original=original['allExistingConformanceFiles']
assert isinstance(original,dict)and len(original)==1822
for p,h in original.items():
 expected=h['sha256']if isinstance(h,dict)else h
 assert (root/p).is_file()
 if p!='tests/Riftbound.ConformanceTests/InsightRepeatTests.cs':assert sha(root/p)==expected,p
old_start=json.loads(gzip.decompress((old_home/'sole-check-start-inputs-v1.json.gz').read_bytes()));full_sources=old_start['allNineFullGameSourceHashes'];assert len(full_sources)==9 and all(sha(root/p)==h for p,h in full_sources.items())
prior_sql=json.loads(subprocess.check_output(['git','show',base+':tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'],cwd=root));sql=load(root/'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json');assert len(prior_sql['cases'])==63 and sql['cases'][:63]==prior_sql['cases']and sql['cases'][63:]==[dict(id='burnout-action-completion',sourceType='BurnoutActionCompletionSqlAcceptance')]
runtime={}
for label,folder in [('Conformance',root/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0'),('Native',root/'clients/godot/.godot/mono/temp/bin/Debug')]:
 runtime[label]={str(p.relative_to(root)):sha(p)for p in folder.rglob('*')if p.is_file()and '/net10.0/var/qa/'not in str(p)}
folder=root/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0'
measurement_command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(folder/'Riftbound.ConformanceTests.deps.json'),'--runtimeconfig',str(folder/'Riftbound.ConformanceTests.runtimeconfig.json'),str(root/'var/qa/fixed267ab-early-native-20261022/executed-own-native-readers-and-drivers-v1/IndependentFixed267abControlledLabV1.dll'),'--loaded-inputs']
measurement=json.loads(subprocess.check_output(measurement_command,cwd=folder,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0')))
assert Path(measurement['baseDirectory'])==folder and len(measurement['assemblies'])==4
for a in measurement['assemblies']:assert Path(a['path'])==folder/(a['name']+'.dll')and sha(Path(a['path']))==a['sha256']and a['mvid']
assert measurement['actualRuleInputs']==independent['actualRuleInputs']
start=dict(atUtc=now(),baseCommit=base,sourceHashesAndModes=pins,all1822OriginalConformanceFiles=original,allOriginalFilesRetainedExceptDocumentedInsightExpectationCalibration=True,allNineFullGameSourceHashes=full_sources,all143OriginalCompleteMethods151Cases110Pairs11DecksSeed424242AndVictoryReplayAssertionsRetained=True,actualFourLoadedAssemblies=measurement,actualRuntimeInputs=runtime,baselineCaseNames=sorted(r['name']for r in baseline),newCaseNames=sorted(r['name']for r in new),exactNineEarlyFullMethods=full,allOriginal63SqlObjectsAndOrderRetained=True,expectedCheckCases=13670,expectedCheckMethods=7622,expectedDiscoveryMethods=7763,expectedNextFixedFullCases=13819,newCases=12,newMethods=7,excludedForeignWebScopeExplained=True,noDatabaseConnectionForThisCheck=True,wholeCardOrGoalCertified=False)
manifest=w/'sole-check-start-inputs-v1.json.gz';assert not manifest.exists();manifest.write_bytes(gzip.compress(json.dumps(start,indent=2).encode(),mtime=0))
output=w/'sole-check-v1';assert not output.exists();args=['python3','scripts/test-rules.py','check','--output',str(output)];env=dict(os.environ);env.pop('ConnectionStrings__Riftbound',None)
proof=dict(status='RUNNING_SOLE_COHERENT_FIRST_BURNOUT_ACTION_COMPLETION_CHECK',startedAtUtc=now(),baseCommit=base,actualCommand=args,sourceInputCount=len(pins),runtimeInputCounts={k:len(v)for k,v in runtime.items()},startManifestSha256=sha(manifest));print('SOLE_CHECK_STARTED_EXPECT13670_CASES7622_METHODS',flush=True)
try:
 with(w/'sole-check-original-console-v1.log').open('xb')as log:
  process=subprocess.Popen(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  with(w/'sole-check-running-owner-v1.json').open('x')as f:json.dump(dict(proof,ownerPid=os.getpid(),runnerPid=process.pid),f,indent=2)
  power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(process.pid)]);proof['exitCode']=process.wait();power.wait(timeout=10)
 if proof['exitCode']==0:
  summary=load(output/'summary.json');plan=load(output/'plan.json');actual=rows(output/'check/results.trx')
  assert summary['status']=='PASSED'and len(actual)==summary['total']==13670
  assert collections.Counter(r['name']for r in actual)==collections.Counter(r['name']for r in baseline)+collections.Counter(r['name']for r in new)
  assert all(r['outcome']=='Passed'for r in actual)and plan['discoveredMethods']==7763 and len(plan['shards'][0]['methods'])==7622
  proof.update(status='PASS_SOLE_COHERENT_FIRST_BURNOUT_ACTION_COMPLETION_CHECK13670_CASES7622_METHODS',summary=summary,allOriginal13658CheckCases7615MethodsRetainedPlus12Cases7MethodsOnly=True,trxSha256=sha(output/'check/results.trx'))
 else:proof['status']='FAILED_SOLE_COHERENT_FIRST_BURNOUT_CHECK_ORIGINALS_RETAINED'
finally:
 proof.update(finishedAtUtc=now(),allScopedSourceHashesAndModesStable=all(sha(root/p)==v['sha256']and oct((root/p).stat().st_mode&0o777)==v['mode']for p,v in pins.items()),allCapturedConformanceAndNativeRuntimeInputsStable=all(sha(root/p)==h for group in runtime.values()for p,h in group.items()))
 with(w/'sole-check-owner-terminal-v1.json').open('x')as f:json.dump(proof,f,indent=2)
print(proof['status'],flush=True);assert proof['exitCode']==0 and proof['allScopedSourceHashesAndModesStable']and proof['allCapturedConformanceAndNativeRuntimeInputsStable']
