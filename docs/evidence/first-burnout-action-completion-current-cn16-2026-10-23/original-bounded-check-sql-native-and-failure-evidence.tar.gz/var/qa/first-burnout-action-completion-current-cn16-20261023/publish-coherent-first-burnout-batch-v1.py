from pathlib import Path
import collections,copy,datetime,gzip,hashlib,io,json,re,subprocess,tarfile
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;n=root/'var/qa/fixedf0f4efc5-early-native-20261023'
identity='first-burnout-action-completion-current-cn16-2026-10-23';ev=root/'docs/evidence'/identity;stage=w/'publication-evidence-staged-v1';document='docs/FIRST_BURNOUT_ACTION_COMPLETION_CURRENT_CN16_AUDIT_2026-10-23.md'
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p,x):
 with p.open('x')as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write('\n')
def pin(p,role=None):
 target=ev/p.relative_to(stage)if stage in p.parents else p
 x=dict(path=target.relative_to(root).as_posix(),sha256=sha(p))
 if role:x['role']=role
 return x
check=load(w/'sole-check-owner-terminal-v1.json');assert check['status']=='PASS_SOLE_COHERENT_FIRST_BURNOUT_ACTION_COMPLETION_CHECK13670_CASES7622_METHODS'
assert check['exitCode']==0 and check['allScopedSourceHashesAndModesStable']and check['allCapturedConformanceAndNativeRuntimeInputsStable']
start=json.loads(gzip.decompress((w/'sole-check-start-inputs-v1.json.gz').read_bytes()));assert len(start['sourceHashesAndModes'])==3383
assert all(sha(root/p)==v['sha256']and oct((root/p).stat().st_mode&0o777)==v['mode']for p,v in start['sourceHashesAndModes'].items())
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert base==start['baseCommit']
prep=load(w/'twelve-exact-executed-branches-and-35-static-caller-obligations-v1.json');assert len(prep['cases'])==12 and len(prep['sourceRuleRecords'])==22 and len(prep['callSites'])==35
focus=load(w/'final-parent-boundaries-and-nine-original-games-focus-v7/summary.json');assert focus['status']=='PASSED'and focus['total']==402 and len(start['exactNineEarlyFullMethods'])==9
sql=load(w/'independent-six-burnout-sql-originals-readonly-owner-terminal-v1.json');assert sql['status'].startswith('PASS_INDEPENDENT_SIX_ORIGINAL_BURNOUT_SQL_ROOMS37_PREFIXES68_EACH_PRIVATE_ONE_COORDINATED_REFUSAL_READONLY')
assert sql['totals']==dict(commands=37,events=87,authority=37,snapshots=68,prompts=68,prefixReplays=37,actualForgeryRefusals=1)
assert sql['all442AuditSevenTablesExact']and sql['all127NativeSevenTablesExact']and sql['ownPostgresSmartStopped']and sql['actualRuleInputs']==start['actualFourLoadedAssemblies']['actualRuleInputs']
native=load(n/'fixedf0-nine-original-rooms-early-native-bounded-closure-v1.json');assert native['commands']==122 and native['events']==614 and native['privateSnapshots']==native['privatePrompts']==231 and native['cleanActualSdkProductionControlSubmissions']==27
assert native['actualReleaseRuleInputs']!=sql['actualRuleInputs']
assert 'Ran 90 tests' in (w/'all-current-python-tools90-v3.log').read_text()and (w/'all-current-python-tools90-v3.log').read_text().rstrip().endswith('OK')
mp=root/'docs/audit/current-manifest.json';m=load(mp);old=copy.deepcopy(m);rp=root/m['inputs']['reviews']['path'];reviews=load(rp);old_reviews=copy.deepcopy(reviews);binding=load(w/'current85-context-input-change-plan-before-publication-v1.json')
assert sha(mp)==binding['manifestSha256']and sha(rp)==binding['reviewsSha256']and len(binding['changes'])==68
assert len(reviews['reviews'])==170 and len(m['reviewContexts'])==85 and len(m['acceptanceGates'])==271 and len(m['laterSourceDeltas'])==7
assert json.loads(gzip.decompress((w/'all-original85-complete-contexts-before-first-burnout-input-refresh-v1.json.gz').read_bytes()))==m['reviewContexts']
old_status=(root/'docs/PROJECT_STATUS.md').read_text();assert old_status.startswith('# 当前项目状态\n\n')
assert not stage.exists()and not ev.exists()and not(root/document).exists()
# These independently validated source/tool files remain the peer's exact final blobs.
peer=load(w/'six-reviewed-peer-commits-integrated-exact-final-tree-v1.json');assert len(peer['paths'])==25
assert all(sha(root/r['path'])==r['peerFinalSha256']for r in peer['paths'])
write(w/'final-test-source-and-runtime-retention-v1.json',dict(atUtc=now(),baseCommit=base,newCases=12,newMethods=7,focusCases=402,focusMethods=209,actualNineOriginalFullMethods=start['exactNineEarlyFullMethods'],soleCheckCases=13670,soleCheckMethods=7622,allOriginal13658Cases7615MethodsRetained=True,originalConformanceFiles=1822,all1822FilesPresent1821ByteExactAndOneDocumentedInsightSourceCalibration=True,all143OriginalCompleteMethods151Cases110Pairs11DecksSeed424242AndVictoryReplayAssertionsRetained=True,sourceInputCount=3383,allScopedSourceHashesAndModesStable=True,allOriginal63SqlCaseObjectsAndOrderRetainedPlusOne=True,actualDebugRuleInputs=sql['actualRuleInputs'],nextFixedFullExpected=dict(cases=13819,methods=7763,sqlCases=64),noSerializedPendingWinFlagOrOldMatchMigrationOrDsl=True,wholePrintingCertified=False,goalComplete=False))
copies={
 'sole-check-owner-terminal.json':w/'sole-check-owner-terminal-v1.json','sole-check-start-inputs.json.gz':w/'sole-check-start-inputs-v1.json.gz',
 'exact-rule-and-35-caller-branch-obligations.json':w/'twelve-exact-executed-branches-and-35-static-caller-obligations-v1.json',
 'current-core-and-directory-acquisition.json':w/'current-official-core-and-directory-acquisition-v1.json','original-misused-get-directory.json.gz':w/'current-rule-directory-original-v1.json.gz',
 'current-correct-post-directory.json.gz':w/'current-rule-directory-original-correct-post-v2.json.gz','exact-directory-row-comparison.json':w/'current-rule-directory-exact-row-comparison-v2.json',
 'four-current-full-rows-exact-to-retained1504.json':w/'four-current-full-official-rows-exact-comparison-to-retained1504-v1.json',
 'all-original85-complete-contexts.json.gz':w/'all-original85-complete-contexts-before-first-burnout-input-refresh-v1.json.gz',
 'test-source-and-runtime-retention.json':w/'final-test-source-and-runtime-retention-v1.json',
 'current-sql-six-originals-owner.json':w/'real-sql-six-burnout-original-rooms-owner-terminal-v2.json','independent-sql-six-originals-owner.json':w/'independent-six-burnout-sql-originals-readonly-owner-terminal-v1.json','independent-sql-six-originals-result.json':w/'independent-six-burnout-sql-originals-readonly-result-v1.json',
 'six-peer-commits-final-blob-integration.json':w/'six-reviewed-peer-commits-integrated-exact-final-tree-v1.json','five-peer-archives-independent-byte-verification.json':w/'all-five-integrated-peer-archives-independent-byte-verification-v1.json',
 'preceding-fixed-f0-nine-rooms-bounded-native.json':n/'fixedf0-nine-original-rooms-early-native-bounded-closure-v1.json','preceding-fixed-f0-private-row-count-scope-clarification.json':n/'private-history-per-table-across-viewers-count-clarification-v1.json','preceding-fixed-f0-complete-source-composition.json':n/'frozen-fixedf0f4efc5-native-composition-with-complete-sdk-resources-v3.json','preceding-fixed-f0-retired-only-old-apps-and-installers.json':n/'preceding-f248-app-and-installer-retirement-v1.json',
 'preceding-fixed-f248-later-entire-full-independent.json':root/'var/qa/fixedf248d777-early-native-20261023/cif248d777-entire-full-independent-verification-v1.json',
}
# Retain the actual preceding CI observation, never promote its pending jobs.
ci_root=root/'var/qa/fixedf0-ci-readonly-20261023';observation=sorted((ci_root/'observations').glob('*/run-original.json'))[-1];ci=load(observation);assert ci.get('head_sha',ci.get('headSha'))==native['fixedCommit']
ci_receipt=load(observation.parent/'receipt.json');write(w/'preceding-f0-actual-ci-observation-at-publication-v1.json',dict(atUtc=now(),originalObservationPath=str(observation.relative_to(root)),originalRunJsonSha256=sha(observation),actualRun=ci,originalObservationReceipt=ci_receipt,completeIndependentFullNotInferred=True))
copies['preceding-fixed-f0-actual-ci-observation.json']=w/'preceding-f0-actual-ci-observation-at-publication-v1.json'
stage.mkdir()
for name,p in copies.items():(stage/name).write_bytes(p.read_bytes())
paths={p for folder in (w,n)for p in folder.rglob('*')if p.is_file()and stage not in p.parents}
def generated(p):
 return any(part in {'obj','__pycache__','.godot','native-current','publication-evidence-staged-v1'}or part.endswith('.app')or part.startswith('fixed-source-inputs')for part in p.parts)
def private_name(p):return p.suffix=='.env'or p.name.startswith('session-')or any('profile'in part.lower()for part in p.parts)
def own_module(p):return p.suffix in {'.dll','.pdb'}and(p.name.startswith(('Riftbound.','Independent','FirstBurnout'))or 'Native'in p.name)
def framework(p):return ('bin'in p.parts or any('runtime-v'in part for part in p.parts))and not own_module(p)
secrets=set()
def collect(v):
 if isinstance(v,dict):
  for k,x in v.items():
   if k.lower().replace('_','')in {'playerkey','reconnecttoken','accesstoken','authorization','sessiontoken','connectiontoken'}and isinstance(x,str)and len(x)>=16:secrets.add(x.encode())
   else:collect(x)
 elif isinstance(v,list):
  for x in v:collect(x)
 elif isinstance(v,str)and v.lstrip().startswith(('{','[')):
  try:collect(json.loads(v))
  except(ValueError,RecursionError):pass
for p in paths:
 if generated(p)or framework(p):continue
 if p.name.endswith(('.json','.json.gz','.ndjson','.ndjson.gz','.jsonl.gz')):
  try:
   raw=gzip.decompress(p.read_bytes())if p.suffix=='.gz'else p.read_bytes()
   if '.ndjson'in p.name or '.jsonl'in p.name:
    for line in raw.decode().splitlines():
     if line.strip():collect(json.loads(line))
   else:collect(json.loads(raw))
  except(OSError,ValueError,UnicodeDecodeError):pass
for name in copies:
 raw=(stage/name).read_bytes();raw=gzip.decompress(raw)if name.endswith('.gz')else raw
 assert not any(s in raw for s in secrets),('Private value in readable evidence',name)
canonical={sha(stage/name):dict(externalEvidencePath=pin(stage/name)['path'])for name in copies};mapping=[];members={};excluded=[]
for p in sorted(paths):
 name=p.relative_to(root).as_posix();reason='GENERATED_APP_INSTALLER_SDK_COW_SOURCE_OR_FRAMEWORK_NOT_DUPLICATED'if generated(p)or framework(p)else None
 if private_name(p):reason='PRIVATE_QA_SESSION_LOCAL_ONLY'
 if p.suffix in {'.zip','.pdf'}:reason='EXISTING_INSTALLER_OR_OFFICIAL_SOURCE_NOT_DUPLICATED'
 if reason:excluded.append(dict(path=name,bytes=p.stat().st_size,reason=reason));continue
 raw=p.read_bytes()
 try:inspect=gzip.decompress(raw)if p.suffix=='.gz'else raw
 except(OSError,EOFError):inspect=raw
 digest=hashlib.sha256(raw).hexdigest()
 if any(secret in inspect for secret in secrets)or re.search(rb'[?&](?:access_token|sig|token)=[A-Za-z0-9_%+/=-]{16,}',inspect):
  excluded.append(dict(path=name,bytes=len(raw),sha256=digest,reason='PRIVATE_AUTH_OR_SIGNED_DOWNLOAD_VALUES_LOCAL_ONLY'));continue
 target=canonical.get(digest)
 if target is None:target=dict(archiveMember=name);canonical[digest]=target;members[name]=p
 mapping.append(dict(path=name,bytes=len(raw),sha256=digest,**target))
archive=stage/'original-bounded-check-sql-native-and-failure-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9)as bundle:
 for name,p in sorted(members.items()):
  raw=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(raw);info.mode=p.stat().st_mode&0o777;info.mtime=0;bundle.addfile(info,io.BytesIO(raw))
assert archive.stat().st_size<80_000_000
with tarfile.open(archive,'r:gz')as bundle:
 assert set(bundle.getnames())==set(members)
 for item in mapping:
  target=stage/Path(item['externalEvidencePath']).relative_to(ev.relative_to(root))if 'externalEvidencePath'in item else None
  raw=target.read_bytes()if target else bundle.extractfile(item['archiveMember']).read();assert len(raw)==item['bytes']and hashlib.sha256(raw).hexdigest()==item['sha256']
write(stage/'archive-map.json',dict(atUtc=now(),archive=pin(archive),originalPathsWithExactCanonicalPayload=mapping,localOnlyExclusions=excluded,allMemberBytesHashesClosedSetVerified=True,equalPayloadStoredOnceIncludingReadableCopies=True,originalAuthValuesStayLocal=True,noNewAppInstallerSdkDatabaseOrWorktree=True))
implementation_paths=sorted({c['path']for c in prep['callSites']}|{'src/Riftbound.Engine/CoreRuleEngine.TurnSequence.cs','src/Riftbound.Engine/MatchSession.cs','src/Riftbound.Engine/MatchSession.BurnoutActionScenario.cs'})
implementation=[pin(root/p,'implementation')for p in implementation_paths]
verification=[pin(root/p,'verification-source')for p in ['tests/Riftbound.ConformanceTests/BurnoutActionCompletionTests.cs','tests/Riftbound.ConformanceTests/InsightRepeatTests.cs','tests/Riftbound.PostgresAcceptance/BurnoutActionCompletionSqlAcceptance.cs','tests/Riftbound.PostgresAcceptance/Program.cs','tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json','scripts/tests/test_sql_ci_gate.py']]
subjects=sorted({s for c in prep['cases']for s in c['exactPrintingSubjects']});rule_refs=[r['existingCanonicalId']for r in prep['sourceRuleRecords']]
scope='CN16 first recyclable burnout completes its original draw and suspended parent; subsequent burnout retains immediate victory; ordinary score cleanup after completed top parent precedes lower chain response. Exact Hwei mandatory discard, printed draw2, existing preselected Portal CARDS tie and runtime-granted paid Insight Echo only; consumer mapping and unproven inner cleanup remain OPEN.'
sm=dict(schemaVersion=1,id=identity,atUtc=now(),baseCommit=base,region='CN',language='zh-CN',applicableAsOf='2026-10-23',adoptedCoreEffectiveDate='2026-10-16',corePublishedDate='2026-10-10',coreSha256=prep['coreSource']['sha256'],issue=prep['issue'],scope=scope,exactPrintings=subjects,individualPrintingPublicationAndEffectiveDatesRemainUnknown=True,sourceRuleRecords=prep['sourceRuleRecords'],implementation=implementation,verificationSources=verification,actualDebugRuleInputs=sql['actualRuleInputs'],soleCheckCases=13670,soleCheckMethods=7622,focusedCases=402,focusedMethods=209,actualNineOriginalFullMethods=start['exactNineEarlyFullMethods'],newCases=12,newMethods=7,sql=dict(cases=64,currentSixOriginalRooms=sql['totals'],privateRowsArePerTableAcrossAllViewersNotPerActor=True),expectedNextFixedFull=dict(cases=13819,methods=7763,sqlCases=64),expectedRemainingObligations=17426,sourceUniverse1740And14293AndSevenDeltasUnchanged=True,static35CallersNotSemanticCertification=True,core304AndCorrectPost14RowsOnlyNoAll16Refetch=True,fourExactFullRowsNoSourceDeltaNotFresh1504Refetch=True,grantedInsightEchoNotPrintedInherentEcho=True,portalModeOwnershipNotCertified=True,priorFixedF0NativeInputs=native['actualReleaseRuleInputs'],priorFixedNativeDoesNotCertifyNewDebugOrNextFixedCommit=True,wholePrintingCertified=False,semanticCoverageCertified=False,archive=pin(archive),archiveMap=pin(stage/'archive-map.json'))
write(stage/'source-manifest.json',sm);sp=pin(stage/'source-manifest.json','source-manifest')
branches=[dict(id=c['id'],sourceRefs=c['exactPrintingSubjects']+c['existingCanonicalRuleIds'],sourceManifest=sp,state='RECORDED',boundedCase=dict(actualExecutedCase=c['actualExecutedCase'],method=c['method']),semanticReview=dict(state=c['semanticScope'],wholeCardCertified=False),implementation=dict(state='SHARED_DRAW_AND_EXPLICIT_PARENT_COMPLETION_BOUNDARIES'),testExecution=dict(state='12NEW_402FOCUS_NINE_ORIGINAL_GAMES_SOLE_CHECK13670_PASS'),fixedCommitCi=dict(state='OPEN_NEW_FIXED_FULL'),productAcceptance=dict(state='OPEN_NEW_FIXED_MAIN_PAIR_NETWORK_SCORE_REPLAY_OS_HARDWARE_WINDOWS'),decision=dict(state='OPEN',reason='Bounded executed behavior; fixed full, exact consumers and required current product acceptance remain separate.'),wholePrintingCertified=False)for c in prep['cases']]
for name,reason in [('SHARED_DRAW_35_CONSUMER_BRANCH_MAPPING','35 static call sites require exact current printing/branch mapping and corresponding semantic execution proof; adjacent green tests do not certify every caller.'),('INNER_CLEANUP_IMMEDIATE_VICTORY_LEGAL_REACHABILITY','The generic inner cleanup location requires a legally reachable state/consumer counterexample before any defect claim or implementation change; source absence of a guard alone is not proof.')]:
 branches.append(dict(id='CN16-FIRST-BURNOUT-'+name,sourceRefs=rule_refs,sourceManifest=sp,semanticReview=dict(state='OPEN_REQUIRES_EXACT_BRANCH_PROOF',wholeCardCertified=False),implementation=dict(state='NO_UNPROVEN_GLOBAL_REWRITE'),testExecution=dict(state='OPEN_NO_COUNTEREXAMPLE_OR_COMPLETE_CONSUMER_PROOF'),fixedCommitCi=dict(state='SEPARATE'),productAcceptance=dict(state='OPEN'),decision=dict(state='OPEN',reason=reason),wholePrintingCertified=False))
assert len(branches)==14
write(stage/'fourteen-exact-behavior-and-open-candidate-branches.json',dict(branches=branches))
refreshed=[]
for name,context in m['reviewContexts'].items():
 changes=[]
 for ref in context['implementation']:
  digest=sha(root/ref['path'])
  if digest!=ref['sha256']:changes.append(dict(path=ref['path'],before=ref['sha256'],after=digest));ref['sha256']=digest
 if changes:
  refreshed.append(dict(id=name,changes=changes,oldCompleteContext=old['reviewContexts'][name]))
  context.update(currentImplementationCommit=base,currentImplementationIncludesUncommittedChanges=True,ciState='PENDING',currentFirstBurnoutInputRefresh=dict(sourceManifest=sp,onlyCurrentInputPinsNotWholeSemanticCertification=True,allPriorEvidenceAndOptionalVerificationReferencesRetained=True,newFixedFullAndProducts='OPEN'))
assert len(refreshed)==68 and {r['id']for r in refreshed}=={r['id']for r in binding['changes']}
for name,original in old['reviewContexts'].items():
 current=m['reviewContexts'][name];assert current.get('verificationSources')==original.get('verificationSources')and('verificationSources'in current)==('verificationSources'in original)
 if name not in {r['id']for r in refreshed}:assert current==original
(stage/'sixty-eight-input-refreshes-complete-old-contexts.json.gz').write_bytes(gzip.compress(json.dumps(refreshed,ensure_ascii=False,indent=2).encode(),mtime=0))
m['reviewContexts'][identity]=dict(evidenceCommit=base,currentImplementationCommit=base,currentImplementationIncludesUncommittedChanges=True,ciState='PENDING',ciReceipts=[],region='CN',language='zh-CN',applicableAsOf='2026-10-23',adoptedCoreEffectiveDate='2026-10-16',sourceManifest=sp,implementation=implementation,verificationSources=verification,branches=branches,evidence=[pin(stage/'test-source-and-runtime-retention.json','focus-check-and-retention'),pin(stage/'independent-sql-six-originals-owner.json','independent-real-sql'),pin(stage/'preceding-fixed-f0-nine-rooms-bounded-native.json','prior-fixed-native-only')])
reviews['reviews'].append(dict(id=identity,scope=scope,subjects=subjects,ruleRecords=rule_refs,status='BOUNDED_FIRST_BURNOUT_PARENT_COMPLETION_PASS_NEW_FULL_CONSUMER_MAPPING_AND_PRODUCTS_OPEN',sourceManifest=sp,auditDocument=document,validation=dict(newCases=12,newMethods=7,soleCheckCases=13670,soleCheckMethods=7622,focusedCases=402,focusedMethods=209,originalFullGameMethods=9,wholeCardCertification=False),exclusions=['35 static callers are not whole-consumer certification','Unproven generic inner cleanup candidate remains OPEN, not a reproduced bug','Portal preselected branch does not certify mode ownership; Insight paid granted Echo is not printed inherent Echo','Prior fixed f0 Release native and CI do not certify new Debug or next fixed commit','OS hardware and physical Windows remain independently OPEN']))
gate=dict(id='FIRST_BURNOUT_PARENT_COMPLETION_CURRENT_FIXED_MAIN_AND_PRODUCTS',state='OPEN',requirement='Verify the new fixed full13819/7763 and64 real SQL cases; then current fixed Main first-burnout draw/mandatory-discard/subsequent immediate win, paired recovery, network reconnect, ordinary score finish and complete original replay. Keep SDK, CI exported entry, OS hardware and physical Windows separate. Retain the exact-consumer mapping and unproven inner cleanup candidates.',scope=scope,sourceManifest=sp,issues=[prep['issue']],semanticReview='BOUNDED',implementation='SHARED_DRAW_AND_EXPLICIT_PARENT_BOUNDARIES',testExecution='12NEW_402FOCUS_NINE_ORIGINAL_GAMES_SOLE_CHECK13670',fixedCommitCi='OPEN_NEW_FIXED_FULL',productAcceptance='OPEN_CURRENT_FIXED_MAIN_AND_REQUIRED_PRODUCTS',wholePrintingCertified=False)
assert gate['id']not in {g['id']for g in m['acceptanceGates']};m['acceptanceGates'].append(gate)
assert reviews['reviews'][:-1]==old_reviews['reviews']and m['acceptanceGates'][:-1]==old['acceptanceGates']and m['laterSourceDeltas']==old['laterSourceDeltas']and m['certificationScope']==old['certificationScope']
review_bytes=(json.dumps(reviews,ensure_ascii=False,indent=2)+'\n').encode();m['inputs']['reviews']['sha256']=hashlib.sha256(review_bytes).hexdigest()
coverage=load(root/old['cardCoverageManifest']['path']);old_coverage=copy.deepcopy(coverage);coverage.update(previousCurrentScopedReviewDecisionsBeforeFirstBurnout=old_coverage['currentScopedReviewDecisions'],currentScopedReviewDecisions=m['inputs']['reviews'],currentFirstBurnoutScopedSourceManifest=sp)
assert all(coverage[k]==v for k,v in old_coverage.items()if k!='currentScopedReviewDecisions');write(stage/'source-coverage.json',coverage);m['cardCoverageManifest']=pin(stage/'source-coverage.json','current-card-coverage')
m['currentFirstBurnoutActionCompletionInputChange']=dict(sourceManifest=sp,auditDocument=document,issue=prep['issue'],newExecutedBehaviorBranches=12,newExplicitOpenCandidateBranches=2,newProductGate=1,allOriginal17411ObligationIdentitiesRetained=True,expectedRemainingObligations=17426,allOriginal170Reviews85Contexts271GatesSevenDeltasRetained=True,all85CompleteOldContextsArchived68InputRefreshes17WholeObjectsExact=True,allOldVerificationSourcesPresenceAndValuesRetained=True,newFixedFullAndProducts='OPEN',wholePrintingOrGoalCertified=False)
m['precedingFixedF0BoundedSdkMainGpuScoreNetworkAndOriginalReplay']=pin(stage/'preceding-fixed-f0-nine-rooms-bounded-native.json');m['precedingFixedF0PrivateHistoryCountScopeClarification']=pin(stage/'preceding-fixed-f0-private-row-count-scope-clarification.json');m['precedingFixedF0ObservedCiBeforeFirstBurnoutPublication']=pin(stage/'preceding-fixed-f0-actual-ci-observation.json');m['precedingFixedF248ActualCompleteFullCiReadback']=pin(stage/'preceding-fixed-f248-later-entire-full-independent.json')
source_supplements=['drawings-parallel-source-2026-10-23','drawings-cn-candidates-2026-10-23','drawings-worlds-runes-2026-10-23']
kr=load(root/'docs/evidence/drawings-parallel-source-2026-10-23/report.json')['newKoreanPreviewPrintings'];assert len(kr)==5
m['currentGlobalDrawingsParallelSourceFollowups']=dict(sourceManifests=[pin(root/'docs/evidence'/p/'source-manifest.json','source-manifest')for p in source_supplements],peerCommits=peer['peerCommits'][:4],newFiveKoreanPreviewObservations=kr,existingT1GateIds=[g['id']for g in old['acceptanceGates']if 'GLOBAL_DRAWINGS2026_T1_PLAYER_'in g['id']],allOriginal17DrawingsGatesWholeObjectsUnchanged=True,all1740CatalogAnd14293RuleIdentitiesRetained=True,previewLanguageAndEditionAreDistinctNotMerged=True,knownVen155AOnlyNotNewCardIdentity=True,worldsAndGiftRunesStillUnresolved=True,newSourceObservationsRequireEffectiveChangeRecheckBeforeFinalCertification=True,notAssumedEnglishEightGapIdentities=True,semanticCoverageCertified=False)
m['currentEnglishGalleryCaptureIntegrityFollowups']=dict(peerCommits=peer['peerCommits'][4:],verification=[pin(root/'docs/evidence'/p/'verification.json','offline-source-input-verification')for p in ['gallery-json-type-conflict-2026-10-23','gallery-capture-duplicate-members-2026-10-23']],currentTools=[pin(root/'scripts/audit'/p,'audit-tool')for p in ['gallery_coverage.py','gallery_gap_diagnostics.py']],allOriginal84ToolMethodsPreservedPlusSix=True,currentToolMethods=90,all285OriginalSourceArchiveMembersRetained=True,sourceGapState='OPEN',reported=1416,actualExactIdentities=1408,unknownIdentityGap=8,noActualOfficialDuplicateKeysOrTypeDeltaObservedFromSyntheticCases=True,semanticCoverageCertified=False)
assert(len(reviews['reviews']),len(m['reviewContexts']),len(m['acceptanceGates']),len(m['laterSourceDeltas']))==(171,86,272,7)
assert all(m['inputs'][k]==old['inputs'][k]for k in old['inputs']if k!='reviews')
write(stage/'publication-governance-retention.json',dict(atUtc=now(),oldReviews=170,oldContexts=85,oldGates=271,oldDeltas=7,oldRemainingIds=17411,newExecutedBehaviorBranches=12,newOpenCandidateBranches=2,newGate=1,currentRemainingObligations=17426,currentReviews=171,currentContexts=86,currentGates=272,completeOldContextsArchived=85,refreshedCurrentImplementationPins=68,otherWholeContextsUnchanged=17,allOldReviewsGatesDeltasScopeAndVerificationReferencesRetained=True,sourceCoverageCertified=False))
audit=(w/'final-audit-prose-prepared-v1.md').read_text().replace('本批唯一 check 实际结果见单独收据，目标为原 13658/7615 加 12/7，即 13670 例/7622 方法。','本批唯一 check13670例/7622方法实际全过，用例多重集精确等于原13658/7615加12/7。')
status=(w/'final-status-prose-prepared-v1.md').read_text().replace('唯一check目标13670/7622，实际终态另存。','唯一check13670/7622实际全过。')
assert(root/'docs/PROJECT_STATUS.md').read_text()==old_status and sha(mp)==binding['manifestSha256']and sha(rp)==binding['reviewsSha256']
stage.rename(ev);rp.write_bytes(review_bytes);mp.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n');(root/document).write_text(audit);heading='# 当前项目状态\n\n';(root/'docs/PROJECT_STATUS.md').write_text(heading+status+old_status[len(heading):])
print('PUBLISHED_N50_12NEW7METHODS402FOCUS209METHODS_NINE_ORIGINAL_GAMES_SOLECHECK13670_7622_171REVIEWS86CONTEXTS272GATES7DELTAS17426OBLIGATIONS',flush=True)
