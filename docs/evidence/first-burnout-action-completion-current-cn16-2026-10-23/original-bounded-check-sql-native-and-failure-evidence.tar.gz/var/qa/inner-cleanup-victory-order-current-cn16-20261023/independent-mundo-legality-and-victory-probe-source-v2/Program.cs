using System.IO.Compression;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using Riftbound.CardCatalog;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;
var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
var output = Path.GetFullPath(args.Single()); Check(!Directory.Exists(output), "Fresh original legality/cleanup evidence directory required."); Directory.CreateDirectory(output);
var modules = new[] { typeof(CoreRuleEngine).Assembly, typeof(GameCommand).Assembly, typeof(OfficialCardCatalog).Assembly, typeof(PostgresMatchRecoveryStore).Assembly };
var loaded = new { baseDirectory = AppContext.BaseDirectory, actualRuleInputs = RuleInputIdentity.Current,
    assemblies = modules.Select(a => new { name = a.GetName().Name, path = a.Location, mvid = a.ManifestModule.ModuleVersionId,
        sha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(a.Location))).ToLowerInvariant() }).ToArray() };
var outcomes = new List<object>(); var passed = 0;
foreach (var wounded in new[] { false, true })
foreach (var opponentScore in new[] { 6, 7 })
{
    var label = (wounded ? "real-damage8" : "undamaged") + "-opponent" + opponentScore;
    var cards = new Dictionary<string, CardObjectState>(); var locations = new Dictionary<string, ObjectLocationState>();
    void Put(string id, string no, string zone, string owner = "P1", string? field = null)
    {
        var factory = typeof(CoreRuleEngine).Assembly.GetType("Riftbound.Engine.PrintedCardFactory", true)!;
        var create = factory.GetMethods(BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic).Single(m => m.Name == "TryCreate" && m.GetParameters().Length == 4);
        object?[] arguments = [id, owner, no, null]; Check((bool)create.Invoke(null, arguments)!, "Actual printed factory is required: " + no);
        cards[id] = (CardObjectState)arguments[3]!; locations[id] = new(owner, zone, field);
    }
    Put("MUNDO", "OGN·109/298", "BASE"); Put("DAMAGE", "OGS·022/024", "HAND"); Put("DRAW", "OGN·047/298", "HAND");
    Put("RUNE", "SFD·R03", "RUNE_DECK"); Put("F", "OGN·278/298", "BATTLEFIELD", field: "F"); Put("OTHER", "OGN·294/298", "BATTLEFIELD", "P2", "OTHER");
    foreach (var id in new[] { "G0", "G1", "G2" }) Put(id, "OGN·083/298", "GRAVEYARD");
    var initial = new MatchState("CONTROLLED-MUNDO-" + label, 0, 5, "P1", new Dictionary<string, string> { ["P1"] = "P1", ["P2"] = "P2" },
        status: MatchStatuses.InProgress, readyPlayerIds: ["P1", "P2"], turnPlayerId: "P1", phase: MatchPhases.Main, timingState: TimingStates.NeutralOpen,
        playerZones: new Dictionary<string, PlayerZones> {
            ["P1"] = PlayerZones.Empty with { Base = ["MUNDO"], Hand = ["DAMAGE", "DRAW"], Graveyard = ["G0", "G1", "G2"], RuneDeck = ["RUNE"], Battlefields = ["F"] },
            ["P2"] = PlayerZones.Empty with { Battlefields = ["OTHER"] } },
        cardObjects: cards, objectLocations: locations, playerScores: new Dictionary<string, int> { ["P1"] = 0, ["P2"] = opponentScore },
        runePools: new Dictionary<string, RunePool> { ["P1"] = new(30, 30), ["P2"] = new(30, 30) }, seed: 424242) with { CardPlays = new(5, [], []) };
    Check(cards["MUNDO"].Power == 6 && cards["MUNDO"].Damage == 0 && Might(initial) == 9,
        "The original printed6 plus three real graveyard cards must actually give9, initially undamaged.");
    var journal = new Journal(); var session = new MatchSession(initial, new CoreRuleEngine(), journal); var state = initial;
    if (wounded)
    {
        await Act("P1", new PlayCardCommand("DAMAGE", "OGS·022/024", ["MUNDO"])); await Top();
        Check(state.CardObjects["MUNDO"].Damage == 8 && state.PlayerZones["P1"].Base.Contains("MUNDO")
            && state.PlayerZones["P1"].Graveyard.Contains("DAMAGE") && Might(state) == 10,
            "Eight actual printed damage is legally survived at9; completed original spell enters graveyard and raises might to10. No seeded damage override.");
    }
    var actualBeforeDraw = state; var beforeMight = Might(state); Check(beforeMight > state.CardObjects["MUNDO"].Damage, "The complete original prefix must be nonlethal before the draw parent.");
    await Act("P1", new PlayCardCommand("DRAW", "OGN·047/298", [])); await Top();
    var commands = journal.Entries.Select(e => new RecoveredCommand(e.PlayerId, e.ClientIntentId, e.CommandType, e.RawCommand,
        e.StartedTick, e.CompletedTick, e.StartedEventSequence, e.CompletedEventSequence, e.Accepted, e.ErrorMessage) { RuleInputs = e.RuleInputs }).ToArray();
    var events = journal.Entries.SelectMany(e => e.Events.Select((ev, i) => new RecoveredEvent(e.StartedEventSequence + i + 1, e.CompletedTick, i, ev))).ToArray();
    var replay = await MatchActionLogReplayer.VerifyFinalStateAsync(initial, commands, state, new CoreRuleEngine(), default, events); Check(replay.IsMatch, "Every original setup damage and subsequent draw command/event must replay: " + string.Join("; ", replay.Errors));
    var expectedWin = opponentScore == 7; var expectedMundoAlive = !wounded || expectedWin; var actualAlive = state.PlayerZones["P1"].Base.Contains("MUNDO");
    var kinds = events.Select(e => e.Event.Kind).ToList();
    var sourceMatches = actualAlive == expectedMundoAlive && state.PlayerScores["P2"] == opponentScore + 1
        && state.WinnerPlayerId == (expectedWin ? "P2" : null) && state.Status == (expectedWin ? MatchStatuses.Finished : MatchStatuses.InProgress)
        && state.PlayerZones["P1"].Base.Contains("RUNE") && state.CardObjects["RUNE"].IsExhausted
        && kinds.Count(k => k == "BURNOUT_APPLIED") == 1 && kinds.Count(k => k == "CARD_DRAWN") == 1
        && kinds.Count(k => k == "RUNES_CALLED") == 1 && kinds.Count(k => k == "MATCH_WON") == (expectedWin ? 1 : 0)
        && kinds.IndexOf("RUNES_CALLED") > kinds.IndexOf("CARD_DRAWN");
    if (sourceMatches) passed++;
    outcomes.Add(new { label, sourceMatches, woundedByRealOriginalSpell = wounded, originalOpponentScore = opponentScore, beforeMight,
        actualDamageBeforeDraw = actualBeforeDraw.CardObjects["MUNDO"].Damage, expectedMundoAlive, actualMundoAlive = actualAlive,
        actualMundoInGraveyard = state.PlayerZones["P1"].Graveyard.Contains("MUNDO"), actualWinner = state.WinnerPlayerId, actualOpponentScore = state.PlayerScores["P2"],
        originalCommands = commands.Length, originalReplayMatchesActualState = replay.IsMatch, actualEventKinds = kinds });
    await using (var file = new FileStream(Path.Combine(output, label + "-complete-original-damage-then-draw-history.json.gz"), FileMode.CreateNew))
    await using (var zip = new GZipStream(file, CompressionLevel.SmallestSize))
        await JsonSerializer.SerializeAsync(zip, new { initial, beforeDraw = actualBeforeDraw, commands, events, final = state, journal.Entries }, json);
    Console.WriteLine($"MUNDO_CLEANUP_SOURCE_{(sourceMatches ? "PASS" : "RED")} {label} legalBeforeMight={beforeMight} damage={actualBeforeDraw.CardObjects["MUNDO"].Damage} expectedAlive={expectedMundoAlive} actualAlive={actualAlive}");
    async Task Act(string actor, GameCommand command)
    {
        var prompt = session.PromptFor(actor); var raw = JsonSerializer.SerializeToNode(command, command.GetType(), json)!.AsObject(); raw["promptId"] = prompt.PromptId; raw["snapshotTick"] = state.Tick;
        var result = await session.SubmitAsync(actor, "original-" + journal.Entries.Count, command, JsonSerializer.SerializeToElement(raw, json), default);
        Check(result.Accepted, "Legality preparation failed before the cleanup oracle: " + result.ErrorMessage); state = result.State;
    }
    async Task Top() { var id = state.StackItems.Last().StackItemId; for (var i = 0; i < 8 && state.StackItems.Any(s => s.StackItemId == id); i++) await Act(state.PriorityPlayerId!, new PassPriorityCommand()); Check(!state.StackItems.Any(s => s.StackItemId == id), "The actual parent must complete."); }
}
await File.WriteAllTextAsync(Path.Combine(output, "mundo-legal-damage-then-burnout-cleanup-source-oracle-v1.json"), JsonSerializer.Serialize(new {
    status = passed == 4 ? "SOURCE_ORACLE_ALL_FOUR_MUNDO_NORMAL_VICTORY_ORDER_CASES_PASS" : "REPRODUCED_INNER_LETHAL_CLEANUP_BEFORE_NORMAL_SCORE_VICTORY",
    actualLoadedFourAssemblies = loaded, totalCases = 4, passedCases = passed, failedCases = 4 - passed, outcomes,
    sourceClause3231Before3234 = true, noSeededDamageOrAcceptedHistoryRewrite = true, controlledPositionsNotOrdinaryOpening = true, noRootSourceBinOrSqlMutation = true, wholePrintingCertified = false }, json));
Environment.ExitCode = passed == 4 ? 0 : 1;
static int Might(MatchState state) => JsonSerializer.SerializeToElement(ResolutionResult.BuildSnapshots(state)["P1"], new JsonSerializerOptions(JsonSerializerDefaults.Web))
    .GetProperty("players").GetProperty("P1").GetProperty("objects").GetProperty("MUNDO").GetProperty("effectivePower").GetInt32();
static void Check(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
sealed class Journal : IMatchJournal { internal List<MatchJournalEntry> Entries { get; } = []; public ValueTask RecordAsync(MatchJournalEntry entry, CancellationToken token) { Entries.Add(entry); return ValueTask.CompletedTask; } }
