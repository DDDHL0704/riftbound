from pathlib import Path
import datetime,gzip,hashlib,json,subprocess
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;runtime=root/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0';source=w/'independent-mundo-legality-and-victory-probe-source-v2';dll=source/'bin/Release/net10.0/IndependentMundoCleanupVictoryOrderV2.dll';assert dll.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());obs=load(root/'var/qa/first-burnout-action-completion-current-cn16-20261023/sole-check-actual-post-build-input-observation-v1.json');start=json.loads(gzip.decompress((root/'var/qa/first-burnout-action-completion-current-cn16-20261023/sole-check-start-inputs-v1.json.gz').read_bytes()))
def stable():
 assert all(sha(root/p)==h for p,h in obs['actualPostBuildRuntimeHashes'].items())
 assert all(sha(root/p)==v['sha256']for p,v in start['sourceHashesAndModes'].items())
stable();args=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(runtime/'Riftbound.ConformanceTests.deps.json'),'--runtimeconfig',str(runtime/'Riftbound.ConformanceTests.runtimeconfig.json'),str(dll),str(w/'actual9e42-original-legality-and-oracle-v2')]
proof={'startedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actualCommand':args,'ownSourceAndBinaryHashes':{str(p):sha(p)for p in [Path(__file__),dll,dll.with_suffix('.pdb'),source/'Program.cs',source/'probe.csproj']},'rootCheckSourceAndActualRuntimeStableBefore':True}
try:
 with(w/'actual9e42-original-console-v2.log').open('xb')as f:r=subprocess.run(args,cwd=runtime,stdout=f,stderr=subprocess.STDOUT,timeout=120)
 proof['actualExitCode']=r.returncode;p=w/'actual9e42-original-legality-and-oracle-v2/mundo-legal-damage-then-burnout-cleanup-source-oracle-v1.json'
 if p.exists():
  x=load(p);assert x['actualLoadedFourAssemblies']['actualRuleInputs']==obs['sameDependencyGraphFourAssemblyMeasurement']['actualRuleInputs']
  for a in x['actualLoadedFourAssemblies']['assemblies']:assert Path(a['path'])==runtime/(a['name']+'.dll')and sha(Path(a['path']))==a['sha256']and a['mvid']
  proof.update(status=x['status'],resultPath=str(p),resultSha256=sha(p),actualRuleInputs=x['actualLoadedFourAssemblies']['actualRuleInputs'],totalCases=x['totalCases'],passedCases=x['passedCases'],failedCases=x['failedCases']);print(x['status'],x['passedCases'],x['failedCases'],flush=True)
 else:proof['status']='PREPARATION_FAILED_BEFORE_ANY_COMPLETED_SOURCE_ORACLE';print(proof['status'],flush=True)
finally:
 stable();proof['allRootCheckSourceAndActualRuntimeInputsUnchanged']=True;proof['noSqlAccessOrAcceptedHistoryRewrite']=True
 with(w/'actual9e42-own-legality-and-cleanup-oracle-terminal-v2.json').open('x')as f:json.dump(proof,f,indent=2)
