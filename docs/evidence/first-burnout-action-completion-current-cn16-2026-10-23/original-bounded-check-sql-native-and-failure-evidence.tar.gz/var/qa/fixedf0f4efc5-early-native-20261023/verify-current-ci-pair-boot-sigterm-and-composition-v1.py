from pathlib import Path
from datetime import datetime, timezone
import hashlib, importlib.util, json, stat, subprocess, sys

sys.dont_write_bytecode = True
root = Path('/Users/dinghaolin/MyProjects/riftbound')
qa = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
fixed = 'f0f4efc54f53af3e0b9043473af365392a243a82'
run_id = 39888194599
original_composition = qa/'frozen-fixedf0f4efc5-native-composition-v1.json'
original_composition_hash = sha(original_composition)
pub = load(original_composition)
source_manifest = Path(pub['apiBuildInputsManifest'])
assert sha(source_manifest) == pub['apiBuildInputsManifestSha256']
source_inputs = load(source_manifest)
source_root = Path(pub['fixedSourceRoot'])
manifest_path = qa/'native-app-inputs.json'
native = load(manifest_path)
downloads = load(qa/'current-fixed-native-download-original-result-v1.json')
assert native['fixedCommit'] == pub['fixedCommit'] == downloads['fixedCommit'] == fixed
assert native['runId'] == downloads['runId'] == run_id
assert len(native['ciManagedAndPckPayloads']) == 373 and len(native['apps']) == 2
assert len(downloads['artifacts']) == 2
assert all(a['allOuterZipCrcVerified'] and a['backendDigest'] == 'sha256:'+a['actualSha256']
           and sha(qa/'native-current'/a['filename']) == a['actualSha256'] for a in downloads['artifacts'])

def fixed_inputs():
    assert sha(original_composition) == original_composition_hash
    assert sha(source_manifest) == pub['apiBuildInputsManifestSha256']
    assert all(sha(source_root/p) == h for p, h in source_inputs['sourceHashes'].items())
    assert all(oct(stat.S_IMODE((source_root/p).stat().st_mode)) == m
               for p, m in source_inputs['sourceModes'].items())
    assert all(sha(source_root/'clients/godot/.godot/mono/temp/bin/Debug'/p) == h
               for p, h in source_inputs['nativeManagedRuntimeFiles'].items())
    for directory_key, manifest_key in [('apiRuntimeRoot', 'runtimeFiles'),
                                        ('helperRuntimeRoot', 'helperRuntimeFiles'),
                                        ('networkRuntimeRoot', 'networkRuntimeFiles')]:
        assert all(sha(Path(pub[directory_key])/p) == h for p, h in pub[manifest_key].items())

fixed_inputs()
spec = importlib.util.spec_from_file_location('fixed_committed_desktop_gate', source_root/'clients/godot/tools/ci-desktop.py')
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
records = []
for entry in native['apps']:
    app = Path(entry['app'])
    executable = app/'Contents/MacOS/符文战场'
    assert entry['bundleId'] == 'com.riftbound.qa.current-f0f4efc5.'+entry['label']
    assert all(sha(app/p) == h for p, h in native['ciManagedAndPckPayloads'].items())
    subprocess.run(['codesign', '--verify', '--deep', '--strict', str(app)], capture_output=True, check=True)
    profile = qa/('never-written-default-boot-'+entry['label']+'-v1.json')
    assert not profile.exists()
    log = qa/('current-ci-default-main-natural-'+entry['label']+'-v1.log')
    command = [str(executable), '--headless', '--max-fps', '60', '--quit-after', '120', '--',
               '--riftbound-ephemeral-session', '--riftbound-server=http://127.0.0.1:1',
               '--riftbound-session-file='+str(profile)]
    with log.open('xb') as out:
        process = subprocess.run(command, cwd='/tmp', stdout=out, stderr=subprocess.STDOUT, timeout=45)
    console = log.read_text(errors='replace')
    assert process.returncode == 0 and 'Client booted.' in console
    assert 'Official catalog loaded: 1037 cards.' in console and 'ERROR:' not in console and not profile.exists()
    signal_log = qa/('current-ci-default-main-sigterm-'+entry['label']+'-v1.log')
    gate.verify_macos_sigterm_shutdown(executable, signal_log, qa)
    assert 'Termination requested; exiting through Godot.' in signal_log.read_text()
    assert 'ERROR:' not in signal_log.read_text()
    assert all(sha(app/p) == h for p, h in native['ciManagedAndPckPayloads'].items())
    records.append(dict(role=entry['label'], app=str(app), executable=str(executable), actualCommand=command,
                        naturalExitCode=process.returncode, naturalLogSha256=sha(log), sigtermGuardPassed=True,
                        sigtermLogSha256=sha(signal_log), ephemeralProfileNeverWritten=True,
                        all373CiPayloadsAndSignatureExact=True))
ci_signal = qa/'native-current/ci-logs/mac/exported-sigterm.log'
assert 'Termination requested; exiting through Godot.' in ci_signal.read_text() and 'ERROR:' not in ci_signal.read_text()
fixed_inputs()
proof = dict(atUtc=datetime.now(timezone.utc).isoformat(),
             status='ACTUAL_FIXED_F0_CI_PAIR_DEFAULT_MAIN_NATURAL_AND_SIGTERM_CLEAN_373_PAYLOADS_EACH',
             fixedCommit=fixed, fixedCiRun=run_id, records=records, ciMacosSigtermLogSha256=sha(ci_signal),
             nativeInputManifestSha256=sha(manifest_path), originalApiOnlyCompositionSha256=original_composition_hash,
             matchingFrozenApiRuleInputs=pub['actualRuleInputs'], source3380AndNative23AndApi46Helper87Network22Unchanged=True,
             serverNotStartedAndNoDatabaseAction=True, precedingF248PairMayBeRetiredAfterOwnedProcessCheck=True,
             visiblePairHardwareInputPhysicalWindowsAndWholeFullRemainSeparate=True, semanticCoverageCertified=False)
output = qa/'current-native-headless-boot-and-sigterm-verification-v1.json'
with output.open('x') as f:
    json.dump(proof, f, indent=2)
    f.write('\n')
pub.update(status='FROZEN_FIXED_F0_SOURCE3380_NATIVE23_API46_HELPERS87_NETWORK22_AND_CI_PAIR373_EACH_BOOT_SIGTERM_VERIFIED',
           originalApiOnlyPreparationComposition=str(original_composition),
           originalApiOnlyPreparationCompositionSha256=original_composition_hash,
           nativeApps=native['apps'], ciManagedAndPckPayloads=native['ciManagedAndPckPayloads'],
           nativeAppManifest=str(manifest_path), nativeAppManifestSha256=sha(manifest_path),
           currentDefaultBootAndSigtermResultSha256=sha(output), nativePackagesNotYetDownloaded=False,
           noAppInstallerSdkDatabaseOrGitWorktreeCreated=False,
           currentPackagePhaseCreatedOnlyCurrentPairAndTwoInstallers=True,
           noNewSdkTemplateDatabaseGitWorktreeOrPermanentInnerZip=True,
           wholePrintingOrGoalCertified=False)
target = qa/'frozen-fixedf0f4efc5-native-composition-with-ci-apps-v2.json'
with target.open('x') as f:
    json.dump(pub, f, indent=2)
    f.write('\n')
assert sha(original_composition) == original_composition_hash
print(proof['status'], flush=True)
