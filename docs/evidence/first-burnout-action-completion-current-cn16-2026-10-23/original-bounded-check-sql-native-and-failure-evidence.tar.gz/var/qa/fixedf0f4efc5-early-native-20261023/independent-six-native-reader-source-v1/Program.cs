using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.CardCatalog;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
var modules = new[] { typeof(CoreRuleEngine).Assembly, typeof(GameCommand).Assembly, typeof(OfficialCardCatalog).Assembly, typeof(PostgresMatchRecoveryStore).Assembly };
var loaded = new { baseDirectory = AppContext.BaseDirectory, actualRuleInputs = RuleInputIdentity.Current,
    assemblies = modules.Select(a => new { name = a.GetName().Name, path = a.Location, mvid = a.ManifestModule.ModuleVersionId, sha256 = Sha(a.Location) }).ToArray() };
if (args is ["--loaded-inputs"]) { Console.WriteLine(JsonSerializer.Serialize(loaded, json)); return; }
Check(args.Length == 2 && !File.Exists(args[1]), "One exact original input manifest and one fresh result required.");
using var input = JsonDocument.Parse(File.ReadAllText(args[0])); var top = input.RootElement;
Check(top.GetProperty("fixedCommit").GetString() == "f0f4efc54f53af3e0b9043473af365392a243a82"
    && Same(top.GetProperty("actualRuleInputs"), JsonSerializer.SerializeToElement(RuleInputIdentity.Current, json)), "Exact fixed commit and actual loaded identity.");
var settings = new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
Check(settings.Host == "127.0.0.1" && settings.Port == 55486 && settings.Database == "riftbound_here_native"
    && settings.Username == "codex_riftbound_audit", "Only the original own native database.");
settings.Options = "-c default_transaction_read_only=on";
await using var source = NpgsqlDataSource.Create(settings.ConnectionString);
await using var connection = await source.OpenConnectionAsync();
Check((string)(await new NpgsqlCommand("show transaction_read_only", connection).ExecuteScalarAsync())! == "on", "Actual read-only transaction.");
var totals = new Dictionary<string, int> { ["commands"] = 0, ["events"] = 0, ["authority"] = 0, ["snapshots"] = 0, ["prompts"] = 0, ["prefixReplays"] = 0,
    ["cleanSdkProductionCommands"] = 0, ["canonicalSdkPairedColdStages"] = 0, ["canonicalSdkViewportImages"] = 0 };
var expectedCounts = new Dictionary<string, int> { ["draw-hold"] = 8, ["win"] = 6, ["burnout"] = 6, ["brush-decline"] = 7, ["brush-return"] = 9, ["combat"] = 7 };
var expectedCold = new Dictionary<string, int> { ["draw-hold"] = 3, ["win"] = 2, ["burnout"] = 2, ["brush-decline"] = 3, ["brush-return"] = 3, ["combat"] = 2 };
var seen = new HashSet<string>(); var seenNative = new HashSet<(string Room, string Intent)>(); var results = new List<object>();
foreach (var entry in top.GetProperty("branches").EnumerateArray())
{
    var branch = entry.GetProperty("branch").GetString()!; var room = entry.GetProperty("room").GetString()!;
    Check(seen.Add(branch) && expectedCounts.ContainsKey(branch), "Six exact distinct branches.");
    var actors = entry.GetProperty("players").EnumerateArray().Select(v => v.GetString()!).ToArray();
    Check(actors.SequenceEqual(new[] { "qa55a24c64b880186", "qa55b152911f0650f" }), "Original own A/B identities and seat order.");
    var a = actors[0]; var b = actors[1]; var framePath = entry.GetProperty("finalFramePath").GetString()!; var rowsPath = entry.GetProperty("finalRowsPath").GetString()!;
    Check(Sha(framePath) == entry.GetProperty("finalFrameSha256").GetString() && Sha(rowsPath) == entry.GetProperty("finalRowsSha256").GetString(), "Original retained frame and row hashes.");
    using var savedFrame = Read(framePath); using var savedRows = Read(rowsPath); var originalRows = savedRows.RootElement.GetProperty("originalRows");
    var frame = savedFrame.RootElement.Deserialize<MatchRecoveryFrame>(json)!;
    var live = await new PostgresMatchRecoveryStore(source).LoadAsync(room, default) ?? throw new Exception("Original SQL room required.");
    Check(Same(savedFrame.RootElement, JsonSerializer.SerializeToElement(live, json)), "All actual current recovery-frame fields, nulls, omissions and arrays equal the retained original.");
    Check(frame.IsConsistent && frame.ValidationErrors.Count == 0 && frame.OpeningSeed != 0
        && frame.ReplayInitialState is { Tick: 0, Status: "EMPTY", Seats.Count: 0, CardObjects.Count: 0 }
        && frame.Commands.Count == expectedCounts[branch] && frame.Commands.All(c => c.Accepted && c.RuleInputs == RuleInputIdentity.Current), "Complete original accepted history, EMPTY origin, private seed and loaded inputs.");
    var scenario = "final-conquest-"+entry.GetProperty("scenario").GetString();
    var expectedTypes = new List<string> { "ROOM_SEAT", "ROOM_SEAT", "DEV_SEED_SCENARIO:"+scenario, "MOVE_UNIT", "PASS_FOCUS", "PASS_FOCUS" };
    if (branch == "draw-hold") expectedTypes.AddRange(["END_TURN", "END_TURN"]);
    if (branch.StartsWith("brush", StringComparison.Ordinal)) expectedTypes.Add("CHOOSE_CARDS");
    if (branch == "brush-return") expectedTypes.AddRange(["PASS_PRIORITY", "PASS_PRIORITY"]);
    if (branch == "combat") expectedTypes.Add("DECLARE_BATTLE");
    Check(frame.Commands.Select(c => c.CommandType).SequenceEqual(expectedTypes), "Independent literal entire command sequence without repeated accepted actions.");
    for (var i = 0; i < 2; i++) {
        var command = frame.Commands[i]; var raw = command.RawCommand!.Value; var actor = actors[i]; var seat = i == 0 ? "P1" : "P2";
        Check(command.PlayerId == actor && command.ClientIntentId == "room-seat:"+seat && raw.EnumerateObject().Count() == 3
            && raw.GetProperty("playerId").GetString() == actor && raw.GetProperty("seat").GetString() == seat
            && raw.GetProperty("cmdType").GetString() == "ROOM_SEAT", "Exact reserved atomic seat inputs have no public credentials.");
    }
    var states = new Dictionary<(long Tick, long Seq), MatchState>(); var rowCounts = new Dictionary<string, int>();
    foreach (var table in new[] { "matches", "match_players", "command_log", "game_events", "state_snapshots", "snapshots", "action_prompts" }) {
        await using var command = new NpgsqlCommand($"select coalesce(json_agg(t order by row_to_json(t)::text),'[]'::json)::text from (select * from {table} where match_id=@room)t", connection);
        command.Parameters.AddWithValue("room", room); using var actual = JsonDocument.Parse((string)(await command.ExecuteScalarAsync())!);
        if (!Same(actual.RootElement, originalRows.GetProperty(table)))
            await File.WriteAllTextAsync(args[1]+".first-seven-table-difference.json", JsonSerializer.Serialize(new { branch, room, table, original = originalRows.GetProperty(table), actual = actual.RootElement }, json));
        Check(Same(actual.RootElement, originalRows.GetProperty(table)), "Every original seven-table field, value, null, omission and array: "+branch+"/"+table);
        rowCounts[table] = actual.RootElement.GetArrayLength();
        if (table == "state_snapshots") foreach (var row in actual.RootElement.EnumerateArray()) {
            var payload = row.GetProperty("payload"); var state = payload.Deserialize<MatchState>(json)!;
            Check(Same(payload, JsonSerializer.SerializeToElement(state, json)) && state.RuleInputs == RuleInputIdentity.Current
                && states.TryAdd((state.Tick, row.GetProperty("last_event_sequence").GetInt64()), state), "All typed authority fields and unique checkpoint identities.");
        }
    }
    Check(states.Count == expectedCounts[branch], "One original authority history for each accepted input.");
    foreach (var (command, index) in frame.Commands.Select((c, i) => (c, i))) {
        var state = states[(command.CompletedTick, command.CompletedEventSequence)];
        var events = frame.Events.Where(e => e.Sequence <= command.CompletedEventSequence).ToArray();
        var replay = await MatchActionLogReplayer.VerifyFinalStateAsync(frame.ReplayInitialState!, frame.Commands.Take(index+1).ToArray(), state, new CoreRuleEngine(), default, events);
        Check(replay.IsMatch, "Every entire original prefix actually replays: "+string.Join("; ", replay.Errors)); totals["prefixReplays"]++;
        if (index >= 3) {
            var raw = command.RawCommand!.Value;
            var prompt = originalRows.GetProperty("action_prompts").EnumerateArray().Single(r => r.GetProperty("player_id").GetString() == command.PlayerId
                && r.GetProperty("prompt_tick").GetInt64() == command.StartedTick && r.GetProperty("last_event_sequence").GetInt64() == command.StartedEventSequence).GetProperty("payload");
            Check(raw.GetProperty("snapshotTick").GetInt64() == command.StartedTick && raw.GetProperty("promptId").GetString() == prompt.GetProperty("promptId").GetString(), "Each original native gameplay input stamps its independently stored private prompt and tick.");
        }
    }
    foreach (var table in new[] { "snapshots", "action_prompts" }) foreach (var row in originalRows.GetProperty(table).EnumerateArray()) {
        var actor = row.GetProperty("player_id").GetString()!; var payload = row.GetProperty("payload");
        var tick = row.GetProperty(table == "snapshots" ? "snapshot_tick" : "prompt_tick").GetInt64(); var seq = row.GetProperty("last_event_sequence").GetInt64(); var state = states[(tick, seq)];
        Check(state.Seats.ContainsKey(actor), "Only actually existing historical private viewers.");
        var typed = table == "snapshots" ? JsonSerializer.SerializeToElement(payload.Deserialize<SnapshotDto>(json), json) : JsonSerializer.SerializeToElement(payload.Deserialize<ActionPromptDto>(json), json);
        var projected = table == "snapshots" ? JsonSerializer.SerializeToElement(ResolutionResult.BuildSnapshots(state)[actor], json) : JsonSerializer.SerializeToElement(ResolutionResult.BuildPrompts(state)[actor], json);
        if (!Same(payload, typed) || !Same(payload, projected))
            await File.WriteAllTextAsync(args[1]+".first-complete-private-difference.json", JsonSerializer.Serialize(new { branch, room, table, actor, tick, seq, original = payload, typed, projected }, json));
        Check(Same(payload, typed) && Same(payload, projected), "Every original private field, null, omission and exact array matches its complete typed and current projection: "+branch+"/"+table+"/"+actor+"/"+tick);
        Check(!payload.TryGetProperty("openingSeed", out _) && !payload.TryGetProperty("playerKey", out _) && !payload.TryGetProperty("reconnectToken", out _), "No seed or credential projection fields.");
        var text = payload.GetRawText();
        foreach (var enemy in state.Seats.Keys.Where(p => p != actor)) foreach (var id in state.PlayerZones[enemy].Hand.Concat(state.PlayerZones[enemy].MainDeck))
            Check(!text.Contains(JsonSerializer.Serialize(id), StringComparison.Ordinal), "Independent literal opponent hand/deck identity boundary.");
    }
    foreach (var native in top.GetProperty("cleanSdkProductionCommands").EnumerateArray().Where(n => n.GetProperty("room").GetString() == room)) {
        var index = native.GetProperty("index").GetInt32(); var command = frame.Commands[index];
        Check(seenNative.Add((room, command.ClientIntentId)) && Same(native.GetProperty("completeOriginalCommand"), JsonSerializer.SerializeToElement(command, json))
            && native.GetProperty("productionButtonSignals").GetArrayLength() > 0, "Each clean native terminal has a distinct whole original SQL command and actual button signals.");
        var console = native.GetProperty("originalConsole").GetString()!;
        Check(Sha(console) == native.GetProperty("originalConsoleSha256").GetString() && !File.ReadAllText(console).Contains("ERROR:", StringComparison.Ordinal)
            && File.ReadAllText(console).Contains("Official catalog loaded: 1037 cards.", StringComparison.Ordinal), "Clean original production control console and full runtime resources."); totals["cleanSdkProductionCommands"]++;
    }
    var final = frame.AuthoritativeState!; var won = branch is "win" or "draw-hold";
    Check(final.PlayerScores[a] == (won ? 8 : 7) && final.PlayerScores[b] == (branch == "burnout" ? 1 : 0)
        && final.Status == (won ? MatchStatuses.Finished : MatchStatuses.InProgress) && final.WinnerPlayerId == (won ? a : null), "Independent final literal scores, actual hold win, burnout point and winner.");
    Check(final.PlayerZones[a].Hand.Count == (branch == "win" ? 0 : 1) && final.PlayerZones[a].MainDeck.Count == (branch == "win" ? 3 : 2)
        && frame.Events.Count(e => e.Event.Kind == "BATTLEFIELD_SCORE_REPLACED_BY_DRAW") == (branch == "win" ? 0 : 1), "One actual replacement draw except the eligible all-field conquest.");
    if (branch == "burnout") Check(final.RngCursor == 1 && final.PlayerZones[a].Graveyard.Count == 0 && frame.Events.Count(e => e.Event.Kind == "BURNOUT_APPLIED") == 1, "Actual single recycle and RNG advance.");
    if (branch.StartsWith("brush", StringComparison.Ordinal)) Check(final.CardObjects["BF"].CardNo == (branch == "brush-return" ? "OGN·282/298" : "UNL·T03")
        && final.PlayerZones[b].Banished.Count == (branch == "brush-return" ? 0 : 1), "Physical original Brush return or decline, including owner exile link.");
    if (branch == "combat") Check(final.PlayerZones[b].Graveyard.Contains("DEFENDER"), "Actual defeated printed defender remains in its owner's graveyard.");
    Check(frame.Events.All(e => e.Event.Kind is not ("PLAYER_SURRENDERED" or "MATCH_SURRENDERED")) && (await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame, new CoreRuleEngine(), default)).Count == 0, "Whole original frame strictly replays without surrender.");
    Check(entry.GetProperty("canonicalColdStages").GetInt32() == expectedCold[branch] && entry.GetProperty("canonicalViewportImages").GetArrayLength() == 4*expectedCold[branch], "Exact canonical SDK same-process paired cold stage and own-viewport coverage.");
    foreach (var image in entry.GetProperty("canonicalViewportImages").EnumerateArray()) Check(Sha(image.GetProperty("path").GetString()!) == image.GetProperty("sha256").GetString(), "Original GPU viewport bytes unchanged; hash verification does not claim visual reading.");
    totals["commands"] += frame.Commands.Count; totals["events"] += frame.Events.Count; totals["authority"] += states.Count;
    totals["snapshots"] += rowCounts["snapshots"]; totals["prompts"] += rowCounts["action_prompts"]; totals["canonicalSdkPairedColdStages"] += expectedCold[branch]; totals["canonicalSdkViewportImages"] += 4*expectedCold[branch];
    results.Add(new { branch, room, originalSevenTableCounts = rowCounts, originalEntirePrefixesActuallyReplayed = frame.Commands.Count });
    Console.WriteLine("INDEPENDENT_FIXED_F0_NATIVE_ORIGINAL_PASS "+branch);
}
Check(seen.SetEquals(expectedCounts.Keys) && top.GetProperty("expectedTotals").EnumerateObject().All(p => totals[p.Name] == p.Value.GetInt32()), "Exact six-branch 43-prefix/116-event/80-each-private/24-clean-control totals.");
await File.WriteAllTextAsync(args[1], JsonSerializer.Serialize(new { status = "PASS_INDEPENDENT_FIXED_F0_SIX_ORIGINAL_NATIVE_ROOMS43_PREFIXES116_EVENTS80_EACH_PRIVATE24_CLEAN_CONTROLS", actualReadOnlyConnection = true,
    actualLoadedFourAssemblies = loaded, totals, rooms = results, everyOriginalFieldNullOmissionAndArrayCompared = true,
    firstOriginalResourceIncompleteMovementRemainsSeparate = true, controlledPositionsNotOrdinaryOpenings = true, ciExportScreenshotHardwarePhysicalWindowsAndWholePrintingsRemainSeparate = true }, json));
static JsonDocument Read(string path) { using var stream = new GZipStream(File.OpenRead(path), CompressionMode.Decompress); return JsonDocument.Parse(stream); }
static string Sha(string path) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path))).ToLowerInvariant();
static bool Same(JsonElement a, JsonElement b) => JsonNode.DeepEquals(JsonNode.Parse(a.GetRawText()), JsonNode.Parse(b.GetRawText()));
static void Check(bool value, string reason) { if (!value) throw new InvalidOperationException(reason); }
