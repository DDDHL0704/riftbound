def launch_sdk_observer(role, stage):
    folder = w/(stage+'-'+role+'-sdk-paired-observer')
    folder.mkdir()
    log = folder/'actual-fixed-production-main-original-console.log'
    scene = home/'actual-fixed-main-paired-observer-v1.tscn'
    args = [str(sdk), '--path', str(fixed_source/'clients/godot'), '--resolution', '1280x720', '--max-fps', '30',
        '--quit-after', '4500', str(scene), '--', '--riftbound-server=http://127.0.0.1:15847',
        '--riftbound-session-file='+str(profiles/('session-'+role+'.json')), '--riftbound-smoke-connect-only',
        '--qa-observer-folder='+str(folder)]
    env = dict(os.environ, DOTNET_DbgEnableMiniDump='0')
    env.pop('DOTNET_STARTUP_HOOKS', None)
    master, slave = pty.openpty()
    sink = log.open('xb', buffering=0)
    p = subprocess.Popen(args, cwd='/tmp', env=env, stdin=subprocess.DEVNULL, stdout=slave, stderr=slave, start_new_session=True)
    os.close(slave)
    def drain():
        try:
            while True:
                try:
                    block = os.read(master, 65536)
                except OSError as error:
                    if error.errno == errno.EIO:
                        break
                    raise
                if not block:
                    break
                sink.write(block)
        finally:
            os.close(master)
            sink.close()
    pump = threading.Thread(target=drain, daemon=True)
    pumps[p.pid] = pump
    pump.start()
    record = dict(role=role, label=stage, pid=p.pid, actualCommand=args, log=str(log), nonHeadless=True,
        ownViewportAndActualFixedSdkProductionMain=True, ciExportedEntryAndOsHardwareNotClaimed=True, noCommandSubmitted=True)
    proof['ownedNativeProcesses'].append(record)
    item = (p, record, log)
    clients.append(item)
    return item, folder


def cold(stage, before):
    local_stable()
    pair = [launch_sdk_observer(role, stage) for role in ['a', 'b']]
    processes = [item[0] for item, folder in pair]
    native_wait(lambda: all(all(log_count(item[2], key) >= 1 for key in ['Joined', 'Snapshot', 'Prompt']) for item, folder in pair),
        'Both actual fixed SDK Main private views before the own-viewport capture', 40, processes)
    for item, folder in pair:
        with (folder/'owner-initial-views-verified.json').open('x') as f:
            json.dump(dict(originalTick=before['authoritativeState']['tick'], noCommandSubmitted=True), f)
    native_wait(lambda: all((folder/'initial-actual-own-viewport-receipt.json').exists() for item, folder in pair),
        'Both actual SDK own viewports from synchronous native drawing', 30, processes)
    counts = [{key: log_count(item[2], key) for key in ['Joined', 'Snapshot', 'Prompt']} for item, folder in pair]
    pid = api.pid
    assert set(subprocess.check_output(['/usr/sbin/lsof', '-tiTCP:15847', '-sTCP:LISTEN'], text=True).splitlines()) == {str(pid)}
    api.kill()
    api.wait(timeout=10)
    assert api.returncode == -9
    start_api(len(proof['ownedApiProcesses'])+1)
    native_wait(lambda: all(all(log_count(item[2], key) > counts[index][key] for key in counts[index]) for index, (item, folder) in enumerate(pair)),
        'Same fixed SDK paired PIDs recover original private views', 50, processes)
    after = export(stage+'-after-same-sdk-pair-cold-original-frame')
    assert all(after[key] == before[key] for key in ['commands', 'events', 'authoritativeState', 'openingSeed', 'replayInitialState'])
    for item, folder in pair:
        with (folder/'owner-restored-views-verified.json').open('x') as f:
            json.dump(dict(originalTick=after['authoritativeState']['tick'], wholeOriginalStateAndHistoryExact=True), f)
    native_wait(lambda: all((folder/'restored-actual-own-viewport-receipt.json').exists() for item, folder in pair),
        'Both actual SDK own viewports after exact cold recovery', 30, processes)
    for (item, folder), role in zip(pair, ['a', 'b']):
        for phase in ['initial', 'restored']:
            receipt = load(folder/(phase+'-actual-own-viewport-receipt.json'))
            assert receipt['displayDriver'] != 'headless' and receipt['productionMainScript'] == 'res://scripts/Main.cs' and receipt['noCommandSubmitted']
            p = folder/('actual-fixed-main-'+phase+'-own-viewport.png')
            assert p.read_bytes().startswith(b'\x89PNG\r\n\x1a\n')
            current['viewportImages'].append(dict(role=role, stage=stage, phase=phase, path=str(p), sha256=sha(p),
                bytes=p.stat().st_size, localFixedSdkProductionMainNotCiExportedEntry=True, actualPixelsNeedSeparateVisualRead=True))
        with (folder/'owner-stop-after-exact-original-recovery.json').open('x') as f:
            json.dump(dict(noGameplaySubmitted=True), f)
    for item, folder in pair:
        wait_exit(item, 15)
    local_stable()
    current['coldRestores'].append(dict(stage=stage, killedOwnApiPid=pid, sameNativePids=processes and [p.pid for p in processes],
        actualFixedSdkOwnGpuPair=True, ciExportedDefaultMainOrOsHardwareNotClaimed=True,
        wholeOriginalStateHistoryOpeningAndEmptyExact=True, lock=observe_lock()))
    print('FIXED_SDK_MAIN_NONHEADLESS_PAIRED_COLD', branch, stage, flush=True)
    return after
