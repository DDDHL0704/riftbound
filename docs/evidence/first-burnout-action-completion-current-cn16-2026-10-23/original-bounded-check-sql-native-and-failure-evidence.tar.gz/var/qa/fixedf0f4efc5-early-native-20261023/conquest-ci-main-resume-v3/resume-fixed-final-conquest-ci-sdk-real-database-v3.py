import ast, datetime, errno, fcntl, gzip, hashlib, json, os, plistlib, pty, re, resource, socket, stat, subprocess, threading, time, urllib.request
from pathlib import Path

resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
os.umask(0o077)
root = Path('/Users/dinghaolin/MyProjects/riftbound')
home = Path(__file__).resolve().parent
candidate = home.parent
pg = Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin')
cluster = root/'var/qa/permanent-play-here-base-20261017/postgres'
sock = Path('/tmp/rft-here-family-20261018-55486')
tables = ['matches', 'match_players', 'command_log', 'game_events', 'state_snapshots', 'snapshots', 'action_prompts']
read_env = dict(os.environ, PGOPTIONS='-c default_transaction_read_only=on')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
functions = root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
native_functions = root/'var/qa/fixed55fdb-early-native-20261022/lab-ci-pair-v1/controlled-lab-native-owner-functions-v1.py'
control_functions = home/'production-controls-and-ci-pair-functions-v3.py'
for source, names in [(functions, {'query', 'rooms', 'digests', 'observe_lock'}),
                      (native_functions, {'start_api', 'export', 'native_wait', 'log_count', 'wait_exit'}),
                      (control_functions, {'local_stable', 'checkpoint', 'count', 'save_rows', 'launch', 'stop', 'cold', 'native'})]:
    for node in ast.parse(source.read_text()).body:
        if isinstance(node, ast.FunctionDef) and node.name in names:
            body = ast.get_source_segment(source.read_text(), node).replace('live-controlled-lab-api-', 'live-fixed-f0-conquest-api-')
            exec(compile('\n'*(node.lineno-1)+body, str(source), 'exec'), globals())

pub_path = candidate/'frozen-fixedf0f4efc5-native-composition-with-ci-apps-v2.json'
pub = load(pub_path)
assert pub['fixedCommit'] == 'f0f4efc54f53af3e0b9043473af365392a243a82'
assert pub['actualRuleInputs']['identitySha256'] == 'f6a8c5a5d869de225aff84106ad7d0bb0f2cbf13c2efd6585bd9bbf381ee29b8'
api_runtime = Path(pub['apiRuntimeRoot'])
helpers = Path(pub['helperRuntimeRoot'])
fixed_source = Path(pub['fixedSourceRoot'])
local_inputs = load(Path(pub['apiBuildInputsManifest']))
assert len(local_inputs['sourceHashes']) == 3380 and len(local_inputs['nativeManagedRuntimeFiles']) == 23
original_owner_home = Path('/Users/dinghaolin/MyProjects/riftbound/var/qa/fixedf0f4efc5-early-native-20261023/conquest-ci-main-v1')
driver_dll = original_owner_home/'gateway-preparation-source-v1/bin/Release/net10.0/FixedF0FinalConquestPrepareV1.dll'
original_profiles = root/'var/qa/fixed5edb1-early-native-20261023/ordinary-ci-pair-v1'
sdk = Path('/Users/dinghaolin/.local/share/riftbound-tools/godot-4.7.2/Godot_mono.app/Contents/MacOS/Godot')
control_source = home/'actual-current-main-final-conquest-controls-v3.gd'
control_scene = home/'actual-current-main-final-conquest-controls-v3.tscn'
own_inputs = {str(p): sha(p) for p in [Path(__file__), functions, native_functions, control_functions, driver_dll,
    driver_dll.with_suffix('.pdb'), original_owner_home/'gateway-preparation-source-v1/Program.cs',
    original_owner_home/'gateway-preparation-source-v1/probe.csproj', control_source, control_scene, sdk, pub_path,
    Path(pub['apiBuildInputsManifest'])]}

def frozen():
    assert all(sha(api_runtime/p) == h for p, h in pub['runtimeFiles'].items())
    assert all(sha(helpers/p) == h for p, h in pub['helperRuntimeFiles'].items())
    assert all(sha(Path(pub['networkRuntimeRoot'])/p) == h for p, h in pub['networkRuntimeFiles'].items())
    assert all(sha(fixed_source/p) == h for p, h in pub['networkSourceHashes'].items())
    assert all(oct(stat.S_IMODE((fixed_source/p).stat().st_mode)) == m for p, m in local_inputs['sourceModes'].items())
    assert all(sha(Path(a['app'])/p) == h for a in pub['nativeApps'] for p, h in pub['ciManagedAndPckPayloads'].items())
    local_stable()

observer_functions = home/'own-viewport-observer-functions-v1.py'
for node in ast.parse(observer_functions.read_text()).body:
    if isinstance(node, ast.FunctionDef):
        body = ast.get_source_segment(observer_functions.read_text(), node)
        exec(compile('\n'*(node.lineno-1)+body, str(observer_functions), 'exec'), globals())
own_inputs.update({str(p):sha(p) for p in [observer_functions, home/'actual-fixed-main-paired-observer-v1.gd', home/'actual-fixed-main-paired-observer-v1.tscn']})

terminal = home/'current-final-conquest-six-live-original-rooms-owner-terminal-v3.json'
assert not terminal.exists()
guard = (root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a+')
fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
proof = dict(status='RUNNING_FIXED_F0_FINAL_CONQUEST_NATIVE_CI_AND_SDK_REAL_POSTGRES', startedAtUtc=now(),
    fixedCommit=pub['fixedCommit'], fixedCiRun=pub['fixedCiRun'], actualRuleInputs=pub['actualRuleInputs'],
    ownInputHashes=own_inputs, ownedApiProcesses=[], ownedNativeProcesses=[], branches=[], lockAtStart=observe_lock(),
    controlledDevPositionsNotOrdinaryOpening=True, ciExportDefaultMainAndSdkProductionButtonsRemainSeparate=True,
    doesNotCertifyOsHardwareOrPhysicalWindows=True, oneLiveProcessPerActor=True,
    source3380IsFixedSnapshotPrimaryRootMayDevelopIndependently=True)
api = driver = power = None
clients = []
pumps = {}
started = False
room = None
audit = prior_native = before_audit = before_native = None
w = profiles = evidence = None
try:
    frozen()
    assert subprocess.run([str(pg/'pg_ctl'), '-D', str(cluster), 'status'], capture_output=True).returncode == 3
    with socket.socket() as s:
        assert s.connect_ex(('127.0.0.1', 15847)) != 0
    power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())])
    proof['boundIdleAssertionPid'] = power.pid
    proof['originalFailureAndAcceptedFourCommandPrefixRetained'] = True
    sock.mkdir(exist_ok=True)
    subprocess.run([str(pg/'pg_ctl'), '-D', str(cluster), '-l', str(home/'owned-current-conquest-postgres-v2.log'),
        '-o', f'-p 55486 -h 127.0.0.1 -k {sock}', '-w', 'start'], capture_output=True, check=True)
    started = True
    audit = rooms('riftbound_acceptance')
    original_failed_owner = load(original_owner_home/'current-final-conquest-six-live-original-rooms-owner-terminal-v1.json')
    original_partial_frame = json.loads(gzip.decompress((original_owner_home/'draw-hold/original-native-records/owner-final-retained-original-frame.json.gz').read_bytes()))
    partial_room = original_failed_owner['branches'][0]['room']
    all_current_native = rooms('riftbound_here_native')
    prior_native = [r for r in all_current_native if r != partial_room]
    assert len(audit) == 436 and len(prior_native) == 118 and len(all_current_native) == 119
    assert set(all_current_native) == set(original_failed_owner['actualNativeRoomsAtStop'])
    before_audit = digests('riftbound_acceptance', audit)
    before_native = digests('riftbound_here_native', prior_native)
    for branch in ['draw-hold', 'win', 'burnout', 'brush-decline', 'brush-return', 'combat']:
        scenario = 'brush' if branch.startswith('brush') else 'draw' if branch == 'draw-hold' else branch
        w = home/branch
        w.mkdir()
        evidence = w/'original-native-records'
        evidence.mkdir()
        profiles = w/'original-controlled-prefix'
        room = None
        start_api(len(proof['ownedApiProcesses'])+1)
        if branch == 'draw-hold':
            room = partial_room
            profiles.mkdir()
            for role in ['a', 'b']:
                subprocess.run(['/bin/cp', '-c', str(original_owner_home/'draw-hold/original-controlled-prefix'/('session-'+role+'.json')), str(profiles/('session-'+role+'.json'))], check=True)
            entry = load(original_owner_home/'draw-hold/original-controlled-prefix/final-conquest-original-entry-v1.json')
            a, b = entry['players']
            first = export('retained-original-four-command-prefix-before-resume')
            assert first['commands'] == original_partial_frame['commands'] and first['events'] == original_partial_frame['events']
            assert first['authoritativeState'] == original_partial_frame['authoritativeState']
            assert first['openingSeed'] == original_partial_frame['openingSeed'] and first['replayInitialState'] == original_partial_frame['replayInitialState']
            assert len(first['commands']) == 4 and first['commands'][-1]['accepted'] and first['commands'][-1]['commandType'] == 'MOVE_UNIT'
        else:
            old_rooms = set(rooms('riftbound_here_native'))
            args = ['/Users/dinghaolin/.dotnet/dotnet', 'exec', '--depsfile', str(helpers/'Fixed708OriginalBandleTreeScoreV1.deps.json'),
                '--runtimeconfig', str(helpers/'Fixed708OriginalBandleTreeScoreV1.runtimeconfig.json'),
                str(driver_dll), str(profiles), str(original_profiles), scenario]
            with (w/'original-explicit-gateway-preparation.log').open('xb') as f:
                driver = subprocess.Popen(args, cwd=helpers, stdout=f, stderr=subprocess.STDOUT,
                    env=dict(os.environ, DOTNET_DbgEnableMiniDump='0'))
                code = driver.wait(timeout=95)
            added = set(rooms('riftbound_here_native'))-old_rooms
            if len(added) == 1:
                room = next(iter(added))
            assert code == 0 and len(added) == 1, 'Original partial room retained; no reset or gameplay resubmission.'
            entry = load(profiles/'final-conquest-original-entry-v1.json')
            assert entry['room'] == room
            a, b = entry['players']
            first = export('initial-three-original-frame')
        assert len(first['commands']) == (4 if branch == 'draw-hold' else 3)
        assert [c['commandType'] for c in first['commands'][:3]] == ['ROOM_SEAT', 'ROOM_SEAT', 'DEV_SEED_SCENARIO:final-conquest-'+scenario]
        assert first['openingSeed'] != 0 and first['replayInitialState']['status'] == 'EMPTY' and not first['replayInitialState']['seats']
        current = dict(branch=branch, scenario=scenario, room=room, players=[a, b], coldRestores=[], nativeCommands=[],
            viewportImages=[], initialOriginalRows=save_rows('initial-all-seven-original-tables.json.gz'))
        proof['branches'].append(current)
        frame = cold('retained-move-before-next-focus' if branch == 'draw-hold' else 'before-original-move', first)
        if branch != 'draw-hold':
            frame = native('MOVE_UNIT', a, 'move-unit-to-original-bf', frame)
        else:
            current['originalRetainedAcceptedMovement'] = load(Path('/Users/dinghaolin/MyProjects/riftbound/var/qa/fixedf0f4efc5-early-native-20261023/conquest-ci-main-resume-v2/original-native-v1-post-submit-capture-timeout-disposition-v1.json'))
        frame = native('PASS_FOCUS', a, 'original-first-focus-pass', frame)
        frame = native('PASS_FOCUS', b, 'original-second-focus-pass', frame)
        if branch == 'combat':
            frame = native('DECLARE_BATTLE', a, 'declare-original-battle', frame)
        state = frame['authoritativeState']
        own = state['playerZones'][a]
        assert state['cardObjects']['BF']['controllerId'] == a
        assert state['playerScores'][a] == (8 if branch == 'win' else 7)
        assert state['playerScores'][b] == (1 if branch == 'burnout' else 0)
        assert state['status'] == ('FINISHED' if branch == 'win' else 'IN_PROGRESS')
        assert state.get('winnerPlayerId') == (a if branch == 'win' else None)
        assert len(own['hand']) == (0 if branch == 'win' else 1) and len(own['mainDeck']) == (3 if branch == 'win' else 2)
        assert sum(e['kind'] == 'BATTLEFIELD_SCORE_REPLACED_BY_DRAW' for e in frame['events']) == (0 if branch == 'win' else 1)
        if branch == 'burnout':
            assert state['rngCursor'] == 1 and not own['graveyard']
            assert sum(e['kind'] == 'BURNOUT_APPLIED' for e in frame['events']) == 1
        if branch == 'combat':
            assert 'DEFENDER' in state['playerZones'][b]['graveyard']
        frame = cold('original-conquest-resolved', frame)
        if branch.startswith('brush'):
            choice = frame['authoritativeState']['pendingCardChoice']
            assert choice['choiceWindow'] == 'TRIGGER_OPTIONAL_CONFIRMATION' and choice['playerId'] == a and choice['legalObjectIds'] == ['BF']
            hand = frame['authoritativeState']['playerZones'][a]['hand']
            frame = native('CHOOSE_CARDS', a, 'original-brush-confirmation', frame, choice_count=int(branch == 'brush-return'))
            if branch == 'brush-return':
                frame = native('PASS_PRIORITY', frame['authoritativeState']['priorityPlayerId'], 'original-brush-first-priority', frame)
                frame = native('PASS_PRIORITY', frame['authoritativeState']['priorityPlayerId'], 'original-brush-second-priority', frame)
            state = frame['authoritativeState']
            assert state['cardObjects']['BF']['cardNo'] == ('OGN·282/298' if branch == 'brush-return' else 'UNL·T03')
            assert state['playerZones'][a]['hand'] == hand and state['playerScores'][a] == 7
            frame = cold('original-brush-choice-completed', frame)
        if branch == 'draw-hold':
            frame = native('END_TURN', a, 'original-first-turn-ended', frame)
            frame = native('END_TURN', b, 'original-second-turn-ended', frame)
            state = frame['authoritativeState']
            assert state['playerScores'][a] == 8 and state['playerScores'][b] == 0 and state['status'] == 'FINISHED' and state['winnerPlayerId'] == a
            assert any(e['kind'] == 'SCORE_GAINED' and e['payload'].get('reason') == 'BATTLEFIELD_HELD_SCORE' for e in frame['events'])
            frame = cold('original-hold-wins-eight-zero', frame)
        assert all(c['accepted'] for c in frame['commands'])
        assert len(frame['commands']) == {'draw-hold': 8, 'win': 6, 'burnout': 6, 'brush-decline': 7, 'brush-return': 9, 'combat': 7}[branch]
        current.update(status='PASS_FIXED_F0_BOUNDED_ORIGINAL_NATIVE_CONQUEST_INDEPENDENT_SQL_READBACK_PENDING',
            commands=len(frame['commands']), events=len(frame['events']), finalOriginalRows=save_rows('final-all-seven-original-tables.json.gz'))
        checkpoint('completed-original-branch-receipt-v1.json', current)
        api.terminate()
        api.wait(timeout=25)
        assert api.returncode == 0
    assert len(set(rooms('riftbound_here_native'))-set(prior_native)) == 6
    proof['status'] = 'PASS_SIX_FRESH_FIXED_F0_ORIGINAL_NATIVE_CONQUEST_ROOMS_AND_PRODUCTION_CONTROLS_INDEPENDENT_READBACK_PENDING'
except BaseException as error:
    proof.update(status='FAILED_CURRENT_FINAL_CONQUEST_NATIVE_OWNER_OR_PRODUCT_ORIGINALS_RETAINED', errorType=type(error).__name__, error=str(error))
    raise
finally:
    if driver is not None and driver.poll() is None:
        driver.terminate()
        driver.wait(timeout=20)
    for p, record, log in clients:
        if p.poll() is None:
            p.terminate()
            p.wait(timeout=20)
            record['onlyOwnFailureCleanup'] = True
        pumps[p.pid].join(timeout=10)
        record.update(exitCode=p.returncode, logSha256=sha(log), ptyFullyDrained=not pumps[p.pid].is_alive())
    if started and room is not None:
        try:
            export('owner-final-retained-original-frame')
        except BaseException as error:
            proof['finalFrameExportError'] = type(error).__name__
    if api is not None and api.poll() is None:
        api.terminate()
        api.wait(timeout=25)
    proof['ownApiStopped'] = api is None or api.poll() is not None
    if started:
        if before_audit is not None:
            proof.update(all436AuditSevenTablesExact=digests('riftbound_acceptance', audit) == before_audit,
                allOriginal118NativeSevenTablesExact=digests('riftbound_here_native', prior_native) == before_native,
                actualAuditRoomsAtStop=rooms('riftbound_acceptance'), actualNativeRoomsAtStop=rooms('riftbound_here_native'))
        proof['ownPostgresSmartStopped'] = subprocess.run([str(pg/'pg_ctl'), '-D', str(cluster), '-m', 'smart', '-w', '-t', '20', 'stop'], capture_output=True).returncode == 0
    if power is not None and power.poll() is None:
        power.terminate()
        power.wait(timeout=10)
    proof.update(finishedAtUtc=now(), lockAtEnd=observe_lock(), allOwnInputsStable=all(sha(Path(p)) == h for p, h in own_inputs.items()),
        frozenSource3380ManifestSha256=sha(Path(pub['apiBuildInputsManifest'])), sourceAndRuntimeMustRemainFixed=True)
    frozen()
    with terminal.open('x') as f:
        json.dump(proof, f, ensure_ascii=False, indent=2)
    fcntl.flock(guard, fcntl.LOCK_UN)
assert all(proof[k] for k in ['ownApiStopped', 'ownPostgresSmartStopped', 'all436AuditSevenTablesExact', 'allOriginal118NativeSevenTablesExact', 'allOwnInputsStable'])
print(proof['status'], flush=True)
