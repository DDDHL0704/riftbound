extends Node

var folder: String
var main: Node
var limit: int

func _ready() -> void:
	main = get_node("Main")
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--qa-observer-folder="): folder = arg.trim_prefix("--qa-observer-folder=")
	if folder.is_empty():
		get_tree().quit(1)
		return
	limit = Time.get_ticks_msec() + 90000
	for stage in ["initial", "restored"]:
		while not FileAccess.file_exists(folder.path_join("owner-" + stage + "-views-verified.json")) and Time.get_ticks_msec() < limit:
			await get_tree().create_timer(0.05).timeout
		if Time.get_ticks_msec() >= limit:
			push_error("Original paired private views were not independently verified before capture.")
			get_tree().quit(1)
			return
		await get_tree().process_frame
		RenderingServer.force_draw()
		var path := folder.path_join("actual-fixed-main-" + stage + "-own-viewport.png")
		if FileAccess.file_exists(path) or get_viewport().get_texture().get_image().save_png(path) != OK:
			push_error("Actual own viewport could not be recorded without overwriting evidence.")
			get_tree().quit(1)
			return
		var file := FileAccess.open(folder.path_join(stage + "-actual-own-viewport-receipt.json"), FileAccess.WRITE)
		file.store_string(JSON.stringify({"stage": stage, "displayDriver": DisplayServer.get_name(), "productionMainScript": main.get_script().resource_path,
			"actualOwnViewport": path, "noCommandSubmitted": true, "localSdkFixedMainNotCiExportedEntryOrOsHardware": true}))
		file.close()
	while not FileAccess.file_exists(folder.path_join("owner-stop-after-exact-original-recovery.json")) and Time.get_ticks_msec() < limit:
		await get_tree().create_timer(0.05).timeout
	if Time.get_ticks_msec() >= limit:
		get_tree().quit(1)
		return
	main.queue_free()
	await get_tree().process_frame
	get_tree().quit(0)
