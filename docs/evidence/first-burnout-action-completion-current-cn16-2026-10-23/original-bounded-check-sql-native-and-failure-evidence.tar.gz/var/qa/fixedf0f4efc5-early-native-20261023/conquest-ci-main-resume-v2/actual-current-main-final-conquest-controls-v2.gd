extends Node

var folder: String
var plan: Dictionary
var main: Node
var deadline: int
var presses: Array = []

func _ready() -> void:
	main = get_node("Main")
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--qa-action-folder="): folder = arg.trim_prefix("--qa-action-folder=")
	if folder.is_empty():
		_fail("Exact fresh original action evidence directory required.")
		return
	plan = JSON.parse_string(FileAccess.get_file_as_string(folder.path_join("original-server-action-plan.json")))
	deadline = Time.get_ticks_msec() + 60000
	while Time.get_ticks_msec() < deadline:
		var candidates := _buttons(str(plan["actionLabel"]))
		if candidates.size() == 1 and not candidates[0].disabled: break
		await get_tree().create_timer(0.05).timeout
	var actions := _buttons(str(plan["actionLabel"]))
	if actions.size() != 1 or not _press(actions[0], str(plan["action"])): return
	await get_tree().process_frame
	if plan["action"] == "MOVE_UNIT":
		var movement_confirm := _one("ConfirmMovementButton")
		if movement_confirm == null:
			_fail("One visible actual production movement composer required.")
			return
		var movement_layout := movement_confirm.get_parent().get_parent()
		var movement_options: Array = []
		for node in movement_layout.find_children("*", "OptionButton", true, false):
			if node.is_visible_in_tree(): movement_options.append(node)
		var destination_index := int(plan.get("movementDestinationIndex", -1))
		if movement_options.size() != 1 or movement_options[0].item_count != int(plan["movementExpectedDestinationCount"]) or destination_index < 0 or destination_index >= movement_options[0].item_count:
			_fail("The exact original public destination must have one actual native option.")
			return
		var destination: OptionButton = movement_options[0]
		destination.select(destination_index)
		presses.append({"node": str(main.get_path_to(destination)), "meaning": "EXACT_ORIGINAL_MOVEMENT_DESTINATION", "nativeSelectedIndex": destination_index, "text": destination.get_item_text(destination_index)})
		destination.emit_signal("item_selected", destination_index)
		await get_tree().process_frame
		var movement_checks: Array = []
		for node in movement_layout.find_children("*", "CheckBox", true, false):
			if node.is_visible_in_tree(): movement_checks.append(node)
		if movement_checks.size() != 1 or movement_checks[0].disabled or movement_checks[0].button_pressed:
			_fail("One original unselected, enabled public unit checkbox required.")
			return
		movement_checks[0].button_pressed = true
		presses.append({"node": str(main.get_path_to(movement_checks[0])), "meaning": "ACTUAL_PUBLIC_UNIT_CHECKBOX_TOGGLED", "text": movement_checks[0].text})
		await get_tree().process_frame
		if not await _capture("actual-production-movement-before-confirm.png"): return
		if not _write("actual-production-movement-before-confirm.json", _state()): return
		if not _press(movement_confirm, "CONFIRM_ACTUAL_SIMULTANEOUS_MOVEMENT_COMPOSER"): return
	elif plan["action"] == "DECLARE_BATTLE":
		var battle_confirm := _one("ConfirmBattleButton")
		if battle_confirm == null or battle_confirm.disabled:
			_fail("Actual unique server participants must enable production battle confirmation.")
			return
		if not await _capture("actual-production-battle-before-confirm.png"): return
		if not _write("actual-production-battle-before-confirm.json", _state()): return
		if not _press(battle_confirm, "CONFIRM_ACTUAL_UNIQUE_PARTICIPANTS_AND_REQUIRED_COSTS"): return
	elif plan["action"] == "PLAY_CARD":
		for node in main.find_children("*", "OptionButton", true, false):
			if node.is_visible_in_tree() and node.item_count > 1 and node.get_item_text(0) == "请选择目标":
				node.select(1)
				presses.append({"node": str(main.get_path_to(node)), "meaning": "FIRST_SERVER_TARGET", "nativeSelectedIndex": 1, "text": node.get_item_text(1)})
				node.emit_signal("item_selected", 1)
		for label in plan.get("optionalCostLabels", []):
			var checks: Array = []
			for node in main.find_children("*", "CheckBox", true, false):
				if node.is_visible_in_tree() and node.text == label: checks.append(node)
			if checks.size() != 1 or checks[0].disabled:
				_fail("One actual enabled optional-cost checkbox is required.")
				return
			checks[0].button_pressed = true
			presses.append({"node": str(main.get_path_to(checks[0])), "meaning": "OPTIONAL_COST", "text": label})
		var confirm := _one("ConfirmPlayCardButton")
		while (confirm == null or confirm.disabled) and Time.get_ticks_msec() < deadline:
			await get_tree().create_timer(0.05).timeout
			confirm = _one("ConfirmPlayCardButton")
		if confirm == null or confirm.disabled:
			_fail("Actual production composer did not obtain an affordable current backend quote.")
			return
		if not await _capture("actual-production-play-composer-before-confirm.png"): return
		if not _write("actual-production-composer-before-confirm.json", _state()): return
		if not _press(confirm, "CONFIRM_PLAY_AFTER_ACTUAL_BACKEND_QUOTE"): return
	elif plan["action"] in ["CHOOSE_CARDS", "PAY_COST"]:
		var containers: Array = []
		for node in main.find_children("StepChoices", "HBoxContainer", true, false):
			if node.is_visible_in_tree(): containers.append(node)
		if containers.size() != 1:
			_fail("One actual current production choice row required.")
			return
		var choices: Array = []
		for node in containers[0].get_children():
			if node is Button and node.is_visible_in_tree(): choices.append(node)
		if int(plan.get("choiceCount", 1)) > 0:
			var choice_index: int = int(plan.get("choiceIndex", 0))
			if choice_index < 0 or choice_index >= choices.size():
				_fail("The exact original server choice has no actual native button.")
				return
			if not _press(choices[choice_index], "EXACT_ACTUAL_SERVER_CHOICE_INDEX:" + str(choice_index)): return
		await get_tree().process_frame
		var submit := _one("SubmitButton")
		if submit == null or submit.disabled:
			_fail("The actual selected native choice must enable confirmation.")
			return
		if not await _capture("actual-production-private-choice-before-confirm.png"): return
		if not _write("actual-production-choice-before-confirm.json", _state()): return
		if not _press(submit, "CONFIRM_ACTUAL_NATIVE_SELECTION"): return
	elif plan["action"] not in ["PASS_PRIORITY", "PASS_FOCUS", "END_TURN"]:
		_fail("Only the finite recorded movement, battle, choice, payment, focus and turn actions are allowed.")
		return
	if not _write("actual-production-buttons-submitted.json", _state()): return
	while not FileAccess.file_exists(folder.path_join("actual-owner-post-command-views-verified.json")) and Time.get_ticks_msec() < deadline:
		await get_tree().create_timer(0.05).timeout
	if not FileAccess.file_exists(folder.path_join("actual-owner-post-command-views-verified.json")):
		_fail("Original native submission and both fresh server views were not verified.")
		return
	if not await _capture("actual-production-main-after-original-command.png"): return
	if not _write("actual-production-main-controls-terminal.json", _state()): return
	main.queue_free()
	await get_tree().process_frame
	get_tree().quit(0)

func _buttons(text: String) -> Array:
	var found: Array = []
	for node in main.find_children("*", "Button", true, false):
		if node.is_visible_in_tree() and node.text == text: found.append(node)
	return found

func _one(name: String) -> Button:
	var found: Array = []
	for node in main.find_children(name, "Button", true, false):
		if node.is_visible_in_tree(): found.append(node)
	return found[0] if found.size() == 1 else null

func _press(button: Button, meaning: String) -> bool:
	if button.disabled or not button.is_visible_in_tree():
		_fail("Actual production button is hidden or disabled: " + meaning)
		return false
	presses.append({"node": str(main.get_path_to(button)), "text": button.text, "meaning": meaning})
	button.emit_signal("pressed")
	return true

func _capture(name: String) -> bool:
	var path := folder.path_join(name)
	if FileAccess.file_exists(path):
		_fail("Do not overwrite original native pixels.")
		return false
	RenderingServer.force_draw()
	var result := get_viewport().get_texture().get_image().save_png(path)
	if result != OK:
		_fail("Actual native GPU own-viewport save failed.")
		return false
	return true

func _state() -> Dictionary:
	var labels: Array = []
	var buttons: Array = []
	for node in main.find_children("*", "Label", true, false):
		if node.is_visible_in_tree() and not node.text.is_empty(): labels.append({"node": str(main.get_path_to(node)), "text": node.text})
	for node in main.find_children("*", "Button", true, false):
		if node.is_visible_in_tree(): buttons.append({"node": str(main.get_path_to(node)), "text": node.text, "disabled": node.disabled})
	return {"scope": "ACTUAL_CURRENT_SOURCE_LOCAL_SDK_MAIN_PRODUCTION_CONTROLS_AND_GPU_NOT_CI_EXPORTED_ENTRY_OR_OS_HARDWARE_OR_PHYSICAL_WINDOWS", "fixedCommit": plan.get("fixedCommit"), "room": plan.get("room"), "action": plan.get("action"), "productionMainScript": main.get_script().resource_path, "displayDriver": DisplayServer.get_name(), "buttonSignals": presses, "labels": labels, "buttons": buttons, "noAuthValuesOrLineEditsRecorded": true}

func _write(name: String, value: Dictionary) -> bool:
	var path := folder.path_join(name)
	if FileAccess.file_exists(path):
		push_error("Original evidence must not be overwritten.")
		get_tree().quit(1)
		return false
	var file := FileAccess.open(path, FileAccess.WRITE)
	file.store_string(JSON.stringify(value, "\t"))
	file.close()
	return true

func _fail(reason: String) -> void:
	push_error(reason)
	if not folder.is_empty():
		var state := _state()
		state["failure"] = reason
		_write("actual-native-controls-failure.json", state)
	get_tree().quit(1)
