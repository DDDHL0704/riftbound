using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

if (args.SequenceEqual(new[] { "--identity" })) { Console.WriteLine(JsonSerializer.Serialize(RuleInputIdentity.Current, new JsonSerializerOptions(JsonSerializerDefaults.Web))); return; }
Check(args.Length == 2 && !File.Exists(args[1]), "Exact original evidence and fresh independent output required.");
var work = Path.GetFullPath(args[0]); var output = Path.GetFullPath(args[1]);
var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
var settings = new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
Check(settings.Host == "127.0.0.1" && settings.Port == 55486 && settings.Database == "riftbound_acceptance" && settings.Username == "codex_riftbound_audit", "Only own audit SQL database.");
settings.Options = "-c default_transaction_read_only=on";
await using var source = NpgsqlDataSource.Create(settings.ConnectionString);
var expectedCases = new HashSet<(string, bool, int, int)>();
foreach (var printing in new[] { "UNL-118/219", "UNL-118a/219" }) foreach (var copies in new[] { 0, 2 }) expectedCases.Add((printing, true, copies, 0));
foreach (var printing in new[] { "SFD·116/221", "SFD·233/221", "SFD·233*/221" }) foreach (var copies in new[] { 0, 2 }) foreach (var power in new[] { 0, 5 }) expectedCases.Add((printing, false, copies, power));
var seenCases = new HashSet<(string, bool, int, int)>(); var rooms = new List<string>(); var results = new List<object>();
var totalStates = 0; var totalSnapshots = 0; var totalPrompts = 0; var totalCommands = 0; var totalEvents = 0; var rejections = 0;
foreach (var receiptPath in Directory.GetFiles(work, "receipt.json", SearchOption.AllDirectories).Order(StringComparer.Ordinal))
{
    var folder = Path.GetDirectoryName(receiptPath)!; using var receipt = JsonDocument.Parse(File.ReadAllText(receiptPath)); var row = receipt.RootElement;
    var printing = row.GetProperty("printing").GetString()!; var perLocation = row.GetProperty("perLocation").GetBoolean(); var copies = row.GetProperty("copies").GetInt32(); var power = row.GetProperty("power").GetInt32();
    var room = row.GetProperty("room").GetString()!; rooms.Add(room); var count = perLocation ? 4 : 6; var pendingCount = perLocation ? 1 : 3;
    Check(expectedCases.Contains((printing, perLocation, copies, power)) && seenCases.Add((printing, perLocation, copies, power)) && row.GetProperty("rootIntegration").GetBoolean() && row.GetProperty("commands").GetInt32() == count && row.GetProperty("pendingCommandCount").GetInt32() == pendingCount, "Exact finite printing/branch set, no duplicated or missing case.");
    var initial = JsonSerializer.Deserialize<MatchState>(File.ReadAllText(Path.Combine(folder, "explicit-original-controlled-initial.json")), json)!;
    Check(initial.RoomId == room && initial.Tick == 0 && initial.RuleInputs == RuleInputIdentity.Current && initial.CardObjects["SOURCE"].CardNo == printing && initial.CardObjects["SOURCE"].ControllerId == "P1", "Exact original controlled initial, printing, controller and actual executing rule input identity.");
    Check(initial.CardObjects["FIELD"].CardNo == "OGN·296/298" && initial.ObjectLocations["TARGET"].Zone == (perLocation ? "BATTLEFIELD" : "BASE") && (!perLocation || initial.ObjectLocations["TARGET"].BattlefieldObjectId == "FIELD"), "Literal current Void Gate and target-local eligibility; source battlefield is not a base target's location.");
    var annies = initial.CardObjects.Values.Where(c => c.CardNo == "OGS·001/024").ToArray();
    Check(annies.Length == copies && annies.All(c => c.ControllerId == "P1" && !c.IsFaceDown && initial.PlayerZones["P1"].Base.Contains(c.ObjectId)), "Independent literal face-up controlled on-field Annie count; no writer or production numeric bonus derivation.");
    Check(initial.CardObjects["SOURCE"].Power == (perLocation ? 10 : power) && initial.PlayerZones["P2"].Hand.SequenceEqual(new[] { "SECRET_HAND" }) && initial.PlayerZones["P2"].MainDeck.SequenceEqual(new[] { "SECRET_DECK" }), "Literal source Might and independent hidden control cards.");
    var frame = await new PostgresMatchRecoveryStore(source).LoadAsync(room, default) ?? throw new Exception("Real retained SQL frame required.");
    using var original = Read(Path.Combine(folder, $"step-{count:D2}-original-frame.json.gz"));
    Check(Same(original.RootElement, JsonSerializer.SerializeToElement(frame, json)) && frame.IsConsistent && frame.Commands.Count == count && frame.Events.Count == row.GetProperty("events").GetInt32(), "Entire original final SQL frame, every field/null/omission and actual original counts.");
    Check(frame.ReplayInitialState is { Tick: 0, CardObjects.Count: 0 } && !Same(JsonSerializer.SerializeToElement(initial, json), JsonSerializer.SerializeToElement(frame.ReplayInitialState, json)), "Original blank replay metadata is retained separately from the explicit controlled initial, without rewriting either.");
    using var intents = JsonDocument.Parse(File.ReadAllText(Path.Combine(folder, "all-original-accepted-intents.json")));
    Check(intents.RootElement.GetArrayLength() == count, "Every original accepted intent retained.");
    for (var i = 0; i < count; i++)
    {
        using var stepIntent = JsonDocument.Parse(File.ReadAllText(Path.Combine(folder, $"step-{i + 1:D2}-original-intent.json")));
        Check(Same(stepIntent.RootElement, intents.RootElement[i]) && frame.Commands[i].Accepted && frame.Commands[i].RuleInputs == RuleInputIdentity.Current && frame.Commands[i].PlayerId == intents.RootElement[i].GetProperty("actor").GetString() && Same(frame.Commands[i].RawCommand!.Value, intents.RootElement[i].GetProperty("rawCommand")), "Every accepted actor, complete raw intent, immediately retained original input and rule input identity exact.");
    }
    var states = new Dictionary<(long, long), MatchState>(); var counts = new Dictionary<string, int>();
    await using (var connection = await source.OpenConnectionAsync())
    {
        Check((string)(await new NpgsqlCommand("show transaction_read_only", connection).ExecuteScalarAsync())! == "on", "Actual read-only SQL connection.");
        await using (var query = new NpgsqlCommand("select last_event_sequence,payload::text from state_snapshots where match_id=@room order by id", connection))
        {
            query.Parameters.AddWithValue("room", room); await using var rows = await query.ExecuteReaderAsync();
            while (await rows.ReadAsync())
            {
                var raw = rows.GetString(1); var state = JsonSerializer.Deserialize<MatchState>(raw, json)!;
                Check(JsonNode.DeepEquals(JsonNode.Parse(raw), JsonSerializer.SerializeToNode(state, json)) && state.RuleInputs == RuleInputIdentity.Current && states.TryAdd((state.Tick, rows.GetInt64(0)), state), "Every original historical authority field, null, omission, tick/sequence and current rule identity.");
                Check(state.CardObjects["SOURCE"].CardNo == printing && state.CardObjects["FIELD"].CardNo == "OGN·296/298" && state.PlayerZones["P2"].Hand.SequenceEqual(new[] { "SECRET_HAND" }) && state.PlayerZones["P2"].MainDeck.SequenceEqual(new[] { "SECRET_DECK" }), "All histories retain exact sources and unrelated hidden objects.");
                if (!perLocation) Check(state.CardObjects["TARGET"].Damage == 0 || state.CardObjects["TARGET"].Damage == power + copies, "Only the literal current Might plus independent controller bonus can be marked on the base target.");
                if (state.PendingCardChoice is { } choice) Check(choice.PlayerId == "P1" && choice.RequiredCount == (perLocation ? 0 : 1) && choice.MaxCount == (perLocation ? 2 : 1) && choice.SourceObjectId == "SOURCE", "Literal pending source/actor/count in every historical selection window.");
            }
        }
        Check(states.Count == count && frame.Commands.All(c => states.ContainsKey((c.CompletedTick, c.CompletedEventSequence))), "Every accepted command has its exact authoritative historical row.");
        var latest = frame.Commands.GroupBy(c => c.CompletedTick).Select(g => g.OrderBy(c => c.CompletedEventSequence).Last()).ToArray();
        var expectedPrivate = latest.SelectMany(c => new[] { "P1", "P2" }.Select(actor => (c.CompletedTick, c.CompletedEventSequence, actor))).ToHashSet();
        foreach (var table in new[] { "snapshots", "action_prompts" })
        {
            var column = table == "snapshots" ? "snapshot_tick" : "prompt_tick";
            await using (var constraint = new NpgsqlCommand($"select pg_get_constraintdef(oid) from pg_constraint where conrelid='{table}'::regclass and contype='u'", connection)) Check((string)(await constraint.ExecuteScalarAsync())! == $"UNIQUE (match_id, player_id, {column})", "Actual existing private storage key, without schema migration.");
            await using var query = new NpgsqlCommand($"select player_id,last_event_sequence,payload::text from {table} where match_id=@room order by id", connection);
            query.Parameters.AddWithValue("room", room); await using var rows = await query.ExecuteReaderAsync(); var actual = new HashSet<(long, long, string)>();
            while (await rows.ReadAsync())
            {
                var actor = rows.GetString(0); var sequence = rows.GetInt64(1); var raw = rows.GetString(2); using var document = JsonDocument.Parse(raw);
                var tick = document.RootElement.GetProperty(table == "snapshots" ? "tick" : "snapshotTick").GetInt64();
                Check(states.TryGetValue((tick, sequence), out var state) && actual.Add((tick, sequence, actor)), "Each unique private original row binds the exact authority, sequence, tick and viewer.");
                var typed = table == "snapshots" ? JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<SnapshotDto>(raw, json), json) : JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<ActionPromptDto>(raw, json), json);
                Check(JsonNode.DeepEquals(JsonNode.Parse(raw), typed), "Every original private field, null and conditional omission survives typed read.");
                var projected = table == "snapshots" ? JsonSerializer.SerializeToNode(ResolutionResult.BuildSnapshots(state!)[actor], json) : JsonSerializer.SerializeToNode(ResolutionResult.BuildPrompts(state!)[actor], json);
                Check(JsonNode.DeepEquals(JsonNode.Parse(raw), projected), "Every original stored private value equals its exact historical state projection.");
                var other = actor == "P1" ? "P2" : "P1";
                foreach (var id in state!.PlayerZones[other].MainDeck.Concat(state.PlayerZones[other].Hand)) Check(!raw.Contains("\"" + id + "\"", StringComparison.Ordinal), "Literal opponent hidden hand/deck identity is absent.");
                Check(!document.RootElement.TryGetProperty("openingSeed", out _), "Private opening seed is absent from snapshots and prompts.");
            }
            Check(actual.SetEquals(expectedPrivate), "Both viewers retain exactly the latest original projection at every tick, under the actual existing key; no authoritative history is omitted."); counts[table] = actual.Count;
        }
    }
    foreach (var pair in states)
    {
        var commands = frame.Commands.Where(c => c.CompletedEventSequence <= pair.Key.Item2).ToArray(); var events = frame.Events.Where(e => e.Sequence <= pair.Key.Item2).ToArray();
        var verified = await MatchActionLogReplayer.VerifyFinalStateAsync(initial, commands, pair.Value, new CoreRuleEngine(), default, events);
        Check(verified.IsMatch, "Every original historical authority independently replays from its exact controlled initial: " + string.Join(';', verified.Errors));
    }
    using var pendingDocument = Read(Path.Combine(folder, $"step-{pendingCount:D2}-original-frame.json.gz")); var pending = pendingDocument.RootElement.Deserialize<MatchRecoveryFrame>(json)!;
    var pendingState = pending.AuthoritativeState!; var choiceBefore = pendingState.PendingCardChoice!;
    Check(pending.Commands.Count == pendingCount && pending.Events.All(e => e.Event.Kind != "DAMAGE_APPLIED") && choiceBefore.PlayerId == "P1" && choiceBefore.LegalObjectIds.Order().SequenceEqual(perLocation ? new[] { "BASE_TARGET", "TARGET", "UNSELECTED" } : new[] { "TARGET" }), "Exact original per-location/base choice precedes damage.");
    foreach (var bad in new[] { choiceBefore with { PlayerId = "P2" }, choiceBefore with { LegalObjectIds = ["SOURCE"] }, choiceBefore with { SourceObjectId = "TARGET" }, choiceBefore with { RequiredCount = perLocation ? 1 : 0 } })
    {
        Check(MatchRecoveryValidator.Validate(room, pending.LastEventSequence, pending.Commands, pending.Events, pending.PlayerViews, pendingState with { PendingCardChoice = bad }, pending.CurrentTick, pending.SpectatorReplayFrame).Count > 0, "Independent actor/target/source/count substitution rejects against all eight original recovery inputs."); rejections++;
    }
    var final = frame.AuthoritativeState!; var damage = frame.Events.Where(e => e.Event.Kind == "DAMAGE_APPLIED").Select(e => JsonSerializer.SerializeToElement(e.Event.Payload, json)).ToArray();
    if (perLocation)
    {
        Check(damage.Length == 2 && Damage("TARGET") == copies + 2 && Damage("BASE_TARGET") == copies + 1, "Independent literal one base damage plus current Annie copies, with one extra only at the Void target.");
        Check(final.PlayerZones["P2"].Graveyard.Contains("TARGET") && final.PlayerZones["P2"].Graveyard.Contains("BASE_TARGET") && final.PlayerZones["P2"].Battlefields.Contains("UNSELECTED") && final.CardObjects["UNSELECTED"].Damage == 0, "Only the two original selected targets die under the existing Elder passive.");
    }
    else
    {
        Check(damage.Length == (power + copies == 0 ? 0 : 1) && final.CardObjects["TARGET"].Damage == power + copies && (power + copies == 0 || Damage("TARGET") == power + copies), "A zero-valued declared Might instruction can receive a bonus; absent bonus it stays without effective damage. The base target never receives the source's local Void bonus.");
        Check(final.PlayerZones["P2"].Base.Contains("TARGET") && final.PlayerScores["P1"] == 1, "Original base target and ordinary one-point conquest.");
    }
    Check(Same(JsonSerializer.SerializeToElement(pendingState.RunePools, json), JsonSerializer.SerializeToElement(final.RunePools, json)) && final.RngCursor == initial.RngCursor, "Original paid resources remain exact throughout confirmation/response and RNG is unchanged.");
    totalStates += states.Count; totalSnapshots += counts["snapshots"]; totalPrompts += counts["action_prompts"]; totalCommands += count; totalEvents += frame.Events.Count;
    results.Add(new { printing, perLocation, copies, power, room, commands = count, events = frame.Events.Count, historicalStates = states.Count, privateSnapshots = counts["snapshots"], privatePrompts = counts["action_prompts"], everyOriginalFieldAndHistoricalReplayExact = true });
    int Damage(string target) => damage.Single(e => e.GetProperty("targetObjectId").GetString() == target).GetProperty("damage").GetInt32();
}
Check(seenCases.SetEquals(expectedCases) && rooms.Distinct().Count() == 16 && totalCommands == 88 && totalStates == 88 && rejections == 64, "All sixteen original cases execute exactly once, with all 88 original histories and 64 independent structural rejections.");
await File.WriteAllTextAsync(output, JsonSerializer.Serialize(new { status = "PASS_INDEPENDENT_CURRENT_SPECIAL_TRIGGER_FIVE_PRINTINGS_SIXTEEN_BRANCHES_ALL_HISTORY_ORIGINAL_REPLAY", cases = 16, rooms, commands = totalCommands, events = totalEvents, authoritativeHistoricalStates = totalStates, privateSnapshots = totalSnapshots, privatePrompts = totalPrompts, independentStructuralRejections = rejections, actualRuleInputs = RuleInputIdentity.Current, results, actualReadOnlyConnection = true, originalBlankReplayMetadataNotRewritten = true, wholePrintingOrProductCertification = false }, json));
Console.WriteLine($"SPECIAL_TRIGGER_DAMAGE_INDEPENDENT_PASS {totalCommands} commands {totalEvents} events {totalStates} states {totalSnapshots} snapshots {totalPrompts} prompts {rejections} structural rejects");
static JsonDocument Read(string path) { using var zip = new GZipStream(File.OpenRead(path), CompressionMode.Decompress); return JsonDocument.Parse(zip); }
static void Check(bool value, string message) { if (!value) throw new Exception(message); }
static bool Same(JsonElement left, JsonElement right) => JsonNode.DeepEquals(JsonNode.Parse(left.GetRawText()), JsonNode.Parse(right.GetRawText()));
