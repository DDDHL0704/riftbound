from pathlib import Path
import ast,datetime,fcntl,hashlib,json,os,plistlib,resource,socket,subprocess
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts']
read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
definition=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes=[n for n in ast.parse(definition.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(definition),'exec'),globals())
frozen=load(w/'current-special-trigger-frozen-runtime-inputs-v1.json');runtime=Path(frozen['runtimeRoot'])
old=load(root/'var/qa/fixed7a-early-native-20261021/live-current-ci-main-owner-terminal-v3.json');assert old['status'].startswith('PASS_FIXED7A') and old['ownPostgresSmartStopped'];old_audit=old['actualAuditRoomsAtStop'];old_native=old['actualNativeRoomsAtStop'];assert len(old_audit)==300 and len(old_native)==65
stable=lambda:all(sha(runtime/p)==h for p,h in frozen['runtimeFiles'].items()) and all(sha(root/p)==h and oct((root/p).stat().st_mode&0o777)==frozen['sourceInputModes'][p] for p,h in frozen['sourceInputHashes'].items())
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
terminal=w/'actual-current-special-trigger-sql-owner-terminal-v1.json';assert not terminal.exists()
proof={'status':'RUNNING_CURRENT_SPECIAL_TRIGGER_SQL','startedAtUtc':now(),'parentCommit':frozen['parentCommit'],'actualRuleInputs':frozen['actualRuleInputs'],'declaredUncommittedBoundedBatch':True,'lockAtStart':observe_lock(),'allOriginalRoomsActionsAndReplayMetadataRetained':True,'original55SqlIdentitiesAndOrderRetainedOnly56thAppended':True}
started=False;power=writer=independent=None;before_audit=before_native=None
try:
 assert stable();assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid;sock.mkdir(exist_ok=True)
 subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'current-special-trigger-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 assert rooms('riftbound_acceptance')==old_audit and rooms('riftbound_here_native')==old_native
 before_audit=digests('riftbound_acceptance',old_audit);before_native=digests('riftbound_here_native',old_native)
 (w/'original300-audit65-native-seven-table-baseline-v1.json').write_text(json.dumps({'atUtc':now(),'auditRooms':old_audit,'nativeRooms':old_native,'auditSevenTables':before_audit,'nativeSevenTables':before_native},indent=2)+'\n')
 previous_native=root/'var/qa/fixed7a-early-native-20261021';partial=load(previous_native/'late-original-partial-reader-frozen-v1.json');api_manifest=load(previous_native/partial['apiFrozenManifest']);api_runtime=Path(api_manifest['runtimeRoot']);assert all(sha(api_runtime/p)==h for p,h in api_manifest['runtimeFiles'].items()) and all(sha(previous_native/p)==h for p,h in partial['executedBits'].items())
 partial_result=previous_native/'independent-original-first-late-partial-all-history-v1.json';assert not partial_result.exists();partial_command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',partial['depsfile'],'--runtimeconfig',partial['runtimeconfig'],str(previous_native/'late-original-partial-reader-executed-v1/Fixed7aLateOriginalPartialReaderV1.dll'),str(previous_native/'actual-safe-native-main-v2/original-failed-prefix-without-reset.json.gz'),str(partial_result)];proof['actualPreviousFixed7aLatePartialReadCommand']=partial_command
 with (previous_native/'independent-original-first-late-partial-all-history-v1.log').open('xb') as log:independent=subprocess.Popen(partial_command,cwd=api_runtime,env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit',DOTNET_DbgEnableMiniDump='0'),stdout=log,stderr=subprocess.STDOUT);proof['previousFixed7aPartialReaderExitCode']=independent.wait(timeout=180)
 assert proof['previousFixed7aPartialReaderExitCode']==0;proof['previousFixed7aOriginalPartialIndependentlyRetainedAndAll67HistoriesReplayed']=load(partial_result);assert digests('riftbound_here_native',old_native)==before_native
 output=w/'actual-current-special-trigger-sql-v1';assert not output.exists()
 env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit',RIFTBOUND_POSTGRES_EVIDENCE=str(output),DOTNET_DbgEnableMiniDump='0')
 command=['/Users/dinghaolin/.dotnet/dotnet',str(runtime/'Riftbound.PostgresAcceptance.dll'),'--special-trigger-damage-bonus-only'];proof['actualWriterCommand']=command
 with (w/'actual-current-special-trigger-writer-v1.log').open('xb') as log:writer=subprocess.Popen(command,cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT);proof['writerExitCode']=writer.wait(timeout=300)
 assert proof['writerExitCode']==0
 receipts=[load(p) for p in (output/'special-trigger-damage-bonus').rglob('receipt.json')];assert len(receipts)==16
 expected={(p,True,c,0) for p in ['UNL-118/219','UNL-118a/219'] for c in [0,2]}|{(p,False,c,power) for p in ['SFD·116/221','SFD·233/221','SFD·233*/221'] for c in [0,2] for power in [0,5]};assert {(r['printing'],r['perLocation'],r['copies'],r['power']) for r in receipts}==expected
 assert all(r['commands']==r['coldRecoveries']==(4 if r['perLocation'] else 6) and r['directAtomicRejections']==r['independentStructuralRejections']==4 and r['rootIntegration'] and r['actualRuleInputs']==frozen['actualRuleInputs'] for r in receipts)
 added={r['room'] for r in receipts};assert len(added)==16 and set(rooms('riftbound_acceptance'))==set(old_audit)|added and rooms('riftbound_here_native')==old_native
 proof.update(writerCases=16,receipts=receipts,commands=88,events=sum(r['events'] for r in receipts),coldRecoveries=88,directAtomicRejections=64,writerIndependentStructuralRejections=64,newRooms=sorted(added));print('CURRENT_SPECIAL_TRIGGER_SQL_WRITER_PASS16cases88commands',flush=True)
 result=w/'independent-current-special-trigger-all-history-v1.json';command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(runtime/'Riftbound.PostgresAcceptance.deps.json'),'--runtimeconfig',str(runtime/'Riftbound.PostgresAcceptance.runtimeconfig.json'),str(runtime/'CurrentSpecialTriggerIndependentReaderV1.dll'),str(output/'special-trigger-damage-bonus'),str(result)];proof['actualReadOnlyReaderCommand']=command
 with (w/'independent-current-special-trigger-all-history-v1.log').open('xb') as log:independent=subprocess.Popen(command,cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT);proof['independentExitCode']=independent.wait(timeout=300)
 assert proof['independentExitCode']==0
 actual=load(result);proof['independentReadback']=actual;assert actual['cases']==16 and actual['commands']==actual['authoritativeHistoricalStates']==88 and actual['independentStructuralRejections']==64 and actual['events']==proof['events'] and set(actual['rooms'])==added and actual['actualRuleInputs']==frozen['actualRuleInputs'] and actual['actualReadOnlyConnection']
 proof['status']='PASS_CURRENT_SPECIAL_TRIGGER_SIXTEEN_BRANCHES_REAL_SQL_COLD_DEDUP_INDEPENDENT_ALL_HISTORY_ORIGINAL_REPLAY';print(proof['status'],flush=True)
except BaseException as error:
 proof.update(status='FAILED_CURRENT_SPECIAL_TRIGGER_SQL_OR_INDEPENDENT_READBACK_ORIGINALS_RETAINED',errorType=type(error).__name__,error=str(error));raise
finally:
 for process in [writer,independent]:
  if process and process.poll() is None:process.terminate();process.wait(timeout=20)
 if started:
  try:
   if before_audit is not None:proof['allOriginal300AuditSevenTablesExactAtStop']=digests('riftbound_acceptance',old_audit)==before_audit
   if before_native is not None:proof['allOriginal65NativeSevenTablesExactAtStop']=digests('riftbound_here_native',old_native)==before_native
   proof['actualAuditRoomsAtStop']=rooms('riftbound_acceptance');proof['actualNativeRoomsAtStop']=rooms('riftbound_here_native')
  except BaseException as cleanup_error:proof['cleanupReadError']=str(cleanup_error)
  finally:
   stop=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','fast','-w','stop'],capture_output=True,text=True);proof['ownPostgresNormalStopExitCode']=stop.returncode;proof['ownPostgresStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 if power:
  if power.poll() is None:power.terminate()
  power.wait(timeout=10)
 proof.update(finishedAtUtc=now(),lockAtStop=observe_lock(),allFrozenInputsStable=stable());terminal.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
