from pathlib import Path
from urllib.request import Request,urlopen
from urllib.error import HTTPError
from concurrent.futures import ThreadPoolExecutor
import datetime,gzip,hashlib,json
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda b:hashlib.sha256(b).hexdigest()
baseline=json.loads((root/'data/official/upstream/2026-10-16/source-refresh-20261015T160523Z/card-catalog.zh-CN.json').read_text());old={c['id']:c for c in baseline['cards']}
def get(term,ids):
 url='https://lol-api.playloltcg.com/xcx/card/searchCardCraftWeb';body={'pageNum':1,'pageSize':100,'searchContent':term,'cardCategoryList':[],'cardColorList':[],'rarityList':[],'productCodeList':[]};start=now()
 with urlopen(Request(url,json.dumps(body,ensure_ascii=False).encode(),{'Content-Type':'application/json','User-Agent':'Mozilla/5.0','Cache-Control':'no-cache'}),timeout=40) as r:raw=r.read();status=r.status;headers=dict(r.headers)
 p=w/('current-'+str(ids[0])+'-search-whole-response-v1.json.gz');p.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(p.read_bytes())==raw;d=json.loads(raw);cards={c['id']:c for c in d['result']['list']};assert set(ids)<=cards.keys()
 proof={'url':url,'request':body,'startedAtUtc':start,'receivedAtUtc':now(),'httpStatus':status,'responseHeaders':{k:v for k,v in headers.items() if k.lower() in {'date','etag','age','last-modified','content-type'}},'originalRawBytes':len(raw),'originalRawSha256':sha(raw),'original':str(p.relative_to(root)),'compressedSha256':sha(p.read_bytes()),'completeReturnedRows':len(cards),'exactIds':ids,'allKeysValuesNullsAndQaEqualCN16':all(cards[i]==old[i] for i in ids),'currentExactRows':{str(i):cards[i] for i in ids},'newPublicationAndEffectiveDatesNotInferredFromFetchTime':True};(w/(str(ids[0])+'-source-intake-v1.json')).write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');assert proof['allKeysValuesNullsAndQaEqualCN16'];print('API exact whole rows PASS',ids,flush=True);return proof
with ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(lambda x:get(*x),[('远古巨龙',[34658,34659]),('永恩',[33203,33339,33340]),('冰霜要塞',[34765]),('安妮',[31580])]))
prior=json.loads((root/'docs/evidence/source-round-2026-10-21/originals/rules/DOC-01.pdf.receipt.json').read_text());p=root/prior['path'];assert sha(p.read_bytes())==prior['sha256'];etag=prior['responseHeaders']['ETag'];start=now()
try:
 with urlopen(Request(prior['url'],headers={'User-Agent':'Mozilla/5.0','If-None-Match':etag}),timeout=40) as r:raw=r.read();status=r.status;headers=dict(r.headers)
except HTTPError as e:
 if e.code!=304:raise
 raw=None;status=304;headers=dict(e.headers)
core={'url':prior['url'],'startedAtUtc':start,'receivedAtUtc':now(),'httpStatus':status,'conditionalIfNoneMatch':etag,'responseHeaders':headers,'existingOriginal':str(p.relative_to(root)),'existingSha256':prior['sha256'],'rawPayloadDuplicatedOnDisk':False}
if raw is not None:
 core.update(actualPayloadSha256=sha(raw),actualPayloadBytes=len(raw),unchanged=sha(raw)==prior['sha256'])
 if not core['unchanged']:
  n=w/'new-core-original.pdf';n.write_bytes(raw);core['newOriginal']=str(n.relative_to(root))
else:core.update(unchanged=True,existingRawBytesVerified=True)
(w/'current-primary-core-conditional-source-intake-v1.json').write_text(json.dumps(core,ensure_ascii=False,indent=2)+'\n');assert core['unchanged'];(w/'current-seven-exact-api-and-core-source-readback-v1.json').write_text(json.dumps({'atUtc':now(),'status':'ALL_SEVEN_EXACT_WHOLE_API_ROWS_AND_CURRENT_PRIMARY_CORE_UNCHANGED','region':'CN','language':'zh-CN','applicableAsOf':'2026-10-21','currentCoreEffectiveDate':'2026-10-16','apiReceipts':[str(x['exactIds'][0])+'-source-intake-v1.json' for x in rows],'coreReceipt':'current-primary-core-conditional-source-intake-v1.json','sourceVersionsDatesAndFullUniverseNotReplaced':True,'wholeCardSemanticCertification':False},indent=2)+'\n');print('Current primary core unchanged; no duplicate PDF',flush=True)
