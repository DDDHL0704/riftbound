from pathlib import Path
import collections, copy, datetime, gzip, hashlib, io, json, re, subprocess, tarfile, xml.etree.ElementTree as ET

root = Path('/Users/dinghaolin/MyProjects/riftbound')
w = Path(__file__).resolve().parent
native = root / 'var/qa/fixed7a-early-native-20261021'
load = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p, value):
    with p.open('x') as s: json.dump(value, s, ensure_ascii=False, indent=2)
def pin(p, role=None):
    v = {'path': str(p.relative_to(root)), 'sha256': sha(p)}
    if role: v['role'] = role
    return v

check = load(w / 'check-original-case-method-and-input-retention-v1.json')
sql = load(w / 'actual-current-special-trigger-sql-owner-terminal-v1.json')
independent = load(w / 'independent-current-special-trigger-all-history-v1.json')
frozen = load(w / 'current-special-trigger-frozen-runtime-inputs-v1.json')
assert (check['actualCases'], check['actualMethods'], check['failed'], check['skipped']) == (13348, 7521, 0, 0)
assert (sql['writerCases'], sql['commands'], sql['events'], sql['coldRecoveries']) == (16, 88, 241, 88)
assert sql['ownPostgresStopped'] and sql['allOriginal300AuditSevenTablesExactAtStop'] and sql['allOriginal65NativeSevenTablesExactAtStop']
assert (independent['authoritativeHistoricalStates'], independent['privateSnapshots'], independent['privatePrompts'], independent['independentStructuralRejections']) == (88, 176, 176, 64)
assert all(sha(root / p) == h for p, h in frozen['sourceInputHashes'].items())
assert load(native / 'visible-native41-first-seating-replay-counterexample-v1.json')['status'].startswith('CONFIRMED_NATIVE_FIRST_DECK_')
assert load(w / 'frost-controller-confirmed-issue-posted-v1.json')['actualPostedIssue']['number'] == 84
assert load(native / 'native-seating-historical-replay-confirmed-issue-posted-v1.json')['actualPostedIssue']['number'] == 85
mp = root / 'docs/audit/current-manifest.json'; m = load(mp)
rp = root / m['inputs']['reviews']['path']; reviews = load(rp)
oldm, oldreviews = copy.deepcopy(m), copy.deepcopy(reviews)
assert (len(reviews['reviews']), len(m['reviewContexts']), len(m['acceptanceGates']), len(m['laterSourceDeltas'])) == (158, 73, 245, 7)
before = load(w / 'prior-governance-before-coherent-publication-v1.json')
assert before['governanceValid'] and before['errors'] == [] and len(before['remainingObligations']) == 17042
prior = w / 'prior-special-trigger-publication-v1'; prior.mkdir(exist_ok=False)
for p in [mp, rp, root / 'docs/PROJECT_STATUS.md', w / 'prior-governance-before-coherent-publication-v1.json']:
    target = prior / (p.name + '.gz'); target.write_bytes(gzip.compress(p.read_bytes(), mtime=0))
    assert gzip.decompress(target.read_bytes()) == p.read_bytes()
# The lossless baseline remains once, rather than retaining a second 19MB rendering.
(w / 'prior-governance-before-coherent-publication-v1.json').unlink()
ev = root / 'docs/evidence/special-trigger-damage-current-cn16-2026-10-22'; ev.mkdir(exist_ok=False)
reviewid = 'special-trigger-damage-current-cn16-2026-10-22'
frostid = 'frost-controlled-start-source-finding-2026-10-22'
nativeid = 'native-late-seat-historical-replay-finding-2026-10-22'
doc = 'docs/SPECIAL_TRIGGER_DAMAGE_CURRENT_CN16_AUDIT_2026-10-22.md'

ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
tree = ET.parse(w / 'current-special-trigger-focus-v4/focus/results.trx')
rows = tree.findall('.//t:UnitTestResult', ns)
defs = {v.get('id'): v.find('t:TestMethod', ns).attrib for v in tree.findall('.//t:UnitTest', ns)}
methods = {defs[v.get('testId')]['className'] + '.' + defs[v.get('testId')]['name'] for v in rows}
assert len(rows) == 191 and len(methods) == 59 and all(v.get('outcome') == 'Passed' for v in rows)
focus = {'atUtc': now(), 'status': 'BOUNDED_FOCUS_PASS', 'distinctCases': 191, 'distinctMethods': 59,
         'newMethodNames': check['newMethodNames'], 'actualTrx': pin(w / 'current-special-trigger-focus-v4/focus/results.trx'),
         'notFullCiWholeCardOrProductCertification': True}
write(w / 'final-current-special-trigger-focus-v1.json', focus)
corpus = load(root / 'docs/evidence/rules-reaudit-2026-10-11/official-corpus.json')
index = {v['id']: v for v in corpus['records']}
oldsource = load(root / 'docs/evidence/controller-damage-current-cn16-2026-10-21/current-exact-source-review.json')
ruleids = [r['id'] for r in oldsource['ruleRecords']] + ['DOC-01-P029-B006', 'DOC-01-P029-B007', 'DOC-01-P029-B008', 'DOC-01-P029-B009', 'DOC-01-P101-B004']
ruleids = list(dict.fromkeys(ruleids))
records = [{'id': k, 'textSha256': hashlib.sha256(index[k]['text'].encode()).hexdigest()} for k in ruleids]
receipts = [w / (s + '-source-intake-v1.json') for s in ['34658', '34847', '34765', '31580', '31542']]
assert sum(len(load(p)['currentExactRows']) for p in receipts) == 8
source = {'atUtc': now(), 'state': 'BOUNDED_FIVE_PRINTINGS_TWO_SPECIAL_DAMAGE_ROUTES_PASS_FROST_AND_NATIVE_HISTORY_FINDINGS_OPEN',
    'region': 'CN', 'language': 'zh-CN', 'applicableAsOf': '2026-10-21', 'reviewCompletedLocalDate': '2026-10-22',
    'adoptedCoreEffectiveDate': '2026-10-16', 'primaryCoreId': 'DOC-01', 'primaryCoreSha256': 'd6fd7140f106f9b5b3dc0d5817fd040110fe870a6da9ee335ba7f4f70f892d11',
    'ruleRecords': records, 'freshWholeApiRowReceipts': [pin(p) for p in receipts], 'exactFreshRows': [34658,34659,34847,34848,34849,34765,31580,31542],
    'allKeysValuesNullsAndQaEqualRecordedCN16AndLatestRegisteredCN20': True, 'sourceVersionChanged': False,
    'knownYoneApiIdMigrationNotNewSourceDelta': pin(w / 'existing-source-id-migration-is-not-new-source-delta-v1.json'),
    'conditionalCoreIntake': pin(w / 'current-primary-core-conditional-source-intake-v1.json'),
    'formalReviewCompletedAfterCheckSourceIntakePredatedGameplayChange': True,
    'sourceReasoning': {
        'skillDamage': '418.6: absent an explicit other dealer, the describing skill deals damage. Elder play and Yone conquest instructions use captured skill controller, not the unit-dealt path.',
        'passives': '364/365.1/366.1: only currently enabled on-field Annie passives of that controller count; hand, graveyard, opponent and departed sources do not.',
        'perTarget': '714 and715.1/715.2: add the current controller bonus and each target location bonus once before the existing damage prevention/replacement handling; the source battlefield does not modify a base target.',
        'zero': 'Yone current-Might-valued damage is an existing numeric instruction and receives a bonus before the effective-positive guard. This is a combined general-rule interpretation, not an official Yone numeric example.715.4 zero-count Teemo has no damage action and stays distinct.',
        'scope': 'Only two existing special trigger damage call sites reuse the existing helper. No low-level blanket bonus, catalog/parser/contract change, DSL expansion or old-game migration.',
        'frost': '190.6.a controls a controlled battlefield skill;190.6.b falls back to turn player only if uncontrolled.190.6.c concerns a specified choice maker; each-player start timing does not itself override controller.',
        'nativeHistory': 'Engineering journal/replay invariant, observed using the existing two-player product format.487.1 supplies format context only, not an invented official requirement about SEATING SQL histories.'},
    'actualCurrentSpecialTriggerRuleInputs': frozen['actualRuleInputs'],
    'priorFixed7aNativeRuleInputs': load(native / 'fixed7a-api-actual-rule-inputs-v1.json'),
    'check': check, 'focus': focus, 'sqlScope': {'cases':16,'commands':88,'events':241,'history':88,'snapshots':176,'prompts':176,'independentStructuralRejects':64},
    'boundaries': ['Whole printings, remaining damage consumers, copies/grants/control changes, Deathcap and further replacement branches remain open.', 'N38 fixed full and its current candidate product acceptance remain pending.', 'Fixed7a visible score8:0 does not pass every historical replay: issue85 confirmed; Windows physical acceptance remains open.', 'Frost source-controller counterexample is issue84 and is not repaired in this batch.', 'All original source dates, seven source deltas, 1740 printings/14293 blocks and all coverage gaps remain.'],
    'wholePrintingOrGoalComplete': False}
write(w / 'current-special-trigger-exact-source-scope-review-v1.json', source)

copies = {
    'frost-controller-probe.cs': w / 'current-frost-controller-probe-source-v1/Program.cs',
    'native41-historical-replay-counterexample.cs': native / 'visible-seating-replay-counterexample-source-v1/Program.cs',
    'native41-independent-reader-v1.cs': native / 'visible-native41-independent-reader-source-v1/Program.cs',
    'native41-independent-reader-v2.cs': native / 'visible-native41-independent-reader-source-v2/Program.cs',
    'current-exact-source-review.json': w / 'current-special-trigger-exact-source-scope-review-v1.json',
    'check-original-case-method-and-input-retention.json': w / 'check-original-case-method-and-input-retention-v1.json',
    'final-distinct-focus-execution.json': w / 'final-current-special-trigger-focus-v1.json',
    'real-sixteen-sql-terminal.json': w / 'actual-current-special-trigger-sql-owner-terminal-v1.json',
    'independent-all-history-and-original-replay.json': w / 'independent-current-special-trigger-all-history-v1.json',
    'original-all110-owner-terminal.json': w / 'original-all110-pairs-owner-terminal-v1.json',
    'preceding-fixed99e-complete-full.json': w / 'ci99e-entire-full-independent-verification-v1.json',
    'preceding-fixed7a-headless-native-owner.json': native / 'live-current-ci-main-owner-terminal-v3.json',
    'preceding-fixed7a-headless-native-independent.json': native / 'independent-fixed7a-native-history-result-v3.json',
    'preceding-fixed7a-first-late-partial-independent.json': native / 'independent-original-first-late-partial-all-history-v1.json',
    'preceding-fixed7a-visible-owner-terminal-partial.json': native / 'visible-current-api-owner-terminal-v1.json',
    'preceding-fixed7a-visible41-seating-replay-counterexample.json': native / 'visible-native41-first-seating-replay-counterexample-v1.json',
    'preceding-fixed7a-previous-room-reconnect-metadata-delta.json': native / 'visible-finished-room-reconnect-seven-table-readback-v1.json',
    'frost-controller-issue84.json': w / 'frost-controller-confirmed-issue-posted-v1.json',
    'native-history-issue85.json': native / 'native-seating-historical-replay-confirmed-issue-posted-v1.json',
    'old-native-pair-and-two-installers-retirement.json': native / 'superseded-fixed99e-native-pair-and-two-archives-retirement-v1.json',
    'completed-fixed99e-duplicate-extraction-retirement.json': w / 'completed-fixed99e-duplicate-extraction-retirement-v1.json'}
for name, p in copies.items(): (ev / name).write_bytes(p.read_bytes())
# Keep executed probe/readers' own bits once; runtime dependency payloads stay in their measured frozen local composition.
retained = w / 'executed-independent-reader-own-bits-v1'; retained.mkdir(exist_ok=False)
bits = []
for folder in [w / 'current-frost-controller-probe-source-v1', native / 'visible-native41-independent-reader-source-v1', native / 'visible-native41-independent-reader-source-v2', native / 'visible-seating-replay-counterexample-source-v1']:
    projects = list(folder.glob('*.csproj')); assert len(projects) == 1
    text = projects[0].read_text(); match = re.search(r'<AssemblyName>([^<]+)</AssemblyName>', text); assert match
    name = match.group(1)
    for suffix in ['.dll', '.pdb']:
        original = folder / 'bin/Release/net10.0' / (name + suffix); assert original.is_file(), original
        target = retained / (folder.name + '-' + name + suffix); target.write_bytes(original.read_bytes()); assert sha(original) == sha(target)
        bits.append({'original':pin(original),'retained':pin(target)})
write(w / 'executed-independent-reader-own-bits-retention-v1.json', {'atUtc':now(),'bits':bits,'dependenciesRetainedInOriginalMeasuredFixedRuntimes':True})

oldmap_path = root / 'docs/evidence/controller-damage-current-cn16-2026-10-21/archive-map.json'
oldmap = load(oldmap_path); old_by_sha = {}
for row in oldmap['members']: old_by_sha.setdefault(row['sha256'], row)
runtime_names = {'special-trigger-runtime-v1','fixed7a-api-gameplay-closure-runtime-v1','fixed7a-native-helpers-runtime-v1','fixed7a-native-history-reader-runtime-v1','fixed7a-native-history-reader-runtime-v2','Riftbound-A.app','Riftbound-B.app','native-current'}
members, excluded, reuse = {}, [], []
secret = re.compile(rb'(?i)(?:playerKey|reconnectToken)[\"\s]*[:=][\s\"]*([a-z0-9_+/-]{16,})')
for folder in [w, native]:
    for p in sorted(folder.rglob('*')):
        parts = set(p.relative_to(folder).parts)
        if runtime_names & parts or {'bin','obj','__pycache__'} & parts or not p.is_file(): continue
        if p.name.startswith('session-') or 'private-profile' in p.name or p.name.startswith('postpublication-') or p.name.startswith('publish-special-trigger-owner'):
            excluded.append({'path':str(p.relative_to(root)),'sha256':sha(p),'reason':'PRIVATE_AUTH_SESSION_OR_OPERATIONAL_OUTPUT_RETAINED_LOCALLY'}); continue
        data = p.read_bytes()
        if p.suffix in {'.json','.log','.ndjson'}: assert not secret.search(data), p
        name = str(p.relative_to(root)); digest = hashlib.sha256(data).hexdigest()
        if digest in old_by_sha:
            reuse.append({'path':name,'sha256':digest,'existingArchiveMember':old_by_sha[digest]['path'],'existingArchiveMap':pin(oldmap_path)})
        else: members[name] = p
archive = ev / 'original-execution-and-source-records.tar.gz'; rows = []
with tarfile.open(archive, 'w:gz', compresslevel=9) as tar:
    for name, p in sorted(members.items()):
        data=p.read_bytes(); info=tarfile.TarInfo(name);info.size=len(data);info.mode=p.stat().st_mode&0o777;info.mtime=0
        tar.addfile(info,io.BytesIO(data));rows.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(archive, 'r:gz') as tar:
    assert set(tar.getnames()) == {v['path'] for v in rows}
    for v in rows:
        data=tar.extractfile(v['path']).read();assert len(data)==v['bytes'] and hashlib.sha256(data).hexdigest()==v['sha256']
write(ev / 'archive-map.json', {'atUtc':now(),'archive':pin(archive),'members':rows,'existingIdenticalOlderArchiveMembersNotDuplicated':reuse,'privateOrOperationalExclusionsRetainedLocally':excluded,'allMembersBytesHashesAndClosedSetVerified':True,'installersApplicationsFrozenRuntimesAndUnchangedPrimaryPdfNotDuplicated':True})
source_manifest = {'schemaVersion':1,'id':reviewid,'atUtc':now(),'region':'CN','language':'zh-CN','applicableAsOf':'2026-10-21','reviewCompletedLocalDate':'2026-10-22','adoptedCoreEffectiveDate':'2026-10-16','sourceVersionChanged':False,'oldPublicationEffectiveAcquisitionDatesAndAllSevenDeltasRetained':True,'currentSourceReview':pin(ev/'current-exact-source-review.json'),'archive':pin(archive),'archiveMap':pin(ev/'archive-map.json'),'actualRuleInputs':frozen['actualRuleInputs'],'priorFixed7aIdentityDistinct':True,'parentCommit':frozen['parentCommit'],'declaredUncommittedBatch':True,'scope':'Five exact Elder/Yone printings, two existing damage routes,44 bounded conformance cases,16 controlled SQL cases. Separate confirmed Frost controller and fixed7a early-seat replay findings remain OPEN.','fullScopeRetained':{'printings':1740,'ruleBlocks':14293,'cnRows':1504,'enRows':1408,'enReported':1416,'enGap':8,'active':1035,'outsideActive':705,'cnDispositions':236,'news':139,'sourceDeltas':7},'semanticCoverageCertified':False}
write(ev/'source-manifest.json',source_manifest); sp=pin(ev/'source-manifest.json','source-manifest')
cases=load(w/'all-forty-four-current-special-trigger-actual-new-case-identities-v1.json')['cases']; assert len(cases)==44
branches=[]
for case in cases:
    params={k:(v[1:-1] if v.startswith('"') else v=='True' if v in ['True','False'] else int(v)) for k,v in re.findall(r'(\w+): ("[^"]*"|True|False|-?\d+)',case)}
    per_location='PerLocation' in case or params.get('location') is True
    printing=params.get('printing','UNL-118/219' if per_location else 'SFD-116/221').replace('·','-').upper()
    if 'PerLocationPlaySkill' in case: expected={'fieldDamage':1+params['copies']+int(params['local']),'baseDamage':1+params['copies'],'oneSelectedUnitPerLocation':True}
    elif 'ConquestSkillAddsBonus' in case: expected={'targetBaseDamage':params['power']+params['copies'],'sourceVoidGateAddsToBaseTarget':False,'zeroEffectiveDamageEmitsNoAppliedEvent':params['power']+params['copies']==0}
    elif 'BothSkillPaths' in case: expected={'damageWithoutIneligibleAnnie':1 if per_location else 5}
    elif 'PerLocationBonuses' in case: expected={'fieldDamage':0,'baseDamage':0 if params['prevention']=='global' else 2,'fieldTargetSurvives':True}
    else: expected={'targetDamage':0,'preventedDamage':6,'targetSurvives':True}
    exact_sql=('PerLocationPlaySkill' in case and params['copies'] in [0,2] and params['local']) or ('ConquestSkillAddsBonus' in case and params['copies'] in [0,2])
    branches.append({'id':'special-trigger-'+hashlib.sha256(case.encode()).hexdigest()[:20],'sourceRefs':[printing,'OGS-001/024','OGN-296/298','DOC-01-P074-B008','DOC-01-P106-B010','DOC-01-P106-B013','DOC-01-P106-B014'],'state':'RECORDED','sourceManifest':sp,'boundedCase':{'actualExecutedCase':case,'parameters':params,'literalSourceGroundedExpectedValues':expected,'controlledSqlSamePrintingCountAndLocationBranch':bool(exact_sql)},'semanticReview':{'state':'BOUNDED_CURRENT_SOURCE_REVIEW','combinedGeneralRulesNotOfficialYoneNumericExample':True},'implementation':{'state':'TWO_EXISTING_SPECIAL_DAMAGE_CALLS_REUSE_SHARED_HELPER'},'testExecution':{'state':'FOCUS_CHECK_ALL110_AND_SIXTEEN_EXACT_SQL_SCOPE_PASS'},'fixedCommitCi':{'state':'PENDING_NEW_FIXED_FULL'},'productAcceptance':{'state':'OPEN_CURRENT_CANDIDATE_AND_PHYSICAL_WINDOWS'},'decision':{'state':'OPEN','reason':'Bounded implementation/tests do not certify whole printing, future fixed full or current product gates.'},'wholePrintingCertified':False,'existingAcceptanceGateDependencies':['FIXED_CURRENT_CANDIDATE_FULL','VISIBLE_PAIRED_SQL_NETWORK_SCORE_REPLAY','USER_WINDOWS_RUNTIME']})
write(ev/'forty-four-exact-behavior-branches.json',{'branches':branches})
def context(identity, implementation, evidence, branch_rows, subjects, refs, status, validation):
    verification = [root / p for p in ['tests/Riftbound.ConformanceTests/SpecialTriggerDamageBonusTests.cs','tests/Riftbound.ConformanceTests/ElderDragonTests.cs','tests/Riftbound.PostgresAcceptance/SpecialTriggerDamageBonusSqlAcceptance.cs','tests/Riftbound.PostgresAcceptance/Program.cs','tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json','scripts/tests/test_sql_ci_gate.py']] if identity == reviewid else [ev / 'frost-controller-probe.cs', root / 'tests/Riftbound.ConformanceTests/FrostHoldTests.cs'] if identity == frostid else [ev / p for p in ['native41-historical-replay-counterexample.cs','native41-independent-reader-v1.cs','native41-independent-reader-v2.cs']]
    m['reviewContexts'][identity]={'evidenceCommit':frozen['parentCommit'],'currentImplementationCommit':frozen['parentCommit'],'currentImplementationIncludesUncommittedChanges':identity!=nativeid,'ciState':'PENDING','ciReceipts':[],'region':'CN','language':'zh-CN','applicableAsOf':'2026-10-21','reviewCompletedLocalDate':'2026-10-22','adoptedCoreEffectiveDate':'2026-10-16','sourceManifest':sp,'implementation':[pin(root/p,'implementation') for p in implementation],'verificationSources':[pin(p,'verification-source') for p in verification],'evidence':[pin(ev/p,role) for p,role in evidence],'branches':branch_rows}
    reviews['reviews'].append({'id':identity,'scope':source_manifest['scope'] if identity==reviewid else status,'subjects':subjects,'ruleRecords':refs,'status':status,'sourceManifest':sp,'auditDocument':doc,'validation':validation,'exclusions':source['boundaries']})
context(reviewid,['src/Riftbound.Engine/CoreRuleEngine.LocationDamage.cs','src/Riftbound.Engine/CoreRuleEngine.UnitConquest.cs','src/Riftbound.Engine/CoreRuleEngine.cs'],[('final-distinct-focus-execution.json','focus'),('check-original-case-method-and-input-retention.json','check'),('real-sixteen-sql-terminal.json','sql'),('independent-all-history-and-original-replay.json','independent-sql'),('original-all110-owner-terminal.json','original-pair-helpers')],branches,['UNL-118/219','UNL-118A/219','SFD-116/221','SFD-233/221','SFD-233*/221','OGS-001/024','OGN-296/298'],ruleids,'BOUNDED_TWO_SPECIAL_DAMAGE_ROUTES44_CASES_FOCUS191_CHECK13348_SQL88_ALL110_PASS_FIXED_FULL_AND_PRODUCT_OPEN',{'newCases':44,'newMethods':5,'focusCases':191,'focusMethods':59,'checkCases':13348,'checkMethods':7521,'sqlCases':16,'sqlCommands':88,'sqlEvents':241,'sqlColdRecoveries':88,'allOriginal143FullMethods110Pairs11Decks424242AndAssertionsRetained':True,'wholePrintingCertified':False})
def finding(identity, refs, issue, evidence, implementation, explanation):
    branch={'id':identity+'-confirmed-open','sourceRefs':refs,'sourceManifest':sp,'state':'RECORDED','semanticReview':{'state':'CURRENT_SOURCE_OR_ENGINEERING_INVARIANT_CONFIRMED','explanation':explanation},'implementation':{'state':'CONFIRMED_DEFECT_NOT_REPAIRED'},'testExecution':{'state':'ACTUAL_ORIGINAL_COUNTEREXAMPLE_RETAINED'},'fixedCommitCi':{'state':'DOES_NOT_CLOSE_OBSERVED_SEMANTIC_OR_HISTORY_FAILURE'},'productAcceptance':{'state':'OPEN'},'decision':{'state':'OPEN','reason':explanation},'wholePrintingCertified':False,'issue':issue,'existingAcceptanceGateDependencies':['VISIBLE_PAIRED_SQL_NETWORK_SCORE_REPLAY','USER_WINDOWS_RUNTIME']}
    context(identity,implementation,evidence,[branch],['UNL-212/219'] if identity==frostid else [],refs,'CONFIRMED_OPEN_FINDING_NOT_REPAIRED',{'issue':issue,'counterexampleConfirmed':True,'wholePrintingCertified':False})
finding(frostid,['UNL-212/219','DOC-01-P029-B006','DOC-01-P029-B007','DOC-01-P029-B008','DOC-01-P029-B009'],'https://github.com/DDDHL0704/riftbound/issues/84',[('frost-controller-issue84.json','confirmed-issue'),('current-exact-source-review.json','source')],['src/Riftbound.Engine/CoreRuleEngine.BattlefieldStart.cs','src/Riftbound.Engine/MatchRecovery.cs'],'Controlled P2 Frost skill incorrectly captured as P1 turn-player; independent initial validation passes, P1 Elder wrongly destroys P2 target. Capture/provenance and independent recovery remain to repair.')
finding(nativeid,['DOC-01-P101-B004'],'https://github.com/DDDHL0704/riftbound/issues/85',[('preceding-fixed7a-visible41-seating-replay-counterexample.json','counterexample'),('native-history-issue85.json','confirmed-issue'),('preceding-fixed7a-visible-owner-terminal-partial.json','native-owner-partial')],['src/Riftbound.Engine/MatchSession.cs','src/Riftbound.Engine/MatchRecovery.cs','src/Riftbound.Engine/Matchmaking.cs'],'Engineering invariant: first actual SQL state has onlyA; original blank replay initial includes finalA+B. Native41/263 normal8:0 and final-only recovery pass do not certify historical replay. No old-game rewrite/migration.')
assert reviews['reviews'][:158]==oldreviews['reviews']
assert all(m['reviewContexts'][k]==v for k,v in oldm['reviewContexts'].items())
assert m['acceptanceGates']==oldm['acceptanceGates'] and m['laterSourceDeltas']==oldm['laterSourceDeltas']
rp.write_text(json.dumps(reviews,ensure_ascii=False,indent=2)+'\n');m['inputs']['reviews']['sha256']=sha(rp)
m['currentSpecialTriggerDamageAndExplicitOpenFindings']={'sourceManifest':sp,'auditDocument':doc,'newBoundedBehaviorBranches':44,'newExplicitOpenFindings':2,'original17042ObligationIdsMustRemain':True,'expectedCurrentTotal':17088,'all158OldReviews73Contexts245GatesAndSevenDeltasExact':True,'noContextInputRefreshRequired':True,'wholePrintingOrGoalComplete':False}
m['precedingFixed99eActualCompleteFullCiReadback']=pin(ev/'preceding-fixed99e-complete-full.json')
m['precedingFixed7aBoundedHeadlessAndVisibleHistoryFailure']={'headless':pin(ev/'preceding-fixed7a-headless-native-independent.json'),'visibleHistoryCounterexample':pin(ev/'preceding-fixed7a-visible41-seating-replay-counterexample.json'),'visibleNormalScoreDoesNotCloseReplay':True,'windowsPhysical':'OPEN'}
mp.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
write(ev/'publication-original-governance-object-retention.json',{'atUtc':now(),'oldReviews':158,'oldContexts':73,'oldGates':245,'oldDeltas':7,'allCompleteOldObjectsExact':True,'originalObligationCount':17042,'addedBranches':44,'addedOpenFindings':2,'expectedRemainingObligations':17088,'priorCompleteObjectsAndObligations':pin(prior/'prior-governance-before-coherent-publication-v1.json.gz'),'semanticCoverageCertified':False})
document='''# 远古巨龙/永恩特殊技能伤害的现行限定审查

本轮地区CN、语言zh-CN、适用日期2026-10-21，核心规则2026-10-16生效；来源取得与开发始于10-21，check及正式证据收尾于本地10-22。没有以收尾日改写来源取得、发布、生效或旧认证日期。[来源manifest](evidence/special-trigger-damage-current-cn16-2026-10-22/source-manifest.json)保留完整范围；目标active / NOT READY。

远古巨龙UNL118/118a逐位置打出技能、永恩SFD116/233/233*征服战力伤害，在两个既有调用点复用当前场上控制者加成及逐目标虚空之门加成。只改这两个金额入口，保留原目标/费用/生命周期/防止替换/独立恢复；不改目录、协议或DSL。永恩求值为零的已有伤害指令可获加成；这来自通用规则组合解释，并非官方永恩数值例题，与提莫零张时根本没有伤害行动分开。

八条官方完整API行及QA与原CN16/最新已登记CN20相同，核心强ETag条件请求304、原SHA不变。永恩官网34847/48/49与运行目录33203/33339/33340是已登记身份迁移，不新增来源变化或静默改目录。核心29整页实际查看；30/57/74/106沿用已保存整页与哈希。418.6限定技能伤害来源，714/715限定一次加成及目标，364/365/366限定场上被动。原全部来源宇宙、七增量、日期及缺口保留。

新增44例/5方法：远古巨龙两印次×0/1/2安妮×有无本地加成12例；永恩三印次×0/1/2安妮×战力0/5共18例；手牌/废牌堆/对手/结算前离场8例；原防止路径6例。首次新测试编译绑定错误与修正前27红/17绿原件保留。首修150/151中原远古巨龙旧期望仍漏算现行虚空之门；仅精确校准原D伤害1→2，E=1、原方法及全部生存/恢复断言保留。最终focus191/59全过。

本批唯一check13348例/7521方法全部通过，零失败零跳过；原13304例多重集合/7516方法完整，只增44/5。3332源/模式、1419Conformance、23原生Debug载荷全过程稳定，非当前原生执行认证。原九份完整源码/143公共方法/110配对/十一牌组/424242及全部Theory、胜利/回放断言保留；110原配对助手另以本批b881身份完整通过，不能替代新固定full。后续仅治理证据归档，无第二check。

新增第56项SQL，原55项对象/顺序及类源码保留。五精确印次16分支88命令241事件、88冷恢复/64直接拒绝/64写入结构拒绝；独立88权威历史/176私有快照/176提示、每条原历史完整顺序回放及64结构拒绝通过。原300审计/65原生七表全同；新16审计局保留至316，数据库正常停止。原始意图逐条即时保存，原blank元数据与显式受控初态分别保留；实际加载路径、SHA、MVID及b881身份有实测，控制元数据独立物理副本。

前固定99e CI39594660433实际11项success，九原产物独立13403例/7651方法、143/110/11/424242、54SQL及网络15拒绝零泄露通过；原25c13387/7649完整，只增16/2。110终态哈希逐项记录，未要求跨实现不变。固定7a CI39615500598整次终态发布时尚待核，本批新固定full待推送；预计13497/7662及56SQL，尚非已执行结果。

固定7a实际CI原生双端无窗口第二普通局73命令483事件、第43回合8:0、三生产交互提交、同进程冷重连与独立73历史/142快照/142提示及全部回放通过，网络15/0。首个自然开局67命令530事件未达到旧续行前提，两牌堆7张，原局/失败/种子保留；独立67历史/130快照/130提示与全部原回放通过仍只称部分对局，第二局另建并明确记录。7a实际ec217身份与本批b881分开。

另用真实可见A/B创建公开房间RB-CXM5MH：A独处交卡组，B后加入；原生准备/调度/取消出牌/移动Esc/打出/移动/响应/正常得分至第18回合8:0，全部41命令263事件来自真实原生控件，无投降、耗尽或重提动作。双端终局截图与原CUA操作记录保留。但严格逐历史回放失败：首个SQL状态仅A，原blank回放元数据已有最终A+B。最终帧验证零错误，仍不能通过全历史。初读者最终座位假设错误、校准后真实回放失败和独立离线精确反例全部保留；[#85](https://github.com/DDDHL0704/riftbound/issues/85) OPEN，下批优先修复，不改旧局或跳过早期SEATING。

可见API达到其有界45分钟截止后正常清理资源，owner保留PARTIAL/ERROR而非全绿；自有API/PG均停止。此前已完成73局GUI重连使原65原生的matches/match_players连接时间/令牌元数据变化，其他五个游戏历史表字节相同；显式保留旧基线和变化收据，不称旧七表不变。后续只读316审计/66原生七表前后均相同，原历史未改写。Windows实机仍OPEN。

冰霜要塞UNL212/API34765另有确认反例：受P2控制、仅P2占据且非争夺的战场，在P1开始阶段错误把技能归P1，进而使用P1远古巨龙摧毁P2目标。初态独立恢复零错误；实际190.6.a/b/c来源和完整原轨迹保留。[#84](https://github.com/DDDHL0704/riftbound/issues/84) OPEN，未混改本批。修复需捕获可独立验证的技能控制者，不能弱化安全或给旧开发局加迁移。

本批161限定审查/76上下文/245门禁/七来源增量。原158审查、73上下文、245门禁、七增量完整对象不变，无需重绑旧实现；原17042义务身份全留，新增44限定分支及两OPEN发现至17088。semanticCoverageCertified=false。局部数值修复、CI或可见胜利均不代替全量完成。

本地仅最新可用7a A/B及每平台一份已核验包；旧99e双端/两包退役945969407逻辑字节，原件与清单保留。另在每字节等于保留原ZIP后退役577文件8000753字节重复解压；归档复用既有相同成员，不复制整套运行依赖或未变PDF，原来源/测试/执行文件/失败/数据库保留。不推定APFS物理回收，无新SDK、工作树或数据库。
'''
(root/doc).write_text(document)
status=root/'docs/PROJECT_STATUS.md'; text=status.read_text();prefix='# 当前项目状态\n\n';assert text.startswith(prefix)
lead='2026-10-22 本批：[远古巨龙/永恩两特殊伤害入口](SPECIAL_TRIGGER_DAMAGE_CURRENT_CN16_AUDIT_2026-10-22.md)。CN适用10-21、核心10-16，八完整API行/核心未换版，旧永恩ID迁移单独保留。只复用既有控制者/目标本地加成，新44/5；focus191/59、唯一check13348/7521、原110配对助手全过，3332/1419/23输入稳定，原143方法/110/11/424242及断言完整。五印次16真实SQL分支88命令241事件88冷恢复，独立88历史/176快照/176提示/全部原回放64结构拒绝；原300审计65原生七表不变，留至316审计。\n\n前99e全CI11项实际success，独立13403/7651、54SQL、网络15/0；固定7a无窗口73/483正常8:0和完整原回放通过。真实可见新局41/263、第18回合8:0及原生取消/移动/响应已执行，但首个仅A座位历史与最终双座位回放初态不一致，#85确认OPEN；最终帧零错误不能替代历史。原读者假设错误及修正后真实失败完整保留。另冰霜要塞受P2控制却把开始技能归P1、错误使用P1巨龙的独立反例#84 OPEN。两发现未混改本批。旧65原生GUI重连仅连接元数据两表变化，五个游戏历史表保留；后续只读316/66七表均不变，自有API/PG已停止。\n\n原158审查/73上下文/245门禁/七增量对象完整，不需重绑；新增44限定分支和两OPEN发现至17088义务、161审查76上下文，语义false。固定7a整次full及本批新固定full/当前产品/Windows仍分别OPEN。仅最新7a双端/每平台一包，旧99e包及577个已验字节的重复解压退役，必要原件/库保留，不推定物理回收。Goal active / NOT READY。\n\n以下原批按原范围与当时终态保留。\n\n'
status.write_text(prefix+lead+text[len(prefix):])
print('PUBLISHED coherent N38:44 bounded branches+2 confirmed OPEN findings; prior158/73/245/7 complete objects exact; expected17088; archive',archive.stat().st_size)
