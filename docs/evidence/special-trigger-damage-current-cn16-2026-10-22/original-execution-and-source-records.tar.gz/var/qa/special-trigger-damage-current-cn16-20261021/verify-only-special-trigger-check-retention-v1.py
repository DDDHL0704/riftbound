from pathlib import Path
import collections, datetime, hashlib, json, subprocess, xml.etree.ElementTree as ET

root = Path('/Users/dinghaolin/MyProjects/riftbound')
w = Path(__file__).resolve().parent
load = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
pin = lambda p: {'path': str(p.relative_to(root)), 'sha256': sha(p)}
ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def read(p):
    tree = ET.parse(p)
    defs = {t.get('id'): t.find('t:TestMethod', ns).attrib for t in tree.findall('.//t:UnitTest', ns)}
    rows = tree.findall('.//t:UnitTestResult', ns)
    return rows, collections.Counter(t.get('testName') for t in rows), {defs[t.get('testId')]['className'] + '.' + defs[t.get('testId')]['name'] for t in rows}

start = load(w / 'only-check-start-inputs-v1.json')
end = load(w / 'only-check-owner-terminal-v1.json')
assert end['exitCode'] == 0
assert all(end[k] for k in ['all3332SourceHashesAndModesStable', 'all1419ConformanceRuntimeInputsStable', 'all23NativeDebugRuntimeInputsStable'])
before = root / start['originalBaselineTrx']
assert sha(before) == start['originalBaselineTrxSha256']
current = w / 'only-check-v1/check/results.trx'
rows, counts, methods = read(current)
oldrows, oldcounts, oldmethods = read(before)
assert (len(rows), len(methods), len(oldrows), len(oldmethods)) == (13348, 7521, 13304, 7516)
assert all(t.get('outcome') == 'Passed' for t in rows)
assert not oldcounts - counts and oldmethods <= methods
assert sum((counts - oldcounts).values()) == 44 and len(methods - oldmethods) == 5
assert set((counts - oldcounts).elements()) == set(load(w / 'all-forty-four-current-special-trigger-actual-new-case-identities-v1.json')['cases'])
f = load(w / 'current-special-trigger-frozen-runtime-inputs-v1.json')
assert f['sourceInputHashes'] == start['sourceInputHashes'] and f['sourceInputModes'] == start['sourceInputModes']
assert len(f['sourceInputHashes']) == 3332
for p, h in f['sourceInputHashes'].items():
    assert sha(root / p) == h and oct((root / p).stat().st_mode & 0o777) == f['sourceInputModes'][p], p
for key in ['actualConformanceRuntimeFileHashes', 'actualNativeRuntimeFileHashes']:
    assert all(sha(root / p) == h for p, h in start[key].items())
original = load(w / 'pre-change-current-root-and-original-conformance-inputs-v1.json')
changed_old = [p for p, h in original['allOriginalConformanceInputs'].items() if sha(root / p) != h]
assert changed_old == ['tests/Riftbound.ConformanceTests/ElderDragonTests.cs']
calibration_path = changed_old[0]
old = subprocess.check_output(['git', 'show', f['parentCommit'] + ':' + calibration_path], cwd=root).decode()
old_line = '        Assert.Equal(1,done.State.CardObjects["D"].Damage);Assert.Equal(1,done.State.CardObjects["E"].Damage);Assert.DoesNotContain("D",done.State.PlayerZones["P2"].Graveyard);Assert.DoesNotContain("E",done.State.PlayerZones["P2"].Graveyard);Restore(done.State);'
new_line = '        // The captured skill remains; Void Gate still adds one at D\'s battlefield.\n' + old_line.replace('Assert.Equal(1,done.State.CardObjects["D"].Damage)', 'Assert.Equal(2,done.State.CardObjects["D"].Damage)')
assert old.count(old_line) == 1 and (root / calibration_path).read_text() == old.replace(old_line, new_line)
assert len(original['originalCompleteGameSources']) == 9
for p, h in original['originalCompleteGameSources'].items():
    assert sha(root / p) == h and (root / p).read_bytes() == subprocess.check_output(['git', 'show', f['parentCommit'] + ':' + p], cwd=root)
sqlpath = 'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'
sql = load(root / sqlpath)
oldsql = json.loads(subprocess.check_output(['git', 'show', f['parentCommit'] + ':' + sqlpath], cwd=root))
assert len(sql['cases']) == 56 and len(oldsql['cases']) == 55 and sql['cases'][:55] == oldsql['cases']
assert sql['cases'][-1]['id'] == 'special-trigger-damage-bonus'
pairs = load(w / 'original-all110-pairs-owner-terminal-v1.json')
result = load(w / 'original-all110-pairs-result-v1.json')
assert pairs['exitCode'] == 0 and pairs['actualOriginalDirections'] == 110 and pairs['allFrozenRuntimeAndSourceHashesStable']
assert result['seed'] == 424242 and result['originalDeckCount'] == 11 and result['originalFullMatrixPairCount'] == len(result['completed']) == 110
assert pairs['resultSha256'] == sha(w / 'original-all110-pairs-result-v1.json')
proof = {
    'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': 'CHECK_AND_EXACT_CASE_METHOD_PARITY_PASS',
    'actualCases': len(rows), 'actualMethods': len(methods), 'passed': len(rows), 'failed': 0, 'skipped': 0,
    'oldCases': len(oldrows), 'oldMethods': len(oldmethods), 'oldCasesMultisetPreserved': True, 'oldMethodsPreserved': True,
    'oldOriginalCheckOutcomesRetainedNotRelabeled': dict(collections.Counter(t.get('outcome') for t in oldrows)),
    'newCases': 44, 'newMethods': 5, 'newMethodNames': sorted(methods - oldmethods),
    'sourceInputs': 3332, 'conformanceRuntimeFiles': 1419, 'nativeDebugRuntimeFilesStableNotCurrentNativeExecutionCertification': 23,
    'allFrozenAndExecutedInputsUnchanged': True, 'onlyCheckTrx': pin(current), 'originalBaselineTrx': pin(before),
    'allOriginalConformanceSourcesByteExactExceptOneExactExpectationCalibration': True,
    'soleCalibration': {'path': calibration_path, 'oldSha256': original['allOriginalConformanceInputs'][calibration_path], 'newSha256': sha(root / calibration_path), 'change': 'Void Gate target D damage1->2, original base E=1 and all original survival/restore/assertions retained'},
    'allNineOriginalFullSourcesByteExactAgainst7a': original['originalCompleteGameSources'],
    'allOriginal143PublicFullMethods110Pairs11Decks424242AndVictoryReplayAssertionsRetained': True,
    'actual110OriginalHelperDirectionsExecutedSeparately': pin(w / 'original-all110-pairs-owner-terminal-v1.json'),
    'allOriginal55SqlIdentitiesObjectsOrderAndClassSourcesRetainedOnly56Appended': True,
    'lockAtStart': start['lockAtStart'], 'lockAtStop': end['lockAtStop'],
    'currentFixedFullVisibleAndPhysicalWindowsAndWholePrintingCertification': 'OPEN', 'noSecondCheck': True,
}
target = w / 'check-original-case-method-and-input-retention-v1.json'
with target.open('x') as stream: json.dump(proof, stream, ensure_ascii=False, indent=2)
print('PASS check13348/7521; original13304/7516 multiset retained; +44/5; 3332/1419/23 stable; 9full143/110/11/424242 retained; one exact source calibration')
