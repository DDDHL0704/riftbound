using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

Check(args.Length == 2 && !File.Exists(args[1]), "Exact retained original partial frame and unused output required.");
var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
Check(RuleInputIdentity.Current.IdentitySha256 == "ec217d6fa40c76c0fa4da67cefa8a2f7b184a196bdcdef03e26acfcddede1468", "Actual original fixed7a API input identity, without current-WIP substitution.");
using var zip = new GZipStream(File.OpenRead(args[0]), CompressionMode.Decompress); using var original = JsonDocument.Parse(zip);
var saved = original.RootElement.Deserialize<MatchRecoveryFrame>(json)!; var room = saved.RoomId;
Check(room == "N27-RETARGET-E7879B5EEF" && saved.Commands.Count == 67 && saved.Events.Count == 530, "The exact first original late natural opening, not a new match.");
var settings = new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
Check(settings.Host == "127.0.0.1" && settings.Port == 55486 && settings.Database == "riftbound_here_native" && settings.Username == "codex_riftbound_audit", "Only own retained native database.");
settings.Options = "-c default_transaction_read_only=on"; await using var source = NpgsqlDataSource.Create(settings.ConnectionString);
var frame = await new PostgresMatchRecoveryStore(source).LoadAsync(room, default) ?? throw new Exception("Original partial room must remain in SQL.");
Check(Same(original.RootElement, JsonSerializer.SerializeToElement(frame, json)) && frame.IsConsistent && frame.OpeningSeed == saved.OpeningSeed && frame.OpeningSeed != 0 && frame.ReplayInitialState is { Tick: 0, CardObjects.Count: 0 }, "Every original frame field/null/omission, private seed and blank opening remains unchanged after the separate second match.");
var final = frame.AuthoritativeState!; var actors = final.Seats.Keys.ToArray();
Check(final.Status == MatchStatuses.InProgress && final.TurnNumber == 56 && final.PlayerScores.Values.All(v => v == 0) && actors.All(p => final.PlayerZones[p].MainDeck.Count == 7), "Literal partial state and failed at-least-nine deck precondition remain recorded, not relabeled as a completed game.");
var states = new Dictionary<(long, long), MatchState>(); var counts = new Dictionary<string, int>();
await using (var connection = await source.OpenConnectionAsync())
{
    Check((string)(await new NpgsqlCommand("show transaction_read_only", connection).ExecuteScalarAsync())! == "on", "Actual read-only connection.");
    await using (var query = new NpgsqlCommand("select last_event_sequence,payload::text from state_snapshots where match_id=@room order by id", connection))
    {
        query.Parameters.AddWithValue("room", room); await using var rows = await query.ExecuteReaderAsync();
        while (await rows.ReadAsync())
        {
            var raw = rows.GetString(1); var state = JsonSerializer.Deserialize<MatchState>(raw, json)!;
            Check(JsonNode.DeepEquals(JsonNode.Parse(raw), JsonSerializer.SerializeToNode(state, json)) && state.RuleInputs == RuleInputIdentity.Current && states.TryAdd((state.Tick, rows.GetInt64(0)), state), "Every original authority field/null/omission and tick/sequence retained.");
        }
    }
    Check(states.Count == 67 && frame.Commands.All(c => c.Accepted && c.RuleInputs == RuleInputIdentity.Current && states.ContainsKey((c.CompletedTick, c.CompletedEventSequence))), "All original 67 accepted commands retain their individual historical authority."); counts["state_snapshots"] = states.Count;
    var expected = frame.Commands.GroupBy(c => c.CompletedTick).Select(g => g.OrderBy(c => c.CompletedEventSequence).Last()).SelectMany(c => actors.Select(actor => (c.CompletedTick, c.CompletedEventSequence, actor))).ToHashSet();
    foreach (var table in new[] { "snapshots", "action_prompts" })
    {
        await using var query = new NpgsqlCommand($"select player_id,last_event_sequence,payload::text from {table} where match_id=@room order by id", connection); query.Parameters.AddWithValue("room", room);
        await using var rows = await query.ExecuteReaderAsync(); var actual = new HashSet<(long, long, string)>();
        while (await rows.ReadAsync())
        {
            var actor = rows.GetString(0); var sequence = rows.GetInt64(1); var raw = rows.GetString(2); using var document = JsonDocument.Parse(raw);
            var tick = document.RootElement.GetProperty(table == "snapshots" ? "tick" : "snapshotTick").GetInt64();
            Check(states.TryGetValue((tick, sequence), out var state) && actual.Add((tick, sequence, actor)), "Each original private row retains its viewer/tick/sequence binding.");
            var typed = table == "snapshots" ? JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<SnapshotDto>(raw, json), json) : JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<ActionPromptDto>(raw, json), json);
            var projected = table == "snapshots" ? JsonSerializer.SerializeToNode(ResolutionResult.BuildSnapshots(state!)[actor], json) : JsonSerializer.SerializeToNode(ResolutionResult.BuildPrompts(state!)[actor], json);
            Check(JsonNode.DeepEquals(JsonNode.Parse(raw), typed) && JsonNode.DeepEquals(JsonNode.Parse(raw), projected), "Every original private field/null/omission survives typed read and equals its original historical projection.");
            foreach (var other in actors.Where(p => p != actor)) foreach (var id in state!.PlayerZones[other].MainDeck.Concat(state.PlayerZones[other].Hand)) Check(!raw.Contains("\"" + id + "\"", StringComparison.Ordinal), "Opponent hidden identities remain absent.");
        }
        Check(actual.SetEquals(expected), "Both viewers retain the exact original latest private projection at every tick."); counts[table] = actual.Count;
    }
}
var replaySession = new MatchSession(frame.ReplayInitialState!, new CoreRuleEngine(), NoopMatchJournal.Instance); var histories = 0;
Check(frame.Commands.All(c => !c.CommandType.StartsWith("DEV_SEED_SCENARIO", StringComparison.Ordinal)), "Original ordinary match contains no development seed command.");
foreach (var command in frame.Commands.OrderBy(c => c.StartedEventSequence).ThenBy(c => c.CompletedEventSequence).ThenBy(c => c.ClientIntentId, StringComparer.Ordinal))
{
    var raw = command.RawCommand!.Value; var intent = GameCommandJsonMapper.Map(raw);
    var result = intent switch { ReadyCommand => await replaySession.ReadyAsync(command.PlayerId, command.ClientIntentId, raw, default), SubmitDeckCommand deck => await replaySession.SubmitDeckAsync(command.PlayerId, command.ClientIntentId, deck, raw, default), _ => await replaySession.SubmitAsync(command.PlayerId, command.ClientIntentId, intent, raw, default) };
    Check(result.Accepted == command.Accepted && result.ErrorMessage == command.ErrorMessage && result.State.Tick == command.CompletedTick && Same(JsonSerializer.SerializeToElement(result.State, json), JsonSerializer.SerializeToElement(states[(command.CompletedTick, command.CompletedEventSequence)], json)), "Every original accepted command and complete historical state independently replays, without submitting anything to the live room.");
    var events = frame.Events.Where(e => e.Sequence > command.StartedEventSequence && e.Sequence <= command.CompletedEventSequence).OrderBy(e => e.Sequence).ThenBy(e => e.Order).ToArray();
    Check(events.Length == result.Events.Count, "Exact original event span count.");
    for (var i = 0; i < events.Length; i++) Check(JsonNode.DeepEquals(EventNode(events[i].Event), EventNode(result.Events[i])), "Every original event kind/description/payload exact; only unordered simultaneous rune actor sets are normalized.");
    histories++;
}
Check(histories == 67 && (await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame, new CoreRuleEngine(), default)).Count == 0, "All original partial history and complete unchanged recovery replay pass.");
await File.WriteAllTextAsync(args[1], JsonSerializer.Serialize(new { status = "PASS_INDEPENDENT_ORIGINAL_LATE_PARTIAL_67_ACTIONS_ALL_HISTORY_REPLAY_NOT_A_COMPLETED_GAME", room, commands = 67, events = 530, histories, actualHistoricalPayloads = counts, actualRuleInputs = RuleInputIdentity.Current, actualReadOnlyConnection = true, everyOriginalFieldNullOmissionAndPrivateProjectionExact = true, originalSeedBlankOpeningAndAcceptedHistoryUnchanged = true, originalNineCardPreconditionFailed = true, completedGameOrNativeControlAcceptance = false }, json));
Console.WriteLine("PASS original partial67/530 all authority/private histories and complete replay; it remains a partial game.");
static void Check(bool condition, string message) { if (!condition) throw new Exception(message); }
static bool Same(JsonElement left, JsonElement right) => JsonNode.DeepEquals(JsonNode.Parse(left.GetRawText()), JsonNode.Parse(right.GetRawText()));
JsonNode EventNode(GameEvent value)
{
    var node = JsonSerializer.SerializeToNode(value, json)!;
    if (value.Kind == "RUNE_POOL_CLEARED" && node["payload"]?["playerIds"] is JsonArray ids) node["payload"]!["playerIds"] = new JsonArray(ids.Select(i => i!.GetValue<string>()).Order(StringComparer.Ordinal).Select(i => JsonValue.Create(i)).ToArray());
    return node;
}
