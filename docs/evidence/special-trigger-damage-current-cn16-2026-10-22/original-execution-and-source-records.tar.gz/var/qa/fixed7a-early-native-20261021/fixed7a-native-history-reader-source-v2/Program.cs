using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

if(args.SequenceEqual(new[]{"--identity-only"})){Console.WriteLine(JsonSerializer.Serialize(RuleInputIdentity.Current,new JsonSerializerOptions(JsonSerializerDefaults.Web)));return;}
Check(args.Length==2,"Exact original evidence and unused output required.");var work=Path.GetFullPath(args[0]);var output=Path.GetFullPath(args[1]);Check(!File.Exists(output),"Never overwrite an independent readback.");
var json=new JsonSerializerOptions(JsonSerializerDefaults.Web){WriteIndented=true};
using var ready=JsonDocument.Parse(File.ReadAllText(Path.Combine(work,"live-current-ci-main-ready-v3.json")));var room=ready.RootElement.GetProperty("room").GetString()!;
Check(ready.RootElement.GetProperty("baseCommit").GetString()=="7a334e7c1cab701d9506b6cf94f3f3a86d316ef8"&&ready.RootElement.GetProperty("nativeAcceptedGameplayCommands").GetInt32()==3,"Exact fixed7a candidate and three CI exported native interaction submissions; full CI and visible acceptance remain separate.");
using var entryDoc=JsonDocument.Parse(File.ReadAllText(Path.Combine(work,"actual-safe-native-prefix-v3/pending-original-native-prefix-receipt.json")));var entry=entryDoc.RootElement;Check(entry.GetProperty("room").GetString()==room,"Same original room.");var actors=entry.GetProperty("players").EnumerateArray().Select(x=>x.GetString()!).ToArray();var a=actors[0];var b=actors[1];var n=entry.GetProperty("acceptedCommands").GetInt32();
var settings=new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));Check(settings.Host=="127.0.0.1"&&settings.Port==55486&&settings.Database=="riftbound_here_native"&&settings.Username=="codex_riftbound_audit","Only own native database.");settings.Options="-c default_transaction_read_only=on";await using var source=NpgsqlDataSource.Create(settings.ConnectionString);
var frame=await new PostgresMatchRecoveryStore(source).LoadAsync(room,default)??throw new Exception("Actual SQL frame required.");using var finalDoc=Read(ready.RootElement.GetProperty("rawFinalFrame").GetString()!);
Check(Same(finalDoc.RootElement,JsonSerializer.SerializeToElement(frame,json)),"Every original final frame field, null and omission equals the independent SQL read.");
using var oldDoc=Read(Path.Combine(work,"actual-safe-native-main-v3/before-ci-native-cold-reconnect-original-frame-v3.json.gz"));var old=oldDoc.RootElement.Deserialize<MatchRecoveryFrame>(json)!;
Check(frame.IsConsistent&&frame.Commands.Count==n+20&&frame.Events.Count==ready.RootElement.GetProperty("events").GetInt32()&&old.Commands.Count==n&&frame.Commands.All(c=>c.Accepted&&c.RuleInputs==RuleInputIdentity.Current)&&frame.AuthoritativeState!.RuleInputs==RuleInputIdentity.Current,"Exact accepted original prefix plus3 native and17 gateway actions and current input identity.");
Check(frame.OpeningSeed==old.OpeningSeed&&frame.OpeningSeed!=0&&frame.ReplayInitialState is{Tick:0,CardObjects.Count:0}&&Same(JsonSerializer.SerializeToElement(frame.ReplayInitialState,json),oldDoc.RootElement.GetProperty("replayInitialState")),"Original private nonzero seed and blank opening remain exact, not migrated.");
Check(Same(JsonSerializer.SerializeToElement(frame.Commands.Take(n),json),oldDoc.RootElement.GetProperty("commands"))&&Same(JsonSerializer.SerializeToElement(frame.Events.Take(old.Events.Count),json),oldDoc.RootElement.GetProperty("events")),"Every original prefix command and event field is unchanged.");
using var prefix=JsonDocument.Parse(File.ReadAllText(Path.Combine(work,"actual-safe-native-prefix-v3/original-accepted-native-prefix-intents.json")));using var continuation=JsonDocument.Parse(File.ReadAllText(ready.RootElement.GetProperty("originalScoreIntentFile").GetString()!));
Check(prefix.RootElement.GetArrayLength()==n&&continuation.RootElement.GetArrayLength()==17,"All exact original gateway intents retained.");
using var nativeDoc=Read(Path.Combine(work,"actual-safe-native-main-v3/after-native-priority-pass-2-original-frame-v3.json.gz"));
Check(Same(JsonSerializer.SerializeToElement(frame.Commands.Take(n+3),json),nativeDoc.RootElement.GetProperty("commands"))&&Same(JsonSerializer.SerializeToElement(frame.Events.Take(nativeDoc.RootElement.GetProperty("events").GetArrayLength()),json),nativeDoc.RootElement.GetProperty("events")),"Every original native accepted command/event field is retained through same-room continuation.");
for(var i=0;i<frame.Commands.Count;i++){
 if(i>=n&&i<n+3)continue;
 var row=i<n?prefix.RootElement[i]:continuation.RootElement[i-n-3];
 Check(frame.Commands[i].PlayerId==row.GetProperty("actor").GetString()&&Same(frame.Commands[i].RawCommand!.Value,row.GetProperty("rawCommand")),"Every actual gateway actor and complete raw intent equals its original accepted input.");
}
Check(frame.Commands.All(c=>c.PlayerId==c.PlayerId.Trim().ToLowerInvariant()),"All accepted canonical actors are literal lower-case identities.");
Check(frame.Commands[n].PlayerId==b&&frame.Commands[n].CommandType=="PAY_COST"&&frame.Commands[n].RawCommand!.Value.GetProperty("paymentChoiceIds").EnumerateArray().Select(x=>x.GetString()).SequenceEqual(new[]{"KEEP_ALL"})&&frame.Commands[n+1].PlayerId==b&&frame.Commands[n+2].PlayerId==a&&frame.Commands.Skip(n+1).Take(2).All(c=>c.CommandType=="PASS_PRIORITY"),"Literal original KEEP and two actual priority owners; these three are actual CI exported native interaction submissions, with no hardware/visible claim.");
Check(frame.Commands.All(c=>c.CommandType!="SURRENDER")&&frame.Events.Count(e=>e.Event.Kind=="MATCH_WON")==1&&frame.Events.All(e=>e.Event.Kind is not("PLAYER_SURRENDERED" or "MATCH_SURRENDERED" or "DECK_OUT" or "DECK_EXHAUSTED_LOSS")),"One ordinary win, no surrender or deck exhaustion.");
var scores=frame.Events.Where(e=>e.Event.Kind=="SCORE_GAINED").Select(e=>JsonSerializer.SerializeToElement(e.Event.Payload,json)).ToArray();Check(scores.Length==8&&scores.Select(x=>x.GetProperty("score").GetInt32()).SequenceEqual(Enumerable.Range(1,8))&&scores.All(x=>x.GetProperty("playerId").GetString()==a&&x.GetProperty("amount").GetInt32()==1)&&scores[0].GetProperty("reason").GetString()=="BATTLEFIELD_CONQUERED_SCORE"&&scores.Skip(1).All(x=>x.GetProperty("reason").GetString()=="BATTLEFIELD_HELD_SCORE"),"Exactly one conquest and seven holds supply all8 points.");
var final=frame.AuthoritativeState!;Check(final.Status==MatchStatuses.Finished&&final.WinnerPlayerId==a&&final.PlayerScores[a]==8&&final.PlayerScores[b]==0&&actors.All(p=>final.PlayerZones[p].MainDeck.Count>0),"Normal score winner and both nonempty decks.");
var states=new Dictionary<(long Tick,long Sequence),MatchState>();var counts=new Dictionary<string,int>();var pending=0;
await using(var connection=await source.OpenConnectionAsync()){
 Check((string)(await new NpgsqlCommand("show transaction_read_only",connection).ExecuteScalarAsync())! == "on","Actual read-only connection.");
 foreach(var command in frame.Commands.Skip(n).Take(3)){
  await using var q=new NpgsqlCommand("select payload::text from action_prompts where match_id=@room and player_id=@actor and prompt_tick=@tick and last_event_sequence=@sequence",connection);
  q.Parameters.AddWithValue("room",room);q.Parameters.AddWithValue("actor",command.PlayerId);q.Parameters.AddWithValue("tick",command.StartedTick);q.Parameters.AddWithValue("sequence",command.StartedEventSequence);
  var originalPromptText=(string)(await q.ExecuteScalarAsync())!;Check(originalPromptText is not null,"Each native action has its exact previously persisted original private prompt.");
  using var promptDocument=JsonDocument.Parse(originalPromptText!);var raw=command.RawCommand!.Value;
  Check(raw.GetProperty("promptId").GetString()==promptDocument.RootElement.GetProperty("promptId").GetString()&&raw.GetProperty("snapshotTick").GetInt64()==command.StartedTick,"Each original native intent stamps the independently stored prompt and start tick.");
  Check(raw.GetProperty("cmdType").GetString()==command.CommandType,"Native raw intent type equals accepted command type.");
 }

 foreach(var (table,column) in new[]{("snapshots","snapshot_tick"),("action_prompts","prompt_tick")}){var sql=$"select pg_get_constraintdef(oid) from pg_constraint where conrelid='{table}'::regclass and contype='u'";await using var command=new NpgsqlCommand(sql,connection);var constraint=(string)(await command.ExecuteScalarAsync())!;Check(constraint==$"UNIQUE (match_id, player_id, {column})","Actual existing private storage key is viewer plus tick; no schema migration.");}
 await using(var query=new NpgsqlCommand("select last_event_sequence,payload::text from state_snapshots where match_id=@room order by id",connection)){
  query.Parameters.AddWithValue("room",room);await using var rows=await query.ExecuteReaderAsync();while(await rows.ReadAsync()){
   var text=rows.GetString(1);var state=JsonSerializer.Deserialize<MatchState>(text,json)!;Check(JsonNode.DeepEquals(JsonNode.Parse(text),JsonSerializer.SerializeToNode(state,json))&&state.RuleInputs==RuleInputIdentity.Current,"All historical authoritative fields/nulls and exact current identity.");Check(states.TryAdd((state.Tick,rows.GetInt64(0)),state),"Tick plus event sequence unique; no historical row hidden.");
   if(state.PendingRuleChoice?.Request.Kind=="SPELL_CHOICE_REMAKE"){pending++;var choice=state.PendingRuleChoice;Check(choice.Request.PlayerId==b&&choice.Answers.Count==0&&choice.Request.Options.Any(o=>o.Id=="KEEP_ALL")&&!choice.Request.Options.Any(o=>o.Label.Contains("模式 ")||o.Label.Contains("目的地")),"One literal target-only original pending choice; no invented edit or broader mode grant.");}
  }
 }
 Check(states.Count==frame.Commands.Count&&frame.Commands.All(c=>states.ContainsKey((c.CompletedTick,c.CompletedEventSequence))),"Every accepted command has its exact original authoritative historical row.");counts["state_snapshots"]=states.Count;
 var latestPrivateAtEachTick=frame.Commands.GroupBy(c=>c.CompletedTick).Select(g=>g.OrderBy(c=>c.CompletedEventSequence).Last()).ToArray();
 var expectedPrivate=latestPrivateAtEachTick.SelectMany(c=>actors.Select(p=>(c.CompletedTick,c.CompletedEventSequence,p))).ToHashSet();
 foreach(var table in new[]{"snapshots","action_prompts"}){
  await using var query=new NpgsqlCommand($"select player_id,last_event_sequence,payload::text from {table} where match_id=@room order by id",connection);query.Parameters.AddWithValue("room",room);await using var rows=await query.ExecuteReaderAsync();var keys=new HashSet<(long,long,string)>();
  while(await rows.ReadAsync()){
   var actor=rows.GetString(0);var sequence=rows.GetInt64(1);var text=rows.GetString(2);using var document=JsonDocument.Parse(text);var tick=document.RootElement.GetProperty(table=="snapshots"?"tick":"snapshotTick").GetInt64();Check(states.TryGetValue((tick,sequence),out var state)&&keys.Add((tick,sequence,actor)),"Each unique private row binds the original authority, tick, event sequence and viewer.");
   var typed=table=="snapshots"?JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<SnapshotDto>(text,json),json):JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<ActionPromptDto>(text,json),json);Check(JsonNode.DeepEquals(JsonNode.Parse(text),typed),"Every original private field, null and conditional omission survives typed read.");
   var projected=table=="snapshots"?JsonSerializer.SerializeToNode(ResolutionResult.BuildSnapshots(state!)[actor],json):JsonSerializer.SerializeToNode(ResolutionResult.BuildPrompts(state!)[actor],json);Check(JsonNode.DeepEquals(JsonNode.Parse(text),projected),"Entire stored private row equals the projection of the exact original state.");
   var other=actor==a?b:a;foreach(var id in state!.PlayerZones[other].Hand.Concat(state.PlayerZones[other].MainDeck))Check(!text.Contains("\""+id+"\"",StringComparison.Ordinal),"Literal opponent hidden hand/deck object identity is absent.");Check(!document.RootElement.TryGetProperty("openingSeed",out _),"Private opening seed is not exposed as a snapshot/prompt field.");
  }
  Check(keys.SetEquals(expectedPrivate),"Both viewers retain the exact latest original event sequence at every tick, matching the independently checked existing private-row key; all authoritative same-tick histories remain separate.");counts[table]=keys.Count;
 }
}
var keptCommand=frame.Commands[n];var kept=states[(keptCommand.CompletedTick,keptCommand.CompletedEventSequence)];var spell=kept.StackItems.Single();var oldTarget=entry.GetProperty("originalTargetObjectId").GetString()!;var otherTarget=entry.GetProperty("newTargetObjectId").GetString()!;var spellSource=entry.GetProperty("targetSourceObjectId").GetString()!;
Check(spell.ControllerId==b&&spell.TargetObjectIds.SequenceEqual(new[]{oldTarget})&&kept.PendingRuleChoice is null&&frame.Events.All(e=>e.Event.Kind!="SPELL_CHOICES_REMADE"),"KEEP preserves the exact original target and completes control without a fabricated remake.");
var parentCommand=frame.Commands[n+2];var parent=states[(parentCommand.CompletedTick,parentCommand.CompletedEventSequence)];var initial=old.AuthoritativeState!;
Check(parent.CardObjects[oldTarget].Power==Math.Max(1,initial.CardObjects[oldTarget].Power-1)&&parent.CardObjects[otherTarget].Power==initial.CardObjects[otherTarget].Power&&parent.PlayerZones[b].Hand.Count==initial.PlayerZones[b].Hand.Count+1,"Only the retained original target gets the printed modifier; only the actual controller draws1.");
Check(parent.PlayerZones[a].Graveyard.Contains(spellSource)&&parent.CardPlays.Finalized.Single(p=>p.Source.ObjectId==spellSource).PlayerId==a&&parent.CardPlays.Resolved.Single(p=>p.Source.ObjectId==spellSource).PlayerId==b,"Physical owner, original finalizer and current resolver remain distinct.");
Check(JsonNode.DeepEquals(JsonSerializer.SerializeToNode(initial.RunePools,json),JsonSerializer.SerializeToNode(parent.RunePools,json)),"Original costs are not paid again during KEEP or parent resolution.");
Check(final.TurnNumber==parent.TurnNumber+14&&frame.Commands.Skip(n+3).Count(c=>c.CommandType=="END_TURN")==14&&frame.Commands.Skip(n+3).Count(c=>c.CommandType=="MOVE_UNIT")==1&&frame.Commands.Skip(n+3).Count(c=>c.CommandType=="PASS_FOCUS")==2,"Exactly original normal movement, two focus passes and14 turn endings.");
var replaySession=new MatchSession(frame.ReplayInitialState!,new CoreRuleEngine(),NoopMatchJournal.Instance);var replayedHistoricalStates=0;
Check(frame.Commands.All(c=>!c.CommandType.StartsWith("DEV_SEED_SCENARIO",StringComparison.Ordinal)),"Real ordinary match contains no development seed command.");
foreach(var command in frame.Commands.OrderBy(c=>c.StartedEventSequence).ThenBy(c=>c.CompletedEventSequence).ThenBy(c=>c.ClientIntentId,StringComparer.Ordinal))
{
 var raw=command.RawCommand!.Value;var intent=GameCommandJsonMapper.Map(raw);
 var replayedStep=intent switch {
  ReadyCommand=>await replaySession.ReadyAsync(command.PlayerId,command.ClientIntentId,raw,default),
  SubmitDeckCommand deck=>await replaySession.SubmitDeckAsync(command.PlayerId,command.ClientIntentId,deck,raw,default),
  _=>await replaySession.SubmitAsync(command.PlayerId,command.ClientIntentId,intent,raw,default)};
 Check(replayedStep.Accepted==command.Accepted&&replayedStep.ErrorMessage==command.ErrorMessage&&replayedStep.State.Tick==command.CompletedTick,"Every original linear action retains accepted/error/tick behavior.");
 Check(states.TryGetValue((command.CompletedTick,command.CompletedEventSequence),out var originalState)&&JsonNode.DeepEquals(JsonSerializer.SerializeToNode(replayedStep.State,json),JsonSerializer.SerializeToNode(originalState,json)),"Every field/null/omission of every independently stored original historical state equals its actual sequential replay.");
 var originalEvents=frame.Events.Where(e=>e.Sequence>command.StartedEventSequence&&e.Sequence<=command.CompletedEventSequence).OrderBy(e=>e.Sequence).ThenBy(e=>e.Order).ToArray();
 Check(originalEvents.Length==replayedStep.Events.Count,"Every original event span has its literal original count.");
 for(var i=0;i<originalEvents.Length;i++)Check(JsonNode.DeepEquals(EventNode(originalEvents[i].Event),EventNode(replayedStep.Events[i])),"Every replayed original event kind, description and complete payload is exact; only simultaneous rune-pool actor sets have no order.");
 replayedHistoricalStates++;Console.WriteLine($"LINEAR_ORIGINAL_HISTORY_PASS {replayedHistoricalStates}/{frame.Commands.Count} tick={replayedStep.State.Tick} sequence={command.CompletedEventSequence}");
}
Check(replayedHistoricalStates==states.Count,"Every original historical state is replayed exactly once without resubmission to the live room.");
Check(pending==1,"One original pending target choice; no draft was silently created.");var errors=await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame,new CoreRuleEngine(),default);Check(errors.Count==0,"All original blank-opening commands/events and final state replay: "+string.Join(';',errors));
var result=new{status="PASS_INDEPENDENT_FIXED7A_CI_EXPORTED_NATIVE3_GATEWAY17_ALL_SQL_HISTORY_AND_NORMAL_SCORE_REPLAY_NOT_VISIBLE_OR_WINDOWS",room,commands=frame.Commands.Count,events=frame.Events.Count,originalPrefix=n,gatewayContinuationCommands=17,nativeAcceptedGameplayCommands=3,actualHistoricalPayloads=counts,originalPendingStates=pending,originalDraftStates=0,winningScore=8,losingScore=0,finalTurn=final.TurnNumber,allOriginalFieldsNullConditionalOmissionsAndPrivateProjectionValuesExact=true,everyOriginalHistoricalStateReplayedExactlyOnce=true,verificationMethod="Independent literal sequential replay plus unchanged complete production recovery-frame validation",usesPreviouslyVerifiedLinearHarness=true,priorCandidateQuadraticTimeoutNotThisRun=true,originalRoomAllAcceptedHistoryPrivateSeedAndBlankInitialPreserved=true,literalKeepTargetCostDrawOwnerAndOneConquestSevenHoldsChecks=true,actualReadOnlyConnection=true,privateStorageContract="Latest projection per viewer/tick; same-tick earlier authoritative histories remain retained, superseded private rows are not claimed",actualRuleInputs=RuleInputIdentity.Current,completeCurrentCandidateFullCiVisibleAndWindowsAcceptanceRemainSeparate=true,visibleAndPhysicalWindowsAcceptance=false};await File.WriteAllTextAsync(output,JsonSerializer.Serialize(result,json));Console.WriteLine(JsonSerializer.Serialize(result,json));
static JsonDocument Read(string path){using var zip=new GZipStream(File.OpenRead(path),CompressionMode.Decompress);return JsonDocument.Parse(zip);}
bool Same(JsonElement a,JsonElement b)=>JsonNode.DeepEquals(JsonNode.Parse(a.GetRawText()),JsonNode.Parse(b.GetRawText()));
static void Check(bool value,string reason){if(!value)throw new Exception(reason);}

JsonNode EventNode(GameEvent value)
{
 var node=JsonSerializer.SerializeToNode(value,json)!;
 if(value.Kind=="RUNE_POOL_CLEARED"&&node["payload"]?["playerIds"] is JsonArray ids)
  node["payload"]!["playerIds"]=new JsonArray(ids.Select(i=>i!.GetValue<string>()).Order(StringComparer.Ordinal).Select(i=>JsonValue.Create(i)).ToArray());
 return node;
}
