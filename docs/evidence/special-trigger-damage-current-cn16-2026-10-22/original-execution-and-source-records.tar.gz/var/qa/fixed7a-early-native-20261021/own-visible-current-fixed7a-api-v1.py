from pathlib import Path
import ast,datetime,fcntl,hashlib,json,os,resource,socket,subprocess,time,urllib.request
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on');tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486')
definition=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py';nodes=[n for n in ast.parse(definition.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(definition),'exec'),globals())
prior=load(root/'var/qa/special-trigger-damage-current-cn16-20261021/actual-current-special-trigger-sql-owner-terminal-v1.json');assert prior['status'].startswith('PASS_CURRENT_SPECIAL_TRIGGER_') and prior['ownPostgresStopped'];audit=prior['actualAuditRoomsAtStop'];native=prior['actualNativeRoomsAtStop'];assert len(audit)==316 and len(native)==65
f=load(w/'frozen-fixed7a-native-composition-v1.json');runtime=Path(f['apiRuntimeRoot']);stable=lambda:all(sha(runtime/p)==h for p,h in f['runtimeFiles'].items()) and all(sha(Path(a['app'])/p)==h for a in f['nativeApps'] for p,h in f['ciManagedAndPckPayloads'].items());assert stable();ready=w/'visible-current-api-owner-ready-v1.json';stop=w/'visible-current-api-owner-stop-v1.json';terminal=w/'visible-current-api-owner-terminal-v1.json';assert not any(p.exists() for p in [ready,stop,terminal]);guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof={'status':'STARTING_FIXED7A_VISIBLE_UI_API_ONLY_NOT_YET_PRODUCT_ACCEPTANCE','startedAtUtc':now(),'fixedCommit':f['fixedCommit'],'fixedCiRun':f['fixedCiRun'],'actualRuleInputs':f['actualRuleInputs'],'allOriginal316Audit65NativeSevenTablesProtected':True,'originalRoomHistoriesNeverMigrated':True,'lockAtStart':observe_lock(),'sourceIsFrozen7aApi46NotMutableRootCandidate':True};api=power=None;started=False;before_audit=before_native=None
try:
 assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);sock.mkdir(exist_ok=True);subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'visible-current-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 assert rooms('riftbound_acceptance')==audit and rooms('riftbound_here_native')==native;before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',native)
 (w/'visible-current316-audit65-native-seven-table-baseline-v1.json').write_text(json.dumps({'atUtc':now(),'auditRooms':audit,'nativeRooms':native,'auditSevenTables':before_audit,'nativeSevenTables':before_native},indent=2)+'\n')
 env=dict(os.environ,ASPNETCORE_ENVIRONMENT='Production',ASPNETCORE_URLS='http://127.0.0.1:15847',ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit',DOTNET_DbgEnableMiniDump='0');env.pop('DOTNET_STARTUP_HOOKS',None)
 with (w/'visible-current-fixed7a-api-v1.log').open('xb') as log:api=subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet',str(runtime/'Riftbound.Api.dll')],cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 until=time.monotonic()+30
 while True:
  assert api.poll() is None and time.monotonic()<until
  try:
   with urllib.request.urlopen('http://127.0.0.1:15847/health',timeout=.5) as response:health=json.load(response)
   assert health['persistenceMode']=='postgres' and health['environment']=='Production';break
  except OSError:time.sleep(.1)
 assert set(subprocess.check_output(['/usr/sbin/lsof','-tiTCP:15847','-sTCP:LISTEN'],text=True).splitlines())=={str(api.pid)};proof.update(status='FIXED7A_VISIBLE_UI_API_READY_ONLY_NO_NATIVE_OR_NEW_GAME_CLAIM',ownPid=os.getpid(),ownApiPid=api.pid,health=health,readyAtUtc=now());ready.write_text(json.dumps(proof,indent=2)+'\n');print(proof['status'],flush=True)
 until=time.monotonic()+2700
 while not stop.exists():
  assert api.poll() is None and time.monotonic()<until;time.sleep(.2)
 proof['visibleAcceptanceEvidence']=load(stop);proof['status']='OWN_FIXED7A_VISIBLE_UI_API_STOP_REQUESTED_WITH_EXACT_RESULT_SCOPE'
except BaseException as error:proof.update(status='VISIBLE_OWN_API_STOPPED_WITH_PARTIAL_OR_ERROR_SCOPE_RETAINED',errorType=type(error).__name__,error=str(error));raise
finally:
 if api is not None:
  if api.poll() is None:api.terminate();api.wait(timeout=25)
  proof['ownApiStopped']=api.poll() is not None
 if started:
  if before_audit is not None:proof.update(allOriginal316AuditSevenTablesExact=digests('riftbound_acceptance',audit)==before_audit,allOriginal65NativeSevenTablesExact=digests('riftbound_here_native',native)==before_native,actualAuditRoomsAtStop=rooms('riftbound_acceptance'),actualNativeRoomsAtStop=rooms('riftbound_here_native'))
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None:
  if power.poll() is None:power.terminate();power.wait(timeout=10)
  proof['boundIdleAssertionEnded']=power.poll() is not None
 proof.update(finishedAtUtc=now(),lockAtStop=observe_lock(),allFrozenApi46AndBoth373CiPayloadsStillExact=stable());terminal.write_text(json.dumps(proof,indent=2)+'\n');fcntl.flock(guard,fcntl.LOCK_UN)
