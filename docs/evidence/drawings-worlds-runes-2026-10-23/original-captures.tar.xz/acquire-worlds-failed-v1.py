from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen
import gzip
import hashlib
import json
import re

Q = Path(__file__).resolve().parent

class Article(HTMLParser):
    def __init__(self):
        super().__init__(); self.text = []; self.images = []; self.links = []
    def handle_data(self, data):
        if data.strip(): self.text.append(data.strip())
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'img': self.images.append(attrs)
        if tag == 'a' and 'href' in attrs: self.links.append(attrs['href'])

def acquire(label, url, suffix):
    record = {'label': label, 'url': url, 'startedAtUtc': datetime.now(timezone.utc).isoformat()}
    try:
        response = urlopen(Request(url, headers={'User-Agent': 'Mozilla/5.0 Riftbound source audit'}), timeout=30)
    except HTTPError as error:
        response = error
    with response:
        raw = response.read()
        record.update(httpStatus=response.status, resolvedUrl=response.url,
                      responseHeaders=dict(response.headers), acquiredAtUtc=datetime.now(timezone.utc).isoformat())
    name = label + '.' + suffix
    (Q/name).write_bytes(raw)
    record.update(rawFile=name, rawBytes=len(raw), rawSha256=hashlib.sha256(raw).hexdigest())
    if suffix == 'html':
        match = re.search(r'<script id="__NEXT_DATA__"[^>]*>(.*?)</script>', raw.decode())
        page = json.loads(match.group(1))['props']['pageProps']['page']
        bodies = [b['richText']['body'] for b in page['blades'] if isinstance(b.get('richText'),dict) and 'body' in b['richText']]
        article = Article()
        for body in bodies: article.feed(body)
        record.update(page=page, bodyHtml=bodies, bodySha256=[hashlib.sha256(b.encode()).hexdigest() for b in bodies],
                      text='\n'.join(article.text), images=article.images, links=article.links)
    (Q/(label+'.receipt.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    print(label, record['httpStatus'], record['rawBytes'])

acquire('worlds-esports-en', 'https://lolesports.com/en-US/news/introducing-the-worlds-2026-merch-collection', 'html')
acquire('worlds-esports-product', 'https://cmsassets.rgpub.io/sanity/images/dsfx7636/news_live/33854d00271d487306fc7021e85bae1de74e3055-1920x1080.jpg', 'jpg')
