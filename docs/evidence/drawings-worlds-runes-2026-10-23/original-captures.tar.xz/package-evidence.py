from datetime import datetime, timezone
from pathlib import Path
import hashlib
import io
import json
import tarfile

ROOT = Path('/Users/dinghaolin/MyProjects/riftbound')
WT = ROOT.parent / '.worktrees/riftbound-parallel-official-audit-20261023'
Q = Path(__file__).resolve().parent
OUT = WT / 'docs/evidence/drawings-worlds-runes-2026-10-23'
OUT.mkdir(parents=True, exist_ok=True)
sha = lambda b: hashlib.sha256(b).hexdigest()
def write(p, value):
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
def pin(path, base=ROOT):
    p = base/path
    return dict(path=path, sha256=sha(p.read_bytes()), bytes=p.stat().st_size)

catalog_path = 'docs/evidence/source-round-2026-10-21/originals/en-after-full-rows-checker-adapter-v1.json'
catalog = json.loads((ROOT/catalog_path).read_text())['data']
names = ['Black Market', 'Cosmic Vista', "Hunters' Circle", 'Unforgiven']
rune_names = ['Order Rune','Chaos Rune','Fury Rune','Calm Rune','Mind Rune','Body Rune']
candidates = {name:[x for x in catalog if x['name']==name] for name in names+rune_names}
assert [len(candidates[n]) for n in names] == [1,1,1,3]
assert all(len(candidates[n])==5 for n in rune_names)
write(Q/'catalog-candidates.json', dict(source=pin(catalog_path), recordsByName=candidates,
    exactProductPrintingMappingConfirmed=False, semanticEquivalenceConfirmed=False))

article = json.loads((Q/'worlds-esports-en.parsed-v3.json').read_text())
source = (Q/'worlds-esports-en.html').read_text()
assert sha(source.encode()) == article['rawSha256']
assert len(article['bodyHtml']) == len(article['bodyCharacterRanges']) == 1
begin,end = article['bodyCharacterRanges'][0]
assert source[begin:end] == article['bodyHtml'][0]
(Q/'worlds-esports-en.literal-body.html').write_text(article['bodyHtml'][0])
image = json.loads((Q/'worlds-esports-product.receipt.json').read_text())
assert image['httpStatus'] == article['httpStatus'] == 200
assert image['url'] in [x['src'] for x in article['images']]
for rec in (article,image):
    raw = (Q/rec['rawFile']).read_bytes()
    assert len(raw)==rec['rawBytes'] and sha(raw)==rec['rawSha256']
write(Q/'parser-failures-retained.json', dict(
    firstAttempt=dict(rawFile='worlds-esports-en-failed-parser-v1.html',
        rawSha256=sha((Q/'worlds-esports-en-failed-parser-v1.html').read_bytes()),
        parserFile='acquire-worlds-failed-v1.py',error="AttributeError: 'NoneType' object has no attribute 'group'",
        reason='LoL Esports response has no __NEXT_DATA__ page object.',
        receiptWasNotPersistedBeforeFailure=True, httpMetadataUnavailable=True),
    secondAttempt=dict(rawFile='worlds-esports-en.html',receipt='worlds-esports-en.receipt.json',
        parserFile='acquire-worlds-failed-v2.py',error="TypeError: 'int' object is not callable",
        reason='Local method offset collided with HTMLParser.offset integer.'),
    repair=dict(parserFile='acquire-worlds.py',parsedReceipt='worlds-esports-en.parsed-v3.json',
        sameSecondHttpCaptureReparsed=True, originalResponsesNeverRewritten=True)))

news_index_path='docs/evidence/source-round-2026-10-21/originals/news-reparsed-v2/all-current-news-original-readback-v2.json'
image_index_path='docs/evidence/news-body-source-observation-2026-10-16/all-known-news-img-acquisition.json'
news=next(x for x in json.loads((ROOT/news_index_path).read_text()) if x['url']=='https://mp.weixin.qq.com/s/kU9sVsIRwPAh-6Iu7Geh0A')
image_index=json.loads((ROOT/image_index_path).read_text())
by_url={x['url']:x for x in image_index['uniqueImages']}
topics=[
    'Regional tournament, Piltover Forge attendance card, Jayce prizes and event performers; not Gift product contents.',
    'Exhibition player lineup; no Gift product or rune printing faces.',
    'Resonance event, Mystic Vortex attendance card, Jayce prizes and event awards; not Gift product contents.',
    'Explicit 2025 Worlds champion SIGNATURE limited collection drawing; not Player Bundle.',
    'Venue entry and visitor activity QA; no Gift product or rune printing faces.'
]
observed=[]
for i,img in enumerate(news['images']):
    old=by_url[img['url']]; p=Path(old['path'])
    if not p.is_absolute(): p=ROOT/p
    assert sha(p.read_bytes())==old['sha256']
    observed.append(dict(ordinal=i+1,url=img['url'],localOriginalPath=str(p),sha256=old['sha256'],
        bytes=p.stat().st_size,dimensions=old['dimensions'],actuallyViewed=True,
        displayLimit='First image resized by viewer from1080x6171 to1050x6000; no tiny card-footer certification.' if i==0 else None,
        scopedObservation=topics[i],originalBytesReusedLocallyNotIncludedAgainInThisArchive=True))

gates_path='docs/evidence/global-2026-drawings-source-supplement-2026-10-23/seventeen-new-source-obligations.json'
raw_gates=json.loads((ROOT/gates_path).read_text())
gate_ids=set()
def collect(v):
    if isinstance(v,str) and v.startswith('GLOBAL_DRAWINGS2026_') and v.endswith('_20261023'):gate_ids.add(v)
    elif isinstance(v,dict):
        for x in v.values():collect(x)
    elif isinstance(v,list):
        for x in v:collect(x)
collect(raw_gates)
assert len(gate_ids)==17

report=dict(schemaVersion=1,reviewDate='2026-10-23',recordedAtUtc=datetime.now(timezone.utc).isoformat(),
    scope='Four existing Worlds source groups and six Gift foil-rune groups; all17 original Drawings gates retained.',
    sources=dict(originalDrawingsManifest=pin('docs/evidence/global-2026-drawings-source-supplement-2026-10-23/source-manifest.json'),
        originalGateSource=pin(gates_path),originalEnglishGallery=pin(catalog_path),
        sameDayCompleteGalleryComparison=pin('docs/evidence/en-gallery-gap-parallel-2026-10-23/source-manifest.json',WT)),
    currentWorldsArticle=dict(url=article['url'],httpStatus=article['httpStatus'],acquiredAtUtc=article['acquiredAtUtc'],
        rawSha256=article['rawSha256'],bodySha256=article['bodySha256'][0],declaredPublicationDate='2026-10-07',
        firstImagePublicationIndependentlyConfirmed=None,gameEffectiveDate=None,
        literalBodyRootPreserved=True,fullArticleLinks=article['links'],
        announcedCities=['Los Angeles','Dallas','New York City'],
        otherParagraphStageCities=['Los Angeles','Allen, TX','Brooklyn, NY'],
        productContents='Yasuo legend promo, three host-city battlefield promos, deckbox, foiled card sleeves and ecommerce-only game capsule.',
        noDedicatedRiftboundProductPageLinkedInArticle=True,
        commercialEventAvailabilityNotGameplayEffectiveDate=True),
    currentWorldsProductImage=dict(url=image['url'],rawSha256=image['rawSha256'],rawBytes=image['rawBytes'],
        dimensions=[1920,1080],actuallyViewed=True,
        earlierDrawingsImage=pin('docs/evidence/global-2026-drawings-source-supplement-2026-10-23/official-product-image-03.jpg'),
        bytesDifferFromEarlierDrawingsImage=True,
        observation='Same visible product layout, three battlefield artwork/title/city panels and Yasuo legend; smaller image does not resolve tiny printing identifiers.',
        exactPrintingIdentifiers=None,completePrintedRulesIndependentlyCertified=False),
    worldsCandidates=[dict(title=n,baseGalleryCandidateIds=[x['id'] for x in candidates[n]],
        galleryPublicCodes=[x['publicCode'] for x in candidates[n]],
        printedCity={'Black Market':'BROOKLYN','Cosmic Vista':'LOS ANGELES',"Hunters' Circle":'ALLEN'}.get(n),
        exactProductPrintingMappingConfirmed=False) for n in names],
    previousObservationCorrection=dict(commit='14c6fca7',incorrectTitle='Victory Circle',correctedTitle="Hunters' Circle",
        reason='Assistant visual transcription error, corrected by rereading original2560x1440 image.',
        correctedReport=pin('docs/evidence/drawings-parallel-source-2026-10-23/report.json',WT),
        originalSourcesAnd17GateIdsUnchanged=True),
    runeCandidates=[dict(name=n,candidateIds=[x['id'] for x in candidates[n]],
        productPrintingMapping='UNKNOWN',foilTreatmentMapping='UNKNOWN',exactLanguageMapping='UNKNOWN') for n in rune_names],
    runeCandidateLimit='30 pre-existing same-name gallery records are candidates only; no assumption that any is a Gift foil printing, and no inference that product copies are new identities.',
    priorChineseAnniversaryCandidate=dict(url=news['url'],newsId=news['id'],listingDeclaredDate='2026-08-09',
        priorReadbackIndex=pin(news_index_path),priorImageIndex=pin(image_index_path),
        refreshedToday=False,priorArticleRecord=news,actualImageObservations=observed,
        result='All five prior article images scoped visually read; event anniversary material does not establish Gift product, Chinese Player printing, or six foil-rune identities.',
        fullCardSemanticsAndEventRuleReview=False),
    gateDispositions=[dict(id=gid,state='OPEN') for gid in sorted(gate_ids)],
    newCatalogEntries=0,original1740CardsAnd14293RulesUnchanged=True,englishEightSourceGapRemainsOpen=True,
    runtimeAdoption=False,semanticCoverageCertified=False,
    validation=dict(rawHttpAndImageHashesVerified=True,literalBodyExactCharacterSliceVerified=True,
        selectedCatalogRecordsAllFieldsPreserved=True,localReusedImageHashesVerified=5,
        oldFailedParserCapturesRetained=True,gameTestsRun=False,sqlRun=False,nativeRun=False))
write(OUT/'report.json',report)

files=sorted(p for p in Q.iterdir() if p.is_file() and p.name != 'package-evidence.py')
files.append(Path(__file__).resolve())
members=[]
with tarfile.open(OUT/'original-captures.tar.xz','w:xz',preset=6) as archive:
    for p in files:
        raw=p.read_bytes();info=tarfile.TarInfo(p.name);info.size=len(raw);info.mtime=0;info.mode=0o644
        archive.addfile(info,io.BytesIO(raw));members.append(dict(path=p.name,bytes=len(raw),sha256=sha(raw)))
with tarfile.open(OUT/'original-captures.tar.xz','r:xz') as archive:
    assert archive.getnames()==[m['path'] for m in members]
    for m in members:
        raw=archive.extractfile(m['path']).read();assert len(raw)==m['bytes'] and sha(raw)==m['sha256']
write(OUT/'archive-index.json',dict(schemaVersion=1,members=members,verifiedMembers=len(members)))
manifest=dict(schemaVersion=1,id='drawings-worlds-runes-parallel-20261023',reviewDate='2026-10-23',
    originalGateCount=17,closedGates=0,exactNewPrintingIdentities=0,semanticCoverageCertified=False,runtimeAdoption=False,
    artifacts=[dict(path=p.name,sha256=sha(p.read_bytes()),bytes=p.stat().st_size) for p in sorted(OUT.iterdir()) if p.name!='source-manifest.json'],
    reusedLocalOnlyImages=observed)
write(OUT/'source-manifest.json',manifest)
print('verified archive members',len(members),'archive bytes',(OUT/'original-captures.tar.xz').stat().st_size)
