from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen
import gzip
import hashlib
import json
import re

Q = Path(__file__).resolve().parent

class Article(HTMLParser):
    def __init__(self):
        super().__init__(); self.text = []; self.images = []; self.links = []
    def handle_data(self, data):
        if data.strip(): self.text.append(data.strip())
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'img': self.images.append(attrs)
        if tag == 'a' and 'href' in attrs: self.links.append(attrs['href'])

class BodyRoot(HTMLParser):
    def __init__(self, raw):
        super().__init__(); self.raw = raw; self.depth = 0; self.ranges = []; self.begin = None
        self.offsets = [0]
        for line in raw.splitlines(keepends=True): self.offsets.append(self.offsets[-1] + len(line))
    def offset(self):
        line, col = self.getpos(); return self.offsets[line-1] + col
    def handle_starttag(self, tag, attrs):
        if tag != 'div': return
        if self.depth:
            self.depth += 1
        elif 'before:content_open-quote' in dict(attrs).get('class', ''):
            self.depth = 1; self.begin = self.offset() + len(self.get_starttag_text())
    def handle_endtag(self, tag):
        if tag == 'div' and self.depth:
            self.depth -= 1
            if self.depth == 0: self.ranges.append((self.begin, self.offset()))

def acquire(label, url, suffix):
    record = {'label': label, 'url': url, 'startedAtUtc': datetime.now(timezone.utc).isoformat()}
    try:
        response = urlopen(Request(url, headers={'User-Agent': 'Mozilla/5.0 Riftbound source audit'}), timeout=30)
    except HTTPError as error:
        response = error
    with response:
        raw = response.read()
        record.update(httpStatus=response.status, resolvedUrl=response.url,
                      responseHeaders=dict(response.headers), acquiredAtUtc=datetime.now(timezone.utc).isoformat())
    name = label + '.' + suffix
    assert not (Q/name).exists(), name
    (Q/name).write_bytes(raw)
    record.update(rawFile=name, rawBytes=len(raw), rawSha256=hashlib.sha256(raw).hexdigest())
    (Q/(label+'.receipt.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    if suffix == 'html':
        source = raw.decode(); root = BodyRoot(source); root.feed(source)
        assert len(root.ranges) == 1, root.ranges
        bodies = [source[begin:end] for begin,end in root.ranges]
        article = Article()
        for body in bodies: article.feed(body)
        record.update(bodyHtml=bodies, bodyCharacterRanges=root.ranges, bodySha256=[hashlib.sha256(b.encode()).hexdigest() for b in bodies],
                      displayedDate=re.findall(r'<time dateTime="([^"]+)">([^<]+)</time>',source),
                      text='\n'.join(article.text), images=article.images, links=article.links)
    (Q/(label+'.receipt.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    print(label, record['httpStatus'], record['rawBytes'])

acquire('worlds-esports-en', 'https://lolesports.com/en-US/news/introducing-the-worlds-2026-merch-collection', 'html')
acquire('worlds-esports-product', 'https://cmsassets.rgpub.io/sanity/images/dsfx7636/news_live/33854d00271d487306fc7021e85bae1de74e3055-1920x1080.jpg', 'jpg')
