from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,tarfile,io,subprocess,xml.etree.ElementTree as E
R=Path.cwd();Q=R/'var/qa/battle-win-late-participant-20261023';D=R/'docs/evidence/battle-win-late-participant-parallel-2026-10-23';D.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def trx(path):
 r=E.parse(path);defs={d.get('id'):d.find('t:TestMethod',ns).attrib for d in r.findall('.//t:UnitTest',ns)}
 return {'sha256':sha(path.read_bytes()),'counters':r.find('.//t:Counters',ns).attrib,'cases':[{'name':x.get('testName'),'method':defs[x.get('testId')]['className']+'.'+defs[x.get('testId')]['name'],'outcome':x.get('outcome'),'failure':x.find('.//t:Message',ns).text if x.find('.//t:Message',ns)is not None else None}for x in r.findall('.//t:UnitTestResult',ns)]}
runs={k:trx(Q/k/'focus/results.trx')for k in ['focus-v1','focus-v2','focus-v3','adjacent-and-original-game-v1']}
for k,total,passed,failed in [('focus-v1',4,2,2),('focus-v2',5,2,3),('focus-v3',5,2,3),('adjacent-and-original-game-v1',35,35,0)]:
 c=runs[k]['counters'];assert c['total']==str(total)and c['passed']==str(passed)and c['failed']==str(failed)and c['notExecuted']=='0'
receiptPath=R/'var/qa/battle-win-combined-20261023/applied-peer-fixed-n52-first45-v1.json';receipt=json.load(receiptPath.open());peer=Path(receipt['overlaySource']);assert sha(peer.read_bytes())==receipt['overlaySha256']
for f in receipt['files']:assert sha((R/f['path']).read_bytes())==f['afterSha256']
proof=[];ruleInputs=[]
for p in sorted((Q/'original-v3').glob('*.json.gz')):
 a=json.loads(gzip.decompress(p.read_bytes()));assert a['originalPrefixReplayCount']==len(a['commands'])==len(a['entries'])==len(a['states']);assert a['initial']['seed']==424242
 events=[e for entry in a['entries']for e in entry['events']];assert events==[e['event']for e in a['events']]
 if a['lateDefender']:
  assert len(a['commands'])==9 and sum(c['accepted']for c in a['commands'])==8
  assert a['commands'][-1]['commandType']=='DECLARE_BATTLE' and not a['commands'][-1]['accepted']
  assert a['states'][-1]==a['states'][-2]
  assert a['probes'][0]['entryDefending']is True
  s=a['states'][-1];assert s['cardObjects']['RENGAR']['isDefending']is True and s['timingState']=='NEUTRAL_OPEN'and not s['pendingTaskQueue']['hasTasks']and'BATTLEFIELD_BATTLE_SKIPPED:FIELD'in s['untilEndOfTurnEffects']
 elif a['lateAttacker']:
  assert len(a['commands'])==5 and sum(c['accepted']for c in a['commands'])==4 and len(events)==15
  assert a['commands'][-1]['commandType']=='PLAY_CARD'and not a['commands'][-1]['accepted']and a['states'][-1]==a['states'][-2]
 else:assert a['failure']is None and len(a['commands'])==6
 for c in a['commands']:
  if c['ruleInputs']not in ruleInputs:ruleInputs.append(c['ruleInputs'])
 proof.append({'caseId':a['caseId'],'lateDefender':a['lateDefender'],'lateAttacker':a['lateAttacker'],'commands':len(a['commands']),'accepted':sum(c['accepted']for c in a['commands']),'events':len(events),'originalPrefixReplays':a['originalPrefixReplayCount'],'sha256':sha(p.read_bytes()),'failure':a['failure']})
assert len(proof)==5 and sum(x['commands']for x in proof)==35 and sum(x['events']for x in proof)==117 and len(ruleInputs)==1
n52=[x for x in proof if not x['lateAttacker']];assert sum(x['commands']for x in n52)==30 and sum(x['events']for x in n52)==102
plans={k:json.load((Q/k/'plan.json').open())for k in runs};assert plans['focus-v1']['testAssemblySha256']==plans['adjacent-and-original-game-v1']['testAssemblySha256']
assembly=R/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0/Riftbound.ConformanceTests.dll';assert plans['focus-v3']['testAssemblySha256']==sha(assembly.read_bytes())
for p in Q.rglob('current-*-original-v1.json.gz'):
 a=json.loads(gzip.decompress(p.read_bytes()));assert sha(a['originalUtf8'].encode())==a['rawSha256']
source='tests/Riftbound.ConformanceTests/BattleWinLateParticipantTests.cs';deferred='tests/Riftbound.ConformanceTests/RengarAttackingBattlefieldPermissionTests.cs'
assert (Q/'focus-v3/test-source.cs').read_bytes()==(R/source).read_bytes()and(Q/'focus-v3/separate-rengar-test-source.cs').read_bytes()==(R/deferred).read_bytes()
extra=[source,'docs/BATTLE_WIN_LATE_PARTICIPANT_PARALLEL_2026-10-23.md','var/qa/draven-battle-win-score-20261023/current-core304-http-original-v1.json']
paths=[(str(p.relative_to(R)),p)for p in Q.rglob('*')if p.is_file()]+[(x,R/x)for x in extra]+[('deferred/RengarAttackingBattlefieldPermissionTests.cs',R/deferred),('inputs/peer-fixed-n52-first45-v1.tar.gz',peer),('inputs/applied-peer-fixed-n52-first45-v1.json',receiptPath)]
archive=D/'original-tests-fixed-inputs-and-sources-v1.tar.gz';members=[]
with archive.open('xb')as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as tar:
   for name,p in sorted(paths):
    data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data));members.append({'path':name,'bytes':len(data),'sha256':sha(data)})
with tarfile.open(archive,'r:gz')as tar:
 for m in members:
  data=tar.extractfile(m['path']).read();assert len(data)==m['bytes']and sha(data)==m['sha256']
manifest={'status':'SOURCE_RED_N52_LATE_DEFENDER_REMAINS_ROLE_AND_BLOCKS_NEXT_BATTLE','atUtc':datetime.now(timezone.utc).isoformat(),'baseCommit':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'region':'CN','language':'zh-CN','coreEffectiveDate':'2026-10-16','peerOverlay':receipt,'all19SharedInputsUnchanged':True,'actualRuleInputs':ruleInputs[0],'testAssemblySha256ByRun':{k:v['testAssemblySha256']for k,v in plans.items()},'source':{'path':source,'sha256':sha((R/source).read_bytes())},'deferredIndependentPermissionTest':{'path':deferred,'sha256':sha((R/deferred).read_bytes()),'includedInN52Commit':False,'status':'PLAY_CARD permission rejected before attacking-role cleanup; do not claim that later assertion executed'},'originalRuns':runs,'finalOriginalHistories':proof,'deliveredN52Cases':4,'deliveredN52Methods':1,'deliveredN52Passed':2,'deliveredN52SourceFailures':2,'deliveredN52OriginalCommands':30,'deliveredN52Accepted':28,'deliveredN52Rejected':2,'deliveredN52OriginalPrefixReplays':30,'deliveredN52OriginalEvents':102,'adjacentOriginalPassed':34,'originalFullGamePassed':1,'seed':424242,'freshCompleteSourceRows':json.load((Q/'sources-v1/extra-rows.json').open()),'onlyNewN52TestAndScopedEvidenceToCommit':True,'noExtraCheckOrFull':True,'noDatabaseExecution':True,'allEarlierSourcesTestsSeedsAndFailuresPreserved':True,'backendGoalComplete':False,'sharedIntegrationOwner':'01a16770-8c1b-7da2-872b-a8ec5ae77413','parallelThread':'01a16771-220b-7e83-91c6-44acf6dfe4b0','archive':{'path':str(archive.relative_to(R)),'sha256':sha(archive.read_bytes()),'members':members}}
with(D/'source-and-red-test-manifest.json').open('x')as f:json.dump(manifest,f,ensure_ascii=False,indent=2)
print(manifest['status'],len(members),'members',archive.stat().st_size,'bytes;N52 2pass2fail30prefixes;separate1permissionfail;35 adjacentpass')
