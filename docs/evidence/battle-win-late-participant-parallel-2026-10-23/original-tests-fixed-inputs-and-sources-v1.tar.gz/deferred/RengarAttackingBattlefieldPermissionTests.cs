using Xunit;

namespace Riftbound.ConformanceTests;

public sealed class RengarAttackingBattlefieldPermissionTests
{
    [Fact]
    public Task ReactionAttackerAfterTheResultLosesItsRoleWhenNoFurtherBattleIsDue()
        => BattleWinLateParticipantTests.Run("UNL-114/219", lateDefender: false, lateAttacker: true);
}
