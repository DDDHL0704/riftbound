from pathlib import Path
import ast,datetime,json
root=Path('/Users/dinghaolin/MyProjects/riftbound');old=root/'var/qa/fixed5edb1-early-native-20261023';new=root/'var/qa/fixeda68bf-early-native-20261023'
source=(old/'verify-completed-fixed5edb1-full-originals-v1.py').read_text()
replacements=[
("fixed='5edb12e57576358f3ef4a9f9d6da92c313f12437';run_id=39810044243","fixed='a68bfcf9684c328e999d2a57ec8c6e360528c8a9';run_id=39844928152",1),
("summary['total']==13706","summary['total']==13782",1),("plan['discoveredMethods']==7718","plan['discoveredMethods']==7741",1),("sum(cases.values())==13706","sum(cases.values())==13782",1),
("var/qa/fixed008a0-early-native-20261022/ci008a0-entire-full-independent-verification-v1.json","var/qa/fixed5edb1-early-native-20261023/ci5edb1-entire-full-independent-verification-v1.json",1),
("sum(before[0].values())==13649 and len(before[1])==7701 and before[4]=={'Passed':13649}","sum(before[0].values())==13706 and len(before[1])==7718 and before[4]=={'Passed':13706}",1),
("docs/evidence/wild-claw-reflexive-current-cn16-2026-10-22/exact57-behavior-branch-preparation.json","docs/evidence/lightning-rush-flow-current-cn16-2026-10-23/exact76-branch-preparation.json",2),
("sum(added.values())==57 and added_methods==set(prep['newMethods']) and len(added_methods)==17","sum(added.values())==76 and added_methods==set(prep['newMethods']) and len(added_methods)==23",1),
("len(old_manifest['cases'])==60 and len(load(manifest)['cases'])==61 and load(manifest)['cases'][:60]==old_manifest['cases']","len(old_manifest['cases'])==61 and len(load(manifest)['cases'])==62 and load(manifest)['cases'][:61]==old_manifest['cases']",1),
("load(manifest)['cases'][60:]==[{'id':'wild-claw-reflexive','sourceType':'WildClawReflexiveSqlAcceptance'}]","load(manifest)['cases'][61:]==[{'id':'lightning-rush-flow','sourceType':'LightningRushFlowSqlAcceptance'}]",1),
("sql['caseCount']==61","sql['caseCount']==62",1),
("governance['currentReviewCount']==167 and len(governance['remainingObligations'])==17291","governance['currentReviewCount']==168 and len(governance['remainingObligations'])==17384",1),
("'actualCases':13706,'actualMethods':7718","'actualCases':13782,'actualMethods':7741",1),
("'original13649Cases7701MethodsExactRetainedPlus57Cases17Methods'","'original13706Cases7718MethodsExactRetainedPlus76Cases23Methods'",1),
("'exact57PreparationSha256'","'exact76PreparationSha256'",1),("'allOriginal60SqlCaseObjectsAndOrderExact'","'allOriginal61SqlCaseObjectsAndOrderExact'",1),
("'soleN46CheckOriginal13556PassOneCatalogPinFailureNotRelabelled':True,'independentLaterFixedFullActuallyIncludesTheCatalogPinCorrection':True","'soleN47CheckActually13633Cases7600MethodsPassed':True,'newExact76FlowAndPrivateChoiceCasesActuallyPresent':True",1),
("'status':'FIXED5EDB1_ALL11_SUCCESS13706_CASES7718_METHODS_INDEPENDENT61_SQL_ALL_ORIGINAL57_WILD_CASES_AND_NETWORK_VERIFIED'","'status':'FIXEDA68BF_ALL11_SUCCESS13782_CASES7741_METHODS_INDEPENDENT62_SQL_ALL_ORIGINAL76_FLOW_CASES_AND_NETWORK_VERIFIED'",1),
("print('PASS fixed5edb1 actual13706/7718; all original13649/7701 plus exact57/17;143full151cases110pairs11decks424242;61SQL;original15network0leaks;all11success. Visible/Windows and full audit remain OPEN.',flush=True)","print('PASS fixeda68bf actual13782/7741; all original13706/7718 plus exact76/23;143full151cases110pairs11decks424242;62SQL;original15network0leaks;all11success. OS hardware/Windows and full audit remain OPEN.',flush=True)",1)]
for a,b,count in replacements:
 assert source.count(a)==count,(a,source.count(a),count);source=source.replace(a,b)
source=source.replace("w/'ci5edb1-","w/'cia68bf-").replace("w/'exact-fixed5edb1-","w/'exact-fixeda68bf-").replace("'exact_fixed5edb1_sql_gate'","'exact_fixeda68bf_sql_gate'")
p=new/'verify-completed-fixeda68bf-full-originals-v1.py';assert not p.exists();ast.parse(source);p.write_text(source)
assert 'fixed5edb1-early-native-20261023/ci5edb1-entire-full-independent-verification-v1.json'in source
record=Path(__file__).parent/'independent-ci-verifier-preparation-original-assertion-disposition-v1.json';assert not record.exists();record.write_text(json.dumps(dict(atUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),firstPreparationFailedBeforeVerifierExecution=True,cause='Two legitimate occurrences of the exact preparation path include the final receipt hash, but preparation expected one.',correctedPreparationOccurrenceCount=2,expectedTestOrSqlOracleNotWeakened=True,gameplayAndCurrentCheckInputsUnchanged=True,notProductFailure=True),indent=2))
print('PREPARED_ONLY_A68BF_VERIFIER_SYNTAX_VALID_EXPECT13782_CASES7741_METHODS62SQL')
