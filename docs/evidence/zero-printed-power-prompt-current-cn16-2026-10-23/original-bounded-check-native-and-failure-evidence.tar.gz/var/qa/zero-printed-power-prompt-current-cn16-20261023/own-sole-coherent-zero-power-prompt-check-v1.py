from pathlib import Path
import collections,datetime,gzip,hashlib,json,os,resource,subprocess,xml.etree.ElementTree as E
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
base='a68bfcf9684c328e999d2a57ec8c6e360528c8a9'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==base
positive=load(w/'corrected-payment-and-flow-focus-v1/summary.json');games=load(w/'original-six-complete-games-focus-v1/summary.json');game_owner=load(w/'original-six-complete-games-focus-owner-terminal-v1.json')
assert positive['status']=='PASSED'and positive['total']==131 and games['status']=='PASSED'and games['total']==6 and game_owner['exitCode']==0 and game_owner['declaredSourceInputsStable']
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def rows(path):
 document=E.parse(path);definitions={d.get('id'):d.find('t:TestMethod',ns).attrib for d in document.findall('.//t:UnitTest',ns)}
 return [dict(name=r.get('testName'),method=definitions[r.get('testId')]['className']+'.'+definitions[r.get('testId')]['name'],outcome=r.get('outcome'))for r in document.findall('.//t:UnitTestResult',ns)]
baseline=rows(root/'var/qa/deck-look-draw-graveyard-current-cn16-20261022/sole-check-v1/check/results.trx')
assert len(baseline)==13633 and len({r['method']for r in baseline})==7600 and all(r['outcome']=='Passed'for r in baseline)
new=[r for r in rows(w/'corrected-payment-and-flow-focus-v1/focus/results.trx')if '.ZeroPrintedPowerPromptTests.'in r['method']]
assert len(new)==5 and len({r['method']for r in new})==2 and all(r['outcome']=='Passed'for r in new)
native=load(root/'var/qa/deck-look-draw-graveyard-current-cn16-20261022/native-actual-sql62-controls-v2/actual-native-control-terminal-v2.json')
pins={p:dict(sha256=sha(root/p),mode=oct((root/p).stat().st_mode&0o777))for p in native['sourceHashes']}
changed=[p for p,h in native['sourceHashes'].items()if pins[p]['sha256']!=h]
assert changed==['src/Riftbound.Engine/MatchSession.cs']or set(changed)=={'src/Riftbound.Engine/MatchSession.cs'}
new_path='tests/Riftbound.ConformanceTests/ZeroPrintedPowerPromptTests.cs'
assert new_path not in pins;pins[new_path]=dict(sha256=sha(root/new_path),mode=oct((root/new_path).stat().st_mode&0o777));assert len(pins)==3374
original=json.loads(gzip.decompress((w/'all-original-conformance-files-before-zero-prompt-v1.json.gz').read_bytes()))
assert len(original)==1819 and all(sha(root/p)==h for p,h in original.items())
old_start=json.loads(gzip.decompress((root/'var/qa/deck-look-draw-graveyard-current-cn16-20261022/sole-check-start-inputs-v1.json.gz').read_bytes()))
full_sources=old_start['allNineFullGameSourceHashes'];assert len(full_sources)==9 and all(sha(root/p)==h for p,h in full_sources.items())
runtime={}
for label,folder in [('Conformance',root/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0'),('Native',root/'clients/godot/.godot/mono/temp/bin/Debug')]:
 runtime[label]={str(p.relative_to(root)):sha(p)for p in folder.rglob('*')if p.is_file()and '/net10.0/var/qa/'not in str(p)}
measurement=load(w/'actual-current-debug-loaded-four-assemblies-v1.json')
assert Path(measurement['baseDirectory'])==root/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0'
for a in measurement['assemblies']:assert sha(Path(a['path']))==a['sha256']and a['mvid']
start=dict(atUtc=now(),baseCommit=base,all3374SourceHashesAndModes=pins,all1819OriginalConformanceFiles=original,onlyOneOriginalGameplaySourceChanged=changed,allOriginalConformanceFilesByteExact=True,allNineFullGameSourceHashes=full_sources,all143OriginalCompleteMethods151Cases110Pairs11DecksSeed424242AndVictoryReplayAssertionsRetained=True,actualFourLoadedAssemblies=measurement,actualRuntimeInputs=runtime,baselineCaseNames=sorted(r['name']for r in baseline),newCaseNames=sorted(r['name']for r in new),expectedCheckCases=13638,expectedCheckMethods=7602,expectedDiscoveryMethods=7743,expectedNextFixedFullCases=13787,newCases=5,newMethods=2,noDatabaseConnectionForThisCheck=True,wholeCardOrGoalCertified=False)
manifest=w/'sole-check-start-inputs-v1.json.gz';assert not manifest.exists();manifest.write_bytes(gzip.compress(json.dumps(start,indent=2).encode(),mtime=0))
out=w/'sole-check-v1';assert not out.exists();args=['python3','scripts/test-rules.py','check','--output',str(out)];env=dict(os.environ);env.pop('ConnectionStrings__Riftbound',None)
proof=dict(status='RUNNING_SOLE_COHERENT_ZERO_PRINTED_POWER_PROMPT_CHECK',startedAtUtc=now(),baseCommit=base,actualCommand=args,sourceInputs=len(pins),runtimeInputCounts={k:len(v)for k,v in runtime.items()},startManifestSha256=sha(manifest))
print('SOLE_CHECK_STARTED_EXPECT13638_CASES7602_METHODS_3374_SOURCES',flush=True)
try:
 with(w/'sole-check-original-console-v1.log').open('xb')as log:
  process=subprocess.Popen(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  with(w/'sole-check-running-owner-v1.json').open('x')as output:json.dump(dict(proof,ownerPid=os.getpid(),runnerPid=process.pid),output,indent=2)
  power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(process.pid)])
  proof['exitCode']=process.wait();power.wait(timeout=10)
 if proof['exitCode']==0:
  summary=load(out/'summary.json');plan=load(out/'plan.json');actual=rows(out/'check/results.trx')
  assert summary['status']=='PASSED'and summary['total']==13638 and len(actual)==13638
  assert collections.Counter(r['name']for r in actual)==collections.Counter(r['name']for r in baseline)+collections.Counter(r['name']for r in new)
  assert all(r['outcome']=='Passed'for r in actual)and plan['discoveredMethods']==7743 and len(plan['shards'][0]['methods'])==7602
  proof.update(status='PASS_SOLE_COHERENT_ZERO_PRINTED_POWER_PROMPT_CHECK13638_CASES7602_METHODS',summary=summary,allOriginal13633CheckCases7600MethodsRetainedPlus5Cases2MethodsOnly=True,trxSha256=sha(out/'check/results.trx'))
 else:proof['status']='FAILED_SOLE_COHERENT_ZERO_PRINTED_POWER_PROMPT_CHECK_ORIGINALS_RETAINED'
finally:
 proof.update(finishedAtUtc=now(),all3374SourceHashesAndModesStable=all(sha(root/p)==v['sha256']and oct((root/p).stat().st_mode&0o777)==v['mode']for p,v in pins.items()),allCapturedConformanceAndNativeRuntimeInputsStable=all(sha(root/p)==h for group in runtime.values()for p,h in group.items()))
 with(w/'sole-check-owner-terminal-v1.json').open('x')as output:json.dump(proof,output,indent=2)
print(proof['status'],flush=True)
assert proof['exitCode']==0 and proof['all3374SourceHashesAndModesStable']and proof['allCapturedConformanceAndNativeRuntimeInputsStable']
