from pathlib import Path
import datetime,hashlib,json,os,subprocess
root=Path('/Users/dinghaolin/MyProjects/riftbound');z=Path(__file__).resolve().parent;old=root/'var/qa/fixeda68bf-early-native-20261023';load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();files=lambda p:{str(f.relative_to(p)):sha(f)for f in p.rglob('*')if f.is_file()};now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
fixed=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert subprocess.check_output(['git','rev-parse','HEAD^'],cwd=root,text=True).strip()=='a68bfcf9684c328e999d2a57ec8c6e360528c8a9'
subprocess.run(['git','diff','--quiet','HEAD','--'],cwd=root,check=True);assert 'Amount: > 0, Traits.Count: >= 2'in(root/'src/Riftbound.Engine/MatchSession.cs').read_text();assert load(z/'sole-check-owner-terminal-v1.json')['status']=='PASS_SOLE_COHERENT_ZERO_PRINTED_POWER_PROMPT_CHECK13638_CASES7602_METHODS'
w=root/'var/qa'/('fixed'+fixed[:8]+'-early-native-20261023');assert not w.exists();w.mkdir();original=load(old/'fixeda68bf-api-gameplay-closure-frozen-inputs-v1.json');source={p:sha(root/p)for p in original['allDeclaredApiGameplaySourceInputsExactFixedCommit']};assert len(source)==257
for p,digest in source.items():assert hashlib.sha256(subprocess.check_output(['git','show',fixed+':'+p],cwd=root)).hexdigest()==digest
runtime=w/'current-fixed-api-runtime-v1';command=[c.replace(original['fixedCommit'],fixed).replace(original['runtimeRoot'],str(runtime))for c in original['actualCommand']]
with(w/'publish-current-fixed-api-v1.log').open('xb')as log:subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
api_files=files(runtime);assert len(api_files)==46 and all(sha(root/p)==h for p,h in source.items())
prior=load(old/'fixeda68bf-native-helper-and-network-frozen-v1.json');oldhelpers=Path(prior['helperRuntimeRoot']);assert files(oldhelpers)==prior['helperRuntimeFiles'];own={p:h for p,h in prior['helperRuntimeFiles'].items()if p not in prior['runtimeFiles']};assert len(own)==41
helpers=w/'current-fixed-helpers-runtime-v1';subprocess.run(['/bin/cp','-cR',str(runtime),str(helpers)],check=True)
for name,digest in own.items():
 p=helpers/name;assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);subprocess.run(['/bin/cp','-c',str(oldhelpers/name),str(p)],check=True);assert sha(p)==digest
helper_files=files(helpers);assert len(helper_files)==87
probe=root/'var/qa/fixed267ab-early-native-20261022/executed-own-native-readers-and-drivers-v1/IndependentFixed267abControlledLabV1.dll';measurements=[]
for label,directory,expected in [('api',runtime,api_files),('helpers',helpers,helper_files)]:
 command_probe=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(directory/'Riftbound.Api.deps.json'),'--runtimeconfig',str(directory/'Riftbound.Api.runtimeconfig.json'),str(probe),'--loaded-inputs'];actual=json.loads(subprocess.check_output(command_probe,cwd=directory,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0')));assert Path(actual['baseDirectory'])==directory and len(actual['assemblies'])==4
 for a in actual['assemblies']:assert Path(a['path'])==directory/(a['name']+'.dll')and a['sha256']==expected[a['name']+'.dll']and a['mvid']
 measurements.append(dict(runtime=label,actualCommand=command_probe,actual=actual));assert files(directory)==expected
identity=measurements[0]['actual']['actualRuleInputs'];assert measurements[1]['actual']['actualRuleInputs']==identity and identity['authoritySha256']==prior['actualRuleInputs']['authoritySha256']and identity['catalogSha256']==prior['actualRuleInputs']['catalogSha256']and identity['identitySha256']!=prior['actualRuleInputs']['identitySha256']
network=w/'current-fixed-native-network-net8-runtime-v1';network_source={p:sha(root/p)for p in prior['networkSourceHashes']}
for p,h in network_source.items():assert hashlib.sha256(subprocess.check_output(['git','show',fixed+':'+p],cwd=root)).hexdigest()==h
network_command=['/Users/dinghaolin/.dotnet/dotnet','publish','tests/Riftbound.NativeNetworkSmoke/Riftbound.NativeNetworkSmoke.csproj','--configuration','Release','--no-restore','--nologo','-p:SourceRevisionId='+fixed,'--output',str(network)]
with(w/'publish-current-fixed-net8-network-v1.log').open('xb')as log:subprocess.run(network_command,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
network_files=files(network);assert len(network_files)==22 and files(runtime)==api_files and files(helpers)==helper_files and all(sha(root/p)==h for p,h in source.items())
proof=dict(atUtc=now(),status='CURRENT_FIXED_API46_HELPERS87_NET8NETWORK22_FROZEN_ACTUAL_FOUR_LOADED_PATHS_SHA_MVID_MEASURED_NATIVE_PRODUCTS_NOT_YET_PASSED',fixedCommit=fixed,baseCommit=fixed,parentCommit=original['fixedCommit'],apiRuntimeRoot=str(runtime),runtimeFiles=api_files,helperRuntimeRoot=str(helpers),helperRuntimeFiles=helper_files,networkRuntimeRoot=str(network),networkRuntimeFiles=network_files,networkSourceHashes=network_source,actualRuleInputs=identity,allDeclaredApiGameplaySourceInputsExactFixedCommit=source,apiCommand=command,networkCommand=network_command,actualLoaderRecords=measurements,probeUsedOnlyLoadedInputsFlagNoPreviousVerdict=True,probeSha256=sha(probe),all41OriginalHelperOnlyPayloadsByteExact=True,notCiExportedApiBinary=True,noAppInstallerSdkDatabaseOrWorktreeCreated=True,wholePrintingOrGoalCertified=False)
with(w/'current-fixed-native-helper-and-network-frozen-v1.json').open('x')as f:json.dump(proof,f,indent=2);f.write('\n')
with(z/'new-fixed-native-workspace-pointer-v1.json').open('x')as f:json.dump(dict(fixedCommit=fixed,path=str(w),sourceManifest=str(w/'current-fixed-native-helper-and-network-frozen-v1.json')),f,indent=2)
print('FROZEN_CURRENT_FIXED_ZERO_PROMPT_API46_HELPERS87_NETWORK22',fixed,identity['identitySha256'],flush=True)
