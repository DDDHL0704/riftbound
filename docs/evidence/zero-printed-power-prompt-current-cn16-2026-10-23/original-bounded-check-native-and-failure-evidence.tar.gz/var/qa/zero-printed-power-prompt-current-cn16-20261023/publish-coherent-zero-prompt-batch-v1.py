from pathlib import Path
import collections, copy, datetime, gzip, hashlib, io, json, subprocess, tarfile, xml.etree.ElementTree as E
root=Path('/Users/dinghaolin/MyProjects/riftbound');z=Path(__file__).resolve().parent;n=root/'var/qa/fixeda68bf-early-native-20261023'
base='a68bfcf9684c328e999d2a57ec8c6e360528c8a9';identity='zero-printed-power-prompt-current-cn16-2026-10-23'
ev=root/'docs/evidence'/identity;document='docs/ZERO_PRINTED_POWER_PROMPT_CURRENT_CN16_AUDIT_2026-10-23.md';mp=root/'docs/audit/current-manifest.json'
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def pin(p,role=None):
 d=dict(path=p.relative_to(root).as_posix(),sha256=sha(p))
 if role:d['role']=role
 return d
def write(p,d):
 with p.open('x')as f:json.dump(d,f,ensure_ascii=False,indent=2);f.write('\n')
def rows(p):return [r for r in E.parse(p).getroot().iter()if r.tag.endswith('UnitTestResult')]
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==base
check=load(z/'sole-check-owner-terminal-v1.json');assert check['status']=='PASS_SOLE_COHERENT_ZERO_PRINTED_POWER_PROMPT_CHECK13638_CASES7602_METHODS'
assert check['exitCode']==0 and check['all3374SourceHashesAndModesStable']and check['allCapturedConformanceAndNativeRuntimeInputsStable']
start=json.loads(gzip.decompress((z/'sole-check-start-inputs-v1.json.gz').read_bytes()))
assert all(sha(root/p)==v['sha256']and oct((root/p).stat().st_mode&0o777)==v['mode']for p,v in start['all3374SourceHashesAndModes'].items())
assert all(sha(root/p)==h for group in start['actualRuntimeInputs'].values()for p,h in group.items())
assert len(start['all1819OriginalConformanceFiles'])==1819 and start['allOriginalConformanceFilesByteExact']and len(start['allNineFullGameSourceHashes'])==9
prep=load(z/'five-exact-executed-branches-and-seventeen-existing-source-identities-v2.json');assert len(prep['cases'])==5 and len(prep['newMethods'])==2 and len(prep['sourceRuleRecords'])==17
focus=load(z/'corrected-payment-and-flow-focus-v1/summary.json');plan=load(z/'corrected-payment-and-flow-focus-v1/plan.json')
assert focus['status']=='PASSED'and focus['total']==131 and sum(len(s['methods'])for s in plan['shards'])==50
full=load(z/'original-six-complete-games-focus-owner-terminal-v1.json');assert full['exitCode']==0 and full['declaredSourceInputsStable']and len(full['exactSixOriginalMethods'])==6
assert load(z/'original-six-complete-games-focus-v1/summary.json')['total']==6
red=load(z/'original-red-zero-allocation-failure-and-executed-inputs-v1.json');assert red['status']=='ORIGINAL_RED_FIVE_CASES_TWO_EXPECTED_ZERO_ALLOCATION_FAILURES_THREE_PASS_RETAINED'
old_native=load(n/'bounded-current-fixed-native49-controls40-ci-pair-cold-normal-network-and-original-replay-v1.json')
assert old_native['fixedCommit']==base and old_native['allOriginalCommandEntries']==165 and old_native['acceptedOriginalCommandEntries']==164 and old_native['originalRejectedCommandEntriesRetained']==1
assert old_native['actualSourceBoundProductionNativeControls']==49 and old_native['actualCurrentCiDefaultMainPairedGpuColdStages']==40 and old_native['originalEvents']==751 and old_native['privateSnapshots']==old_native['privatePrompts']==312
assert old_native['allIndependentOriginalReadbacksAndCompleteReplaysPassed']and old_native['old422AuditAndCurrent111NativeAllSevenTablesReadOnlyGuardExact']
assert old_native['actualRuleInputs']['identitySha256']=='3b842ce10486d75ca9bf14f5844b5d787241ed050ccba05952abfed256c41dcd'
assert start['actualFourLoadedAssemblies']['actualRuleInputs']['identitySha256']=='e9958528d7551b4f6297b9167373c60c07ac413e2e12c5a8426e89e7b3a1a8b4'
m=load(mp);old=copy.deepcopy(m);rp=root/m['inputs']['reviews']['path'];reviews=load(rp);old_reviews=copy.deepcopy(reviews)
binding=load(z/'current83-context-input-change-plan-before-publication-v1.json');assert sha(mp)==binding['manifestSha256']and sha(rp)==binding['reviewsSha256']and len(binding['changes'])==38
assert (len(reviews['reviews']),len(m['reviewContexts']),len(m['acceptanceGates']),len(m['laterSourceDeltas']))==(168,83,269,7)
archived=json.loads(gzip.decompress((z/'all-original83-complete-contexts-before-zero-prompt-input-refresh-v1.json.gz').read_bytes()));assert archived==m['reviewContexts']
assert not ev.exists();ev.mkdir()
retention=dict(atUtc=now(),status='PASS_BOUNDED_ZERO_PROMPT_ALL_ORIGINAL_TEST_AND_SOURCE_RETENTION',baseCommit=base,newCases=5,newMethods=2,focusedCases=131,focusedMethods=50,affectedOriginalCompleteGames=full['exactSixOriginalMethods'],originalCompleteGameCases=6,soleCheckCases=13638,soleCheckMethods=7602,allPrior13633CheckCases7600MethodsRetainedPlusFiveCasesTwoMethodsOnly=True,all3374SourceHashesModesAndCapturedConformanceNativeRuntimeInputsStable=True,all1819OriginalConformanceFilesByteExact=True,allNineOriginalCompleteGameSourcesByteExact=start['allNineFullGameSourceHashes'],all143OriginalMethods151Cases110Pairs11DecksSeed424242VictoryAndReplayAssertionsRetained=True,originalRedFiveCasesTwoFailuresThreePassNotRelabeled=True,serverMalformedAllocationRefusalPreserved=True,actualDebugInputs=start['actualFourLoadedAssemblies']['actualRuleInputs'],expectedNextFixedFullCases=13787,expectedNextFixedFullMethods=7743,all62SqlCaseObjectsAndOrderUntouched=True,newFixedFullAndProducts='OPEN',wholePrintingOrGoalCertified=False)
write(z/'final-original-retention-v1.json',retention)
copies={
 'original-test-and-source-retention.json':z/'final-original-retention-v1.json',
 'sole-check-owner-terminal.json':z/'sole-check-owner-terminal-v1.json','sole-check-start-inputs.json.gz':z/'sole-check-start-inputs-v1.json.gz',
 'original-red-execution-and-runtime.json':z/'original-red-zero-allocation-failure-and-executed-inputs-v1.json',
 'five-exact-branches-and-existing-rule-identities.json':z/'five-exact-executed-branches-and-seventeen-existing-source-identities-v2.json',
 'current-targeted-source-readback.json':z/'current-targeted-source-readback-before-fix-v1.json',
 'rule-directory-volatile-envelope-disposition.json':z/'rule-directory-content-vs-volatile-envelope-disposition-v1.json',
 'all-original83-complete-contexts.json.gz':z/'all-original83-complete-contexts-before-zero-prompt-input-refresh-v1.json.gz',
 'preceding-fixed-a68bf-bounded-native49-ci-pair40-and-original-replay.json':n/'bounded-current-fixed-native49-controls40-ci-pair-cold-normal-network-and-original-replay-v1.json',
 'preceding-fixed-a68bf-14-images-visual-disposition.json':n/'flow-ci-main-v1/actual-twelve-ci-pair-viewports-and-two-production-composers-visual-disposition-v1.json',
 'preceding-fixed-a68bf-eight-selected-images-visual-disposition.json':n/'eight-additional-actually-read-current-native-viewports-and-composers-visual-disposition-v1.json',
 'preceding-fixed-a68bf-retired-only-old-pair-and-installers.json':n/'retire-only-preceding5edb-native-pair-and-two-installers-v1.json'}
partial_rule=load(n/'cia68bf-completed-rule-suite-independent-before-entire-ci-v1.json');assert partial_rule['actualCases']==13782 and partial_rule['actualMethods']==7741 and partial_rule['notEntireFullCiOrSqlPass']
copies.update({'preceding-fixed-a68bf-completed-rule-suite-independent.json':n/'cia68bf-completed-rule-suite-independent-before-entire-ci-v1.json','preceding-fixed-a68bf-original-rule-artifact-transport.json':n/'cia68bf-prefetched-completed-conformance-original-v1.json'})
ci=n/'cia68bf-entire-full-independent-verification-v1.json'
if ci.exists():
 c=load(ci);assert c['fixedCommit']==base and c['runId']==39844928152 and c['actualCases']==13782 and c['actualMethods']==7741 and c['sql']['caseCount']==62 and len(c['jobs'])==11 and set(c['jobs'].values())=={'success'}
 copies['preceding-fixed-a68bf-entire-full-independent.json']=ci
else:
 c=json.loads(subprocess.check_output(['gh','run','view','39844928152','--json','status,conclusion,headSha,jobs,url'],cwd=root));assert c['headSha']==base
 assert not any(j['conclusion']in {'failure','cancelled','timed_out','action_required'}for j in c['jobs'])
 snapshot=dict(atUtc=now(),status='ACTUAL_CURRENT_FIXED_A68BF_CI_OBSERVATION_NOT_COMPLETE_SUCCESS',fixedCommit=base,runId=39844928152,actualRunStatus=c['status'],actualRunConclusion=c['conclusion'],jobs={j['name']:dict(status=j['status'],conclusion=j['conclusion'])for j in c['jobs']},url=c['url'],doesNotCertifyFull=True)
 write(z/'preceding-fixed-a68bf-ci-observation-at-publication-v1.json',snapshot);copies['preceding-fixed-a68bf-ci-observation.json']=z/'preceding-fixed-a68bf-ci-observation-at-publication-v1.json'
face=load(z/'current-exact-cn156-face-conditional-readback-v1.json');assert face['originalBytesExactlyUnchanged']and face['previousAndCurrentSha256']=='916e66e07ff9a6badbb0b2bbd6a0fa1391a0d0f1aee905c433a51ee501fa4855'
copies.update({'current-exact-cn156-face-conditional-readback.json':z/'current-exact-cn156-face-conditional-readback-v1.json','current-exact-cn156-face-actual-visual-cost-disposition.json':z/'current-exact-cn156-face-actual-visual-cost-disposition-v1.json'})
enw=root/'var/qa/current-en-gallery-readback-20261023'
endisposition=load(enw/'current-english-whole-list-existing-version-disposition-v1.json');assert endisposition['all1408CurrentFullRowsFieldsValuesNullsPresenceExactLatestVersion']and endisposition['existingSevenDeltasPreservedNoEighthDelta']
copies.update({'current-english-whole-list-original-comparison.json':enw/'current-english-complete-whole-list-readback-v1.json','current-english-whole-list-existing-version-disposition.json':enw/'current-english-whole-list-existing-version-disposition-v1.json','current-english-whole-list-original-response.json.gz':enw/'original-current-english-whole-list-v1.json.gz','current-english-whole-list-readback.py':enw/'read-current-complete-english-whole-list-v1.py'})
nexts=root/'var/qa/deck-consumer-eleven-source-current-cn16-20261023';next_source=load(nexts/'current-eleven-exact-source-rows-v1.json');assert len(next_source['exactTargets'])==11 and next_source['allElevenCurrentFullRowsExactlyRegistered']
copies.update({'finite70-existing-consumer-obligation-crosswalk-before-n48.json':root/'var/qa/swain-predict-three-types-current-cn16-20261023/all70-existing-consumers-current-review-and-branch-reference-crosswalk-v1.json','current-eleven-runtime-consumer-source-preparation.json':nexts/'current-eleven-exact-source-rows-v1.json','current-eleven-consumer-eight-original-queries.jsonl.gz':nexts/'original-eight-filtered-queries-v1.jsonl.gz'})
for name,p in copies.items():(ev/name).write_bytes(p.read_bytes())
# One payload per hash; keep original failures and exact executed red bits. Runtime/app/installer copies stay local.
paths={p for folder in (z,n)for p in folder.rglob('*')if p.is_file()}
runtime_names={'fixeda68bf-native-helpers-runtime-v1','fixeda68bf-api-gameplay-closure-runtime-v1','fixeda68bf-native-network-net8-runtime-v1','native-current','prior-coherent-publication-inputs-v1'}
def generated(p):return any(x in runtime_names or x in {'obj','__pycache__','.godot'}or x.endswith('.app')for x in p.parts)
def private_name(p):return p.suffix=='.env'or p.name.startswith('session-')or any('profile'in x.lower()for x in p.parts)
secrets=set()
def collect(v):
 if isinstance(v,dict):
  for k,item in v.items():
   if k.lower().replace('_','')in {'playerkey','reconnecttoken','accesstoken','authorization','sessiontoken','connectiontoken'}and isinstance(item,str)and len(item)>=16:secrets.add(item.encode())
   else:collect(item)
 elif isinstance(v,list):
  for item in v:collect(item)
 elif isinstance(v,str)and v.lstrip().startswith(('{','[')):
  try:collect(json.loads(v))
  except(ValueError,RecursionError):pass
for p in paths:
 if generated(p):continue
 if p.name.endswith(('.json','.json.gz','.ndjson','.ndjson.gz','.jsonl.gz')):
  try:
   raw=p.read_bytes();raw=gzip.decompress(raw)if p.suffix=='.gz'else raw
   if '.ndjson'in p.name or '.jsonl'in p.name:
    for line in raw.decode().splitlines():
     if line.strip():collect(json.loads(line))
   else:collect(json.loads(raw))
  except(OSError,ValueError,UnicodeDecodeError):pass
for name in copies:
 raw=(ev/name).read_bytes();inspect=gzip.decompress(raw)if name.endswith('.gz')else raw
 assert not any(secret in inspect for secret in secrets),('Readable evidence unexpectedly contains authentication values',name)
canonical={sha(ev/name):dict(externalEvidencePath=pin(ev/name)['path'])for name in copies};mapping=[];members={};excluded=[]
for p in sorted(paths):
 name=p.relative_to(root).as_posix();reason=None
 if generated(p):reason='GENERATED_CURRENT_APP_INSTALLER_SDK_OR_RUNTIME_NOT_DUPLICATED'
 if private_name(p):reason='PRIVATE_QA_SESSION_LOCAL_ONLY'
 raw=p.read_bytes();inspect=raw
 if p.suffix=='.gz':
  try:inspect=gzip.decompress(raw)
  except(OSError,EOFError):pass
 if p.suffix in {'.zip','.pdf'}:reason='EXISTING_INSTALLER_OR_OFFICIAL_PDF_NOT_DUPLICATED'
 if any(s in inspect for s in secrets):reason='PRIVATE_AUTH_VALUES_LOCAL_ONLY'
 digest=hashlib.sha256(raw).hexdigest()
 if reason:excluded.append(dict(path=name,bytes=len(raw),sha256=digest,reason=reason));continue
 target=canonical.get(digest)
 if target is None:target=dict(archiveMember=name);canonical[digest]=target;members[name]=p
 mapping.append(dict(path=name,bytes=len(raw),sha256=digest,**target))
archive=ev/'original-bounded-check-native-and-failure-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9)as t:
 for name,p in sorted(members.items()):
  raw=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(raw);info.mode=p.stat().st_mode&0o777;info.mtime=0;t.addfile(info,io.BytesIO(raw))
assert archive.stat().st_size<70_000_000
with tarfile.open(archive,'r:gz')as t:
 assert set(t.getnames())==set(members)
 for r in mapping:
  raw=t.extractfile(r['archiveMember']).read()if 'archiveMember'in r else(root/r['externalEvidencePath']).read_bytes()
  assert len(raw)==r['bytes']and hashlib.sha256(raw).hexdigest()==r['sha256']
write(ev/'archive-map.json',dict(atUtc=now(),archive=pin(archive),originalPathsWithExactCanonicalPayload=mapping,localOnlyExclusions=excluded,allMemberBytesHashesClosedSetVerified=True,equalPayloadsStoredOnlyOnceIncludingReadableCopies=True,noNewAppInstallerSdkDatabaseOrWorktree=True,originalAuthValuesStayLocal=True))
source=load(z/'current-targeted-source-readback-before-fix-v1.json')
implementation=[pin(root/'src/Riftbound.Engine/MatchSession.cs','implementation')]
verification=[pin(root/'tests/Riftbound.ConformanceTests/ZeroPrintedPowerPromptTests.cs','verification-source')]
sm=dict(schemaVersion=1,id=identity,atUtc=now(),region='CN',language='zh-CN',applicableAsOf='2026-10-23',adoptedCoreEffectiveDate='2026-10-16',baseCommit=base,issue='https://github.com/DDDHL0704/riftbound/issues/95',scope='CN API37859 VEN-156: zero printed power exposes no empty trait-allocation option. Normal, Echo, Flow and Flow+Echo retain actual authoritative costs. Explicit malformed empty allocation remains rejected. Positive multi-trait printed costs and Flow generic power retain prior behavior.',exactPrintings=['VEN-156'],runtimeCardNo='VEN·156',printedFace='VEN·156/166 SC',individualPublicationDate=None,individualEffectiveDate=None,separateGlobalPrintingNotCertified='VEN-156/166',currentExactSourceRow=source['currentExactCn156'],currentCore=source['currentCore'],currentKnownDirectory=source['currentRuleDirectory'],sourceRuleRecords=prep['sourceRuleRecords'],implementation=implementation,verificationSources=verification,actualDebugRuleInputs=start['actualFourLoadedAssemblies']['actualRuleInputs'],onlyOneProductionLineChanged=True,all1037RuntimeRowsScannedOnlyCurrentZeroMultiTraitConsumer='VEN·156',runtimeCatalogAnd1740LedgerRowsUnchanged=True,sourceVersionDeltasUnchanged=7,soleCheckCases=13638,soleCheckMethods=7602,focusCases=131,focusMethods=50,originalSixFullGameMethods=full['exactSixOriginalMethods'],newCases=5,newMethods=2,expectedNextFixedFullCases=13787,expectedNextFixedFullMethods=7743,sqlManifestCases=62,expectedRemainingObligations=17390,priorFixedNativeRuleInputs=old_native['actualRuleInputs'],priorFixed49Controls40CiPairedColdStages165OriginalEntries751Events312PrivateSnapshotsAndPromptsSeparateFromNewInput=True,newFixedFullAndNativeProducts='OPEN',wholePrintingCertified=False,semanticCoverageCertified=False,archive=pin(archive),archiveMap=pin(ev/'archive-map.json'))
sm['separateFinite70ExistingConsumerObligationCrosswalk']=pin(ev/'finite70-existing-consumer-obligation-crosswalk-before-n48.json');sm['separateCurrentElevenConsumerSourcePreparation']=pin(ev/'current-eleven-runtime-consumer-source-preparation.json');sm['finite70CrosswalkWasObservedBeforeN48PublicationNotWholeCertificationOrProofNoTestsExist']=True
sm['currentExactCn156ImageSourceReadback']=pin(ev/'current-exact-cn156-face-conditional-readback.json');sm['actualPrintedCostVisualReadback']=pin(ev/'current-exact-cn156-face-actual-visual-cost-disposition.json');sm['precedingFixedA68bfActualCompletedRuleSuiteOnly']=pin(ev/'preceding-fixed-a68bf-completed-rule-suite-independent.json');sm['currentEnglishWholeListReadback']=pin(ev/'current-english-whole-list-existing-version-disposition.json');sm['all1408ReturnedEnRowsMatchLatestRegisteredVersionWithExistingEightGapRetained']=True
write(ev/'source-manifest.json',sm);sp=pin(ev/'source-manifest.json','source-manifest')
branches=[]
for c in prep['cases']:
 branches.append(dict(id=c['id'],sourceRefs=c['exactPrintingSubjects']+c['existingCanonicalRuleIds'],sourceManifest=sp,state='RECORDED',boundedCase=dict(actualExecutedCase=c['actualExecutedCase'],method=c['method']),semanticReview=dict(state='BOUNDED_ZERO_PRINTED_POWER_PROMPT_AND_REAL_NORMAL_FLOW_ECHO_COSTS'),implementation=dict(state='ONE_SHARED_PROMPT_GUARD_ONLY_SERVER_REFUSAL_UNCHANGED'),testExecution=dict(state='ACTUAL_FIVE_NEW_CASES_131_FOCUS_SIX_ORIGINAL_GAMES_AND_SOLE13638_CHECK_PASS'),fixedCommitCi=dict(state='PENDING_NEW_FIXED_FULL'),productAcceptance=dict(state='OPEN_NEW_FIXED_NATIVE_AND_REQUIRED_PRODUCTS'),decision=dict(state='OPEN',reason='Bounded current source and execution evidence; fixed full and current product acceptance remain separate.'),wholePrintingCertified=False))
write(ev/'five-exact-behavior-branches.json',dict(branches=branches))
refreshed=[]
for name,c in m['reviewContexts'].items():
 changes=[]
 for ref in c['implementation']:
  h=sha(root/ref['path'])
  if h!=ref['sha256']:
   assert ref['path']=='src/Riftbound.Engine/MatchSession.cs';changes.append(dict(path=ref['path'],before=ref['sha256'],after=h));ref['sha256']=h
 if changes:
  refreshed.append(dict(id=name,changes=changes,oldCompleteContext=old['reviewContexts'][name]));c.update(currentImplementationCommit=base,currentImplementationIncludesUncommittedChanges=True,ciState='PENDING',currentZeroPrintedPowerPromptInputRefresh=dict(sourceManifest=sp,onlyCurrentInputPinsNotWholeSemanticCertification=True,allPriorEvidenceAndOptionalVerificationReferencesRetained=True,newFixedFullAndProducts='OPEN'))
assert len(refreshed)==38 and {r['id']for r in refreshed}=={r['id']for r in binding['changes']}
for name,c in old['reviewContexts'].items():
 current=m['reviewContexts'][name];assert current.get('verificationSources')==c.get('verificationSources')and('verificationSources'in current)==('verificationSources'in c)
 if name not in {r['id']for r in refreshed}:assert current==c
(ev/'thirty-eight-input-refreshes-complete-old-contexts.json.gz').write_bytes(gzip.compress(json.dumps(refreshed,ensure_ascii=False,indent=2).encode(),mtime=0))
m['reviewContexts'][identity]=dict(evidenceCommit=base,currentImplementationCommit=base,currentImplementationIncludesUncommittedChanges=True,ciState='PENDING',ciReceipts=[],region='CN',language='zh-CN',applicableAsOf='2026-10-23',adoptedCoreEffectiveDate='2026-10-16',sourceManifest=sp,implementation=implementation,verificationSources=verification,branches=branches,evidence=[pin(ev/'original-test-and-source-retention.json','focus-check-and-retention'),pin(ev/'original-red-execution-and-runtime.json','original-red'),pin(ev/'preceding-fixed-a68bf-bounded-native49-ci-pair40-and-original-replay.json','preceding-fixed-native-only')])
reviews['reviews'].append(dict(id=identity,scope=sm['scope'],subjects=['VEN-156'],ruleRecords=[r['id']for r in prep['sourceRuleRecords']],status='BOUNDED_ZERO_POWER_PROMPT_COST_AND_REFUSAL_PASS_NEW_FIXED_FULL_PRODUCTS_OPEN',sourceManifest=sp,auditDocument=document,validation=dict(newCases=5,newMethods=2,soleCheckCases=13638,soleCheckMethods=7602,focusedCases=131,focusedMethods=50,originalFullGameMethods=6,wholeCardCertification=False),exclusions=['Whole printing and distinct GLOBAL printing remain uncertified','All prior sources and seven source deltas retained','Prior a68bf native proofs remain on their original RIF3b84 input, not new Debug e995','New fixed full, current native, OS hardware input and physical Windows remain separate','Original malformed request and all owner/helper failures retained; accepted histories and seeds unchanged']))
gate=dict(id='ZERO_PRINTED_POWER_PROMPT_CURRENT_FIXED_MAIN_AND_PRODUCTS',state='OPEN',scope='CN VEN-156 zero-power prompt, normal/Flow/Echo real costs and malformed input refusal',sourceManifest=sp,issue='https://github.com/DDDHL0704/riftbound/issues/95',semanticReview='BOUNDED',implementation='SHARED_PROMPT_GUARD_ONLY',testExecution='FIVE_NEW_131_FOCUS_SIX_ORIGINAL_GAMES_SOLE_CHECK13638',fixedCommitCi='OPEN_NEW_FIXED_FULL',productAcceptance='OPEN_NEW_FIXED_MAIN_PAIR_NETWORK_NORMAL_SCORE_REPLAY_OS_HARDWARE_AND_PHYSICAL_WINDOWS',wholePrintingCertified=False)
assert gate['id']not in {g['id']for g in m['acceptanceGates']};m['acceptanceGates'].append(gate)
assert reviews['reviews'][:-1]==old_reviews['reviews']and m['acceptanceGates'][:-1]==old['acceptanceGates']and m['laterSourceDeltas']==old['laterSourceDeltas']and m['certificationScope']==old['certificationScope']
rp.write_text(json.dumps(reviews,ensure_ascii=False,indent=2)+'\n');m['inputs']['reviews']['sha256']=sha(rp)
coverage=load(root/old['cardCoverageManifest']['path']);old_coverage=copy.deepcopy(coverage)
coverage.update(previousCurrentScopedReviewDecisionsBeforeZeroPowerPrompt=old_coverage['currentScopedReviewDecisions'],currentScopedReviewDecisions=m['inputs']['reviews'],currentZeroPowerPromptScopedSourceManifest=sp)
assert all(coverage[k]==v for k,v in old_coverage.items()if k!='currentScopedReviewDecisions')
write(ev/'source-coverage.json',coverage);m['cardCoverageManifest']=pin(ev/'source-coverage.json','current-card-coverage')
m['currentZeroPrintedPowerPromptInputChange']=dict(sourceManifest=sp,auditDocument=document,issue='https://github.com/DDDHL0704/riftbound/issues/95',newBoundedBehaviorBranches=5,newProductGate=1,all168OldReviewObjects83ContextIdentities269GatesSevenDeltasRetained=True,all83OldCompleteContextsArchived38InputPinRefreshes45WholeObjectsExact=True,allOldOptionalVerificationSourcePresenceAndValuesExact=True,noCatalogOrSourceUniverseChange=True,allOriginal17384ObligationIdsRetained=True,expectedRemainingObligations=17390,newFixedFullAndProducts='OPEN',wholePrintingOrGoalComplete=False)
m['precedingFixedA68bfBoundedLockedGpuPairControlsNormalScoreNetworkAndOriginalReplay']=pin(ev/'preceding-fixed-a68bf-bounded-native49-ci-pair40-and-original-replay.json')
if ci.exists():m['precedingFixedA68bfActualCompleteFullCiReadback']=pin(ev/'preceding-fixed-a68bf-entire-full-independent.json')
else:m['precedingFixedA68bfObservedCiBeforeZeroPromptPublication']=pin(ev/'preceding-fixed-a68bf-ci-observation.json')
assert (len(reviews['reviews']),len(m['reviewContexts']),len(m['acceptanceGates']),len(m['laterSourceDeltas']))==(169,84,270,7)
assert all(m['inputs'][k]==old['inputs'][k]for k in old['inputs']if k!='reviews')
mp.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
prior_ci_sentence='前固定a68bf完整CI39844928152实际11项成功，九原ZIP独立复核13782例/7741方法、62SQL；原143/151、110配对11牌组424242全部保留。'if ci.exists()else'前固定a68bf完整CI39844928152的规则任务原ZIP已独立核对13782例/7741方法、143完整151例110配对11牌组424242全部保留；发布时整次实际观察另存，SQL与整次成功仍独立，未取得完整终态前不记完整通过。'
(root/document).write_text((z/'final-audit-prose-v1.md').read_text().replace('{{PRIOR_CI_SENTENCE}}',prior_ci_sentence));status=root/'docs/PROJECT_STATUS.md';old_status=gzip.decompress((z/'prior-coherent-publication-inputs-v1/PROJECT_STATUS.md.gz').read_bytes()).decode();heading='# 当前项目状态\n\n';assert status.read_text()==old_status and old_status.startswith(heading)
status.write_text(heading+(z/'final-status-prose-v1.md').read_text().replace('{{PRIOR_CI_SENTENCE}}',prior_ci_sentence)+old_status[len(heading):])
governance=root/'docs/PROJECT_GOVERNANCE.md';prior_gov=gzip.decompress((z/'prior-coherent-publication-inputs-v1/PROJECT_GOVERNANCE.md.gz').read_bytes()).decode();assert governance.read_text()==prior_gov
anchor='不同提交的CI互不取消';paragraph='2026-10-23 已在锁屏中实测非headless原生GPU自身视口：固定CI导出的默认Main可保存双方真实画面并做同进程冷恢复、正常得分结束及原始回放；单份SDK可实例化未改生产Main执行真实控件、后端费用预览和提交。两条路径分别绑定实际源、程序集及规则输入，SDK控件证据不得冒称CI导出包的硬件输入；导出包禁止外部场景覆写时保留其拒绝，不关闭限制。逐步收据与原始失败保留，桌面键鼠和Windows实机仍独立OPEN。只复用最新双端、每平台一包、一份SDK/模板和原数据库，不因锁屏重复请求解锁或复制运行环境。\n\n'
assert prior_gov.count(anchor)==1;governance.write_text(prior_gov.replace(anchor,paragraph+anchor,1))
write(ev/'publication-governance-retention.json',dict(atUtc=now(),oldReviews=168,oldContexts=83,oldGates=269,oldDeltas=7,oldRemainingIds=17384,newBehaviorBranches=5,newGate=1,currentRemainingObligations=17390,currentReviews=169,currentContexts=84,currentGates=270,completeOldContextsArchived=83,refreshedCurrentImplementationPins=38,otherWholeContextObjectsUnchanged=45,allOldReviewsGatesDeltasScopeOptionalVerificationReferencesAndSourceDatesRetained=True,noCardLedgerIndexOrRuntimeCatalogChange=True,semanticCoverageCertified=False))
print('PUBLISHED_N48_5NEW_131FOCUS_6ORIGINALGAMES_CHECK13638_7602_169REVIEWS84CONTEXTS270GATES7DELTAS_17390OBLIGATIONS',flush=True)
