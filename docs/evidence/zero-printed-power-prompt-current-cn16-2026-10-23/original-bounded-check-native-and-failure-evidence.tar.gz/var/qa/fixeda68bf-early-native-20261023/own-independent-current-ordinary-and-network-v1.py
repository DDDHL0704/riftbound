from pathlib import Path
import ast,datetime,fcntl,gzip,hashlib,json,os,plistlib,resource,socket,subprocess

resource.setrlimit(resource.RLIMIT_CORE,(0,0))
os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound')
n=Path(__file__).resolve().parent
w=n/'ordinary-ci-pair-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin')
cluster=root/'var/qa/permanent-play-here-base-20261017/postgres'
sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts']
read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
functions=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
for node in ast.parse(functions.read_text()).body:
 if isinstance(node,ast.FunctionDef)and node.name in {'query','rooms','digests','observe_lock'}:
  exec(compile(ast.get_source_segment(functions.read_text(),node),str(functions),'exec'),globals())
pub=load(n/'frozen-fixeda68bf-native-composition-v1.json')
runtime=Path(pub['apiRuntimeRoot'])
helpers=Path(pub['helperRuntimeRoot'])
previous=load(w/'current-ordinary-score-network-owner-terminal-v1.json')
assert previous['status'].startswith('PASS_CURRENT_ORDINARY_')
assert all(previous[k]for k in ['ownApiStopped','ownPostgresSmartStopped','all422AuditSevenTablesExact','all101PriorNativeSevenTablesExact'])
terminal=w/'independent-current-ordinary-and-network-owner-terminal-v1.json'
assert not terminal.exists()
reader_specs=[('ordinary',w/'independent-ordinary-reader-source-v1','Fixeda68bfOrdinaryHistoryReaderV1'),('network',w/'independent-network-reader-source-v1','IndependentFixeda68bfTwoNetworkV1')]
own_files=[Path(__file__),functions]
for _,source,name in reader_specs:
 own_files += [source/'Program.cs',source/'probe.csproj',source/'bin/Release/net10.0'/(name+'.dll'),source/'bin/Release/net10.0'/(name+'.pdb')]
own_hashes={str(p):sha(p)for p in own_files}
def stable():
 assert all(sha(runtime/p)==h for p,h in pub['runtimeFiles'].items())
 assert all(sha(helpers/p)==h for p,h in pub['helperRuntimeFiles'].items())
 assert all(sha(Path(p))==h for p,h in own_hashes.items())
def reader_prefix(source,name):
 return ['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(runtime/'Riftbound.Api.deps.json'),'--runtimeconfig',str(runtime/'Riftbound.Api.runtimeconfig.json'),str(source/'bin/Release/net10.0'/(name+'.dll'))]
proof=dict(status='RUNNING_INDEPENDENT_CURRENT_ORDINARY88_NETWORK3_READONLY',startedAtUtc=now(),fixedCommit=pub['fixedCommit'],actualRuleInputs=pub['actualRuleInputs'],ownReaderInputHashes=own_hashes,lockAtStart=observe_lock(),actualLoadedReaders=[])
for label,source,name in reader_specs:
 measurement=json.loads(subprocess.check_output(reader_prefix(source,name)+['--loaded-inputs'],cwd=runtime,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0')))
 assert Path(measurement['baseDirectory'])==runtime and measurement['actualRuleInputs']==pub['actualRuleInputs']and len(measurement['assemblies'])==4
 for a in measurement['assemblies']:
  assert Path(a['path'])==runtime/(a['name']+'.dll')and a['sha256']==pub['runtimeFiles'][a['name']+'.dll']and a['mvid']
 proof['actualLoadedReaders'].append(dict(label=label,actualLoadedFourAssemblies=measurement))
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a')
fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
started=False
power=None
audit=native=before_audit=before_native=None
try:
 stable()
 assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket()as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())])
 proof['boundIdleAssertionPid']=power.pid
 sock.mkdir(exist_ok=True)
 subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'independent-current-ordinary-network-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True)
 started=True
 audit=rooms('riftbound_acceptance')
 native=rooms('riftbound_here_native')
 assert audit==previous['actualAuditRoomsAtStop']and native==previous['actualNativeRoomsAtStop']and len(audit)==422 and len(native)==104
 before_audit=digests('riftbound_acceptance',audit)
 before_native=digests('riftbound_here_native',native)
 for room in previous['twoSeparateNewNetworkRooms']:
  assert room in native and (room.startswith('NETWORK-')or room.startswith('NETWORK-SEAT-'))
  frame_path=w/'original-native-records'/('current-network-'+room+'-original-frame-v1.json.gz')
  assert not frame_path.exists()
  args=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(helpers/'Riftbound.Api.deps.json'),'--runtimeconfig',str(helpers/'Riftbound.Api.runtimeconfig.json'),str(helpers/'FixedNativeFrameExport.dll'),room,str(frame_path)]
  env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit;Options=-c default_transaction_read_only=on',DOTNET_DbgEnableMiniDump='0')
  metadata=json.loads(subprocess.check_output(args,cwd=helpers,env=env))
  assert metadata['actualRuleInputs']==pub['actualRuleInputs']
  (w/'original-native-records'/('current-network-'+room+'-actual-loader-v1.json')).write_text(json.dumps(metadata,indent=2))
  raw={t:json.loads(query('riftbound_here_native',f"select coalesce(json_agg(t order by row_to_json(t)::text),'[]'::json)::text from(select * from {t} where match_id='{room}')t"))for t in tables}
  path=w/'original-native-records'/('current-network-'+room+'-all-seven-original-tables-v1.json.gz')
  assert not path.exists()
  path.write_bytes(gzip.compress(json.dumps(dict(room=room,originalRows=raw),ensure_ascii=False,indent=2).encode(),mtime=0))
 results={}
 for label,source,name in reader_specs:
  result=w/('independent-current-'+label+'-originals-result-v1.json')
  assert not result.exists()
  args=reader_prefix(source,name)+[str(w),str(result)]
  with(w/('independent-current-'+label+'-originals-console-v1.log')).open('xb')as output:
   code=subprocess.run(args,cwd=runtime,env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit',DOTNET_DbgEnableMiniDump='0'),stdout=output,stderr=subprocess.STDOUT,timeout=300).returncode
  proof[label+'ExitCode']=code
  assert code==0,'Original independent failure retained; never rewrite a history or weaken its oracle.'
  data=load(result)
  assert data['actualRuleInputs']==pub['actualRuleInputs']
  if label=='ordinary':
   assert data['commands']==88 and data['events']==603 and data['winningScore']==8 and data['nativeAcceptedGameplayCommands']==3
   assert data['actualHistoricalPayloads']==dict(state_snapshots=88,snapshots=175,action_prompts=175)
  else:assert data['totals']==dict(commands=3,events=3,authority=3,snapshots=4,prompts=4)
  results[label]=dict(status=data['status'],result=str(result),sha256=sha(result))
  print('INDEPENDENT_CURRENT_ORIGINAL_READBACK_PASS',label,flush=True)
 proof.update(status='PASS_INDEPENDENT_CURRENT_ORDINARY88_COMMANDS603_EVENTS_ALL_ORIGINAL_STATES_PRIVATE_VIEWS_AND_FULL_REPLAY_NETWORK3_ORIGINAL_SEATS_AND_FOUR_PRIVATE_VIEWS',results=results)
except BaseException as error:
 proof.update(status='FAILED_INDEPENDENT_CURRENT_ORDINARY_NETWORK_ORIGINALS_RETAINED',errorType=type(error).__name__,error=str(error))
 raise
finally:
 if started:
  if before_audit is not None:
   proof.update(all422AuditSevenTablesExact=digests('riftbound_acceptance',audit)==before_audit,all104NativeSevenTablesExact=digests('riftbound_here_native',native)==before_native,actualAuditRoomsAtStop=rooms('riftbound_acceptance'),actualNativeRoomsAtStop=rooms('riftbound_here_native'))
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None and power.poll()is None:
  power.terminate()
  power.wait(timeout=10)
 stable()
 proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),allFrozen46Api87HelperAndOwnReaderInputsStable=True)
 with terminal.open('x')as output:json.dump(proof,output,ensure_ascii=False,indent=2)
 fcntl.flock(guard,fcntl.LOCK_UN)
assert all(proof[k]for k in ['all422AuditSevenTablesExact','all104NativeSevenTablesExact','ownPostgresSmartStopped'])
print(proof['status'],flush=True)
