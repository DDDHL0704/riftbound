import ast,copy,datetime,errno,fcntl,gzip,hashlib,json,os,plistlib,pty,re,resource,socket,subprocess,threading,time,urllib.request
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');n=Path(__file__).resolve().parent;home=n/'remaining-native-completed-v3';home.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486');tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
functions=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py';base_functions=root/'var/qa/fixed55fdb-early-native-20261022/lab-ci-pair-v1/controlled-lab-native-owner-functions-v1.py';control_functions=n/'flow-ci-main-v1/own-current-production-controls-and-ci-pair-v5.py'
for source,names in [(functions,{'query','rooms','digests','observe_lock'}),(base_functions,{'frozen','start_api','export','native_wait','log_count','wait_exit'}),(control_functions,{'checkpoint','save_rows','launch','stop','cold','native','local_stable'})]:
 for node in ast.parse(source.read_text()).body:
  if not isinstance(node,ast.FunctionDef)or node.name not in names:continue
  body=ast.get_source_segment(source.read_text(),node)
  if node.name=='native':
   needle=" (action_dir/'original-server-action-plan.json').write_text"
   extra=""" if action=='PAY_COST':
  options=candidate['metadata']['paymentChoices'];plan['choiceIndex']=next(i for i,c in enumerate(options)if c['id']=='BANISH')
 if action=='CHOOSE_CARDS':
  choices=candidate['metadata']['cardChoices'];wanted='P1_FIRST'if branch=='observed-keep'else'P1_FIRST_FILLER_1'
  plan['choiceIndex']=next(i for i,c in enumerate(choices)if c['id']==wanted)
"""
   assert body.count(needle)==1;body=body.replace(needle,extra+needle)
  exec(compile(body,str(source),'exec'),globals())
pub=load(n/'frozen-fixeda68bf-native-composition-v1.json');api_runtime=Path(pub['apiRuntimeRoot']);helpers=Path(pub['helperRuntimeRoot'])
local_inputs=load(root/'var/qa/deck-look-draw-graveyard-current-cn16-20261022/native-actual-sql62-controls-v2/actual-native-control-terminal-v2.json');sdk=Path('/Users/dinghaolin/.local/share/riftbound-tools/godot-4.7.2/Godot_mono.app/Contents/MacOS/Godot');control_scene=n/'flow-ci-main-v1/actual-current-main-controls-v2.tscn';driver_dll=n/'flow-ci-main-v1/gateway-preparation-source-v1/bin/Release/net10.0/Fixeda68bfLightningRushPrepareV1.dll'
prior_owner=n/'remaining-six-ci-main-v2/current-remaining-six-native-owner-terminal-v2.json';previous=load(prior_owner)
assert previous['status']=='FAILED_CURRENT_SIX_NATIVE_BRANCH_ORIGINALS_RETAINED'and previous['ownPostgresSmartStopped']and previous['all422AuditSevenTablesExact']and previous['all104PriorNativeSevenTablesExact']
assert len(previous['branches'])==6 and all(b.get('status','').startswith('PASS_CURRENT_SOURCE_NATIVE_')for b in previous['branches'][:5])
old_branch=previous['branches'][-1];old_root=n/'remaining-six-ci-main-v2/observed';resume_room=old_branch['room'];old_frame_path=old_root/'original-native-records/owner-final-retained-original-frame.json.gz';old_frame=json.loads(gzip.decompress(old_frame_path.read_bytes()));assert len(old_frame['commands'])==7 and old_frame['commands'][-1]['rawCommand']['paymentChoiceIds']==['KEEP']and all(c['accepted']for c in old_frame['commands'])
own_inputs={str(p):sha(p)for p in [Path(__file__),functions,base_functions,control_functions,control_scene,n/'flow-ci-main-v1/actual-current-main-controls-v2.gd',sdk,driver_dll,driver_dll.with_suffix('.pdb'),prior_owner,old_frame_path,n/'own-current-remaining-six-flow-main-v2.py']}
def count():
 assert re.fullmatch('N47-FLOW-[0-9A-F]{10}',room)
 return int(query('riftbound_here_native',"select count(*) from command_log where match_id='"+room+"'"))
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof=dict(status='RUNNING_ORIGINAL_OBSERVATION_KEEP_AND_FRESH_EXPLICIT_BANISH',startedAtUtc=now(),fixedCommit=pub['fixedCommit'],fixedCiRun=pub['fixedCiRun'],actualRuleInputs=pub['actualRuleInputs'],ownInputHashes=own_inputs,ownedApiProcesses=[],ownedNativeProcesses=[],branches=copy.deepcopy(previous['branches'][:5]),lockAtStart=observe_lock(),allFiveCompletedPreviousBranchObjectsRetainedExact=True,allOriginalKeepInputsRetainedNeverReclassifiedAsBanish=True,sourceNativeControlsAndCiPairGpuViewsSeparatelyBound=True,osHardwareAndPhysicalWindowsOpen=True)
api=driver=power=None;clients=[];pumps={};started=False;room=None;audit=prior_native=before_audit=before_native=None;w=profiles=evidence=None
try:
 frozen();local_stable();assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket()as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid;sock.mkdir(exist_ok=True)
 subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(home/'owned-observation-variants-postgres-v3.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 audit=rooms('riftbound_acceptance');prior_native=rooms('riftbound_here_native');assert audit==previous['actualAuditRoomsAtStop']and prior_native==previous['actualNativeRoomsAtStop']and len(audit)==422 and len(prior_native)==110
 before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',[r for r in prior_native if r!=resume_room])
 for branch in ['observed-keep','observed-banish']:
  w=home/branch;w.mkdir();evidence=w/'original-native-records';evidence.mkdir();profiles=w/'original-controlled-prefix';room=None;start_api(len(proof['ownedApiProcesses'])+1)
  if branch=='observed-keep':
   room=resume_room;profiles.mkdir()
   for role in ['a','b']:(profiles/('session-'+role+'.json')).write_bytes((old_root/'original-controlled-prefix'/('session-'+role+'.json')).read_bytes())
   a,b=old_branch['players'];first=old_frame;frame=export('resumed-same-seven-original-keep-inputs');assert all(frame[k]==first[k]for k in ['commands','events','authoritativeState','openingSeed','replayInitialState'])
   current=copy.deepcopy(old_branch);current.update(branch=branch,originalPartialOwnerBranchLabel='observed',acceptedOriginalKeepChoiceNotRewritten=True);proof['branches'].append(current)
   frame=cold('original-keep-private-draw-choice',frame);frame=native('CHOOSE_CARDS',a,'draw-original-observed-kept-card',frame);assert frame['commands'][-1]['rawCommand']['chosenObjectIds']==['P1_FIRST']
  else:
   old_rooms=set(rooms('riftbound_here_native'));args=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(helpers/'Fixed708OriginalBandleTreeScoreV1.deps.json'),'--runtimeconfig',str(helpers/'Fixed708OriginalBandleTreeScoreV1.runtimeconfig.json'),str(driver_dll),str(profiles),str(n/'ordinary-ci-pair-v1'),'observed']
   with(w/'original-explicit-gateway-preparation.log').open('xb')as output:driver=subprocess.Popen(args,cwd=helpers,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0'),stdout=output,stderr=subprocess.STDOUT);code=driver.wait(timeout=95)
   added=set(rooms('riftbound_here_native'))-old_rooms
   if len(added)==1:room=next(iter(added))
   assert code==0 and len(added)==1;entry=load(profiles/'lightning-rush-original-entry-v1.json');assert entry['room']==room;a,b=entry['players'];first=export('initial-three-original-entries');assert len(first['commands'])==3 and first['commands'][2]['commandType']=='DEV_SEED_SCENARIO:lightning-rush-observed'
   current=dict(branch=branch,room=room,players=[a,b],nativeCommands=[],coldRestores=[],viewportImages=[],initialOriginalRows=save_rows('initial-all-seven-original-tables.json.gz'));proof['branches'].append(current)
   frame=cold('before-parent',first);frame=native('PLAY_CARD',a,'play-original-parent',frame);frame=cold('original-parent-on-stack',frame)
   for i in range(2):frame=native('PASS_PRIORITY',frame['authoritativeState']['priorityPlayerId'],'original-parent-priority-'+str(i),frame)
   assert frame['authoritativeState']['pendingRuleChoice']['request']['kind']=='DECK_OBSERVATION_BANISH'
   frame=cold('private-original-observation-banish',frame);frame=native('PAY_COST',a,'choose-actual-server-banish-button',frame);assert frame['commands'][-1]['rawCommand']['paymentChoiceIds']==['BANISH']
   choice=frame['authoritativeState']['pendingCardChoice'];assert choice['legalObjectIds']==['P1_FIRST_FILLER_1','P1_FIRST_FILLER_2']
   frame=cold('private-draw-after-original-banish',frame);frame=native('CHOOSE_CARDS',a,'draw-original-unbanished-filler',frame);assert frame['commands'][-1]['rawCommand']['chosenObjectIds']==['P1_FIRST_FILLER_1']
   assert frame['authoritativeState']['pendingEffectPlay']is not None;frame=cold('original-observed-card-pending-play',frame);frame=native('PLAY_CARD',a,'play-original-observed-card',frame);assert frame['commands'][-1]['rawCommand']['sourceObjectId']=='P1_FIRST'
  state=frame['authoritativeState'];own=state['playerZones'][a];assert not state['stackItems']and state.get('pendingRuleChoice')is None and state.get('pendingCardChoice')is None and state.get('pendingEffectPlay')is None and 'PARENT'in own['graveyard']and state['cardObjects']['PARENT']['objectGeneration']==2
  if branch=='observed-keep':assert len(frame['commands'])==8 and own['hand']==['P1_FIRST']and 'P1_FIRST'not in own['base']and len(own['graveyard'])==3 and len(own['mainDeck'])==4
  else:assert len(frame['commands'])==9 and own['hand']==['P1_FIRST_FILLER_1']and 'P1_FIRST'in own['base']and 'P1_FIRST_FILLER_2'in own['graveyard']and 'P1_FIRST'not in own['graveyard']
  assert frame['commands'][:len(first['commands'])]==first['commands']and frame['events'][:len(first['events'])]==first['events']and frame['openingSeed']==first['openingSeed']and frame['replayInitialState']==first['replayInitialState']and all(c['accepted']for c in frame['commands'])
  frame=cold('completed-original-observation-variant',frame);current.update(status='PASS_CURRENT_SOURCE_NATIVE_BRANCH_AND_CI_PAIR_GPU_COLD_ORIGINAL_HISTORY_REPLAY_PENDING',commands=len(frame['commands']),events=len(frame['events']),finalOriginalRows=save_rows('final-all-seven-original-tables.json.gz'))
  api.terminate();api.wait(timeout=25);assert api.returncode==0;print('ACTUAL_CURRENT_OBSERVATION_VARIANT_PASS',branch,current['commands'],current['events'],flush=True)
 assert proof['branches'][:5]==previous['branches'][:5]and len(set(rooms('riftbound_here_native'))-set(prior_native))==1
 proof['status']='PASS_CURRENT_SEVEN_REMAINING_NATIVE_BRANCHES_INCLUDING_BOTH_ORIGINAL_KEEP_AND_ACTUAL_BANISH_CI_PAIR_GPU_COLD_INDEPENDENT_READBACK_PENDING'
except BaseException as error:
 proof.update(status='FAILED_CURRENT_OBSERVATION_VARIANTS_ORIGINALS_RETAINED',errorType=type(error).__name__,error=str(error));raise
finally:
 if driver is not None and driver.poll()is None:driver.terminate();driver.wait(timeout=20)
 for p,record,log in clients:
  if p.poll()is None:p.terminate();p.wait(timeout=20);record['onlyOwnFailureCleanup']=True
  pumps[p.pid].join(timeout=10);record.update(exitCode=p.returncode,logSha256=sha(log),ptyFullyDrained=not pumps[p.pid].is_alive())
 if started and room is not None:
  try:export('owner-final-retained-original-frame')
  except BaseException as error:proof['finalFrameExportError']=type(error).__name__
 if api is not None and api.poll()is None:api.terminate();api.wait(timeout=25)
 proof['ownApiStopped']=api is None or api.poll()is not None
 if started:
  if before_audit is not None:proof.update(all422AuditSevenTablesExact=digests('riftbound_acceptance',audit)==before_audit,all109OtherNativeSevenTablesExact=digests('riftbound_here_native',[r for r in prior_native if r!=resume_room])==before_native,actualAuditRoomsAtStop=rooms('riftbound_acceptance'),actualNativeRoomsAtStop=rooms('riftbound_here_native'))
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None and power.poll()is None:power.terminate();power.wait(timeout=10)
 frozen();local_stable();proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),allOwnInputsStable=all(sha(Path(p))==h for p,h in own_inputs.items()))
 with(home/'current-seven-remaining-native-owner-terminal-v3.json').open('x')as output:json.dump(proof,output,ensure_ascii=False,indent=2)
 fcntl.flock(guard,fcntl.LOCK_UN)
assert all(proof[k]for k in ['ownApiStopped','ownPostgresSmartStopped','all422AuditSevenTablesExact','all109OtherNativeSevenTablesExact','allOwnInputsStable'])
print(proof['status'],flush=True)
