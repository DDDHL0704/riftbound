from pathlib import Path
import datetime,hashlib,io,json,os,subprocess,tarfile
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;fixed='a68bfcf9684c328e999d2a57ec8c6e360528c8a9'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==fixed
status=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).splitlines();assert all(line=='?? .claude/' for line in status)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
paths=['src/Riftbound.Api','src/Riftbound.Engine','src/Riftbound.CardCatalog','src/Riftbound.Contracts','src/Riftbound.Persistence','data/official/card-catalog.zh-CN.json','data/official/rule-input-scope.json','data/official/armaments.json','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','NuGet.config','nuget.config','global.json']
tracked=set(subprocess.check_output(['git','ls-tree','-r','--name-only',fixed],cwd=root).decode().splitlines());paths=[p for p in paths if p in tracked or any(t.startswith(p+'/') for t in tracked)];raw=subprocess.check_output(['git','archive',fixed,*paths],cwd=root);records={}
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:') as tar:
 for member in tar.getmembers():
  if member.isfile():
   b=tar.extractfile(member).read();assert (root/member.name).read_bytes()==b;records[member.name]=hashlib.sha256(b).hexdigest()
assert len(records)==257
runtime=w/'fixeda68bf-api-gameplay-closure-runtime-v1';assert not runtime.exists()
command=['/Users/dinghaolin/.dotnet/dotnet','publish','src/Riftbound.Api/Riftbound.Api.csproj','--configuration','Release','--no-restore','--nologo','-p:SourceRevisionId='+fixed,'--output',str(runtime)]
with (w/'build-fixeda68bf-exact-api-closure-v1.log').open('xb') as log:subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0'))
assert all(sha(root/p)==h for p,h in records.items());files={str(p.relative_to(runtime)):sha(p) for p in runtime.rglob('*') if p.is_file()};assert len(files)==46
proof={'atUtc':now(),'fixedCommit':fixed,'runtimeRoot':str(runtime),'runtimeFiles':files,'allDeclaredApiGameplaySourceInputsExactFixedCommit':records,'actualCommand':command,'sourceRevisionIdExplicitlyPinned':fixed,'trackedWorktreeCleanBeforeBuild':True,'actualAllowedUntrackedEntries':status,'fullyCleanRootNotClaimedWhileUnrelatedDotClaudeExists':True,'declaredGameplayAndBuildClosureOnlyNotEntireCompilerEnvironment':True,'notCiExportedApiBinary':True,'ownApiNotStarted':True};p=w/'fixeda68bf-api-gameplay-closure-frozen-inputs-v1.json';assert not p.exists();p.write_text(json.dumps(proof,indent=2));print('FIXEDA68BF_API257_EXACT_SOURCE_46_RUNTIME_FROZEN; tracked clean, unrelated .claude explicitly preserved; actual API not yet started',flush=True)
