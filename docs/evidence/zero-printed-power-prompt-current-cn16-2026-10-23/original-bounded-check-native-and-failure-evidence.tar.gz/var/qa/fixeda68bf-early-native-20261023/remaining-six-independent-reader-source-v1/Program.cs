using System.Security.Cryptography;
using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.CardCatalog;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

var json=new JsonSerializerOptions(JsonSerializerDefaults.Web){WriteIndented=true};
var modules=new[]{typeof(CoreRuleEngine).Assembly,typeof(CommandReceiptDto).Assembly,typeof(OfficialCardCatalog).Assembly,typeof(PostgresMatchRecoveryStore).Assembly};
var loaded=new{baseDirectory=AppContext.BaseDirectory,actualRuleInputs=RuleInputIdentity.Current,assemblies=modules.Select(a=>new{name=a.GetName().Name,path=a.Location,sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(a.Location))).ToLowerInvariant(),mvid=a.ManifestModule.ModuleVersionId}).ToArray()};
if(args is ["--loaded-inputs"]){Console.WriteLine(JsonSerializer.Serialize(loaded,json));return;}
Check(args.Length==2,"Original completed owner and one fresh result path only.");
var home=Path.GetFullPath(args[0]);var output=Path.GetFullPath(args[1]);Check(!File.Exists(output),"Never overwrite independent evidence.");
using var owner=JsonDocument.Parse(File.ReadAllText(Path.Combine(home,"current-remaining-six-native-owner-terminal-v2.json")));
var top=owner.RootElement;Check(top.GetProperty("fixedCommit").GetString()=="a68bfcf9684c328e999d2a57ec8c6e360528c8a9"&&top.GetProperty("status").GetString()!.StartsWith("PASS_CURRENT_SIX_REMAINING_",StringComparison.Ordinal),"Exact fixed source and completed, bounded writer.");
Check(top.GetProperty("branches").GetArrayLength()==6&&Same(top.GetProperty("actualRuleInputs"),JsonSerializer.SerializeToElement(RuleInputIdentity.Current,json)),"Two original branches and actual loaded input identity.");
var settings=new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
Check(settings.Host=="127.0.0.1"&&settings.Port==55486&&settings.Database=="riftbound_here_native"&&settings.Username=="codex_riftbound_audit","Only existing own database.");settings.Options="-c default_transaction_read_only=on";
await using var source=NpgsqlDataSource.Create(settings.ConnectionString);await using var connection=await source.OpenConnectionAsync();
Check((string)(await new NpgsqlCommand("show transaction_read_only",connection).ExecuteScalarAsync())! == "on","Actual read-only setting.");
var results=new List<object>();var totals=new Dictionary<string,int>{{"commands",0},{"accepted",0},{"rejected",0},{"events",0},{"authority",0},{"snapshots",0},{"prompts",0},{"native",0},{"originalPrefixReplays",0},{"pairedCiColdStages",0}};
foreach(var branch in top.GetProperty("branches").EnumerateArray()){
 var name=branch.GetProperty("branch").GetString()!;var room=branch.GetProperty("room").GetString()!;
 var expectedCommands=name switch{"flow-control"=>11,"flow-echo"=>8,"flow-counter"=>8,"flow-return-counter"=>9,"flow-empty"=>6,"observed"=>9,_=>throw new Exception("Unknown finite branch")};
 var expectedCold=name switch{"flow-control"or"flow-echo"=>5,"flow-counter"or"flow-empty"=>3,"flow-return-counter"=>4,"observed"=>6,_=>0};
 var actors=branch.GetProperty("players").EnumerateArray().Select(x=>x.GetString()!).ToArray();var a=actors[0];var b=actors[1];var flow=name!="observed";
 var frame=await new PostgresMatchRecoveryStore(source).LoadAsync(room,default)??throw new Exception("Original actual SQL frame required.");
 Check(frame.IsConsistent&&frame.ValidationErrors.Count==0&&frame.Commands.Count==expectedCommands&&frame.Commands.All(c=>c.Accepted&&c.RuleInputs==RuleInputIdentity.Current),"Literal original accepted command count and actual input binding.");
 Check(frame.OpeningSeed!=0&&frame.ReplayInitialState is{Tick:0,Status:"EMPTY",Seats.Count:0,CardObjects.Count:0},"Original private opening seed and atomic EMPTY origin.");
 var expectedTypes=new List<string>{"ROOM_SEAT","ROOM_SEAT","DEV_SEED_SCENARIO:lightning-rush-"+name,"PLAY_CARD"};
 if(name is "flow-control"or"flow-counter"or"flow-return-counter")expectedTypes.AddRange(["PASS_PRIORITY","PLAY_CARD"]);
 expectedTypes.AddRange(["PASS_PRIORITY","PASS_PRIORITY"]);
 if(name=="flow-control")expectedTypes.AddRange(["PASS_PRIORITY","PASS_PRIORITY","CHOOSE_CARDS"]);
 if(name=="flow-echo")expectedTypes.AddRange(["CHOOSE_CARDS","CHOOSE_CARDS"]);
 if(name=="flow-return-counter")expectedTypes.Add("CHOOSE_CARDS");
 if(name=="observed")expectedTypes.AddRange(["PAY_COST","CHOOSE_CARDS","PLAY_CARD"]);
 Check(frame.Commands.Select(c=>c.CommandType).SequenceEqual(expectedTypes),"Literal original finite command order; no invented or repeated parent/counter play.");
 using var finalRows=Read(branch.GetProperty("finalOriginalRows").GetProperty("path").GetString()!);var originalRows=finalRows.RootElement.GetProperty("originalRows");var states=new Dictionary<(long Tick,long Seq),MatchState>();var rowCounts=new Dictionary<string,int>();
 foreach(var table in new[]{"matches","match_players","command_log","game_events","state_snapshots","snapshots","action_prompts"}){
  using var query=new NpgsqlCommand($"select coalesce(json_agg(t order by row_to_json(t)::text),'[]'::json)::text from (select * from {table} where match_id=@room)t",connection);query.Parameters.AddWithValue("room",room);
  using var actual=JsonDocument.Parse((string)(await query.ExecuteScalarAsync())!);Check(Same(actual.RootElement,originalRows.GetProperty(table)),"Every original SQL field, null, omission and value: "+table);rowCounts[table]=actual.RootElement.GetArrayLength();
  if(table=="state_snapshots")foreach(var row in actual.RootElement.EnumerateArray()){
   var payload=row.GetProperty("payload");var state=payload.Deserialize<MatchState>(json)!;Check(Same(payload,JsonSerializer.SerializeToElement(state,json))&&state.RuleInputs==RuleInputIdentity.Current,"All typed original authority fields and input identity.");
   Check(states.TryAdd((state.Tick,row.GetProperty("last_event_sequence").GetInt64()),state),"Each original authority checkpoint is unique.");
  }
 }
 Check(states.Count==expectedCommands&&frame.Commands.All(c=>states.ContainsKey((c.CompletedTick,c.CompletedEventSequence))),"Every original accepted input has its unique original authority checkpoint.");
 foreach(var command in frame.Commands){
  var state=states[(command.CompletedTick,command.CompletedEventSequence)];var prefix=frame.Commands.TakeWhile(c=>c!=command).Append(command).ToArray();var events=frame.Events.Where(e=>e.Sequence<=command.CompletedEventSequence).ToArray();
  var replay=await MatchActionLogReplayer.VerifyFinalStateAsync(frame.ReplayInitialState!,prefix,state,new CoreRuleEngine(),default,events);Check(replay.IsMatch,"Every entire original prefix, including the actual refusal, replays: "+string.Join(";",replay.Errors));totals["originalPrefixReplays"]++;
 }
 var final=frame.AuthoritativeState!;var own=final.PlayerZones[a];Check(final.Tick==expectedCommands&&final.StackItems.Count==0&&final.PendingCardChoice is null&&final.PendingEffectPlay is null&&final.PendingRuleChoice is null,"All original finite work completes without a residual private task.");
 Check((flow?own.Banished:own.Graveyard).Contains("PARENT")&&!(flow?own.Graveyard:own.Banished).Contains("PARENT")&&final.CardObjects["PARENT"].ObjectGeneration==2,"One exact owner-correct physical parent exit; only Flow is banished.");
 Check(final.CardPlays.Finalized.Single(p=>p.Source.ObjectId=="PARENT").PlayerId==a,"Literal original parent finalizer remains A.");
 if(name is "flow-counter"or"flow-return-counter"){
  Check(own.MainDeck.Count==7&&own.Hand.Count==0&&own.Graveyard.Count==0&&frame.Events.All(e=>e.Event.Kind!="CARDS_PUT_IN_GRAVEYARD")&&!final.CardPlays.Resolved.Any(p=>p.Source.ObjectId=="PARENT"),"Countered Flow does not execute, draw, grave or enter successful-resolution history.");
 }else if(name=="flow-empty")Check(own.MainDeck.Count==0&&own.Hand.Count==0&&own.Graveyard.Count==0&&frame.Events.All(e=>e.Event.Kind!="CARD_DRAWN"),"Empty look completes without attempting a draw.");
 else if(name=="flow-echo")Check(own.Hand.SequenceEqual(new[]{"P1_FIRST","P1_SECOND"})&&own.Graveyard.Count==4&&own.MainDeck.SequenceEqual(new[]{"P1_TAIL"})&&final.CardPlays.Finalized.Count(p=>p.Source.ObjectId=="PARENT")==1&&final.CardPlays.Resolved.Count(p=>p.Source.ObjectId=="PARENT")==1,"Echo executes two successive private looks for one physical finalized/resolved card.");
 else if(name=="flow-control"){
  Check(own.MainDeck.Count==7&&own.Hand.Count==0&&own.Graveyard.Count==0&&final.PlayerZones[b].Hand.SequenceEqual(new[]{"P2_FIRST"})&&final.PlayerZones[b].Graveyard.Count==3&&final.CardPlays.Resolved.Single(p=>p.Source.ObjectId=="PARENT").PlayerId==b,"Current controller B draws from its own deck; owner A gets exactly one banished parent; resolver differs from finalizer.");
  var originalControl=states[(8,frame.Commands[7].CompletedEventSequence)];var parent=originalControl.StackItems.Single(s=>s.SourceObjectId=="PARENT");Check(parent.ControllerId==b&&parent.FlowPlay is{OwnerId:var owner,Source.Generation:1}&&owner==a&&originalControl.CardObjects["PARENT"].ObjectGeneration==1&&originalControl.PendingRuleChoice is null,"Same STACK control transfer preserves generation1 and original Flow receipt without invented casting-target remakes.");
 }else Check(own.Base.Contains("P1_FIRST")&&final.CardObjects["P1_FIRST"].CardNo=="OGN·194/298"&&own.Hand.SequenceEqual(new[]{"P1_FIRST_FILLER_1"})&&own.Graveyard.Contains("P1_FIRST_FILLER_2")&&!own.Graveyard.Contains("P1_FIRST"),"Only the actually observed Nocturne gains and uses its separate play after the original draw/grave instruction.");
 Check(frame.Events.All(e=>e.Event.Kind is not("CARD_DISCARDED"or"UNIT_DESTROYED")),"Direct graveyard instructions are not discard or destruction.");
 var native=branch.GetProperty("nativeCommands");Check(native.GetArrayLength()==expectedCommands-3&&native.EnumerateArray().Select(e=>e.GetProperty("index").GetInt32()).Order().SequenceEqual(Enumerable.Range(3,expectedCommands-3)),"Every post-seed original input is represented by one actual source-native control record, including the retained first three control-branch inputs.");
 foreach(var nativeEntry in native.EnumerateArray()){
  var index=nativeEntry.GetProperty("index").GetInt32();var command=frame.Commands[index];Check(Same(nativeEntry.GetProperty("completeOriginalCommand"),JsonSerializer.SerializeToElement(command,json)),"Every exact native raw field is its separately retained actual original SQL input.");
  var prior=states[(command.StartedTick,command.StartedEventSequence)];var rawCommand=command.RawCommand!.Value;Check(rawCommand.GetProperty("snapshotTick").GetInt64()==prior.Tick,"Literal original native prior tick.");
  if(command.CommandType=="PASS_PRIORITY")Check(command.PlayerId==prior.PriorityPlayerId,"Literal actual current priority owner.");
  if(command.CommandType=="PLAY_CARD"&&rawCommand.GetProperty("sourceObjectId").GetString()=="PARENT"){
   Check(command.PlayerId==a&&rawCommand.GetProperty("cardNo").GetString()=="VEN·156"&&rawCommand.GetProperty("optionalCosts").EnumerateArray().Select(v=>v.GetString()).SequenceEqual(name=="flow-echo"?new[]{"ECHO"}:Array.Empty<string>()),"Literal parent identity and only the actual Echo optional cost.");
   var after=states[(command.CompletedTick,command.CompletedEventSequence)];Check(after.RunePools[a].Mana==(name=="flow-echo"?27:flow?28:29)&&after.RunePools[a].TotalPower==(flow?29:30)&&(after.StackItems.Single().FlowPlay is not null)==flow,"Actual server payment uses Flow2+ANY1, additional printed Echo1, or normal1+0.");
  }
  if(command.CommandType=="PLAY_CARD"&&rawCommand.GetProperty("sourceObjectId").GetString()=="COUNTER")Check(command.PlayerId==b&&rawCommand.GetProperty("cardNo").GetString()==(name=="flow-control"?"OGN·080/298":name=="flow-counter"?"OGN·064/298":"UNL-131/219")&&rawCommand.GetProperty("targetObjectIds").EnumerateArray().Select(v=>v.GetString()).SequenceEqual(new[]{"STACK-4-PARENT"}),"Literal original B counter or control source and actual stack target.");
  if(command.CommandType=="CHOOSE_CARDS"){
   Check(prior.PendingCardChoice is{}choice&&choice.PlayerId==command.PlayerId&&rawCommand.GetProperty("choiceId").GetString()==choice.ChoiceId&&rawCommand.GetProperty("choiceWindow").GetString()==choice.ChoiceWindow,"Actual native choice stamps its original private task.");
   if(rawCommand.GetProperty("choiceWindow").GetString()=="INSIGHT")Check(rawCommand.GetProperty("chosenObjectIds").GetArrayLength()==0,"Original optional Insight is explicitly declined by the actual native confirm.");
  }
  if(command.CommandType=="PAY_COST")Check(name=="observed"&&command.PlayerId==a&&rawCommand.GetProperty("paymentChoiceIds").EnumerateArray().Select(v=>v.GetString()).SequenceEqual(new[]{"BANISH"}),"Only the exact observed-card optional banish is paid.");
  var prompts=originalRows.GetProperty("action_prompts").EnumerateArray().Where(r=>r.GetProperty("player_id").GetString()==command.PlayerId&&r.GetProperty("prompt_tick").GetInt64()==command.StartedTick&&r.GetProperty("last_event_sequence").GetInt64()==command.StartedEventSequence).ToArray();Check(prompts.Length==1&&prompts[0].GetProperty("payload").GetProperty("promptId").GetString()==rawCommand.GetProperty("promptId").GetString(),"Actual raw native intent stamps its independently stored original private prompt.");totals["native"]++;
 }
 foreach(var table in new[]{"snapshots","action_prompts"})foreach(var row in originalRows.GetProperty(table).EnumerateArray()){
  var actor=row.GetProperty("player_id").GetString()!;var payload=row.GetProperty("payload");var tick=row.GetProperty(table=="snapshots"?"snapshot_tick":"prompt_tick").GetInt64();var seq=row.GetProperty("last_event_sequence").GetInt64();var state=states[(tick,seq)];Check(state.Seats.ContainsKey(actor),"Actual historical viewer seat.");
  var typed=table=="snapshots"?JsonSerializer.SerializeToNode(payload.Deserialize<SnapshotDto>(json),json):JsonSerializer.SerializeToNode(payload.Deserialize<ActionPromptDto>(json),json);Check(JsonNode.DeepEquals(JsonNode.Parse(payload.GetRawText()),typed),"Every original private typed field and null/omission.");
  var visible=state;
  if(state.PendingRuleChoice is{}pending){var preview=pending.Request.Preview??throw new Exception("Original pending observation requires its separately retained preview.");Check(name=="observed"&&pending.Request.Kind=="DECK_OBSERVATION_BANISH"&&pending.Request.PlayerId==a&&preview.RuleInputs==RuleInputIdentity.Current&&preview.Seats.Keys.Order().SequenceEqual(state.Seats.Keys.Order())&&preview.CardObjects["P1_FIRST"].CardNo=="OGN·194/298"&&preview.CardObjects["P1_FIRST"].OwnerId==a,"Only the literal Nocturne observation may use its exact original intermediate preview, with actual seats and current identity.");visible=preview;}
  var stateJson=JsonSerializer.SerializeToElement(visible,json);var text=payload.GetRawText();
  foreach(var enemy in visible.Seats.Keys.Where(p=>p!=actor))foreach(var zone in new[]{"hand","mainDeck","runeDeck","standby"}){
   if(!stateJson.GetProperty("playerZones").GetProperty(enemy).TryGetProperty(zone,out var ids))continue;
   foreach(var id in ids.EnumerateArray().Where(v=>v.ValueKind==JsonValueKind.String).Select(v=>v.GetString()!))Check(!text.Contains(JsonSerializer.Serialize(id),StringComparison.Ordinal),"Independent opponent private object identity boundary from original authority.");
  }
 }
 Check(branch.GetProperty("coldRestores").GetArrayLength()==expectedCold&&branch.GetProperty("coldRestores").EnumerateArray().All(c=>c.GetProperty("wholeOriginalStateHistoryOpeningAndEmptyExact").GetBoolean()),"Literal current same-pair CI GPU cold stages, including the two original retained control-branch stages.");
 totals["commands"]+=frame.Commands.Count;totals["accepted"]+=frame.Commands.Count;totals["events"]+=frame.Events.Count;totals["authority"]+=states.Count;totals["snapshots"]+=rowCounts["snapshots"];totals["prompts"]+=rowCounts["action_prompts"];totals["pairedCiColdStages"]+=expectedCold;
 results.Add(new{branch=name,room,originalSevenTableCounts=rowCounts,allOriginalFieldsAndPrefixesExact=true,wholePrintingCertified=false});
}
Check(totals["commands"]==51&&totals["accepted"]==51&&totals["rejected"]==0&&totals["authority"]==51&&totals["originalPrefixReplays"]==51&&totals["native"]==33&&totals["pairedCiColdStages"]==26,"Literal six-branch original histories, actual native control inputs and CI pair cold-stage totals.");
await File.WriteAllTextAsync(output,JsonSerializer.Serialize(new{status="PASS_INDEPENDENT_CURRENT_SIX_FLOW_NATIVE_BRANCHES_ORIGINAL51_PREFIXES_NATIVE33_AND_CI_PAIR26_GPU_COLD_STAGES",fixedCommit="a68bfcf9684c328e999d2a57ec8c6e360528c8a9",actualReadOnlyConnection=true,actualLoadedFourAssemblies=loaded,totals,rooms=results,sourceSdkControlsAndCiGpuPairSeparatelyBound=true,osHardwarePhysicalWindowsAndWholePrintingStillOpen=true},json));
Console.WriteLine("PASS independent six remaining original Flow histories, production controls and actual CI GPU pairs.");
static JsonDocument Read(string path){var bytes=File.ReadAllBytes(path);if(path.EndsWith(".gz",StringComparison.Ordinal)){using var stream=new GZipStream(new MemoryStream(bytes),CompressionMode.Decompress);using var data=new MemoryStream();stream.CopyTo(data);bytes=data.ToArray();}return JsonDocument.Parse(bytes);}
static bool Same(JsonElement a,JsonElement b)=>JsonNode.DeepEquals(JsonNode.Parse(a.GetRawText()),JsonNode.Parse(b.GetRawText()));
static void Check(bool value,string reason){if(!value)throw new Exception(reason);}
