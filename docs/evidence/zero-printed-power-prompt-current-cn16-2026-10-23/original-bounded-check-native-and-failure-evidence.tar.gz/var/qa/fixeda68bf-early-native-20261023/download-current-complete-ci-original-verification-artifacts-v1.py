from pathlib import Path
import datetime,gzip,hashlib,json,subprocess,zipfile
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
fixed='a68bfcf9684c328e999d2a57ec8c6e360528c8a9';run_id=39844928152
sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def api(path):
 raw=subprocess.check_output(['gh','api',path],cwd=root,timeout=45);return raw,json.loads(raw)
terminal_raw,terminal=api('repos/DDDHL0704/riftbound/actions/runs/'+str(run_id))
assert terminal['head_sha']==fixed
if terminal['status']!='completed':
 print('FIXEDA68BF_CI_STILL_'+terminal['status'].upper()+'_NOT_FULL_PASS',flush=True);raise SystemExit(0)
assert terminal['conclusion']=='success',terminal['conclusion']
jobs_raw,jobs=api('repos/DDDHL0704/riftbound/actions/runs/'+str(run_id)+'/jobs?per_page=100')
art_raw,art=api('repos/DDDHL0704/riftbound/actions/runs/'+str(run_id)+'/artifacts?per_page=100')
assert jobs['total_count']==len(jobs['jobs'])==11 and all(j['status']=='completed' and j['conclusion']=='success' for j in jobs['jobs'])
names={'verification-scope','conformance-results','native-network-results','postgres-partition-0','postgres-partition-1','postgres-partition-2','postgres-partition-3','postgres-results','full-verification-gate'}
items=[a for a in art['artifacts'] if a['name'] in names];assert len(items)==9 and {a['name'] for a in items}==names
output=w/'cia68bf-complete-originals-v1';output.mkdir(exist_ok=True);assert all(p.name in {name+'.zip'for name in names}for p in output.iterdir());metadata=[]
for role,raw in [('terminal',terminal_raw),('all11-jobs',jobs_raw),('backend-artifacts',art_raw)]:
 f=w/('cia68bf-'+role+'-original-v1.json.gz');assert not f.exists();f.write_bytes(gzip.compress(raw,mtime=0));metadata.append(dict(role=role,path=str(f),rawSha256=sha(raw),compressedSha256=sha(f.read_bytes())))
receipts=[]
for a in sorted(items,key=lambda a:a['name']):
 assert not a['expired'] and a['digest'].startswith('sha256:');attempts=[];path=output/(a['name']+'.zip')
 if path.exists():
  data=path.read_bytes();assert len(data)==a['size_in_bytes']and 'sha256:'+sha(data)==a['digest']
  with zipfile.ZipFile(path)as z:assert z.testzip()is None
  receipts.append(dict(name=a['name'],id=a['id'],path=str(path),bytes=len(data),sha256=sha(data),backendDigest=a['digest'],allZipCrcVerified=True,attempts=[dict(mode='REUSED_SAME_PREFETCHED_ORIGINAL_ZIP_BACKEND_SIZE_SHA256_CRC_REVERIFIED_NO_DUPLICATE_DOWNLOAD')]))
  print('REUSED VERIFIED ORIGINAL '+a['name']+' '+str(len(data))+' bytes',flush=True);continue
 for attempt in range(1,4):
  part=output/(a['name']+'.transport-'+str(attempt)+'.part')
  with part.open('xb') as stream:r=subprocess.run(['gh','api','repos/DDDHL0704/riftbound/actions/artifacts/'+str(a['id'])+'/zip'],cwd=root,stdout=stream,stderr=subprocess.PIPE,timeout=120)
  data=part.read_bytes();valid=r.returncode==0 and len(data)==a['size_in_bytes'] and 'sha256:'+sha(data)==a['digest'];attempts.append(dict(attempt=attempt,returnCode=r.returncode,bytes=len(data),sha256=sha(data),stderrSha256=sha(r.stderr),backendSizeAndDigestMatch=valid))
  if valid:part.rename(path);break
 else:raise RuntimeError('Original artifact transport did not match backend: '+a['name'])
 with zipfile.ZipFile(path) as z:assert z.testzip() is None
 receipts.append(dict(name=a['name'],id=a['id'],path=str(path),bytes=path.stat().st_size,sha256=sha(path.read_bytes()),backendDigest=a['digest'],allZipCrcVerified=True,attempts=attempts));print('VERIFIED ORIGINAL '+a['name']+' '+str(path.stat().st_size)+' bytes',flush=True)
receipt=w/'cia68bf-all-nine-original-artifacts-receipt-v1.json';assert not receipt.exists();receipt.write_text(json.dumps(dict(status='COMPLETED_FIXEDA68BF_ALL11_SUCCESS_NINE_ORIGINAL_ZIPS_TRANSPORT_VERIFIED_SEMANTIC_READBACK_PENDING',atUtc=now(),fixedCommit=fixed,runId=run_id,metadataReceipts=metadata,jobs={j['name']:j['conclusion'] for j in jobs['jobs']},artifacts=receipts),indent=2))
print('All nine original current verification artifacts preserved; existing native installers reused, no new native copies.',flush=True)
