import ast,datetime,errno,fcntl,gzip,hashlib,json,os,plistlib,pty,re,resource,socket,subprocess,threading,time,urllib.request
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');n=Path(__file__).resolve().parent;home=n/'remaining-six-ci-main-v1';home.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486');tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
functions=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py';base_functions=root/'var/qa/fixed55fdb-early-native-20261022/lab-ci-pair-v1/controlled-lab-native-owner-functions-v1.py';control_functions=n/'flow-ci-main-v1/own-current-production-controls-and-ci-pair-v5.py'
for source,names in [(functions,{'query','rooms','digests','observe_lock'}),(base_functions,{'frozen','start_api','export','native_wait','log_count','wait_exit'}),(control_functions,{'checkpoint','save_rows','launch','stop','cold','native','local_stable'})]:
 for node in ast.parse(source.read_text()).body:
  if not isinstance(node,ast.FunctionDef)or node.name not in names:continue
  body=ast.get_source_segment(source.read_text(),node)
  if node.name=='native':
   needle=" (action_dir/'original-server-action-plan.json').write_text"
   assert body.count(needle)==1
   extra=""" if action=='PLAY_CARD'and branch=='flow-echo'and len(before['commands'])==3:
  requirement=next(r for r in candidate['metadata']['sourceRequirements']if r['sourceObjectId']=='PARENT')
  plan['optionalCostLabels']=[c['label']for c in requirement['optionalCostChoices']if c['id']=='ECHO']
  assert len(plan['optionalCostLabels'])==1
 if action=='CHOOSE_CARDS'and before['authoritativeState']['pendingCardChoice']['choiceWindow']=='INSIGHT':plan['choiceCount']=0
"""
   body=body.replace(needle,extra+needle)
  exec(compile(body,str(source),'exec'),globals())
pub=load(n/'frozen-fixeda68bf-native-composition-v1.json');api_runtime=Path(pub['apiRuntimeRoot']);helpers=Path(pub['helperRuntimeRoot'])
local_inputs=load(root/'var/qa/deck-look-draw-graveyard-current-cn16-20261022/native-actual-sql62-controls-v2/actual-native-control-terminal-v2.json');sdk=Path('/Users/dinghaolin/.local/share/riftbound-tools/godot-4.7.2/Godot_mono.app/Contents/MacOS/Godot');control_scene=n/'flow-ci-main-v1/actual-current-main-controls-v1.tscn'
driver_dll=n/'flow-ci-main-v1/gateway-preparation-source-v1/bin/Release/net10.0/Fixeda68bfLightningRushPrepareV1.dll';original_profiles=n/'ordinary-ci-pair-v1'
previous=load(n/'ordinary-ci-pair-v1/independent-current-ordinary-and-network-owner-terminal-v3.json');assert previous['status'].startswith('PASS_INDEPENDENT_CURRENT_ORDINARY88_')and previous['ownPostgresSmartStopped']and previous['all422AuditSevenTablesExact']and previous['all104NativeSevenTablesExact']
own_inputs={str(p):sha(p)for p in [Path(__file__),functions,base_functions,control_functions,control_scene,n/'flow-ci-main-v1/actual-current-main-controls-v1.gd',sdk,driver_dll,driver_dll.with_suffix('.pdb'),n/'flow-ci-main-v1/gateway-preparation-source-v1/Program.cs',n/'flow-ci-main-v1/gateway-preparation-source-v1/probe.csproj']}
def count():
 assert re.fullmatch('N47-FLOW-[0-9A-F]{10}',room)
 return int(query('riftbound_here_native',"select count(*) from command_log where match_id='"+room+"'"))
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof=dict(status='RUNNING_CURRENT_SIX_REMAINING_NATIVE_FLOW_BRANCHES',startedAtUtc=now(),fixedCommit=pub['fixedCommit'],fixedCiRun=pub['fixedCiRun'],actualRuleInputs=pub['actualRuleInputs'],ownInputHashes=own_inputs,ownedApiProcesses=[],ownedNativeProcesses=[],branches=[],lockAtStart=observe_lock(),controlledExplicitDevSeedsNotOrdinaryOpening=True,sourceNativeControlsAndCiPairGpuViewsSeparatelyBound=True,osHardwareAndPhysicalWindowsOpen=True)
api=driver=power=None;clients=[];pumps={};started=False;room=None;audit=prior_native=before_audit=before_native=None;w=profiles=evidence=None
try:
 frozen();local_stable();assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket()as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid;sock.mkdir(exist_ok=True)
 subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(home/'owned-current-six-branch-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 audit=rooms('riftbound_acceptance');prior_native=rooms('riftbound_here_native');assert audit==previous['actualAuditRoomsAtStop']and prior_native==previous['actualNativeRoomsAtStop']and len(audit)==422 and len(prior_native)==104
 before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',prior_native)
 for branch in ['flow-control','flow-echo','flow-counter','flow-return-counter','flow-empty','observed']:
  w=home/branch;w.mkdir();evidence=w/'original-native-records';evidence.mkdir();profiles=w/'original-controlled-prefix';room=None;start_api(len(proof['ownedApiProcesses'])+1)
  old_rooms=set(rooms('riftbound_here_native'));args=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(helpers/'Fixed708OriginalBandleTreeScoreV1.deps.json'),'--runtimeconfig',str(helpers/'Fixed708OriginalBandleTreeScoreV1.runtimeconfig.json'),str(driver_dll),str(profiles),str(original_profiles),branch]
  with(w/'original-explicit-gateway-preparation.log').open('xb')as output:driver=subprocess.Popen(args,cwd=helpers,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0'),stdout=output,stderr=subprocess.STDOUT);code=driver.wait(timeout=95)
  added=set(rooms('riftbound_here_native'))-old_rooms
  if len(added)==1:room=next(iter(added))
  assert code==0 and len(added)==1,'Any original partial room remains; never reset.'
  entry=load(profiles/'lightning-rush-original-entry-v1.json');assert room==entry['room'];a,b=entry['players'];first=export('initial-three-original-entries')
  assert len(first['commands'])==3 and all(c['accepted']for c in first['commands'])and[c['commandType']for c in first['commands']]==['ROOM_SEAT','ROOM_SEAT','DEV_SEED_SCENARIO:lightning-rush-'+branch]
  assert first['openingSeed']!=0 and first['replayInitialState']['status']=='EMPTY'and not first['replayInitialState']['seats']
  current=dict(branch=branch,room=room,players=[a,b],nativeCommands=[],coldRestores=[],viewportImages=[],initialOriginalRows=save_rows('initial-all-seven-original-tables.json.gz'));proof['branches'].append(current)
  frame=cold('before-parent',first);frame=native('PLAY_CARD',a,'play-parent',frame);assert frame['commands'][-1]['rawCommand']['sourceObjectId']=='PARENT'
  assert frame['commands'][-1]['rawCommand']['optionalCosts']==(['ECHO']if branch=='flow-echo'else[])
  frame=cold('original-parent-on-stack',frame)
  if branch in ['flow-control','flow-counter','flow-return-counter']:
   frame=native('PASS_PRIORITY',a,'original-parent-owner-pass',frame);frame=native('PLAY_CARD',b,'play-original-counter-or-control',frame)
   assert frame['commands'][-1]['rawCommand']['sourceObjectId']=='COUNTER'and frame['commands'][-1]['rawCommand']['targetObjectIds']==['STACK-4-PARENT']
  saw_control=False
  for step in range(20):
   state=frame['authoritativeState']
   controlled=next((s for s in state['stackItems']if s['sourceObjectId']=='PARENT'and s['controllerId']==b),None)
   if branch=='flow-control'and controlled is not None:
    assert state['cardObjects']['PARENT']['objectGeneration']==1 and controlled['flowPlay']['source']['generation']==1 and controlled['flowPlay']['ownerId']==a and state['pendingRuleChoice']is None
    if not saw_control:frame=cold('original-control-same-stack-generation-one',frame);saw_control=True;state=frame['authoritativeState']
   if state['pendingRuleChoice']is not None:
    choice=state['pendingRuleChoice'];assert choice['request']['kind']=='DECK_OBSERVATION_BANISH';frame=cold('private-observation-'+str(step),frame);frame=native('PAY_COST',choice['request']['playerId'],'observation-banish-'+str(step),frame);assert frame['commands'][-1]['rawCommand']['paymentChoiceIds']==['BANISH']
   elif state['pendingCardChoice']is not None:
    choice=state['pendingCardChoice'];assert choice['choiceWindow']in['DECK_EFFECT','INSIGHT'];frame=cold('private-card-choice-'+str(step),frame);frame=native('CHOOSE_CARDS',choice['playerId'],'original-private-choice-'+str(step),frame)
    chosen=frame['commands'][-1]['rawCommand']['chosenObjectIds'];assert len(chosen)==(0 if choice['choiceWindow']=='INSIGHT'else 1)
   elif state['pendingEffectPlay']is not None:
    pending=state['pendingEffectPlay'];assert branch=='observed';frame=cold('original-observed-card-pending-play',frame);frame=native('PLAY_CARD',pending['playerId'],'play-original-observed-card',frame);assert frame['commands'][-1]['rawCommand']['sourceObjectId']=='P1_FIRST'
   elif state['stackItems']:
    actor=state['priorityPlayerId'];assert actor in[a,b];frame=native('PASS_PRIORITY',actor,'original-stack-priority-'+str(step),frame)
   else:
    assert not state['triggerQueue'];break
  else:raise AssertionError('Original finite branch did not finish within its bounded steps.')
  state=frame['authoritativeState'];own=state['playerZones'][a];flow=branch.startswith('flow')
  assert 'PARENT'in own['banished'if flow else'graveyard']and 'PARENT'not in own['graveyard'if flow else'banished']and state['cardObjects']['PARENT']['objectGeneration']==2
  if branch in ['flow-counter','flow-return-counter']:
   assert len(own['mainDeck'])==7 and not own['hand']and not own['graveyard']and all(e['event']['kind']!='CARDS_PUT_IN_GRAVEYARD'for e in frame['events'])
  elif branch=='flow-empty':assert not own['mainDeck']and not own['hand']and not own['graveyard']
  elif branch=='flow-echo':assert len(own['hand'])==2 and len(own['graveyard'])==4 and own['mainDeck']==['P1_TAIL']
  elif branch=='flow-control':assert saw_control and len(own['mainDeck'])==7 and not own['hand']and not own['graveyard']and len(state['playerZones'][b]['hand'])==1 and len(state['playerZones'][b]['graveyard'])==3
  else:assert 'P1_FIRST'in own['base']and own['hand']==['P1_FIRST_FILLER_1']and 'P1_FIRST_FILLER_2'in own['graveyard']and 'P1_FIRST'not in own['graveyard']
  assert frame['commands'][:3]==first['commands']and frame['events'][:len(first['events'])]==first['events']and frame['openingSeed']==first['openingSeed']and frame['replayInitialState']==first['replayInitialState']and all(c['accepted']for c in frame['commands'])
  frame=cold('completed-original-branch',frame);current.update(status='PASS_CURRENT_SOURCE_NATIVE_BRANCH_AND_CI_PAIR_GPU_COLD_ORIGINAL_HISTORY_REPLAY_PENDING',commands=len(frame['commands']),events=len(frame['events']),finalOriginalRows=save_rows('final-all-seven-original-tables.json.gz'))
  api.terminate();api.wait(timeout=25);assert api.returncode==0;print('ACTUAL_CURRENT_REMAINING_NATIVE_BRANCH_PASS',branch,current['commands'],current['events'],flush=True)
 assert len(set(rooms('riftbound_here_native'))-set(prior_native))==6
 proof['status']='PASS_CURRENT_SIX_REMAINING_SOURCE_MAIN_BRANCHES_AND_CI_PAIR_GPU_COLD_INDEPENDENT_ORIGINAL_REPLAY_PENDING'
except BaseException as error:
 proof.update(status='FAILED_CURRENT_SIX_NATIVE_BRANCH_ORIGINALS_RETAINED',errorType=type(error).__name__,error=str(error));raise
finally:
 if driver is not None and driver.poll()is None:driver.terminate();driver.wait(timeout=20)
 for p,record,log in clients:
  if p.poll()is None:p.terminate();p.wait(timeout=20);record['onlyOwnFailureCleanup']=True
  pumps[p.pid].join(timeout=10);record.update(exitCode=p.returncode,logSha256=sha(log),ptyFullyDrained=not pumps[p.pid].is_alive())
 if started and room is not None:
  try:export('owner-final-retained-original-frame')
  except BaseException as error:proof['finalFrameExportError']=type(error).__name__
 if api is not None and api.poll()is None:api.terminate();api.wait(timeout=25)
 proof['ownApiStopped']=api is None or api.poll()is not None
 if started:
  if before_audit is not None:proof.update(all422AuditSevenTablesExact=digests('riftbound_acceptance',audit)==before_audit,all104PriorNativeSevenTablesExact=digests('riftbound_here_native',prior_native)==before_native,actualAuditRoomsAtStop=rooms('riftbound_acceptance'),actualNativeRoomsAtStop=rooms('riftbound_here_native'))
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None and power.poll()is None:power.terminate();power.wait(timeout=10)
 frozen();local_stable();proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),allOwnInputsStable=all(sha(Path(p))==h for p,h in own_inputs.items()))
 with(home/'current-remaining-six-native-owner-terminal-v1.json').open('x')as output:json.dump(proof,output,ensure_ascii=False,indent=2)
 fcntl.flock(guard,fcntl.LOCK_UN)
assert all(proof[k]for k in ['ownApiStopped','ownPostgresSmartStopped','all422AuditSevenTablesExact','all104PriorNativeSevenTablesExact','allOwnInputsStable'])
print(proof['status'],flush=True)
