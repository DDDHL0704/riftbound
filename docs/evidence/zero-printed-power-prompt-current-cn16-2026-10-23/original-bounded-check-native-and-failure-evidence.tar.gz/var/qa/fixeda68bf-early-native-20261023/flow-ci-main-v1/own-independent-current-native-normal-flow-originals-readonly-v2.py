from pathlib import Path
import ast,datetime,fcntl,hashlib,json,os,plistlib,resource,socket,subprocess
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486');tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
functions=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
for node in ast.parse(functions.read_text()).body:
 if isinstance(node,ast.FunctionDef) and node.name in {'query','rooms','digests','observe_lock'}:exec(compile(ast.get_source_segment(functions.read_text(),node),str(functions),'exec'),globals())
pub=load(w.parent/'frozen-fixeda68bf-native-composition-v1.json');previous=load(w/'actual-current-production-controls-and-ci-pair-owner-terminal-v5.json')
assert previous['status'].startswith('PASS_CURRENT_SOURCE_MAIN_') and previous['ownPostgresSmartStopped'] and previous['ownApiStopped'] and previous['all422AuditSevenTablesExact'] and previous['allOriginal99NativeSevenTablesExact']
r=Path(pub['apiRuntimeRoot']);frozen=pub['runtimeFiles'];own=w/'independent-original-reader-source-v2/bin/Release/net10.0/IndependentFixeda68bfFlowMainV2.dll'
own_inputs={str(p):sha(p) for p in [Path(__file__),own,own.with_suffix('.pdb'),w/'independent-original-reader-source-v2/Program.cs',w/'independent-original-reader-source-v2/probe.csproj']};assert len(frozen)==46 and all(sha(r/p)==h for p,h in frozen.items())
prefix=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(r/'Riftbound.Api.deps.json'),'--runtimeconfig',str(r/'Riftbound.Api.runtimeconfig.json'),str(own)]
measurement=json.loads(subprocess.check_output(prefix+['--loaded-inputs'],cwd=r,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0')))
assert Path(measurement['baseDirectory'])==r and measurement['actualRuleInputs']==pub['actualRuleInputs'] and len(measurement['assemblies'])==4
for a in measurement['assemblies']:assert Path(a['path'])==r/(a['name']+'.dll') and a['sha256']==frozen[a['name']+'.dll'] and a['mvid']
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof={'status':'RUNNING_INDEPENDENT_CURRENT_NORMAL_FLOW_ORIGINALS_READONLY','startedAtUtc':now(),'fixedCommit':pub['fixedCommit'],'actualLoadedFourAssemblies':measurement,'actualRuntimeFiles':frozen,'ownReaderInputs':own_inputs,'sharedFrozen46ReusedNoNewRuntimeCopy':True,'lockAtStart':observe_lock(),'actualDatabase':'riftbound_here_native','noLiveWriterOrNewMatchAction':True};started=False;power=None;audit=native=before_audit=before_native=None
terminal=w/'independent-current-native-normal-flow-originals-readonly-owner-terminal-v2.json';assert not terminal.exists()
try:
 assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid;sock.mkdir(exist_ok=True)
 subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'independent-current-normal-flow-originals-postgres-v2.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 audit=rooms('riftbound_acceptance');native=rooms('riftbound_here_native');assert audit==previous['actualAuditRoomsAtStop'] and native==previous['actualNativeRoomsAtStop'] and len(audit)==422 and len(native)==101
 before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',native)
 result=w/'independent-current-normal-flow-originals-result-v2.json';assert not result.exists();args=prefix+[str(w),str(result)];proof['actualCommand']=args
 with (w/'independent-current-normal-flow-originals-console-v2.log').open('xb') as log:code=subprocess.run(args,cwd=r,env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit',DOTNET_DbgEnableMiniDump='0'),stdout=log,stderr=subprocess.STDOUT,timeout=180).returncode
 proof['actualExitCode']=code;assert code==0;data=load(result)
 assert data['totals']==dict(commands=15,accepted=14,rejected=1,events=28,authority=14,snapshots=26,prompts=26,native=8,originalPrefixReplays=15,pairedCiColdStages=6)
 proof.update(status=data['status'],totals=data['totals'],resultSha256=sha(result))
except BaseException as error:
 proof.update(status='FAILED_INDEPENDENT_CURRENT_MAIN_ORIGINALS_READONLY_ORIGINALS_RETAINED',errorType=type(error).__name__,error=str(error));raise
finally:
 if started:
  if before_audit is not None:proof.update(all422AuditSevenTablesExact=digests('riftbound_acceptance',audit)==before_audit,all101NativeSevenTablesExact=digests('riftbound_here_native',native)==before_native,actualAuditRoomsAtStop=rooms('riftbound_acceptance'),actualNativeRoomsAtStop=rooms('riftbound_here_native'))
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None and power.poll() is None:power.terminate();power.wait(timeout=10)
 proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),all46FrozenRuntimeHashesStable=all(sha(r/p)==h for p,h in frozen.items()),allOwnReaderInputsStable=all(sha(Path(p))==h for p,h in own_inputs.items()))
 with terminal.open('x') as f:json.dump(proof,f,indent=2)
 fcntl.flock(guard,fcntl.LOCK_UN)
assert proof['all422AuditSevenTablesExact'] and proof['all101NativeSevenTablesExact'] and proof['ownPostgresSmartStopped'] and proof['all46FrozenRuntimeHashesStable'];print(proof['status'],flush=True)
