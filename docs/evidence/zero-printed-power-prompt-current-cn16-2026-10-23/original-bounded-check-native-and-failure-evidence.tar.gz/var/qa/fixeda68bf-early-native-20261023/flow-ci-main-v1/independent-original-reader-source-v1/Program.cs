using System.Security.Cryptography;
using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.CardCatalog;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

var json=new JsonSerializerOptions(JsonSerializerDefaults.Web){WriteIndented=true};
var modules=new[]{typeof(CoreRuleEngine).Assembly,typeof(CommandReceiptDto).Assembly,typeof(OfficialCardCatalog).Assembly,typeof(PostgresMatchRecoveryStore).Assembly};
var loaded=new{baseDirectory=AppContext.BaseDirectory,actualRuleInputs=RuleInputIdentity.Current,assemblies=modules.Select(a=>new{name=a.GetName().Name,path=a.Location,sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(a.Location))).ToLowerInvariant(),mvid=a.ManifestModule.ModuleVersionId}).ToArray()};
if(args is ["--loaded-inputs"]){Console.WriteLine(JsonSerializer.Serialize(loaded,json));return;}
Check(args.Length==2,"Original completed owner and one fresh result path only.");
var home=Path.GetFullPath(args[0]);var output=Path.GetFullPath(args[1]);Check(!File.Exists(output),"Never overwrite independent evidence.");
using var owner=JsonDocument.Parse(File.ReadAllText(Path.Combine(home,"actual-current-production-controls-and-ci-pair-owner-terminal-v5.json")));
var top=owner.RootElement;Check(top.GetProperty("fixedCommit").GetString()=="a68bfcf9684c328e999d2a57ec8c6e360528c8a9"&&top.GetProperty("status").GetString()!.StartsWith("PASS_CURRENT_SOURCE_MAIN_",StringComparison.Ordinal),"Exact fixed source and completed, bounded writer.");
Check(top.GetProperty("branches").GetArrayLength()==2&&Same(top.GetProperty("actualRuleInputs"),JsonSerializer.SerializeToElement(RuleInputIdentity.Current,json)),"Two original branches and actual loaded input identity.");
var settings=new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
Check(settings.Host=="127.0.0.1"&&settings.Port==55486&&settings.Database=="riftbound_here_native"&&settings.Username=="codex_riftbound_audit","Only existing own database.");settings.Options="-c default_transaction_read_only=on";
await using var source=NpgsqlDataSource.Create(settings.ConnectionString);await using var connection=await source.OpenConnectionAsync();
Check((string)(await new NpgsqlCommand("show transaction_read_only",connection).ExecuteScalarAsync())! == "on","Actual read-only setting.");
var results=new List<object>();var totals=new Dictionary<string,int>{{"commands",0},{"accepted",0},{"rejected",0},{"events",0},{"authority",0},{"snapshots",0},{"prompts",0},{"native",0},{"originalPrefixReplays",0},{"pairedCiColdStages",0}};
foreach(var branch in top.GetProperty("branches").EnumerateArray()){
 var name=branch.GetProperty("branch").GetString()!;var room=branch.GetProperty("room").GetString()!;Check(name is "normal" or "flow","Exactly the bounded normal/Flow branches.");
 var actors=branch.GetProperty("players").EnumerateArray().Select(x=>x.GetString()!).ToArray();var a=actors[0];var b=actors[1];var normal=name=="normal";
 var frame=await new PostgresMatchRecoveryStore(source).LoadAsync(room,default)??throw new Exception("Original actual SQL frame required.");
 Check(frame.IsConsistent&&frame.ValidationErrors.Count==0&&frame.Commands.Count==(normal?8:7)&&frame.Commands.Count(c=>c.Accepted)==7&&frame.Commands.All(c=>c.RuleInputs==RuleInputIdentity.Current),"Seven actual accepted commands and only the original normal-path rejected entry.");
 Check(frame.OpeningSeed!=0&&frame.ReplayInitialState is {Tick:0,Status:"EMPTY",Seats.Count:0,CardObjects.Count:0},"Original private opening seed and atomic EMPTY origin.");
 var expectedTypes=new List<string>{"ROOM_SEAT","ROOM_SEAT","DEV_SEED_SCENARIO:lightning-rush-"+name};if(normal)expectedTypes.Add("PLAY_CARD");expectedTypes.AddRange(["PLAY_CARD","PASS_PRIORITY","PASS_PRIORITY","CHOOSE_CARDS"]);
 Check(frame.Commands.Select(c=>c.CommandType).SequenceEqual(expectedTypes),"Literal original command order, including retained rejection.");
 if(normal){
  var rejection=frame.Commands[3];Check(!rejection.Accepted&&rejection.StartedTick==3&&rejection.CompletedTick==3&&rejection.StartedEventSequence==3&&rejection.CompletedEventSequence==3&&rejection.ErrorMessage=="Invalid printed power allocation."&&rejection.RawCommand!.Value.GetProperty("optionalCosts").EnumerateArray().Select(x=>x.GetString()).SequenceEqual(new[]{"PRINTED_POWER:"}),"The original malformed allocation refusal remains exact, with no game transition.");
  using var original=Read(Path.Combine(home,"normal-v3/original-native-records/owner-final-retained-original-frame.json.gz"));
  Check(Same(original.RootElement.GetProperty("commands"),JsonSerializer.SerializeToElement(frame.Commands.Take(4),json))&&original.RootElement.GetProperty("openingSeed").GetInt32()==frame.OpeningSeed&&Same(original.RootElement.GetProperty("replayInitialState"),JsonSerializer.SerializeToElement(frame.ReplayInitialState,json)),"All four original entries, initial state and private seed preserved in the resumed original room.");
 }
 using var finalRows=Read(branch.GetProperty("finalOriginalRows").GetProperty("path").GetString()!);var originalRows=finalRows.RootElement.GetProperty("originalRows");var states=new Dictionary<(long Tick,long Seq),MatchState>();var rowCounts=new Dictionary<string,int>();
 foreach(var table in new[]{"matches","match_players","command_log","game_events","state_snapshots","snapshots","action_prompts"}){
  using var query=new NpgsqlCommand($"select coalesce(json_agg(t order by row_to_json(t)::text),'[]'::json)::text from (select * from {table} where match_id=@room)t",connection);query.Parameters.AddWithValue("room",room);
  using var actual=JsonDocument.Parse((string)(await query.ExecuteScalarAsync())!);Check(Same(actual.RootElement,originalRows.GetProperty(table)),"Every original SQL field, null, omission and value: "+table);rowCounts[table]=actual.RootElement.GetArrayLength();
  if(table=="state_snapshots")foreach(var row in actual.RootElement.EnumerateArray()){
   var payload=row.GetProperty("payload");var state=payload.Deserialize<MatchState>(json)!;Check(Same(payload,JsonSerializer.SerializeToElement(state,json))&&state.RuleInputs==RuleInputIdentity.Current,"All typed original authority fields and input identity.");
   Check(states.TryAdd((state.Tick,row.GetProperty("last_event_sequence").GetInt64()),state),"Each original authority checkpoint is unique.");
  }
 }
 Check(states.Count==7&&frame.Commands.All(c=>states.ContainsKey((c.CompletedTick,c.CompletedEventSequence))),"Rejected input reuses its unchanged original authority; all accepted inputs have their own rows.");
 foreach(var command in frame.Commands){
  var state=states[(command.CompletedTick,command.CompletedEventSequence)];var prefix=frame.Commands.TakeWhile(c=>c!=command).Append(command).ToArray();var events=frame.Events.Where(e=>e.Sequence<=command.CompletedEventSequence).ToArray();
  var replay=await MatchActionLogReplayer.VerifyFinalStateAsync(frame.ReplayInitialState!,prefix,state,new CoreRuleEngine(),default,events);Check(replay.IsMatch,"Every entire original prefix, including the actual refusal, replays: "+string.Join(";",replay.Errors));totals["originalPrefixReplays"]++;
 }
 var final=frame.AuthoritativeState!;var own=final.PlayerZones[a];Check(final.Tick==7&&final.StackItems.Count==0&&final.PendingCardChoice is null&&own.Hand.SequenceEqual(new[]{"P1_FIRST"})&&own.MainDeck.SequenceEqual(new[]{"P1_SECOND","P1_SECOND_FILLER_1","P1_SECOND_FILLER_2","P1_TAIL"}),"Actual selected first card and exact remaining deck after one completed three-card look.");
 Check(own.Graveyard.Contains("P1_FIRST_FILLER_1")&&own.Graveyard.Contains("P1_FIRST_FILLER_2")&&own.Graveyard.Count==(normal?3:2)&&(normal?own.Graveyard:own.Banished).Contains("PARENT")&&!(normal?own.Banished:own.Graveyard).Contains("PARENT")&&final.CardObjects["PARENT"].ObjectGeneration==2,"Unselected cards directly enter graveyard and the same physical parent makes exactly one final owner-correct transition.");
 Check(frame.Events.All(e=>e.Event.Kind is not("CARD_DISCARDED"or"CARDS_RECYCLED"or"UNIT_DESTROYED")),"Direct graveyard flow never becomes discard, recycle or destruction.");
 var native=branch.GetProperty("nativeCommands");Check(native.GetArrayLength()==4,"All four actual source-bound production-control submissions.");
 foreach(var entry in native.EnumerateArray()){
  var index=entry.GetProperty("index").GetInt32();var command=frame.Commands[index];Check(index>=(normal?4:3)&&Same(entry.GetProperty("completeOriginalCommand"),JsonSerializer.SerializeToElement(command,json))&&command.Accepted,"Every actual native accepted intent is exactly its separate original SQL entry.");
  var prior=states[(command.StartedTick,command.StartedEventSequence)];Check(command.RawCommand!.Value.GetProperty("snapshotTick").GetInt64()==prior.Tick,"Literal original native prior tick.");
  if(command.CommandType=="PASS_PRIORITY")Check(command.PlayerId==prior.PriorityPlayerId,"Actual original priority owner.");
  if(command.CommandType=="PLAY_CARD"){
   Check(command.RawCommand!.Value.GetProperty("sourceObjectId").GetString()=="PARENT"&&command.RawCommand.Value.GetProperty("cardNo").GetString()=="VEN·156"&&command.RawCommand.Value.GetProperty("optionalCosts").GetArrayLength()==0,"Actual composer does not submit malformed or synthetic payment choices.");
   var after=states[(command.CompletedTick,command.CompletedEventSequence)];Check(after.RunePools[a].Mana==(normal?29:28)&&after.RunePools[a].Power==(normal?30:29)&&after.StackItems.Single().FlowPlay is null==normal,"Actual server payment and Flow origin differ from the printed cost as required.");
  }
  var prompts=originalRows.GetProperty("action_prompts").EnumerateArray().Where(r=>r.GetProperty("player_id").GetString()==command.PlayerId&&r.GetProperty("prompt_tick").GetInt64()==command.StartedTick&&r.GetProperty("last_event_sequence").GetInt64()==command.StartedEventSequence).ToArray();
  Check(prompts.Length==1&&prompts[0].GetProperty("payload").GetProperty("promptId").GetString()==command.RawCommand!.Value.GetProperty("promptId").GetString(),"Every submitted intent stamps the independently retained private original prompt.");totals["native"]++;
 }
 foreach(var table in new[]{"snapshots","action_prompts"})foreach(var row in originalRows.GetProperty(table).EnumerateArray()){
  var actor=row.GetProperty("player_id").GetString()!;var payload=row.GetProperty("payload");var tick=row.GetProperty(table=="snapshots"?"snapshot_tick":"prompt_tick").GetInt64();var seq=row.GetProperty("last_event_sequence").GetInt64();var state=states[(tick,seq)];Check(state.Seats.ContainsKey(actor),"Actual historical viewer seat.");
  var typed=table=="snapshots"?JsonSerializer.SerializeToNode(payload.Deserialize<SnapshotDto>(json),json):JsonSerializer.SerializeToNode(payload.Deserialize<ActionPromptDto>(json),json);Check(JsonNode.DeepEquals(JsonNode.Parse(payload.GetRawText()),typed),"Every original private typed field and null/omission.");
  Check(state.PendingRuleChoice is null,"No unrelated intermediate preview exemption in these two original branches.");var stateJson=JsonSerializer.SerializeToElement(state,json);var text=payload.GetRawText();
  foreach(var enemy in state.Seats.Keys.Where(p=>p!=actor))foreach(var zone in new[]{"hand","mainDeck","runeDeck","standby"}){
   if(!stateJson.GetProperty("playerZones").GetProperty(enemy).TryGetProperty(zone,out var ids))continue;
   foreach(var id in ids.EnumerateArray().Where(v=>v.ValueKind==JsonValueKind.String).Select(v=>v.GetString()!))Check(!text.Contains(JsonSerializer.Serialize(id),StringComparison.Ordinal),"Independent opponent private object identity boundary from original authority.");
  }
 }
 Check(branch.GetProperty("coldRestores").GetArrayLength()==3&&branch.GetProperty("coldRestores").EnumerateArray().All(c=>c.GetProperty("wholeOriginalStateHistoryOpeningAndEmptyExact").GetBoolean()),"Three actual CI pair GPU cold restores for each branch.");
 totals["commands"]+=frame.Commands.Count;totals["accepted"]+=frame.Commands.Count(c=>c.Accepted);totals["rejected"]+=frame.Commands.Count(c=>!c.Accepted);totals["events"]+=frame.Events.Count;totals["authority"]+=states.Count;totals["snapshots"]+=rowCounts["snapshots"];totals["prompts"]+=rowCounts["action_prompts"];totals["pairedCiColdStages"]+=3;
 results.Add(new{branch=name,room,originalSevenTableCounts=rowCounts,originalSeed=frame.OpeningSeed,allOriginalFieldsAndPrefixesPreserved=true,wholePrintingCertified=false});
}
Check(totals["commands"]==15&&totals["accepted"]==14&&totals["rejected"]==1&&totals["authority"]==14&&totals["originalPrefixReplays"]==15&&totals["native"]==8&&totals["pairedCiColdStages"]==6,"Literal bounded current original histories, actual native inputs and CI cold stages.");
await File.WriteAllTextAsync(output,JsonSerializer.Serialize(new{status="PASS_INDEPENDENT_CURRENT_FIXED_NORMAL_FLOW_ORIGINAL15_PREFIXES_ONE_REJECTION_EIGHT_SOURCE_BOUND_NATIVE_CONTROLS_SIX_CI_PAIR_GPU_COLD_STAGES",fixedCommit="a68bfcf9684c328e999d2a57ec8c6e360528c8a9",actualReadOnlyConnection=true,actualLoadedFourAssemblies=loaded,totals,rooms=results,localSdkProductionControlsAndCiPairViewsSeparatelyBound=true,osHardwarePhysicalWindowsAndWholePrintingStillOpen=true},json));
Console.WriteLine("PASS independent current original normal/Flow histories, refusal, production controls and CI-pair cold stages.");
static JsonDocument Read(string path){var bytes=File.ReadAllBytes(path);if(path.EndsWith(".gz",StringComparison.Ordinal)){using var stream=new GZipStream(new MemoryStream(bytes),CompressionMode.Decompress);using var data=new MemoryStream();stream.CopyTo(data);bytes=data.ToArray();}return JsonDocument.Parse(bytes);}
static bool Same(JsonElement a,JsonElement b)=>JsonNode.DeepEquals(JsonNode.Parse(a.GetRawText()),JsonNode.Parse(b.GetRawText()));
static void Check(bool value,string reason){if(!value)throw new Exception(reason);}
