extends Node
func _ready() -> void:
	var actual: Node = get_node("Main")
	await get_tree().create_timer(2.0).timeout
	print("ACTUAL_CI_MAIN_EXTERNAL_CONTROL_BOOT ",actual.get_script().resource_path," ",DisplayServer.get_name())
	actual.queue_free()
	await get_tree().process_frame
	get_tree().quit(0)
