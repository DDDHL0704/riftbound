import ast,datetime,errno,fcntl,gzip,hashlib,json,os,plistlib,pty,re,resource,socket,subprocess,threading,time,urllib.request
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');home=Path(__file__).resolve().parent
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
functions=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
native_functions=root/'var/qa/fixed55fdb-early-native-20261022/lab-ci-pair-v1/controlled-lab-native-owner-functions-v1.py'
for source,names in [(functions,{'query','rooms','digests','observe_lock'}),(native_functions,{'frozen','start_api','export','native_wait','log_count','wait_exit'})]:
 for node in ast.parse(source.read_text()).body:
  if isinstance(node,ast.FunctionDef) and node.name in names:
   body=ast.get_source_segment(source.read_text(),node).replace('live-controlled-lab-api-','live-current-a68bf-flow-api-')
   exec(compile(body,str(source),'exec'),globals())
pub=load(home.parent/'frozen-fixeda68bf-native-composition-v1.json');api_runtime=Path(pub['apiRuntimeRoot']);helpers=Path(pub['helperRuntimeRoot'])
assert pub['fixedCommit']=='a68bfcf9684c328e999d2a57ec8c6e360528c8a9' and pub['actualRuleInputs']['identitySha256']=='3b842ce10486d75ca9bf14f5844b5d787241ed050ccba05952abfed256c41dcd'
driver_dll=home/'gateway-preparation-source-v1/bin/Release/net10.0/Fixeda68bfLightningRushPrepareV1.dll'
original_profiles=root/'var/qa/fixed5edb1-early-native-20261023/ordinary-ci-pair-v1'
own_inputs={str(p):sha(p) for p in [Path(__file__),functions,native_functions,driver_dll,driver_dll.with_suffix('.pdb'),home/'gateway-preparation-source-v1/Program.cs',home/'gateway-preparation-source-v1/probe.csproj']}
terminal=home/'actual-current-production-controls-and-ci-pair-owner-terminal-v5.json';assert not terminal.exists()
local_inputs=load(root/'var/qa/deck-look-draw-graveyard-current-cn16-20261022/native-actual-sql62-controls-v2/actual-native-control-terminal-v2.json')
sdk=Path('/Users/dinghaolin/.local/share/riftbound-tools/godot-4.7.2/Godot_mono.app/Contents/MacOS/Godot')
control_source=home/'actual-current-main-controls-v1.gd';control_scene=home/'actual-current-main-controls-v1.tscn'
own_inputs.update({str(p):sha(p)for p in [home/'own-current-ci-native-normal-and-flow-v3.py',control_source,control_scene,sdk]})
previous=load(home/'actual-locked-current-ci-main-normal-flow-owner-terminal-v3.json');resume_room=previous['branches'][0]['room']
original_prefix_path=home/'normal-v3/original-native-records/owner-final-retained-original-frame.json.gz';original_prefix=json.loads(gzip.decompress(original_prefix_path.read_bytes()))
assert len(original_prefix['commands'])==4 and not original_prefix['commands'][-1]['accepted'] and original_prefix['authoritativeState']['tick']==3
own_inputs[str(original_prefix_path)]=sha(original_prefix_path)
def local_stable():
 assert all(sha(root/p)==h for p,h in local_inputs['sourceHashes'].items())
 assert all(sha(root/'clients/godot/.godot/mono/temp/bin/Debug'/p)==h for p,h in local_inputs['nativeManagedRuntimeFiles'].items())
local_stable()

def checkpoint(name,value):
 with(evidence/name).open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2)
def count():
 assert room is not None and re.fullmatch('N47-FLOW-[0-9A-F]{10}',room)
 return int(query('riftbound_here_native',"select count(*) from command_log where match_id='"+room+"'"))
def save_rows(name):
 data={t:json.loads(query('riftbound_here_native',f"select coalesce(json_agg(t order by row_to_json(t)::text),'[]'::json)::text from(select * from {t} where match_id='{room}')t")) for t in tables}
 p=evidence/name;assert not p.exists();p.write_bytes(gzip.compress(json.dumps({'room':room,'originalRows':data},ensure_ascii=False,indent=2).encode(),mtime=0));return dict(path=str(p),sha256=sha(p),counts={t:len(v)for t,v in data.items()})
def launch(role,label,action=None,capture=False):
 app=Path(next(a['app']for a in pub['nativeApps']if a['label']==role));subprocess.run(['codesign','--verify','--deep','--strict',str(app)],check=True,capture_output=True)
 log=w/(label+'-original-native-console.log');png=w/(label+'-actual-own-viewport.png')
 args=[str(app/'Contents/MacOS/符文战场'),'--resolution','1280x720','--max-fps','30','--quit-after','3000','--','--riftbound-server=http://127.0.0.1:15847','--riftbound-session-file='+str(profiles/('session-'+role+'.json')),'--riftbound-smoke-connect-only']
 if action:args+=['--riftbound-smoke-ui-action='+action,'--riftbound-smoke-ui-submit']
 if capture:args+=['--riftbound-visual-screenshot='+str(png),'--riftbound-visual-screenshot-min-table-cards=0']
 env=dict(os.environ,DOTNET_DbgEnableMiniDump='0');env.pop('DOTNET_STARTUP_HOOKS',None)
 master,slave=pty.openpty();sink=log.open('xb',buffering=0)
 p=subprocess.Popen(args,cwd='/tmp',env=env,stdin=subprocess.DEVNULL,stdout=slave,stderr=slave,start_new_session=True);os.close(slave)
 def drain():
  try:
   while True:
    try:block=os.read(master,65536)
    except OSError as error:
     if error.errno==errno.EIO:break
     raise
    if not block:break
    sink.write(block)
  finally:os.close(master);sink.close()
 pump=threading.Thread(target=drain,daemon=True);pumps[p.pid]=pump;pump.start()
 record=dict(role=role,label=label,pid=p.pid,actualCommand=args,log=log.name,action=action,nonHeadless=True,ownViewportNotOsDesktopOrHardwareInput=True,all373CiPayloadsAndSignatureVerified=True)
 proof['ownedNativeProcesses'].append(record);item=(p,record,log);clients.append(item)
 if capture:current['viewportImages'].append(dict(role=role,stage=label,path=str(png)))
 return item
def stop(item):
 p,record,log=item;p.terminate();wait_exit(item,20)
 assert 'Termination requested; exiting through Godot.'in log.read_text(errors='replace')
def cold(stage,before):
 pair=[launch(role,stage+'-'+role,capture=True)for role in ['a','b']]
 native_wait(lambda:all(all(log_count(t[2],k)>=1 for k in ['Joined','Snapshot','Prompt'])for t in pair),'Both actual current Main initial private views',45,[t[0]for t in pair])
 native_wait(lambda:all((w/(stage+'-'+r+'-actual-own-viewport.png')).exists() and 'Visual screenshot saved:'in t[2].read_text(errors='replace')for r,t in zip(['a','b'],pair)),'Both actual GPU own viewports',45,[t[0]for t in pair])
 counts=[{k:log_count(t[2],k)for k in ['Joined','Snapshot','Prompt']}for t in pair];pid=api.pid
 assert set(subprocess.check_output(['/usr/sbin/lsof','-tiTCP:15847','-sTCP:LISTEN'],text=True).splitlines())=={str(pid)}
 api.kill();api.wait(timeout=10);assert api.returncode==-9;start_api(len(proof['ownedApiProcesses'])+1)
 native_wait(lambda:all(all(log_count(t[2],k)>counts[i][k]for k in counts[i])for i,t in enumerate(pair)),'Same current nonheadless pair recovers original stage',50,[t[0]for t in pair])
 after=export(stage+'-after-same-pair-cold-original-frame')
 assert all(after[k]==before[k]for k in ['commands','events','authoritativeState','openingSeed','replayInitialState'])
 for t in pair:stop(t)
 for row in current['viewportImages']:
  if row['stage'].startswith(stage+'-'):
   p=Path(row['path']);assert p.read_bytes().startswith(b'\x89PNG\r\n\x1a\n');row.update(sha256=sha(p),bytes=p.stat().st_size,actualPixelsNeedSeparateVisualRead=True)
 current['coldRestores'].append(dict(stage=stage,killedOwnApiPid=pid,sameNativePids=[t[0].pid for t in pair],wholeOriginalStateHistoryOpeningAndEmptyExact=True,lock=observe_lock()))
 print('CURRENT_NONHEADLESS_PAIRED_COLD',branch,stage,flush=True);return after
def native(action,actor,label,before):
 old=len(before['commands']);role='a'if actor==a else'b';action_dir=w/(label+'-actual-production-controls');action_dir.mkdir()
 candidate=next(c for c in before['playerViews'][actor]['prompt']['candidates']if c['action']==action and c['enabled'])
 action_label='不响应 · 让过'if action=='PASS_PRIORITY'else candidate['label']
 plan=dict(fixedCommit=pub['fixedCommit'],room=room,action=action,actionLabel=action_label,originalActor=actor,originalPromptId=before['playerViews'][actor]['prompt']['promptId'],originalSnapshotTick=before['authoritativeState']['tick'],choiceCount=1,optionalCostLabels=[])
 (action_dir/'original-server-action-plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2))
 local_stable();args=[str(sdk),'--path',str(root/'clients/godot'),'--resolution','1280x720','--max-fps','30','--quit-after','3000',str(control_scene),'--','--riftbound-server=http://127.0.0.1:15847','--riftbound-session-file='+str(profiles/('session-'+role+'.json')),'--riftbound-smoke-connect-only','--qa-action-folder='+str(action_dir)]
 log=action_dir/'actual-production-main-original-console.log';master,slave=pty.openpty();sink=log.open('xb',buffering=0);env=dict(os.environ,DOTNET_DbgEnableMiniDump='0');env.pop('DOTNET_STARTUP_HOOKS',None)
 p=subprocess.Popen(args,cwd='/tmp',env=env,stdin=subprocess.DEVNULL,stdout=slave,stderr=slave,start_new_session=True);os.close(slave)
 def drain():
  try:
   while True:
    try:block=os.read(master,65536)
    except OSError as error:
     if error.errno==errno.EIO:break
     raise
    if not block:break
    sink.write(block)
  finally:os.close(master);sink.close()
 pump=threading.Thread(target=drain,daemon=True);pumps[p.pid]=pump;pump.start()
 record=dict(role=role,label=label,pid=p.pid,actualCommand=args,log=str(log),action=action,nonHeadless=True,localSingleExistingSdkExact3373SourcesAnd23DebugPayloads=True,ciExportedEntryNotClaimed=True,actualProductionButtonsNotOsHardware=True)
 proof['ownedNativeProcesses'].append(record);item=(p,record,log);clients.append(item)
 native_wait(lambda:count()==old+1,'Exactly one original production control request '+action,55,[p])
 after=export(label+'-after-native-original-frame');command=after['commands'][-1]
 assert command['accepted'], 'Original actual native request was rejected: '+str(command.get('errorMessage'))
 native_wait(lambda:(action_dir/'actual-production-buttons-submitted.json').exists() and log_count(log,'Snapshot')>=2 and log_count(log,'Prompt')>=2,'Actual native submission and fresh views',25,[p])
 (action_dir/'actual-owner-post-command-views-verified.json').write_text(json.dumps(dict(originalCommandIndex=old,originalCompletedTick=command['completedTick'],frameConsistent=True)))
 wait_exit(item,15);local_stable()
 terminal=load(action_dir/'actual-production-main-controls-terminal.json');assert terminal['productionMainScript']=='res://scripts/Main.cs' and terminal['displayDriver']!='headless'
 assert after['commands'][:old]==before['commands'] and after['events'][:len(before['events'])]==before['events']
 raw=command['rawCommand'];assert command['playerId']==actor and command['commandType']==raw['cmdType']==action and raw['snapshotTick']==before['authoritativeState']['tick'] and raw['promptId']
 current['nativeCommands'].append(dict(index=old,action=action,actor=actor,completeOriginalCommand=command,productionButtonSignals=terminal['buttonSignals'],originalConsole=str(log),originalConsoleSha256=sha(log),localSdkAndCiPairEvidenceSeparatelyBound=True))
 print('ACTUAL_PRODUCTION_MAIN_CONTROL_ACCEPTED',branch,old,action,flush=True);return after
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof=dict(status='RUNNING_CURRENT_FIXED_NATIVE_NORMAL_AND_FLOW_ACTUAL_NONHEADLESS_MAIN',startedAtUtc=now(),fixedCommit=pub['fixedCommit'],fixedCiRun=pub['fixedCiRun'],actualRuleInputs=pub['actualRuleInputs'],ownInputHashes=own_inputs,ownedApiProcesses=[],ownedNativeProcesses=[],branches=[],lockAtStart=observe_lock(),controlledDevPositionsNotOrdinaryOpening=True,doesNotCertifyOsHardwareOrPhysicalWindows=True,oneLiveProcessPerActor=True)
api=driver=power=None;clients=[];pumps={};started=False;room=None;audit=prior_native=before_audit=before_native=None;w=profiles=evidence=None
try:
 frozen();assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket()as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid;sock.mkdir(exist_ok=True)
 subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(home/'owned-current-flow-postgres-v5.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 audit=rooms('riftbound_acceptance');prior_native=rooms('riftbound_here_native');assert len(audit)==422 and len(prior_native)==100 and resume_room in prior_native
 before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',[r for r in prior_native if r!=resume_room])
 for branch in ['normal','flow']:
  w=home/(branch+'-actual-controls-v5');w.mkdir();evidence=w/'original-native-records';evidence.mkdir();profiles=w/'original-controlled-prefix';room=None;start_api(len(proof['ownedApiProcesses'])+1)
  if branch=='normal':
   room=resume_room;profiles.mkdir()
   for role in ['a','b']:(profiles/('session-'+role+'.json')).write_bytes((home/'normal-v3/original-controlled-prefix'/('session-'+role+'.json')).read_bytes())
   entry=load(home/'normal-v3/original-controlled-prefix/lightning-rush-original-entry-v1.json');a,b=entry['players'];first=export('initial-same-four-original-prefix-with-rejection-retained')
   assert all(first[k]==original_prefix[k]for k in ['commands','events','authoritativeState','openingSeed','replayInitialState'])
  else:
   old_rooms=set(rooms('riftbound_here_native'));args=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(helpers/'Fixed708OriginalBandleTreeScoreV1.deps.json'),'--runtimeconfig',str(helpers/'Fixed708OriginalBandleTreeScoreV1.runtimeconfig.json'),str(driver_dll),str(profiles),str(original_profiles),branch]
   with(w/'original-explicit-gateway-preparation.log').open('xb')as f:driver=subprocess.Popen(args,cwd=helpers,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0'));code=driver.wait(timeout=95)
   added=set(rooms('riftbound_here_native'))-old_rooms
   if len(added)==1:room=next(iter(added))
   assert code==0 and len(added)==1,'Any partial original room is retained, never reset.'
   entry=load(profiles/'lightning-rush-original-entry-v1.json');assert entry['room']==room;a,b=entry['players'];first=export('initial-three-original-frame')
   assert len(first['commands'])==3 and[c['commandType']for c in first['commands']]==['ROOM_SEAT','ROOM_SEAT','DEV_SEED_SCENARIO:lightning-rush-'+branch]
  assert first['openingSeed']!=0 and first['replayInitialState']['status']=='EMPTY' and not first['replayInitialState']['seats']
  current=dict(branch=branch,room=room,players=[a,b],coldRestores=[],nativeCommands=[],viewportImages=[],initialOriginalRows=save_rows('initial-all-seven-original-tables.json.gz'));proof['branches'].append(current)
  frame=cold('before-parent',first);frame=native('PLAY_CARD',a,'play-parent',frame)
  assert frame['commands'][-1]['rawCommand']['sourceObjectId']=='PARENT'
  for i in range(2):frame=native('PASS_PRIORITY',frame['authoritativeState']['priorityPlayerId'],'parent-pass-'+str(i),frame)
  assert frame['authoritativeState']['pendingCardChoice']['playerId']==a
  frame=cold('private-draw-choice',frame);frame=native('CHOOSE_CARDS',a,'choose-original-card',frame)
  state=frame['authoritativeState'];own=state['playerZones'][a];chosen=frame['commands'][-1]['rawCommand']['chosenObjectIds'];assert len(chosen)==1 and chosen[0]in own['hand']
  assert len(frame['commands'])==(8 if branch=='normal'else 7) and not state['stackItems']and state['pendingCardChoice']is None and len(own['mainDeck'])==4
  assert 'PARENT'in own['banished'if branch=='flow'else'graveyard']and 'PARENT'not in own['graveyard'if branch=='flow'else'banished']and state['cardObjects']['PARENT']['objectGeneration']==2
  assert len(own['graveyard'])==(2 if branch=='flow'else 3)
  frame=cold('completed-original-spell',frame)
  current.update(status='PASS_ACTUAL_CURRENT_NONHEADLESS_MAIN_NORMAL_OR_FLOW_WITH_THREE_PAIRED_COLD_STAGES_VISUAL_READ_AND_INDEPENDENT_REPLAY_PENDING',commands=len(frame['commands']),acceptedCommands=sum(c['accepted']for c in frame['commands']),rejectedCommands=sum(not c['accepted']for c in frame['commands']),events=len(frame['events']),finalOriginalRows=save_rows('final-all-seven-original-tables.json.gz'))
  api.terminate();api.wait(timeout=25);assert api.returncode==0
 assert len(set(rooms('riftbound_here_native'))-set(prior_native))==1
 proof['status']='PASS_CURRENT_SOURCE_MAIN_EIGHT_ACTUAL_PRODUCTION_CONTROL_INPUTS_AND_CURRENT_CI_PAIR_SIX_GPU_COLD_STAGES_ORIGINAL_REJECTION_RETAINED_INDEPENDENT_READBACK_PENDING'
except BaseException as error:
 proof.update(status='FAILED_CURRENT_MAIN_ORIGINALS_AND_NATIVE_LOGS_RETAINED',errorType=type(error).__name__,error=str(error));raise
finally:
 if driver is not None and driver.poll()is None:driver.terminate();driver.wait(timeout=20)
 for p,record,log in clients:
  if p.poll()is None:p.terminate();p.wait(timeout=20);record['onlyOwnFailureCleanup']=True
  pumps[p.pid].join(timeout=10);record.update(exitCode=p.returncode,logSha256=sha(log),ptyFullyDrained=not pumps[p.pid].is_alive())
 if started and room is not None:
  try:export('owner-final-retained-original-frame')
  except BaseException as error:proof['finalFrameExportError']=type(error).__name__
 if api is not None and api.poll()is None:api.terminate();api.wait(timeout=25)
 proof['ownApiStopped']=api is None or api.poll()is not None
 if started:
  if before_audit is not None:proof.update(all422AuditSevenTablesExact=digests('riftbound_acceptance',audit)==before_audit,allOriginal99NativeSevenTablesExact=digests('riftbound_here_native',[r for r in prior_native if r!=resume_room])==before_native,actualAuditRoomsAtStop=rooms('riftbound_acceptance'),actualNativeRoomsAtStop=rooms('riftbound_here_native'))
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None and power.poll()is None:power.terminate();power.wait(timeout=10)
 proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),allOwnInputsStable=all(sha(Path(p))==h for p,h in own_inputs.items()),local3373SourceInputs=local_inputs['sourceHashes'],local23NativeRuntimeInputs=local_inputs['nativeManagedRuntimeFiles'],localControlRouteNotCiExportOrHardware=True);frozen();local_stable()
 with terminal.open('x')as f:json.dump(proof,f,ensure_ascii=False,indent=2)
 fcntl.flock(guard,fcntl.LOCK_UN)
assert all(proof[k]for k in ['ownApiStopped','ownPostgresSmartStopped','all422AuditSevenTablesExact','allOriginal99NativeSevenTablesExact','allOwnInputsStable'])
print(proof['status'],flush=True)
