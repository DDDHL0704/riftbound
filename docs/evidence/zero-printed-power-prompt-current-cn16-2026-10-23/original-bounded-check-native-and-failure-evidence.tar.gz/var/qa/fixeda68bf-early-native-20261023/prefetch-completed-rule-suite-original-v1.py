from pathlib import Path
import datetime,gzip,hashlib,json,subprocess,zipfile
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;fixed='a68bfcf9684c328e999d2a57ec8c6e360528c8a9';run=39844928152;sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def get(s):
 raw=subprocess.check_output(['gh','api',s],cwd=root,timeout=45);return raw,json.loads(raw)
run_raw,r=get('repos/DDDHL0704/riftbound/actions/runs/'+str(run));assert r['head_sha']==fixed
jobs_raw,j=get('repos/DDDHL0704/riftbound/actions/runs/'+str(run)+'/jobs?per_page=100');job=next(a for a in j['jobs']if a['name']=='rule_suite');assert job['status']=='completed'and job['conclusion']=='success'
art_raw,a=get('repos/DDDHL0704/riftbound/actions/runs/'+str(run)+'/artifacts?per_page=100');artifact=next(v for v in a['artifacts']if v['name']=='conformance-results');assert not artifact['expired']and artifact['digest'].startswith('sha256:')
folder=w/'cia68bf-complete-originals-v1';folder.mkdir(exist_ok=False);out=folder/'conformance-results.zip';part=folder/'conformance-results.prefetch-original.part'
with part.open('xb')as stream:p=subprocess.run(['gh','api','repos/DDDHL0704/riftbound/actions/artifacts/'+str(artifact['id'])+'/zip'],cwd=root,stdout=stream,stderr=subprocess.PIPE,timeout=120)
raw=part.read_bytes();assert p.returncode==0 and len(raw)==artifact['size_in_bytes']and 'sha256:'+sha(raw)==artifact['digest'];part.rename(out)
with zipfile.ZipFile(out)as z:assert z.testzip()is None
meta=[]
for role,raw in [('run-observation',run_raw),('jobs-observation',jobs_raw),('artifacts-observation',art_raw)]:
 path=w/('cia68bf-prefetch-'+role+'-original-v1.json.gz');assert not path.exists();path.write_bytes(gzip.compress(raw,mtime=0));meta.append(dict(path=str(path.relative_to(root)),sha256=sha(path.read_bytes()),originalSha256=sha(raw)))
receipt=w/'cia68bf-prefetched-completed-conformance-original-v1.json';assert not receipt.exists();receipt.write_text(json.dumps(dict(atUtc=now(),status='COMPLETED_RULE_SUITE_ORIGINAL_ZIP_TRANSPORT_VERIFIED_ENTIRE_CI_NOT_YET_CERTIFIED',fixedCommit=fixed,runId=run,observedEntireRunStatus=r['status'],observedEntireRunConclusion=r['conclusion'],artifact=dict(name=artifact['name'],id=artifact['id'],path=str(out),bytes=out.stat().st_size,sha256=sha(out.read_bytes()),backendDigest=artifact['digest'],allZipCrcVerified=True),metadata=meta,doesNotClaimWholeCiSuccess=True),indent=2)+'\n');print('VERIFIED_ONE_ORIGINAL_COMPLETED_CONFORMANCE_ZIP_NO_FULL_CI_PROMOTION',out.stat().st_size,flush=True)
