from pathlib import Path
import ast, collections, datetime, gzip, hashlib, json, re, subprocess, xml.etree.ElementTree as ET

w = Path(__file__).resolve().parent
root = w.parents[2]
load = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
owner = load(w / 'only-check-owner-terminal-v1.json')
start = load(w / 'only-check-start-inputs-v1.json')
summary = load(w / 'only-check-v1/summary.json')
plan = load(w / 'only-check-v1/plan.json')
assert owner['exitCode'] == 0 and owner['status'] == 'CHECK_PROCESS_EXIT_ZERO_INDEPENDENT_PARITY_STILL_REQUIRED'
for field in ['all3319SourceHashesUnchanged', 'allSourceModesUnchanged', 'allConformanceInputPayloadsUnchanged', 'all23NativePayloadsUnchanged', 'boundIdleAssertionEnded']: assert owner[field], field
assert summary['status'] == 'PASSED' and summary['total'] == 13219 and plan['discoveredMethods'] == 7642
assert sum(len(s['methods']) for s in plan['shards']) == 7501
def read(path):
    tree = ET.parse(path)
    definitions = {d.attrib['id']: d.find('t:TestMethod', ns).attrib for d in tree.findall('.//t:UnitTest', ns)}
    cases = collections.Counter()
    methods = set()
    for r in tree.findall('.//t:UnitTestResult', ns):
        assert r.attrib['outcome'] == 'Passed'
        d = definitions[r.attrib['testId']]
        cases[r.attrib['testName']] += 1
        methods.add(d['className'] + '.' + d['name'])
    return cases, methods
baseline = root / start['originalBaselineTrx']
current = w / 'only-check-v1/check/results.trx'
before_cases, before_methods = read(baseline)
cases, methods = read(current)
assert before_cases == cases and before_methods == methods
assert sum(cases.values()) == 13219 and len(methods) == 7501
assert methods == {m for shard in plan['shards'] for m in shard['methods']}
fixed = load(w / 'fixed-clean-api-runtime-source-and-identity-v1.json')
sources = start['sourceInputHashes']
changed = {p for p, h in fixed['sourceInputHashes'].items() if sources[p] != h}
assert changed == {'tests/Riftbound.PostgresAcceptance/Program.cs','tests/Riftbound.PostgresAcceptance/CandlelitPrivateLookSqlAcceptance.cs'}
assert set(sources) == set(fixed['sourceInputHashes'])
assert len(sources) == 3319 and all(sha(root / p) == h for p, h in sources.items())
assert all(oct((root / p).stat().st_mode & 0o777) == m for p, m in start['sourceInputModes'].items())
conformance = {p: h for p, h in fixed['sourceInputHashes'].items() if p.startswith('tests/Riftbound.ConformanceTests/')}
assert all(sources[p] == h for p, h in conformance.items())
full = {p: h for p, h in conformance.items() if Path(p).name.startswith('FullGameEndToEndTests') and p.endswith('.cs')}
assert len(full) == 9
full_methods = {m for p in full for m in re.findall(r'\bpublic\s+(?:async\s+)?(?:Task|void)\s+(\w+)\s*\(', (root / p).read_text())}
assert len(full_methods) == 143
manifest = load(root / 'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json')
original_manifest=json.loads(subprocess.check_output(['git','show','39eacb2e22ce365c2d56750382518bfcd1bdf32a:tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'],cwd=root,text=True))
assert manifest==original_manifest and len(manifest['cases'])==49
assert all(sources[p]==h for p,h in fixed['sourceInputHashes'].items() if p.endswith('.py'))
sql=load(w/'actual-three-nocturne-sql-owner-terminal-v2.json');independent=load(w/'independent-current-nocturne-sql-all-history-result-v1.json')
assert sql['status'].startswith('PASS_CURRENT_THREE_NOCTURNE_') and sql['commands']==independent['commands']==27 and sql['events']==independent['events']==73
assert sql['coldRecoveries']==27 and sql['directAtomicRejections']==33 and sql['independentStructuralRejections']==12 and independent['independentStructuralRejections']==15
assert sql['ownPostgresSmartStopped'] and sql['allOriginal243AuditSevenTablesExactAtStop'] and sql['allOriginal52NativeSevenTablesExactAtStop']
result = {'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': 'CHECK_AND_EXACT_CASE_METHOD_PARITY_PASS', 'profile': 'check', 'baseCommit': start['baseCommit'], 'actualCases': 13219, 'actualMethods': 7501, 'allFullDiscoveryMethods': 7642, 'fullDiscoveryNotExecution': True, 'originalCaseCount': 13219, 'originalMethodCount': 7501, 'newConformanceCases': 0, 'newConformanceMethods': 0, 'oldCasesPreserved': True, 'oldMethodsPreserved': True, 'frozenInputsUnchanged': True, 'failed': 0, 'skipped': 0, 'allOriginalCaseNameCountMultisetAndMethodsExact': True, 'allOriginalConformanceSourceFilesAndTheoryRowsUnchanged': True, 'original143FullMethodsNineSourceFiles11Decks110Pairs424242VictoryAndReplayAssertionsUnchanged': True, 'allOriginal49SqlIdentitiesManifestAndOrderExact': True, 'allOriginalPythonGateMethodsAndIndependentNegativeAssertionsRetained': True, 'all3319SourceHashesModes1419ConformanceAnd23NativeInputsStableThroughoutCheck': True, 'actualTrxSha256': sha(current), 'baselineTrxSha256': sha(baseline), 'actualTestAssemblySha256': plan['testAssemblySha256'], 'summary': summary, 'ownerTerminal': owner, 'onlyOneCheckExecutedForThisCoherentBatch': True, 'fixedCommitFullCurrentVisibleAndPhysicalWindowsAcceptance': 'OPEN', 'wholePrintingAndGlobalCertification': False}
target = w / 'check-original-case-method-and-input-retention-v1.json'
with target.open('x') as f: json.dump(result, f, indent=2)
print(result['status'], '13219 cases /7501 methods exact; all original49 SQL identities/order; no source/runtime drift', flush=True)
