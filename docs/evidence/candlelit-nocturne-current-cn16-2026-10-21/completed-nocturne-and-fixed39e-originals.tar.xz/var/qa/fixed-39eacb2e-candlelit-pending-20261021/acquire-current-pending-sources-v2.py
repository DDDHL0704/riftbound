from pathlib import Path
import datetime,gzip,hashlib,json,urllib.request

root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda b:hashlib.sha256(b).hexdigest()
catalog=json.loads((root/'data/official/card-catalog.zh-CN.json').read_text())['cards']
result={'startedAtUtc':now(),'region':'CN','language':'zh-CN','observedAsOf':'2026-10-21','adoptedCoreEffectiveDate':'2026-10-16','publicationOrPrintingEffectiveDatesUnknownRemainNull':True,'cards':[],'primaryDocuments':[],'sourceIntakeOnlyNotSemanticCertification':True}
def get(url,payload=None):
 start=now();data=None if payload is None else json.dumps(payload,ensure_ascii=False).encode()
 request=urllib.request.Request(url,data=data,headers={'User-Agent':'RiftboundOfficialSourceAudit/1.0','Content-Type':'application/json'} if data is not None else {'User-Agent':'RiftboundOfficialSourceAudit/1.0'})
 with urllib.request.urlopen(request,timeout=90) as response:
  raw=response.read();receipt={'url':url,'request':payload,'attemptedAtUtc':start,'receivedAtUtc':now(),'httpStatus':response.status,'resolvedUrl':response.url,'headers':{k:response.headers[k] for k in ['Date','Last-Modified','ETag','Content-Length','Content-Type'] if k in response.headers},'bytes':len(raw),'sha256':sha(raw),'publicationDate':None,'printingEffectiveDate':None}
 return raw,receipt
try:
 for name,number,api_id,slug in [('魔腾','OGN·194/298',31426,'nocturne'),('虚空遁地兽','SFD·187/221',33285,'reksai'),('烛光','OGN·291/298',31536,'candlelit'),('大力仙灵','SFD·125/221',33215,'grand-fae')]:
  payload={'pageNum':1,'pageSize':100,'searchContent':name,'cardCategoryList':[],'cardColorList':[],'rarityList':[],'productCodeList':[]}
  raw,receipt=get('https://lol-api.playloltcg.com/xcx/card/searchCardCraftWeb',payload)
  path=w/(slug+'-current-original-card-search-v2.json.gz');assert not path.exists();path.write_bytes(gzip.compress(raw,mtime=0))
  receipt.update(path=str(path.relative_to(root)),compressedSha256=sha(path.read_bytes()),allOriginalResponseBytesRetained=True)
  d=json.loads(raw);assert d['code']==0 and d['type']=='success',d
  rows=d['result']['list'];matches=[c for c in rows if c.get('cardNo')==number and c.get('id')==api_id];assert len(matches)==1
  row=matches[0];original=next(c for c in catalog if c['id']==api_id and c['cardNo']==number)
  normalized=dict(row);normalized['cardCategory']=normalized.pop('cardCategoryList')[0];normalized['cardCategoryName']=normalized.pop('cardCategoryNameList')[0]
  if normalized.get('errata'):normalized['cardEffect']=normalized['errata']
  for key in ['errata','isPreview','otherDesc']:normalized.pop(key,None)
  receipt['explicitCatalogNormalization']={'singleCategoryListsToCategoryFields':True,'nonemptyErrataOverridesPrintedCardEffect':True,'onlyApiSurfaceKeysRemoved':['errata','isPreview','otherDesc']}
  if slug=='nocturne':receipt['allOriginalRowFieldsAndNullsEqualOct14RawRecord']=row==json.loads((root/'docs/evidence/nocturne-observation-2026-10-14/source-current.json').read_text())['records'][0]
  if slug=='candlelit':receipt['allOriginalRowFieldsAndNullsEqualPreviousW32RawRecord']=row==json.loads(gzip.decompress((root/'var/qa/candlelit-current-cn16-recertification-20261021/candlelit-current-card-search-v1.gz').read_bytes()))['result']['list'][0]
  receipt.update(exactApiId=api_id,exactPrinting=number,returnedRowCount=len(rows),responseTotal=d['result']['total'],allKeysValuesPresenceAndNullsEqualCatalogAfterExplicitKnownApiNormalization=normalized==original,exactCurrentRow=row,cardQaNullNeverProvesNoFaq=row.get('cardQaList') is None)
  result['cards'].append(receipt)
  if slug in ['nocturne','reksai','grand-fae']:
   face,fr=get(row['frontImage']);fp=w/(slug+'-current-official-face.png');assert not fp.exists();fp.write_bytes(face);fr.update(path=str(fp.relative_to(root)),visualReview='OPEN');receipt['officialFace']=fr
  print('CURRENT_CARD_INTAKE',slug,api_id,number,'same-effective-catalog-after-explicit-normalization',normalized==original,flush=True)
 raw,receipt=get('https://lol-api.playloltcg.com/xcx/gameRule/getGameRuleList',{'pageNum':1,'pageSize':1000})
 target=w/'current-original-rules-directory-v2.json.gz';assert not target.exists();target.write_bytes(gzip.compress(raw,mtime=0));receipt.update(path=str(target.relative_to(root)),compressedSha256=sha(target.read_bytes()))
 prior=root/'var/qa/candlelit-current-cn16-recertification-20261021/cn-current-rules-directory-v1.gz'
 receipt['allOriginalDirectoryRecordFieldsAndNullsEqualPriorIntake']=json.loads(raw)['result']==json.loads(gzip.decompress(prior.read_bytes()))['result'];result['rulesDirectory']=receipt
 old=json.loads((root/'var/qa/candlelit-current-cn16-recertification-20261021/source-intake-current-observation-v1.json').read_text())
 for before in old['currentThreePrimaryPdfReceipts']:
  raw,receipt=get(before['url']);existing=root/before['priorRawReference']['path']
  same=sha(raw)==before['sha256']==sha(existing.read_bytes());receipt['sameExactOriginalRawBytesAsPrior']=same
  if same:receipt.update(path=str(existing.relative_to(root)),verifiedExistingOriginalReusedWithoutDuplicateFile=True)
  else:
   target=w/('changed-primary-'+str(len(result['primaryDocuments'])+1)+'.pdf');assert not target.exists();target.write_bytes(raw);receipt.update(path=str(target.relative_to(root)),newSourceChangeRequiresIndependentDelta=True)
  result['primaryDocuments'].append(receipt);print('CURRENT_PRIMARY_SOURCE',receipt['sha256'],same,flush=True)
 result['status']='CURRENT_EXACT_OFFICIAL_INPUTS_ACQUIRED_BEFORE_PENDING_BRANCH_REVIEW'
finally:
 result['finishedAtUtc']=now();out=w/'current-pending-source-intake-original-v2.json';assert not out.exists();out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
