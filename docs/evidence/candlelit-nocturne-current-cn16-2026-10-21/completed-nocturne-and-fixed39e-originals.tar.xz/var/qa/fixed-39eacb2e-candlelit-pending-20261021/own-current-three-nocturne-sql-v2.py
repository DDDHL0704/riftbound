import ast,datetime,fcntl,hashlib,json,os,plistlib,resource,socket,subprocess,time
from pathlib import Path

resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();load=lambda p:json.loads(p.read_text())
definition=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes=[n for n in ast.parse(definition.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}]
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(definition),'exec'),globals())
pub=load(w/'observed-sql-frozen-current-source-and-runtime-v2.json');r=Path(pub['runtimeRoot'])
old=load(root/'var/qa/fixed-c2bea309-native-locked-20261021/actual-safe-native-main-v2/original241-audit50-native-seven-table-baseline-v2.json')
last=load(root/'var/qa/fixed-c2bea309-native-locked-20261021/same-original42-fixed-ci-score-owner-terminal-v2.json')
assert last['ownPostgresSmartStopped'] and last['status'].startswith('PASS_')
failed=load(w/'actual-three-nocturne-sql-owner-terminal-v1.json');assert failed['ownPostgresSmartStopped'] and failed['allOriginal241AuditSevenTablesExactAtStop'] and failed['allOriginal52NativeSevenTablesExactAtStop']
ready=w/'actual-three-nocturne-sql-ready-v2.json';stop=w/'actual-three-nocturne-sql-stop-v2.json';terminal=w/'actual-three-nocturne-sql-owner-terminal-v2.json'
assert not any(p.exists() for p in [ready,stop,terminal])
def frozen():
 assert all(sha(r/p)==h for p,h in pub['runtimeFiles'].items())
 assert all(sha(root/p)==h and oct((root/p).stat().st_mode&0o777)==pub['sourceInputModes'][p] for p,h in pub['sourceInputHashes'].items())
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof={'status':'RUNNING_CURRENT_CN16_THREE_ORIGINAL_NOCTURNE_OBSERVATION_SQL_BRANCHES_NOT_WHOLE_CARD','startedAtUtc':now(),'parentFixedCommit':pub['parentFixedCommit'],'actualRuleInputs':pub['actualRuleInputs'],'lockAtStart':observe_lock(),'controlledOriginalSourceFixturesOnly':True}
power=writer=None;started=False;audit=native=None;before_audit=before_native=None
try:
 frozen();assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid
 sock.mkdir(exist_ok=True);subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'three-nocturne-postgres-v2.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 audit=rooms('riftbound_acceptance');native=rooms('riftbound_here_native')
 assert audit==failed['actualAuditRoomsAtStop'] and len(audit)==243 and native==last['actualNativeRoomsAtStop'] and len(native)==52
 before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',native)
 assert digests('riftbound_acceptance',old['auditRooms'])==old['auditSevenTables'] and digests('riftbound_here_native',old['nativeRooms'])==old['nativeSevenTables']
 (w/'original243-audit52-native-seven-table-baseline-v2.json').write_text(json.dumps({'atUtc':now(),'auditRooms':audit,'nativeRooms':native,'auditSevenTables':before_audit,'nativeSevenTables':before_native},indent=2)+'\n')
 output=w/'actual-three-nocturne-sql-v2'
 command=['/Users/dinghaolin/.dotnet/dotnet',str(r/'Riftbound.PostgresAcceptance.dll'),'--candlelit-observed-pending-only'];proof['command']=command
 print('REAL_SQL_THREE_CURRENT_NOCTURNE_BRANCHES_STARTED',flush=True)
 with (w/'actual-three-nocturne-sql-writer-v2.log').open('xb') as f:
  writer=subprocess.Popen(command,cwd=r,env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit',RIFTBOUND_POSTGRES_EVIDENCE=str(output),DOTNET_DbgEnableMiniDump='0'),stdout=f,stderr=subprocess.STDOUT);assert writer.wait(timeout=540)==0
 receipts=[load(output/'candlelit-observed-pending'/branch/'receipt.json') for branch in ['nocturne-zero','nocturne-one','nocturne-two']]
 assert all(c['status'].startswith('REAL_SQL_CURRENT_CANDLELIT_') and c['actualRuleInputs']==pub['actualRuleInputs'] and c['coldRecoveries']==c['commands'] for c in receipts)
 added={c['room'] for c in receipts};assert len(added)==3 and set(rooms('riftbound_acceptance'))==set(audit)|added and rooms('riftbound_here_native')==native
 assert digests('riftbound_acceptance',audit)==before_audit and digests('riftbound_here_native',native)==before_native
 proof.update(status='CURRENT_THREE_NOCTURNE_SQL_WRITER_PASS_INDEPENDENT_ALL_HISTORY_PENDING',newRooms=sorted(added),cases=3,commands=sum(c['commands'] for c in receipts),events=sum(c['events'] for c in receipts),coldRecoveries=sum(c['coldRecoveries'] for c in receipts),directAtomicRejections=sum(c['directAtomicRejections'] for c in receipts),independentStructuralRejections=sum(c['independentStructuralRejections'] for c in receipts))
 ready.write_text(json.dumps(proof,indent=2)+'\n');print('THREE_CURRENT_NOCTURNE_WRITER_PASS_WAITING_INDEPENDENT_READ_ONLY',proof['commands'],proof['events'],flush=True)
 until=time.monotonic()+900
 while not stop.exists():assert time.monotonic()<until;time.sleep(.2)
 completed=load(stop);assert completed['independentReadOnlyAllHistoryAndReplayPass'] and set(completed['rooms'])==added
 proof.update(status='PASS_CURRENT_THREE_NOCTURNE_ORIGINAL_SET_CAPTURED_PENDING_COLD_DEDUP_AND_INDEPENDENT_ALL_HISTORY_REPLAY',independentReadback=completed)
except BaseException as e:
 proof.update(status='FAILED_OR_INTERRUPTED_CURRENT_NOCTURNE_ORIGINALS_AND_NEW_ROOMS_RETAINED',errorType=type(e).__name__,error=str(e));raise
finally:
 if writer is not None and writer.poll() is None:writer.terminate();writer.wait(timeout=20)
 if started:
  if before_audit is not None:
   proof['allOriginal243AuditSevenTablesExactAtStop']=digests('riftbound_acceptance',audit)==before_audit;proof['allOriginal52NativeSevenTablesExactAtStop']=digests('riftbound_here_native',native)==before_native;proof['actualAuditRoomsAtStop']=rooms('riftbound_acceptance');proof['actualNativeRoomsAtStop']=rooms('riftbound_here_native')
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None:
  if power.poll() is None:power.terminate();power.wait(timeout=10)
  proof['boundIdleAssertionEnded']=power.poll() is not None
 frozen();proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),frozenRuntimeAndRootSourceInputsStable=True);terminal.write_text(json.dumps(proof,indent=2)+'\n');fcntl.flock(guard,fcntl.LOCK_UN)
print(proof['status'],flush=True)
