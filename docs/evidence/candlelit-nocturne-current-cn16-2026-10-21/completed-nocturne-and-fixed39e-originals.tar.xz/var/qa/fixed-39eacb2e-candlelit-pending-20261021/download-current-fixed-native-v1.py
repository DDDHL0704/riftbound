from pathlib import Path
import datetime,hashlib,json,os,subprocess,zipfile

os.umask(0o077)
w=Path(__file__).resolve().parent;fixed='39eacb2e22ce365c2d56750382518bfcd1bdf32a';run_id=39520536954
raw=subprocess.check_output(['gh','api',f'repos/DDDHL0704/riftbound/actions/runs/{run_id}/artifacts'],text=True)
metadata=json.loads(raw);(w/'native-current-ready-ci-artifacts-v1.json').write_text(json.dumps(metadata,indent=2)+'\n')
folder=w/'native-current';folder.mkdir(exist_ok=False);results=[]
try:
 for name,filename in [('native-macos-latest','mac-ci-artifact.zip'),('native-windows-latest','windows-ci-artifact.zip')]:
  meta=next(a for a in metadata['artifacts'] if a['name']==name)
  assert not meta['expired'] and meta['workflow_run']['head_sha']==fixed
  target=folder/filename
  with target.open('xb') as out:
   run=subprocess.run(['gh','api',f'repos/DDDHL0704/riftbound/actions/artifacts/{meta["id"]}/zip'],stdout=out,check=False)
  digest=hashlib.sha256(target.read_bytes()).hexdigest()
  row={'name':name,'id':meta['id'],'filename':filename,'actualDownloadExitCode':run.returncode,'actualBytes':target.stat().st_size,'actualSha256':digest,'expectedBytes':meta['size_in_bytes'],'expectedDigest':meta['digest']};results.append(row)
  assert run.returncode==0 and row['actualBytes']==meta['size_in_bytes'] and meta['digest']=='sha256:'+digest
  with zipfile.ZipFile(target) as archive:
   assert archive.testzip() is None;row['allOuterZipCrcVerified']=True
   row['entries']=[{'name':a.filename,'bytes':a.file_size,'crc32':format(a.CRC,'08x')} for a in archive.infolist()]
  print(name,'BACKEND_DIGEST_SIZE_AND_OUTER_CRC_PASS',row['actualBytes'],flush=True)
finally:
 out=w/'current-fixed-native-download-original-result-v1.json';assert not out.exists();out.write_text(json.dumps({'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fixedCommit':fixed,'runId':run_id,'artifacts':results,'previousFixedC2PairRetainedUntilNewUsabilityVerified':True,'newBootInnerPayloadAndPhysicalWindowsStillPending':True},indent=2)+'\n')
