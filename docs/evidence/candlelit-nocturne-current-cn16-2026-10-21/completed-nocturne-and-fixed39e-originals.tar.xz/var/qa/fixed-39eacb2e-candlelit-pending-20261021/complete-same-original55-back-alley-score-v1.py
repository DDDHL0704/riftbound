import ast, datetime, fcntl, gzip, hashlib, json, os, plistlib, re, resource, socket, subprocess, time, urllib.request
from pathlib import Path

resource.setrlimit(resource.RLIMIT_CORE, (0, 0)); os.umask(0o077)
root = Path('/Users/dinghaolin/MyProjects/riftbound'); w = Path(__file__).resolve().parent
pg = Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin'); cluster = root / 'var/qa/permanent-play-here-base-20261017/postgres'; sock = Path('/tmp/rft-here-family-20261018-55486')
tables = ['matches', 'match_players', 'command_log', 'game_events', 'state_snapshots', 'snapshots', 'action_prompts']; read_env = dict(os.environ, PGOPTIONS='-c default_transaction_read_only=on')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest(); now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat(); load = lambda p: json.loads(p.read_text())
definition = root / 'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes = [x for x in ast.parse(definition.read_text()).body if isinstance(x, ast.FunctionDef) and x.name in {'query', 'rooms', 'digests', 'observe_lock'}]; exec(compile(ast.Module(body=nodes, type_ignores=[]), str(definition), 'exec'), globals())
pub = load(w / 'frozen-fixed39e-native-composition-v1.json'); helpers = w / 'live-acceptance-helper-runtime-v1'; api_runtime = w / 'api-runtime-v1'
evidence = w / 'same-original55-back-alley-fixed-ci-score-continuation-v2'; evidence.mkdir(exist_ok=False)
definition = w / 'run-fixed39e-ci-main-pair-v1.py'; text = definition.read_text().replace('live-current-ci-api-', 'same-original55-back-alley-exact-destination-api-').replace('live-current-ci-owner-state-v2', 'same-original55-back-alley-exact-destination-owner-state-v2')
names = {'checkpoint', 'frozen', 'state', 'start_api', 'export', 'count'}; nodes = [x for x in ast.parse(text).body if isinstance(x, ast.FunctionDef) and x.name in names]; exec(compile(ast.Module(body=nodes, type_ignores=[]), str(definition), 'exec'), globals())
previous = load(w / 'live-current-ci-main-owner-terminal-v2.json'); baseline = load(w / 'actual-safe-native-main-v2/original246-audit52-native-seven-table-baseline-v2.json'); entry = load(w / 'actual-safe-native-prefix-v2/pending-original-native-prefix-receipt.json')
room = entry['room']; a, b = entry['players']; n = entry['acceptedCommands']; assert n == 52 and previous['nativeAcceptedGameplayCommands'] == 3 and previous['actualColdRestartAndBothCiNativeRestore'] and all(p['exitCode'] == 0 and p['ptyFullyDrained'] for p in previous['ownedNativeProcesses'])
prior_path = w / 'actual-safe-native-main-v2/owner-final-current-ci-native-original-frame-v2.json.gz'; prior = json.loads(gzip.decompress(prior_path.read_bytes())); assert len(prior['commands']) == 55 and not prior['authoritativeState']['stackItems'] and prior['authoritativeState']['pendingPayment'] is None
ready = w / 'live-current-ci-main-ready-v2.json'; stop = w / 'live-current-ci-main-stop-v2.json'; terminal = w / 'same-original55-back-alley-score-owner-terminal-v1.json'; assert not any(p.exists() for p in [ready, stop, terminal])
score_runtime = w / 'explicit-original-back-alley-score-runtime-v1'; score_files = load(w / 'explicit-original-back-alley-score-frozen-inputs-v1.json')['runtimeFiles']
guard = (root / 'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a'); fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
proof = {'status': 'RUNNING_SAME_ORIGINAL55_FIXED39E_CI_NATIVE_COMPLETE_NORMAL_SCORE_ONLY', 'startedAtUtc': now(), 'fixedCommit': pub['fixedCommit'], 'baseCommit': pub['fixedCommit'], 'fixedCiRun': 39520536954, 'room': room, 'originalGatewayPrefixCommands': n, 'nativeAcceptedGameplayCommands': 3, 'actualRuleInputs': pub['actualRuleInputs'], 'bothFixedCiNativeColdReconnectAndAllFiveExit0AlreadyPassed': True, 'original52Plus3CiNativeCommandsNotReplayed': True, 'ownedApiProcesses': [], 'lockAtStart': observe_lock()}
api = power = driver = None; started = False
try:
    frozen(); assert all(sha(score_runtime / p) == h for p, h in score_files.items())
    assert subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), 'status'], capture_output=True).returncode == 3
    with socket.socket() as s: assert s.connect_ex(('127.0.0.1', 15847)) != 0
    power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())]); proof['boundIdleAssertionPid'] = power.pid
    sock.mkdir(exist_ok=True); subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-l', str(w / 'same-original55-back-alley-fixed-ci-postgres-v2.log'), '-o', f'-p 55486 -h 127.0.0.1 -k {sock}', '-w', 'start'], capture_output=True, check=True); started = True
    assert rooms('riftbound_acceptance') == baseline['auditRooms'] and set(rooms('riftbound_here_native')) == set(baseline['nativeRooms']) | {room}
    assert digests('riftbound_acceptance', baseline['auditRooms']) == baseline['auditSevenTables'] and digests('riftbound_here_native', baseline['nativeRooms']) == baseline['nativeSevenTables']
    start_api(1); before = export('same-original55-back-alley-before-any-score-command-v1'); assert before == prior and count() == 55
    score = w / 'same-original55-back-alley-fixed-ci-normal-score-v2'; assert not score.exists()
    command = ['/Users/dinghaolin/.dotnet/dotnet', str(score_runtime / 'Fixed39eOriginalBackAlleyScoreV1.dll'), 'http://127.0.0.1:15847', str(score), str(w), str(w / 'actual-safe-native-prefix-v2/pending-original-native-prefix-receipt.json'), str(w / 'actual-safe-native-main-v2/after-native-priority-pass-2-original-frame-v2.json.gz'), 'BATTLEFIELD:'+next(id for id in prior['authoritativeState']['playerZones'][b]['battlefields'] if prior['authoritativeState']['cardObjects'][id]['cardNo']=='OGN·277/298')]; proof['actualScoreCommand'] = command
    with (w / 'same-original55-back-alley-fixed-ci-score-writer-v2.log').open('xb') as log:
        driver = subprocess.Popen(command, cwd=score_runtime, stdout=log, stderr=subprocess.STDOUT, env=dict(os.environ, DOTNET_DbgEnableMiniDump='0')); assert driver.wait(timeout=330) == 0
    score_receipt = load(score / 'normal-original-score-continuation-receipt.json'); assert score_receipt['continuationCommands'] == 17 and score_receipt['winningScore'] == 8
    final = export('same-original-fixed-ci-normal-score-final-v1'); current = final['authoritativeState']
    assert len(final['commands']) == 72 and current['status'] == 'FINISHED' and current['winnerPlayerId'] == a and current['playerScores'] == {a: 8, b: 0}
    assert final['commands'][:55] == before['commands'] and final['events'][:len(before['events'])] == before['events'] and final['openingSeed'] == before['openingSeed'] and final['replayInitialState'] == before['replayInitialState']
    assert all(c['commandType'] != 'SURRENDER' and c['playerId'] == c['playerId'].strip().lower() for c in final['commands'])
    network_before = rooms('riftbound_here_native')
    with (w / 'same-original55-back-alley-fixed-ci-backend-network-v2.log').open('xb') as log:
        driver = subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet', str(w / 'native-network-runtime-v1/Riftbound.NativeNetworkSmoke.dll')], cwd=w / 'native-network-runtime-v1', stdout=log, stderr=subprocess.STDOUT, env=dict(os.environ, RIFTBOUND_SERVER_URL='http://127.0.0.1:15847', DOTNET_DbgEnableMiniDump='0')); assert driver.wait(timeout=90) == 0
    raw = (w / 'same-original55-back-alley-fixed-ci-backend-network-v2.log').read_text(); assert 'Native canonical room identity passed:' in raw and 'Native network recovery passed: socket loss, authenticated room restore, fresh snapshot, rejected-token guard.' in raw
    wire = json.loads(next(x[len('NATIVE_ROOM_IDENTITY_EVIDENCE '):] for x in raw.splitlines() if x.startswith('NATIVE_ROOM_IDENTITY_EVIDENCE '))); assert wire['rejectedActions'] == 15 and wire['leakedPrivateMessages'] == 0 and wire['validReconnectTokenWasSupplied']
    added = set(rooms('riftbound_here_native')) - set(network_before); assert len(added) == 1 and next(iter(added)).startswith('NETWORK-')
    proof.update(status='SAME_ORIGINAL_FIXED_CI_NATIVE3_NORMAL_SCORE17_READY_FOR_INDEPENDENT_HISTORY', totalCommands=72, events=len(final['events']), winningScore=8, losingScore=0, finalTurn=current['turnNumber'], normalGatewayCommands=17, separateNewNetworkRoom=next(iter(added)), networkOriginalEvidence=wire, networkDriverOriginallyN29SourceBuiltNotCiArtifact=True)
    ready.write_text(json.dumps({**proof, 'rawFinalFrame': str(evidence / 'same-original-fixed-ci-normal-score-final-v1.json.gz'), 'originalScoreIntentFile': str(score / 'all-original-normal-score-continuation-intents.json')}, indent=2)); state('WAITING_SAME_ORIGINAL72_FIXED_CI_ALL_SQL_HISTORY_AND_FULL_REPLAY')
    until = time.monotonic() + 900
    while not stop.exists(): assert api.poll() is None and time.monotonic() < until; time.sleep(.2)
    completion = load(stop); assert completion['room'] == room and completion['independentReadOnlyHistoryAndFullReplayPass']; proof.update(status='PASS_SAME_ORIGINAL52_PLUS3_FIXED_CI_NATIVE_PLUS17_NORMAL_SCORE_NETWORK15_AND_INDEPENDENT_ALL_SQL_REPLAY_NOT_VISIBLE_OR_WINDOWS', independentReadback=completion)
except BaseException as e:
    proof.update(status='FAILED_OR_INTERRUPTED_SAME_ORIGINAL42_FIXED_CI_SCORE_ROOM_RETAINED_NO_RESET', errorType=type(e).__name__, error=str(e)); raise
finally:
    if driver is not None and driver.poll() is None: driver.terminate(); driver.wait(timeout=20)
    if api is not None:
        if api.poll() is None: api.terminate(); api.wait(timeout=25)
        proof['ownApiStopped'] = api.poll() is not None
    if started:
        proof['allOriginal246AuditSevenTablesExactAtStop'] = digests('riftbound_acceptance', baseline['auditRooms']) == baseline['auditSevenTables']; proof['allOriginal52NativeSevenTablesExactAtStop'] = digests('riftbound_here_native', baseline['nativeRooms']) == baseline['nativeSevenTables']; proof['actualNativeRoomsAtStop'] = rooms('riftbound_here_native'); proof['ownPostgresSmartStopped'] = subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-m', 'smart', '-w', '-t', '20', 'stop'], capture_output=True).returncode == 0
    if power is not None:
        if power.poll() is None: power.terminate(); power.wait(timeout=10)
        proof['boundIdleAssertionEnded'] = power.poll() is not None
    frozen(); assert all(sha(score_runtime / p) == h for p, h in score_files.items()); proof.update(finishedAtUtc=now(), lockAtEnd=observe_lock(), allFixedCiApiHelperNetworkAndExplicitScoreInputsExact=True, allOriginalAcceptedHistoryAndDatabasesRetained=True); terminal.write_text(json.dumps(proof, indent=2)); fcntl.flock(guard, fcntl.LOCK_UN)
print(proof['status'], flush=True)
