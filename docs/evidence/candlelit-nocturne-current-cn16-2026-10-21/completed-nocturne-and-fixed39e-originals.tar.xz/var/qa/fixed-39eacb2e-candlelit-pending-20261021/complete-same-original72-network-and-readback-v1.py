import ast,datetime,fcntl,gzip,hashlib,json,os,plistlib,re,resource,socket,subprocess,time,urllib.request
from pathlib import Path

resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();load=lambda p:json.loads(p.read_text())
definition=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes=[n for n in ast.parse(definition.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(definition),'exec'),globals())
pub=load(w/'frozen-fixed39e-native-composition-v2.json');helpers=w/'live-acceptance-helper-runtime-v1';api_runtime=w/'api-runtime-v1'
evidence=w/'same-original72-network-and-readback-v1';evidence.mkdir(exist_ok=False)
definition=w/'run-fixed39e-ci-main-pair-v1.py';text=definition.read_text().replace('live-current-ci-api-','same-original72-network-api-').replace('live-current-ci-owner-state-v2','same-original72-network-owner-state-v1').replace("w/'native-network-runtime-v1'","w/'native-network-runtime-v2'")
nodes=[n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name in {'checkpoint','frozen','state','start_api','export','count'}];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(definition),'exec'),globals())
last=load(w/'same-original55-back-alley-score-owner-terminal-v1.json');baseline=load(w/'actual-safe-native-main-v2/original246-audit52-native-seven-table-baseline-v2.json');entry=load(w/'actual-safe-native-prefix-v2/pending-original-native-prefix-receipt.json')
room=entry['room'];a,b=entry['players'];n=entry['acceptedCommands'];assert n==52 and last['ownApiStopped'] and last['ownPostgresSmartStopped'] and len(last['actualNativeRoomsAtStop'])==53
prior_path=w/'same-original55-back-alley-fixed-ci-score-continuation-v2/same-original-fixed-ci-normal-score-final-v1.json.gz';prior=json.loads(gzip.decompress(prior_path.read_bytes()));assert len(prior['commands'])==72 and prior['authoritativeState']['status']=='FINISHED' and prior['authoritativeState']['playerScores']=={a:8,b:0}
ready=w/'live-current-ci-main-ready-v2.json';stop=w/'live-current-ci-main-stop-v2.json';terminal=w/'same-original72-network-owner-terminal-v1.json';assert not any(p.exists() for p in [ready,stop,terminal])
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof={'status':'RUNNING_NET8_NETWORK_ONLY_AND_READONLY_FINISHED72_NO_GAMEPLAY_REPLAY','startedAtUtc':now(),'fixedCommit':pub['fixedCommit'],'baseCommit':pub['fixedCommit'],'fixedCiRun':39520536954,'actualRuleInputs':pub['actualRuleInputs'],'room':room,'originalGatewayPrefixCommands':52,'nativeAcceptedGameplayCommands':3,'normalGatewayCommands':17,'totalCommands':72,'events':len(prior['events']),'winningScore':8,'losingScore':0,'finalTurn':42,'lockAtStart':observe_lock(),'ownedApiProcesses':[],'allOriginal52Plus3NativePlus17ScoreCommandsNotResubmitted':True,'networkDriverOriginallyN29Net8SourceBuiltNotCiArtifact':True}
api=driver=power=None;started=False;before_audit=before_native=None
try:
 frozen();assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid
 subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'same-original72-network-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 audit=rooms('riftbound_acceptance');native=rooms('riftbound_here_native');assert audit==baseline['auditRooms'] and len(audit)==246 and native==last['actualNativeRoomsAtStop'] and set(native)==set(baseline['nativeRooms'])|{room}
 before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',native);assert before_audit==baseline['auditSevenTables'] and digests('riftbound_here_native',baseline['nativeRooms'])==baseline['nativeSevenTables']
 checkpoint('original246-audit53-native-seven-table-baseline-v1.json',{'auditRooms':audit,'nativeRooms':native,'auditSevenTables':before_audit,'nativeSevenTables':before_native})
 start_api(1);actual=export('same-original72-before-network-readonly-v1');assert actual==prior and count()==72
 log=w/'same-original72-restored-net8-network-v1.log'
 with log.open('xb') as out:
  driver=subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet',str(w/'native-network-runtime-v2/Riftbound.NativeNetworkSmoke.dll')],cwd=w/'native-network-runtime-v2',stdout=out,stderr=subprocess.STDOUT,env=dict(os.environ,RIFTBOUND_SERVER_URL='http://127.0.0.1:15847',DOTNET_DbgEnableMiniDump='0'));assert driver.wait(timeout=90)==0
 raw=log.read_text();assert 'Native canonical room identity passed:' in raw and 'Native network recovery passed: socket loss, authenticated room restore, fresh snapshot, rejected-token guard.' in raw
 wire=json.loads(next(line[len('NATIVE_ROOM_IDENTITY_EVIDENCE '):] for line in raw.splitlines() if line.startswith('NATIVE_ROOM_IDENTITY_EVIDENCE ')));assert wire['rejectedActions']==15 and wire['leakedPrivateMessages']==0 and wire['validReconnectTokenWasSupplied']
 added=set(rooms('riftbound_here_native'))-set(native);assert len(added)==1 and next(iter(added)).startswith('NETWORK-')
 assert digests('riftbound_acceptance',audit)==before_audit and digests('riftbound_here_native',native)==before_native and export('same-original72-after-network-readonly-v1')==prior
 proof.update(status='FIXED39E_NATIVE3_SCORE17_AND_NETWORK15_READY_FOR_INDEPENDENT_ALL72_HISTORY',separateNewNetworkRoom=next(iter(added)),networkOriginalEvidence=wire,allOriginal246AuditAnd53NativeSevenTablesUnchanged=True)
 ready.write_text(json.dumps({**proof,'rawFinalFrame':str(prior_path),'originalScoreIntentFile':str(w/'same-original55-back-alley-fixed-ci-normal-score-v2/all-original-normal-score-continuation-intents.json'),'actualDatabase':'riftbound_here_native'},indent=2)+'\n');state('WAITING_INDEPENDENT_FIXED39E_ALL72_SQL_HISTORY_AND_FULL_REPLAY')
 until=time.monotonic()+900
 while not stop.exists():assert api.poll() is None and time.monotonic()<until;time.sleep(.2)
 result=load(stop);assert result['room']==room and result['independentReadOnlyHistoryAndFullReplayPass'];proof.update(status='PASS_FIXED39E_CI_NATIVE3_ORIGINAL52_SCORE17_NETWORK15_AND_INDEPENDENT_ALL72_HISTORY_REPLAY_NOT_VISIBLE_OR_WINDOWS',independentReadback=result)
except BaseException as e:
 proof.update(status='FAILED_OR_INTERRUPTED_NETWORK_OR_INDEPENDENT_READBACK_ALL72_ORIGINALS_RETAINED',errorType=type(e).__name__,error=str(e));raise
finally:
 if driver is not None and driver.poll() is None:driver.terminate();driver.wait(timeout=20)
 if api is not None:
  if api.poll() is None:api.terminate();api.wait(timeout=25)
  proof['ownApiStopped']=api.poll() is not None
 if started:
  if before_audit is not None:
   proof['allOriginal246AuditSevenTablesExactAtStop']=digests('riftbound_acceptance',audit)==before_audit;proof['allOriginal53NativeSevenTablesExactAtStop']=digests('riftbound_here_native',native)==before_native;proof['actualNativeRoomsAtStop']=rooms('riftbound_here_native')
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None:
  if power.poll() is None:power.terminate();power.wait(timeout=10)
  proof['boundIdleAssertionEnded']=power.poll() is not None
 frozen();proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),allCurrentFrozenApiHelperNet8NetworkAndCi373InputsExact=True,allOriginalDatabasesAndAcceptedHistoriesRetained=True);terminal.write_text(json.dumps(proof,indent=2)+'\n');fcntl.flock(guard,fcntl.LOCK_UN)
print(proof['status'],flush=True)
