from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;old=root/'var/qa/fixed9633-early-native-20261022';prior=root/'var/qa/room-seat-peer-notifications-20261022';load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();files=lambda p:{str(f.relative_to(p)):sha(f) for f in p.rglob('*') if f.is_file()}
def write(p,d):
 with p.open('x') as f:json.dump(d,f,indent=2)
fixed='401470234dcd9dc4d72fe89dd79e99187096277f';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==fixed and subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)==''
api=load(w/'fixed4014-api-gameplay-closure-frozen-inputs-v1.json');runtime=Path(api['runtimeRoot']);assert api['fixedCommit']==fixed and files(runtime)==api['runtimeFiles'] and len(api['runtimeFiles'])==46
original=load(old/'frozen-fixed9633-native-composition-v1.json');oldhelpers=Path(original['helperRuntimeRoot']);assert files(oldhelpers)==original['helperRuntimeFiles']
helpers=w/'fixed4014-native-helpers-runtime-v1';assert not helpers.exists();subprocess.run(['/bin/cp','-cR',str(oldhelpers),str(helpers)],check=True)
for name in api['runtimeFiles']:
 p=helpers/name;p.parent.mkdir(parents=True,exist_ok=True)
 if p.exists() or p.is_symlink():p.unlink()
 shutil.copy2(runtime/name,p)
assert all(sha(helpers/p)==h for p,h in api['runtimeFiles'].items())
originalOwn={p:h for p,h in original['helperRuntimeFiles'].items() if p not in original['runtimeFiles']};assert len(originalOwn)==41 and all(sha(helpers/p)==h for p,h in originalOwn.items())
reader=w/'fixed4014-native-history-reader-source-v1';assembly='Fixed4014NativeHistoryReaderV1'
with (w/'build-fixed4014-native-history-reader-v1.log').open('xb') as log:subprocess.run(['/Users/dinghaolin/.dotnet/dotnet','build',str(reader/'probe.csproj'),'--configuration','Release','--nologo'],cwd=reader,stdout=log,stderr=subprocess.STDOUT,check=True)
rr=w/'fixed4014-native-history-reader-runtime-v1';assert not rr.exists();subprocess.run(['/bin/cp','-cR',str(runtime),str(rr)],check=True)
for suffix in ['.dll','.pdb']:shutil.copy2(reader/'bin/Release/net10.0'/(assembly+suffix),rr/(assembly+suffix))
reader_hashes=files(rr);assert len(reader_hashes)==48
measurements=[]
for label,r,expected in [('api',runtime,api['runtimeFiles']),('helpers',helpers,files(helpers)),('reader',rr,reader_hashes)]:
 for p in ['Riftbound.Api.deps.json','Riftbound.Api.runtimeconfig.json']:assert not (r/p).is_symlink()
 command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(r/'Riftbound.Api.deps.json'),'--runtimeconfig',str(r/'Riftbound.Api.runtimeconfig.json'),str(rr/(assembly+'.dll')),'--loaded-inputs'];actual=json.loads(subprocess.check_output(command,cwd=r,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0')))
 assert Path(actual['baseDirectory'])==r and len(actual['assemblies'])==4 and actual['hasRoomSeatReplay'] and actual['hasAtomicSeatCommit']
 for a in actual['assemblies']:assert Path(a['path'])==r/(a['name']+'.dll') and a['sha256']==expected[a['name']+'.dll'] and a['mvid']
 measurements.append({'runtime':label,'actualCommand':command,'actual':actual});assert files(r)==expected
identity=measurements[0]['actual']['actualRuleInputs'];assert all(m['actual']['actualRuleInputs']==identity for m in measurements) and identity['authoritySha256']=='70ccda5893a1b8b56cdceadee35e084b1e3f5b297ef64e1ce7d0cbeb141ce2d4' and identity['catalogSha256']=='e7455edc32d43f8253a9d0c6fedb83c347bebafbef064f9b8dffaaabc4b4d266'
network=w/'fixed4014-native-network-net8-runtime-v1';assert not network.exists();priorNetwork=load(prior/'peer-notification-wip-api-and-network-frozen-inputs-v1.json');network_sources={p:sha(root/p) for p in priorNetwork['networkSourceHashes']}
for p,h in network_sources.items():assert hashlib.sha256(subprocess.check_output(['git','show',fixed+':'+p],cwd=root)).hexdigest()==h
with (w/'build-fixed4014-native-network-net8-v1.log').open('xb') as log:subprocess.run(['/Users/dinghaolin/.dotnet/dotnet','publish','tests/Riftbound.NativeNetworkSmoke/Riftbound.NativeNetworkSmoke.csproj','--configuration','Release','--no-restore','--nologo','--output',str(network)],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
network_files=files(network);assert len(network_files)==22
assert all(sha(root/p)==h for p,h in api['allDeclaredApiGameplaySourceInputsExactFixedCommit'].items()) and files(runtime)==api['runtimeFiles']
write(w/'fixed4014-native-history-reader-frozen-v1.json',{'runtimeRoot':str(rr),'runtimeFiles':reader_hashes,'assembly':assembly,'sourceHashes':{str(p.relative_to(w)):sha(p) for p in reader.iterdir() if p.is_file()},'exactActualApiRuleInputs':identity,'allOriginalFiniteReaderAssertionsRetainedWithExactCurrentCandidateBinding':True})
write(w/'fixed4014-actual-loaded-path-sha-mvid-and-input-identity-v1.json',{'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fixedCommit':fixed,'status':'PASS','records':measurements})
pub={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fixedCommit':fixed,'baseCommit':fixed,'fixedCiRun':39682586542,'status':'FROZEN_LOCAL_FIXED4014_API_HELPERS_CURRENT_NET8_NETWORK_ACTUAL_CI_APPS_PENDING','apiRuntimeRoot':str(runtime),'runtimeFiles':api['runtimeFiles'],'apiBuildInputsManifest':str(w/'fixed4014-api-gameplay-closure-frozen-inputs-v1.json'),'apiBuildInputsManifestSha256':sha(w/'fixed4014-api-gameplay-closure-frozen-inputs-v1.json'),'actualRuleInputs':identity,'helperRuntimeRoot':str(helpers),'helperRuntimeFiles':files(helpers),'networkRuntimeRoot':str(network),'networkRuntimeFiles':network_files,'networkSourceHashes':network_sources,'networkDriverDependencyFramework':'net8.0','apiAndHelpersNotClaimedCiExported':True,'all41OriginalHelperOnlyFilesByteExactPriorFixedRuntime':originalOwn,'sourceGameplayClosure251ExactCurrentFixedCommit':True,'originalScoreOracleAssembly':'Fixed708OriginalBandleTreeScoreV1.dll','originalScoreOracleAssertionsUnchangedWithAlreadyVerified278FieldCalibration':True,'allApiHelpersReaderMetadataPhysicalAndLoadedFourAssemblyPathsShaMvidMeasured':True,'actualLoaderMeasurement':str(w/'fixed4014-actual-loaded-path-sha-mvid-and-input-identity-v1.json'),'actualLoaderMeasurementSha256':sha(w/'fixed4014-actual-loaded-path-sha-mvid-and-input-identity-v1.json'),'oldGamesNotMigrated':True,'originalSoleCheckAnd13CiFailurePreserved':True,'nativePackagesNotYetDownloaded':True,'currentWholeFullCiVisibleAndWindowsAcceptance':'OPEN'};write(w/'fixed4014-native-helper-and-network-frozen-v1.json',pub)
print('FIXED4014_FROZEN api46 helper87 reader48 currentNet8network22; actual4loadedpathsSHA_MVID_measured; identity',identity['identitySha256'],flush=True)
