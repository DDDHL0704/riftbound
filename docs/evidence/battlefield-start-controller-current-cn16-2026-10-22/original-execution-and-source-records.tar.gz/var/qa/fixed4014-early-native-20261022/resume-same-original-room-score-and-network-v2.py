# -*- coding: utf-8 -*-
from pathlib import Path
import ast,collections,datetime,fcntl,gzip,hashlib,json,os,plistlib,re,resource,socket,subprocess,textwrap,time,urllib.request
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486');tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
source=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py';nodes=[n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),globals())
original_owner=w/'run-fixed4014-ci-main-pair-v1.py';original=original_owner.read_text();nodes=[n for n in ast.parse(original).body if isinstance(n,ast.FunctionDef) and n.name in {'frozen','start_api','export','count'}];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(original_owner),'exec'),globals())
pub=load(w/'frozen-fixed4014-native-composition-v1.json');previous=load(w/'live-current-ci-main-owner-terminal-v2.json');assert previous['status']=='FAILED_OR_INTERRUPTED_CURRENT_FIXED_CI_EXPORTED_NATIVE_ORIGINAL_ROOM_AND_INPUTS_RETAINED' and previous['errorType']=='AssertionError' and previous['error']==''
assert previous['ownPostgresSmartStopped'] and previous['ownApiStopped'] and previous['actualColdRestartAndBothCiNativeRestore'] and previous['nativeAcceptedGameplayCommands']==3 and previous['allOriginal331AuditSevenTablesExactAtStop'] and previous['allOriginal69NativeSevenTablesExactAtStop']
assert len(previous['actualAuditRoomsAtStop'])==331 and len(previous['actualNativeRoomsAtStop'])==70 and len(previous['ownedNativeProcesses'])==5 and all(r['exitCode']==0 and r['ptyFullyDrained'] and sha(w/r['log'])==r['logSha256'] for r in previous['ownedNativeProcesses'])
entry=load(w/'actual-safe-native-prefix-v2/pending-original-native-prefix-receipt.json');room=entry['room'];a,b=entry['players'];client_n=entry['acceptedCommands'];n=client_n+2;assert room==previous['room']
post_path=w/'actual-safe-native-main-v2/after-native-priority-pass-2-original-frame-v2.json.gz';post=json.loads(gzip.decompress(post_path.read_bytes()));assert len(post['commands'])==n+3==59 and len(post['events'])==332 and post['authoritativeState']['status']=='IN_PROGRESS'
all_fields=[id for z in post['authoritativeState']['playerZones'].values() for id in z['battlefields'] if post['authoritativeState']['cardObjects'][id]['cardNo']=='OGN\u00b7278/298'];own_fields=[id for id in post['authoritativeState']['playerZones'][a]['battlefields'] if post['authoritativeState']['cardObjects'][id]['cardNo']=='OGN\u00b7278/298'];assert len(all_fields)==2 and len(own_fields)==1 and post['authoritativeState']['cardObjects'][own_fields[0]]['ownerId']==a
exact_destination='BATTLEFIELD:'+own_fields[0];assert all(len(z['mainDeck'])>=9 for z in post['authoritativeState']['playerZones'].values())
api_runtime=Path(pub['apiRuntimeRoot']);helpers=Path(pub['helperRuntimeRoot']);evidence=w/'actual-safe-native-main-v3';evidence.mkdir(exist_ok=False)
terminal=w/'live-current-ci-main-owner-terminal-v3.json';ready=w/'live-current-ci-main-ready-v3.json';stop=w/'live-current-ci-main-stop-v3.json';assert not any(p.exists() for p in [terminal,ready,stop])
def checkpoint(name,data):
 with (evidence/name).open('x') as f:json.dump(data,f,ensure_ascii=False,indent=2)
def state(stage):
 proof['stage']=stage;proof['updatedAtUtc']=now();p=w/'live-current-ci-owner-state-v3.json';p.write_text(json.dumps(proof,indent=2));print(stage,flush=True)
proof={'status':'RUNNING_SAME_ORIGINAL_FIXED4014_ROOM_AFTER_ACCEPTANCE_FIELD_SELECTOR_FAILURE','startedAtUtc':now(),'baseCommit':pub['baseCommit'],'fixedCommit':pub['fixedCommit'],'fixedCiRun':39682586542,'actualRuleInputs':pub['actualRuleInputs'],'fixedExportedCiPayloads':True,'completeFixedCiAcceptanceStillPending':True,'ownedApiProcesses':[],'ownedNativeProcesses':[],'originalNativeProcessesAllExitedSuccessfullyRetained':previous['ownedNativeProcesses'],'originalFailedOwnerTerminalSha256':sha(w/'live-current-ci-main-owner-terminal-v2.json'),'originalOwnerSourceSha256':sha(original_owner),'originalGatewayPrefixCommands':client_n,'originalServerSeatCommands':2,'originalJournalPrefixCommands':n,'nativeAcceptedGameplayCommands':3,'actualColdRestartAndBothCiNativeRestore':True,'originalSameRoomCheckpointCommands':59,'originalSameRoomCheckpointEvents':332,'originalPostNativeFrameSha256':sha(post_path),'originalTwoPhysicalOgn278Battlefields':all_fields,'actualOriginalLegalOwnOgn278Destination':exact_destination,'originalScoreOracleAssemblyByteExact':sha(helpers/'Fixed708OriginalBandleTreeScoreV1.dll'),'allOriginal17ContinuationAndFullScoreHistoryReplayAssertionsPreserved':True,'oldFailedResultsAndAllFiveOriginalNativeLogsNotRelabeledOrOverwritten':True,'room':room,'noNewOrdinaryRoomNoSeedChangeNoPrefixOrNativeActionResubmission':True,'visibleOrPhysicalWindowsAcceptance':False,'lockAtStart':observe_lock()}
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
api=power=driver=None;started=False;audit=native=before_audit=before_native=None
try:
 frozen();assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid;sock.mkdir(exist_ok=True);subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'same-original-room-resume-postgres-v3.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 audit=rooms('riftbound_acceptance');all_native=rooms('riftbound_here_native');assert audit==previous['actualAuditRoomsAtStop'] and all_native==previous['actualNativeRoomsAtStop'];native=[r for r in all_native if r!=room];assert len(native)==69
 before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',native);baseline=load(w/'actual-safe-native-main-v2/original331-audit69-native-seven-table-baseline-v2.json');assert before_audit==baseline['auditSevenTables'] and before_native==baseline['nativeSevenTables'];checkpoint('original331-audit69-protected-and-same-original-room-start-v3.json',{'auditSevenTables':before_audit,'nativeSevenTables':before_native,'sameOriginalRoom':room,'originalRoomCommands':59,'originalRoomEvents':332})
 start_api(3);current=export('same-original-room-before-normal-score-v3');assert current['commands']==post['commands'] and current['events']==post['events'] and current['authoritativeState']==post['authoritativeState'] and current['openingSeed']==post['openingSeed'] and current['replayInitialState']==post['replayInitialState'];state('RESUMED_SAME_ORIGINAL59_COMMAND332_EVENT_ROOM_NO_REPLAYED_NATIVE_ACTION')
 score=w/'actual-safe-normal-score-continuation-v3';assert not score.exists()
 with (w/'same-original-normal-score-writer-v3.log').open('xb') as log:driver=subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet',str(helpers/'Fixed708OriginalBandleTreeScoreV1.dll'),'http://127.0.0.1:15847',str(score),str(w),str(w/'actual-safe-native-prefix-v2/pending-original-native-prefix-receipt.json'),str(post_path),exact_destination],cwd=helpers,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0'));assert driver.wait(timeout=330)==0,'Original same-room17 score continuation failed; preserve all commands and the original seed'
 receipt=load(score/'normal-original-score-continuation-receipt.json');assert receipt['continuationCommands']==17 and receipt['winningScore']==8 and receipt['normalEndTurns']==14
 final=export('after-current-ci-native-normal-score-final-original-frame-v3');s=final['authoritativeState'];assert len(final['commands'])==n+20==76 and s['status']=='FINISHED' and s['winnerPlayerId']==a and s['playerScores']=={a:8,b:0};assert final['commands'][:n+3]==post['commands'] and final['events'][:len(post['events'])]==post['events'] and final['openingSeed']==post['openingSeed'] and final['replayInitialState']==post['replayInitialState'] and all(c['commandType']!='SURRENDER' for c in final['commands'])
 proof.update(totalCommands=len(final['commands']),events=len(final['events']),winningScore=8,losingScore=0,finalTurn=s['turnNumber'],normalGatewayCommands=17);state('SAME_ORIGINAL_ROOM_NORMAL8_TO0_ALL59_ORIGINAL_COMMANDS_AND332_EVENTS_RETAINED')
 start=original.index(" network_before=rooms('riftbound_here_native')");end=original.index(" assert all(c['playerId']==c['playerId'].strip().lower()",start);network_code=textwrap.dedent(original[start:end]);exec(compile(network_code,str(original_owner)+'::<unchanged_original_network_gate>','exec'),globals())
 assert set(rooms('riftbound_here_native'))==set(all_native)|set(proof['twoSeparateNewNetworkRooms']) and len(proof['twoSeparateNewNetworkRooms'])==2
 assert digests('riftbound_acceptance',audit)==before_audit and digests('riftbound_here_native',native)==before_native
 ready.write_text(json.dumps({**proof,'status':'CURRENT_FIXED_CI_EXPORTED_NATIVE_AND_NORMAL_SCORE_READY_FOR_INDEPENDENT_FULL_SQL_HISTORY_REPLAY','apiPid':api.pid,'rawFinalFrame':str(evidence/'after-current-ci-native-normal-score-final-original-frame-v3.json.gz'),'originalScoreIntentFile':str(score/'all-original-normal-score-continuation-intents.json'),'actualDatabase':'riftbound_here_native'},indent=2));state('WAITING_INDEPENDENT_CURRENT_SAME_ORIGINAL_FULL_HISTORY_REPLAY')
 until=time.monotonic()+900
 while not stop.exists():assert api.poll() is None and time.monotonic()<until;time.sleep(.2)
 completion=load(stop);assert completion['independentReadOnlyHistoryAndFullReplayPass'] and completion['room']==room;proof.update(status='PASS_FIXED4014_CI_EXPORTED_DEFAULT_MAIN_PAIR_CANONICAL_COLD_RECONNECT_AND_NORMAL_SCORE_INDEPENDENT_SQL_REPLAY_NOT_VISIBLE_OR_WINDOWS',independentReadback=completion)
except BaseException as e:
 proof.update(status='FAILED_SAME_ORIGINAL_FIXED4014_ROOM_RESUME_ALL_ORIGINAL_HISTORY_RETAINED',errorType=type(e).__name__,error=str(e));raise
finally:
 if driver is not None and driver.poll() is None:driver.terminate();driver.wait(timeout=20)
 if started:
  try:export('same-original-room-resume-owner-final-v3');proof['latestSameOriginalFrameRetainedAtStop']=True
  except BaseException as e:proof['finalFrameExportErrorType']=type(e).__name__
 if api is not None and api.poll() is None:api.terminate();api.wait(timeout=25)
 proof['ownApiStopped']=api is None or api.poll() is not None
 if started:
  if before_audit is not None:
   proof['allOriginal331AuditSevenTablesExactAtStop']=digests('riftbound_acceptance',audit)==before_audit;proof['allOriginal69NativeSevenTablesExactAtStop']=digests('riftbound_here_native',native)==before_native;proof['actualAuditRoomsAtStop']=rooms('riftbound_acceptance');proof['actualNativeRoomsAtStop']=rooms('riftbound_here_native')
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None and power.poll() is None:power.terminate();power.wait(timeout=10)
 frozen();proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),allFrozenApiHelpersCurrentNetworkAndBoth373NativePayloadsStable=True,allOriginalDatabaseHistoriesAndSameRoomSeedRetained=True)
 with terminal.open('x') as f:json.dump(proof,f,indent=2)
 fcntl.flock(guard,fcntl.LOCK_UN)
print(proof['status'],flush=True)
