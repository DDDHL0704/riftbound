from pathlib import Path
import ast,datetime,fcntl,hashlib,json,os,plistlib,resource,shutil,socket,subprocess
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486');tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
source=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py';nodes=[n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),globals())
pub=load(w/'frozen-fixed4014-native-composition-v1.json');previous=load(w/'live-current-ci-main-owner-terminal-v3.json');assert previous['status']=='PASS_FIXED4014_CI_EXPORTED_DEFAULT_MAIN_PAIR_CANONICAL_COLD_RECONNECT_AND_NORMAL_SCORE_INDEPENDENT_SQL_REPLAY_NOT_VISIBLE_OR_WINDOWS'
assert previous['ownPostgresSmartStopped'] and previous['ownApiStopped'] and previous['allOriginal331AuditSevenTablesExactAtStop'] and previous['allOriginal69NativeSevenTablesExactAtStop'] and len(previous['actualAuditRoomsAtStop'])==331 and len(previous['actualNativeRoomsAtStop'])==72
r=w/'independent-fixed4014-two-network-runtime-v2';assert not r.exists();subprocess.run(['/bin/cp','-cR',pub['apiRuntimeRoot'],str(r)],check=True);assembly='IndependentFixed4014TwoNetworkV2'
for extension in ['.dll','.pdb']:shutil.copy2(w/'independent-fixed4014-two-network-source-v2/bin/Release/net10.0'/(assembly+extension),r/(assembly+extension))
frozen={str(p.relative_to(r)):sha(p) for p in r.rglob('*') if p.is_file()};assert len(frozen)==48 and all(frozen[p]==h for p,h in pub['runtimeFiles'].items())
probe=w/'fixed4014-native-history-reader-runtime-v1/Fixed4014NativeHistoryReaderV1.dll';command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(r/'Riftbound.Api.deps.json'),'--runtimeconfig',str(r/'Riftbound.Api.runtimeconfig.json'),str(probe),'--loaded-inputs'];measurement=json.loads(subprocess.check_output(command,cwd=r,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0')))
assert Path(measurement['baseDirectory'])==r and measurement['actualRuleInputs']==pub['actualRuleInputs'] and len(measurement['assemblies'])==4
for a in measurement['assemblies']:assert Path(a['path'])==r/(a['name']+'.dll') and a['sha256']==frozen[a['name']+'.dll'] and a['mvid']
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof={'status':'RUNNING_INDEPENDENT_FIXED4014_TWO_NETWORK_ORIGINAL_READONLY','startedAtUtc':now(),'fixedCommit':pub['fixedCommit'],'actualLoadedFourAssemblies':measurement,'actualRuntimeFiles':frozen,'lockAtStart':observe_lock(),'actualDatabase':'riftbound_here_native','noLiveWriterOrMatchAction':True};started=False;power=None;audit=native=before_audit=before_native=None
try:
 assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid;sock.mkdir(exist_ok=True);subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'independent-fixed4014-two-network-postgres-v2.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 audit=rooms('riftbound_acceptance');native=rooms('riftbound_here_native');assert audit==previous['actualAuditRoomsAtStop'] and native==previous['actualNativeRoomsAtStop'];before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',native)
 result=w/'independent-fixed4014-two-network-result-v2.json';args=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(r/'Riftbound.Api.deps.json'),'--runtimeconfig',str(r/'Riftbound.Api.runtimeconfig.json'),str(r/(assembly+'.dll')),str(w),str(result)];proof['actualCommand']=args
 with (w/'independent-fixed4014-two-network-v2.log').open('xb') as log:code=subprocess.run(args,cwd=r,env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit',DOTNET_DbgEnableMiniDump='0'),stdout=log,stderr=subprocess.STDOUT,timeout=90).returncode
 proof['independentReadOnlyExitCode']=code;assert code==0;d=load(result);assert d['totals']=={'commands':3,'events':3,'authority':3,'snapshots':4,'prompts':4} and d['actualRuleInputs']==pub['actualRuleInputs'];proof.update(status=d['status'],resultSha256=sha(result),allThreeOriginalCommandAndEventPrefixesFourPrivateViewsAndWholeReplayPass=True)
except BaseException as e:
 proof.update(status='FAILED_INDEPENDENT_FIXED4014_NETWORK_READER_ALL_ORIGINALS_RETAINED',errorType=type(e).__name__,error=str(e));raise
finally:
 if started:
  if before_audit is not None:
   proof['allOriginal331AuditSevenTablesExact']=digests('riftbound_acceptance',audit)==before_audit;proof['allOriginal72NativeSevenTablesExact']=digests('riftbound_here_native',native)==before_native;proof['actualAuditRoomsAtStop']=rooms('riftbound_acceptance');proof['actualNativeRoomsAtStop']=rooms('riftbound_here_native')
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None and power.poll() is None:power.terminate();power.wait(timeout=10)
 proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),all48FrozenRuntimeHashesStable=all(sha(r/p)==h for p,h in frozen.items()),actualLoaderMetadataRetained=True)
 with (w/'independent-fixed4014-two-network-owner-terminal-v2.json').open('x') as f:json.dump(proof,f,indent=2)
 fcntl.flock(guard,fcntl.LOCK_UN)
assert proof['allOriginal331AuditSevenTablesExact'] and proof['allOriginal72NativeSevenTablesExact'] and proof['ownPostgresSmartStopped'] and proof['all48FrozenRuntimeHashesStable'];print(proof['status'],flush=True)
