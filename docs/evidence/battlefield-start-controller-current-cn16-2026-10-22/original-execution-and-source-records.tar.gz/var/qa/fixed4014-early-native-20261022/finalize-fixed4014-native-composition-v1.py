from pathlib import Path
import datetime,hashlib,json,os,subprocess
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();fixed='401470234dcd9dc4d72fe89dd79e99187096277f'
pub=load(w/'fixed4014-native-helper-and-network-frozen-v1.json');native=load(w/'native-app-inputs.json');reader=load(w/'fixed4014-native-history-reader-frozen-v1.json');boot=load(w/'current-native-headless-boot-verification.json');assert native['fixedCommit']==pub['fixedCommit']==boot['fixedCommit']==fixed and boot['status']=='CURRENT_FIXED_DEFAULT_MAIN_HEADLESS_BOOT_PASS'
measure=[]
for label,r,expected in [('api',Path(pub['apiRuntimeRoot']),pub['runtimeFiles']),('helpers',Path(pub['helperRuntimeRoot']),pub['helperRuntimeFiles']),('reader',Path(reader['runtimeRoot']),reader['runtimeFiles'])]:
 assert all(sha(r/p)==h for p,h in expected.items());assert all(not (r/p).is_symlink() for p in expected if p.endswith(('.deps.json','.runtimeconfig.json')))
 command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(r/'Riftbound.Api.deps.json'),'--runtimeconfig',str(r/'Riftbound.Api.runtimeconfig.json'),str(Path(reader['runtimeRoot'])/(reader['assembly']+'.dll')),'--loaded-inputs'];actual=json.loads(subprocess.check_output(command,cwd=r,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0')))
 assert Path(actual['baseDirectory'])==r and actual['actualRuleInputs']==pub['actualRuleInputs'] and len(actual['assemblies'])==4 and actual['hasRoomSeatReplay'] and actual['hasAtomicSeatCommit']
 for a in actual['assemblies']:assert Path(a['path'])==r/(a['name']+'.dll') and a['sha256']==expected[a['name']+'.dll'] and a['mvid']
 measure.append({'runtime':label,'actualCommand':command,'actual':actual,'allRuntimeHashesStable':all(sha(r/p)==h for p,h in expected.items())})
for a in native['apps']:
 p=Path(a['app']);assert all(sha(p/k)==h for k,h in native['ciManagedAndPckPayloads'].items());subprocess.run(['codesign','--verify','--deep','--strict',str(p)],capture_output=True,check=True)
assert len(native['ciManagedAndPckPayloads'])==373 and all(sha(Path(pub['networkRuntimeRoot'])/p)==h for p,h in pub['networkRuntimeFiles'].items())
pub.update(atUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='CURRENT_FIXED4014_LOCAL_API_AND_ACTUAL_CI_EXPORTED_NATIVE_FROZEN_NOT_VISIBLE_OR_WINDOWS',nativeApps=native['apps'],ciManagedAndPckPayloads=native['ciManagedAndPckPayloads'],nativeMain373PayloadsAreActualCiExports=True,nativePackagesNotYetDownloaded=False,actualApiHelpersAndReaderLoaderMeasurementsImmediatelyBeforeProductRun=measure,localHeadlessDefaultMainBootPass=True)
p=w/'frozen-fixed4014-native-composition-v1.json';assert not p.exists();p.write_text(json.dumps(pub,indent=2));print('FROZEN_FIXED4014_COMPOSITION actualCI373 A/B, physicalAPI46 helper87 reader48 currentNet8network22; three actual loaded4assemblies pathsSHA_MVID; ruleidentity',pub['actualRuleInputs']['identitySha256'])
