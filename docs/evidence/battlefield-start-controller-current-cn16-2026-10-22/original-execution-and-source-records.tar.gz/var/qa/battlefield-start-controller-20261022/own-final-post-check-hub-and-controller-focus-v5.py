# -*- coding: utf-8 -*-
from pathlib import Path
import ast,collections,datetime,hashlib,json,os,plistlib,resource,subprocess,xml.etree.ElementTree as ET
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
start=load(w/'only-check-start-inputs-v1.json');end=load(w/'only-check-owner-terminal-v1.json');assert end['exitCode']!=0 and all(end[k] for k in ['all3340SourceHashesAndModesStable','all1419ConformanceRuntimeInputsStable','all23NativeDebugRuntimeInputsStable'])
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
rows=ET.parse(w/'only-check-v1/check/results.trx').findall('.//t:UnitTestResult',ns);failed=[r for r in rows if r.get('outcome')!='Passed']
assert len(rows)==13411 and len(failed)==1 and failed[0].get('testName')=='Riftbound.ConformanceTests.GameHubJoinTests.P79BattlefieldTurnStartDamageSeedDamagesAndDestroysBeforeRuneCall'
inputs={p:sha(root/p) for p in start['sourceInputHashes']};modes={p:oct((root/p).stat().st_mode&0o777) for p in inputs}
changed={p for p,h in inputs.items() if h!=start['sourceInputHashes'][p]};assert changed=={'tests/Riftbound.ConformanceTests/GameHubJoinTests.cs'}
old=(w/'original-GameHubJoinTests-before-P79-priority-calibration.cs.gz').read_bytes();import gzip
before=gzip.decompress(old).decode();after=(root/'tests/Riftbound.ConformanceTests/GameHubJoinTests.cs').read_text()
name='P79BattlefieldTurnStartDamageSeedDamagesAndDestroysBeforeRuneCall';a=before.index(name);b=before.find('\n    [Fact]',a);block=before[a:b]
needle='foreach (var (player, connection) in new[]{("P2", "connection-2"), ("P1", "connection-1")})';replacement='foreach (var (player, connection) in new[]{("P1", "connection-1"), ("P2", "connection-2")})'
assert block.count(needle)==1 and after==before[:a]+block.replace(needle,replacement,1)+before[b:]
with (w/'final-post-check-hub-controller-build-v5.log').open('xb') as log:
 subprocess.run(['/Users/dinghaolin/.dotnet/dotnet','build','tests/Riftbound.ConformanceTests/Riftbound.ConformanceTests.csproj','--no-restore','--nologo'],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
runtime={k:{p:sha(root/p) for p in start[key]} for k,key in [('Conformance','actualConformanceRuntimeFileHashes'),('Native','actualNativeRuntimeFileHashes')]};assert len(runtime['Conformance'])==1419 and len(runtime['Native'])==23
base=root/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0';probe=root/'var/qa/fixed4014-early-native-20261022/fixed4014-native-history-reader-runtime-v2/Fixed4014NativeHistoryReaderV2.dll'
actual=json.loads(subprocess.check_output(['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(base/'Riftbound.ConformanceTests.deps.json'),'--runtimeconfig',str(base/'Riftbound.ConformanceTests.runtimeconfig.json'),str(probe),'--loaded-inputs'],cwd=base,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0')))
assert actual['actualRuleInputs']==start['actualLoadedDebugBaseFourAssembliesAndRuleInputs']['actualRuleInputs']
for row in actual['assemblies']:assert Path(row['path'])==base/(row['name']+'.dll') and row['sha256']==runtime['Conformance'][str((base/(row['name']+'.dll')).relative_to(root))]
definition=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py';nodes=[n for n in ast.parse(definition.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='observe_lock'];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(definition),'exec'),globals())
filters=['GameHubJoinTests','RoomSeatJournalTests','BattlefieldStartControllerTests','FrostHoldTests','FrostHoldNativeTests','DuskRoseLabStartTests','DuskRoseLabNativeTests','OfficialDeckMidgameResolvesFrostHoldTurnStartDamageAndScoreVictoryActionLogReplaysToFinalStateHash','OfficialDeckMidgameResolvesDuskpetalLabTurnStartDestroyDrawAndScoreVictoryActionLogReplaysToFinalStateHash']
command=['python3','scripts/test-rules.py','focus','--include-games']
for value in filters:command+=['--match',value]
output=w/'final-post-check-hub-controller-focus-v5';terminal=w/'final-post-check-hub-controller-owner-terminal-v5.json';assert not output.exists() and not terminal.exists();command+=['--output',str(output)]
proof={'startedAtUtc':now(),'baseCommit':start['baseCommit'],'actualCommand':command,'final3340SourceHashes':inputs,'final3340SourceModes':modes,'onlySourceChangedAfterOriginalCheck':sorted(changed),'finalConformanceRuntimeHashes':runtime['Conformance'],'finalNativeRuntimeHashes':runtime['Native'],'actualCurrentDebugFourLoadedAssembliesAndRuleInputs':actual,'originalCheckFailureRetainedNoSecondCheck':True,'exactOriginalAllHubAssertionsMethodsAndTheoryRowsByteRetainedOnlyPriorityOrderChanged':True,'lockAtStart':observe_lock()}
try:
 with (w/'final-post-check-hub-controller-console-v5.log').open('xb') as log:
  child=subprocess.Popen(command,cwd=root,stdout=log,stderr=subprocess.STDOUT);power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(child.pid)]);proof['exitCode']=child.wait();power.wait(timeout=10)
finally:
 proof.update(finishedAtUtc=now(),lockAtStop=observe_lock(),all3340FinalSourceHashesAndModesStable=all(sha(root/p)==h and oct((root/p).stat().st_mode&0o777)==modes[p] for p,h in inputs.items()),all1419FinalConformanceInputsStable=all(sha(root/p)==h for p,h in runtime['Conformance'].items()),all23FinalNativeDebugInputsStable=all(sha(root/p)==h for p,h in runtime['Native'].items()))
 with terminal.open('x') as f:json.dump(proof,f,indent=2)
assert proof['exitCode']==0 and proof['all3340FinalSourceHashesAndModesStable'] and proof['all1419FinalConformanceInputsStable'] and proof['all23FinalNativeDebugInputsStable']
doc=ET.parse(output/'focus/results.trx');rows=doc.findall('.//t:UnitTestResult',ns);defs={r.get('id'):r.find('t:TestMethod',ns).attrib for r in doc.findall('.//t:UnitTest',ns)};methods={defs[r.get('testId')]['className']+'.'+defs[r.get('testId')]['name'] for r in rows}
assert len(rows)==388 and len(methods)==291 and all(r.get('outcome')=='Passed' for r in rows)
print('PASS final source388cases291methods allHub+allfieldadjacent+twooriginalfull;3340/1419/23stable;originalsolecheckP79failure retained;noSecondCheck',flush=True)
