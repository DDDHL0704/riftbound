# -*- coding: utf-8 -*-
from pathlib import Path
import ast,datetime,hashlib,json,os,plistlib,resource,subprocess
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
parent='401470234dcd9dc4d72fe89dd79e99187096277f';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==parent
pub=load(w/'current-battlefield-controller-real-sql-frozen-inputs-v3.json');inputs=pub['all3340SourceHashes'];modes=pub['all3340SourceModes']
assert len(inputs)==3340 and all(sha(root/p)==h and oct((root/p).stat().st_mode&0o777)==modes[p] for p,h in inputs.items())
sql=load(w/'current-battlefield-controller-real-sql-owner-terminal-v3.json');reader=load(w/'independent-battlefield-controller-sql-owner-terminal-v1.json');readback=load(w/'independent-battlefield-controller-sql-result-v1.json')
assert sql['sqlCase58ExitCode']==0 and sql['allOriginal333AuditSevenTablesExact'] and sql['allOriginal72NativeSevenTablesExact'] and sql['ownPostgresSmartStopped']
assert reader['readerExitCode']==0 and reader['allOriginal338AuditSevenTablesExact'] and reader['allOriginal72NativeSevenTablesExact'] and reader['ownPostgresSmartStopped'] and readback['histories']==22 and readback['refused']==4
for name in ['final-combined-adjacent-and-original-games-owner-terminal-v3.json','final-two-native-adjacent-owner-terminal-v4.json']:
 end=load(w/name);assert end['exitCode']==0 and end['all3340SourceHashesAndModesStable']
baseline=load(root/'var/qa/room-seat-peer-notifications-20261022/only-check-start-inputs-v1.json')
paths={k:{str(p.relative_to(root)):sha(p) for p in (root/folder).rglob('*') if p.is_file() and not str(p.relative_to(root)).startswith(baseline['excludedGeneratedOutputDirectory']+'/')} for k,folder in [('Conformance','tests/Riftbound.ConformanceTests/bin/Debug/net10.0'),('Native','clients/godot/.godot/mono/temp/bin/Debug')]}
assert len(paths['Conformance'])==1419 and len(paths['Native'])==23 and set(paths['Conformance'])==set(baseline['actualConformanceRuntimeFileHashes']) and set(paths['Native'])==set(baseline['actualNativeRuntimeFileHashes'])
runtime=root/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0';probe=root/'var/qa/fixed4014-early-native-20261022/fixed4014-native-history-reader-runtime-v2/Fixed4014NativeHistoryReaderV2.dll'
actual=json.loads(subprocess.check_output(['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(runtime/'Riftbound.ConformanceTests.deps.json'),'--runtimeconfig',str(runtime/'Riftbound.ConformanceTests.runtimeconfig.json'),str(probe),'--loaded-inputs'],cwd=runtime,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0')))
assert Path(actual['baseDirectory'])==runtime and len(actual['assemblies'])==4
for a in actual['assemblies']:assert Path(a['path'])==runtime/(a['name']+'.dll') and a['sha256']==paths['Conformance'][str((runtime/(a['name']+'.dll')).relative_to(root))] and a['mvid']
definition=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py';nodes=[n for n in ast.parse(definition.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='observe_lock'];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(definition),'exec'),globals())
start={'atUtc':now(),'baseCommit':parent,'includesDeclaredUncommittedChanges':True,'sourceInputCount':3340,'sourceInputHashes':inputs,'sourceInputModes':modes,'excludedGeneratedOutputDirectory':baseline['excludedGeneratedOutputDirectory'],'actualConformanceRuntimeFileCount':1419,'actualConformanceRuntimeFileHashes':paths['Conformance'],'actualNativeRuntimeFileCount':23,'actualNativeRuntimeFileHashes':paths['Native'],'actualLoadedDebugBaseFourAssembliesAndRuleInputs':actual,'originalBaselineTrx':'var/qa/room-seat-peer-notifications-20261022/only-check-v1/check/results.trx','expectedCases':13411,'expectedMethods':7540,'onlyOneCheckForCoherentBattlefieldControllerBatch':True,'originalTestsRetainedWithOnlyThreeDeclaredFixtureExpectationCalibrations':True,'originalFullMethods143Pairs110Decks11Seed424242AndVictoryReplayAssertionsPreserved':True,'finalAdjacentActual81Cases35MethodsIncludesBothOriginalFullGames':True,'actualRealSql22Inputs22ColdAndIndependent22Histories39Snapshots39PromptsFourRefusals':True,'ordinaryFullGameVisibleAndWindowsNotInferredFromControlledSql':True,'lockAtStart':observe_lock()}
start['originalBaselineTrxSha256']=sha(root/start['originalBaselineTrx'])
with (w/'only-check-start-inputs-v1.json').open('x') as f:json.dump(start,f,indent=2)
output=w/'only-check-v1';terminal=w/'only-check-owner-terminal-v1.json';assert not output.exists() and not terminal.exists()
command=['python3','scripts/test-rules.py','check','--output',str(output)];proof={'startedAtUtc':now(),'command':command,'lockAtStart':start['lockAtStart'],'currentDebugRuleInputs':actual['actualRuleInputs']}
print('SOLE_BATTLEFIELD_CONTROLLER_CHECK_STARTED_3340_SOURCES_1419_CONFORMANCE_23_NATIVE',flush=True)
try:
 with (w/'only-check-console-v1.log').open('xb') as log:
  child=subprocess.Popen(command,cwd=root,stdout=log,stderr=subprocess.STDOUT);power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(child.pid)]);proof['exitCode']=child.wait();power.wait(timeout=10)
finally:
 proof.update(finishedAtUtc=now(),lockAtStop=observe_lock(),all3340SourceHashesAndModesStable=all(sha(root/p)==h and oct((root/p).stat().st_mode&0o777)==modes[p] for p,h in inputs.items()),all1419ConformanceRuntimeInputsStable=all(sha(root/p)==h for p,h in paths['Conformance'].items()),all23NativeDebugRuntimeInputsStable=all(sha(root/p)==h for p,h in paths['Native'].items()))
 with terminal.open('x') as f:json.dump(proof,f,indent=2)
print(json.dumps(proof),flush=True)
assert proof['exitCode']==0 and all(proof[k] for k in ['all3340SourceHashesAndModesStable','all1419ConformanceRuntimeInputsStable','all23NativeDebugRuntimeInputsStable'])
