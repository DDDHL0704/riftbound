# -*- coding: utf-8 -*-
from pathlib import Path
import datetime,gzip,hashlib,json,shutil
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
for name in ['current-battlefield-controller-real-sql-owner-terminal-v1.json','current-battlefield-controller-real-sql-owner-terminal-v2.json','current-battlefield-controller-real-sql-owner-terminal-v3.json','independent-original-failed-sql-diagnostic-owner-terminal-v2.json','independent-battlefield-controller-sql-owner-terminal-v1.json']:
 assert load(w/name)['ownPostgresSmartStopped']
bits=w/'executed-own-sql-and-independent-reader-bits-v1';bits.mkdir();retained=[]
executed=[('sql-v1',w/'battlefield-controller-real-sql-runtime-v1','Riftbound.PostgresAcceptance'),('sql-v2',w/'battlefield-controller-real-sql-runtime-v2','Riftbound.PostgresAcceptance'),('sql-v3',w/'battlefield-controller-real-sql-runtime-v3','Riftbound.PostgresAcceptance'),('old-failure-diagnostic',w/'independent-current-failed-sql-diagnostic-runtime-v1','IndependentCurrentFailedSqlDiagnosticV1'),('current-independent-reader',w/'independent-battlefield-controller-reader-source-v1/bin/Release/net10.0','IndependentBattlefieldControllerReaderV1')]
for label,folder,assembly in executed:
 for extension in ['.dll','.pdb']:
  original=folder/(assembly+extension);p=bits/(label+'-'+original.name);p.write_bytes(original.read_bytes());assert sha(original)==sha(p)
  retained.append({'original':str(original.relative_to(root)),'retained':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':sha(p)})
assert len(retained)==10
kept=[w/'battlefield-controller-real-sql-runtime-v1',w/'battlefield-controller-real-sql-runtime-v3',bits]
by_hash={}
for folder in kept:
 for p in folder.rglob('*'):
  if p.is_file():by_hash.setdefault(sha(p),[]).append(str(p.relative_to(root)))
v2=load(w/'current-battlefield-controller-real-sql-frozen-inputs-v2.json');diag=load(w/'independent-original-failed-sql-diagnostic-owner-terminal-v1.json')
duplicates=[(w/'battlefield-controller-real-sql-runtime-v2',v2['runtimeFiles']),(w/'independent-current-failed-sql-diagnostic-runtime-v1',diag['runtimeFiles'])]
rows=[];folders=[]
for folder,manifest in duplicates:
 actual={str(p.relative_to(folder)):sha(p) for p in folder.rglob('*') if p.is_file()};assert actual==manifest
 for name,digest in actual.items():
  p=folder/name;assert not p.is_symlink() and digest in by_hash
  rows.append({'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':digest,'allExactRetainedRuntimeOrExecutedBitAlternatives':by_hash[digest]})
 folders.append(folder)
# Only the two finished standalone reader projects; root build and current check
# inputs, original SQL v1/v3 and original databases remain outside this list.
for project in [w/'independent-current-failed-sql-diagnostic-source-v1',w/'independent-battlefield-controller-reader-source-v1']:
 for name in ['bin','obj']:
  folder=project/name
  if not folder.exists():continue
  for p in folder.rglob('*'):
   if p.is_file():rows.append({'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':sha(p),'reason':'FINISHED_STANDALONE_READER_BUILD_CACHE_OWN_EXECUTED_DLL_PDB_AND_SOURCES_RETAINED'})
  folders.append(folder)
manifest=w/'verified-finished-duplicate-and-reader-cache-originals-v1.json.gz';raw=json.dumps({'atUtc':now(),'retainedExecutedOwnBits':retained,'retiredOriginalFileRows':rows,'keptSharedRuntimeRoots':[str(p.relative_to(root)) for p in kept]},indent=2).encode();manifest.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(manifest.read_bytes())==raw
for folder in folders:
 expected={r['path']:r['sha256'] for r in rows if Path(r['path']).is_relative_to(folder.relative_to(root))};actual={str(p.relative_to(root)):sha(p) for p in folder.rglob('*') if p.is_file()};assert actual==expected
 shutil.rmtree(folder)
assert all(sha(root/r['retained'])==r['sha256'] for r in retained)
result={'atUtc':now(),'status':'ONLY_VERIFIED_FINISHED_DUPLICATE_COMPOSITIONS_AND_READER_BUILD_CACHES_RETIRED','files':len(rows),'logicalBytes':sum(r['bytes'] for r in rows),'retainedExecutedOwnBits':10,'originalHashManifest':str(manifest.relative_to(root)),'originalSqlV1AndCurrentSqlV3FrozenRuntimesRemain':True,'rootSourcesCurrentCheckInputsOriginalFailuresAndAllDatabasesUntouched':True,'historicalRetiredRuntimePathsNotClaimedStillPresent':True,'physicalApfsBytesNotInferred':True}
(w/'verified-finished-duplicate-and-reader-cache-retirement-v1.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
