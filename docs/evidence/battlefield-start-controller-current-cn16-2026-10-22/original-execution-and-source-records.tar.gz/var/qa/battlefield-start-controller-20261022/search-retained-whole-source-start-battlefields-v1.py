# -*- coding: utf-8 -*-
from pathlib import Path
import collections,datetime,hashlib,json,re
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=load(root/'docs/audit/current-manifest.json');cnref=next(d['after'] for d in reversed(m['laterSourceDeltas']) if d['kind']=='cn_cards');enref=m['inputs']['en'];activeref=m['inputs']['active']
cn=load(root/cnref['path'])['data'];en=load(root/enref['path'])['cards'];active=load(root/activeref['path'])['cards']
normalize=lambda s:s.upper().replace('\u00b7','-');active_numbers={normalize(c['cardNo']) for c in active};candidates=[]
assert len(cn)==1504 and len(en)==1408 and len(active)==1035
for c in cn:
 categories=c.get('cardCategoryList') or ([c['cardCategory']] if c.get('cardCategory') else [])
 assert isinstance(categories,list) and all(isinstance(t,str) for t in categories)
 text=c.get('cardEffect') or '';assert isinstance(text,str)
 if 'battlefield' in categories and '\u5f00\u59cb' in text:
  candidates.append({'region':'CN','id':c['id'],'printing':c['cardNo'],'name':c['cardName'],'allOriginalRowSha256':hashlib.sha256(json.dumps(c,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'originalText':text,'active':normalize(c['cardNo']) in active_numbers,'candidateSearchIncludesCombatAndOtherStartWording':True})
nulls=[]
for c in en:
 card_type=c['cardType'];assert isinstance(card_type,dict) and isinstance(card_type['type'],list)
 text=c.get('text')
 if text is None:nulls.append(c['id']);body=''
 else:
  assert isinstance(text,dict) and isinstance(text.get('richText'),dict) and isinstance(text['richText'].get('body'),str)
  body=text['richText']['body']
 if any(t.get('id')=='battlefield' for t in card_type['type']) and re.search(r'(?:start|beginning).*?(?:turn|phase)|(?:turn|phase).*?(?:start|beginning)',body,re.I|re.S):
  candidates.append({'region':'GLOBAL','language':'en-US','id':c['id'],'printing':c.get('publicCode'),'name':c['name'],'allOriginalRowSha256':hashlib.sha256(json.dumps(c,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'originalText':body,'active':normalize(c.get('publicCode') or '') in active_numbers,'candidateSearchIncludesCombatAndOtherStartWording':True})
result={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'READ_ONLY_ALL_RETAINED_CN1504_EN1408_SOURCE_START_WORD_CANDIDATE_SEARCH_NOT_FRESH_ALL_GALLERY_OR_SEMANTIC_CERTIFICATION','sourceRefs':{'CN':cnref,'EN':enref,'active':activeref},'allSourcePinsByteExact':all(sha(root/r['path'])==r['sha256'] for r in [cnref,enref,activeref]),'candidateRows':candidates,'english1375StructuredTextRowsRead':len(en)-len(nulls),'english33NullTextRowsRemainUncertified':nulls,'initialStringOnlyEnglishProbeWasIncompleteOnStructuredTextAndNotUsedAsCoverage':True,'full1740UniverseOutside705AndEightEnglishGalleryMissingRowsStillOpen':True,'currentRuntimeCatalogOrSourcesAdopted':False,'wholePrintingOrGoalCertified':False}
assert result['allSourcePinsByteExact'] and len(nulls)==33
f=w/'retained-cn1504-en1408-all-start-battlefield-source-candidates-v1.json';assert not f.exists();f.write_text(json.dumps(result,ensure_ascii=False,indent=2))
for c in candidates:print(c['region'],c['id'],c['printing'],c['name'],'active='+str(c['active']))
