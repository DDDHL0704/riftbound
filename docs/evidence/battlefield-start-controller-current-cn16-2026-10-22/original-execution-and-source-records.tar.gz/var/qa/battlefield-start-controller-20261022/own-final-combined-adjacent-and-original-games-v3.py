# -*- coding: utf-8 -*-
from pathlib import Path
import ast,datetime,hashlib,json,os,plistlib,subprocess,xml.etree.ElementTree as ET
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();load=lambda p:json.loads(p.read_text())
b=load(w/'original-full-source-and-case-retention-before-family-v1.json');paths=set(b['all3337OriginalSourceInputHashes'])|{'src/Riftbound.Engine/BattlefieldStartRecoveryRules.cs','tests/Riftbound.ConformanceTests/BattlefieldStartControllerTests.cs','tests/Riftbound.PostgresAcceptance/BattlefieldStartControllerSqlAcceptance.cs'};inputs={p:sha(root/p) for p in sorted(paths)};modes={p:oct((root/p).stat().st_mode&0o777) for p in paths};assert len(inputs)==3340
source=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py';nodes=[n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='observe_lock'];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),globals())
methods=['OfficialDeckMidgameResolvesFrostHoldTurnStartDamageAndScoreVictoryActionLogReplaysToFinalStateHash','OfficialDeckMidgameResolvesDuskpetalLabTurnStartDestroyDrawAndScoreVictoryActionLogReplaysToFinalStateHash'];command=['python3','scripts/test-rules.py','focus','--include-games','--match','BattlefieldStartControllerTests','--match','FrostHoldTests','--match','DuskRoseLabStartTests'];
for method in methods:command+=['--match',method]
command+=['--output',str(w/'final-combined-adjacent-and-original-games-focus-v3')];proof={'startedAtUtc':now(),'baseCommit':b['baseCommit'],'actualCommand':command,'all3340SourceHashes':inputs,'all3340SourceModes':modes,'originalTwoFullGameMethods':methods,'allOriginalTheoryMethods143Full110PairsSeed424242AndVictoryReplayAssertionsRetained':True,'lockAtStart':observe_lock()};p=w/'final-combined-adjacent-and-original-games-owner-terminal-v3.json';assert not p.exists()
try:
 with (w/'final-combined-adjacent-and-original-games-console-v3.log').open('xb') as log:
  child=subprocess.Popen(command,cwd=root,stdout=log,stderr=subprocess.STDOUT);power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(child.pid)]);proof['exitCode']=child.wait();power.wait(timeout=10)
finally:
 proof.update(finishedAtUtc=now(),lockAtStop=observe_lock(),all3340SourceHashesAndModesStable=all(sha(root/path)==h and oct((root/path).stat().st_mode&0o777)==modes[path] for path,h in inputs.items()));p.write_text(json.dumps(proof,indent=2))
assert proof['exitCode']==0 and proof['all3340SourceHashesAndModesStable']
trx=w/'final-combined-adjacent-and-original-games-focus-v3/focus/results.trx'
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
rows=ET.parse(trx).findall('.//t:UnitTestResult',ns)
assert len(rows)==81 and all(r.get('outcome')=='Passed' for r in rows)
names={r.get('testName').split('(')[0] for r in rows}
assert len(names)==35 and all(any(n.endswith(m) for n in names) for m in methods)
print('PASS actual81cases35methods including both original affected fullgames; all3340source+mode stable; no full143or110claim',flush=True)
