# -*- coding: utf-8 -*-
import pathlib,json,hashlib,gzip,re,subprocess,datetime
root=pathlib.Path('/Users/dinghaolin/MyProjects/riftbound');w=root/'var/qa/battlefield-start-controller-20261022'
b=json.loads((w/'original-full-source-and-case-retention-before-family-v1.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
changed={p for p,h in b['all1801OriginalConformanceFiles'].items() if sha(root/p)!=h}
expected={'tests/Riftbound.ConformanceTests/FrostHoldTests.cs','tests/Riftbound.ConformanceTests/DuskRoseLabStartTests.cs','tests/Riftbound.ConformanceTests/FullGameEndToEndTests.cs'};assert changed==expected
rows=[]
for p in sorted(changed):
 old=subprocess.check_output(['git','show',b['baseCommit']+':'+p],cwd=root);new=(root/p).read_bytes();oldtext=old.decode();newtext=new.decode()
 theory=lambda t:re.findall(r'\[(?:InlineData|MemberData|ClassData)\([^\n]*',t)
 methods=lambda t:re.findall(r'public\s+(?:async\s+)?(?:Task(?:<[^>]+>)?|void)\s+(\w+)\s*\(',t)
 assert theory(oldtext)==theory(newtext) and methods(oldtext)==methods(newtext) and newtext.count('Assert.')>=oldtext.count('Assert.')
 f=w/('original-before-N41-'+pathlib.Path(p).name+'.gz')
 if f.exists():assert gzip.decompress(f.read_bytes())==old
 else:f.write_bytes(gzip.compress(old,mtime=0))
 rows.append({'path':p,'originalSha256':hashlib.sha256(old).hexdigest(),'currentSha256':sha(root/p),'originalMethodsAndTheoryRowsExact':True,'oldAssertExpressions':oldtext.count('Assert.'),'newAssertExpressions':newtext.count('Assert.')})
full='tests/Riftbound.ConformanceTests/FullGameEndToEndTests.cs';original=subprocess.check_output(['git','show',b['baseCommit']+':'+full],cwd=root).decode();current=(root/full).read_text()
added='        Assert.Equal("P1", beforeTurnStart.State.CardObjects[battlefieldObjectId].ControllerId);\n'
needle='        Assert.Equal("P1", triggerEvent.Payload["playerId"]);\n        Assert.Equal([battlefieldObjectId], Assert.IsAssignableFrom<IReadOnlyList<string>>(triggerEvent.Payload["sourceObjectIds"]));'
assert current.count(added)==1 and current.count(needle)==1
normalized=current.replace(added,'',1).replace(needle,needle.replace('Assert.Equal("P1",','Assert.Equal("P2",',1),1);assert normalized==original
oldplan=json.loads((root/'var/qa/room-seat-peer-notifications-20261022/only-check-v1/plan.json').read_text());plan=json.loads((w/'only-check-v1/plan.json').read_text())
oldmethods=set(oldplan['shards'][0]['methods']);newmethods=set(plan['shards'][0]['methods']);assert oldmethods<=newmethods and len(newmethods-oldmethods)==6 and all('BattlefieldStartControllerTests.' in p for p in newmethods-oldmethods)
def fullnames(p):return {line.strip() for line in p.read_text().splitlines() if line.strip().startswith('Riftbound.ConformanceTests.FullGameEndToEndTests.')}
oldfull=fullnames(root/'var/qa/room-seat-peer-notifications-20261022/only-check-v1/discovery.log');newfull=fullnames(w/'only-check-v1/discovery.log');assert oldfull==newfull and len(oldfull)==143
for p,h in b['allNineFullGameSources'].items():
 if p!=full:assert sha(root/p)==h
prior=w/'prior-battlefield-controller-publication-v1';prior.mkdir(exist_ok=True);manifest=root/'docs/audit/current-manifest.json';m=json.loads(manifest.read_text());reviews=root/m['inputs']['reviews']['path']
for p in [manifest,reviews,root/'docs/PROJECT_STATUS.md']:
 f=prior/(p.name+'.gz')
 if f.exists():assert gzip.decompress(f.read_bytes())==p.read_bytes()
 else:f.write_bytes(gzip.compress(p.read_bytes(),mtime=0))
result={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseCommit':b['baseCommit'],'allOriginal1801ConformanceFilesPreservedExceptThreeDeclaredCalibrations':True,'unchangedOriginalFiles':1798,'exactDeclaredCalibrations':rows,'everyOldMethodAndTheoryRowInThreeFilesExact':True,'allNineOriginalFullSourcesEightByteExactAndOneOnlyExactActorExpectationAndAddedPrecondition':True,'all143OriginalPublicFullMethodIdentitiesExact':sorted(newfull),'original110Pairs11Decks424242VictoryReplayAssertionsUnchanged':True,'onlyCheckExpectedOld7534MethodsRetainedPlusSixNew':sorted(newmethods-oldmethods),'newCheckCountsNotYetResults':True,'originalGovernanceManifestReviewsAndStatusPreserved':True,'earlierReadOnlyNormalizationAttemptHadOverbroadStringReplacementNowExactUniqueHunk':True}
f=w/'pre-check-original-method-source-theory-and-assertion-retention-v1.json';assert not f.exists();f.write_text(json.dumps(result,indent=2))
print('PASS1798originalfiles byteexact;3onlydeclaredcalibrations alloldmethodsTheoryrows;143fullidentities;110/11/424242 andvictoryreplay unchanged;checknotyetresult')
