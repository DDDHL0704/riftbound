# -*- coding: utf-8 -*-
from pathlib import Path
import collections,datetime,gzip,hashlib,json,subprocess,xml.etree.ElementTree as ET
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pin=lambda p:{'path':str(p.relative_to(root)),'sha256':sha(p)}
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def read(path):
 doc=ET.parse(path);defs={r.get('id'):r.find('t:TestMethod',ns).attrib for r in doc.findall('.//t:UnitTest',ns)};rows=doc.findall('.//t:UnitTestResult',ns)
 return rows,collections.Counter(r.get('testName') for r in rows),{defs[r.get('testId')]['className']+'.'+defs[r.get('testId')]['name'] for r in rows}
start=load(w/'only-check-start-inputs-v1.json');end=load(w/'only-check-owner-terminal-v1.json')
assert end['exitCode']!=0 and all(end[k] for k in ['all3340SourceHashesAndModesStable','all1419ConformanceRuntimeInputsStable','all23NativeDebugRuntimeInputsStable'])
post=load(w/'final-post-check-hub-controller-owner-terminal-v5.json')
assert post['exitCode']==0 and all(post[k] for k in ['all3340FinalSourceHashesAndModesStable','all1419FinalConformanceInputsStable','all23FinalNativeDebugInputsStable'])
baseline=root/start['originalBaselineTrx'];assert sha(baseline)==start['originalBaselineTrxSha256'];trx=w/'only-check-v1/check/results.trx'
rows,counts,methods=read(trx);oldrows,oldcounts,oldmethods=read(baseline)
assert (len(rows),len(methods),len(oldrows),len(oldmethods))==(13411,7540,13379,7534)
assert collections.Counter(r.get('outcome') for r in rows)=={'Passed':13410,'Failed':1} and not(oldcounts-counts) and oldmethods<=methods
failed=[r.get('testName') for r in rows if r.get('outcome')!='Passed'];assert failed==['Riftbound.ConformanceTests.GameHubJoinTests.P79BattlefieldTurnStartDamageSeedDamagesAndDestroysBeforeRuneCall']
added=counts-oldcounts;added_methods=methods-oldmethods
assert sum(added.values())==32 and len(added_methods)==6 and all('.BattlefieldStartControllerTests.' in name for name in added)
adjacent=[];adjacent_methods=set()
for path in [w/'final-combined-adjacent-and-original-games-focus-v3/focus/results.trx',w/'final-two-native-adjacent-focus-v4/focus/results.trx']:
 r,c,m=read(path);assert all(item.get('outcome')=='Passed' for item in r);adjacent+=r;adjacent_methods.update(m)
assert len(adjacent)==81 and len(adjacent_methods)==35 and len({r.get('testName') for r in adjacent})==81
fulls=[m for m in adjacent_methods if '.FullGameEndToEndTests.' in m];assert len(fulls)==2
assert set(added)=={r.get('testName') for r in adjacent if '.BattlefieldStartControllerTests.' in r.get('testName')}
final_rows,final_counts,final_methods=read(w/'final-post-check-hub-controller-focus-v5/focus/results.trx')
hub_rows,hub_counts,hub_methods=read(root/'var/qa/room-seat-peer-notifications-20261022/all-hub-and-room-seat-focus-v2/focus/results.trx')
adjacent_counts=collections.Counter(r.get('testName') for r in adjacent)
assert len(final_rows)==388 and len(final_methods)==291 and all(r.get('outcome')=='Passed' for r in final_rows)
assert final_counts==hub_counts+adjacent_counts and final_methods==hub_methods|adjacent_methods and failed[0] in final_counts
red,_,redmethods=read(w/'first-red-focus-v1/focus/results.trx');assert len(red)==32 and len(redmethods)==6 and collections.Counter(r.get('outcome') for r in red)=={'Failed':30,'Passed':2}
original=load(w/'original-full-source-and-case-retention-before-family-v1.json');pre=load(w/'pre-check-original-method-source-theory-and-assertion-retention-v2.json')
declared={r['path'] for r in pre['exactDeclaredCalibrations']}|{'tests/Riftbound.ConformanceTests/GameHubJoinTests.cs'};assert len(declared)==4 and len(original['all1801OriginalConformanceFiles'])==1801
assert all(sha(root/p)==h for p,h in original['all1801OriginalConformanceFiles'].items() if p not in declared)
assert all(sha(root/r['path'])==r['currentSha256'] for r in pre['exactDeclaredCalibrations'])
assert all(sha(root/p)==h and oct((root/p).stat().st_mode&0o777)==post['final3340SourceModes'][p] for p,h in post['final3340SourceHashes'].items())
assert {p for p,h in post['final3340SourceHashes'].items() if h!=start['sourceInputHashes'][p]}=={'tests/Riftbound.ConformanceTests/GameHubJoinTests.cs'}
assert post['exactOriginalAllHubAssertionsMethodsAndTheoryRowsByteRetainedOnlyPriorityOrderChanged']
hub_path='tests/Riftbound.ConformanceTests/GameHubJoinTests.cs';old_hub=gzip.decompress((w/'original-GameHubJoinTests-before-P79-priority-calibration.cs.gz').read_bytes()).decode();new_hub=(root/hub_path).read_text()
assert hashlib.sha256(old_hub.encode()).hexdigest()==original['all1801OriginalConformanceFiles'][hub_path]
where=old_hub.index('P79BattlefieldTurnStartDamageSeedDamagesAndDestroysBeforeRuneCall');stop=old_hub.find('\n    [Fact]',where);old_block=old_hub[where:stop]
old_loop='foreach (var (player, connection) in new[]{("P2", "connection-2"), ("P1", "connection-1")})';new_loop='foreach (var (player, connection) in new[]{("P1", "connection-1"), ("P2", "connection-2")})'
assert old_block.count(old_loop)==1 and new_hub==old_hub[:where]+old_block.replace(old_loop,new_loop,1)+old_hub[stop:]
oldsql=json.loads(subprocess.check_output(['git','show',start['baseCommit']+':tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'],cwd=root));sql=load(root/'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json');assert len(oldsql['cases'])==57 and sql['cases'][:57]==oldsql['cases'] and sql['cases'][57:]==[{'id':'battlefield-start-controller','sourceType':'BattlefieldStartControllerSqlAcceptance'}]
independent=load(w/'independent-battlefield-controller-sql-result-v1.json');reader=load(w/'independent-battlefield-controller-sql-owner-terminal-v1.json');writer=load(w/'current-battlefield-controller-real-sql-owner-terminal-v3.json')
assert [independent[k] for k in ['histories','snapshots','prompts','eventCount','refused']]==[22,39,39,63,4]
assert writer['originalAcceptedInputs']==writer['actualColdRecoveries']==22 and reader['allOriginal338AuditSevenTablesExact'] and reader['allOriginal72NativeSevenTablesExact'] and reader['ownPostgresSmartStopped']
result={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'SOLE_CHECK13411_CASES7540_METHODS_ORIGINAL_P79_FAILURE_RETAINED_TEST_ONLY_PRIORITY_CALIBRATION_FINAL_FOCUS388_291_ALL_PASS','baseCommit':start['baseCommit'],'actualCases':13411,'actualMethods':7540,'outcomes':dict(collections.Counter(r.get('outcome') for r in rows)),'originalCaseCount':13379,'originalMethodCount':7534,'oldExactCaseMultisetAndMethodsRetained':True,'originalCheckFailedCaseIdentitiesNotRelabeled':failed,'newCases':32,'newMethods':6,'newCaseIdentities':sorted(added.elements()),'newMethodNames':sorted(added_methods),'preCalibrationAdjacentCases':81,'preCalibrationAdjacentMethods':35,'finalAdjacentCases':388,'finalAdjacentMethods':291,'finalOriginalAffectedFullMethods':sorted(fulls),'firstRedOriginalOutcomes':{'Failed':30,'Passed':2},'all1801OriginalConformanceFilesWith1797ByteExactAndOnlyFourDeclaredCalibrations':True,'originalTestSourceRetention':pin(w/'pre-check-original-method-source-theory-and-assertion-retention-v2.json'),'onlyOneAdditionalTestFilePriorityOrderChangedAfterOriginalCheck':True,'postCalibrationInputsAndExactAllHubAssertionRetention':pin(w/'final-post-check-hub-controller-owner-terminal-v5.json'),'all143PublicFullMethods110PairIds11DecksSeed424242AndVictoryReplayAssertionsRetained':True,'currentAll143And110FixedFullNotClaimedByCheck':True,'actualDebugRuleInputs':post['actualCurrentDebugFourLoadedAssembliesAndRuleInputs']['actualRuleInputs'],'actualWipReleaseSqlRuleInputs':independent['actualRuleInputs'],'sqlOriginal57IdentitiesOrderAndClassesRetainedOnlyCase58Added':True,'actualRealSqlInputs':22,'actualRealSqlColdRecoveries':22,'independentSqlHistories':22,'independentSqlPrivateSnapshots':39,'independentSqlPrivatePrompts':39,'independentSqlEvents':63,'independentActualDbRefusals':4,'allOriginal338Audit72NativeSevenTablesRetained':True,'onlyCheckTrx':pin(trx),'originalBaselineTrx':pin(baseline),'originalCheck3340SourcesAndModes1419Conformance23NativeStableBeforeCalibration':True,'soleCheckNoDatabaseConnectionProvidedActualSqlOnlyFromDedicatedCase58':True,'all3340FinalSourceAndModes1419Conformance23NativeInputsStable':True,'noSecondCheck':True,'newFixedFullAndNewCurrentNativeVisiblePairedAndPhysicalWindows':'OPEN','wholePrintingOrGoalCertified':False}
f=w/'final-only-check-original-retention-v1.json';assert not f.exists();f.write_text(json.dumps(result,indent=2))
print('PASS retention:original sole13411/7540 had13410pass1P79failure retained;exact test-only priority calibration;finalfocus388/291 allpass;realSQL22cold22 independent22/39/39/63 four refusals;3340/1419/23finalstable;143/110/11/424242 retained;fixedfull/products OPEN',flush=True)
