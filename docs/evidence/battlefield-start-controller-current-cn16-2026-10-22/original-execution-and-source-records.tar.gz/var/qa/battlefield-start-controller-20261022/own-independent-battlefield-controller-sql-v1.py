# -*- coding: utf-8 -*-
from pathlib import Path
import ast,datetime,fcntl,hashlib,json,os,plistlib,subprocess
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
source=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes=[n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}]
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),globals())
pub=load(w/'current-battlefield-controller-real-sql-frozen-inputs-v3.json');previous=load(w/'current-battlefield-controller-real-sql-owner-terminal-v3.json');r=Path(pub['runtimeRoot'])
project=w/'independent-battlefield-controller-reader-source-v1';bits=project/'bin/Release/net10.0'
terminal=w/'independent-battlefield-controller-sql-owner-terminal-v1.json';result=w/'independent-battlefield-controller-sql-result-v1.json'
assert not terminal.exists() and not result.exists() and previous['ownPostgresSmartStopped']
with (w/'independent-battlefield-controller-reader-final-build-v1.log').open('xb') as log:
 subprocess.run(['/Users/dinghaolin/.dotnet/dotnet','build',str(project/'probe.csproj'),'-c','Release','--nologo','--no-restore'],stdout=log,stderr=subprocess.STDOUT,check=True)
own={str(p.relative_to(w)):sha(p) for p in [project/'Program.cs',project/'probe.csproj',bits/'IndependentBattlefieldControllerReaderV1.dll',bits/'IndependentBattlefieldControllerReaderV1.pdb']}
def frozen():
 assert all(sha(r/p)==h for p,h in pub['runtimeFiles'].items()) and all(sha(w/p)==h for p,h in own.items())
 assert all(sha(root/p)==h and oct((root/p).stat().st_mode&0o777)==pub['all3340SourceModes'][p] for p,h in pub['all3340SourceHashes'].items())
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof={'status':'RUNNING_INDEPENDENT_READONLY_ORIGINAL_BATTLEFIELD_CONTROLLER_SQL','startedAtUtc':now(),'baseCommit':pub['baseCommit'],'originalSqlOwnerSha256':sha(w/'current-battlefield-controller-real-sql-owner-terminal-v3.json'),'ownSourcesAndExecutedBits':own,'reusesExistingFrozen89RuntimeWithoutAnotherCopy':True,'lockAtStart':observe_lock()}
started=False;power=None
try:
 frozen();assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid
 subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'independent-battlefield-controller-readonly-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 audit=rooms('riftbound_acceptance');native=rooms('riftbound_here_native');assert audit==previous['actualAuditRoomsAtStop'] and len(audit)==338 and native==previous['actualNativeRoomsAtStop'] and len(native)==72
 a=digests('riftbound_acceptance',audit);n=digests('riftbound_here_native',native)
 command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(r/'Riftbound.PostgresAcceptance.deps.json'),'--runtimeconfig',str(r/'Riftbound.PostgresAcceptance.runtimeconfig.json'),str(bits/'IndependentBattlefieldControllerReaderV1.dll'),str(w/'actual-current-battlefield-controller-real-sql-v3'),str(result)]
 proof['actualCommand']=command
 with (w/'independent-battlefield-controller-sql-console-v1.log').open('xb') as log:
  proof['readerExitCode']=subprocess.run(command,cwd=r,env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit',DOTNET_DbgEnableMiniDump='0'),stdout=log,stderr=subprocess.STDOUT,timeout=900).returncode
 assert proof['readerExitCode']==0
 d=load(result);assert d['histories']==22 and d['snapshots']==39 and d['prompts']==39 and d['refused']==4 and d['actualRuleInputs']==pub['actualLoadedFourAssemblyPathsShaMvidAndRuleInputs']['actualRuleInputs'] and Path(d['baseDirectory'])==r
 assert len(d['actualLoadedAssemblies'])==4
 for row in d['actualLoadedAssemblies']:assert Path(row['path'])==r/(row['name']+'.dll') and row['sha256']==pub['runtimeFiles'][row['name']+'.dll'] and row['mvid']
 proof.update(status=d['status'],independentResultSha256=sha(result),actualFourLoadedPathsShaMvid=d['actualLoadedAssemblies'])
except BaseException as e:
 proof.update(status='FAILED_INDEPENDENT_READBACK_OR_ORACLE_ORIGINALS_RETAINED',errorType=type(e).__name__,error=str(e));raise
finally:
 if started:
  proof['allOriginal338AuditSevenTablesExact']=digests('riftbound_acceptance',audit)==a;proof['allOriginal72NativeSevenTablesExact']=digests('riftbound_here_native',native)==n
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None and power.poll() is None:power.terminate();power.wait(timeout=10)
 frozen();proof.update(finishedAtUtc=now(),lockAtStop=observe_lock(),all3340SourcesAndModes89FrozenRuntimeAndExecutedReaderBitsStable=True)
 with terminal.open('x') as f:json.dump(proof,f,indent=2)
 fcntl.flock(guard,fcntl.LOCK_UN)
assert proof['allOriginal338AuditSevenTablesExact'] and proof['allOriginal72NativeSevenTablesExact'] and proof['ownPostgresSmartStopped']
print(proof['status'],flush=True)
