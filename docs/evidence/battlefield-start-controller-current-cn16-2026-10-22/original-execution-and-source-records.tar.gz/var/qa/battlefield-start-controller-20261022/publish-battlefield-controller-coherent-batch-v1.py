# -*- coding: utf-8 -*-
from pathlib import Path
import copy,datetime,gzip,hashlib,io,json,re,tarfile
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
native=root/'var/qa/fixed4014-early-native-20261022';old_execution=root/'var/qa/room-seat-peer-notifications-20261022'
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(path,value):
 with path.open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2)
def pin(path,role=None):
 value={'path':str(path.relative_to(root)),'sha256':sha(path)}
 if role:value['role']=role
 return value
final=load(w/'final-only-check-original-retention-v1.json');assert(final['actualCases'],final['actualMethods'],final['newCases'],final['newMethods'])==(13411,7540,32,6)
start=load(w/'only-check-start-inputs-v1.json');post=load(w/'final-post-check-hub-controller-owner-terminal-v5.json')
assert all(sha(root/p)==h for p,h in post['final3340SourceHashes'].items()) and final['outcomes']=={'Passed':13410,'Failed':1} and final['finalAdjacentCases']==388 and final['finalAdjacentMethods']==291
mp=root/'docs/audit/current-manifest.json';m=load(mp);rp=root/m['inputs']['reviews']['path'];reviews=load(rp)
prior=w/'prior-battlefield-controller-publication-v1'
for path in [mp,rp,root/'docs/PROJECT_STATUS.md']:assert gzip.decompress((prior/(path.name+'.gz')).read_bytes())==path.read_bytes()
oldm=copy.deepcopy(m);oldreviews=copy.deepcopy(reviews);assert(len(reviews['reviews']),len(m['reviewContexts']),len(m['acceptanceGates']),len(m['laterSourceDeltas']))==(163,78,250,7)
baseline=root/'docs/evidence/room-seat-peer-notifications-2026-10-22/final-governance.json.gz';oldgov=json.loads(gzip.decompress(baseline.read_bytes()));assert oldgov['governanceValid'] and len(oldgov['remainingObligations'])==17124
source=load(w/'two-exact-start-battlefield-source-and-core-readback-v1.json');assert source['allTwoCompleteRowsAndQaExactLatestRegistered'] and source['currentCoreOriginalReadback']['sha256']=='d6fd7140f106f9b5b3dc0d5817fd040110fe870a6da9ee335ba7f4f70f892d11'
sql=load(w/'independent-battlefield-controller-sql-result-v1.json');assert [sql[k] for k in ['histories','snapshots','prompts','eventCount','refused']]==[22,39,39,63,4]
previous_native=load(native/'final-current-fixed4014-early-native-same-room-independent-verification-v1.json');assert previous_native['actualMainCommands']==76 and previous_native['actualMainEvents']==495 and previous_native['actualMainPrivateSnapshots']==previous_native['actualMainPrivatePrompts']==147
old_failure=load(old_execution/'ci9633-entire-original-failure-and57-sql-independent-verification-v3.json');assert old_failure['actualOutcomes']=={'Passed':13505,'Failed':13} and old_failure['actualSql']['caseCount']==57
fullpath=w/'ci4014-entire-full-independent-verification-v1.json';full=load(fullpath) if fullpath.exists() else None
if full:assert full['actualCases']==13528 and full['actualMethods']==7675 and full['sql']['caseCount']==57 and len(full['jobs'])==11 and all(s=='success' for s in full['jobs'].values())
identity='battlefield-start-controller-current-cn16-2026-10-22';document='docs/BATTLEFIELD_START_CONTROLLER_CURRENT_CN16_AUDIT_2026-10-22.md';ev=root/'docs/evidence/battlefield-start-controller-current-cn16-2026-10-22';ev.mkdir();assert not any(ev.iterdir())

oldmap_path=root/'docs/evidence/room-seat-peer-notifications-2026-10-22/archive-map.json';oldmap=load(oldmap_path);old_by_sha={}
for row in oldmap['members']:old_by_sha.setdefault(row['sha256'],row)
members={};reuse=[];excluded=[];paths=[];runtime_dirs={p.name for base in [w,native] for p in base.iterdir() if p.is_dir() and 'runtime' in p.name.lower()}
for base in [w,native]:paths.extend(p for p in base.rglob('*') if p.is_file())
for p in old_execution.iterdir():
 if p.name.startswith(('ci9633','exact-fixed9633')):paths.extend(p.rglob('*') if p.is_dir() else [p])
paths.extend(old_execution/p for p in ['verify-completed-fixed9633-original-failure-and57sql-v3.py','download-completed-fixed9633-nine-originals-after-failure-v2.py'])
secret=re.compile(rb'(?i)(?:playerKey|reconnectToken)[\"\s]*[:=][\s\"]*((?:rt_|qa-)[a-z0-9_+/-]{16,})')
for p in sorted(set(paths)):
 if not p.is_file():continue
 parts=set(p.relative_to(root).parts)
 if runtime_dirs&parts or {'bin','obj','__pycache__'}&parts or any(part.endswith('.app') for part in parts) or p.name in {'mac-ci-artifact.zip','windows-ci-artifact.zip'}:continue
 raw=p.read_bytes();inspect=raw
 if p.suffix=='.gz':
  try:inspect=gzip.decompress(raw)
  except OSError:pass
 if p.name=='additional-global-vendetta-overview-original-v1.html.gz':
  excluded.append({'path':str(p.relative_to(root)),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'reason':'FULL_ADDITIONAL_GLOBAL_OVERVIEW_ORIGINAL_RETAINED_LOCALLY_ONLY_SHORT_PRIMARY_DATE_QUOTE_AND_COMPLETE_HASH_PUBLISHED'});continue
 if (p.name.startswith('session-') and p.suffix=='.json') or (p.suffix in {'.json','.log','.ndjson','.txt','.gz'} and secret.search(inspect)):
  excluded.append({'path':str(p.relative_to(root)),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'reason':'CURRENT_PRIVATE_QA_AUTH_MATERIAL_ORIGINAL_RETAINED_LOCALLY_NOT_PUBLISHED'});continue
 name=str(p.relative_to(root));digest=hashlib.sha256(raw).hexdigest()
 if digest in old_by_sha:reuse.append({'path':name,'sha256':digest,'existingArchiveMember':old_by_sha[digest]['path'],'existingArchiveMap':pin(oldmap_path)})
 else:members[name]=p
archive=ev/'original-execution-and-source-records.tar.gz';archive_rows=[]
with tarfile.open(archive,'w:gz',compresslevel=9) as tar:
 for name,p in sorted(members.items()):
  raw=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(raw);info.mode=p.stat().st_mode&0o777;info.mtime=0;tar.addfile(info,io.BytesIO(raw));archive_rows.append({'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
with tarfile.open(archive,'r:gz') as tar:
 assert set(tar.getnames())=={r['path'] for r in archive_rows}
 for row in archive_rows:
  raw=tar.extractfile(row['path']).read();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
write(ev/'archive-map.json',{'atUtc':now(),'archive':pin(archive),'members':archive_rows,'existingIdenticalOlderArchiveMembersNotDuplicated':reuse,'privateExclusionsRetainedLocally':excluded,'allBytesHashesAndClosedSetVerified':True,'applicationsInstallersSdksAndFrozenRuntimeDependenciesNotDuplicated':True})
copies={'final-original-test-and-input-retention.json':w/'final-only-check-original-retention-v1.json','current-exact-two-source-and-core-readback.json':w/'two-exact-start-battlefield-source-and-core-readback-v1.json','current-all16-rule-version-readback.json':w/'current-cn-rule-directory-and-known-source-versions-v1.json','active1035-all-primary-category-shapes-consumer-search.json':w/'all-primary-category-shapes-finite-consumers-v2.json','retained-cn1504-en1408-start-word-candidate-search.json':w/'retained-cn1504-en1408-all-start-battlefield-source-candidates-v1.json','additional1906-c-d-semantic-disposition.json':w/'additional-current-1906-c-and-d-semantic-disposition-v1.json','current-real-sql-original-writer.json':w/'current-battlefield-controller-real-sql-owner-terminal-v3.json','independent-current-real-sql-history-and-refusals.json':w/'independent-battlefield-controller-sql-result-v1.json','preceding-fixed4014-locked-native-pair-normal-score-and-replay.json':native/'final-current-fixed4014-early-native-same-room-independent-verification-v1.json','preceding-fixed9633-complete-original-failure-and57-sql.json':old_execution/'ci9633-entire-original-failure-and57-sql-independent-verification-v3.json','space-verified-finished-duplicate-retirement.json':w/'verified-finished-duplicate-and-reader-cache-retirement-v1.json'}
if full:copies['preceding-fixed4014-complete-full.json']=fullpath
else:copies['preceding-fixed4014-original-ci-state-before-publication.json.gz']=w/'ci4014-original-current-state-before-N41-publication-v1.json.gz'
copies['additional-global-regional-release-date-source-supplement.json']=w/'additional-global-regional-release-date-source-supplement-v1.json'
for name,path in copies.items():(ev/name).write_bytes(path.read_bytes())
rule_refs=['DOC-01-P029-B006','DOC-01-P029-B007','DOC-01-P029-B008','DOC-01-P029-B009','DOC-01-P029-B010','DOC-01-P030-B007','DOC-01-P030-B010']
source_manifest={'schemaVersion':1,'id':identity,'atUtc':now(),'region':'CN','language':'zh-CN','applicableAsOf':'2026-10-22','adoptedCoreEffectiveDate':'2026-10-16','scope':'Two existing battlefield-start consumers: capture controlled field actor, use turn actor only for uncontrolled Frost, keep original skill actor after source changes, independently validate literal finite definitions and original journal birth/replay. Existing Dusk Rose your-start eligibility is unchanged. Clause190.6.d establishes no you-referent when uncontrolled; dedicated execution and post-birth source/LKI coverage remain OPEN.','exactPrintings':['UNL-212/219','UNL-209/219'],'exactApiIds':[34765,34762],'exactRuleRecords':rule_refs,'currentSourceReadback':pin(ev/'current-exact-two-source-and-core-readback.json'),'all16SourceVersions':pin(ev/'current-all16-rule-version-readback.json'),'primaryCoreSha256':source['currentCoreOriginalReadback']['sha256'],'corePublicationOriginalUpdatedDate':'2026-10-10','coreEffectiveDateFromExistingOfficialTitle':'2026-10-16','exactCardPublicationAndEffectiveDatesIndependentlyConfirmed':False,'exactCardCompleteRowsAndQaNullsUnchanged':True,'onlyCheckNoDatabaseConnectionProvided':True,'realSqlExecutionIsDedicatedNewCase58OnlyOriginal57AwaitNewFixedFull':True,'allOldSourceAcquisitionPublicationEffectiveAndRegionDatesRetained':True,'currentBoundedTwoCardAnd16RuleSourceVersionChangesDetected':False,'additional1906CDSemanticDisposition':pin(ev/'additional1906-c-d-semantic-disposition.json'),'laterSourceDeltasRemainSevenUnmodified':True,'wholeScopeRetained':{'printings':1740,'ruleRecords':14293,'activeCatalog':1035,'outsideActive':705,'CNRawRows':1504,'ENReturned':1408,'ENReported':1416,'ENUnreturnedGap':8,'CNOfficialNewsScope':139,'globalKdaFiveExactPrintingApplicabilityGates':'OPEN'},'implementationStrategy':'Existing finite shared flow and independent recovery guard; no general DSL, provenance payload schema expansion or legacy match migration. Existing recorded Frost scenario gains only its actually referenced missing second battlefield.','actualDebugRuleInputs':final['actualDebugRuleInputs'],'actualReleaseSqlRuleInputs':sql['actualRuleInputs'],'archive':pin(archive),'archiveMap':pin(ev/'archive-map.json'),'newFixedFullAndNativeVisiblePhysicalWindows':'OPEN','semanticCoverageCertified':False}
source_manifest['additionalGlobalRegionalReleaseDateSupplement']=pin(ev/'additional-global-regional-release-date-source-supplement.json')
source_manifest['noGlobalDateSourceRevisionChangeClaimedWithoutPriorRawComparison']=True
write(ev/'source-manifest.json',source_manifest);sp=pin(ev/'source-manifest.json','source-manifest')
branches=[]
for case in final['newCaseIdentities']:
 branches.append({'id':'bf-start-'+hashlib.sha256(case.encode()).hexdigest()[:24],'sourceRefs':['UNL-212/219']+rule_refs,'sourceManifest':sp,'state':'RECORDED','boundedCase':{'actualExecutedCase':case,'issue':'https://github.com/DDDHL0704/riftbound/issues/84','actualNewMatrixIsFrostOnlyDuskRoseExistingAdjacentEligibilityNotExpanded':True},'semanticReview':{'state':'BOUNDED_CURRENT_CN190_6_191_5_CONTROLLER_AND_ORIGINAL_BIRTH_REVIEW'},'implementation':{'state':'CAPTURED_ACTOR_AND_INDEPENDENT_LITERAL_ORIGINAL_JOURNAL_AND_STRICT_REPLAY_VALIDATION'},'testExecution':{'state':'ACTUAL32_NEW_ORIGINAL_SOLE13411_CHECK_ONE_OLD_P79_PRIORITY_FAILURE_RETAINED_THEN_TEST_ONLY_CALIBRATION_FINAL388_FOCUS_TWO_ORIGINAL_FULL_AND_REAL_SQL22_COLD22_INDEPENDENT22_39_39_FOUR_REFUSALS_PASS'},'fixedCommitCi':{'state':'PENDING_NEW_FIXED_FULL'},'productAcceptance':{'state':'OPEN_NEW_FIXED_CANDIDATE_NATIVE_PAIR_RECONNECT_SCORE_HISTORY_VISIBLE_AND_PHYSICAL_WINDOWS'},'decision':{'state':'OPEN','reason':'Bounded local behavior passes; new fixed full and actual current product acceptance remain required.'},'wholePrintingCertified':False,'existingAcceptanceGateDependencies':['FIXED_CURRENT_CANDIDATE_FULL','VISIBLE_PAIRED_SQL_NETWORK_SCORE_REPLAY','USER_WINDOWS_RUNTIME']})
assert len(branches)==32;write(ev/'thirty-two-exact-controller-behavior-branches.json',{'branches':branches})
refresh=[]
for review_id,context in m['reviewContexts'].items():
 changes=[]
 for ref in context['implementation']:
  current=sha(root/ref['path'])
  if current!=ref['sha256']:changes.append({'path':ref['path'],'before':ref['sha256'],'after':current});ref['sha256']=current
 if changes:
  refresh.append({'id':review_id,'changes':changes,'oldCompleteContext':oldm['reviewContexts'][review_id]})
  context.update(currentImplementationCommit=start['baseCommit'],currentImplementationIncludesUncommittedChanges=True,ciState='PENDING',currentBattlefieldControllerInputRefresh={'sourceManifest':sp,'onlyCurrentImplementationRefsAndExplicitPendingStateRefreshed':True,'oldCompleteContextSourceEvidenceBranchesAndReceiptsRetained':True,'newFixedFullAndProducts':'OPEN','noAdditionalWholePriorFindingSemanticCertification':True})
assert len(refresh)==49
m['reviewContexts']['frost-controlled-start-source-finding-2026-10-22']['currentBoundedControllerRepairFollowup']={'review':identity,'sourceManifest':sp,'originalCounterexampleAndIssue84Retained':True,'localBoundedImplementationAndTestsAndActualSql':'PASS','newFixedFullAndCurrentProducts':'OPEN','wholeFindingOrGoalClosed':False}
(ev/'complete-prior-contexts-current-input-refresh.json.gz').write_bytes(gzip.compress(json.dumps(refresh,ensure_ascii=False,indent=2).encode(),mtime=0))
implementation=['src/Riftbound.Engine/CoreRuleEngine.BattlefieldStart.cs','src/Riftbound.Engine/BattlefieldStartRecoveryRules.cs','src/Riftbound.Engine/MatchRecovery.cs','src/Riftbound.Engine/MatchSession.cs']
m['reviewContexts'][identity]={'evidenceCommit':start['baseCommit'],'currentImplementationCommit':start['baseCommit'],'currentImplementationIncludesUncommittedChanges':True,'ciState':'PENDING','ciReceipts':[],'region':'CN','language':'zh-CN','applicableAsOf':'2026-10-22','adoptedCoreEffectiveDate':'2026-10-16','sourceManifest':sp,'implementation':[pin(root/p,'implementation') for p in implementation],'verificationSources':[pin(root/p,'verification-source') for p in ['tests/Riftbound.ConformanceTests/BattlefieldStartControllerTests.cs','tests/Riftbound.ConformanceTests/FrostHoldTests.cs','tests/Riftbound.ConformanceTests/DuskRoseLabStartTests.cs','tests/Riftbound.ConformanceTests/FullGameEndToEndTests.cs','tests/Riftbound.ConformanceTests/GameHubJoinTests.cs','tests/Riftbound.PostgresAcceptance/BattlefieldStartControllerSqlAcceptance.cs','tests/Riftbound.PostgresAcceptance/Program.cs','tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json']],'branches':branches,'evidence':[pin(ev/name,role) for name,role in [('final-original-test-and-input-retention.json','focus-check-and-retention'),('independent-current-real-sql-history-and-refusals.json','independent-sql-history-refusals')]]}
reviews['reviews'].append({'id':identity,'scope':source_manifest['scope'],'subjects':['UNL-212/219','UNL-209/219'],'ruleRecords':rule_refs,'status':'BOUNDED_CURRENT_CN_SOURCE_CONTROLLER_CAPTURE_FINAL_FOCUS_PASS_ORIGINAL_SOLE_CHECK_P79_FAILURE_RETAINED_REAL_SQL_INDEPENDENT_HISTORY_PASS_NEW_FIXED_FULL_PRODUCTS_OPEN','sourceManifest':sp,'auditDocument':document,'validation':{'newCases':32,'newMethods':6,'finalAdjacentCases':388,'finalAdjacentMethods':291,'affectedOriginalFullGameMethods':2,'onlyCheckCases':13411,'onlyCheckMethods':7540,'originalOnlyCheckOutcomes':{'Passed':13410,'Failed':1},'originalP79FailureRetainedThenOnlyPriorityOrderCalibrated':True,'sqlCase58OnlyNewFiveBranches':True,'sqlInputs':22,'sqlColdRecoveries':22,'independentAuthorityHistories':22,'independentPrivateSnapshots':39,'independentPrivatePrompts':39,'independentEvents':63,'actualCorruptOrWrongVersionRefusals':4,'wholePrintingCertified':False},'exclusions':['Uncontrolled Dusk Rose timing, copied or transferred battlefield abilities beyond implemented consumers, outside-active705, all source gaps and whole printings remain OPEN.','Recorded controlled SQL scenes are not ordinary full matches or visible native acceptance.','New fixed full and current native/network/normal-score/full-history/visible/physical Windows gates remain independent.','Original SQL v1 scenario and v2 event-reader oracle failures, all accepted inputs and old CI9633 failure remain original.']})
assert reviews['reviews'][:163]==oldreviews['reviews'] and m['acceptanceGates']==oldm['acceptanceGates'] and m['laterSourceDeltas']==oldm['laterSourceDeltas'] and m['certificationScope']==oldm['certificationScope']
assert(len(reviews['reviews']),len(m['reviewContexts']),len(m['acceptanceGates']))==(164,79,250)
rp.write_text(json.dumps(reviews,ensure_ascii=False,indent=2)+'\n');m['inputs']['reviews']['sha256']=sha(rp)
m['currentBattlefieldStartControllerInputChange']={'sourceManifest':sp,'auditDocument':document,'issue':'https://github.com/DDDHL0704/riftbound/issues/84','onlyNewBoundedBranches':32,'all163OldReviews250GatesAndSevenDeltasExact':True,'all78OldCompleteContextsInOriginalArchive49ExplicitInputRefreshes':True,'original17124RemainingIdsMustRemain':True,'expectedRemainingObligations':17156,'newFixedFullAndCurrentProducts':'OPEN','wholePrintingOrGoalComplete':False}
m['precedingFixed4014BoundedLockedNativePairScoreAndAllHistoryReplay']=pin(ev/'preceding-fixed4014-locked-native-pair-normal-score-and-replay.json')
m['precedingFixed9633ActualCompleteFailureAnd57SqlReadback']=pin(ev/'preceding-fixed9633-complete-original-failure-and57-sql.json')
m['additionalGlobalRegionalReleaseDateSourceReadback']={'source':pin(ev/'additional-global-regional-release-date-source-supplement.json'),'all705OutsideActivePrintingApplicabilityStillOpen':True,'noRuntimeAdoptionOrRuleEffectiveDateInference':True,'originalSourceUniverseAndCn139NewsScopeUnchanged':True}
if full:m['precedingFixed4014ActualCompleteFullCiReadback']=pin(ev/'preceding-fixed4014-complete-full.json')
else:m['precedingFixed4014ObservedCiStateBeforeCurrentPublication']=pin(ev/'preceding-fixed4014-original-ci-state-before-publication.json.gz')
mp.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
write(ev/'publication-original-governance-object-retention.json',{'atUtc':now(),'oldReviews':163,'oldContexts':78,'oldGates':250,'oldDeltas':7,'oldRemainingIds':17124,'newBranches':32,'expectedRemainingObligations':17156,'explicitImplementationPinRefreshedContexts':49,'otherCompleteContextsExact':29,'allOldReviewsGatesDeltasAndCertificationScopeExact':True,'allOldCompleteContextsSavedBeforeRefresh':True,'baselineGovernance':pin(baseline),'semanticCoverageCertified':False})
ci_text='固定4014完整CI十一项成功，独立核实13528例/7675方法、143完整方法/151例、110配对/十一牌组/424242、57SQL以及原15网络拒绝零泄露和新双方tick2推送。' if full else '固定4014完整CI仍待实际终态，已有范围不得提升为完整通过。'
text='''# 战场开始技能控制者与原始触发日志的限定审查

本批CN/zh-CN、适用2026-10-22，核心规则10-16生效。[来源manifest](evidence/battlefield-start-controller-current-cn16-2026-10-22/source-manifest.json)保留精确34765冰霜要塞、34762暮色玫瑰实验室和190.6/191.5条款、取得/发布/生效日期及哈希。16份已知规则文档原哈希一致，15次HTTP304；两API完整字段和QA未变，无相同PDF副本。Goal active / NOT READY。

[#84](https://github.com/DDDHL0704/riftbound/issues/84)原反例仍保留：受另一玩家控制的冰霜要塞错误归回合玩家，继而使用错误巨龙。现从战场控制者捕获技能控制者；仅未受控制时用回合玩家兜底。来源之后换控制者或新一代不转移既有技能。实验室原“你的开始”资格不扩张。190.6.c是指定选择者覆盖，190.6.d明确未受控制战场的“你”不指代任何人；相应专门执行及后续来源/技能信息时机审查仍OPEN，不由Frost矩阵提升认证。

生产入口使用既有共享流程；恢复检查独立列明两精确技能的原文数值，按既有TRIGGER_QUEUED与原接受指令事件区间绑定原控制者/来源。篡改技能与投影不能冒充原触发；连原事件一同伪造仍被严格原指令回放拒绝。缺日志在空指令早退前拒绝。未增加通用DSL、事件来源登记系统或旧局迁移。

原1801份Conformance文件中1797份逐字不变；四份仅校准控制者期望、同一控制者排序夹具及原Hub响应顺序。全部旧方法/Theory行/有意义断言保留，九份完整源码中八份逐字不变、一份只加原场地控制者前提并校准单一事件控制者；143公共完整方法、110配对、十一牌组、424242及胜利/回放断言完整。

新32例/6方法，首轮30红2绿原件保留。校准前focus78/33加原生交互相邻3/2，共81/35，包含两场原完整胜利/回放；中间汇总计数及旧完整队列排序假设错误原件保留。唯一check13411/7540实际13410过、一条原Hub的P79响应顺序失败，零跳过，原13379/7534多重集合完整加32/6，3340源/模式、1419Conformance、23原生Debug输入稳定。检查结束后仅将P79的P2先响应改为实际控制者P1先响应，全部原断言逐字保留，最终全部Hub/规则族/两原完整focus388/291全过且最终3340/1419/23稳定；原失败不回填，无第二check，新固定full仍独立待核。

真实SQL新增第58项，原57项身份/顺序/类原样。五新受控场景22原输入、22冷恢复；独立逐条回放22历史、39快照、39提示、63事件，四实际篡改/错版分支拒绝。包括一致伪造控制者及私有投影、一并伪造原事件、缺历史和自洽错实现身份。原338审计72原生七表全部保持，数据库正常停止。受控开发场景不充当普通完整对局。

SQL最初三条原输入暴露既有Frost场景引用缺失OTHER战场；只补该实际场地、区域和位置。第二轮六输入/六冷恢复已正确，JSON字符串验证把JsonElement与string比较而误报；仅改验证读取，新五局执行最终结果，旧两个失败局与每条原输入完整保留，不重写或迁移。

此前固定4014实际CI导出的默认Main双端在锁屏下同进程冷重连，三条生产交互指令后同局续17条正常动作，76命令495事件、第44回合8:0；独立全部76历史/147快照/147提示及严格原开局回放通过。原选择器错误在59命令/332事件处停止的原失败保留，仅定位实际己方同名场地后续同局，不重提历史。它不覆盖本批新控制者输入，也不代替可见控件、双窗或Windows实机。

旧9633整次CI真实失败：13518/7671中13505过、13个SQL准备失败，其他九任务成功，57SQL独立原门禁通过；失败full门禁在写产物前中止，只有八个原验证ZIP，未虚构第九个。原143完整方法和110配对通过也不提升该整次失败。CI_CURRENT_TEXT

活跃1035行以1011单类与24多类完整读取确认两现有消费者；24行是有效多类结构。另对已登记CN1504/EN1408逐行做开始字样候选搜索，英文1375结构化文本/33空文本分开，未称新全图库刷新。1740精确印次/14293条款、目录外705、英文报告1416但返回1408的八缺口、139中文新闻范围和K/DA五精确身份门禁均保留。

另独立登记官方GLOBAL/en-US《The Vendetta Overview》的英中7月31日发售短原文、取得时间、正文哈希与版本身份；2026年取自该公告明确发布年并标记上下文推断，不以商品发售日充当规则生效日。目录外705不能统称未来预览，仍逐项保留适用性、限制和实现义务；中文售前正文访问失败也保留，不据标题闭合缺口。该补充不增加CN139新闻计数、不改变目录或1740总范围。

原163审查、250门禁、七源增量与全部旧义务身份原样。78完整旧上下文保存；49项当前实现绑定显式刷新并置新full待核，29项原样，不把旧语义证据提升。新增32限定分支至17156义务，164审查/79上下文，semanticCoverageCertified=false。仅最新A/B及每平台一包；228份已核对的完成副本/缓存退役27477930逻辑字节，10个实际执行的SQL/独立读者DLL/PDB保留，不推定APFS物理回收。新固定full及当前产品、可见双端、Windows仍各自OPEN。
'''.replace('CI_CURRENT_TEXT',ci_text)
(root/document).write_text(text)
status='2026-10-22 本批：[战场开始技能控制者与原触发日志](BATTLEFIELD_START_CONTROLLER_CURRENT_CN16_AUDIT_2026-10-22.md)。现行16文档及冰霜/实验室完整来源未换版，按190.6/191.5捕获实际战场控制者，独立原触发/严格日志恢复，实验室专门执行等仍OPEN。新32/6，唯一check13411/7540实际13410过一原P79响应顺序失败，原13379/7534全留，3340/1419/23稳定。检查后仅校准P79响应顺序并保留全部断言，最终全部Hub/战场族/两原完整focus388/291全过，原失败不回填，无第二check。原143/110/11/424242与Theory及断言完整，原1801文件仅四声明校准、1797份逐字不变。\n\n真实SQL只加58，五新局22输入/22冷恢复，独立22历史/39快照39提示/63事件及四实际拒绝通过；原338审计72原生七表不变。早期场地缺失与JSON字符串验证误报原局不重写。固定4014锁屏默认Main双端76/495正常8:0、同进程重连及全原76/147/147历史回放通过，不覆盖本批新输入或可见/Windows。'+ci_text+'原9633整次13失败及57SQL八产物证明完整保留。\n\n原163审查/250门禁/七源增量完整，78旧上下文全留、49当前绑定显式待新full；17124旧义务加32至17156，164审查79上下文，语义false。全1740/14293及705/八英文/139新闻/KDA来源缺口保留，只有最新双端/每平台一包，228份完成重复退役27477930逻辑字节。新固定full、当前原生/可见/Windows与全量目标仍OPEN。Goal active / NOT READY。\n\n以下原批按原范围与当时终态保留。\n\n'
status_path=root/'docs/PROJECT_STATUS.md';old_status=gzip.decompress((prior/'PROJECT_STATUS.md.gz').read_bytes()).decode();assert old_status.startswith('# 当前项目状态\n\n');status_path.write_text('# 当前项目状态\n\n'+status+old_status[len('# 当前项目状态\n\n'):])
print('PUBLISHED N41 bounded32;164reviews79contexts250gates7deltas;49explicitpins;17124oldIds+32expected17156;governance independent readback still required',flush=True)
