from pathlib import Path
import ast,datetime,fcntl,hashlib,json,os,plistlib,resource,socket,subprocess
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486');tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
source=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py';nodes=[n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),globals())
pub=load(w/'current-battlefield-controller-real-sql-frozen-inputs-v3.json');previous=load(w/'current-battlefield-controller-real-sql-owner-terminal-v2.json');assert previous['ownPostgresSmartStopped'] and previous['allOriginal332AuditSevenTablesExact'] and previous['allOriginal72NativeSevenTablesExact']
r=Path(pub['runtimeRoot']);output=w/'actual-current-battlefield-controller-real-sql-v3';terminal=w/'current-battlefield-controller-real-sql-owner-terminal-v3.json';assert not output.exists() and not terminal.exists()
def frozen():
 assert all(sha(r/p)==h for p,h in pub['runtimeFiles'].items()) and all(sha(root/p)==h and oct((root/p).stat().st_mode&0o777)==pub['all3340SourceModes'][p] for p,h in pub['all3340SourceHashes'].items())
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof={'status':'RUNNING_CURRENT_WIP_REAL_SQL_FINITE_BATTLEFIELD_START_CONTROLLER_AND_ORIGINAL_TRIGGER_REJECTION','startedAtUtc':now(),'baseCommit':pub['baseCommit'],'includesDeclaredUncommittedFiniteChanges':True,'actualLoadedFourAssemblies':pub['actualLoadedFourAssemblyPathsShaMvidAndRuleInputs'],'actualDatabase':'riftbound_acceptance','actualConnectionProvided':True,'onlyNewSqlCase58SelectedAll57OriginalRetained':True,'lockAtStart':observe_lock()};started=False;power=None;audit=native=before_audit=before_native=None
try:
 frozen();assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid;sock.mkdir(exist_ok=True);subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'current-battlefield-controller-real-sql-postgres-v3.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 audit=rooms('riftbound_acceptance');native=rooms('riftbound_here_native');assert audit==previous['actualAuditRoomsAtStop'] and len(audit)==333 and native==previous['actualNativeRoomsAtStop'] and len(native)==72;before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',native)
 command=['/Users/dinghaolin/.dotnet/dotnet',str(r/'Riftbound.PostgresAcceptance.dll'),'--battlefield-start-controller-only'];proof['actualCommand']=command
 with (w/'current-battlefield-controller-real-sql-v3.log').open('xb') as log:code=subprocess.run(command,cwd=r,env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit',RIFTBOUND_POSTGRES_EVIDENCE=str(output),DOTNET_DbgEnableMiniDump='0'),stdout=log,stderr=subprocess.STDOUT,timeout=900).returncode
 proof['sqlCase58ExitCode']=code;assert code==0
 receipts=[load(p) for p in sorted((output/'battlefield-start-controller').rglob('receipt.json'))];assert len(receipts)==5 and {d['branch'] for d in receipts}=={'normal','actor-and-context','actor-context-and-event','no-history','wrong-inputs'};assert sum(d['originalAcceptedInputs'] for d in receipts)==sum(d['coldRecoveries'] for d in receipts)==22 and all(d['actualRuleInputs']==pub['actualLoadedFourAssemblyPathsShaMvidAndRuleInputs']['actualRuleInputs'] for d in receipts)
 assert all(d['deliberateTamperRecoveryRejected']==(d['branch']!='normal') for d in receipts);added=set(rooms('riftbound_acceptance'))-set(audit);assert added=={d['room'] for d in receipts}
 proof.update(status='PASS_CURRENT_WIP_REAL_SQL22_ORIGINAL_INPUTS22_COLD_SOURCE_CONTROLLER_NORMAL_RESOLUTION_AND_FOUR_REAL_DB_TAMPER_OR_WRONG_VERSION_REFUSALS',receipts=receipts,ownNewAuditRooms=sorted(added),originalAcceptedInputs=22,actualColdRecoveries=22,actualRealDbRefusals=4,ordinaryFullGameOrNativeVisibleAcceptanceClaimed=False)
except BaseException as e:
 proof.update(status='FAILED_CURRENT_WIP_REAL_SQL_ORACLE_OR_RUNTIME_ORIGINAL_INPUTS_AND_PARTIAL_ROOMS_RETAINED',errorType=type(e).__name__,error=str(e));raise
finally:
 if started:
  if before_audit is not None:
   proof['allOriginal333AuditSevenTablesExact']=digests('riftbound_acceptance',audit)==before_audit;proof['allOriginal72NativeSevenTablesExact']=digests('riftbound_here_native',native)==before_native;proof['actualAuditRoomsAtStop']=rooms('riftbound_acceptance');proof['actualNativeRoomsAtStop']=rooms('riftbound_here_native')
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None and power.poll() is None:power.terminate();power.wait(timeout=10)
 frozen();proof.update(finishedAtUtc=now(),lockAtStop=observe_lock(),all3340SourceHashesModesAnd89FrozenRuntimeFilesStable=True)
 with terminal.open('x') as f:json.dump(proof,f,indent=2)
 fcntl.flock(guard,fcntl.LOCK_UN)
assert proof['allOriginal333AuditSevenTablesExact'] and proof['allOriginal72NativeSevenTablesExact'] and proof['ownPostgresSmartStopped'];print(proof['status'],flush=True)
