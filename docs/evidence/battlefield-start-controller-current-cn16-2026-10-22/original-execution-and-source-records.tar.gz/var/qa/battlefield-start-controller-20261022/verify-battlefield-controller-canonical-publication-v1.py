# -*- coding: utf-8 -*-
from pathlib import Path
import copy,datetime,gzip,hashlib,json,tarfile
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pin=lambda p:{'path':str(p.relative_to(root)),'sha256':sha(p)}
prior=w/'prior-battlefield-controller-publication-v1';old=json.loads(gzip.decompress((prior/'current-manifest.json.gz').read_bytes()));oldreviews=json.loads(gzip.decompress((prior/'review-decisions.json.gz').read_bytes()))
m=load(root/'docs/audit/current-manifest.json');reviews=load(root/m['inputs']['reviews']['path']);identity='battlefield-start-controller-current-cn16-2026-10-22';ev=root/'docs/evidence/battlefield-start-controller-current-cn16-2026-10-22'
assert len(reviews['reviews'])==164 and reviews['reviews'][:163]==oldreviews['reviews'] and len(m['reviewContexts'])==79 and m['acceptanceGates']==old['acceptanceGates'] and m['laterSourceDeltas']==old['laterSourceDeltas'] and m['certificationScope']==old['certificationScope']
assert all(m['inputs'][k]==v for k,v in old['inputs'].items() if k!='reviews') and m['cardCoverageManifest']==old['cardCoverageManifest'] and m['officialNewsObligations']==old['officialNewsObligations'] and m['historicalReviewPin']==old['historicalReviewPin']
refresh=json.loads(gzip.decompress((ev/'complete-prior-contexts-current-input-refresh.json.gz').read_bytes()));indexed={r['id']:r for r in refresh};assert len(refresh)==len(indexed)==49
finding='frost-controlled-start-source-finding-2026-10-22';unchanged=0
for key,original in old['reviewContexts'].items():
 current=copy.deepcopy(m['reviewContexts'][key]);follow=current.pop('currentBoundedControllerRepairFollowup',None) if key==finding else None
 if key not in indexed:assert current==original;unchanged+=1;continue
 row=indexed[key];assert row['oldCompleteContext']==original
 diffs=[];expected=copy.deepcopy(original)
 for ref in expected['implementation']:
  actual=sha(root/ref['path'])
  if actual!=ref['sha256']:diffs.append({'path':ref['path'],'before':ref['sha256'],'after':actual});ref['sha256']=actual
 assert diffs==row['changes'] and diffs
 metadata=current.pop('currentBattlefieldControllerInputRefresh');assert metadata['oldCompleteContextSourceEvidenceBranchesAndReceiptsRetained'] and metadata['newFixedFullAndProducts']=='OPEN' and metadata['noAdditionalWholePriorFindingSemanticCertification']
 for field in ['currentImplementationCommit','currentImplementationIncludesUncommittedChanges','ciState']:
  actual=current.pop(field);expected.pop(field,None)
  assert actual=={'currentImplementationCommit':'401470234dcd9dc4d72fe89dd79e99187096277f','currentImplementationIncludesUncommittedChanges':True,'ciState':'PENDING'}[field]
 assert current==expected
assert unchanged==29
context=m['reviewContexts'][identity];final=load(ev/'final-original-test-and-input-retention.json');source=load(ev/'source-manifest.json');branches=context['branches']
assert len(branches)==32 and {b['boundedCase']['actualExecutedCase'] for b in branches}==set(final['newCaseIdentities'])
assert all(b['decision']['state']=='OPEN' and not b['wholePrintingCertified'] and b['fixedCommitCi']['state']=='PENDING_NEW_FIXED_FULL' for b in branches)
for ref in [context['sourceManifest']]+context['implementation']+context['verificationSources']+context['evidence']:assert sha(root/ref['path'])==ref['sha256']
assert len(context['implementation'])==4 and len(context['verificationSources'])==8
assert source['region']=='CN' and source['language']=='zh-CN' and source['applicableAsOf']=='2026-10-22' and source['adoptedCoreEffectiveDate']=='2026-10-16' and source['exactApiIds']==[34765,34762] and source['allOldSourceAcquisitionPublicationEffectiveAndRegionDatesRetained'] and not source['semanticCoverageCertified']
assert source['wholeScopeRetained']=={'printings':1740,'ruleRecords':14293,'activeCatalog':1035,'outsideActive':705,'CNRawRows':1504,'ENReturned':1408,'ENReported':1416,'ENUnreturnedGap':8,'CNOfficialNewsScope':139,'globalKdaFiveExactPrintingApplicabilityGates':'OPEN'}
assert final['outcomes']=={'Passed':13410,'Failed':1} and final['finalAdjacentCases']==388 and final['finalAdjacentMethods']==291 and final['onlyOneAdditionalTestFilePriorityOrderChangedAfterOriginalCheck']
dates=load(ev/'additional-global-regional-release-date-source-supplement.json');assert dates['regionDateInterpretation']['yearIsContextualInferenceFromExplicit2026PublicationNotPrintedInTheShortKeyDatesLine'] and dates['regionalDateDoesNotCertifyEveryPrintingLegalityOrSemantics'] and len(dates['shortExactReleaseQuote'].split())<=25 and dates['full1740Universe14293Rules705OutsideActiveAndEightEnglishGalleryGapRetained']
post=load(w/'final-post-check-hub-controller-owner-terminal-v5.json');assert all(sha(root/p)==h and oct((root/p).stat().st_mode&0o777)==post['final3340SourceModes'][p] for p,h in post['final3340SourceHashes'].items())
mapping=load(ev/'archive-map.json');archive=root/mapping['archive']['path'];assert sha(archive)==mapping['archive']['sha256'];rows=mapping['members'];names={r['path'] for r in rows};assert len(rows)==len(names)
assert not any(any(part.endswith('.app') or part in {'bin','obj','__pycache__'} for part in Path(name).parts) or Path(name).name in {'mac-ci-artifact.zip','windows-ci-artifact.zip','session-a.json','session-b.json'} for name in names)
assert not any(Path(name).name=='additional-global-vendetta-overview-original-v1.html.gz' for name in names)
with tarfile.open(archive,'r:gz') as tar:
 assert set(tar.getnames())==names
 for row in rows:
  raw=tar.extractfile(row['path']).read();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
previous_maps={}
for row in mapping['existingIdenticalOlderArchiveMembersNotDuplicated']:
 p=root/row['existingArchiveMap']['path'];assert sha(p)==row['existingArchiveMap']['sha256'];key=str(p)
 if key not in previous_maps:
  oldmap=load(p);oldarchive=root/oldmap['archive']['path'];assert sha(oldarchive)==oldmap['archive']['sha256'];previous_maps[key]=tarfile.open(oldarchive,'r:gz')
 assert hashlib.sha256(previous_maps[key].extractfile(row['existingArchiveMember']).read()).hexdigest()==row['sha256']
for tar in previous_maps.values():tar.close()
retired=json.loads(gzip.decompress((w/'verified-finished-duplicate-and-reader-cache-originals-v1.json.gz').read_bytes()));bits=retired['retainedExecutedOwnBits'];assert len(bits)==10
for bit in bits:assert sha(root/bit['retained'])==bit['sha256'] and bit['retained'] in names
sql=load(ev/'independent-current-real-sql-history-and-refusals.json');assert [sql[k] for k in ['histories','snapshots','prompts','eventCount','refused']]==[22,39,39,63,4]
native=load(ev/'preceding-fixed4014-locked-native-pair-normal-score-and-replay.json');assert native['actualMainCommands']==76 and native['actualMainEvents']==495 and native['actualMainPrivateSnapshots']==native['actualMainPrivatePrompts']==147 and native['physicalWindows']=='OPEN' and native['visiblePairedWindows']=='OPEN'
old_failure=load(ev/'preceding-fixed9633-complete-original-failure-and57-sql.json');assert old_failure['actualOutcomes']=={'Passed':13505,'Failed':13} and old_failure['actualSql']['caseCount']==57 and old_failure['ninthFullGateArtifactDeliberatelyAbsentBecauseChildRuleFailureRaisedBeforeOutputWrite']
govpath=w/'postpublication-current-governance-v1.json';gov=load(govpath);assert gov['governanceValid'] and gov['errors']==[] and not gov['semanticCoverageCertified'] and gov['currentReviewCount']==164
baseline=json.loads(gzip.decompress((root/'docs/evidence/room-seat-peer-notifications-2026-10-22/final-governance.json.gz').read_bytes()));oldids={r['id'] for r in baseline['remainingObligations']};newids={r['id'] for r in gov['remainingObligations']};expected={'BRANCH:'+identity+':'+b['id'] for b in branches}
assert len(oldids)==17124 and len(newids)==17156 and oldids<=newids and newids-oldids==expected
raw=govpath.read_bytes();canonical=ev/'final-governance.json.gz';assert not canonical.exists();canonical.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(canonical.read_bytes())==raw
proof={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'CANONICAL_N41_ALL163_OLD_REVIEWS250_GATES7_DELTAS_78_OLD_COMPLETE_CONTEXTS_EXPLICIT49_REFRESH_AND17124_OLD_IDS_PLUS32_VERIFIED','oldReviewsExact':163,'oldCompleteContextsPreserved':78,'explicitCurrentInputRefreshes':49,'otherContextsExact':29,'oldGatesExact':250,'oldDeltasExact':7,'newReviews':164,'newContexts':79,'newRemainingObligationCount':17156,'old17124IdsRetained':True,'onlyNew32BoundedBranchIds':True,'allOriginal143FullMethods110Pairs11Decks424242TheoryAndVictoryReplayAssertionsRetained':True,'allArchiveMemberBytesHashesAndClosedSetVerified':True,'archiveMemberCount':len(rows),'archiveBytes':archive.stat().st_size,'identicalPreviousArchiveReuse':len(mapping['existingIdenticalOlderArchiveMembersNotDuplicated']),'tenActualExecutedOwnSqlReaderBitsRetained':True,'current3340SourceHashesAndModesStable':True,'actualSoleCheck':{'cases':13411,'methods':7540,'passed':13410,'failed':1,'newCases':32,'newMethods':6,'originalP79FailureNeverRelabeled':True},'finalFocusAfterOnlyTestPriorityCalibration':{'cases':388,'methods':291,'passed':388},'actualRealSql':{'inputs':22,'coldRecoveries':22,'independentHistory':22,'snapshots':39,'prompts':39,'events':63,'refusals':4},'preceding4014Native76_495_147_147NotCurrentOrVisible':True,'original9633FailedFullPreserved':True,'canonicalGovernance':pin(canonical),'semanticCoverageCertified':False,'newFixedFullCurrentNativeVisibleAndPhysicalWindows':'OPEN','wholePrintingOrGoalCertified':False}
f=ev/'independent-publication-and-retention-verification.json';assert not f.exists();f.write_text(json.dumps(proof,indent=2));print('PASS canonical164/79/250/7;all17124oldIDs+32=17156;alloldcompletecontexts preserved49explicitpins;archive',len(rows),archive.stat().st_size,'semanticfalse',flush=True)
