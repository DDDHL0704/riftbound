# -*- coding: utf-8 -*-
from pathlib import Path
import ast,copy,datetime,gzip,hashlib,json
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;ev=root/'docs/evidence/battlefield-start-controller-current-cn16-2026-10-22'
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def pin(p,role=None):
 value={'path':str(p.relative_to(root)),'sha256':sha(p)}
 if role:value['role']=role
 return value
postpath=w/'final-post-check-hub-controller-owner-terminal-v5.json';post=load(postpath);path='scripts/tests/test_sql_ci_gate.py';p=root/path
old=gzip.decompress((w/'original-test-sql-ci-gate-before-case58-calibration.py.gz').read_bytes()).decode();new=p.read_text()
addition="        self.assertEqual('battlefield-start-controller', self.ids[57])\n"
assert new.count("self.assertEqual(58, result['caseCount'])")==1 and new.count(addition)==1
assert new.replace("self.assertEqual(58, result['caseCount'])","self.assertEqual(57, result['caseCount'])",1).replace(addition,'',1)==old
assert hashlib.sha256(old.encode()).hexdigest()==post['final3340SourceHashes'][path]
names=lambda text:[n.name for n in ast.walk(ast.parse(text)) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith('test_')]
assert names(old)==names(new)
current={k:sha(root/k) for k in post['final3340SourceHashes']};assert {k for k,h in current.items() if h!=post['final3340SourceHashes'][k]}=={path}
assert all(oct((root/k).stat().st_mode&0o777)==v for k,v in post['final3340SourceModes'].items())
assert all(sha(root/k)==h for k,h in post['finalConformanceRuntimeHashes'].items()) and all(sha(root/k)==h for k,h in post['finalNativeRuntimeHashes'].items())
failed=(w/'all-python-verification-tools-v1.log').read_text();passed=(w/'all-python-verification-tools-v2.log').read_text();assert 'Ran 74 tests' in failed and 'FAILED (failures=1)' in failed and "AssertionError: 57 != 58" in failed and 'Ran 74 tests' in passed and passed.rstrip().endswith('OK')
mp=root/'docs/audit/current-manifest.json';m=load(mp);rp=root/m['inputs']['reviews']['path'];reviews=load(rp);identity='battlefield-start-controller-current-cn16-2026-10-22';context=m['reviewContexts'][identity];review=reviews['reviews'][-1];assert review['id']==identity
assert not any(ref['path']==path for c in m['reviewContexts'].values() for ref in c['implementation'])
record={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'FINAL_VERIFICATION_FIXTURE_ONLY_CASE58_LITERAL_COUNT_AND_EXACT_ID_CALIBRATION_ALL74_TOOLS_PASS','onlyAdditionalSourceAfterFinal388Focus':{'path':path,'beforeSha256':hashlib.sha256(old.encode()).hexdigest(),'afterSha256':sha(p),'exactCorrection':'57 to 58 literal expected default SQL count plus exact battlefield-start-controller identity at original ordinal57; every old test method and other assertion unchanged'},'allOriginal74VerificationMethodsRetained':True,'original74ToolOneFailureNeverRelabeled':pin(w/'all-python-verification-tools-v1.log'),'final74ToolAllPass':pin(w/'all-python-verification-tools-v2.log'),'baseFinal388FocusSourceAndRuntimeManifest':pin(postpath),'final3340SourceManifestReconstruction':'Use base final3340 hashes and modes; replace only this declared verification-test file hash, all other sources/modes and1419Conformance23Native files are exact.','allGameplayAndClrPayloadsByteExactSinceFinal388Focus':True,'actualRuleInputsDebugUnchanged':post['actualCurrentDebugFourLoadedAssembliesAndRuleInputs']['actualRuleInputs'],'newFixedFullStillRequiredForFinalWholeInputSet':True,'onlyCheckOriginal13410Pass1P79FailRetainedNoSecondCheck':True,'oldCompleteCurrentNewContextBeforeVerificationAddition':copy.deepcopy(context),'oldCompleteCurrentNewReviewBeforeVerificationAddition':copy.deepcopy(review),'wholePrintingOrGoalCertified':False}
out=ev/'final-verification-case58-count-calibration-and-input-delta.json'
if out.exists():
 original=load(out);assert {k:v for k,v in original.items() if k!='atUtc'}=={k:v for k,v in record.items() if k!='atUtc'}
else:out.write_text(json.dumps(record,indent=2))
ref=pin(out,'verification-fixture-calibration')
context['verificationSources'].append(pin(p,'verification-source'));context['evidence'].append(ref);context['currentVerificationOnlyInputCalibration']=ref
review['validation']['postRegistrationPythonVerificationFixture']={'originalMethods':74,'originalOutcome':'73PASS_1_OLD57COUNT_FAILURE_RETAINED','finalOutcome':'74PASS','onlyLiteral58AndExactNewCaseIdentityAdded':True,'allOtherMethodsAndAssertionsRetained':True,'evidence':ref}
rp.write_text(json.dumps(reviews,ensure_ascii=False,indent=2)+'\n');m['inputs']['reviews']['sha256']=sha(rp);m['currentBattlefieldStartControllerInputChange']['finalVerificationOnlyInputCalibration']=ref;mp.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
note='原脚本检查74方法中一项仍固定要求57SQL而失败；原结果保留。只将该独立期望改为58并新增第58项精确身份断言，全部原方法和其他断言逐字保留，最终74方法全过。该验证脚本是最终388focus之后唯一额外源码变化，游戏代码及1419/23运行载荷逐字不变，最终输入另由新固定full验证；不重跑check。'
doc=root/'docs/BATTLEFIELD_START_CONTROLLER_CURRENT_CN16_AUDIT_2026-10-22.md';text=doc.read_text().replace('且最终3340/1419/23稳定','且该focus期间3340/1419/23稳定');needle='原163审查、250门禁';assert text.count(needle)==1;doc.write_text(text.replace(needle,note+'\n\n'+needle,1))
status=root/'docs/PROJECT_STATUS.md';text=status.read_text();needle='原163审查/250门禁/七源增量完整';assert text.count(needle)==1;status.write_text(text.replace(needle,'脚本74原一项旧57SQL计数失败保留，仅校准58及新精确身份后74全过；该脚本为focus后唯一额外源变化，游戏/CLR不变，最终输入待新固定full，无第二check。\n\n'+needle,1))
print('FINAL_INPUTS onlySQLgate-test delta after388focus;all74methods preserved andpass;allgameplay/1419/23 exact;originalfailures kept;rootmanifest current context adds explicitverification9',flush=True)
