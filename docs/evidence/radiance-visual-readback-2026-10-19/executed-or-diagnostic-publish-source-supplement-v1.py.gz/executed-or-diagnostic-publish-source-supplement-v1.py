import copy
import datetime
import hashlib
import json
import os
import pathlib
import shutil
import subprocess

r = pathlib.Path.cwd()
n = pathlib.Path(__file__).resolve().parent
native = r / 'var/qa/empty-reveal-followup-20261019'
e = r / 'docs/evidence/radiance-visual-readback-2026-10-19'
base = 'f537973255ca7dde8dba288efe5f1b5f81d39f6e'
fixed = '797f813c03a739141ba4a8fbe1bb9921337bd351'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
write = lambda p, d: p.write_text(json.dumps(d, ensure_ascii=False, indent=2) + '\n')
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == base
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True)
assert not subprocess.check_output(['git', 'diff', fixed, '--', 'src', 'clients', 'tests', 'scripts', 'data'], text=True)
mp = r / 'docs/audit/current-manifest.json'
rp = r / 'docs/evidence/rules-reaudit-2026-10-11/review-decisions.json'
prior_manifest = load(mp)
prior_reviews_sha = sha(rp)
assert len(prior_manifest['acceptanceGates']) == 221 and len(prior_manifest['reviewContexts']) == 54
assert len(load(rp)['reviews']) == 139 and len(prior_manifest['laterSourceDeltas']) == 5
assert load(native / 'fixed-native-independent-verification-v1.json')['status'].startswith('PASS')
assert load(native / 'fixed-native-independent-verification-v1.json')['ownPostgresSmartStopped']
assert not e.exists()
e.mkdir()
(e / 'raw').mkdir()
archives = []

def pin(path, role=None):
    return {'path': str(path.relative_to(r)), 'sha256': sha(path), 'role': role or path.stem}

def archive(path, name, hardlink=False):
    destination = e / name
    assert path.is_file() and not destination.exists()
    if hardlink:
        os.link(path, destination)
    else:
        shutil.copyfile(path, destination)
    assert sha(destination) == sha(path)
    archives.append({'originalPath': str(path.relative_to(r)), 'canonical': pin(destination),
        'bytes': path.stat().st_size, 'samePhysicalRawFileHardlinked': hardlink})
    return destination

for path in sorted(n.iterdir()):
    if not path.is_file():
        continue
    if path.name.startswith('I') and path.suffix in ['.jpg', '.png', '.svg', '.webp']:
        archive(path, 'raw/' + path.name, True)
    elif path.suffix == '.json':
        archive(path, 'original-' + path.name)
    elif path.name.endswith(('.html.gz', '.txt.gz')):
        archive(path, path.name, True)
    elif path.suffix == '.py':
        import gzip
        destination = e / ('executed-or-diagnostic-' + path.name + '.gz')
        destination.write_bytes(gzip.compress(path.read_bytes(), mtime=0))
        archives.append({'originalPath': str(path.relative_to(r)), 'canonical': pin(destination),
            'uncompressedSha256': sha(path), 'bytes': path.stat().st_size, 'samePhysicalRawFileHardlinked': False})

for label, path in [
    ('prior-en-overview', r / 'var/qa/paka-move-reveal-20261019/radiance-overview-next-frontier.html.gz'),
    ('prior-zh-overview', r / 'var/qa/battlefield-positive-play-20261017/source-current/the-radiance-overview.html.gz'),
    ('prior-zh-prerift', r / 'var/qa/battlefield-positive-play-20261017/source-current/preparing-for-the-radiance-pre-rift.html.gz')]:
    archive(path, label + '.html.gz', True)

native_names = ['fixed-release-publication-inputs-v1.json', 'fixed-release-rule-inputs-v1.json',
    'fixed-release-sql-verification-v1.json', 'fixed-independent-sql-verification-v1.json',
    'fixed-independent-sql-reader-result-v1.json', 'current-native-headless-boot-verification.json',
    'native-app-inputs.json', 'fixed-native-download-v1.json', 'fixed-background-native-build-v1.json',
    'exported-graceful-pair-verification.json', 'exported-stale-retry-v2-verification-v1.json',
    'score-without-desktop-verification.json', 'fixed-socket-identity-verification-v1.json',
    'fixed-native-independent-verification-v1.json', 'fixed-native-independent-reader-result-v1.json',
    'prior-native-pair-retirement.json']
capsule = {'fixedCommit': fixed, 'actualRuleInputs': load(native / 'fixed-release-rule-inputs-v1.json'),
    'status': 'ACTUAL_CURRENT797F_LOCKED_SCOPED_ACCEPTANCE_NOT_VISIBLE_OR_PHYSICAL_WINDOWS',
    'records': {name: {'originalPath': str((native / name).relative_to(r)), 'sha256': sha(native / name), 'record': load(native / name)} for name in native_names},
    'scope': 'Current frozen797f Release SQL2; actual exported Main result/retry; two production gateways cold recovery and normal45commands359events8:0; socket15 identity rejections0private leaks; independent actual stored originals. Not a new source-supplement runtime certificate.',
    'visibleControlsPairedScoringAndPhysicalWindows': 'OPEN', 'sourceSupplementDoesNotAdoptNewRuntimeInputs': True}
write(e / 'fixed797f-locked-acceptance.json', capsule)
for name in ['exported-graceful-original-frame.json.gz', 'exported-stale-retry-v2-original-frame.json.gz',
             'score-paired-before-restart-original-frame.json.gz', 'score-paired-after-continuation-original-frame.json.gz']:
    archive(native / name, 'fixed797f-' + name, True)
for name in ['original-paired-wire-views.json.gz', 'original-private-wire-timeline.json.gz']:
    archive(native / 'score-network-evidence' / name, 'fixed797f-' + name, True)

old_index_path = r / 'docs/evidence/pakaa-move-reveal-2026-10-19/radiance-next-frontier-index.json'
old_index = load(old_index_path)
first = load(n / 'all37-visual-checkpoint-v1.json')
extra = load(n / 'two-existing-metadata-image-acquisition-v1.json')['records']
current = load(n / 'article-version-recheck-corrected-v3.json')
current_en = next(row for row in current['records'] if row['label'] == 'en-overview')
raw_records = first['rawReferences'] + [{'id': row['id'], 'url': row['url'], 'path': row['path'],
    'sha256': row['rawSha256'], 'obtainedAtUtc': row['receivedAtUtc'], 'bytes': row['bytes']} for row in extra]
assert len(raw_records) == 39 and len({row['id'] for row in raw_records}) == 39
url_to_id = {row['url']: row['id'] for row in raw_records}
assert set(current_en['allPageImageUrls']) <= set(url_to_id)
refs = []
for row in raw_records:
    path = e / 'raw' / pathlib.Path(row['path']).name
    assert sha(path) == row['sha256']
    refs.append({'id': row['id'], 'url': row['url'], 'raw': pin(path, 'official-raw-image'),
        'obtainedAtUtc': row['obtainedAtUtc'], 'bytes': row['bytes'], 'publicationDate': None, 'effectiveDate': None,
        'sourceLanguage': 'en-US', 'publisherRegion': 'GLOBAL_CN_DISPOSITION_OPEN',
        'pixelsActuallyRead': True, 'inCurrentEnPageResponse': row['url'] in current_en['allPageImageUrls'],
        'wholePrintingCertified': False})
faces = load(n / 'face-identity-reconciliation-v1.json')
image_pins = {ref['id']: ref['raw'] for ref in refs}
normalized_faces = copy.deepcopy(faces)
for face in normalized_faces['faces']:
    face['canonicalImage'] = image_pins[face['sourceImageId']]
write(e / 'face-identity-reconciliation.json', normalized_faces)
supplemental = []
for number in faces['eightPrintedNumberCandidatesNotMatchedInThis1740Ledger']:
    matching = [face for face in normalized_faces['faces'] if face['normalizedNumberCandidateOnly'] == number]
    assert matching
    supplemental.append({'id': 'SOURCE-PRINTING-CANDIDATE:' + number, 'normalizedLookupCandidate': number,
        'printedReadings': [face['printedNumberAsRead'] for face in matching], 'faces': matching,
        'state': 'OPEN', 'sourceFact': 'OFFICIAL_IMAGE_READ_PRINTED_NUMBER_NOT_MATCHED_IN_FROZEN1740_LEDGER',
        'officialStructuredApiIdentity': 'UNRESOLVED_DO_NOT_INVENT_OR_MERGE', 'publicationDate': None, 'effectiveDate': None,
        'semanticReview': 'VISUAL_IDENTITY_FACT_ONLY', 'implementation': 'NOT_RUNTIME_ADOPTED',
        'testExecution': 'OPEN_IF_APPLICABLE', 'fixedCommitCi': 'PENDING_SOURCE_INDEX_CI', 'productAcceptance': 'OPEN_IF_APPLICABLE',
        'wholePrintingCertified': False})
write(e / 'supplemental-printing-obligations.json', {'status': 'EIGHT_EXPLICIT_UNRESOLVED_SOURCE_PRINTING_CANDIDATES',
    'historicalStructuredLedgerCountUnchanged': 1740, 'candidates': supplemental,
    'notAClaimTheCompleteOfficialUniverseHasOnly1748Printings': True,
    'sameNumberPromoStampsAndSpNamespaceStillSeparateOpenRequirement': True})
manifest = {'recordedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'BOUNDED_VISUAL_SOURCE_INTAKE_AND_EXACT_IDENTITY_GAPS_NOT_WHOLE_RULE_CERTIFICATION',
    'certificationBaseline': {'region': 'CN', 'language': 'zh-CN', 'applicableAsOf': '2026-10-16'},
    'sourceScope': {'publisherRegion': 'GLOBAL_OFFICIAL', 'sourceLanguage': 'en-US',
        'sourceUrl': old_index['sourceUrl'], 'sourceId': old_index['sourceId'],
        'articlePublishedAtFromCms': '2026-09-25T22:30:00.000Z', 'articleStatesUpdated': '2026-10-16',
        'individualPrintingPublicationAndEffectiveDates': 'UNKNOWN_NOT_INFERRED_FROM_ARTICLE_OR_HTTP_LAST_MODIFIED',
        'cnRegionalPrecedenceAndFormatLegality': 'OPEN'},
    'original37ReferenceObjectsRetainedExact': old_index['images'], 'original146TextBlocksRetainedViaFrozenIndex': pin(old_index_path),
    'versionedReferenceUnion': refs, 'originalBladesImageReferences': 37, 'expandedHistoricalWholePageReferences': 39,
    'currentEnWholePageReferences': 38, 'actualReadRasterOriginals': 37, 'actualReadSvgOriginalsViaDerivedRenders': 2,
    'all39HaveExactRawHashAcquisitionTimeAndVisualDisposition': True,
    'sourceVisualParts': [pin(e / ('original-' + name)) for name in ['visual-readback-v2.json',
        'second-five-visual-readback-v3.json', 'ten11-20-visual-readback-v1.json', 'last17-visual-readback-v1.json',
        'two-existing-metadata-visual-readback-v1.json']],
    'currentArticleVersions': pin(e / 'original-article-version-recheck-corrected-v3.json'),
    'auxiliaryPageObservation': {'historicalReferenceId': 'GLOBAL-RADIANCE-OVERVIEW-20260925-I002',
        'url': old_index['images'][1]['url'], 'currentPresence': False,
        'historicalContext': {'path': ['blades', 5, 'items', 8, 'media', 'url'], 'bladeType': 'articleCardCarousel'},
        'classification': 'RELATED_ARTICLE_CAROUSEL_RESPONSE_DIFFERENCE_RICH_ARTICLE_BODY_UNCHANGED',
        'oldReferenceAndRawImageRetained': True, 'sourceCardOrRuleChangeInferred': False,
        'twoExpandedMetadataUrlsAlreadyPresentInHistoricalRaw': True},
    'wholeArticleTextsAndGlobalZhCnImages': 'NOT_SEMANTICALLY_CERTIFIED_BY_THIS_IMAGE_INTAKE',
    'regionalDateConflictRetained': 'Global EN overview Oct16-22/Oct23 versus global localized ZH overview Oct17-23/Oct24; localized Pre-Rift guide Oct16. Exact three article bodies unchanged. CN precedence still OPEN.',
    'printedFaceObservations': 42, 'distinctPrintedNumberLookupCandidates': 38,
    'faceReconciliation': pin(e / 'face-identity-reconciliation.json'),
    'supplementalPrintingObligations': pin(e / 'supplemental-printing-obligations.json'),
    'eightUnmatchedNumbersNotSilentlyMergedOrRuntimeAdopted': True,
    'explicitCorrections': 'Original TLS/preflight/format failures and intake coverage errors retained. I009KaynMight5 was a visual misread corrected to6 byI023, not an official rule update. V1text normalization and image scope were corrected from the same raw responses; V2false unchanged-image expectation retained.',
    'priorFiveTemporalDeltasUnchanged': True, 'runtimeInputsChanged': False,
    'fixed797fActualLockedAcceptanceSeparate': pin(e / 'fixed797f-locked-acceptance.json'),
    'wholePrintingCertified': False, 'semanticCoverageCertified': False, 'visibleProductAndPhysicalWindows': 'OPEN'}
write(e / 'source-manifest.json', manifest)
write(e / 'archive-map.json', {'status': 'EXACT_ORIGINAL_SOURCE_AND_FIXED_NATIVE_EVIDENCE_ARCHIVED', 'files': archives,
    'rawImagesHardlinkedToAvoidAnotherLocalPhysicalCopy': True, 'noDatabaseSourceTestOrRuntimeRetirement': True})

m = copy.deepcopy(prior_manifest)
source_pin = pin(e / 'source-manifest.json', 'source-manifest')
parent_gate = 'GATE:RADIANCE_OVERVIEW_EXACT_BODY_AND_FORMAT_APPLICABILITY'
for row in supplemental:
    identity = 'RADIANCE_VISUAL_NUMBER_' + row['normalizedLookupCandidate'].replace('-', '_').replace('/', '_')
    m['acceptanceGates'].append({'id': identity, 'state': 'OPEN', 'parentObligationId': parent_gate,
        'region': 'GLOBAL_CN_DISPOSITION_OPEN', 'language': 'en-US', 'observedAt': '2026-10-19',
        'requirement': 'Resolve exact printed-number/source-version identity, token or rune namespace, regional dates and applicability, then all applicable shared behavior, independent tests, fixed CI and product evidence. Do not merge a similar structured card number or infer a new official API ID.',
        'sourceManifest': source_pin, 'sourcePrintingCandidate': row, 'semanticReview': 'SOURCE_VISUAL_FACT_ONLY',
        'implementation': 'NOT_RUNTIME_ADOPTED', 'testExecution': 'OPEN_IF_APPLICABLE',
        'fixedCommitCi': 'PENDING_SOURCE_INDEX_CI', 'productAcceptance': 'OPEN_IF_APPLICABLE', 'wholePrintingCertified': False})
m['acceptanceGates'].append({'id': 'RADIANCE_SAME_NUMBER_PROMO_STAMPS_AND_SP_NAMESPACES', 'state': 'OPEN',
    'parentObligationId': parent_gate, 'region': 'GLOBAL_CN_DISPOSITION_OPEN', 'language': 'en-US', 'observedAt': '2026-10-19',
    'requirement': 'Resolve numeric/SP/promo exact identities and same-number TOP8 versus CHAMPION stamps for Akali015 and Ahri038, plus Heimer132 prerelease and ordinary faces. Matching rule text/printed number alone does not certify every physical variant or CN eligibility.',
    'sourceManifest': source_pin, 'semanticReview': 'VISUAL_VARIANTS_RECORDED', 'implementation': 'NOT_RUNTIME_ADOPTED',
    'testExecution': 'OPEN_IF_APPLICABLE', 'fixedCommitCi': 'PENDING_SOURCE_INDEX_CI', 'productAcceptance': 'OPEN_IF_APPLICABLE',
    'wholePrintingCertified': False})
assert m['acceptanceGates'][:221] == prior_manifest['acceptanceGates']
assert m['reviewContexts'] == prior_manifest['reviewContexts'] and m['laterSourceDeltas'] == prior_manifest['laterSourceDeltas']
coverage = load(r / prior_manifest['cardCoverageManifest']['path'])
coverage['priorRadianceVisualCoverage'] = copy.deepcopy(prior_manifest['cardCoverageManifest'])
coverage['currentRadianceVisualReadback'] = source_pin
coverage['supplementalUnmatchedPrintingCandidates'] = pin(e / 'supplemental-printing-obligations.json')
coverage['note'] = 'Retain all original1740 structured printing IDs/dates,36 historical documents14293 blocks, English8 source gap,236 CN source-version dispositions and5 temporal deltas. Add8 unresolved official-image number candidates plus same-number stamp/SP obligations without claiming a complete1748 universe or runtime adoption. Source39 visuals and fixed797f locked evidence remain bounded; whole cards, global texts/CN precedence, current visible product and physical Windows stay OPEN.'
write(e / 'source-coverage.json', coverage)
m['cardCoverageManifest'] = pin(e / 'source-coverage.json', 'current-card-coverage')
m['currentRadianceVisualSourceSupplement'] = source_pin
m['currentRadianceSupplementalPrintingObligations'] = pin(e / 'supplemental-printing-obligations.json')
assert sha(rp) == prior_reviews_sha
write(mp, m)
write(n / 'canonical-publication-v1.json', {'status': 'SOURCE_SUPPLEMENT_CANONICAL_WRITTEN_PENDING_GOVERNANCE_AND_FIXED_CI',
    'baseCommit': base, 'currentRunningCodeFixedCommit': fixed, 'all139ReviewDictionariesAnd54ContextsUnchanged': True,
    'all221PriorGateDictionariesAnd5TemporalDeltasUnchanged': True, 'newOpenGates': 9,
    'currentGateCount': len(m['acceptanceGates']), 'canonicalSourceManifest': source_pin,
    'noLocalSecondCheckOrRuntimeBuildOrSourceCardAdoption': True})
print('CANONICAL_SOURCE_SUPPLEMENT_WRITTEN', len(refs), 'image refs,8unmatched numbers,9open gates,total', len(m['acceptanceGates']), flush=True)
