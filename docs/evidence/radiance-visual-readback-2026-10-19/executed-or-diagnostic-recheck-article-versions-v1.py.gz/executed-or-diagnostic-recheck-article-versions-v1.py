import ast
import datetime
import gzip
import hashlib
import json
import pathlib
import re
import urllib.request
from html import escape
from html.parser import HTMLParser

n = pathlib.Path(__file__).resolve().parent
r = n.parents[2]
sha = lambda b: hashlib.sha256(b).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
extractor = r / 'scripts/audit/snapshot-global-rules.py'
declarations = [x for x in ast.parse(extractor.read_text()).body
    if isinstance(x, (ast.ClassDef, ast.FunctionDef)) and x.name in ['Body', 'article_body']]
namespace = {'HTMLParser': HTMLParser, 'escape': escape}
exec(compile(ast.Module(body=declarations, type_ignores=[]), str(extractor), 'exec'), namespace)
old_en = json.loads((r / 'docs/evidence/pakaa-move-reveal-2026-10-19/radiance-next-frontier-source.json').read_text())
old_zh = json.loads((r / 'docs/evidence/battlefield-play-damage-2026-10-17/global-zh-cn-source-variant-discovery.json').read_text())
old_index = json.loads((r / 'docs/evidence/pakaa-move-reveal-2026-10-19/radiance-next-frontier-index.json').read_text())
sources = [('en-overview', 'en-US', old_en)]
sources += [('zh-' + ('overview' if 'the-radiance-overview' in row['url'] else 'prerift'), 'zh-CN', row) for row in old_zh['sources']]
out = n / 'article-version-recheck-v1.json'
assert not out.exists()
record = {'startedAtUtc': now(), 'status': 'RUNNING_NOT_CERTIFICATION',
    'scope': 'Exact global EN overview and global localized ZH overview/prerift article versions only. CN regional precedence and legality remain open.',
    'trustedExtractorSha256': sha(extractor.read_bytes()), 'records': []}
def save():
    out.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
save()
for label, language, previous in sources:
    row = {'label': label, 'url': previous['url'], 'attemptedAtUtc': now(), 'language': language,
        'tlsVerificationDisabled': False, 'publisherRegion': 'GLOBAL_LOCALIZATION_CN_PRECEDENCE_OPEN'}
    try:
        request = urllib.request.Request(row['url'], headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(request, timeout=30) as response:
            raw = response.read(4 * 1024 * 1024 + 1)
            assert len(raw) <= 4 * 1024 * 1024
            row.update(httpStatus=response.status, resolvedUrl=response.url, httpDate=response.headers.get('Date'), lastModified=response.headers.get('Last-Modified'))
        page = json.loads(re.search(r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>', raw.decode()).group(1))['props']['pageProps']['page']
        body = namespace['article_body'](page)
        parser = namespace['Body']()
        parser.feed(body)
        text = ''.join(parser.parts).strip()
        images = set()
        def visit(value):
            if isinstance(value, dict):
                for child in value.values(): visit(child)
            elif isinstance(value, list):
                for child in value: visit(child)
            elif isinstance(value, str) and value.startswith('https://cmsassets.rgpub.io/') and re.search(r'\.(?:png|jpg|jpeg|webp|svg)(?:\?|$)', value):
                images.add(value)
        visit(page)
        path = n / (label + '-current-article.html.gz')
        assert not path.exists()
        path.write_bytes(gzip.compress(raw, mtime=0))
        body_path = n / (label + '-current-body.html.gz')
        text_path = n / (label + '-current-body.txt.gz')
        assert not body_path.exists() and not text_path.exists()
        body_path.write_bytes(gzip.compress(body.encode(), mtime=0))
        text_path.write_bytes(gzip.compress(text.encode(), mtime=0))
        baseline_text = previous.get('bodyTextSha256', previous.get('textSha256'))
        row.update(status='ACQUIRED_BODY_VERSION_COMPARED_NOT_REGION_OR_WHOLE_SEMANTICS', receivedAtUtc=now(),
            rawBytes=len(raw), rawSha256=sha(raw), rawArchive=str(path.relative_to(r)), rawArchiveSha256=sha(path.read_bytes()),
            bodyHtmlSha256=sha(body.encode()), bodyTextSha256=sha(text.encode()),
            previousBodyHtmlSha256=previous['bodyHtmlSha256'], previousBodyTextSha256=baseline_text,
            bodyHtmlUnchanged=sha(body.encode()) == previous['bodyHtmlSha256'], bodyTextUnchanged=sha(text.encode()) == baseline_text,
            publicationFromCms=page.get('displayedPublishDate'), revisionFromCms=page.get('analytics', {}).get('rev'),
            imageUrls=sorted(images), exactCurrentImageReferences=len(images),
            dateTextFragments=[v.strip() for v in re.split(r'\n\s*\n', text) if re.search(r'October|November|December|10月|11月|12月|更新时间', v)][:22],
            bodyArchive=str(body_path.relative_to(r)), textArchive=str(text_path.relative_to(r)))
        if label == 'en-overview':
            row['all37FrozenImageUrlsRetained'] = images == {v['url'] for v in old_index['images']}
    except Exception as error:
        row.update(status='FAILED_ACQUISITION_OR_COMPARISON_NOT_CERTIFICATION', errorType=type(error).__name__, error=str(error)[:700])
    record['records'].append(row)
    save()
    print(label, row['status'], row.get('bodyHtmlUnchanged'), row.get('bodyTextUnchanged'), flush=True)
record.update(status='COMPARISON_COMPLETE_WITH_EXPLICIT_RESULTS_NOT_CN_APPLICABILITY_CERTIFICATION', finishedAtUtc=now(),
    actualBodyVersionDifferences=[row['label'] for row in record['records'] if row.get('bodyHtmlUnchanged') is False or row.get('bodyTextUnchanged') is False],
    wholeSourceOrRegionalEligibilityOrRuntimeAdoption=False)
save()
