import datetime
import hashlib
import io
import json
import pathlib
import urllib.request
from PIL import Image

n = pathlib.Path(__file__).resolve().parent
r = n.parents[2]
sha = lambda b: hashlib.sha256(b).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
p = r / 'docs/evidence/pakaa-move-reveal-2026-10-19/radiance-next-frontier-index.json'
index = json.loads(p.read_text())
assert sha(p.read_bytes()) == '9b0a1a03788791d09edd2935debec911f05cf3dabe787b354c899ec8e54a99aa'
out = n / 'next-ten-acquisition-v4.json'
assert not out.exists()
record = {'recordedAtUtc': now(), 'status': 'RUNNING_NOT_VISUAL_REVIEW', 'requestedCount': 10,
    'original37IndexSha256': sha(p.read_bytes()), 'frozenBodyHtmlSha256': index['bodyHtmlSha256'],
    'wholeArticleNotFreshlyReconfirmedHere': True, 'records': []}
def save():
    out.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
save()
for ref in index['images'][10:20]:
    row = {'id': ref['id'], 'url': ref['url'], 'sourceReferenceUnchanged': ref, 'attemptedAtUtc': now(),
        'tlsVerificationDisabled': False, 'language': 'en-US', 'region': 'GLOBAL_SUPPLEMENTARY_CN_DISPOSITION_OPEN',
        'pixelsInspected': False}
    try:
        assert urllib.request.urlparse(ref['url']).hostname == 'cmsassets.rgpub.io'
        request = urllib.request.Request(ref['url'], headers={'User-Agent': 'RiftboundOfficialSourceAudit/1.0'})
        with urllib.request.urlopen(request, timeout=25) as response:
            raw = response.read(15 * 1024 * 1024 + 1)
            assert len(raw) <= 15 * 1024 * 1024
            row.update(httpStatus=response.status, resolvedUrl=response.url, httpDate=response.headers.get('Date'),
                lastModified=response.headers.get('Last-Modified'), contentType=response.headers.get('Content-Type'))
        with Image.open(io.BytesIO(raw)) as picture:
            picture.verify()
        suffix = pathlib.Path(urllib.request.urlparse(ref['url']).path).suffix.lower()
        path = n / (ref['id'][-4:] + suffix)
        assert not path.exists()
        path.write_bytes(raw)
        row.update(status='ACQUIRED_VISUAL_REVIEW_PENDING', path=str(path.relative_to(r)), receivedAtUtc=now(),
            bytes=len(raw), rawSha256=sha(raw))
    except Exception as error:
        row.update(status='FAILED_ACQUISITION_NOT_REVIEWED', errorType=type(error).__name__, error=str(error)[:600])
    record['records'].append(row)
    save()
    print(row['id'][-4:], row['status'], flush=True)
assert sha(p.read_bytes()) == record['original37IndexSha256']
record['acquiredCount'] = sum(row['status'] == 'ACQUIRED_VISUAL_REVIEW_PENDING' for row in record['records'])
record['status'] = 'ALL_TEN_ACQUIRED_VISUAL_PENDING' if record['acquiredCount'] == 10 else 'PARTIAL_ACQUISITION_ORIGINAL_FAILURES_RETAINED'
record['finishedAtUtc'] = now()
save()
print(record['status'], record['acquiredCount'], flush=True)
