import ast
import datetime
import gzip
import hashlib
import json
import pathlib
import re
from html import escape, unescape
from html.parser import HTMLParser

n = pathlib.Path(__file__).resolve().parent
r = n.parents[2]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
digest = lambda b: hashlib.sha256(b).hexdigest()
load = lambda p: json.loads(p.read_text())
out = n / 'article-version-recheck-corrected-v3.json'
assert not out.exists()
extractor = r / 'scripts/audit/snapshot-global-rules.py'
nodes = [x for x in ast.parse(extractor.read_text()).body if isinstance(x, (ast.ClassDef, ast.FunctionDef)) and x.name in ['Body', 'article_body']]
namespace = {'HTMLParser': HTMLParser, 'escape': escape}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(extractor), 'exec'), namespace)
image_extractor = r / 'var/qa/paka-move-reveal-20261019/expand-radiance-source-images-v2.py'
image_nodes = [x for x in ast.parse(image_extractor.read_text()).body if isinstance(x, ast.FunctionDef) and x.name == 'visit']

def read(path):
    raw = gzip.decompress(path.read_bytes())
    page = json.loads(re.search(r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>', raw.decode()).group(1))['props']['pageProps']['page']
    body = namespace['article_body'](page)
    parser = namespace['Body']()
    parser.feed(body)
    images = {'re': re, 'unescape': unescape, 'links': set()}
    exec(compile(ast.Module(body=image_nodes, type_ignores=[]), str(image_extractor), 'exec'), images)
    images['visit'](page)
    return page, body, ''.join(parser.parts).strip(), images['links']

prior = {
    'en-overview': r / 'var/qa/paka-move-reveal-20261019/radiance-overview-next-frontier.html.gz',
    'zh-overview': r / 'var/qa/battlefield-positive-play-20261017/source-current/the-radiance-overview.html.gz',
    'zh-prerift': r / 'var/qa/battlefield-positive-play-20261017/source-current/preparing-for-the-radiance-pre-rift.html.gz'}
v1 = load(n / 'article-version-recheck-v1.json')
frozen = load(r / 'docs/evidence/pakaa-move-reveal-2026-10-19/radiance-next-frontier-index.json')
frozen_urls = {x['url'] for x in frozen['images']}
rows = []
for original in v1['records']:
    assert original['status'].startswith('ACQUIRED_')
    label = original['label']
    current_file = r / original['rawArchive']
    assert sha(current_file) == original['rawArchiveSha256']
    old_page, old_body, old_text, old_images = read(prior[label])
    current_page, current_body, current_text, current_images = read(current_file)
    row = {'label': label, 'url': original['url'], 'language': original['language'],
        'sameOriginalHttpAcquisitionNoRefetch': original, 'priorRawArchive': str(prior[label].relative_to(r)),
        'priorRawArchiveSha256': sha(prior[label]), 'currentBodyHtmlSha256': digest(current_body.encode()),
        'recomputedPriorBodyTextSha256': digest(old_text.encode()), 'currentBodyTextSha256': digest(current_text.encode()),
        'bodyHtmlSame': old_body == current_body, 'bodyTextSameUnderSameTrustedExtractor': old_text == current_text,
        'currentCmsRevision': current_page.get('analytics', {}).get('rev'), 'priorCmsRevision': old_page.get('analytics', {}).get('rev'),
        'publicationDateSame': current_page.get('displayedPublishDate') == old_page.get('displayedPublishDate'),
        'allPageImageUrls': sorted(current_images), 'allPageImageUrlCount': len(current_images),
        'allPriorImageUrlsRetained': current_images == old_images,
        'addedImageUrls': sorted(current_images - old_images), 'removedImageUrls': sorted(old_images - current_images),
        'sameExactUrlSubsetOfAlreadyRead37': sorted(current_images & frozen_urls),
        'otherImageReferencesStillNeedSeparateDisposition': sorted(current_images - frozen_urls),
        'regionPrecedenceAndTournamentLegality': 'OPEN_NOT_INFERRED_FROM_LOCALIZATION',
        'semanticWholeArticleOrPrintingCertified': False}
    row['frozen37BladesIndexIsNotFullPageMetadataImageUniverse'] = True
    row['oldMetadataReferencesOutsideFrozen37'] = sorted(old_images - frozen_urls) if label == 'en-overview' else []
    rows.append(row)
assert all(row['bodyHtmlSame'] and row['bodyTextSameUnderSameTrustedExtractor'] for row in rows)
record = {'recordedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'ALL_THREE_ARTICLE_BODIES_UNCHANGED_SAME_EXTRACTOR_AUXILIARY_PAGE_URL_DIFFERENCES_EXPLICIT',
    'priorIncorrectAggregateReceipt': {'path': str((n / 'article-version-recheck-v1.json').relative_to(r)), 'sha256': sha(n / 'article-version-recheck-v1.json')},
    'explicitCorrections': ['V1 compared ZH text produced by a different historical text normalization; unchanged original HTML is not a source-body edit. Both old/current raw responses now use the same trusted extractor.',
        'V1 direct-string URL walk omitted URLs inside rich HTML. Reuse the previously corrected nested/HTML URL extractor on both complete page objects. The apparent12-reference result was an intake defect, not official image removal.'],
    'onlyTrustedRepositoryExtractorDeclarationsExecuted': True, 'articleExtractorSha256': sha(extractor), 'imageExtractorSha256': sha(image_extractor),
    'records': rows, 'actualArticleBodyTextChangeInTheseThreeSources': False,
    'auxiliaryPageReferenceDifferencesRequireRecordedContext': [{'label': row['label'], 'added': row['addedImageUrls'], 'removed': row['removedImageUrls']} for row in rows if row['addedImageUrls'] or row['removedImageUrls']],
    'priorFailedV2Precondition': 'Expected full-page URLs to equal the frozen37 blades-derived index. The original full page contains39 URLs, the current EN page38; inspect auxiliary metadata and related-carousel contexts without assuming image deletion or a rule change.',
    'oldRegionalDateConflictStillOpen': True, 'noOldReceiptSourceDateOrRuntimeInputOverwritten': True}
out.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
print(record['status'], [(row['label'], row['allPageImageUrlCount']) for row in rows], flush=True)
