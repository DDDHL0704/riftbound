import fcntl
import json
import os
import runpy
import subprocess
from pathlib import Path

os.umask(0o077)
n = Path(__file__).resolve().parent
c = runpy.run_path(str(n / 'empty_reveal_common.py'))
base_digest = c['digests']
c['digests'] = lambda db, ids=None: base_digest(db, c['rooms'](db) if ids is None else ids)
c['fixed'] = c['publication']['baseCommit']
c['verify_fixed'] = c['verify_frozen']
c['environment'] = lambda db: dict(os.environ, ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database='+db+';Username=codex_riftbound_audit')
sha, load, write, now = [c[k] for k in ['sha', 'load', 'write', 'now']]
last = load(n / 'development-sql-verification-v1.json')
assert last['status'].startswith('PASS') and last['ownPostgresSmartStopped']
runtime = n / 'independent-sql-reader/bin/Release/net10.0'
files = {str(p.relative_to(n)): sha(p) for p in runtime.rglob('*') if p.is_file()}
for p in [n / 'independent-sql-reader/Program.cs', n / 'independent-sql-reader/reader.csproj']:
    files[str(p.relative_to(n))] = sha(p)
originals = ['development-sql-v1/empty-reveal-followup/empty-paka-CoreRules-original-frame.json.gz',
             'development-sql-v1/empty-reveal-followup/empty-paka-ChinaStandard20260724-original-frame.json.gz']
for name in originals:
    files[name] = sha(n / name)
for dll in ['Riftbound.Engine.dll', 'Riftbound.CardCatalog.dll', 'Riftbound.Contracts.dll', 'Riftbound.Persistence.dll']:
    assert sha(runtime / dll) == sha(n / 'development-sql-publish' / dll)
manifest = n / 'independent-sql-reader-inputs-v1.json'
assert not manifest.exists()
write(manifest, {'baseCommit': c['fixed'], 'files': files, 'actualRuleInputs': c['identity']})
out = n / 'independent-sql-verification-v1.json'
assert not out.exists()
proof = {'startedAtUtc': now(), 'baseCommit': c['fixed'], 'actualRuleInputs': c['identity'],
         'status': 'RUNNING_NOT_ACCEPTANCE', 'lockAtStart': c['locked'](),
         'readerInputsSha256': sha(manifest), 'originalFramesNeverRewritten': True, 'scope': 'Current frozen development Debug SQL modules, actual two new seed0 empty-observation rooms, original source-derived Might4 and both private views. Not an old fixed native receipt or current product certificate.',
         'visibleNativeControlsAndPairedClients': 'OPEN', 'physicalWindows': 'OPEN'}
guard = (n.parent / 'ravenbloom-paired-20261018/without-desktop.lock').open('a')
fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
write(out, proof)
pg, cluster, sock = [c[k] for k in ['pg', 'cluster', 'sock']]
started = False
power = None
try:
    assert subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), 'status'], capture_output=True).returncode == 3
    power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    proof.update(ownRunnerPid=os.getpid(), boundIdleSleepAssertionPid=power.pid)
    subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-l', str(n / 'independent-sql-postgres-v1.log'),
                    '-o', f'-p 55486 -h 127.0.0.1 -k {sock}', '-w', 'start'], check=True, capture_output=True)
    started = True
    native = c['rooms']('riftbound_here_native')
    audit = c['rooms']('riftbound_acceptance')
    assert len(native) == 27 and len(audit) == 158
    before_native = c['digests']('riftbound_here_native')
    before_audit = c['digests']('riftbound_acceptance')
    proof.update(priorNativeRooms=native, priorAuditRooms=audit, priorNativeSevenTables=before_native, priorAuditSevenTables=before_audit)
    write(out, proof)
    result = subprocess.run([c['dotnet'], str(runtime / 'reader.dll'), 'validate-empty-reveal-originals-readonly-v1'],
                            cwd=runtime, env=c['environment']('riftbound_acceptance'), capture_output=True, text=True, timeout=180)
    log = n / 'independent-sql-reader-v1.log'
    with log.open('x') as stream:
        stream.write(result.stdout + result.stderr)
    proof['readerExitCode'] = result.returncode
    assert result.returncode == 0
    reader = json.loads(result.stdout)
    assert reader['status'].startswith('PASS') and reader['actualRuleInputs'] == c['identity']
    write(n / 'independent-sql-reader-result-v1.json', reader)
    assert c['digests']('riftbound_here_native') == before_native
    assert c['digests']('riftbound_acceptance') == before_audit
    assert c['rooms']('riftbound_here_native') == native and c['rooms']('riftbound_acceptance') == audit
    proof.update(status=reader['status'], independentActualReadOnlyResult=reader,
                 all27NativeAnd158AuditRoomsSevenTablesUnchanged=True, noNewRoomOrSeedOrHistoryRewrite=True)
except BaseException as error:
    proof.update(status='FAILED_OR_INTERRUPTED_ORIGINALS_RETAINED', errorType=type(error).__name__)
    raise
finally:
    if started:
        proof['ownPostgresSmartStopped'] = subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-m', 'smart', '-w', '-t', '20', 'stop'], capture_output=True).returncode == 0
    if power is not None:
        if power.poll() is None:
            power.terminate()
            power.wait(timeout=10)
        proof['boundIdleSleepAssertionEnded'] = power.poll() is not None
    assert all(sha(n / p) == h for p, h in files.items())
    c['verify_fixed']()
    proof.update(finishedAtUtc=now(), lockAtEnd=c['locked'](), allFrozenReaderAndNativeRuntimeFilesStillExact=True, originalDatabaseRetained=cluster.exists())
    write(out, proof)
    fcntl.flock(guard, fcntl.LOCK_UN)
print(proof['status'], flush=True)
