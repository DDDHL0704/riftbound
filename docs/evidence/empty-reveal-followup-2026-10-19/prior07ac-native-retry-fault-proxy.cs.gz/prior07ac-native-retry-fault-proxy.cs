using System.Collections.Concurrent;
using System.Net.WebSockets;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

// A bounded localhost transport experiment. No payload fields, cards, source
// histories, identities, receipts or prompts are manufactured or rewritten.
var builder = WebApplication.CreateBuilder(args);
builder.WebHost.UseUrls("http://127.0.0.1:15840");
var app = builder.Build();
app.UseWebSockets();
using var http = new HttpClient();
var fault = new Fault();
app.MapGet("/fault-evidence", () => Results.Json(fault.Evidence()));
app.MapFallback(async context =>
{
    var destination = "http://127.0.0.1:15839" + context.Request.Path + context.Request.QueryString;
    if (!context.WebSockets.IsWebSocketRequest)
    {
        using var request = new HttpRequestMessage(new HttpMethod(context.Request.Method), destination);
        if (context.Request.ContentLength is > 0) request.Content = new StreamContent(context.Request.Body);
        foreach (var header in context.Request.Headers)
        {
            if (header.Key.Equals("Host", StringComparison.OrdinalIgnoreCase)
                || header.Key.Equals("Connection", StringComparison.OrdinalIgnoreCase)
                || header.Key.Equals("Transfer-Encoding", StringComparison.OrdinalIgnoreCase)) continue;
            if (!request.Headers.TryAddWithoutValidation(header.Key, header.Value.ToArray()))
                request.Content?.Headers.TryAddWithoutValidation(header.Key, header.Value.ToArray());
        }
        using var response = await http.SendAsync(request, context.RequestAborted);
        context.Response.StatusCode = (int)response.StatusCode;
        foreach (var header in response.Headers.Concat(response.Content.Headers))
            if (!header.Key.Equals("Transfer-Encoding", StringComparison.OrdinalIgnoreCase))
                context.Response.Headers[header.Key] = header.Value.ToArray();
        await response.Content.CopyToAsync(context.Response.Body, context.RequestAborted);
        return;
    }
    using var upstream = new ClientWebSocket();
    await upstream.ConnectAsync(new Uri(destination.Replace("http://", "ws://", StringComparison.Ordinal)), context.RequestAborted);
    using var downstream = await context.WebSockets.AcceptWebSocketAsync();
    using var lifetime = CancellationTokenSource.CreateLinkedTokenSource(context.RequestAborted);
    lifetime.CancelAfter(TimeSpan.FromSeconds(100));
    var connection = new Connection();
    var outgoing = Relay(downstream, upstream, true, connection, fault, lifetime.Token);
    var incoming = Relay(upstream, downstream, false, connection, fault, lifetime.Token);
    await Task.WhenAny(outgoing, incoming);
    lifetime.Cancel();
    try { await Task.WhenAll(outgoing, incoming); }
    catch (OperationCanceledException) { }
    catch (WebSocketException) { }
});
await app.RunAsync();

static async Task Relay(WebSocket source, WebSocket target, bool outgoing, Connection connection, Fault fault, CancellationToken ct)
{
    var buffer = new byte[65536];
    while (!ct.IsCancellationRequested && source.State == WebSocketState.Open && target.State == WebSocketState.Open)
    {
        using var message = new MemoryStream();
        WebSocketReceiveResult result;
        do
        {
            result = await source.ReceiveAsync(new ArraySegment<byte>(buffer), ct);
            if (result.MessageType == WebSocketMessageType.Close)
            {
                await target.CloseOutputAsync(result.CloseStatus ?? WebSocketCloseStatus.NormalClosure, result.CloseStatusDescription, ct);
                return;
            }
            message.Write(buffer, 0, result.Count);
            if (message.Length > 4 * 1024 * 1024) throw new Exception("Unexpectedly large bounded SignalR message.");
        } while (!result.EndOfMessage);
        var payload = message.ToArray();
        if (result.MessageType == WebSocketMessageType.Text)
        {
            foreach (var part in Encoding.UTF8.GetString(payload).Split('\u001e', StringSplitOptions.RemoveEmptyEntries))
            {
                using var json = JsonDocument.Parse(part);
                await fault.Observe(json.RootElement, outgoing, connection, payload, ct);
            }
        }
        var before = SHA256.HashData(payload);
        await target.SendAsync(new ArraySegment<byte>(payload), result.MessageType, true, ct);
        if (!before.AsSpan().SequenceEqual(SHA256.HashData(payload))) throw new Exception("Transport experiment modified a payload.");
    }
}

sealed class Connection { public string Label = "unknown"; }
sealed class Fault
{
    readonly TaskCompletionSource<bool> surrenderHeld = new(TaskCreationOptions.RunContinuationsAsynchronously);
    readonly TaskCompletionSource<bool> mulliganAccepted = new(TaskCreationOptions.RunContinuationsAsynchronously);
    readonly ConcurrentQueue<object> trace = new();
    string? heldMulliganInvocation;
    long heldSurrenderTick = -1, acceptedMulliganTick = -1;
    int heldA, heldB;
    public async Task Observe(JsonElement packet, bool outgoing, Connection connection, byte[] raw, CancellationToken ct)
    {
        if (outgoing && packet.TryGetProperty("target", out var target))
        {
            var method = target.GetString();
            var arguments = packet.GetProperty("arguments");
            if (method == "Authenticate")
            {
                var handle = arguments[0].GetString()!;
                connection.Label = handle.StartsWith("retrya", StringComparison.Ordinal) ? "a"
                    : handle.StartsWith("retryb", StringComparison.Ordinal) ? "b" : "unexpected";
                if (connection.Label == "unexpected") throw new Exception("Only the two dedicated native actors may use this fault proxy.");
            }
            if (method == "SubmitIntent")
            {
                var command = arguments[3];
                var type = command.GetProperty("cmdType").GetString();
                var tick = command.TryGetProperty("snapshotTick", out var tickElement) ? tickElement.GetInt64() : -1;
                if (connection.Label == "a" && type == "MULLIGAN" && Interlocked.CompareExchange(ref heldA, 1, 0) == 0)
                {
                    heldMulliganInvocation = packet.GetProperty("invocationId").GetString();
                    trace.Enqueue(new { stage = "HOLD_ORIGINAL_A_MULLIGAN", tick, sha256 = Convert.ToHexString(SHA256.HashData(raw)).ToLowerInvariant() });
                    await surrenderHeld.Task.WaitAsync(TimeSpan.FromSeconds(20), ct);
                    trace.Enqueue(new { stage = "FORWARD_ORIGINAL_A_MULLIGAN_UNMODIFIED", tick });
                }
                if (connection.Label == "b" && type == "SURRENDER" && Interlocked.CompareExchange(ref heldB, 1, 0) == 0)
                {
                    Interlocked.Exchange(ref heldSurrenderTick, tick);
                    trace.Enqueue(new { stage = "HOLD_ORIGINAL_B_SURRENDER", tick, sha256 = Convert.ToHexString(SHA256.HashData(raw)).ToLowerInvariant() });
                    surrenderHeld.TrySetResult(true);
                    await mulliganAccepted.Task.WaitAsync(TimeSpan.FromSeconds(20), ct);
                    if (Interlocked.Read(ref acceptedMulliganTick) <= tick) throw new Exception("A real accepted ordinary command must advance the original B prompt.");
                    trace.Enqueue(new { stage = "FORWARD_ORIGINAL_STALE_B_SURRENDER_UNMODIFIED", tick, authoritativeTick = Interlocked.Read(ref acceptedMulliganTick) });
                }
                else if (connection.Label == "b" && type == "SURRENDER")
                    trace.Enqueue(new { stage = "ACTUAL_NATIVE_B_RETRY_UNMODIFIED", tick });
            }
        }
        if (!outgoing && connection.Label == "a" && heldMulliganInvocation is not null
            && packet.TryGetProperty("type", out var kind) && kind.GetInt32() == 3
            && packet.GetProperty("invocationId").GetString() == heldMulliganInvocation)
        {
            var receipt = packet.GetProperty("result");
            if (!receipt.GetProperty("accepted").GetBoolean()) throw new Exception("The ordinary A mulligan must really be accepted.");
            Interlocked.Exchange(ref acceptedMulliganTick, receipt.GetProperty("serverTick").GetInt64());
            trace.Enqueue(new { stage = "REAL_SERVER_ACCEPTED_A_MULLIGAN", authoritativeTick = Interlocked.Read(ref acceptedMulliganTick) });
            mulliganAccepted.TrySetResult(true);
        }
    }
    public object Evidence() => new { payloadsNeverRewritten = true, boundedLocalhostOnly = true,
        heldAFirstMulligan = heldA == 1, heldBFirstSurrender = heldB == 1,
        heldSurrenderTick, acceptedMulliganTick, trace = trace.ToArray() };
}
