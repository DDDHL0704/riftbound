using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

if (!args.SequenceEqual(new[] { "validate-empty-reveal-originals-readonly-v1" })) throw new Exception("Exact bounded gate required.");
var root = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "../../../../"));
var settings = new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
if (settings.Host != "127.0.0.1" || settings.Port != 55486 || settings.Database != "riftbound_acceptance"
    || settings.Username != "codex_riftbound_audit") throw new Exception("Only the existing dedicated audit database.");
settings.Options = "-c default_transaction_read_only=on";
await using var source = NpgsqlDataSource.Create(settings.ConnectionString);
var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
using var publication = JsonDocument.Parse(File.ReadAllText(Path.Combine(root, "development-sql-publication-v1.json")));
if (!JsonNode.DeepEquals(JsonSerializer.SerializeToNode(RuleInputIdentity.Current, json),
        JsonNode.Parse(publication.RootElement.GetProperty("actualRuleInputs").GetRawText())))
    throw new Exception("Actual reader identity differs from the frozen development SQL runtime.");
using var fixture = JsonDocument.Parse(File.ReadAllText(Path.Combine(root, "development-sql-publish/Fixtures/pakaa-protector-openings.json")));
var host = fixture.RootElement.GetProperty("branches").EnumerateArray().Single(row => row.GetProperty("profile").GetString() == "UNIT").GetProperty("host").GetString()!;
var checks = new List<object>();
foreach (var format in new[] { "CoreRules", "ChinaStandard20260724" })
{
    var file = Path.Combine(root, "development-sql-v1/empty-reveal-followup/empty-paka-" + format + "-original-frame.json.gz");
    using var zip = new GZipStream(File.OpenRead(file), CompressionMode.Decompress);
    var frozen = await JsonSerializer.DeserializeAsync<MatchRecoveryFrame>(zip, json) ?? throw new Exception("Missing original frozen SQL frame.");
    var actual = await new PostgresMatchRecoveryStore(source).LoadAsync(frozen.RoomId, default) ?? throw new Exception("Missing actual original SQL room.");
    if (!JsonNode.DeepEquals(JsonSerializer.SerializeToNode(actual, json), JsonSerializer.SerializeToNode(frozen, json)))
        throw new Exception("Stored original fields, nulls, commands, events or both private views differ from the actual frozen frame.");
    if (!actual.IsConsistent || actual.Commands.Count != 85 || actual.Events.Count != 664 || actual.OpeningSeed != 0
        || actual.ReplayInitialState is not { Tick: 0 } blank || blank.CardObjects.Count != 0
        || actual.AuthoritativeState is not { } state || state.RuleInputs != RuleInputIdentity.Current
        || actual.Commands.Any(command => !command.Accepted || command.RuleInputs != RuleInputIdentity.Current))
        throw new Exception("Original blank seed0,85 accepted commands,664 events and exact rule identity required.");
    if (state.PlayerZones["P1"].MainDeck.Count != 0 || state.CardObjects[host].UntilEndOfTurnPowerModifiers.Count != 0)
        throw new Exception("Empty main deck cannot manufacture a new Might modifier.");
    foreach (var view in actual.PlayerViews.Values)
    {
        var snapshot = JsonSerializer.SerializeToElement(view.Snapshot, json);
        if (snapshot.GetProperty("players").GetProperty("P1").GetProperty("objects").GetProperty(host).GetProperty("effectivePower").GetInt32() != 4)
            throw new Exception("Independent source-derived expected Might4 must be public in both stored player views.");
    }
    var move = actual.Commands.Last(command => command.CommandType == CommandTypes.MoveUnit);
    if (actual.Events.Where(entry => entry.Sequence > move.StartedEventSequence).Any(entry => entry.Event.Kind is
        "BURNOUT_APPLIED" or "CARDS_REVEALED" or "CARDS_MILLED" or "CARD_DRAWN"))
        throw new Exception("The empty observation cannot cause a burnout or phantom card action.");
    var errors = await MatchActionLogReplayer.ValidateRecoveryFrameAsync(actual, new CoreRuleEngine(), default);
    if (errors.Count != 0) throw new Exception("Full original action/event/state replay failed: " + string.Join(';', errors));
    checks.Add(new { room = actual.RoomId, format, commands = 85, events = 664, originalBlankSeed = 0,
        allStoredFieldsAndBothPrivateViewsExact = true, independentExpectedMight = 4, originalFullReplayMatched = true });
}
Console.WriteLine(JsonSerializer.Serialize(new { status = "PASS_INDEPENDENT_ACTUAL_READONLY_TWO_ORIGINAL_EMPTY_REVEAL_FRAMES", checks,
    actualRuleInputs = RuleInputIdentity.Current, noNewRoomSeedStateOrHistoryRewrite = true, visibleAndPhysicalWindows = "OPEN" }, json));
