import fcntl
import os
import subprocess
from empty_reveal_common import *

os.umask(0o077)
out = n / 'development-sql-verification-v1.json'
assert not out.exists()
inputs = load(n / 'development-sql-publication-inputs-before-v1.json')
assert all(sha(r / p) == h for p, h in inputs['sourceFiles'].items())
guard = (r / 'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a')
fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
proof = {'startedAtUtc': now(), 'status': 'RUNNING_NOT_ACCEPTANCE',
    'scope': 'Two new original ordinary empty-Paka SQL rooms in explicitly named engine formats. Current development Debug modules are byte-identical to the79-case focus. Frozen07ac native acceptance, future fixed CI and visible/Windows product are separate.',
    'baseCommit': '07ac3ac93098c476179297ad755b18e9aa3f2e95', 'actualRuleInputs': identity,
    'publicationInputsSha256': sha(n / 'development-sql-publication-v1.json'),
    'sourceInputsSha256': sha(n / 'development-sql-publication-inputs-before-v1.json'),
    'runnerSourceSha256': sha(pathlib.Path(__file__)), 'lockAtStart': locked(),
    'visibleNativeAndPhysicalWindows': 'OPEN'}
write(out, proof)
started = False
power = None
try:
    verify_frozen()
    assert subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), 'status'], capture_output=True).returncode == 3
    power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    proof.update(ownRunnerPid=os.getpid(), boundIdleSleepAssertionPid=power.pid)
    subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-l', str(n / 'development-sql-postgres-v1.log'), '-o',
        f'-p 55486 -h 127.0.0.1 -k {sock}', '-w', 'start'], capture_output=True, check=True)
    started = True
    audit = rooms('riftbound_acceptance'); native = rooms('riftbound_here_native')
    assert len(audit) == 156 and len(native) == 27
    audit_before = digests('riftbound_acceptance', audit); native_before = digests('riftbound_here_native', native)
    proof.update(priorAuditRooms=audit, priorNativeRooms=native, priorAuditSevenTables=audit_before, priorNativeSevenTables=native_before)
    write(out, proof)
    output = n / 'development-sql-v1'
    assert not output.exists()
    with (n / 'development-sql-actual-v1.log').open('x') as log:
        process = subprocess.Popen([dotnet, str(runtime / 'Riftbound.PostgresAcceptance.dll'), '--empty-reveal-followup-only'],
            cwd=r, env=dict(os.environ,
                ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit',
                RIFTBOUND_POSTGRES_EVIDENCE=str(output)), stdout=log, stderr=subprocess.STDOUT)
        proof['ownAcceptancePid'] = process.pid; write(out, proof)
        code = process.wait(timeout=900)
    proof['exitCode'] = code
    assert code == 0
    receipt_path = output / 'empty-reveal-followup/receipt.json'
    receipt = load(receipt_path)
    assert receipt['status'].startswith('REAL_POSTGRES_ORIGINAL_EMPTY_REVEAL_FOLLOWUP_')
    results = receipt['results']; assert len(results) == 2
    assert {row['format'] for row in results} == {'CoreRules', 'ChinaStandard20260724'}
    assert all(row['originalBlankSeed'] == 0 and row['initialObservedCards'] == 0 and row['expectedFinalMight'] == 4
        and row['originalFullReplayMatched'] and row['originalPrivateViewsAndPromptsExact']
        and row['noStateSeedOrHistoryInjection'] and row['ruleInputs'] == identity
        and row['coldRestores'] >= 5 and row['originalNextCommandsMatched'] >= 4
        and row['atomicRejections'] == 2 for row in results)
    added = sorted(set(rooms('riftbound_acceptance')) - set(audit))
    assert added == sorted(row['room'] for row in results) and len(rooms('riftbound_acceptance')) == 158
    assert rooms('riftbound_here_native') == native
    assert digests('riftbound_acceptance', audit) == audit_before
    assert digests('riftbound_here_native', native) == native_before
    proof.update(status='PASS_REAL_POSTGRES_TWO_ORDINARY_EMPTY_REVEAL_CASES_COLD_ORIGINAL_NEXT_AND_REPLAY',
        originalReceiptSha256=sha(receipt_path), branches=2,
        commands=sum(row['commands'] for row in results), events=sum(row['events'] for row in results),
        coldRestores=sum(row['coldRestores'] for row in results), originalNextCommandsMatched=sum(row['originalNextCommandsMatched'] for row in results),
        atomicRejections=sum(row['atomicRejections'] for row in results), newOriginalRooms=added,
        all156PriorAuditAnd27NativeRoomsSevenTablesExact=True,
        newRoomSevenTables=digests('riftbound_acceptance', added), observedAuditRooms=158, observedNativeRooms=27)
except BaseException as error:
    proof.update(status='FAILED_OR_INTERRUPTED_ORIGINAL_PREFIX_RETAINED', errorType=type(error).__name__)
    raise
finally:
    if started:
        proof['ownPostgresSmartStopped'] = subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-m', 'smart', '-w', '-t', '20', 'stop'], capture_output=True).returncode == 0
    if power is not None:
        if power.poll() is None: power.terminate(); power.wait(timeout=10)
        proof['boundIdleSleepAssertionEnded'] = power.poll() is not None
    verify_frozen()
    assert all(sha(r / p) == h for p, h in inputs['sourceFiles'].items())
    proof.update(finishedAtUtc=now(), lockAtEnd=locked(), allFrozenRuntimeAndAuthoredSourceInputsStillExact=True, originalDatabaseRetained=cluster.exists())
    write(out, proof); fcntl.flock(guard, fcntl.LOCK_UN)
print(proof['status'], flush=True)
