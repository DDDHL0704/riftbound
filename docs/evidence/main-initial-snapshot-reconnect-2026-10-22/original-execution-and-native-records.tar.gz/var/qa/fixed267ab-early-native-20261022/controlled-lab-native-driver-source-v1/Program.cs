using System.Collections.Concurrent;
using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.Json.Serialization;
using Microsoft.AspNetCore.SignalR.Client;
using Microsoft.Extensions.DependencyInjection;
using Riftbound.Contracts;

Check(args.Length == 2, "Only fresh controlled-output and current private auth directories.");
var output = Path.GetFullPath(args[0]); var originals = Path.GetFullPath(args[1]);
Check(!Directory.Exists(output), "Never overwrite an original controlled room.");
Directory.CreateDirectory(output);
using var deadline = new CancellationTokenSource(TimeSpan.FromSeconds(80)); var ct = deadline.Token;
var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
using var healthClient = new HttpClient();
using var health = JsonDocument.Parse(await healthClient.GetStringAsync("http://127.0.0.1:15847/health", ct));
Check(health.RootElement.GetProperty("environment").GetString() == "Development"
    && health.RootElement.GetProperty("persistenceMode").GetString() == "postgres", "Declared controlled Development and real PostgreSQL only.");
var room = "N42-LAB-" + Guid.NewGuid().ToString("N")[..10].ToUpperInvariant();
using var trace = new StreamWriter(new GZipStream(new FileStream(Path.Combine(output, "original-private-controlled-wire.ndjson.gz"), FileMode.CreateNew), CompressionLevel.SmallestSize));
var profiles = new[] { "a", "b" }.Select(r => JsonNode.Parse(File.ReadAllText(Path.Combine(originals, "session-" + r + ".json")))!).ToArray();
await using var a = new Side(profiles[0], "a", room, output, trace); await using var b = new Side(profiles[1], "b", room, output, trace);
var sides = new[] { a, b };
foreach (var side in sides) await side.Connect();
await Until(() => sides.All(s => s.Snapshot.GetProperty("players").EnumerateObject().Count() == 2), "Original two seated lobby views.");
var beforeSeed = a.Snapshot.GetProperty("tick").GetInt64();
await a.Hub.InvokeAsync("SeedScenario", room, a.Actor, "battlefield-turn-start-destroy-draw", "fixed-lab-controlled-seed-" + Guid.NewGuid().ToString("N"), ct);
await Until(() => sides.All(s => s.Snapshot.GetProperty("tick").GetInt64() > beforeSeed) && a.Enabled("END_TURN"), "Existing recorded Lab position.");
Check(!b.Enabled("END_TURN"), "Only original A owns the seeded main phase.");
var command = new JsonObject { ["cmdType"] = "END_TURN", ["promptId"] = a.Prompt.GetProperty("promptId").GetString(), ["snapshotTick"] = a.Prompt.GetProperty("snapshotTick").GetInt64() };
var intent = "fixed-lab-controlled-end-" + Guid.NewGuid().ToString("N");
var receipt = await a.Hub.InvokeAsync<CommandReceiptDto>("SubmitIntent", room, a.Actor, intent, JsonSerializer.SerializeToElement(command), ct);
Check(receipt.Accepted, "Actual original EndTurn must be accepted: " + receipt.ErrorCode);
await Until(() => sides.All(s => s.Snapshot.GetProperty("tick").GetInt64() == receipt.ServerTick && s.Prompt.GetProperty("snapshotTick").GetInt64() == receipt.ServerTick), "Both original current private views.");
Check(b.Enabled("CHOOSE_CARDS") && !a.Enabled("CHOOSE_CARDS")
    && a.Snapshot.GetProperty("timing").GetProperty("turnPlayerId").GetString() == b.Actor,
    "Only actual B Lab controller receives the original optional local sacrifice choice.");
var result = new { status = "CONTROLLED_LAB_ORIGINAL_TWO_SEATS_SEED_AND_END_READY_FOR_ACTUAL_EXPORTED_NATIVE_CHOICE_AND_PASSES", room,
    players = sides.Select(s => s.Actor).ToArray(), existingRecordedScenario = "battlefield-turn-start-destroy-draw",
    originalEndIntent = new { actor = a.Actor, clientIntentId = intent, rawCommand = command, receipt },
    expectedJournalCommands = 4, expectedNativeCommandActors = new[] { b.Actor, b.Actor, a.Actor }, expectedNativeCommandTypes = new[] { "CHOOSE_CARDS", "PASS_PRIORITY", "PASS_PRIORITY" },
    actualSeededGatewayPreparationNotOrdinaryFullGame = true, noOriginalOrdinaryRoomOrSeedChanged = true,
    visibleHardwareAndWindowsAcceptance = false };
await File.WriteAllTextAsync(Path.Combine(output, "controlled-lab-original-entry-v1.json"), JsonSerializer.Serialize(result, json), ct);
Console.WriteLine(JsonSerializer.Serialize(result, json));

async Task Until(Func<bool> condition, string reason)
{
    while (!condition()) { foreach (var side in sides) side.CheckErrors(); await Task.Delay(20, ct); }
    foreach (var side in sides) side.CheckErrors();
}
static void Check(bool value, string reason) { if (!value) throw new Exception(reason); }

sealed class Side : IAsyncDisposable
{
    readonly ConcurrentQueue<string> errors = new(); readonly object gate = new();
    JsonElement snapshot, prompt; string? token;
    public string Actor { get; }
    public HubConnection Hub { get; }
    public JsonElement Snapshot { get { lock (gate) return snapshot; } }
    public JsonElement Prompt { get { lock (gate) return prompt; } }
    readonly JsonNode profile; readonly string role, room, output; readonly StreamWriter trace;
    public Side(JsonNode profile, string role, string room, string output, StreamWriter trace)
    {
        this.profile = profile; this.role = role; this.room = room; this.output = output; this.trace = trace; Actor = profile["handle"]!.GetValue<string>();
        Hub = new HubConnectionBuilder().WithUrl("http://127.0.0.1:15847/hubs/game")
            .AddJsonProtocol(o => { o.PayloadSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase; o.PayloadSerializerOptions.Converters.Add(new JsonStringEnumConverter()); }).Build();
        Hub.On<WsServerMessage>("Joined", m => Receive("Joined", m));
        Hub.On<WsServerMessage>("Snapshot", m => Receive("Snapshot", m));
        Hub.On<WsServerMessage>("Prompt", m => Receive("Prompt", m));
        Hub.On<WsServerMessage>("Events", m => Receive("Events", m));
        Hub.On<WsServerMessage>("Error", m => Receive("Error", m));
    }
    void Receive(string kind, WsServerMessage m)
    {
        if (m.Payload is not JsonElement payload) return;
        lock (gate)
        {
            if (kind == "Joined")
            {
                token = payload.GetProperty("reconnectToken").GetString();
                var current = new JsonObject { ["handle"] = Actor, ["playerKey"] = profile["playerKey"]!.GetValue<string>(), ["roomId"] = m.RoomId,
                    ["reconnectToken"] = token, ["lastDeckId"] = profile["lastDeckId"]!.GetValue<string>(), ["serverUrl"] = "http://127.0.0.1:15847" };
                var path = Path.Combine(output, "session-" + role + ".json");
                File.WriteAllText(path, current.ToJsonString(new JsonSerializerOptions { WriteIndented = true }));
                if (!OperatingSystem.IsWindows()) File.SetUnixFileMode(path, UnixFileMode.UserRead | UnixFileMode.UserWrite);
            }
            else if (kind == "Snapshot") snapshot = payload.Clone();
            else if (kind == "Prompt") prompt = payload.Clone();
            else if (kind == "Error") errors.Enqueue(payload.GetProperty("code").GetString() ?? "UNKNOWN");
            if (kind != "Joined") lock (trace) { trace.WriteLine(JsonSerializer.Serialize(new { actor = Actor, kind, payload })); trace.Flush(); }
        }
    }
    public async Task Connect()
    {
        using var limit = new CancellationTokenSource(TimeSpan.FromSeconds(20));
        await Hub.StartAsync(limit.Token);
        var auth = await Hub.InvokeAsync<AuthResultDto>("Authenticate", Actor, profile["playerKey"]!.GetValue<string>(), limit.Token);
        if (!auth.Authenticated) throw new Exception("Existing own auth rejected.");
        await Hub.InvokeAsync("JoinRoom", room, Actor, (string?)null, limit.Token);
        while (token is null || Snapshot.ValueKind != JsonValueKind.Object || Prompt.ValueKind != JsonValueKind.Object) { CheckErrors(); await Task.Delay(20, limit.Token); }
    }
    public bool Enabled(string action) => Prompt.ValueKind == JsonValueKind.Object && Prompt.GetProperty("actionable").GetBoolean()
        && Prompt.GetProperty("candidates").EnumerateArray().Any(c => c.GetProperty("action").GetString() == action && c.GetProperty("enabled").GetBoolean());
    public void CheckErrors() { if (errors.TryPeek(out var error)) throw new Exception("Actual controlled preparation error " + error); }
    public ValueTask DisposeAsync() => Hub.DisposeAsync();
}
