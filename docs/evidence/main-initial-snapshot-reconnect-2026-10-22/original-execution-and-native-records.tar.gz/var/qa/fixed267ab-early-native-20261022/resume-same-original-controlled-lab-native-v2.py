# -*- coding: utf-8 -*-
import ast, datetime, errno, fcntl, gzip, hashlib, json, os, plistlib, pty, re, resource, socket, subprocess, threading, time, urllib.request
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CORE, (0, 0)); os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();load=lambda p:json.loads(p.read_text())
source=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py';nodes=[n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),globals())
functions=w/'controlled-lab-original-native-owner-functions-v1.py';exec(compile(functions.read_text(),str(functions),'exec'),globals())
pub=load(w/'frozen-fixed267ab-native-composition-v1.json');previous=load(w/'independent-fixed267ab-two-network-owner-terminal-v2.json')
assert previous['ownPostgresSmartStopped'] and previous['allOriginal345AuditSevenTablesExact'] and previous['allOriginal79NativeSevenTablesExact']
assert len(previous['actualAuditRoomsAtStop'])==345 and len(previous['actualNativeRoomsAtStop'])==79
api_runtime=Path(pub['apiRuntimeRoot']);helpers=Path(pub['helperRuntimeRoot']);profiles=w/'controlled-lab-native-prefix-v1';assert profiles.is_dir();resume_previous=load(w/'controlled-lab-native-owner-terminal-v1.json');assert resume_previous['ownApiStopped'] and resume_previous['ownPostgresSmartStopped'] and resume_previous['allOriginal345AuditSevenTablesExact'] and resume_previous['allOriginal79NativeSevenTablesExact'] and len(resume_previous['actualNativeRoomsAtStop'])==80
evidence=w/'controlled-lab-native-raw-v2';evidence.mkdir(exist_ok=False)
driver_root=w/'controlled-lab-native-driver-source-v1';dll=driver_root/'bin/Release/net10.0/Fixed267abControlledLabPrepareV1.dll';assert dll.is_file()
own_inputs={str(p.relative_to(w)):sha(p) for p in [dll,dll.with_suffix('.pdb'),driver_root/'Program.cs',driver_root/'probe.csproj',functions,Path(__file__)]}
terminal=w/'controlled-lab-native-owner-terminal-v2.json';assert not terminal.exists()
def checkpoint(name,data):
    with (evidence/name).open('x') as f:json.dump(data,f,ensure_ascii=False,indent=2)
def rows(name):
    raw={t:json.loads(query('riftbound_here_native',f"select coalesce(json_agg(t order by row_to_json(t)::text),'[]'::json)::text from (select * from {t} where match_id='{room}')t")) for t in tables}
    p=evidence/name;p.write_bytes(gzip.compress(json.dumps({'room':room,'originalRows':raw},ensure_ascii=False,indent=2).encode(),mtime=0));return {'path':str(p),'sha256':sha(p),'counts':{t:len(r) for t,r in raw.items()}}
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof={'status':'RUNNING_CURRENT_FIXED_CONTROLLED_LAB_NATIVE_NOT_ORDINARY_OR_VISIBLE_OR_WINDOWS','startedAtUtc':now(),'fixedCommit':pub['fixedCommit'],'fixedCiRun':pub['fixedCiRun'],'actualRuleInputs':pub['actualRuleInputs'],'existingScenario':'battlefield-turn-start-destroy-draw','ownedApiProcesses':[],'ownedNativeProcesses':[],'ownSourceAndDriverInputs':own_inputs,'lockAtStart':observe_lock(),'separateOriginalOrdinary65Command396EventGameRetained':True,'visibleHardwareAndPhysicalWindowsAcceptance':False}
api=driver=power=None;clients=[];pumps={};started=False;room=resume_previous['room'];audit=native=before_audit=before_native=None
try:
    frozen();assert all(sha(w/p)==h for p,h in own_inputs.items())
    assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
    with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
    power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid
    sock.mkdir(exist_ok=True);subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'controlled-lab-postgres-v2.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
    audit=rooms('riftbound_acceptance');all_native=rooms('riftbound_here_native');assert audit==previous['actualAuditRoomsAtStop'] and all_native==resume_previous['actualNativeRoomsAtStop'];native=[id for id in all_native if id!=room];assert native==previous['actualNativeRoomsAtStop']
    before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',native)
    checkpoint('original345-audit79-native-seven-table-baseline-v1.json',{'auditRooms':audit,'nativeRooms':native,'auditSevenTables':before_audit,'nativeSevenTables':before_native})
    start_api(3)
    entry=load(profiles/'controlled-lab-original-entry-v1.json');assert entry['room']==room;a,b=entry['players'];proof['room']=room;proof['players']=[a,b]
    original_frame=json.loads(gzip.decompress((w/'controlled-lab-native-raw-v1/before-cold-controlled-lab-original-frame-v1.json.gz').read_bytes()))
    proof.update(noNewRoomOrReseedOrOriginalFourInputResubmission=True,originalFailedOwnerTerminalSha256=sha(w/'controlled-lab-native-owner-terminal-v1.json'),originalFourInputFrameSha256=sha(w/'controlled-lab-native-raw-v1/before-cold-controlled-lab-original-frame-v1.json.gz'))
    before=export('before-cold-controlled-lab-original-frame-v1');initial=before['authoritativeState']
    assert len(before['commands'])==4 and [c['commandType'] for c in before['commands']]==['ROOM_SEAT','ROOM_SEAT','DEV_SEED_SCENARIO:battlefield-turn-start-destroy-draw','END_TURN']
    assert initial['turnPlayerId']==b and initial['pendingCardChoice']['playerId']==b and 'P2-BATTLEFIELD-ROSE-SACRIFICE' in initial['pendingCardChoice']['legalObjectIds'] and len(initial['stackItems'])==1 and initial['stackItems'][0]['controllerId']==b and initial['pendingCardChoice']['resolvingStackItemId']==initial['stackItems'][0]['stackItemId'] and initial['stackItems'][0]['triggerCost'] is None
    assert 'P2-OTHER' in initial['cardObjects'] and initial['objectLocations']['P2-OTHER']['battlefieldObjectId']=='P2-OTHER'
    assert before['commands']==original_frame['commands'] and before['events']==original_frame['events'] and initial==original_frame['authoritativeState'] and before['openingSeed']==original_frame['openingSeed'] and before['replayInitialState']==original_frame['replayInitialState']
    proof['originalAllSevenTablesBeforeNative']=rows('original-all-seven-tables-before-native-v1.json.gz')
    observers=[launch('a','lab-observe-a',1200),launch('b','lab-observe-b',1200)]
    native_wait(lambda:all(all(log_count(item[2],k)>=1 for k in ['Joined','Snapshot','Prompt']) for item in observers),'Both actual CI Main instances must receive original Lab choice views.',40,[item[0] for item in observers])
    counts=[{k:log_count(item[2],k) for k in ['Joined','Snapshot','Prompt']} for item in observers]
    api.terminate();api.wait(timeout=25);start_api(4)
    native_wait(lambda:all(all(log_count(item[2],k)>counts[i][k] for k in ['Joined','Snapshot','Prompt']) for i,item in enumerate(observers)),'Both same original CI Main processes cold restore the Lab choice.',45,[item[0] for item in observers])
    cold=export('after-cold-controlled-lab-original-frame-v1')
    assert cold['commands']==before['commands'] and cold['events']==before['events'] and cold['authoritativeState']==initial and cold['openingSeed']==before['openingSeed'] and cold['replayInitialState']==before['replayInitialState']
    for item in observers:wait_exit(item,40)
    proof['actualSameTwoCiNativeProcessesColdRestoredOriginalLabChoiceAndAllGameFrameFields']=True
    chosen=launch('b','lab-choice-b',600,'CHOOSE_CARDS')
    native_wait(lambda:count()==5,'Actual B CI Main must choose its one original local sacrifice.',30,[chosen[0]])
    paid=export('after-native-lab-local-cost-original-frame-v1');ps=paid['authoritativeState'];item=ps['stackItems'][0]
    assert paid['commands'][-1]['playerId']==b and paid['commands'][-1]['commandType']=='CHOOSE_CARDS' and paid['commands'][-1]['rawCommand']['chosenObjectIds']==['P2-BATTLEFIELD-ROSE-SACRIFICE']
    assert len(ps['stackItems'])==1 and ps['priorityPlayerId']==b and item['controllerId']==b and item['battlefieldStart']['controllerId']==b and item['battlefieldStart']['cardNo']=='UNL-209/219' and item['battlefieldStart']['drawCount']==1
    assert item['triggerCost']['destructionTarget']['objectId']=='P2-BATTLEFIELD-ROSE-SACRIFICE' and 'P2-BATTLEFIELD-ROSE-SACRIFICE' in ps['playerZones'][b]['graveyard'] and not ps['playerZones'][b]['hand']
    wait_exit(chosen,30);assert 'UI smoke staged CHOOSE_CARDS' in chosen[2].read_text()
    own_a=launch('a','lab-pass-a',1800,'PASS_PRIORITY');own_b=launch('b','lab-pass-b',600,'PASS_PRIORITY')
    native_wait(lambda:count()==7,'Actual B then A CI Main must close the original paid Lab skill.',35,[own_a[0],own_b[0]])
    for item_native in [own_a,own_b]:wait_exit(item_native,45);assert 'UI smoke staged PASS_PRIORITY' in item_native[2].read_text()
    final=export('final-controlled-lab-original-frame-v1');fs=final['authoritativeState']
    assert len(final['commands'])==7 and final['commands'][:4]==before['commands'] and final['events'][:len(before['events'])]==before['events'] and final['openingSeed']==before['openingSeed'] and final['replayInitialState']==before['replayInitialState']
    assert [c['playerId'] for c in final['commands'][4:]]==[b,b,a] and [c['commandType'] for c in final['commands'][4:]]==['CHOOSE_CARDS','PASS_PRIORITY','PASS_PRIORITY']
    assert fs['phase']=='MAIN' and fs['turnPlayerId']==b and not fs['stackItems'] and fs['pendingCardChoice'] is None and len(fs['playerZones'][b]['hand'])==2 and not fs['playerZones'][a]['hand']
    assert 'P2-BATTLEFIELD-ROSE-SACRIFICE' in fs['playerZones'][b]['graveyard'] and fs['cardObjects']['P2-BATTLEFIELD-AAA-OFFSITE']['damage']==0 and 'P2-OTHER' in fs['cardObjects']
    resolved=[e for e in final['events'] if e['event']['kind']=='BATTLEFIELD_TRIGGER_RESOLVED'];assert len(resolved)==1 and resolved[0]['event']['payload']['playerId']==b
    assert final['openingSeed']!=0 and final['replayInitialState']['status']=='EMPTY' and not final['replayInitialState']['seats']
    proof.update(status='PASS_CURRENT_FIXED_CI_MAIN_CONTROLLED_LAB_NATIVE_COST_THEN_TWO_RESPONSES_AND_SAME_PROCESS_COLD_SQL_INDEPENDENT_REPLAY_PENDING',totalCommands=7,events=len(final['events']),nativeAcceptedGameplayCommands=3,actualCapturedController=b,actualTurnPlayer=b,rawFinalFrame=str(evidence/'final-controlled-lab-original-frame-v1.json.gz'),originalFinalSevenTables=rows('original-final-all-seven-tables-v1.json.gz'),independentReadOnlyHistoryAndFullReplayStillPending=True,declineBranchNotCertifiedByThisPaidNativeScene=True,ordinaryFullGameNotClaimedByControlledLab=True)
except BaseException as e:
    proof.update(status='FAILED_OR_INTERRUPTED_CURRENT_CONTROLLED_LAB_ORIGINAL_ROOM_PREFIX_RETAINED',errorType=type(e).__name__,error=str(e));raise
finally:
    if driver is not None and driver.poll() is None:driver.terminate();driver.wait(timeout=20)
    for p,record,log in clients:
        if p.poll() is None:p.terminate();p.wait(timeout=20);record['terminatedOnlyForOwnedFailureCleanup']=True
        pumps[p.pid].join(timeout=10);record.update(exitCode=p.returncode,logSha256=sha(log),ptyFullyDrained=not pumps[p.pid].is_alive())
    if started and room is not None:
        try:export('owner-final-controlled-lab-original-frame-v1');proof['originalLatestFrameRetainedAtStop']=True
        except BaseException as e:proof['finalFrameExportErrorType']=type(e).__name__
    if api is not None and api.poll() is None:api.terminate();api.wait(timeout=25)
    proof['ownApiStopped']=api is None or api.poll() is not None
    if started:
        if before_audit is not None:
            proof['allOriginal345AuditSevenTablesExact']=digests('riftbound_acceptance',audit)==before_audit;proof['allOriginal79NativeSevenTablesExact']=digests('riftbound_here_native',native)==before_native;proof['actualAuditRoomsAtStop']=rooms('riftbound_acceptance');proof['actualNativeRoomsAtStop']=rooms('riftbound_here_native')
        proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
    if power is not None and power.poll() is None:power.terminate();power.wait(timeout=10)
    frozen();proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),allFrozenApiHelpers373NativeAndOwnDriverSourceBitsStable=all(sha(w/p)==h for p,h in own_inputs.items()))
    with terminal.open('x') as f:json.dump(proof,f,indent=2)
    fcntl.flock(guard,fcntl.LOCK_UN)
print(proof['status'],flush=True)
