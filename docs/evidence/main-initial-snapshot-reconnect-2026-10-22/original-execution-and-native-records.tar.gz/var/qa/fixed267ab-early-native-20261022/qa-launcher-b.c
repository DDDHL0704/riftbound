#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
int main(void){
int log=open("/Users/dinghaolin/MyProjects/riftbound/var/qa/fixed267ab-early-native-20261022/client-b.log",O_WRONLY|O_CREAT|O_APPEND,0600);if(log<0)return 125;dup2(log,1);dup2(log,2);close(log);
char *const args[]={"/Users/dinghaolin/MyProjects/riftbound/var/qa/fixed267ab-early-native-20261022/Riftbound-B.app/Contents/MacOS/符文战场","--resolution","1280x720","--position","0,30","--","--riftbound-server=http://127.0.0.1:15847","--riftbound-session-file=/Users/dinghaolin/MyProjects/riftbound/var/qa/fixed267ab-early-native-20261022/session-b.json","--riftbound-smoke-connect-only",0};execv(args[0],args);perror("execv native QA client");return 126;}
