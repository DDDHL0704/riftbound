# -*- coding: utf-8 -*-
from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;old=root/'var/qa/fixed3f2dc-early-native-20261022'
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();files=lambda p:{str(f.relative_to(p)):sha(f) for f in p.rglob('*') if f.is_file()}
fixed='267ab4f0690436d57cd45277e44c8bb5ee5ef6f0';run_id=39715300747
def write(p,d):
 with p.open('x') as f:json.dump(d,f,indent=2)
api_path=w/'fixed267ab-api-gameplay-closure-frozen-inputs-v2.json';api=load(api_path);runtime=Path(api['runtimeRoot'])
assert api['fixedCommit']==fixed and len(api['runtimeFiles'])==46 and files(runtime)==api['runtimeFiles']
assert all(sha(root/p)==h for p,h in api['allDeclaredApiGameplaySourceInputsExactFixedCommit'].items())
original=load(old/'fixed3f2dc-native-helper-and-network-frozen-v1.json');oldhelpers=Path(original['helperRuntimeRoot'])
assert files(oldhelpers)==original['helperRuntimeFiles']
own={p:h for p,h in original['helperRuntimeFiles'].items() if p not in original['runtimeFiles']};assert len(own)==41
helpers=w/'fixed267ab-native-helpers-runtime-v1';assert not helpers.exists();subprocess.run(['/bin/cp','-cR',str(runtime),str(helpers)],check=True)
for name,h in own.items():
 p=helpers/name;assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);subprocess.run(['/bin/cp','-c',str(oldhelpers/name),str(p)],check=True);assert sha(p)==h
helper_files=files(helpers);assert len(helper_files)==87 and all(helper_files[p]==h for p,h in api['runtimeFiles'].items())
probe=old/'fixed3f2dc-native-history-reader-runtime-v1/Fixed3f2dcNativeHistoryReaderV1.dll';assert probe.is_file()
measurements=[]
for label,r,expected in [('api',runtime,api['runtimeFiles']),('helpers',helpers,helper_files)]:
 for name in ['Riftbound.Api.deps.json','Riftbound.Api.runtimeconfig.json']:assert not (r/name).is_symlink()
 command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(r/'Riftbound.Api.deps.json'),'--runtimeconfig',str(r/'Riftbound.Api.runtimeconfig.json'),str(probe),'--loaded-inputs']
 actual=json.loads(subprocess.check_output(command,cwd=r,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0')))
 assert Path(actual['baseDirectory'])==r and len(actual['assemblies'])==4 and actual['hasRoomSeatReplay'] and actual['hasAtomicSeatCommit']
 for a in actual['assemblies']:assert Path(a['path'])==r/(a['name']+'.dll') and a['sha256']==expected[a['name']+'.dll'] and a['mvid']
 measurements.append({'runtime':label,'actualCommand':command,'actual':actual});assert files(r)==expected
identity=measurements[0]['actual']['actualRuleInputs'];assert all(m['actual']['actualRuleInputs']==identity for m in measurements)
assert identity['authoritySha256']=='70ccda5893a1b8b56cdceadee35e084b1e3f5b297ef64e1ce7d0cbeb141ce2d4' and identity['catalogSha256']=='e7455edc32d43f8253a9d0c6fedb83c347bebafbef064f9b8dffaaabc4b4d266'
network=w/'fixed267ab-native-network-net8-runtime-v1';assert not network.exists();network_sources={p:sha(root/p) for p in original['networkSourceHashes']}
for p,h in network_sources.items():assert hashlib.sha256(subprocess.check_output(['git','show',fixed+':'+p],cwd=root)).hexdigest()==h
with (w/'build-fixed267ab-native-network-net8-v1.log').open('xb') as log:
 subprocess.run(['/Users/dinghaolin/.dotnet/dotnet','publish','tests/Riftbound.NativeNetworkSmoke/Riftbound.NativeNetworkSmoke.csproj','--configuration','Release','--no-restore','--nologo','--output',str(network)],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
network_files=files(network);assert len(network_files)==22
assert files(runtime)==api['runtimeFiles'] and files(helpers)==helper_files and all(sha(root/p)==h for p,h in api['allDeclaredApiGameplaySourceInputsExactFixedCommit'].items())
measurement_path=w/'fixed267ab-actual-loaded-path-sha-mvid-and-input-identity-v1.json'
write(measurement_path,{'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fixedCommit':fixed,'status':'PASS','records':measurements,'existingProbeUsedOnlyLoadedInputsFlagNoPriorCandidateGameplayVerdict':True,'probeSha256':sha(probe)})
pub={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fixedCommit':fixed,'baseCommit':fixed,'fixedCiRun':run_id,'status':'FROZEN_FIXED267AB_API46_HELPERS87_NET8NETWORK22_ACTUAL_CI_APPS_PENDING','apiRuntimeRoot':str(runtime),'runtimeFiles':api['runtimeFiles'],'apiBuildInputsManifest':str(api_path),'apiBuildInputsManifestSha256':sha(api_path),'actualRuleInputs':identity,'helperRuntimeRoot':str(helpers),'helperRuntimeFiles':helper_files,'networkRuntimeRoot':str(network),'networkRuntimeFiles':network_files,'networkSourceHashes':network_sources,'networkDriverDependencyFramework':'net8.0','apiAndHelpersNotClaimedCiExported':True,'all41OriginalHelperOnlyFilesByteExactPriorFixedRuntime':own,'sourceGameplayClosureExactCurrentFixedCommit':True,'sourceGameplayClosureFileCount':252,'originalScoreOracleAssembly':'Fixed708OriginalBandleTreeScoreV1.dll','originalScoreOracleAssertionsRetainedWithFiniteField275FollowupRequiredIfActualField275':True,'allApiHelpersMetadataPhysicalAndLoadedFourAssemblyPathsShaMvidMeasured':True,'actualLoaderMeasurement':str(measurement_path),'actualLoaderMeasurementSha256':sha(measurement_path),'oldGamesNotMigrated':True,'priorFailuresAndOriginalAcceptedInputsRetained':True,'nativePackagesNotYetDownloaded':True,'currentWholeFullCiVisibleAndWindowsAcceptance':'OPEN','separateExtraReaderRuntimeNotCreatedExistingApiRuntimeReused':True}
write(w/'fixed267ab-native-helper-and-network-frozen-v1.json',pub)
print('FIXED267AB_FROZEN_API46_HELPERS87_NET8NETWORK22_ACTUAL4_PATH_SHA_MVID',identity['identitySha256'],flush=True)
