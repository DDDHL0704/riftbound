# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
from pathlib import Path
import datetime,hashlib,json,os,subprocess,zipfile
os.umask(0o077);w=Path(__file__).resolve().parent;fixed='267ab4f0690436d57cd45277e44c8bb5ee5ef6f0';run_id=39715300747;attempts=[]
for index in range(3):
 r=subprocess.run(['gh','api',f'repos/DDDHL0704/riftbound/actions/runs/{run_id}/artifacts'],capture_output=True,text=True,timeout=35);attempts.append({'attempt':index+1,'exitCode':r.returncode,'stderr':r.stderr})
 if r.returncode==0:break
assert r.returncode==0;metadata=json.loads(r.stdout);(w/'native-current-ready-ci-artifacts-v1.json').write_text(json.dumps({'receivedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'attempts':attempts,'response':metadata},indent=2)+'\n');folder=w/'native-current';folder.mkdir();results=[]
try:
 for name,filename in [('native-macos-latest','mac-ci-artifact.zip'),('native-windows-latest','windows-ci-artifact.zip')]:
  a=next(x for x in metadata['artifacts'] if x['name']==name);assert not a['expired'] and a['workflow_run']['head_sha']==fixed;target=folder/filename;downloads=[]
  for index in range(3):
   assert not target.exists()
   with target.open('xb') as out:r=subprocess.run(['gh','api',f'repos/DDDHL0704/riftbound/actions/artifacts/{a["id"]}/zip'],stdout=out,stderr=subprocess.PIPE)
   b=target.read_bytes();h=hashlib.sha256(b).hexdigest();valid=r.returncode==0 and len(b)==a['size_in_bytes'] and 'sha256:'+h==a['digest'];downloads.append({'attempt':index+1,'exitCode':r.returncode,'bytes':len(b),'sha256':h,'stderr':r.stderr.decode(errors='replace'),'validBackendSizeAndSha256':valid})
   if valid:break
   target.unlink();downloads[-1]['unusableTransportFragmentRetiredAfterSizeHashAndErrorRecorded']=True
  assert valid
  with zipfile.ZipFile(target) as z:
   assert z.testzip() is None;entries=[{'name':i.filename,'bytes':i.file_size,'crc32':format(i.CRC,'08x')} for i in z.infolist()]
  results.append({'name':name,'id':a['id'],'filename':filename,'actualBytes':len(b),'actualSha256':h,'backendDigest':a['digest'],'allOuterZipCrcVerified':True,'entries':entries,'downloadAttempts':downloads});print(name,'BACKEND_SIZE_SHA256_OUTER_CRC_PASS',len(b),flush=True)
finally:
 (w/'current-fixed-native-download-original-result-v1.json').write_text(json.dumps({'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fixedCommit':fixed,'runId':run_id,'artifacts':results,'previousFixed3f2dcPairRetainedUntilNewUsabilityVerified':True,'newBootInnerPayloadAndPhysicalWindowsStillPending':True},indent=2)+'\n')
