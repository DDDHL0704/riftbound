# -*- coding: utf-8 -*-
from pathlib import Path
import collections, datetime, gzip, hashlib, json, re, subprocess, types, xml.etree.ElementTree as ET, zipfile
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
fixed='267ab4f0690436d57cd45277e44c8bb5ee5ef6f0';run_id=39715300747
load=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
downloads=load(w/'ci267ab-all-nine-original-artifacts-receipt-v1.json')
assert downloads['fixedCommit']==fixed and downloads['runId']==run_id and len(downloads['jobs'])==11 and all(s=='success' for s in downloads['jobs'].values())
artifacts={a['name']:a for a in downloads['artifacts']};assert len(artifacts)==9
for a in artifacts.values():
 b=Path(a['path']).read_bytes();assert len(b)==a['bytes'] and sha(b)==a['sha256'] and 'sha256:'+sha(b)==a['backendDigest']
 with zipfile.ZipFile(a['path']) as z:assert z.testzip() is None
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def collect(path,current=False):
 cases=collections.Counter();methods=set();matrices=[];hashes={};outcomes=collections.Counter()
 with zipfile.ZipFile(path) as z:
  if current:
   assert z.read('ci-rule-suite-commit.txt').decode().strip()==fixed
   plan=json.loads(z.read('ci-rules/plan.json'));summary=json.loads(z.read('ci-rules/summary.json'))
   assert summary['profile']=='full' and summary['status']=='PASSED' and summary['total']==13585
   planned=[m for s in plan['shards'] for m in s['methods']];assert len(planned)==len(set(planned))==plan['discoveredMethods']==7684
  for name in z.namelist():
   if not name.endswith('/results.trx'):continue
   raw=z.read(name);hashes[name]=sha(raw);doc=ET.fromstring(raw);actual=set()
   definitions={d.get('id'):d.find('t:TestMethod',ns).attrib for d in doc.findall('.//t:UnitTest',ns)}
   for row in doc.findall('.//t:UnitTestResult',ns):
    outcome=row.get('outcome');outcomes[outcome]+=1;assert outcome=='Passed'
    definition=definitions[row.get('testId')];method=definition['className']+'.'+definition['name'];methods.add(method);actual.add(method);cases[row.get('testName')]+=1
    for output in row.findall('.//t:StdOut',ns):
     for line in (output.text or '').splitlines():
      if line.startswith('PRECONSTRUCTED_MATRIX '):matrices.append(json.loads(line[len('PRECONSTRUCTED_MATRIX '):]))
   if current:
    counters=doc.find('.//t:Counters',ns).attrib;assert int(counters['total'])==int(counters['passed']) and counters['failed']=='0' and counters['notExecuted']=='0'
    assert actual==set(next(s['methods'] for s in plan['shards'] if s['name']==name.split('/')[-2]))
  if current:assert methods==set(planned) and sum(cases.values())==13585
 return cases,methods,matrices,hashes,outcomes
current=collect(Path(artifacts['conformance-results']['path']),True)
prior=load(root/'var/qa/battlefield-start-you-lab-20261022/ci3f2dc-entire-full-independent-verification-v1.json')
oldartifact=next(a for a in prior['artifacts'] if a['name']=='conformance-results');assert sha(Path(oldartifact['path']).read_bytes())==oldartifact['sha256']
before=collect(Path(oldartifact['path']))
assert sum(before[0].values())==13560 and len(before[1])==7681 and before[4]=={'Passed':13560}
assert not(before[0]-current[0]) and before[1]<=current[1]
added=current[0]-before[0];added_methods=current[1]-before[1]
assert sum(added.values())==25 and len(added_methods)==3 and all('.DuskRoseLabControllerYouTests.' in name for name in added)
assert len(current[2])==1;matrix=current[2][0]
decks=json.loads(gzip.decompress((root/'var/qa/graveyard-source-fixed-candidate-20261020/native-visible-v1/live-api-eleven-preconstructed-decks-original.json.gz').read_bytes()))
ids=[d['id'] for d in decks];pairs={a+'-vs-'+b for a in ids for b in ids if a!=b}
assert len(ids)==11 and matrix['seed']==424242 and matrix['deckCount']==11 and matrix['pairCount']==110 and set(matrix['completed'])==pairs==set(prior['matrix']['completed']) and all(re.fullmatch('[0-9a-f]{64}',h) for h in matrix['completed'].values())
full={m for m in current[1] if '.FullGameEndToEndTests.' in m}
assert len(full)==143 and full=={m for m in before[1] if '.FullGameEndToEndTests.' in m}
assert sum(n for name,n in current[0].items() if '.FullGameEndToEndTests.' in name)==151
stage=w/'ci267ab-independent-sql-members-v1';stage.mkdir();members=[]
for index in range(4):
 target=stage/str(index);target.mkdir()
 with zipfile.ZipFile(artifacts['postgres-partition-'+str(index)]['path']) as z:
  for name in z.namelist():
   assert not Path(name).is_absolute() and '..' not in Path(name).parts
   if name.endswith('/'):continue
   p=target/name;p.parent.mkdir(parents=True,exist_ok=True);raw=z.read(name)
   with p.open('xb') as f:f.write(raw)
   members.append({'partition':index,'originalZipMember':name,'path':str(p.relative_to(root)),'bytes':len(raw),'sha256':sha(raw)})
manifest=w/'exact-fixed267ab-sql-manifest-original-v1.json'
manifest.write_bytes(subprocess.check_output(['git','show',fixed+':tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'],cwd=root))
old_manifest=json.loads(subprocess.check_output(['git','show',prior['fixedCommit']+':tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'],cwd=root))
assert len(old_manifest['cases'])==58 and len(load(manifest)['cases'])==59 and load(manifest)['cases'][:58]==old_manifest['cases']
assert load(manifest)['cases'][58:]==[{'id':'battlefield-start-lab-you','sourceType':'BattlefieldStartLabYouSqlAcceptance'}]
gate_source=subprocess.check_output(['git','show',fixed+':scripts/sql-ci-gate.py'],cwd=root)
gate_path=w/'exact-fixed267ab-sql-ci-gate-original-v1.py';gate_path.write_bytes(gate_source)
module=types.ModuleType('exact_fixed267ab_sql_gate');exec(compile(gate_source,str(gate_path),'exec'),module.__dict__)
sql=module.verify(fixed,manifest,stage,dict.fromkeys(['scope','postgres_partitions','native_network'],'success'));assert sql['caseCount']==59
with zipfile.ZipFile(artifacts['postgres-results']['path']) as z:assert json.loads(z.read('result.json'))==sql
with zipfile.ZipFile(artifacts['full-verification-gate']['path']) as z:
 gate=json.loads(z.read('result.json'));assert gate['commit']==fixed and gate['status']=='FIXED_COMMIT_FULL_CHILD_JOBS_ALL_SUCCEEDED' and all(s=='success' for s in gate['jobs'].values())
with zipfile.ZipFile(artifacts['verification-scope']['path']) as z:
 decision=json.loads(z.read('decision.json'));governance=json.loads(z.read('governance.json'))
 assert decision['headSha']==fixed and decision['full'] is True and governance['governanceValid'] and not governance['semanticCoverageCertified'] and governance['errors']==[] and governance['currentReviewCount']==165
with zipfile.ZipFile(artifacts['native-network-results']['path']) as z:
 assert z.read('commit.txt').decode().strip()==fixed;log=z.read('native-network.log').decode()
 wire=next(json.loads(l[len('NATIVE_ROOM_IDENTITY_EVIDENCE '):]) for l in log.splitlines() if l.startswith('NATIVE_ROOM_IDENTITY_EVIDENCE '))
 peer=next(json.loads(l[len('NATIVE_ROOM_SEAT_PEER_EVIDENCE '):]) for l in log.splitlines() if l.startswith('NATIVE_ROOM_SEAT_PEER_EVIDENCE '))
 assert wire['rejectedActions']==15 and wire['leakedPrivateMessages']==0 and wire['validReconnectTokenWasSupplied']
 assert peer['firstPlayerOriginalTick']==1 and peer['firstPlayerRefreshedTick']==peer['secondPlayerTick']==2 and peer['privateViewers']==2 and peer['explicitSnapshotRequests']==peer['commandRetries']==peer['wrongViewerMessages']==0 and peer['originalOnePlayerViewRetained'] and peer['bothPrivateViewersRefreshed'] and peer['reconnectTokensAndPlayerKeysAbsentFromPrivateViews']
 assert 'Native canonical room identity passed:' in log and 'Native network recovery passed: socket loss, authenticated room restore, fresh snapshot, rejected-token guard.' in log
member_manifest=w/'ci267ab-original-sql-zip-members-v1.json.gz';member_manifest.write_bytes(gzip.compress(json.dumps(members,indent=2).encode(),mtime=0))
result={'atUtc':now(),'status':'FIXED267AB_ALL11_SUCCESS13585_CASES7684_METHODS_INDEPENDENT59_SQL_ORIGINAL_NETWORK_AND_PEER_VIEWS_VERIFIED','fixedCommit':fixed,'runId':run_id,'jobs':downloads['jobs'],'actualCases':13585,'actualMethods':7684,'actualOutcomes':dict(current[4]),'original13560Cases7681MethodsExactRetainedPlus25Cases3Methods':True,'priorActualCompleteEvidenceSha256':sha((root/'var/qa/battlefield-start-you-lab-20261022/ci3f2dc-entire-full-independent-verification-v1.json').read_bytes()),'original9633FailedRunAndN41LocalP79FailureNotRelabeled':True,'addedCaseNames':sorted(added.elements()),'addedMethodNames':sorted(added_methods),'fullGameMethods':143,'fullGameCases':151,'matrix':matrix,'allOriginal110PairIds11Decks424242AndVictoryReplayAssertionsRetained':True,'trxSha256':current[3],'sql':sql,'original58SqlCaseObjectsAndOrderExactOnly59Added':True,'originalNetwork':wire,'newPeerViews':peer,'artifacts':downloads['artifacts'],'scopeDecision':decision,'originalSqlZipMembers':str(member_manifest.relative_to(root)),'exactTargetSqlGateSourceSha256':sha(gate_source),'uncommittedClientSnapshot13AndIssue89NotCoveredByFixed267ab':True,'twoWebCommitsIncludedInFixed267abFullButNoBrowserProductAcceptanceClaimed':True,'visibleHardwarePairAndPhysicalWindowsRemainSeparate':True,'wholePrintingOrGoalCertified':False}
output=w/'ci267ab-entire-full-independent-verification-v1.json';assert not output.exists();output.write_text(json.dumps(result,indent=2))
assert {str(p.relative_to(root)) for p in stage.rglob('*') if p.is_file()}=={m['path'] for m in members}
for row in members:
 p=root/row['path'];assert len(p.read_bytes())==row['bytes'] and sha(p.read_bytes())==row['sha256']
 with zipfile.ZipFile(artifacts['postgres-partition-'+str(row['partition'])]['path']) as z:assert p.read_bytes()==z.read(row['originalZipMember'])
 p.unlink()
for p in sorted([p for p in stage.rglob('*') if p.is_dir()],key=lambda p:len(p.parts),reverse=True):p.rmdir()
stage.rmdir()
(w/'ci267ab-verified-duplicate-sql-extraction-retirement-v1.json').write_text(json.dumps({'atUtc':now(),'files':len(members),'logicalBytes':sum(r['bytes'] for r in members),'allOriginalNineZipsAndMemberHashesRetained':True,'onlyVerifiedTemporaryIndependentExtractionRemoved':True,'physicalApfsBytesNotInferred':True},indent=2))
print('PASS fixed267ab actual13585/7684; original13560/7681 retained+25/3;143full151cases110pairs11decks424242;59SQL;original15network0leaks+freshpeer;all11success;newclient13 and real coldMain race separate OPEN',flush=True)
