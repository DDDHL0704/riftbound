from pathlib import Path
import collections,datetime,gzip,hashlib,json,os,subprocess
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
protected=json.loads((w/'only-check-start-inputs-v1.json').read_text())['sourceInputHashes']
files=[]
for parent,dirs,names in os.walk(root/'var/qa'):
 dirs[:]=[d for d in dirs if d not in {'bin','obj','postgres','node_modules','.git','__pycache__'} and not d.endswith('.app') and 'runtime' not in d.lower()]
 for name in names:
  p=Path(parent)/name
  if p.suffix.lower()!='.pdf' or p.is_symlink() or not p.is_file() or p.stat().st_size<1024*1024:continue
  rel=str(p.relative_to(root));assert rel not in protected
  stat=p.stat();raw=p.read_bytes();assert len(raw)==stat.st_size and p.stat().st_mtime_ns==stat.st_mtime_ns
  files.append({'path':rel,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'mode':oct(stat.st_mode&0o777),'mtimeNs':stat.st_mtime_ns,'inode':stat.st_ino,'device':stat.st_dev})
groups=collections.defaultdict(list)
for row in files:groups[row['sha256']].append(row)
duplicates=[r for r in groups.values() if len(r)>1]
report={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'READ_ONLY_EXACT_PDF_CONTENT_INVENTORY_NO_MUTATION','largeOfficialPdfPaths':len(files),'allLargePdfLogicalBytes':sum(r['bytes'] for r in files),'uniquePayloads':len(groups),'duplicatePayloadGroups':len(duplicates),'additionalPathsWithSameBytes':sum(len(g)-1 for g in duplicates),'additionalLogicalBytesPotentiallyShareable':sum(sum(r['bytes'] for r in g[1:]) for g in duplicates),'groups':duplicates,'onlyLocalQaPdfPayloadsNotLiveCheckSourceOrRuntime':True,'independentApfsClonesPlannedNotHardLinks':True,'physicalReclamationNotInferredFromLogicalBytes':True,'dfBeforeInventory':subprocess.check_output(['df','-k',str(root)],text=True)}
out=w/'identical-official-pdf-original-inventory-v1.json.gz';assert not out.exists();out.write_bytes(gzip.compress(json.dumps(report,ensure_ascii=False,indent=2).encode(),mtime=0));print(json.dumps({k:v for k,v in report.items() if k not in {'groups','dfBeforeInventory'}},ensure_ascii=False),flush=True)
