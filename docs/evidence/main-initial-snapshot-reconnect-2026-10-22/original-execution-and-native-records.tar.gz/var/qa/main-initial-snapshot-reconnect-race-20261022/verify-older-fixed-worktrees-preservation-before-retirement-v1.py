from pathlib import Path
import collections,concurrent.futures,datetime,gzip,hashlib,json,os,subprocess
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
original=json.loads(gzip.decompress((w/'older-fixed-worktrees-original-inventory-v1.json.gz').read_bytes()))
sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
lsof=subprocess.run(['/usr/sbin/lsof','-nP','-Fpn'],capture_output=True,text=True,timeout=55);open_names=[];pid=None
for line in lsof.stdout.splitlines():
 if line.startswith('p'):pid=line[1:]
 elif line.startswith('n/'):open_names.append((pid,line[1:]))
def runs(row):
 proc=subprocess.run(['gh','api','repos/DDDHL0704/riftbound/actions/runs?head_sha='+row['head']+'&per_page=100'],capture_output=True,check=True,timeout=55);value=json.loads(proc.stdout);assert all(r['head_sha']==row['head'] for r in value['workflow_runs']);return row['path'],proc.stdout,value
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:ci={name:(raw,value) for name,raw,value in pool.map(runs,original['worktrees'])}
results=[]
for row in original['worktrees']:
 path=Path(row['path']);status=subprocess.check_output(['git','-C',str(path),'status','--porcelain=v1','--untracked-files=all'],text=True);assert status==row['status']
 assert subprocess.check_output(['git','-C',str(path),'rev-parse','HEAD'],text=True).strip()==row['head']
 assert subprocess.run(['git','merge-base','--is-ancestor',row['head'],'HEAD'],cwd=root,capture_output=True).returncode==0
 actual_open=[{'pid':pid,'path':name} for pid,name in open_names if name==str(path) or name.startswith(str(path)+'/')]
 tree=subprocess.check_output(['git','ls-tree','-r','-z',row['head']],cwd=root);tracked=[];mismatches=[]
 for item in tree.split(b'\0'):
  if not item:continue
  prefix,name=item.split(b'\t',1);mode,kind,oid=prefix.decode().split();rel=name.decode();p=path/rel
  if kind!='blob':mismatches.append({'path':rel,'reason':'NON_BLOB_ENTRY'});continue
  if not p.exists() and not p.is_symlink():mismatches.append({'path':rel,'reason':'MISSING'});continue
  raw=os.readlink(p).encode() if mode=='120000' else p.read_bytes();actual=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();tracked.append({'path':rel,'gitBlob':oid,'currentContentGitBlob':actual,'bytes':len(raw),'sha256':sha(raw),'mode':mode})
  if actual!=oid:mismatches.append({'path':rel,'reason':'CHANGED_BYTES'})
 derivative=None
 if status:
  target='docs/evidence/ambush-2026-10-13/entry-generation-red-results.trx';compressed=path/(target+'.gz');assert mismatches==[{'path':target,'reason':'MISSING'}] and status==' D '+target+'\n?? '+target+'.gz\n'
  blob=subprocess.check_output(['git','show',row['head']+':'+target],cwd=root);assert gzip.decompress(compressed.read_bytes())==blob
  derivative={'originalGitPath':target,'originalGitBlobSha256':sha(blob),'compressedPath':target+'.gz','compressedSha256':sha(compressed.read_bytes()),'decompressedBytesExactOriginalGitBlob':True}
 raw_ci,value=ci[row['path']];ci_out=w/('older-fixed-'+row['head'][:8]+'-complete-ci-status-original-v1.json.gz');assert not ci_out.exists();ci_out.write_bytes(gzip.compress(raw_ci,mtime=0));all_terminal=bool(value['workflow_runs']) and all(r['status']=='completed' for r in value['workflow_runs'])
 ignored=[]
 for rel in row['ignoredPaths']:
  p=path/rel;assert p.is_file() and not p.is_symlink();b=p.read_bytes();parts=p.relative_to(path).parts;regenerable=any(x in parts for x in ['bin','obj','.godot'])
  own_assembly=p.name.startswith('Riftbound') and p.suffix.lower() in {'.dll','.pdb'}
  record=p.suffix.lower() in {'.trx','.log'} or p.name.endswith(('.deps.json','.runtimeconfig.json'))
  old_installer=rel=='clients/godot/exports/macos/Riftbound.zip'
  keep=own_assembly or record or not regenerable and not old_installer
  ignored.append({'path':rel,'bytes':len(b),'sha256':sha(b),'mode':oct(p.stat().st_mode&0o777),'preserveInSingleArchive':keep,'disposition':'ORIGINAL_OWN_EXECUTED_ASSEMBLY_OR_RECORD_OR_LOCAL_ONLY_SOURCE_VISUAL' if keep else 'SUPERSEDED_NATIVE_INSTALLER_USER_ONLY_CURRENT' if old_installer else 'REGENERABLE_COMPILER_OR_GODOT_OUTPUT'})
 assert not mismatches or derivative
 results.append({'path':str(path),'head':row['head'],'sourceTree':sha(tree),'allTrackedOriginalGitBlobsExactExceptVerifiedLosslessTrxCompression':True,'trackedFiles':tracked,'originalStatus':status,'losslessTrxDerivative':derivative,'ignoredFiles':ignored,'actualOpenProcesses':actual_open,'ciOriginal':str(ci_out.relative_to(root)),'ciRawSha256':sha(raw_ci),'ciStates':[{'id':r['id'],'status':r['status'],'conclusion':r['conclusion']} for r in value['workflow_runs']],'allRemoteRunsTerminal':all_terminal,'canRetireAfterSingleArchiveValidation':not actual_open and all_terminal})
proof={'atUtc':now(),'status':'PRE_RETIREMENT_ALL_OLD_FIXED_WORKTREE_GIT_SOURCE_CI_OPEN_PROCESS_AND_IGNORED_PURPOSE_VERIFIED_NO_REMOVAL','worktrees':results,'allTrackedSourceAndTestsRecoverableFromExistingMainAncestorCommits':True,'lsofExitCode':lsof.returncode,'currentCheck3344AndNative1419_23PathsNotInAnyOldWorktree':True,'currentWorktreeAndUnrelatedDotClaudeNeverTargeted':True,'noDatabaseOrOfficialOriginalSourceDeletionProposed':True}
out=w/'older-fixed-worktree-source-purpose-and-terminal-verification-v1.json.gz';assert not out.exists();out.write_bytes(gzip.compress(json.dumps(proof,ensure_ascii=False,indent=2).encode(),mtime=0));print(json.dumps([{'path':r['path'],'trackedFiles':len(r['trackedFiles']),'allOriginalGitSourceExact':r['allTrackedOriginalGitBlobsExactExceptVerifiedLosslessTrxCompression'],'originalTrxCompressionOnly':bool(r['losslessTrxDerivative']),'ignoredFiles':len(r['ignoredFiles']),'preservePayloadFiles':sum(x['preserveInSingleArchive'] for x in r['ignoredFiles']),'openPids':[x['pid'] for x in r['actualOpenProcesses']],'remoteRuns':r['ciStates'],'canRetireAfterArchive':r['canRetireAfterSingleArchiveValidation']} for r in results]),flush=True)
