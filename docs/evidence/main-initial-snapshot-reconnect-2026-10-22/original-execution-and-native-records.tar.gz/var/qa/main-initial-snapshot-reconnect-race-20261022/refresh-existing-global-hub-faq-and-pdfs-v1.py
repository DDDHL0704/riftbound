# -*- coding: utf-8 -*-
from pathlib import Path
from urllib.request import Request,urlopen
from html.parser import HTMLParser
from html import escape
from concurrent.futures import ThreadPoolExecutor
import ast,datetime,gzip,hashlib,json,re
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;out=w/'global-source-readback-v1';out.mkdir()
old=root/'var/qa/current-whole-source-monitor-20261022/global-page-originals-v1';now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda b:hashlib.sha256(b).hexdigest()
source=root/'scripts/audit/snapshot-global-rules.py';nodes=[n for n in ast.parse(source.read_text()).body if isinstance(n,ast.ClassDef) and n.name=='Body' or isinstance(n,ast.FunctionDef) and n.name=='article_body'];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),globals())
def page(raw):return json.loads(re.search(rb'<script id="__NEXT_DATA__"[^>]*>(.*?)</script>',raw,re.S).group(1))['props']['pageProps']['page']
def fetch(item):
 name,url=item;started=now()
 with urlopen(Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=40) as response:raw=response.read();status=response.status;resolved=response.url;headers=dict(response.headers)
 before_path=old/(name+'.html.gz');before_raw=gzip.decompress(before_path.read_bytes());before=page(before_raw);current=page(raw);body=article_body(current);prior_body=article_body(before);parser=Body();parser.feed(body)
 original=before_path
 if raw!=before_raw:
  original=out/(name+'.html.gz');original.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(original.read_bytes())==raw
 selected=lambda p:[b for b in p['blades'] if b.get('type') in {'articleRichText','articleRichTextAccordion'}]
 surfaces=lambda p:sum(1 if b.get('type')=='articleRichText' else len(b.get('groups',[])) for b in selected(p))
 record={'url':url,'resolvedUrl':resolved,'startedAtUtc':started,'receivedAtUtc':now(),'region':'GLOBAL','pageLocale':current['locale'],'language':'en-US','httpStatus':status,'responseHeaders':{k:v for k,v in headers.items() if k.lower() in {'date','etag','last-modified','content-type'}},'rawBytes':len(raw),'rawSha256':sha(raw),'original':str(original.relative_to(root)),'originalCompressedSha256':sha(original.read_bytes()),'sameRawHtmlReusedWithoutDuplicate':raw==before_raw,'fullOriginalHtmlLocalOnlyNotRepublished':True,'exactContentId':current['analytics']['contentId'],'exactRevision':current['analytics']['rev'],'declaredPublication':current.get('displayedPublishDate'),'sameExactContentIdAndRevisionAsRegistered':current['analytics']['contentId']==before['analytics']['contentId'] and current['analytics']['rev']==before['analytics']['rev'],'title':current['title'],'allRichTextAndAccordionSurfaces':surfaces(current),'allRichTextAndAccordionStructuredValuesExactPrevious':selected(current)==selected(before),'completePrimaryBodySha256':sha(body.encode()),'sameCompletePrimaryBodyAsPreviouslyRegistered':body==prior_body,'allPrimaryBodyLinks':parser.links,'noGameEffectiveDatePrintingLanguageRegionalLegalityOrCatalogAdoptionInferred':True,'allOriginalPrintingUniverseAndKnownGapsRetained':True}
 (out/(name+'.receipt.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2));return record
urls=[('rules-hub','https://playriftbound.com/en-us/rules-hub/'),('product-drawing-faq','https://playriftbound.com/en-us/news/announcements/product-drawing-faq/')]
with ThreadPoolExecutor(max_workers=2) as pool:pages=list(pool.map(fetch,urls))
known=json.loads((root/'data/official/upstream/2026-10-11/global-rules-sources.json').read_text())['records'];pdfs=[]
for url in sorted({u for p in pages if p['url'].endswith('/rules-hub/') for u in p['allPrimaryBodyLinks'] if u.endswith('.pdf')}):
 candidates=[p for p in known if p['url']==url or p.get('resolvedUrl')==url];assert len(candidates)==1;prior=candidates[0];old_raw=root/prior['localPath'];assert old_raw.is_file() and sha(old_raw.read_bytes())==prior['sha256'];started=now()
 with urlopen(Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=40) as response:raw=response.read();status=response.status;headers=dict(response.headers)
 assert raw.startswith(b'%PDF');same=sha(raw)==prior['sha256'];target=old_raw
 if not same:target=out/(sha(raw)+'.pdf');target.write_bytes(raw)
 pdfs.append({'url':url,'startedAtUtc':started,'receivedAtUtc':now(),'region':'GLOBAL','language':'en-US','httpStatus':status,'responseHeaders':{k:v for k,v in headers.items() if k.lower() in {'date','etag','last-modified','content-type'}},'bytes':len(raw),'sha256':sha(raw),'sameAllOriginalPdfBytesAsRegistered':same,'exactOriginalPath':str(target.relative_to(root)),'equalPdfNotDuplicatedOnDisk':same,'originalPublicationEffectiveAndConfirmationDatesNotRewritten':True})
assert len(pdfs)==2
result={'atUtc':now(),'status':'FRESH_EXISTING_GLOBAL_RULES_HUB_AND_ALREADY_REGISTERED_KDA_DRAW_FAQ_COMPLETE_RICH_TEXT_AND_ACCORDION_PLUS_TWO_PDF_READBACK','articleExtractorSourceSha256':sha(source.read_bytes()),'pages':pages,'pdfs':pdfs,'alreadyRegisteredKdaSourceManifest':'docs/evidence/room-seat-journal-inputs-2026-10-22/global-kda-couture-source-supplement.json','alreadyRegisteredFiveExactPrintingApplicabilityGatesRemainOpen':True,'noDuplicateNewFaqGateOrSourceDeltaFromRediscoveringKnownUrl':True,'pageChromeOrRelatedCarouselChangesAreNotPrimaryRuleRevision':True,'old1740Printings14293Rules705OutsideEightEnglishGap139CnNewsAndSevenSourceDeltasRetained':True,'runtimeCatalogAuthorityAndRootTrackedManifestNotMutatedByReadback':True,'semanticCoverageCertified':False}
(w/'current-global-hub-existing-kda-faq-and-two-pdf-readback-v1.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print('GLOBAL source-only:',[(p['title'],p['allRichTextAndAccordionSurfaces'],p['sameCompletePrimaryBodyAsPreviouslyRegistered'],p['sameExactContentIdAndRevisionAsRegistered']) for p in pages],'twoPDFsame',[p['sameAllOriginalPdfBytesAsRegistered'] for p in pdfs],flush=True)
