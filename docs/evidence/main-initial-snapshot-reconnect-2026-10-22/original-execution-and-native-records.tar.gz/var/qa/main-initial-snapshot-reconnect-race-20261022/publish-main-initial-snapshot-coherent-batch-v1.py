# -*- coding: utf-8 -*-
from pathlib import Path
import copy, datetime, gzip, hashlib, io, json, re, subprocess, tarfile
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
native=root/'var/qa/fixed267ab-early-native-20261022'
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p,v):
 with p.open('x') as f:json.dump(v,f,ensure_ascii=False,indent=2)
def pin(p,role=None):
 v={'path':str(p.relative_to(root)),'sha256':sha(p)}
 if role:v['role']=role
 return v
# All terminal, preservation and governance preconditions precede publication.
final=load(w/'final-only-check-original-retention-v1.json');start=load(w/'only-check-start-inputs-v1.json')
assert (final['actualCases'],final['actualMethods'],final['newCases'],final['newMethods'])==(13449,7550,13,7) and final['outcomes']=={'Passed':13449}
assert all(sha(root/p)==h for p,h in start['sourceInputHashes'].items())
base='267ab4f0690436d57cd45277e44c8bb5ee5ef6f0';assert start['baseCommit']==base and subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()==base
mp=root/'docs/audit/current-manifest.json';m=load(mp);old=copy.deepcopy(m);rp=root/m['inputs']['reviews']['path'];reviews=load(rp);review_bytes=rp.read_bytes()
prep=load(w/'client-snapshot-product-gate-publication-preparation-v1.json');assert prep['currentManifestSha256']==sha(mp)
assert (len(reviews['reviews']),len(m['reviewContexts']),len(m['acceptanceGates']),len(m['laterSourceDeltas']))==(165,80,250,7)
contexts=json.loads(gzip.decompress((w/'complete-original80-contexts-before-client-snapshot-refresh-v1.json.gz').read_bytes()));assert contexts==m['reviewContexts'] or any(v==m['reviewContexts'] for v in contexts.values())
cn=load(w/'current-cn-rule-directory-and-known-source-versions-v1.json');glob=load(w/'current-global-hub-existing-kda-faq-and-two-pdf-readback-v1.json')
assert cn['unchangedKnownDocuments']==16 and cn['conditionalNotModifiedResponses']==15 and cn['noEqualPdfPayloadCopiesCreated']
assert all(p['sameCompletePrimaryBodyAsPreviouslyRegistered'] and p['allRichTextAndAccordionStructuredValuesExactPrevious'] for p in glob['pages']) and glob['noDuplicateNewFaqGateOrSourceDeltaFromRediscoveringKnownUrl']
closure_path=native/'fixed267ab-early-native-and-real-reconnect-race-closure-v1.json';closure=load(closure_path)
assert closure['fixedCommit']==base and closure['priorLabSameProcessColdNativeClient'].startswith('FAILED_') and closure['apiAndOwnedPgStopped'] and closure['allOriginal345Audit80NativeSevenTablesExactAtFinalReadOnlyPass']
for name,digest in closure['receiptSha256'].items():assert sha(native/name)==digest
counter=load(w/'actual-fixed267ab-native-counterexample-v1.json');assert sha(root/counter['nativeErrorLog']['path'])==counter['nativeErrorLog']['sha256'] and counter['currentNativeColdAcceptance'].startswith('FAILED')
full_path=w/'ci267ab-entire-full-independent-verification-v1.json';full=load(full_path) if full_path.exists() else None
if full:assert (full['actualCases'],full['actualMethods'],full['sql']['caseCount'])==(13585,7684,59) and len(full['jobs'])==11 and all(s=='success' for s in full['jobs'].values())
baseline=root/'docs/evidence/lab-start-you-current-cn16-2026-10-22/final-governance.json.gz';oldgov=json.loads(gzip.decompress(baseline.read_bytes()));assert oldgov['governanceValid'] and len(oldgov['remainingObligations'])==17181
prior=w/'prior-main-snapshot-publication-v1';prior.mkdir()
for p in [mp,root/'docs/PROJECT_STATUS.md']:(prior/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
ev=root/'docs/evidence/main-initial-snapshot-reconnect-2026-10-22';ev.mkdir()
document=root/'docs/MAIN_INITIAL_SNAPSHOT_RECONNECT_AUDIT_2026-10-22.md'
# Publish evidence once. Installers, frozen runtime dependencies, full external HTML,
# private profiles and backend ZIP originals remain in their existing local locations.
secret=re.compile(rb'(?i)(?:playerKey|reconnectToken)[\"\s]*[:=][\s\"]*((?:rt_|qa-)[a-z0-9_+/-]{16,})')
paths=sorted({p for base_dir in [w,native] for p in base_dir.rglob('*') if p.is_file()})
# Scan exact locally held session secrets as well as labeled JSON fields: raw
# SignalR invocation arrays do not necessarily carry playerKey field names.
known_secrets=set()
def collect_secrets(value):
 if isinstance(value,dict):
  for key,item in value.items():
   if key.lower() in {'playerkey','reconnecttoken'} and isinstance(item,str) and len(item)>=16:known_secrets.add(item.encode())
   else:collect_secrets(item)
 elif isinstance(value,list):
  for item in value:collect_secrets(item)
for p in paths:
 if any(x in {'bin','obj','__pycache__','native-current'} or x.endswith('.app') or 'runtime' in x.lower() for x in p.parts[:-1]):continue
 if p.name.endswith(('.json','.json.gz','.ndjson','.ndjson.gz')):
  try:
   raw=p.read_bytes();raw=gzip.decompress(raw) if p.suffix=='.gz' else raw
   if '.ndjson' in p.name:
    for line in raw.decode().splitlines():
     if line.strip():collect_secrets(json.loads(line))
   else:collect_secrets(json.loads(raw))
  except (ValueError,OSError,UnicodeDecodeError):pass
canonical={};rows=[];excluded=[];members={}
for p in paths:
 name=str(p.relative_to(root));parts=p.relative_to(root).parts
 reason=None
 if any(x in {'bin','obj','__pycache__','native-current'} or x.endswith('.app') or 'runtime' in x.lower() for x in parts[:-1]):reason='EXISTING_RUNTIME_OR_ONLY_CURRENT_INSTALLER_NOT_DUPLICATED'
 elif p.suffix=='.zip':reason='ONE_ORIGINAL_BACKEND_VERIFICATION_ZIP_RETAINED_LOCALLY_WITH_PUBLISHED_DIGEST'
 elif p.name.endswith(('.html','.html.gz')):reason='COMPLETE_OFFICIAL_HTML_RETAINED_LOCALLY_METADATA_AND_PRIMARY_HASH_PUBLISHED'
 elif p.name.startswith(('session-','profile-')) or p.suffix=='.env':reason='PRIVATE_QA_PROFILE_OR_AUTH_MATERIAL_LOCAL_ONLY'
 raw=p.read_bytes();inspect=raw
 if p.suffix=='.gz':
  try:inspect=gzip.decompress(raw)
  except OSError:pass
 if secret.search(inspect) or any(value in inspect for value in known_secrets):reason='PRIVATE_QA_AUTH_VALUE_LOCAL_ONLY'
 digest=hashlib.sha256(raw).hexdigest()
 if reason:excluded.append({'path':name,'bytes':len(raw),'sha256':digest,'reason':reason});continue
 member=canonical.get(digest)
 if member is None:canonical[digest]=name;member=name;members[member]=p
 rows.append({'path':name,'bytes':len(raw),'sha256':digest,'archiveMember':member})
archive=ev/'original-execution-and-native-records.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as tar:
 for name,p in sorted(members.items()):
  raw=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(raw);info.mode=p.stat().st_mode&0o777;info.mtime=0;tar.addfile(info,io.BytesIO(raw))
with tarfile.open(archive,'r:gz') as tar:
 assert set(tar.getnames())==set(members)
 for row in rows:
  raw=tar.extractfile(row['archiveMember']).read();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
write(ev/'archive-map.json',{'atUtc':now(),'archive':pin(archive),'originalPathsWithExactCanonicalMember':rows,'localOnlyExclusions':excluded,'allMemberBytesHashesAndClosedSetVerified':True,'identicalPayloadsWithinThisArchiveStoredOnlyOnce':True,'appsInstallersSdksAndFrozenRuntimeNotDuplicated':True})
copies={
 'final-original-test-and-input-retention.json':w/'final-only-check-original-retention-v1.json',
 'actual-fixed267ab-native-counterexample.json':w/'actual-fixed267ab-native-counterexample-v1.json',
 'original-extracted-legacy-flow-red.json':w/'original-legacy-flow-red-execution-v1.json',
 'current-all16-cn-rule-version-readback.json':w/'current-cn-rule-directory-and-known-source-versions-v1.json',
 'current-global-hub-existing-kda-and-pdfs-readback.json':w/'current-global-hub-existing-kda-faq-and-two-pdf-readback-v1.json',
 'preceding-fixed267ab-native-main-network-paid-lab-and-race-closure.json':closure_path,
 'new-issue89-exact-readback.json':w/'new-main-snapshot-reconnect-race-issue-exact-readback-v1.json',
 'same-content-official-pdf-apfs-sharing.json.gz':w/'identical-official-pdf-apfs-sharing-result-v2.json.gz',
 'completed-old-fixed-worktree-retirement.json.gz':w/'completed-old-fixed-worktree-retirement-result-v1.json.gz'}
if full:copies['preceding-fixed267ab-complete-full.json']=full_path
for name,p in copies.items():(ev/name).write_bytes(p.read_bytes())
implementation=[pin(root/p,'implementation') for p in ['clients/godot/scripts/Main.cs','clients/godot/scripts/RiftboundGameHubClient.cs','clients/godot/scripts/RoomSnapshotRequest.cs']]
verification=[pin(root/p,'verification-source') for p in ['tests/Riftbound.ConformanceTests/RoomSnapshotRequestTests.cs','tests/Riftbound.ConformanceTests/Riftbound.ConformanceTests.csproj','tests/Riftbound.NativeNetworkSmoke/Program.cs']]
source={'schemaVersion':1,'id':'main-initial-snapshot-reconnect-2026-10-22','atUtc':now(),'scopeKind':'NATIVE_CLIENT_TRANSPORT_PRODUCT_FLOW_NOT_NEW_CARD_OR_RULE_REVIEW','region':'CN','language':'zh-CN','applicableAsOf':'2026-10-22','adoptedCoreEffectiveDate':'2026-10-16','existingCoreSha256':'d6fd7140f106f9b5b3dc0d5817fd040110fe870a6da9ee335ba7f4f70f892d11','sourceScope':'Initial Join/Reconnect followed by RequestSnapshot must stay bound to the captured hub, connection ID, room and authenticated actor. Current automatic restore is retained; no command retry, rule change or accepted-history migration.','exactPrintingOrRuleSemanticExpansion':False,'currentCnKnown16Documents':pin(ev/'current-all16-cn-rule-version-readback.json'),'globalExistingHubKdaAndPdfsObservationOnly':pin(ev/'current-global-hub-existing-kda-and-pdfs-readback.json'),'allPreviousSourcePublicationEffectiveAcquisitionRegionAndIdentityDatesRetained':True,'newSourceDeltaDetected':False,'baseCommit':base,'issue':'https://github.com/DDDHL0704/riftbound/issues/89','implementation':implementation,'verificationSources':verification,'actualDebugLoadedInputIdentity':final['actualFourLoadedDebugAssembliesAndRuleInputs'],'soleCheck':pin(ev/'final-original-test-and-input-retention.json'),'originalActualNativeCounterexample':pin(ev/'actual-fixed267ab-native-counterexample.json'),'extractedLegacy13Cases5Pass8FailIsSeparateFromOriginalActualNativeMain':pin(ev/'original-extracted-legacy-flow-red.json'),'precedingFixed267abBoundedProducts':pin(ev/'preceding-fixed267ab-native-main-network-paid-lab-and-race-closure.json'),'original59SqlExecutionIdentitiesAnd15NetworkRejectionGuardsByteExact':True,'currentFixedFullExpectedCases':13598,'currentFixedFullExpectedMethods':7691,'newFixedFullAndActualCiDefaultMainNativeRaceRepair':'OPEN','visibleHardwarePairAndPhysicalWindows':'OPEN','allOld165Reviews80Contexts250GatesSevenDeltas1740Printings14293Rules705OutsideEightEnglishGap139CnNewsAndKdaGatesRetained':True,'archive':pin(archive),'archiveMap':pin(ev/'archive-map.json'),'semanticCoverageCertified':False,'sameContentPdfIndependentApfsSharing':pin(ev/'same-content-official-pdf-apfs-sharing.json.gz'),'tenCompletedOldFixedWorktreesRetirement':pin(ev/'completed-old-fixed-worktree-retirement.json.gz'),'physicalDiskReclamationNotInferredFromLogicalClonedBytes':True}
if full:source['precedingFixed267abCompleteFull']=pin(ev/'preceding-fixed267ab-complete-full.json')
write(ev/'source-manifest.json',source);sp=pin(ev/'source-manifest.json','source-manifest')
refresh=[]
for identity,context in m['reviewContexts'].items():
 changes=[]
 for ref in context['implementation']:
  digest=sha(root/ref['path'])
  if digest!=ref['sha256']:changes.append({'path':ref['path'],'before':ref['sha256'],'after':digest});ref['sha256']=digest
 if changes:
  assert all(c['path']=='clients/godot/scripts/Main.cs' for c in changes)
  refresh.append({'id':identity,'changes':changes,'oldCompleteContext':old['reviewContexts'][identity]})
  context.update(currentImplementationCommit=base,currentImplementationIncludesUncommittedChanges=True,ciState='PENDING',currentInitialSnapshotInputRefresh={'sourceManifest':sp,'onlyCurrentImplementationPinsAndExplicitPendingStateRefreshed':True,'allOriginalSourceEvidenceBranchesAndVerificationRefsRetained':True,'newFixedFullAndCurrentProducts':'OPEN','noAdditionalPriorCardOrRuleCertification':True})
assert len(refresh)==4 and {r['id'] for r in refresh}=={r['contextId'] for r in prep['changes']}
assert sum(c==old['reviewContexts'][i] for i,c in m['reviewContexts'].items())==76
assert all(('verificationSources' in c)==('verificationSources' in old['reviewContexts'][i]) and c.get('verificationSources')==old['reviewContexts'][i].get('verificationSources') for i,c in m['reviewContexts'].items())
(ev/'complete-prior-four-contexts-current-input-refresh.json.gz').write_bytes(gzip.compress(json.dumps(refresh,ensure_ascii=False,indent=2).encode(),mtime=0))
cases=[{'id':'INITIAL_SNAPSHOT_CASE_'+str(i+1).zfill(2),'actualExecutedCase':name,'sourceVersion':{'baseCommit':base,'currentImplementationSha256':{p['path']:p['sha256'] for p in implementation}},'semanticReview':'NOT_A_CARD_RULE_SEMANTIC_REVIEW','testExecution':'ACTUAL_PASS_NEW13_FINAL647_AND_SOLE13449','fixedCommitCi':'PENDING_NEW_FIXED_FULL','productAcceptance':'OPEN_NEW_ACTUAL_CI_DEFAULT_MAIN_RECONNECT'} for i,name in enumerate(final['newCaseNames'])]
assert len(cases)==13
m['acceptanceGates'].append({'id':'NATIVE_INITIAL_ROOM_SNAPSHOT_RECONNECT_RACE','state':'OPEN','region':'CN','language':'zh-CN','sourceManifest':sp,'issue':'https://github.com/DDDHL0704/riftbound/issues/89','requirement':'Verify this fixed client in its actual CI default Main during initial room entry interrupted by automatic reconnect, including changed connection epoch or target and in-flight snapshot. Preserve active-operation failures, server rejection, cancellation, original auth/private guards and no command retries. Finish current full, normal score and original replay; visible paired controls and real Windows remain separate.','semanticReview':'CLIENT_TRANSPORT_ONLY_NO_NEW_CARD_OR_RULE_CERTIFICATION','implementation':implementation,'verificationSources':verification,'testExecution':{'newCases':13,'newMethods':7,'legacyActualPassed':5,'legacyActualFailed':8,'finalFocusCases':647,'finalFocusSelectedMethods':372,'onlyCheckCases':13449,'onlyCheckMethods':7550,'allOriginalCasesTheoryRowsAndAssertionsRetained':True},'behaviorCases':cases,'fixedCommitCi':'PENDING_NEW_FIXED_FULL','productAcceptance':'OPEN','wholePrintingCertified':False})
assert m['acceptanceGates'][:250]==old['acceptanceGates'] and m['laterSourceDeltas']==old['laterSourceDeltas'] and m['certificationScope']==old['certificationScope'] and rp.read_bytes()==review_bytes
m['currentNativeInitialSnapshotReconnectInputChange']={'sourceManifest':sp,'auditDocument':str(document.relative_to(root)),'onlyOneNewProductGateNoNewSemanticReview':True,'all165OldReviews80ContextIdentities250GatesSevenDeltasAnd17181ObligationsRetained':True,'fourCurrentImplementationPinRefreshes76WholeContextsExact':True,'expectedRemainingObligations':17182,'newFixedFullCurrentNativeRepairVisibleAndWindows':'OPEN','wholePrintingOrGoalComplete':False}
m['precedingFixed267abBoundedNativeMainNetworkPaidLabAndRealSnapshotRace']=pin(ev/'preceding-fixed267ab-native-main-network-paid-lab-and-race-closure.json')
if full:m['precedingFixed267abActualCompleteFullCiReadback']=pin(ev/'preceding-fixed267ab-complete-full.json')
assert (len(m['reviewContexts']),len(m['acceptanceGates']),len(m['laterSourceDeltas']))==(80,251,7)
mp.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
write(ev/'publication-original-governance-object-retention.json',{'atUtc':now(),'oldReviews':165,'oldContexts':80,'oldGates':250,'oldDeltas':7,'oldRemainingIds':17181,'newProductGates':1,'newSemanticReviews':0,'newBehaviorBranchesInsideExistingSemanticReviews':0,'expectedRemainingObligations':17182,'fourCompleteOldContextsArchived76WholeObjectsExact':True,'allOriginalOptionalVerificationSourcePresenceAndValuesExact':True,'allOldReviewsGatesDeltasAndCertificationScopeExact':True,'baselineGovernance':pin(baseline),'semanticCoverageCertified':False})
full_text='上一固定267ab完整CI39715300747实际11项success；九原验证产物经后台大小/SHA与全部CRC核验，独立13585/7684、59SQL，原13560/7681完整加25/3，143完整方法/151例、110配对/十一牌组/424242及网络15拒绝零泄露和双方tick2全部保留。' if full else '上一固定267ab完整CI39715300747尚待实际整次终态；已有子任务或局部产品结果不代替完整成功。'
text='''# 原生初次快照与自动重连并发的限定修复

本批是客户端传输流程修复，CN/zh-CN验收轮次适用2026-10-22，既有核心10-16版本及全部来源范围保留；没有新增整卡或规则条款认证。[输入与来源manifest](evidence/main-initial-snapshot-reconnect-2026-10-22/source-manifest.json)记录精确实现、运行输入和逐项证据。Goal active / NOT READY。

[#89](https://github.com/DDDHL0704/riftbound/issues/89)来自实际CI39715300747导出的267ab默认Main：受控实验室同局冷重连时，B在初次入房后的RequestSnapshot遇到自动重连，抛出InvokeCoreAsync连接未激活。两个原生进程虽零退出，原GD错误仍使这项产品验收失败。原四指令十事件、私有种子和EMPTY初态不改写；之后同一原局的支付分支通过不能覆盖这次失败。

原方法只在入口检查连接，随后两次await继续读取可能已改变的连接与房间。现在捕获hub、连接ID、房间和认证玩家，每个异步阶段确认仍是同一次请求；旧连接或目标被替换时结束旧快照请求，由既有自动恢复取得新视图。仅过期请求的InvalidOperationException被结束处理，当前连接异常、服务端拒绝与原取消令牌继续上抛；不重试游戏指令，不改认证、服务端权威、隐私或历史。连接库仅增加只读ConnectionId属性。

新增13例/7方法使用可控异步屏障：入房前或期间断连两例，连接/客户端/房间/玩家替换四例，快照进行中断连或快速恢复两例，服务端拒绝两例，当前异常、取消及健康单次请求各一例。先执行原两await提取流程实际5过8失败，再执行修复全部13通过；提取流程不是对实际原生Main的替代反例，两份证明分别保留。最终全部原生、Hub与身份相邻focus647/372全过；Godot Debug显式编译零警告零错误。

唯一check13449/7550全过零跳过，原13436/7543精确多重集合与方法完整保留，仅加13/7；3344源码/模式、1419Conformance和23原生Debug运行文件稳定，实际加载四程序集路径/SHA/MVID与规则输入单独记录。原1803份Conformance文件仅增加一个客户端辅助类编译链接，其余1802份、全部509旧C#、九原完整源码及原方法/Theory/断言逐字不变。143完整方法、151例、110配对、十一牌组和种子424242全部保留；本地check不冒称执行全143场。原59SQL身份/顺序和原15网络守卫源码逐字不变。原20网页文件的观察与规则check范围分开。

'''+full_text+'''

267ab实际CI默认Main双端普通原局完成正常8:0，共65原指令396事件，独立65权威历史/125快照/125提示及完整原回放通过。原43网关加两原子入座和三原生动作后，真实随机后巷酒吧超出首助手支持范围而停止的原件保留；随后沿同一48指令原局按该真实场地续17正常动作，不重提原生命令，不投降或燃尽。源码路径、deps缺客户端依赖及读者HintPath三类助手前置失败亦保留。

两真实网络房间原15越权拒绝零泄露、socket丢失与认证恢复守卫，以及双方无需显式请求或指令重试更新tick2通过；独立3历史/4快照/4提示和3事件及全部原回放。受控实验室沿同一四指令原局，由实际B客户端选择摧毁并双方响应，最终7指令24事件、独立7/13/13与完整原回放通过；费用在后续响应/抽牌前支付，B捕获控制者和场外单位位置不变。这是支付单分支证据，原生拒绝支付、当前修复候选和整卡仍OPEN。原345审计80原生七表保持，专用API及PG已正常停止。

本轮条件回读保留16份CN文档：15次304，一份等值正文不重复存PDF，原取得、发布及生效日期不变。GLOBAL入口和已登记K/DA抽签FAQ正文、十个正文/折叠问答区块及版本身份一致；两个当前链接PDF实际HTTP正文哈希与登记版本一致。完整HTML仅在本地保留，不把网页外围变化当正文换版，不重复登记既有K/DA缺口，五精确印次适用性门禁仍OPEN。国际资料不静默采用到CN运行输入。

原165审查、80上下文身份、250门禁、七源增量及17181义务身份完整保留。四上下文仅刷新Main实现绑定并显式待新full，76整对象原样，全部旧验证引用及可选字段存在性保留。只增一个产品门禁并挂13个精确执行分支，预期17182义务、251门禁，无新卡牌/条款语义审查，semanticCoverageCertified=false。1740印次/14293规则、705目录外、八英文缺口、139中文新闻和K/DA范围不缩减。

仅保留最新可用267ab双端及每平台一个安装包；旧3f应用/包945969841逻辑字节和六个已完成自有助手163文件2850047逻辑字节按清单退役，必要实际执行DLL/PDB与全部源码、失败、来源和原库保留，不推定APFS物理回收。另外74份同内容来源PDF改用独立APFS写时复制，共2160900648逻辑字节；全部原路径、内容、SHA、模式、mtime及扩展属性不变，3344活跃源码不变。最初Python缺扩展属性接口在任何改写前失败，原零修改收据保留；改用系统xattr后74份通过。该PDF共享操作前后可用磁盘未见明显回升，不声称其已释放2.16GB。另对10个已完成固定验证的旧工作树，逐Git blob核对全部源码/测试、原CI终态和打开进程；两处dirty差异均仅为与原Git字节一致的TRX无损压缩。1250原始执行/来源视觉路径的400唯一载荷已在31675325字节的单份压缩档逐项验证，保留全部原失败CI状态；随后普通git worktree remove不带force退役十份副本及旧导出，现仅当前工作树。其间实际df可用增加4242124KiB，约4.05GiB；3344当前源码与当前原生/数据库不变。旧源/测试可从原主线祖先提交恢复，旧物理运行目录已退役，不冒称仍可直接执行旧路径。新固定full预期13598/7691及59SQL，修复后实际CI默认Main重连、可见双端控件、Windows实机与全量目标分别OPEN。锁屏期间继续后台工作，锁定状态只按实际边界观察，不声称全程锁定或可见验收。
'''
document.write_text(text)
status='2026-10-22 本批：[原生初次快照与自动重连并发](MAIN_INITIAL_SNAPSHOT_RECONNECT_AUDIT_2026-10-22.md)。267ab实际CI默认Main冷重连报连接未激活，零进程退出仍记产品失败，#89追踪。捕获连接/客户端/房间/玩家，结束已过期请求；当前异常、服务端拒绝、取消和既有认证/恢复守卫保留，无指令重试。新13/7，原提取流程5过8失败，修复13全过；最终focus647/372、原生编译零警告错误、唯一check13449/7550全过，原13436/7543及全部Theory、143完整方法110配对11牌组424242与断言保留，3344/1419/23稳定。\n\n'+full_text+'267ab普通原局正常8:0共65/396及独立65/125/125、两网络局3/3及独立3/4/4、实验室支付7/24及独立7/13/13通过；同局冷重连GD错误单独FAILED，原历史和助手失败不改写。345审计80原生七表保持，API/库停止，现有证据不覆盖新修复候选或可见/Windows。\n\nCN16文档和已登记GLOBAL入口/KDA完整正文折叠问答及两PDF未换版，无重复新增来源。原165审查80上下文250门禁七增量17181义务保留；四Main输入绑定待新full、76整对象原样，只增一产品门禁至17182/251，语义false。全1740/14293/705/八英文/139新闻/KDA范围与旧59SQL/15网络守卫完整。仅最新双端和每平台一包；新固定full、修复后的实际原生、可见双端、Windows及全量目标OPEN。Goal active / NOT READY。\n\n以下原批按原范围与当时终态保留。\n\n'
status_path=root/'docs/PROJECT_STATUS.md';oldstatus=gzip.decompress((prior/'PROJECT_STATUS.md.gz').read_bytes()).decode();assert oldstatus.startswith('# 当前项目状态\n\n');status_path.write_text('# 当前项目状态\n\n'+status+oldstatus[len('# 当前项目状态\n\n'):])
print('PUBLISHED transport-only13cases;165reviews80contexts251gates7deltas;4explicitMainpins76wholecontexts;17181oldIDs+onegate expected17182;independentgovernance pending',flush=True)
