from pathlib import Path
import datetime,gzip,hashlib,io,json,os,subprocess,tarfile
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
source=w/'older-fixed-worktree-source-purpose-and-terminal-verification-v1.json.gz';original=json.loads(gzip.decompress(source.read_bytes()));items=original['worktrees'];assert len(items)==10 and all(r['canRetireAfterSingleArchiveValidation'] for r in items)
start=json.loads((w/'only-check-start-inputs-v1.json').read_text());assert all(sha(root/p)==h for p,h in start['sourceInputHashes'].items());main_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()
archive=w/'retired-older-fixed-worktrees-original-own-binaries-and-records-v1.tar.gz';assert not archive.exists();entries=[];members={};by_sha={}
for r in items:
 path=Path(r['path']);assert path!=root and path.is_dir() and (path/'.git').is_file()
 assert subprocess.check_output(['git','-C',str(path),'status','--porcelain=v1','--untracked-files=all'],text=True)==r['originalStatus']
 assert subprocess.check_output(['git','-C',str(path),'rev-parse','HEAD'],text=True).strip()==r['head']
 assert subprocess.run(['git','merge-base','--is-ancestor',r['head'],'HEAD'],cwd=root,capture_output=True).returncode==0
 selected=[{'path':x['path'],'sha256':x['sha256'],'bytes':x['bytes']} for x in r['ignoredFiles'] if x['preserveInSingleArchive']]
 if r['losslessTrxDerivative']:
  d=r['losslessTrxDerivative'];p=path/d['compressedPath'];selected.append({'path':d['compressedPath'],'sha256':d['compressedSha256'],'bytes':p.stat().st_size})
 for x in selected:
  p=path/x['path'];assert p.is_file() and not p.is_symlink() and p.stat().st_size==x['bytes'] and sha(p)==x['sha256']
  member=by_sha.get(x['sha256'])
  if member is None:member=r['head'][:8]+'/'+x['path'];by_sha[x['sha256']]=member;members[member]=p
  entries.append({'originalWorktree':r['path'],'head':r['head'],'originalRelativePath':x['path'],'bytes':x['bytes'],'sha256':x['sha256'],'archiveMember':member})
with tarfile.open(archive,'w:gz',compresslevel=9) as tar:
 for name,p in sorted(members.items()):
  b=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(b);info.mode=p.stat().st_mode&0o777;info.mtime=0;tar.addfile(info,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as tar:
 assert set(tar.getnames())==set(members)
 for r in entries:
  b=tar.extractfile(r['archiveMember']).read();assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']
map_path=w/'retired-older-fixed-worktree-original-payload-map-v1.json.gz';assert not map_path.exists();map_path.write_bytes(gzip.compress(json.dumps({'atUtc':now(),'archive':str(archive),'archiveSha256':sha(archive),'members':entries,'allMemberBytesHashesAndClosedSetVerifiedBeforeAnyRetirement':True,'oldTrackedSourceAndTestsRemainInOriginalMainAncestorGitCommits':True},ensure_ascii=False,indent=2).encode(),mtime=0))
print('PRESERVATION_ARCHIVE_ALL_BYTES_VERIFIED',len(entries),'original paths',len(members),'unique payloads',archive.stat().st_size,'compressed bytes',flush=True)
report={'startedAtUtc':now(),'status':'RUNNING_OLD_FIXED_WORKTREE_RETIREMENT_AFTER_COMPLETE_ARCHIVE','originalPreflightSha256':sha(source),'originalPayloadMapSha256':sha(map_path),'archiveSha256':sha(archive),'dfBefore':subprocess.check_output(['df','-k',str(root)],text=True),'removed':[],'currentMainHead':main_head,'allTenRemoteCiRunsAlreadyTerminalIncludingOriginalFailures':True,'originalFailingCisNeverPromotedToPass':True,'noCurrentCheckRuntimeOrSourceInputsOrLatestNativeAppsInstallersOrOriginalDbTargeted':True}
try:
 for r in items:
  path=Path(r['path']);assert subprocess.check_output(['git','-C',str(path),'status','--porcelain=v1','--untracked-files=all'],text=True)==r['originalStatus']
  # The only two dirty trees contain one proven lossless gzip derivative. Restore
  # their original Git blob and retire only that archived derivative, then use
  # ordinary clean worktree removal without --force.
  if r['losslessTrxDerivative']:
   d=r['losslessTrxDerivative'];p=path/d['compressedPath'];raw=gzip.decompress(p.read_bytes());assert hashlib.sha256(raw).hexdigest()==d['originalGitBlobSha256'] and sha(p)==d['compressedSha256']
   restored=path/d['originalGitPath'];assert not restored.exists();restored.write_bytes(raw);p.unlink()
  assert subprocess.check_output(['git','-C',str(path),'status','--porcelain=v1','--untracked-files=all'],text=True)==''
  lsof=subprocess.run(['/usr/sbin/lsof','-nP','-Fpn'],capture_output=True,text=True,timeout=55);assert not any(line=='n'+str(path) or line.startswith('n'+str(path)+'/') for line in lsof.stdout.splitlines())
  subprocess.run(['git','worktree','remove',str(path)],cwd=root,capture_output=True,check=True,timeout=55);assert not path.exists()
  report['removed'].append({'path':str(path),'commit':r['head'],'trackedSourceAndAllTestsRecoverableFromOriginalGitTree':True,'ownCompiledAssembliesDepsLogsScreenshotsAndOriginalTrxDerivativeInVerifiedArchive':True,'otherRegenerableCompilerGodotOutputAndSupersededInstallersRetired':True,'normalGitWorktreeRemoveWithoutForce':True});print('RETIRED_CLOSED_FIXED_WORKTREE',r['head'][:8],flush=True)
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()==main_head
 assert all(sha(root/p)==h for p,h in start['sourceInputHashes'].items())
 remaining=subprocess.check_output(['git','worktree','list','--porcelain'],cwd=root,text=True);assert [line[9:] for line in remaining.splitlines() if line.startswith('worktree ')]==[str(root)]
 report.update(status='PASS_TEN_COMPLETED_FIXED_VERIFICATION_WORKTREES_RETIRED_ALL_SOURCE_TESTS_GIT_AND_ORIGINAL_RECORD_ARCHIVE_RETAINED',all3344CurrentCheckSourceHashesStable=True,allOriginalCommitObjectsStillMainAncestors=True,currentOnlyWorktree=str(root),physicalDiskReclamationMustBeReadFromActualDfNotLogicalSize=True)
except BaseException as e:report.update(status='PARTIAL_OLD_WORKTREE_RETIREMENT_VERIFIED_ARCHIVE_ALL_BYTES_RETAINED',errorType=type(e).__name__,error=str(e));raise
finally:
 report.update(finishedAtUtc=now(),dfAfter=subprocess.check_output(['df','-k',str(root)],text=True))
 out=w/'completed-old-fixed-worktree-retirement-result-v1.json.gz';assert not out.exists();out.write_bytes(gzip.compress(json.dumps(report,ensure_ascii=False,indent=2).encode(),mtime=0));print(report['status'],flush=True)
