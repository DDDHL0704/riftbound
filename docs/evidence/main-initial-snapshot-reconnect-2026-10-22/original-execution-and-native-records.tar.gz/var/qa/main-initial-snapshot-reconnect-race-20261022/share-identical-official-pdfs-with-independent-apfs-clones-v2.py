from pathlib import Path
import datetime,gzip,hashlib,json,os,subprocess,uuid
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
inventory=json.loads(gzip.decompress((w/'identical-official-pdf-original-inventory-v1.json.gz').read_bytes()))
assert inventory['status']=='READ_ONLY_EXACT_PDF_CONTENT_INVENTORY_NO_MUTATION' and inventory['additionalPathsWithSameBytes']==74
protected=load(w/'only-check-start-inputs-v1.json')['sourceInputHashes'];changed=[];skipped=[];temporary=None
def attributes(path):
 names=subprocess.check_output(['/usr/bin/xattr',str(path)],text=True).splitlines()
 return {name:subprocess.check_output(['/usr/bin/xattr','-px',name,str(path)]) for name in names}
report={'startedAtUtc':now(),'status':'RUNNING_EXACT_PDF_APFS_CONTENT_SHARING_ALL_SOURCE_PATHS_RETAINED','inventorySha256':sha(w/'identical-official-pdf-original-inventory-v1.json.gz'),'dfBefore':subprocess.check_output(['df','-k',str(root)],text=True),'independentCopyOnWriteClonesNotHardLinks':True,'onlyLocalQaPdfBytesAndNoLiveVerificationSourceOrBinMutation':True}
try:
 for group in inventory['groups']:
  canonical=root/group[0]['path'];assert canonical.is_file() and not canonical.is_symlink() and sha(canonical)==group[0]['sha256']
  for row in group[1:]:
   path=root/row['path'];assert row['path'] not in protected and path.is_relative_to(root/'var/qa') and path.suffix.lower()=='.pdf' and not path.is_symlink()
   old=path.stat();assert old.st_size==row['bytes'] and old.st_mtime_ns==row['mtimeNs'] and oct(old.st_mode&0o777)==row['mode'] and sha(path)==row['sha256']
   if old.st_dev!=canonical.stat().st_dev or getattr(old,'st_flags',0):skipped.append({'path':row['path'],'reason':'DIFFERENT_DEVICE_OR_SPECIAL_FILE_FLAGS_NO_MUTATION'});continue
   xattrs=attributes(path)
   if attributes(canonical)!=xattrs:skipped.append({'path':row['path'],'reason':'DIFFERENT_EXTENDED_ATTRIBUTES_ORIGINAL_PATH_LEFT_UNCHANGED'});continue
   temporary=path.parent/('.riftbound-apfs-share-'+uuid.uuid4().hex)
   assert not temporary.exists();subprocess.run(['/bin/cp','-c','-p',str(canonical),str(temporary)],capture_output=True,check=True,timeout=25)
   assert temporary.stat().st_ino!=canonical.stat().st_ino and temporary.stat().st_size==row['bytes'] and sha(temporary)==row['sha256']
   os.chmod(temporary,old.st_mode&0o777);os.utime(temporary,ns=(old.st_atime_ns,old.st_mtime_ns))
   assert attributes(temporary)==xattrs
   assert path.stat().st_mtime_ns==old.st_mtime_ns and path.stat().st_ino==old.st_ino and sha(path)==row['sha256'] and sha(canonical)==row['sha256']
   os.replace(temporary,path);temporary=None
   new=path.stat();assert new.st_ino!=canonical.stat().st_ino and new.st_mtime_ns==old.st_mtime_ns and (new.st_mode&0o777)==(old.st_mode&0o777) and sha(path)==row['sha256']
   changed.append({'path':row['path'],'canonicalIndependentCloneSource':group[0]['path'],'bytes':row['bytes'],'originalAndFinalSha256':row['sha256'],'oldInode':old.st_ino,'newIndependentInode':new.st_ino,'canonicalInode':canonical.stat().st_ino,'mode':row['mode'],'mtimeNsRetained':old.st_mtime_ns,'allOriginalXattrNamesAndValuesRetained':True})
 for group in inventory['groups']:
  for row in group:
   p=root/row['path'];assert p.is_file() and p.stat().st_size==row['bytes'] and p.stat().st_mtime_ns==row['mtimeNs'] and oct(p.stat().st_mode&0o777)==row['mode'] and sha(p)==row['sha256']
 assert all(sha(root/p)==digest for p,digest in protected.items())
 report.update(status='PASS_ALL_DUPLICATE_PDF_SOURCE_PATHS_BYTES_HASHES_MODES_MTIMES_XATTRS_RETAINED_INDEPENDENT_APFS_COW_CLONES',originalSourceFilesDeleted=0,pathsSharingPayloadWithIndependentCOW=len(changed),logicalBytesNowCloned=sum(r['bytes'] for r in changed),allInventorySourcePathsStillReadableAndByteExact=True,all3344ActiveCheckSourceInputsStable=True,physicalReclamationNotInferredFromLogicalSize=True)
except BaseException as error:
 report.update(status='PARTIAL_OR_FAILED_APFS_SHARING_ALL_ALREADY_VERIFIED_PATHS_RETAINED',errorType=type(error).__name__,error=str(error));raise
finally:
 if temporary is not None and temporary.exists():temporary.unlink()
 report.update(finishedAtUtc=now(),changedPaths=changed,skippedPaths=skipped,dfAfter=subprocess.check_output(['df','-k',str(root)],text=True))
 out=w/'identical-official-pdf-apfs-sharing-result-v2.json.gz';assert not out.exists();out.write_bytes(gzip.compress(json.dumps(report,ensure_ascii=False,indent=2).encode(),mtime=0))
 print(json.dumps({k:v for k,v in report.items() if k not in {'changedPaths','skippedPaths','dfBefore','dfAfter'}},ensure_ascii=False),flush=True)
