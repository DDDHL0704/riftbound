# -*- coding: utf-8 -*-
from pathlib import Path
import collections,datetime,gzip,hashlib,json,subprocess,xml.etree.ElementTree as ET
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pin=lambda p:{'path':str(p.relative_to(root)),'sha256':sha(p)}
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def read(path):
 doc=ET.parse(path);defs={d.get('id'):d.find('t:TestMethod',ns).attrib for d in doc.findall('.//t:UnitTest',ns)};rows=doc.findall('.//t:UnitTestResult',ns)
 return rows,collections.Counter(d.get('testName') for d in rows),{defs[d.get('testId')]['className']+'.'+defs[d.get('testId')]['name'] for d in rows}
start=load(w/'only-check-start-inputs-v1.json');end=load(w/'only-check-owner-terminal-v1.json')
assert end['exitCode']==0 and all(end[k] for k in ['all3344SourceHashesAndModesStable','all1419ConformanceRuntimeInputsStable','all23NativeDebugRuntimeInputsStable'])
old=root/start['originalBaselineTrx'];assert sha(old)==start['originalBaselineTrxSha256'];trx=w/'only-check-v1/check/results.trx'
rows,cases,methods=read(trx);oldrows,oldcases,oldmethods=read(old)
assert (len(rows),len(methods),len(oldrows),len(oldmethods))==(13449,7550,13436,7543)
assert collections.Counter(r.get('outcome') for r in rows)=={'Passed':13449} and all(r.get('outcome')=='Passed' for r in oldrows)
assert not(oldcases-cases) and oldmethods<=methods;new=cases-oldcases;newmethods=methods-oldmethods
assert sum(new.values())==13 and len(newmethods)==7 and all('.RoomSnapshotRequestTests.' in n for n in new)
focus=w/'all-native-hub-identity-and-initial-snapshot-focus-v3';fr,fc,fm=read(focus/'focus/results.trx')
assert len(fr)==647 and len(fm)==372 and all(r.get('outcome')=='Passed' for r in fr) and not(fc-cases)
assert collections.Counter(n for n in fc.elements() if '.RoomSnapshotRequestTests.' in n)==new
rr,rc,rm=read(w/'original-flow-red-v1/focus/results.trx');assert len(rr)==13 and len(rm)==7 and rc==new and collections.Counter(r.get('outcome') for r in rr)=={'Passed':5,'Failed':8}
original=json.loads(gzip.decompress((w/'original-all1803-conformance-files-before-main-race-v1.json.gz').read_bytes()));files=original['allOriginalTrackedConformanceFiles'];assert len(files)==1803 and original['originalTrackedCSharpCount']==509
project='tests/Riftbound.ConformanceTests/Riftbound.ConformanceTests.csproj';assert all(sha(root/p)==r['sha256'] and oct((root/p).stat().st_mode&0o777)==r['mode'] for p,r in files.items() if p!=project)
oldproject=subprocess.check_output(['git','show',start['baseCommit']+':'+project],cwd=root).decode();line='    <Compile Include="../../clients/godot/scripts/ClientCommandSerializer.cs" Link="Native/ClientCommandSerializer.cs" />\n';added='    <Compile Include="../../clients/godot/scripts/RoomSnapshotRequest.cs" Link="Native/RoomSnapshotRequest.cs" />\n';assert oldproject.count(line)==1 and (root/project).read_text()==oldproject.replace(line,line+added,1)
fulls={p:r for p,r in files.items() if Path(p).name.startswith('FullGameEndToEndTests') and p.endswith('.cs')};assert len(fulls)==9 and all(sha(root/p)==r['sha256'] for p,r in fulls.items())
assert len(start['sourceInputHashes'])==3344 and all(sha(root/p)==h and oct((root/p).stat().st_mode&0o777)==start['sourceInputModes'][p] for p,h in start['sourceInputHashes'].items())
sql='tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json';assert (root/sql).read_bytes()==subprocess.check_output(['git','show',start['baseCommit']+':'+sql],cwd=root) and len(load(root/sql)['cases'])==59
wire='tests/Riftbound.NativeNetworkSmoke/Program.cs';assert (root/wire).read_bytes()==subprocess.check_output(['git','show',start['baseCommit']+':'+wire],cwd=root)
report={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'SOLE_CLIENT_INITIAL_SNAPSHOT_CHECK13449_CASES7550_METHODS_ALL_PASS_OLD13436_7543_EXACT_PLUS13_7','baseCommit':start['baseCommit'],'actualCases':13449,'actualMethods':7550,'outcomes':{'Passed':13449},'originalCases':13436,'originalMethods':7543,'oldExactCaseMultisetAndMethodsRetained':True,'newCases':13,'newMethods':7,'newCaseNames':sorted(new.elements()),'newMethodNames':sorted(newmethods),'legacyExtractedFlowOriginalOutcomes':{'Passed':5,'Failed':8},'legacyOriginalCaseMultisetExactCurrent':True,'finalAdjacentCases':647,'finalAdjacentSelectedMethods':372,'focusWholeSuiteDiscoveredMethods':7691,'all1803OriginalConformanceFilesExceptOneExactCompileLinkAdditionUnchanged':True,'all509OriginalCSharpAndAllOldMethodsTheoryRowsAssertionsByteExact':True,'allNineFullSources143Methods151Cases110Pairs11Decks424242AndVictoryReplayAssertionsRetained':True,'currentCheckDoesNotClaimAll143FullGamesExecuted':True,'original59SqlObjectsOrderClassesAndOriginalNetwork15GuardsSourceByteExact':True,'onlyCheckTrx':pin(trx),'originalBaselineTrx':pin(old),'all3344SourceModes1419Conformance23NativeDebugStable':True,'onlyOneCheckForThisCoherentBatch':True,'noDatabaseConnectionInLocalCheck':True,'actualFourLoadedDebugAssembliesAndRuleInputs':start['actualLoadedDebugBaseFourAssembliesAndRuleInputs'],'separate20WebObservationsNotLocallyCertified':True,'newFixedFullActualCiExportNativeColdRaceRepairVisibleAndWindows':'OPEN','currentTransportBugDoesNotCreateCardOrClauseSemanticCertification':True,'wholePrintingOrGoalCertified':False}
out=w/'final-only-check-original-retention-v1.json';assert not out.exists();out.write_text(json.dumps(report,indent=2));print('PASS sole13449/7550; original13436/7543+13/7;647/372; legacy5pass8fail retained;1803 original files onlycompilelink;509CSharp9full sources143/110/11/424242 intact;59SQL/network guards exact;3344/1419/23 stable;newfixedfull/productsOPEN',flush=True)
