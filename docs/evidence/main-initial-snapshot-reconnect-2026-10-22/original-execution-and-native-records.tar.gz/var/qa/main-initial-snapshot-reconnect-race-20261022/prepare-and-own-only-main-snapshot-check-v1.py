# -*- coding: utf-8 -*-
from pathlib import Path
import ast,datetime,gzip,hashlib,json,os,plistlib,resource,subprocess,xml.etree.ElementTree as ET,collections
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
parent='267ab4f0690436d57cd45277e44c8bb5ee5ef6f0';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==parent
baseline=load(root/'var/qa/battlefield-start-you-lab-20261022/only-check-start-inputs-v1.json')
changed={'clients/godot/scripts/Main.cs','clients/godot/scripts/RiftboundGameHubClient.cs','tests/Riftbound.ConformanceTests/Riftbound.ConformanceTests.csproj'}
added={'clients/godot/scripts/RoomSnapshotRequest.cs','tests/Riftbound.ConformanceTests/RoomSnapshotRequestTests.cs'}
assert {p for p,h in baseline['sourceInputHashes'].items() if sha(root/p)!=h}==changed
paths=set(baseline['sourceInputHashes'])|added;assert len(paths)==3344
inputs={p:sha(root/p) for p in sorted(paths)};modes={p:oct((root/p).stat().st_mode&0o777) for p in sorted(paths)}
original=json.loads(gzip.decompress((w/'original-all1803-conformance-files-before-main-race-v1.json.gz').read_bytes()));files=original['allOriginalTrackedConformanceFiles'];assert len(files)==1803 and original['originalTrackedCSharpCount']==509
project='tests/Riftbound.ConformanceTests/Riftbound.ConformanceTests.csproj'
assert all(sha(root/p)==record['sha256'] and oct((root/p).stat().st_mode&0o777)==record['mode'] for p,record in files.items() if p!=project)
old_project=subprocess.check_output(['git','show',parent+':'+project],cwd=root).decode();line='    <Compile Include="../../clients/godot/scripts/ClientCommandSerializer.cs" Link="Native/ClientCommandSerializer.cs" />\n';link='    <Compile Include="../../clients/godot/scripts/RoomSnapshotRequest.cs" Link="Native/RoomSnapshotRequest.cs" />\n'
assert old_project.count(line)==1 and (root/project).read_text()==old_project.replace(line,line+link,1)
full_sources={p:r for p,r in files.items() if Path(p).name.startswith('FullGameEndToEndTests') and p.endswith('.cs')};assert len(full_sources)==9 and all(sha(root/p)==r['sha256'] for p,r in full_sources.items())
focus=w/'all-native-hub-identity-and-initial-snapshot-focus-v3';summary=load(focus/'summary.json');plan=load(focus/'plan.json');assert summary['status']=='PASSED' and summary['total']==647 and plan['discoveredMethods']==7691 and sum(len(s['methods']) for s in plan['shards'])==372
red=load(w/'original-legacy-flow-red-execution-v1.json');assert red['outcomes']=={'Passed':5,'Failed':8} and red['actualCases']==13 and red['actualMethods']==7
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
rows=ET.parse(focus/'focus/results.trx').findall('.//t:UnitTestResult',ns);new=collections.Counter(r.get('testName') for r in rows if '.RoomSnapshotRequestTests.' in r.get('testName'));assert sum(new.values())==13 and all(r.get('outcome')=='Passed' for r in rows)
assert '0 个警告' in (w/'native-debug-build-v1.log').read_text() and '0 个错误' in (w/'native-debug-build-v1.log').read_text()
runtime_hashes={k:{str(p.relative_to(root)):sha(p) for p in (root/folder).rglob('*') if p.is_file() and not str(p.relative_to(root)).startswith(baseline['excludedGeneratedOutputDirectory']+'/')} for k,folder in [('Conformance','tests/Riftbound.ConformanceTests/bin/Debug/net10.0'),('Native','clients/godot/.godot/mono/temp/bin/Debug')]}
assert len(runtime_hashes['Conformance'])==1419 and len(runtime_hashes['Native'])==23 and set(runtime_hashes['Conformance'])==set(baseline['actualConformanceRuntimeFileHashes']) and set(runtime_hashes['Native'])==set(baseline['actualNativeRuntimeFileHashes'])
runtime=root/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0';probe=root/'var/qa/fixed267ab-early-native-20261022/executed-own-native-readers-and-drivers-v1/IndependentFixed267abControlledLabV1.dll';assert probe.is_file()
actual=json.loads(subprocess.check_output(['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(runtime/'Riftbound.ConformanceTests.deps.json'),'--runtimeconfig',str(runtime/'Riftbound.ConformanceTests.runtimeconfig.json'),str(probe),'--loaded-inputs'],cwd=runtime,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0')))
assert Path(actual['baseDirectory'])==runtime and len(actual['assemblies'])==4
for a in actual['assemblies']:assert Path(a['path'])==runtime/(a['name']+'.dll') and a['sha256']==runtime_hashes['Conformance'][str((runtime/(a['name']+'.dll')).relative_to(root))] and a['mvid']
definition=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py';nodes=[n for n in ast.parse(definition.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='observe_lock'];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(definition),'exec'),globals())
environment=dict(os.environ);removed=[]
for key in ['ConnectionStrings__Riftbound']:
 if key in environment:removed.append(key);del environment[key]
old_trx=root/'var/qa/battlefield-start-you-lab-20261022/only-check-v1/check/results.trx'
web=subprocess.check_output(['git','ls-files','--','clients/web'],cwd=root,text=True).splitlines();assert len(web)==20
start={'atUtc':now(),'baseCommit':parent,'includesDeclaredUncommittedClientOnlyChanges':True,'sourceInputCount':3344,'sourceInputHashes':inputs,'sourceInputModes':modes,'exactChangedOriginalSourcePaths':sorted(changed),'exactAddedSourcePaths':sorted(added),'sourceScopeDefinition':'Same3342 compiled .NET/native/data/scripts inputs as prior batch plus2 new files.20 independently committed web files are observations, not executed .NET check inputs.','separate20WebInputsObservedNotCertifiedByThisCheck':{p:sha(root/p) for p in web},'excludedGeneratedOutputDirectory':baseline['excludedGeneratedOutputDirectory'],'actualConformanceRuntimeFileHashes':runtime_hashes['Conformance'],'actualNativeRuntimeFileHashes':runtime_hashes['Native'],'actualLoadedDebugBaseFourAssembliesAndRuleInputs':actual,'originalBaselineTrx':str(old_trx.relative_to(root)),'originalBaselineTrxSha256':sha(old_trx),'expectedCases':13449,'expectedMethods':7550,'new13Cases7Methods':sorted(new.elements()),'finalFocusActual647Cases372SelectedMethods':True,'focusDiscoveredWholeSuiteMethods':7691,'nativeDebugBuildZeroWarningsErrors':True,'all1803OriginalConformanceFilesExceptOneCompileLinkAdditionExact':True,'all509OriginalCSharpAndNineFullSources143Methods110Pairs11Decks424242AndAllOriginalTheoryAssertionsByteExact':True,'noSecondCheckForThisCoherentClientBatch':True,'checkDoesNotHaveDatabaseConnection':True,'removedEnvironmentNamesOnly':removed,'separateActualSql59AndNativeNetworkAndProductEvidenceRequired':True,'native267ColdClientRaceStillFailedDespiteOrdinaryAndPaidLabPass':True,'wholePrintingOrGoalCertified':False,'lockAtStart':observe_lock()}
with (w/'only-check-start-inputs-v1.json').open('x') as f:json.dump(start,f,indent=2)
out=w/'only-check-v1';terminal=w/'only-check-owner-terminal-v1.json';assert not out.exists() and not terminal.exists()
command=['python3','scripts/test-rules.py','check','--output',str(out)];proof={'startedAtUtc':now(),'command':command,'baseCommit':parent,'lockAtStart':start['lockAtStart'],'currentDebugRuleInputs':actual['actualRuleInputs']}
print('SOLE_MAIN_SNAPSHOT_CHECK_STARTED_3344_SOURCES_1419_CONFORMANCE_23_NATIVE_EXPECT13449_CASES7550_METHODS',flush=True)
try:
 with (w/'only-check-console-v1.log').open('xb') as log:
  child=subprocess.Popen(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,env=environment);power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(child.pid)]);proof['exitCode']=child.wait();power.wait(timeout=10)
finally:
 proof.update(finishedAtUtc=now(),lockAtStop=observe_lock(),all3344SourceHashesAndModesStable=all(sha(root/p)==h and oct((root/p).stat().st_mode&0o777)==modes[p] for p,h in inputs.items()),all1419ConformanceRuntimeInputsStable=all(sha(root/p)==h for p,h in runtime_hashes['Conformance'].items()),all23NativeDebugRuntimeInputsStable=all(sha(root/p)==h for p,h in runtime_hashes['Native'].items()))
 with terminal.open('x') as f:json.dump(proof,f,indent=2)
print(json.dumps(proof),flush=True)
assert proof['exitCode']==0 and all(proof[k] for k in ['all3344SourceHashesAndModesStable','all1419ConformanceRuntimeInputsStable','all23NativeDebugRuntimeInputsStable'])
