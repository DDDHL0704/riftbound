from pathlib import Path
import datetime,hashlib,json,tarfile
w=Path(__file__).resolve().parent;root=w.parents[2];out=root/'docs/evidence/canonical-room-identity-2026-10-21';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text())
old=load(w/'original-governance-before-publication-v1/docs/audit/current-manifest.json');current=load(root/'docs/audit/current-manifest.json');source=load(out/'source-manifest.json');archive_map=load(out/'archive-map.json');inputs=load(out/'actual-candidate-source-and-runtime-inputs.json');check=load(out/'check-original-retention.json')
assert current['certificationScope']==old['certificationScope'] and current['inputs']==old['inputs'] and current['cardCoverageManifest']==old['cardCoverageManifest'] and current['laterSourceDeltas']==old['laterSourceDeltas'] and len(current['laterSourceDeltas'])==7
assert current['semanticCoverageCertified'] is False and set(current['reviewContexts'])==set(old['reviewContexts']) and len(current['reviewContexts'])==65
changed=[]
for name,before in old['reviewContexts'].items():
    after=current['reviewContexts'][name]
    if after==before:continue
    expected=json.loads(json.dumps(before))
    for p in expected['implementation']:
        if p['path']=='clients/godot/scripts/Main.cs':p['sha256']=sha(root/p['path'])
    expected['currentImplementationCommit']=inputs['baseCommit'];expected['currentPlatformInputEvidence']=current['currentCanonicalRoomAccountIdentityInputChange'];assert after==expected
    assert after['ciState']==before['ciState']=='PENDING' and after['evidence']==before['evidence'] and after['branches']==before['branches'];changed.append(name)
assert len(changed)==4 and len(current['acceptanceGates'])==245
old_gates={g['id']:g for g in old['acceptanceGates']};new_gates={g['id']:g for g in current['acceptanceGates']};assert len(old_gates)==len(new_gates)==245 and set(old_gates)==set(new_gates)
for name,g in old_gates.items():
    if name!='ROOM_IDENTITY_BOUNDARY':assert new_gates[name]==g
    else:
        assert load(out/'previous-room-identity-gate.json')==g
        after=new_gates[name]
        for k,v in g.items():
            if k!='implementation':assert after[k]==v
        assert after['state']=='OPEN' and after['implementation']==[{'path':'src/Riftbound.Api/Hubs/GameHub.cs','sha256':sha(root/'src/Riftbound.Api/Hubs/GameHub.cs')}]
reviews=load(root/'docs/evidence/rules-reaudit-2026-10-11/review-decisions.json');assert len(reviews['reviews'])==150 and (root/'docs/evidence/rules-reaudit-2026-10-11/review-decisions.json').read_bytes()==(w/'original-governance-before-publication-v1/docs/evidence/rules-reaudit-2026-10-11/review-decisions.json').read_bytes()
archive=root/archive_map['archive']['path'];assert sha(archive)==archive_map['archive']['sha256'];records=archive_map['records'];assert len({r['member'] for r in records})==len(records)==191
with tarfile.open(archive,'r:xz') as tar:
    assert {i.name for i in tar.getmembers() if i.isfile()}=={r['member'] for r in records}
    for row in records:
        raw=tar.extractfile(row['member']).read();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'] and sha(root/row['originalPath'])==row['sha256']
for row in archive_map['explicitPrivateExclusions']:assert row['retainedLocally'] and sha(root/row['originalPath'])==row['sha256']
assert len(inputs['sourceInputHashes'])==3318 and all(sha(root/p)==h for p,h in inputs['sourceInputHashes'].items()) and all(oct((root/p).stat().st_mode&0o777)==m for p,m in inputs['sourceInputModes'].items())
assert check['actualCases']==13219 and check['actualMethods']==7501 and check['addedCases']==5 and len(check['addedMethods'])==2 and check['onlyOneCheckExecutedForThisCoherentBatch']
gov_path=w/'actual-post-publication-governance-full-v1.json';gov=load(gov_path);previous=load(root/'var/qa/n28-current-governance-20261021-v1.json');assert gov['governanceValid'] and not gov['errors'] and not gov['semanticCoverageCertified'] and gov['counts']==previous['counts'] and gov['counts']['combinedExactPrintingNumbers']==1740 and gov['counts']['sourceBlocks']==14293 and gov['counts']['enSourceCountGap']==8
old_rows={r['id']:r for r in previous['remainingObligations']};new_rows={r['id']:r for r in gov['remainingObligations']};assert len(old_rows)==len(new_rows)==16944 and set(old_rows)==set(new_rows)
for name,row in old_rows.items():
    if name=='GATE:ROOM_IDENTITY_BOUNDARY':continue
    assert new_rows[name]==row,name
assert source['actualRuleInputs']==inputs['actualRuleInputs'] and source['sourceToolAcceptance']['commands']==80 and source['sourceToolAcceptance']['events']==547 and not source['sourceToolAcceptance']['hardwareButtonsOrVisibleAcceptance'] and source['fixedCommitCi']=='PENDING_NEW_COHERENT_COMMIT_FULL' and source['wholePrintingOrGlobalSemanticCertification'] is False
for ref in [current['currentCanonicalRoomAccountIdentityInputChange'],current['precedingFixedA56137ActualCompleteFullCiReadback']]:assert sha(root/ref['path'])==ref['sha256']
summary={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_ACTUAL_CURRENT_GOVERNANCE_ONLY_NOT_SEMANTIC_OR_PRODUCT_COMPLETION','governanceValid':True,'errors':gov['errors'],'warnings':gov['warnings'],'counts':gov['counts'],'reviews':150,'contexts':65,'gates':245,'sourceDeltas':7,'remainingObligationCount':16944,'allOriginalRemainingIdsExact':True,'fullOriginalReportPath':str(gov_path.relative_to(root)),'fullOriginalReportSha256':sha(gov_path),'fullOriginalReportBytes':gov_path.stat().st_size,'semanticCoverageCertified':False}
(out/'actual-governance-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
result={'atUtc':summary['atUtc'],'status':'PASS_INDEPENDENT_CANONICAL_ACCOUNT_SOURCE_ALL_DECLARED_ORIGINALS_AND_SCOPE_RETENTION','sourceManifestSha256':sha(out/'source-manifest.json'),'rootCurrentManifestSha256':sha(root/'docs/audit/current-manifest.json'),'all191DeclaredOriginalFilesByteExactInLosslessArchiveAndLocalSource':True,'explicitPrivacyExclusionsStillLocalAndHashExact':len(archive_map['explicitPrivateExclusions']),'all150OriginalReviewObjectsAnd65ContextScopesEvidenceBranchesRetained':True,'onlyFourMainImplementationBindingsRefreshed':changed,'all245GateIdsRetainedOther244GateObjectsExact':True,'previousIdentityGateWholeObjectRetainedAndCurrentInputExplicitlyUpdated':True,'all16944OriginalObligationIdsAndAllOther16943ObjectsExact':True,'allOriginalSourceDatesScopeCardCoverageSevenDeltasAndCountsExact':True,'all3318SourceHashesAndModesMatchTheOnlyCheck':True,'onlyCheck':{'cases':13219,'methods':7501,'addedCases':5,'addedMethods':2},'newFixedFullCurrentVisibleWindowsAndWholePrintingAcceptance':'OPEN','goalComplete':False}
(out/'publication-independent-readback.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));(w/'independent-canonical-account-publication-result-v1.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(result['status'],flush=True)
