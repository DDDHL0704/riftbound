import ast, datetime, fcntl, gzip, hashlib, json, os, plistlib, re, resource, socket, subprocess, time, urllib.request
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CORE, (0, 0)); os.umask(0o077)
root = Path('/Users/dinghaolin/MyProjects/riftbound'); w = Path(__file__).resolve().parent
pg = Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin'); cluster = root/'var/qa/permanent-play-here-base-20261017/postgres'; sock = Path('/tmp/rft-here-family-20261018-55486')
tables = ['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts']; read_env = dict(os.environ, PGOPTIONS='-c default_transaction_read_only=on')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest(); now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat(); load = lambda p: json.loads(p.read_text())
source = root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes = [n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}]; exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),globals())
pub = load(w/'frozen-current-canonical-candidate-inputs-v3.json'); helper_pub = {'runtimeFiles':pub['helperRuntimeFiles']}; helpers = w/'live-acceptance-helper-runtime-v1'; api_runtime = w/'api-runtime-v1'
evidence = w/'same-canonical-original-room-continuation-v1'; evidence.mkdir(exist_ok=False)
source = w/'run-current-source-tool-main-pair-v1.py'
text = source.read_text().replace('live-current-tool-owner-state-v1','same-canonical-continuation-owner-state-v1').replace('live-current-tool-api-','same-canonical-continuation-api-')
nodes = [n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name in {'checkpoint','frozen','state','start_api','export','count'}]; exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),globals())
failed = load(w/'live-current-tool-main-owner-terminal-v1.json'); entry = load(w/'actual-safe-native-prefix-v1/pending-original-native-prefix-receipt.json')
baseline = load(w/'actual-safe-native-main-v1/original231-audit48-native-seven-table-baseline-v1.json')
room = entry['room']; a,b = entry['players']; n = entry['acceptedCommands']; assert room == failed['room'] and n == 60
original = load(w/'current-tool-original-field-assumption-failure-disposition-v1.json'); assert original['actualNativeAcceptedCommands'] == 3
prior_frame_path = w/'actual-safe-native-main-v1/owner-final-current-tool-native-original-frame-v1.json.gz'
prior_frame = json.loads(gzip.decompress(prior_frame_path.read_bytes())); assert len(prior_frame['commands']) == n+3
ready = w/'same-canonical-room-score-ready-v1.json'; stop = w/'same-canonical-room-stop-v1.json'; terminal = w/'same-canonical-room-owner-terminal-v1.json'; assert not any(p.exists() for p in [ready,stop,terminal])
guard = (root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a'); fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof = {'status':'RUNNING_SAME_ORIGINAL_CANONICAL_ROOM_NOT_FIXED_CI_OR_VISIBLE_ACCEPTANCE','startedAtUtc':now(),'baseCommit':pub['baseCommit'],'actualRuleInputs':pub['actualRuleInputs'],'room':room,'originalPrefix':n,'nativeAcceptedGameplayCommands':3,'nativeSourceToolNotHardwareOrVisible':True,'ownedApiProcesses':[],'lockAtStart':observe_lock()}
api=power=driver=None; started=False
try:
    frozen(); assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode == 3
    with socket.socket() as s: assert s.connect_ex(('127.0.0.1',15847)) != 0
    power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]); proof['boundIdleAssertionPid']=power.pid
    sock.mkdir(exist_ok=True); subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'same-canonical-continuation-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True); started=True
    assert rooms('riftbound_acceptance') == baseline['auditRooms'] and len(baseline['auditRooms']) == 231
    assert set(rooms('riftbound_here_native')) == set(baseline['nativeRooms']) | {room} and len(baseline['nativeRooms']) == 48
    assert digests('riftbound_acceptance',baseline['auditRooms']) == baseline['auditSevenTables'] and digests('riftbound_here_native',baseline['nativeRooms']) == baseline['nativeSevenTables']
    start_api(1); before=export('before-same-original-canonical-score-continuation-v1')
    assert before == prior_frame and before['authoritativeState']['pendingPayment'] is None and not before['authoritativeState']['stackItems'] and count() == n+3
    checkpoint('same-original63-command-frame-before-any-new-writer-v1.json',{'atUtc':now(),'originalFinalFrameSha256':sha(prior_frame_path),'allFieldsNullsCommandsEventsViewsSeedAndInitialExact':True,'nativeAcceptedGameplayCommands':3,'room':room})
    state('SAME_ORIGINAL_CANONICAL_ROOM_NORMAL_SCORE_CONTINUATION')
    score=w/'actual-safe-normal-score-continuation-v1'; assert not score.exists()
    with (w/'same-canonical-normal-score-writer-v1.log').open('xb') as stream:
        driver=subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet',str(helpers/'Fixed564SafeBandleScore.dll'),'http://127.0.0.1:15847',str(score),str(w)],cwd=helpers,stdout=stream,stderr=subprocess.STDOUT,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0')); assert driver.wait(timeout=330) == 0
    result=load(score/'normal-original-score-continuation-receipt.json'); assert result['continuationCommands'] == 17 and result['winningScore'] == 8
    final=export('after-same-original-canonical-normal-score-final-frame-v1'); current=final['authoritativeState']
    assert len(final['commands']) == n+20 and current['status']=='FINISHED' and current['winnerPlayerId']==a and current['playerScores']=={a:8,b:0}
    assert final['commands'][:n+3]==before['commands'] and final['events'][:len(before['events'])]==before['events'] and final['openingSeed']==before['openingSeed'] and final['replayInitialState']==before['replayInitialState']
    assert all(c['commandType']!='SURRENDER' and c['playerId']==c['playerId'].strip().lower() for c in final['commands'])
    state('SAME_ROOM_NORMAL_WIN_COMPLETE_CHECKING_ORIGINAL_NATIVE_NETWORK_RECOVERY')
    network_before=rooms('riftbound_here_native'); network_log=w/'actual-current-network-smoke-v1.log'
    with network_log.open('xb') as stream:
        driver=subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet',str(w/'native-network-runtime-v1/Riftbound.NativeNetworkSmoke.dll')],cwd=w/'native-network-runtime-v1',env=dict(os.environ,RIFTBOUND_SERVER_URL='http://127.0.0.1:15847',DOTNET_DbgEnableMiniDump='0'),stdout=stream,stderr=subprocess.STDOUT); assert driver.wait(timeout=90)==0
    raw=network_log.read_text(); assert 'Native canonical room identity passed:' in raw and 'Native network recovery passed: socket loss, authenticated room restore, fresh snapshot, rejected-token guard.' in raw
    wire=json.loads(next(line[len('NATIVE_ROOM_IDENTITY_EVIDENCE '):] for line in raw.splitlines() if line.startswith('NATIVE_ROOM_IDENTITY_EVIDENCE '))); assert wire['rejectedActions']==15 and wire['leakedPrivateMessages']==0 and wire['validReconnectTokenWasSupplied']
    added=set(rooms('riftbound_here_native'))-set(network_before); assert len(added)==1 and next(iter(added)).startswith('NETWORK-')
    proof.update(status='SAME_CANONICAL_ROOM_NORMAL_SCORE_AND_NATIVE_NETWORK_READY_FOR_INDEPENDENT_HISTORY_REPLAY',commands=len(final['commands']),events=len(final['events']),winningScore=8,losingScore=0,finalTurn=current['turnNumber'],normalGatewayContinuationCommands=17,currentNativeWireCanonicalAndOriginalRecoveryPass=True,networkOriginalEvidence=wire,separateNewNetworkRoom=next(iter(added)),original63AcceptedCommandsAndEveryEventRetained=True)
    ready.write_text(json.dumps({**proof,'apiPid':api.pid,'rawFinalFrame':str(evidence/'after-same-original-canonical-normal-score-final-frame-v1.json.gz')},indent=2)); state('WAITING_READ_ONLY_SAME_ORIGINAL_ROOM_ALL_HISTORY_AND_FULL_REPLAY')
    until=time.monotonic()+900
    while not stop.exists(): assert api.poll() is None and time.monotonic()<until; time.sleep(.2)
    completion=load(stop); assert completion['room']==room and completion['independentReadOnlyHistoryAndFullReplayPass']
    proof.update(status='PASS_SAME_ORIGINAL_CANONICAL_ROOM_SOURCE_TOOL3_NORMAL_SCORE17_NETWORK15_REJECTIONS_AND_INDEPENDENT_ALL_SQL_REPLAY_NOT_FIXED_CI_OR_VISIBLE',independentReadback=completion)
except BaseException as e:
    proof.update(status='FAILED_OR_INTERRUPTED_SAME_ORIGINAL_ROOM_RETAINED_NO_RESET',errorType=type(e).__name__,error=str(e)); raise
finally:
    if driver is not None and driver.poll() is None: driver.terminate(); driver.wait(timeout=20)
    if api is not None:
        if api.poll() is None: api.terminate(); api.wait(timeout=25)
        proof['ownApiStopped']=api.poll() is not None
    if started:
        proof['allOriginal231AuditSevenTablesExactAtStop']=digests('riftbound_acceptance',baseline['auditRooms'])==baseline['auditSevenTables']; proof['allOriginal48NativeSevenTablesExactAtStop']=digests('riftbound_here_native',baseline['nativeRooms'])==baseline['nativeSevenTables']; proof['actualNativeRoomsAtStop']=rooms('riftbound_here_native')
        proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
    if power is not None:
        if power.poll() is None: power.terminate(); power.wait(timeout=10)
        proof['boundIdleAssertionEnded']=power.poll() is not None
    frozen(); proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),allFrozenApiNativeNetworkAndCurrent23ToolPayloadsExact=True,originalDatabasesAndSameRoomRetained=True); terminal.write_text(json.dumps(proof,indent=2)); fcntl.flock(guard,fcntl.LOCK_UN)
print(proof['status'],flush=True)
