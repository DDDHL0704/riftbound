from pathlib import Path
import collections, datetime, gzip, hashlib, json, re, subprocess, xml.etree.ElementTree as ET, zipfile
w=Path(__file__).resolve().parent;root=w.parents[2];fixed='a56137a93d48a38d6e2e62b5b7195aa03412577f';sha=lambda b:hashlib.sha256(b).hexdigest()
metadata=json.loads((w/'preceding-a56137-artifacts-original-v2.json').read_text());a=next(a for a in metadata['artifacts'] if a['name']=='conformance-results')
assert not a['expired'] and a['workflow_run']['head_sha']==fixed
p=w/'preceding-a56137-conformance-results-original-v1.zip'
with p.open('xb') as f:subprocess.run(['gh','api',f'repos/DDDHL0704/riftbound/actions/artifacts/{a["id"]}/zip'],stdout=f,check=True)
assert p.stat().st_size==a['size_in_bytes'] and 'sha256:'+sha(p.read_bytes())==a['digest']
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};cases=collections.Counter();methods=set();trx_hashes={};matrices=[]
with zipfile.ZipFile(p) as z:
    assert z.testzip() is None and z.read('ci-rule-suite-commit.txt').decode().strip()==fixed
    plan=json.loads(z.read('ci-rules/plan.json'));summary=json.loads(z.read('ci-rules/summary.json'))
    assert summary['status']=='PASSED' and summary['profile']=='full' and summary['total']==13325
    assert all(s['total']==s['passed'] and not s['failed'] and not s['notExecuted'] for s in summary['shards'])
    planned=[m for s in plan['shards'] for m in s['methods']];assert len(planned)==len(set(planned))==plan['discoveredMethods']==7635
    for name in z.namelist():
        if not name.endswith('/results.trx'):continue
        raw=z.read(name);trx_hashes[name]=sha(raw);t=ET.fromstring(raw)
        definitions={d.attrib['id']:d.find('t:TestMethod',ns).attrib for d in t.findall('.//t:UnitTest',ns)};actual=set()
        for r in t.findall('.//t:UnitTestResult',ns):
            assert r.attrib['outcome']=='Passed'
            d=definitions[r.attrib['testId']];method=d['className']+'.'+d['name'];methods.add(method);actual.add(method);cases[r.attrib['testName']]+=1
            for output in r.findall('.//t:StdOut',ns):
                for line in (output.text or '').splitlines():
                    if line.startswith('PRECONSTRUCTED_MATRIX '):matrices.append(json.loads(line[len('PRECONSTRUCTED_MATRIX '):]))
        assert actual==set(next(s['methods'] for s in plan['shards'] if s['name']==name.split('/')[-2]))
    assert methods==set(planned) and sum(cases.values())==13325
baseline=ET.parse(root/'var/qa/spell-remake-no-declaration-20261021/only-check-v1/check/results.trx')
baseline_cases=collections.Counter(r.attrib['testName'] for r in baseline.findall('.//t:UnitTestResult',ns))
assert sum(baseline_cases.values())==13176 and not baseline_cases-cases
source_files=sorted((root/'tests/Riftbound.ConformanceTests').glob('FullGameEndToEndTests*.cs'));expected=set();source_hashes={}
assert len(source_files)==9
for path in source_files:
    relative=str(path.relative_to(root));raw=subprocess.check_output(['git','show',fixed+':'+relative],cwd=root);assert raw==path.read_bytes();source_hashes[relative]=sha(raw)
    expected.update('Riftbound.ConformanceTests.FullGameEndToEndTests.'+m for m in re.findall(r'\bpublic\s+(?:async\s+)?(?:Task|void)\s+(\w+)\s*\(',raw.decode()))
assert len(expected)==143 and {m for m in methods if m.startswith('Riftbound.ConformanceTests.FullGameEndToEndTests.')}==expected
assert len(matrices)==1;matrix=matrices[0]
deck_path=root/'var/qa/graveyard-source-fixed-candidate-20261020/native-visible-v1/live-api-eleven-preconstructed-decks-original.json.gz'
decks=json.loads(gzip.decompress(deck_path.read_bytes()));deck_ids=[d['id'] for d in decks];assert len(deck_ids)==len(set(deck_ids))==11
expected_pairs={a+'-vs-'+b for a in deck_ids for b in deck_ids if a!=b}
assert matrix['seed']==424242 and matrix['deckCount']==11 and matrix['pairCount']==110 and set(matrix['completed'])==expected_pairs and len(matrix['completed'])==110
assert all(re.fullmatch('[0-9a-f]{64}',h) for h in matrix['completed'].values())
result={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_ONLY_A56137_COMPLETE_RULE_SUITE_ORIGINALS_13325_CASES_7635_METHODS_143_ORIGINAL_FULL_GAMES_110_PAIRS_NOT_ENTIRE_CI',
        'fixedCommit':fixed,'runId':39481821852,'artifactId':a['id'],'artifactBytes':p.stat().st_size,'artifactSha256':sha(p.read_bytes()),
        'backendSizeDigestAllCrcAndOriginalTrxOutcomesExact':True,'original13176CheckCaseNameCountMultisetRetained':True,'oldFailedCheckNotRewritten':True,
        'actualCases':sum(cases.values()),'actualMethods':len(methods),'originalFullGameSourceHashes':source_hashes,'originalMatrix':matrix,'independentOriginalElevenDecksSha256':sha(deck_path.read_bytes()),
        'originalTrxSha256':trx_hashes,'planSha256':sha(json.dumps(plan,sort_keys=True).encode()),'summary':summary,'stableAggregateAndRemainingSqlPartition0':'OPEN'}
(w/'preceding-a56137-rule-suite-independent-original-readback-v1.json').write_text(json.dumps(result,indent=2))
print(result['status'],flush=True)
