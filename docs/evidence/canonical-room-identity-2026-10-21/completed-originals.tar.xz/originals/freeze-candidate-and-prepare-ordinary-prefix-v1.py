from pathlib import Path
import datetime, hashlib, json, os, shutil, subprocess, xml.etree.ElementTree as ET

os.umask(0o077)
root = Path('/Users/dinghaolin/MyProjects/riftbound')
w = Path(__file__).resolve().parent
prior = root / 'var/qa/fixed-a56137-native-locked-20261021'
old = root / 'var/qa/fixed-reversal-native-locked-20261020'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
paths = list(load(root / 'var/qa/fixed-f470429-native-locked-20261021/fixed-clean-api-runtime-source-and-identity-v1.json')['sourceInputHashes'])
paths.append('tests/Riftbound.ConformanceTests/GameHubCanonicalRoomIdentityTests.cs')
assert len(paths) == len(set(paths)) == 3318
source_hashes = {p: sha(root / p) for p in paths}
source_modes = {p: oct((root / p).stat().st_mode & 0o777) for p in paths}
mutable = {(p.stat().st_dev, p.stat().st_ino) for p in [root / p for p in paths]}
for folder in ['src', 'tests', 'clients/godot/.godot/mono/temp/bin']:
    for p in (root / folder).rglob('*'):
        if p.is_file() and ('bin' in p.parts or 'obj' in p.parts):
            mutable.add((p.stat().st_dev, p.stat().st_ino))
known = {}
for folder in [root / 'var/qa/fixed-f470429-native-locked-20261021/api-runtime-v1', prior / 'live-acceptance-helper-runtime-v1']:
    for p in folder.rglob('*'):
        if p.is_file() and (p.stat().st_dev, p.stat().st_ino) not in mutable:
            known.setdefault((p.stat().st_size, sha(p)), p)
shared = []
def retain(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    h = sha(source)
    identical = known.get((source.stat().st_size, h))
    if target.exists():
        assert sha(target) == h
        if identical and (target.stat().st_dev, target.stat().st_ino) != (identical.stat().st_dev, identical.stat().st_ino):
            tmp = target.with_name(target.name + '.immutable-link')
            os.link(identical, tmp)
            os.replace(tmp, target)
            shared.append(str(target.relative_to(w)))
    elif identical:
        os.link(identical, target)
        shared.append(str(target.relative_to(w)))
    else:
        shutil.copy2(source, target)
    assert (target.stat().st_dev, target.stat().st_ino) not in mutable
    known.setdefault((target.stat().st_size, h), target)

api = w / 'api-runtime-v1'
for p in list(api.rglob('*')):
    if p.is_file(): retain(p, p)
reader = api / 'ClairvoyanceIndependentFrameReaderV2.dll'
retain(prior / 'api-runtime-v1' / reader.name, reader)
command = ['/Users/dinghaolin/.dotnet/dotnet', 'exec', '--depsfile', str(api / 'Riftbound.Api.deps.json'), '--runtimeconfig', str(api / 'Riftbound.Api.runtimeconfig.json'), str(reader), 'identity-print']
identity = json.loads(subprocess.check_output(command, cwd=api))
native = w / 'native-tool-runtime-v1'
native_sources = root / 'clients/godot/.godot/mono/temp/bin/Debug'
for p in native_sources.rglob('*'):
    if p.is_file(): retain(p, native / p.relative_to(native_sources))
network = w / 'native-network-runtime-v1'
network_sources = root / 'tests/Riftbound.NativeNetworkSmoke/bin/Release/net8.0'
for p in network_sources.rglob('*'):
    if p.is_file(): retain(p, network / p.relative_to(network_sources))
helpers = w / 'live-acceptance-helper-runtime-v1'
for p in api.rglob('*'):
    if p.is_file(): retain(p, helpers / p.relative_to(api))
for p in (prior / 'live-acceptance-helper-runtime-v1').rglob('*'):
    if p.is_file() and not (helpers / p.relative_to(prior / 'live-acceptance-helper-runtime-v1')).exists():
        retain(p, helpers / p.relative_to(prior / 'live-acceptance-helper-runtime-v1'))
transport = root / 'clients/godot/scripts/RiftboundGameHubClient.cs'
assert sha(transport) == sha(old / 'native-reversal-prefix-safe-v1-source/ActualProductionNativeGateway.cs')
src = w / 'canonical-native-prefix-source-v1'
src.mkdir(exist_ok=False)
for name in ['Program.cs', 'ActualProductionNativeGateway.cs', 'probe.csproj', 'Fixtures/reversal-target-openings.json']:
    target = src / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((old / 'native-reversal-prefix-safe-v1-source' / name).read_bytes())
p = src / 'Program.cs'
s = p.read_text().replace('public string Handle { get; }', 'public string Handle { get; private set; }')
needle = '                    ReconnectToken = payload.GetProperty("reconnectToken").GetString();'
assert s.count(needle) == 1
s = s.replace(needle, '                    var canonical = payload.GetProperty("playerId").GetString()!;\n'
    '                    Check(canonical == Handle.Trim().ToLowerInvariant() && message.PlayerId == canonical, "Joined must bind the authenticated canonical actor.");\n'
    '                    Handle = canonical;\n' + needle)
p.write_text(s)
p = src / 'probe.csproj'
tree = ET.parse(p)
for hint in tree.findall('.//HintPath'):
    name = Path(hint.text).name
    target = helpers / name
    assert target.exists(), name
    hint.text = str(target)
tree.write(p, encoding='unicode')
for label in ['a', 'b']:
    profile = {'handle': 'Q31Canonical-' + label.upper() + '-' + os.urandom(4).hex(),
               'playerKey': 'qa-' + os.urandom(24).hex(), 'roomId': '', 'lastDeckId': 'lillia-lowcurve',
               'serverUrl': 'http://127.0.0.1:15847', 'reconnectToken': None}
    (w / ('session-' + label + '.json')).write_text(json.dumps(profile, indent=2))
with (w / 'canonical-prefix-build-v1.log').open('xb') as f:
    r = subprocess.run(['/Users/dinghaolin/.dotnet/dotnet', 'build', str(src / 'probe.csproj'), '-c', 'Release', '-v:q'], stdout=f, stderr=subprocess.STDOUT)
assert r.returncode == 0
for p in (src / 'bin/Release/net10.0').rglob('*'):
    if p.is_file():
        target = helpers / p.relative_to(src / 'bin/Release/net10.0')
        if p.name.startswith('Fixed564SafeNativeReversalPrefix') and target.exists(): target.unlink()
        retain(p, target)
files = lambda folder: {str(p.relative_to(folder)): sha(p) for p in folder.rglob('*') if p.is_file()}
result = {'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'status': 'FROZEN_UNCOMMITTED_CANONICAL_IDENTITY_CANDIDATE_NOT_FIXED_COMMIT_OR_CI_ACCEPTANCE',
          'baseCommit': 'f4704291ff87c99b1599d93f0fc71700f0433cae', 'sourceInputHashes': source_hashes,
          'sourceInputModes': source_modes, 'actualRuleInputs': identity, 'identityReaderCommand': command,
          'runtimeFiles': files(api), 'nativeToolRuntimeFiles': files(native),
          'networkRuntimeFiles': files(network), 'helperRuntimeFiles': files(helpers),
          'sharedImmutablePaths': shared, 'freshCanonicalPrefixSources': files(src / 'Fixtures'),
          'productionTransportSourceSha256': sha(transport), 'newDatabaseSdkCheckoutOrInstaller': False,
          'nativeToolRootLoadsExactlyRecordedFilesBeforeAndAfterRun': True,
          'visiblePhysicalWindowsOrWholePrintingAcceptance': False}
assert len(result['runtimeFiles']) == 47
assert all(sha(root / p) == h for p, h in source_hashes.items())
(w / 'frozen-current-canonical-candidate-inputs-v1.json').write_text(json.dumps(result, indent=2))
print('Frozen', len(source_hashes), 'source files;', len(shared), 'immutable shared paths;', len(result['helperRuntimeFiles']), 'helper files; canonical fresh prefix built', flush=True)
