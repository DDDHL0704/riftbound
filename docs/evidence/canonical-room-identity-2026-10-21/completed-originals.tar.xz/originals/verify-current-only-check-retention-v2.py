from pathlib import Path
import collections,datetime,hashlib,json,re,xml.etree.ElementTree as ET
w=Path(__file__).resolve().parent;root=w.parents[2];load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
owner=load(w/'only-check-owner-terminal-v1.json');start=load(w/'only-check-start-inputs-v1.json');summary=load(w/'only-check-v1/summary.json');plan=load(w/'only-check-v1/plan.json')
assert owner['exitCode']==0 and owner['status']=='CHECK_PROCESS_EXIT_ZERO_INDEPENDENT_PARITY_STILL_REQUIRED'
for field in ['all3318SourceHashesUnchanged','allSourceModesUnchanged','allConformanceInputPayloadsUnchanged','all23NativePayloadsUnchanged','boundIdleAssertionEnded']:assert owner[field],field
assert summary['status']=='PASSED' and summary['total']==13219 and plan['discoveredMethods']==7642 and sum(len(s['methods']) for s in plan['shards'])==7501
def read(path):
    t=ET.parse(path);cases=collections.Counter();methods=set()
    definitions={d.attrib['id']:d.find('t:TestMethod',ns).attrib for d in t.findall('.//t:UnitTest',ns)}
    for r in t.findall('.//t:UnitTestResult',ns):
        assert r.attrib['outcome']=='Passed';d=definitions[r.attrib['testId']];cases[r.attrib['testName']]+=1;methods.add(d['className']+'.'+d['name'])
    return cases,methods
baseline=root/'var/qa/spell-remake-no-complete-choice-20261021/only-check-v1/check/results.trx';current=w/'only-check-v1/check/results.trx';before_cases,before_methods=read(baseline);cases,methods=read(current)
assert methods=={m for shard in plan['shards'] for m in shard['methods']}
assert sum(before_cases.values())==13214 and len(before_methods)==7499 and sum(cases.values())==13219 and len(methods)==7501 and not before_cases-cases and before_methods<=methods
red=ET.parse(w/'red-canonical-alias-focus-v2/focus/results.trx');red_cases=collections.Counter(r.attrib['testName'] for r in red.findall('.//t:UnitTestResult',ns));assert cases-before_cases==red_cases and sum(red_cases.values())==5
added={'Riftbound.ConformanceTests.GameHubJoinTests.AuthenticatedRoomAliasesCreateOneCanonicalSeatAndCanonicalPrivateGroups','Riftbound.ConformanceTests.GameHubJoinTests.CanonicalRoomAliasRestoresPrivateOrderAndDeduplicatesTheSameActorIntent'};assert methods-before_methods==added
original=(w/'original-before-change/tests/Riftbound.ConformanceTests/GameHubIdentityBoundaryTests.cs').read_text();now=(root/'tests/Riftbound.ConformanceTests/GameHubIdentityBoundaryTests.cs').read_text()
expected=original.replace('ClairvoyanceTests.Position()','CanonicalIdentityChoicePosition()').replace('"P1"','"p1"').replace('"P2"','"p2"').replace('// Restored fixture: create the original live seat token before the authenticated join.','// New canonical-ID fixture: create the live seat token before the authenticated join.');assert expected==now
original_network=(w/'original-before-change/tests/Riftbound.NativeNetworkSmoke/Program.cs').read_text();network=(root/'tests/Riftbound.NativeNetworkSmoke/Program.cs').read_text();marker='static async Task VerifyRoomIdentityBoundaryAsync';assert original_network[original_network.index(marker):]==network[network.index(marker):]
clean=load(root/'var/qa/fixed-f470429-native-locked-20261021/fixed-clean-api-runtime-source-and-identity-v1.json');current_sources=start['sourceInputHashes'];changed={p for p,h in clean['sourceInputHashes'].items() if current_sources[p]!=h};assert changed=={'src/Riftbound.Api/Hubs/GameHub.cs','clients/godot/scripts/Main.cs','tests/Riftbound.ConformanceTests/GameHubIdentityBoundaryTests.cs','tests/Riftbound.NativeNetworkSmoke/Program.cs'} and set(current_sources)-set(clean['sourceInputHashes'])=={'tests/Riftbound.ConformanceTests/GameHubCanonicalRoomIdentityTests.cs'}
assert len(current_sources)==3318 and all(sha(root/p)==h for p,h in current_sources.items()) and all(oct((root/p).stat().st_mode&0o777)==m for p,m in start['sourceInputModes'].items())
full={p:h for p,h in clean['sourceInputHashes'].items() if Path(p).name.startswith('FullGameEndToEndTests') and p.endswith('.cs')};assert len(full)==9 and all(sha(root/p)==h for p,h in full.items());full_methods={m for p in full for m in re.findall(r'\bpublic\s+(?:async\s+)?(?:Task|void)\s+(\w+)\s*\(',(root/p).read_text())};assert len(full_methods)==143
manifest=root/'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json';assert sha(manifest)==clean['sourceInputHashes'][str(manifest.relative_to(root))] and len(load(manifest)['cases'])==48
result={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_ONLY_CHECK_13219_CASES7501_METHODS_ORIGINAL13214_7499_EXACT_MULTISET_AND_ALL_FROZEN_INPUTS',
        'profile':'check','baseCommit':start['baseCommit'],'actualCases':13219,'actualMethods':7501,'allFullDiscoveryMethods':7642,'fullDiscoveryNotExecution':True,'originalCaseCount':13214,'originalMethodCount':7499,'addedCases':5,'addedMethods':sorted(added),
        'allOriginalCaseNameCountMultisetAndMethodsRetained':True,'allOriginalIdentityBoundaryMethods24RowsAndSecurityAssertionsRetainedWithFreshCanonicalFixtures':True,
        'allOriginalNativeWireIdentity15RejectActionsAndDropProxyAssertionsByteExact':True,'exactOnlyFourExistingSourceChangesAndOneNewTest':sorted(changed),
        'all3318SourceHashesAndModesStableThroughoutCheck':True,'all1419ConformanceAnd23NativeInputsStable':True,'original143FullMethodsNineSourceFiles11Decks110Pairs424242VictoryAndReplayAssertionsUnchanged':True,
        'original48SqlIdsOrderAndManifestBytesUnchanged':True,'actualTrxSha256':sha(current),'baselineTrxSha256':sha(baseline),'actualTestAssemblySha256':plan['testAssemblySha256'],'summary':summary,'ownerTerminal':owner,
        'onlyOneCheckExecutedForThisCoherentBatch':True,'fixedCommitFullAndCurrentVisibleWindowsAcceptance':'OPEN','wholePrintingAndGlobalCertification':False}
p=w/'check-original-case-method-and-input-retention-v2.json';assert not p.exists();p.write_text(json.dumps(result,indent=2));print(result['status'],flush=True)
