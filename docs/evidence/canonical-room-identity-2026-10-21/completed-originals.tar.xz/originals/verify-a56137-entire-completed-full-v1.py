from pathlib import Path
import ast,collections,datetime,hashlib,json,subprocess,xml.etree.ElementTree as ET,zipfile
w=Path(__file__).resolve().parent;root=w.parents[2];fixed='a56137a93d48a38d6e2e62b5b7195aa03412577f';run=39481821852;sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(p.read_text())
terminal=load(w/'preceding-a56137-actual-terminal-all11-jobs-v1.json');metadata=load(w/'preceding-a56137-terminal-artifacts-metadata-v3.json');artifacts={a['name']:a for a in metadata['artifacts']}
assert terminal['headSha']==fixed and terminal['status']=='completed' and terminal['conclusion']=='success' and len(terminal['jobs'])==11 and all(j['status']=='completed' and j['conclusion']=='success' for j in terminal['jobs'])
paths={'postgres-partition-0':w/'preceding-a56137-final-originals-v1/postgres-partition-0.zip','postgres-partition-1':w/'preceding-a56137-parts12-originals-v1/postgres-partition-1.zip','postgres-partition-2':w/'preceding-a56137-parts12-originals-v1/postgres-partition-2.zip','postgres-partition-3':root/'var/qa/fixed-a56137-native-locked-20261021/ci-fixed-a56137/postgres-partition-3.zip','native-network-results':root/'var/qa/fixed-a56137-native-locked-20261021/ci-fixed-a56137/native-network-results.zip','conformance-results':w/'preceding-a56137-conformance-results-original-v1.zip','postgres-results':w/'preceding-a56137-final-originals-v1/postgres-results.zip','full-verification-gate':w/'preceding-a56137-final-originals-v1/full-verification-gate.zip'}
originals=[]
for name,p in paths.items():
    a=artifacts[name];assert a['workflow_run']['head_sha']==fixed and not a['expired'] and p.stat().st_size==a['size_in_bytes'] and 'sha256:'+sha(p.read_bytes())==a['digest']
    with zipfile.ZipFile(p) as z:assert z.testzip() is None
    originals.append({'name':name,'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'artifactId':a['id'],'backendSizeDigestAndAllCrcExact':True})
manifest_raw=subprocess.check_output(['git','show',fixed+':tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'],cwd=root);ids=[c['id'] for c in json.loads(manifest_raw)['cases']];assert len(ids)==len(set(ids))==48
parts=[]
for i in range(4):
    with zipfile.ZipFile(paths['postgres-partition-'+str(i)]) as z:
        raw=z.read('ci-postgres/partition-receipt.json');d=json.loads(raw);expected=ids[i::4]
        assert d['status']=='REAL_POSTGRES_PARTITION_COMPLETE' and d['fixedCommit']==fixed and d['partitionIndex']==i and d['partitionCount']==4 and d['manifestSha256']==sha(manifest_raw)
        assert d['orderedDefaultCases']==ids and d['expectedCases']==d['completedCases']==expected and [e['id'] for e in d['executions']]==expected and [e['ordinal'] for e in d['executions']]==list(range(i,48,4)) and all(e['status']=='PASSED' for e in d['executions'])
        members=[]
        for f in d['outputFiles']:
            name='ci-postgres/'+f['path'];payload=z.read(name);assert len(payload)==f['bytes'] and sha(payload)==f['sha256'];members.append(name)
        assert len(members)==len(set(members)) and {n for n in z.namelist() if not n.endswith('/')}==set(members)|{'ci-postgres/partition-receipt.json','ci-postgres-partition-commit.txt'} and z.read('ci-postgres-partition-commit.txt').decode().strip()==fixed
        assert len(d['runtimeAssemblies'])==5
        parts.append({'partitionIndex':i,'cases':expected,'outputFilesVerified':len(members),'receiptSha256':sha(raw),'actualRuleInputs':d['actualRuleInputs'],'runtimeAssemblies':d['runtimeAssemblies']})
assert len({json.dumps(p['actualRuleInputs'],sort_keys=True) for p in parts})==1 and len({json.dumps(p['runtimeAssemblies'],sort_keys=True) for p in parts})==1 and sum(len(p['cases']) for p in parts)==48
with zipfile.ZipFile(paths['postgres-results']) as z:
    gate=json.loads(z.read('result.json'));assert gate['status']=='FIXED_COMMIT_ALL_SQL_PARTITIONS_AND_NATIVE_NETWORK_PASS' and gate['fixedCommit']==fixed and gate['manifestSha256']==sha(manifest_raw) and gate['caseCount']==48 and gate['orderedDefaultCases']==ids and gate['partitionCount']==4 and all(v=='success' for v in gate['jobs'].values())
    for g,p in zip(gate['partitions'],parts):assert g['partitionIndex']==p['partitionIndex'] and g['cases']==p['cases'] and g['receiptSha256']==p['receiptSha256'] and g['actualRuleInputs']==p['actualRuleInputs'] and g['runtimeAssemblies']==p['runtimeAssemblies']
with zipfile.ZipFile(paths['full-verification-gate']) as z:
    gate=json.loads(z.read('result.json'));assert gate['status']=='FIXED_COMMIT_FULL_CHILD_JOBS_ALL_SUCCEEDED' and gate['commit']==fixed and all(v=='success' for v in gate['jobs'].values())
rules=load(w/'preceding-a56137-rule-suite-independent-original-readback-v1.json');assert rules['actualCases']==13325 and rules['actualMethods']==7635 and rules['artifactSha256']==sha(paths['conformance-results'].read_bytes()) and rules['originalMatrix']['pairCount']==110 and len(rules['originalFullGameSourceHashes'])==9
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def collect(path):
    cases=collections.Counter();methods=set()
    with zipfile.ZipFile(path) as z:
        for name in z.namelist():
            if not name.endswith('/results.trx'):continue
            t=ET.fromstring(z.read(name));defs={d.attrib['id']:d.find('t:TestMethod',ns).attrib for d in t.findall('.//t:UnitTest',ns)}
            for r in t.findall('.//t:UnitTestResult',ns):
                assert r.attrib['outcome']=='Passed';d=defs[r.attrib['testId']];methods.add(d['className']+'.'+d['name']);cases[r.attrib['testName']]+=1
    return cases,methods
before=load(root/'var/qa/fixed-reversal-native-locked-20261020/fixed564-entire-full-ci-original-independent-verification-v1.json');prior_zip=next(a for a in before['originalArtifacts'] if a['name']=='conformance-results');p=root/prior_zip['path'];assert sha(p.read_bytes())==prior_zip['sha256'];old_cases,old_methods=collect(p);new_cases,new_methods=collect(paths['conformance-results']);assert sum(old_cases.values())==13315 and len(old_methods)==7631 and not old_cases-new_cases and old_methods<=new_methods and sum((new_cases-old_cases).values())==10 and len(new_methods-old_methods)==4
with zipfile.ZipFile(paths['native-network-results']) as z:
    assert z.read('commit.txt').decode().strip()==fixed;raw=z.read('native-network.log').decode();prefix='NATIVE_ROOM_IDENTITY_EVIDENCE ';network=json.loads(next(line[len(prefix):] for line in raw.splitlines() if line.startswith(prefix)))
    assert network['rejectedActions']==15 and network['leakedPrivateMessages']==0 and network['validReconnectTokenWasSupplied'] and network['identities']==['ANONYMOUS','FAILED_KEY','OTHER_HANDLE'] and 'Native network recovery passed: socket loss, authenticated room restore, fresh snapshot, rejected-token guard.' in raw
package_rows=[]
for platform,name in [('mac','native-macos-latest'),('windows','native-windows-latest')]:
    p=root/('var/qa/fixed-a56137-native-locked-20261021/native-current/'+platform+'-ci-artifact.zip');a=artifacts[name];assert p.stat().st_size==a['size_in_bytes'] and 'sha256:'+sha(p.read_bytes())==a['digest'] and a['workflow_run']['head_sha']==fixed
    package_rows.append({'platform':platform,'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'artifactId':a['id'],'sameExactPreviousVerifiedBootLifecycleAnd373PayloadArchive':True,'physicalWindowsAcceptance':False})
source=root/'scripts/audit/check-project-governance.py';function=next(n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='gameplay_path');exec(compile(ast.Module(body=[function],type_ignores=[]),str(source),'exec'),globals())
tree=subprocess.check_output(['git','ls-tree','-rz',fixed],cwd=root).split(b'\0');blobs=[]
for row in tree:
    if not row:continue
    header,name=row.split(b'\t',1);mode,kind,blob=header.decode().split();path=name.decode()
    if kind=='blob' and gameplay_path(path):blobs.append((path,blob))
batch=subprocess.Popen(['git','cat-file','--batch'],cwd=root,stdin=subprocess.PIPE,stdout=subprocess.PIPE);raw,_=batch.communicate(('\n'.join(blob for _,blob in blobs)+'\n').encode());assert batch.returncode==0;offset=0;inputs={}
for path,blob in blobs:
    end=raw.index(b'\n',offset);got,kind,size=raw[offset:end].decode().split();assert got==blob and kind=='blob';offset=end+1;payload=raw[offset:offset+int(size)];assert len(payload)==int(size);inputs[path]=sha(payload);offset+=int(size)+1
assert offset==len(raw) and inputs
result={'status':'FIXED_COMMIT_FULL_CI_AND_PARITY_VERIFIED','verifiedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commit':fixed,'runId':run,'url':terminal['url'],'jobs':{j['name']:j['conclusion'] for j in terminal['jobs']},'actualCases':13325,'actualMethods':7635,'fullGameMethods':143,'preconstructedPairs':110,'decks':11,'seed':424242,'allOriginal13315CasesAnd7631MethodsRetained':True,'addedCases':10,'addedMethods':4,'sqlCases':48,'sqlOriginalOrderedCases':ids,'sqlOriginalOutputs':sum(p['outputFilesVerified'] for p in parts),'sqlPartitions':parts,'actualSqlRuleInputs':parts[0]['actualRuleInputs'],'ciReportedRuntimeAssemblyIdentities':parts[0]['runtimeAssemblies'],'runtimeBinariesNotUploadedNotClaimedIndependentlyDownloaded':True,'network':network,'ruleOriginalRetention':{'path':str((w/'preceding-a56137-rule-suite-independent-original-readback-v1.json').relative_to(root)),'sha256':sha((w/'preceding-a56137-rule-suite-independent-original-readback-v1.json').read_bytes())},'gameplaySourceInputs':{'commit':fixed,'files':inputs,'derivedFromExactGitBlobsNoCheckoutOrBuildCreated':True},'originalArtifacts':originals,'nativeMacAndWindowsPackages':package_rows,'actualNativeAliasRestoreFailureIssue77RetainedDespiteGreenFull':True,'currentF470AndUncommittedCanonicalIdentityCandidateNotCovered':True,'visibleCurrentPairedWindowsAndWholePrintingAcceptance':'OPEN','wholeGoalComplete':False}
assert result['sqlOriginalOutputs']==312
p=w/'preceding-a56137-entire-full-independent-original-verification-v1.json';assert not p.exists();p.write_text(json.dumps(result,indent=2));print('PASS actuala56137 11 jobs /13325 cases7635 methods /143 full110 pairs /48 SQL312 original outputs; original13315/7631 retained plus10/4',flush=True)
