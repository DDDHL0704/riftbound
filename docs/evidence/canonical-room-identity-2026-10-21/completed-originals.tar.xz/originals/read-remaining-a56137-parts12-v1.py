from pathlib import Path
import datetime, hashlib, json, subprocess, zipfile

w = Path(__file__).resolve().parent
root = w.parents[2]
fixed = 'a56137a93d48a38d6e2e62b5b7195aa03412577f'
metadata = json.loads((w / 'preceding-a56137-artifacts-original-v1.json').read_text())
out = w / 'preceding-a56137-parts12-originals-v1'
out.mkdir(exist_ok=False)
sha = lambda b: hashlib.sha256(b).hexdigest()
raw_manifest = subprocess.check_output(['git', 'show', fixed + ':tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'], cwd=root)
ids = [c['id'] for c in json.loads(raw_manifest)['cases']]
assert len(ids) == len(set(ids)) == 48
with zipfile.ZipFile(root / 'var/qa/fixed-a56137-native-locked-20261021/ci-fixed-a56137/postgres-partition-3.zip') as z:
    reference = json.loads(z.read('ci-postgres/partition-receipt.json'))
records = []
result = {'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'fixedCommit': fixed,
          'runId': 39481821852, 'status': 'RUNNING_READ_ONLY_DOWNLOAD_AND_VERIFY', 'records': records,
          'entireFullOrOtherPartsCertified': False}
try:
    for index in [1, 2]:
        name = 'postgres-partition-' + str(index)
        a = next(a for a in metadata['artifacts'] if a['name'] == name)
        assert not a['expired'] and a['workflow_run']['head_sha'] == fixed
        target = out / (name + '.zip')
        with target.open('xb') as stream:
            subprocess.run(['gh', 'api', f'repos/DDDHL0704/riftbound/actions/artifacts/{a["id"]}/zip'], stdout=stream, check=True)
        digest = sha(target.read_bytes())
        assert target.stat().st_size == a['size_in_bytes'] and 'sha256:' + digest == a['digest']
        with zipfile.ZipFile(target) as z:
            assert z.testzip() is None
            d = json.loads(z.read('ci-postgres/partition-receipt.json'))
            expected = ids[index::4]
            assert d['fixedCommit'] == fixed and d['partitionIndex'] == index and d['partitionCount'] == 4
            assert d['status'] == 'REAL_POSTGRES_PARTITION_COMPLETE'
            assert d['orderedDefaultCases'] == ids and d['expectedCases'] == d['completedCases'] == expected
            assert d['manifestSha256'] == sha(raw_manifest) and d['actualRuleInputs'] == reference['actualRuleInputs']
            assert [e['id'] for e in d['executions']] == expected
            assert [e['ordinal'] for e in d['executions']] == list(range(index, 48, 4))
            assert all(e['status'] == 'PASSED' for e in d['executions'])
            members = []
            for f in d['outputFiles']:
                member = 'ci-postgres/' + f['path']
                raw = z.read(member)
                assert len(raw) == f['bytes'] and sha(raw) == f['sha256']
                members.append(member)
            assert len(members) == len(set(members))
            assert {n for n in z.namelist() if not n.endswith('/')} == set(members) | {'ci-postgres/partition-receipt.json', 'ci-postgres-partition-commit.txt'}
            assert z.read('ci-postgres-partition-commit.txt').decode().strip() == fixed
            records.append({'partition': index, 'artifactId': a['id'], 'bytes': target.stat().st_size,
                            'sha256': digest, 'backendSizeDigestAndEveryCrcExact': True,
                            'allOutputsBytesHashesAndClosedMemberSetExact': True,
                            'orderedExecutedIds': expected, 'outputFileCount': len(members),
                            'actualCiRuleInputs': d['actualRuleInputs'], 'runtimeAssemblyReports': d['runtimeAssemblies']})
        print(name, 'PASS', len(expected), 'original identities', len(members), 'original outputs', flush=True)
    result['status'] = 'PASS_ONLY_FIXED_A56137_PARTITIONS_1_AND_2_ORIGINALS_NOT_ENTIRE_FULL'
finally:
    (w / 'preceding-a56137-parts12-independent-readback-v1.json').write_text(json.dumps(result, indent=2))
