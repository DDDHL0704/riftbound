from pathlib import Path
import datetime, gzip, hashlib, json, urllib.request
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=root/'var/qa/candlelit-current-cn16-recertification-20261021';w.mkdir(exist_ok=False)
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda b:hashlib.sha256(b).hexdigest()
def digest_file(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
def acquire(url,name,body=None,prior=None):
    row={'url':url,'request':body,'attemptedAtUtc':now(),'region':'CN','language':'zh-CN','observedAsOf':'2026-10-21','publicationDate':None,'effectiveDateIndependentlyConfirmed':None,'semanticCertification':False}
    target=w/(name+'.gz');assert not target.exists()
    try:
        req=urllib.request.Request(url,data=None if body is None else json.dumps(body,ensure_ascii=False).encode(),headers={'User-Agent':'Mozilla/5.0 Riftbound official audit','Content-Type':'application/json'})
        h=hashlib.sha256();size=0
        with urllib.request.urlopen(req,timeout=45) as response,target.open('xb') as f:
            row.update(httpStatus=response.status,resolvedUrl=response.url,responseHeaders={k:response.headers[k] for k in ['Date','ETag','Age','Last-Modified','Content-Length','Content-Type'] if k in response.headers})
            with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as sink:
                while True:
                    b=response.read(262144)
                    if not b:break
                    h.update(b);size+=len(b);sink.write(b)
        row.update(receivedAtUtc=now(),sha256=h.hexdigest(),bytes=size,status='FETCHED_ORIGINAL_CURRENT_BYTES_NOT_SEMANTIC_CERTIFICATION',path=str(target.relative_to(root)),losslessGzipRawResponse=True,compressedSha256=digest_file(target))
        if prior and row['sha256']==prior['sha256']:
            original=root/prior['path'];assert original.is_file() and digest_file(original)==row['sha256']
            row.update(priorRawReference={'path':prior['path'],'sha256':prior['sha256']},exactOriginalReused=True,retiredIdenticalTemporaryGzip={'bytes':target.stat().st_size,'sha256':row['compressedSha256']},path=prior['path'],losslessGzipRawResponse=False)
            target.unlink()
    except Exception as e:
        row.update(status='EXPLICIT_SOURCE_ACCESS_OR_ACQUISITION_GAP',receivedAtUtc=now(),errorType=type(e).__name__,error=str(e))
        if target.exists():row['retainedPartialCompressedBytes']=target.stat().st_size
    (w/(name+'.receipt.json')).write_text(json.dumps(row,ensure_ascii=False,indent=2))
    print(name,row['status'],row.get('sha256'),flush=True)
    return row
def raw(row):
    p=root/row['path'];return gzip.decompress(p.read_bytes()) if row['losslessGzipRawResponse'] else p.read_bytes()

params=dict(pageNum=1,pageSize=100,searchContent='',cardCategoryList=[],cardColorList=[],rarityList=[],productCodeList=[])
cards=[]
for query,name in [('烛光','candlelit-current-card-search-v1'),('光明未来','bright-future-current-card-search-v1')]:
    receipt=acquire('https://lol-api.playloltcg.com/xcx/card/searchCardCraftWeb',name,{**params,'searchContent':query});cards.append(receipt)
    if receipt['status'].startswith('FETCHED_'):
        d=json.loads(raw(receipt));assert d['code']==0 and d['result']['total']==len(d['result']['list'])
        rows=d['result']['list'];(w/(name+'-all-original-fields.json')).write_text(json.dumps(rows,ensure_ascii=False,indent=2));print('exact selected IDs',[(r['id'],r['cardNo'],r['cardName']) for r in rows],flush=True)
directory=acquire('https://lol-api.playloltcg.com/xcx/gameRule/getGameRuleList','cn-current-rules-directory-v1',{'pageNum':1,'pageSize':1000})
if directory['status'].startswith('FETCHED_'):
    listed=json.loads(raw(directory));assert listed['code']==0
    before=json.loads((root/'var/qa/source-round-20261021/rules/cn-directory-comparison.json').read_text())['after']
    (w/'current-listed-rules-full-field-comparison-v1.json').write_text(json.dumps({'atUtc':now(),'allOriginalRowsAndOrderExact':listed['result']==before,'before':before,'after':listed['result'],'noHistoricalSourceRemovedOrReplaced':True,'semanticCertification':False},ensure_ascii=False,indent=2))
pdfs=[]
for source_id in ['DOC-01','DOC-02','DOC-03']:
    prior=json.loads((root/('docs/evidence/source-round-2026-10-21/originals/rules/'+source_id+'.pdf.receipt.json')).read_text())
    pdfs.append(acquire(prior['url'],source_id+'-current-pdf-v1',prior=prior))
(w/'source-intake-current-observation-v1.json').write_text(json.dumps({'atUtc':now(),'status':'EXACT_CURRENT_SOURCE_INTAKE_ONLY_BEFORE_CN16_SEMANTIC_REVIEW','regionalAuthority':'CN/zh-CN','currentAdoptedCoreEffectiveDate':'2026-10-16','oldCandlelitJulyRuleReviewRetainedAsHistorical':True,'cardReceipts':cards,'rulesDirectoryReceipt':directory,'currentThreePrimaryPdfReceipts':pdfs,'allOtherPrintingsClausesConsumersAndProductObligationsRetained':True,'runtimeSourceTestsOrAcceptedDatabaseHistoriesChanged':False},ensure_ascii=False,indent=2))
