from pathlib import Path
import datetime,hashlib,json,shutil,tarfile
w=Path(__file__).resolve().parent;root=w.parents[2];out=root/'docs/evidence/canonical-room-identity-2026-10-21';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
check=load(w/'check-original-case-method-and-input-retention-v2.json');assert check['actualCases']==13219 and check['actualMethods']==7501 and check['onlyOneCheckExecutedForThisCoherentBatch']
native=load(w/'same-canonical-room-owner-terminal-v2.json');assert native['status'].startswith('PASS_') and native['ownApiStopped'] and native['ownPostgresSmartStopped'] and native['allOriginal231AuditSevenTablesExactAtStop'] and native['allOriginal48NativeSevenTablesExactAtStop']
independent=load(w/'independent-canonical-room-history-result-v2.json');assert independent['commands']==80 and independent['events']==547 and independent['actualHistoricalPayloads']=={'state_snapshots':80,'snapshots':156,'action_prompts':156}
previous_full=load(w/'preceding-a56137-entire-full-independent-original-verification-v1.json');assert previous_full['status']=='FIXED_COMMIT_FULL_CI_AND_PARITY_VERIFIED' and previous_full['sqlOriginalOutputs']==312
inputs=load(w/'frozen-current-canonical-candidate-inputs-v3.json');assert all(sha(root/p)==h for p,h in inputs['sourceInputHashes'].items())
old=load(w/'original-governance-before-publication-v1/docs/audit/current-manifest.json');assert load(root/'docs/audit/current-manifest.json')==old
reviews_before=(w/'original-governance-before-publication-v1/docs/evidence/rules-reaudit-2026-10-11/review-decisions.json').read_bytes();assert reviews_before==(root/'docs/evidence/rules-reaudit-2026-10-11/review-decisions.json').read_bytes()
python_log=(w/'actual-python-verification-v1.log').read_text();assert 'Ran 73 tests' in python_log and python_log.rstrip().endswith('OK')
out.mkdir(exist_ok=False)
def write(path,value):
    with path.open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
def pin(path,role):return {'path':str(path.relative_to(root)),'sha256':sha(path),'role':role}
selected={
 'red-reproduction.json':'red-before-product-change-v2.json',
 'focus80.json':'green-canonical-boundary-focus-v1/summary.json',
 'focus284.json':'green-all-gamehub-identity-focus-v2/summary.json',
 'check-original-retention.json':'check-original-case-method-and-input-retention-v2.json',
 'actual-candidate-source-and-runtime-inputs.json':'frozen-current-canonical-candidate-inputs-v3.json',
 'native-original-tool-owner-failure-retained.json':'live-current-tool-main-owner-terminal-v1.json',
 'native-same-room-normal-score-and-network-terminal.json':'same-canonical-room-owner-terminal-v2.json',
 'native-80-original-history.json':'independent-canonical-room-history-result-v2.json',
 'native-independent-reader-runtime-and-run.json':'independent-canonical-room-history-run-v2.json',
 'actual-canonical-sql-account-seat-binding.json':'independent-current-canonical-sql-account-seat-binding-v1.json',
 'previous-a56137-full.json':'preceding-a56137-entire-full-independent-original-verification-v1.json',
 'previous-a56137-rule-suite-originals.json':'preceding-a56137-rule-suite-independent-original-readback-v1.json',
 'fixed-f470-parts12-only.json':'fixed-f470-only-parts12-original-independent-readback-v1.json',
 'latest-only-native-app-inventory.json':'actual-current-only-pair-and-two-platform-archive-inventory-v1.json',
 'obsolete-build-staging-retirement.json':'actual-obsolete-qa-build-staging-cleanup-v1.json',
 'duplicate-godot-download-retirement.json':'actual-duplicate-godot-tool-download-retirement-v1.json',
 'original-serialized-field-assumption-failure.json':'current-tool-original-field-assumption-failure-disposition-v1.json',
 'original-score-helper-selector-failure.json':'score-helper-ambiguous-battlefield-disposition-v1.json'
}
for name,source in selected.items():shutil.copyfile(w/source,out/name)
write(out/'python-verification.json',{'atUtc':now(),'status':'PASS_ALL73_ORIGINAL_PYTHON_VERIFICATION_TESTS','command':'python3 -m unittest discover -s scripts/tests -v','originalLogSha256':sha(w/'actual-python-verification-v1.log'),'sourceChangesMadeForThisResult':False})
gate=next(g for g in old['acceptanceGates'] if g['id']=='ROOM_IDENTITY_BOUNDARY');write(out/'previous-room-identity-gate.json',gate)
affected={name:context for name,context in old['reviewContexts'].items() if any(p['path']=='clients/godot/scripts/Main.cs' for p in context['implementation'])};assert len(affected)==4;write(out/'previous-four-platform-implementation-contexts.json',affected)
# Explicit privacy and runtime exclusions: classify by actual purpose, never by a broad substring such as "private".
private={w/'session-a.json',w/'session-b.json',w/'actual-safe-native-prefix-v1/session-native-a.json',w/'actual-safe-native-prefix-v1/session-native-b.json'}
private.update(w/p for p in ['actual-safe-native-prefix-v1/original-private-native-wire-snapshots-prompts.ndjson.gz','actual-safe-normal-score-continuation-v1/original-private-score-gateway-wire.ndjson.gz','actual-safe-normal-score-continuation-v2/original-private-score-gateway-wire.ndjson.gz'])
for file in ['live-current-tool-main-owner-terminal-v1.json','same-canonical-room-owner-terminal-v1.json','same-canonical-room-owner-terminal-v2.json']:
    private.update(w/p['log'] for p in load(w/file).get('ownedApiProcesses',[]))
runtime_dirs={p for p in w.iterdir() if p.is_dir() and 'runtime' in p.name}
records=[];excluded=[];paths=[]
for p in sorted(w.rglob('*')):
    if not p.is_file():continue
    relative=p.relative_to(w)
    if any(parent==folder for folder in runtime_dirs for parent in p.parents):continue
    if any(part in {'bin','obj','__pycache__'} for part in relative.parts) or p.suffix in {'.pyc','.tmp'}:continue
    if p.name=='publish-canonical-account-batch-v1.log':continue
    if p in private or p.name.endswith('.rotating-next'):
        excluded.append({'originalPath':str(p.relative_to(root)),'sha256':sha(p),'bytes':p.stat().st_size,'reason':'EXPLICIT_AUTH_SESSION_OR_PRIVATE_OPERATIONAL_WIRE_LOG_RETAINED_LOCALLY','retainedLocally':True});continue
    if p.suffix not in {'.json','.log','.cs','.csproj','.py','.md','.trx','.zip','.gz','.txt'}:continue
    member='originals/'+relative.as_posix();paths.append((p,member));records.append({'originalPath':str(p.relative_to(root)),'member':member,'bytes':p.stat().st_size,'sha256':sha(p)})
archive=out/'completed-originals.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as tar:
    for p,member in paths:tar.add(p,arcname=member,recursive=False)
with tarfile.open(archive,'r:xz') as tar:
    assert {i.name for i in tar.getmembers() if i.isfile()}=={r['member'] for r in records}
    for row in records:
        raw=tar.extractfile(row['member']).read();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
write(out/'archive-map.json',{'atUtc':now(),'status':'ALL_DECLARED_COMPLETED_ORIGINAL_BYTES_VERIFIED_WITH_EXACT_PRIVACY_EXCLUSIONS','archive':pin(archive,'completed-originals'),'records':records,'explicitPrivateExclusions':excluded,'allExecutedImmutableRuntimePayloadsRemainLocalAndAreNotDuplicatedIntoArchive':True,'allSourceMethodsTheoryRowsFailuresDatabaseAndNeededTracesRetained':True})
source={
 'recordedAtUtc':now(),'status':'SCOPED_CANONICAL_ROOM_IDENTITY_CHECK_NATIVE_SOURCE_TOOL_SQL_AND_ORIGINAL_HISTORY_PASS_NEW_FIXED_FULL_VISIBLE_WINDOWS_OPEN',
 'region':'CN','language':'zh-CN','adoptedCoreEffectiveAsOf':'2026-10-16','observationAsOf':'2026-10-21','sourceManifestAtExecution':old['currentSourceRound20261021'],
 'sourceDatesAndOriginalCertificationScopeUnchanged':True,'baseCommit':inputs['baseCommit'],'actualTestedSourceIncludedDeclaredUncommittedChanges':True,'issue':77,
 'exactSourceAndAll47Api23Native22Network74HelperRuntimeFiles':pin(out/'actual-candidate-source-and-runtime-inputs.json','actual-source-and-platform-runtime-inputs'),
 'actualRuleInputs':inputs['actualRuleInputs'],'platformApiAssemblySha256':inputs['runtimeFiles']['Riftbound.Api.dll'],'platformNativeClientAssemblySha256':inputs['nativeToolRuntimeFiles']['Riftbound.GodotClient.dll'],
 'actualRuleInputIdentitySameAsCleanFixedF470EngineButPlatformApiAndMainSourceChanged':True,'futureFixedCiRuntimeIdentityMustBeRecordedSeparately':True,
 'semanticReview':'PLATFORM_CANONICAL_ACCOUNT_BOUNDARY_ONLY_NOT_CARD_OR_RULE_CERTIFICATION','implementation':'FIVE_CONFIGURED_AUTHORITY_ROOM_BOUNDARIES_USE_EXISTING_ACCOUNT_NORMALIZATION_BEFORE_INDEPENDENT_AUTHORIZATION_NO_OLD_SEAT_FALLBACK',
 'testExecution':{'red':pin(out/'red-reproduction.json','red'),'focus80':pin(out/'focus80.json','focus'),'allGameHubAndIdentity284':pin(out/'focus284.json','adjacent'),'oneCheck':pin(out/'check-original-retention.json','check'),'python73':pin(out/'python-verification.json','python')},
 'sourceToolAcceptance':{'terminal':pin(out/'native-same-room-normal-score-and-network-terminal.json','source-tool-native-and-normal-score'),'independentAllHistory':pin(out/'native-80-original-history.json','independent-sql-history'),'actualCanonicalAccountsAndSeats':pin(out/'actual-canonical-sql-account-seat-binding.json','independent-account-seat-binding'),'commands':80,'events':547,'states':80,'bothPlayersCombinedPrivateSnapshots':156,'bothPlayersCombinedPrivatePrompts':156,'gatewayOpening':60,'nativeInteractionControllerCommands':3,'normalGatewayContinuation':17,'score':'8:0','turn':50,'hardwareButtonsOrVisibleAcceptance':False},
 'fixedCommitCi':'PENDING_NEW_COHERENT_COMMIT_FULL','productAcceptance':{'currentFixedCiExportedPair':'OPEN','visiblePairedSqlNetworkNormalScoreAndReplay':'OPEN','physicalWindows':'OPEN'},
 'previousA56137ActualCompleteFull':pin(out/'previous-a56137-full.json','prior-fixed-full'),'f470PartialCi':pin(out/'fixed-f470-parts12-only.json','fixed-f470-partial-originals'),
 'originalA56137NativeAliasFailureAndSameOldGatewayContinuationRemainExactlyTheirOldScopes':old['currentFixedA56137NativeHandleCaseFinding'],
 'existingUnifiedAcceptanceGate':'ROOM_IDENTITY_BOUNDARY','previousGate':pin(out/'previous-room-identity-gate.json','prior-identity-gate'),
 'allOriginal150Reviews65ContextScopes245GateIdsSevenDeltas16944ObligationIds1740Printings14293BlocksCn236En8And139NewsRetained':True,
 'previousFourMainImplementationContexts':pin(out/'previous-four-platform-implementation-contexts.json','prior-platform-contexts'),
 'storage':{'inventory':pin(out/'latest-only-native-app-inventory.json','latest-only-native-inventory'),'obsoleteQaBuildStaging':pin(out/'obsolete-build-staging-retirement.json','build-staging-retirement'),'duplicateGodotToolDownload':pin(out/'duplicate-godot-download-retirement.json','tool-download-retirement'),'newSdkCheckoutDatabaseNativeAppOrInstallerCopies':False},
 'completedOriginals':pin(out/'archive-map.json','all-declared-originals'),'wholePrintingOrGlobalSemanticCertification':False,'goalComplete':False
}
write(out/'source-manifest.json',source);source_pin=pin(out/'source-manifest.json','current-canonical-account-platform-input-change')
manifest=load(root/'docs/audit/current-manifest.json');assert manifest==old;main_hash=sha(root/'clients/godot/scripts/Main.cs');hub_hash=sha(root/'src/Riftbound.Api/Hubs/GameHub.cs')
for name in affected:
    context=manifest['reviewContexts'][name]
    for p in context['implementation']:
        if p['path']=='clients/godot/scripts/Main.cs':p['sha256']=main_hash
    context['currentImplementationCommit']=inputs['baseCommit'];context['currentPlatformInputEvidence']=source_pin
    expected=json.loads(json.dumps(affected[name]))
    for item in expected['implementation']:
        if item['path']=='clients/godot/scripts/Main.cs':item['sha256']=main_hash
    expected['currentImplementationCommit']=inputs['baseCommit'];expected['currentPlatformInputEvidence']=source_pin
    assert context==expected and context['ciState']=='PENDING'
current_gate=next(g for g in manifest['acceptanceGates'] if g['id']=='ROOM_IDENTITY_BOUNDARY');current_gate['implementation']=[{'path':'src/Riftbound.Api/Hubs/GameHub.cs','sha256':hub_hash}];current_gate['priorImplementationAndAllPreviousEvidence']=pin(out/'previous-room-identity-gate.json','prior-identity-gate');current_gate['currentCanonicalAccountEvidence']=source_pin;current_gate['currentStatus']={'semanticReview':'PLATFORM_IDENTITY_ONLY','implementation':'SCOPED_CURRENT_SOURCE','testExecution':'FOCUS80_ALL_GAMEHUB284_ONLY_CHECK13219_NATIVE3_PLUS_SAME_ROOM80_547_AND_NETWORK15_REJECTS_PASS','fixedCommitCi':'PENDING_NEW_FULL','visibleAndPhysicalWindows':'OPEN'}
assert len(manifest['acceptanceGates'])==245 and all(g==next(x for x in old['acceptanceGates'] if x['id']==g['id']) for g in manifest['acceptanceGates'] if g['id']!='ROOM_IDENTITY_BOUNDARY')
manifest['currentCanonicalRoomAccountIdentityInputChange']=source_pin;manifest['precedingFixedA56137ActualCompleteFullCiReadback']=pin(out/'previous-a56137-full.json','previous-fixed-a56137-entire-full')
(root/'docs/audit/current-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
document=(w/'planned-canonical-account-audit-v1.md').read_text();document=document.replace('本批唯一check及原方法/用例/输入保留以','唯一check13219例/7501方法全部通过，原13214例/7499方法完整保留，仅增5例/2方法；3318源码/模式、1419 Conformance和23原生输入全程不变。对应原方法/用例/输入保留以')
(root/'docs/CANONICAL_ROOM_IDENTITY_AUDIT_2026-10-21.md').write_text(document)
status_path=root/'docs/PROJECT_STATUS.md';old_status=(w/'original-governance-before-publication-v1/docs/PROJECT_STATUS.md').read_text();assert status_path.read_text()==old_status
new='''2026-10-21 本批：[普通房间规范账号与锁屏验收](CANONICAL_ROOM_IDENTITY_AUDIT_2026-10-21.md)。[#77](https://github.com/DDDHL0704/riftbound/issues/77)配置认证的五个房间入口统一账号身份后再独立授权，保留旧全部测试方法/Theory/安全与幂等断言；旧受控夹具在首动作前创建为规范账号，不迁移旧局。新增5例/2方法；原五个红例保留，80及284定向通过。唯一check13219/7501全过，原13214/7499多重集合完整保留，3318源/模式、1419 Conformance和23原生载荷全程稳定，原143方法/110配对/11牌组/424242/胜利回放及48 SQL身份顺序不变；Python73通过，无第二次check。

锁屏同一普通局60网关开局+3真实Godot交互控制器+17网关正常续行，共80命令547事件、8:0第50回合，一征服七驻守、非投降/燃尽、双牌堆非空。80历史状态/双方合计156私有快照/156提示、全部字段/null/隐私/原提示tick及完整原回放独立通过；原63命令历史和种子/空白初态不变。混合大小写真实网络恢复和原15拒绝零泄露保留，实际只读SQL账号与恰好两席同为规范身份。两次助手错误保留同局继续，均不重放原生命令；该轮原231审计48旧原生七表不变，新普通及网络局留至50，API/库正常停止。源候选工具通过不称CI导出/硬件按钮/可见双端或Windows通过。旧a56137原生失败0命令及其同局网关48/259正常结束仍保留。

前a56137完整CI39481821852实际11项success，独立核对13325/7635、143完整方法110配对、48 SQL身份312原输出、网络15拒绝零泄露；原564的13315/7631保留，仅增10/4。f470429仍等完整终态，本批新固定full另需执行。CN16源范围/取得日期及150审查65上下文245门禁7增量16944义务、1740印次14293块/CN236/EN8/139公告保留；身份门禁追加新证据并留完整前版，四Main上下文仅刷新当前实现输入，不提升整卡或全量。清退200756622字节重复工具ZIP及4526724字节过期构建暂存；153安装工具文件、最新A/B与每平台一包、执行冻结载荷/来源/失败/库均保留，物理回收不推定。Goal active / NOT READY。

以下原批次文字按当时范围和终态保留，当前状态以上述本批及精确收据为准。

'''
assert old_status.startswith('# 当前项目状态\n\n');status_path.write_text('# 当前项目状态\n\n'+new+old_status[len('# 当前项目状态\n\n'):])
write(w/'coherent-canonical-account-publication-v1.json',{'atUtc':now(),'status':'PUBLISHED_EXACT_SCOPED_SOURCE_NATIVE_AND_CHECK_EVIDENCE_NOT_FULL_OR_GOAL_COMPLETION','canonicalDirectory':str(out.relative_to(root)),'declaredOriginalFiles':len(records),'archiveBytes':archive.stat().st_size,'explicitPrivateExclusions':len(excluded),'fourMainContextScopesAndEvidenceUnchangedCurrentImplementationPinsRefreshed':True,'allOther244GatesExactlyUnchanged':True,'originalRoomIdentityGateFullObjectRetained':True,'original150ReviewObjectsExactlyUnchanged':reviews_before==(root/'docs/evidence/rules-reaudit-2026-10-11/review-decisions.json').read_bytes(),'allSourceAndTestInputHashesRemainCheckVerified':all(sha(root/p)==h for p,h in inputs['sourceInputHashes'].items()),'governanceValidationAndIndependentPublicationReadbackStillRequired':True})
print('Published canonical account evidence:',len(records),'originals',archive.stat().st_size,'archive bytes; governance/independent readback required',flush=True)
