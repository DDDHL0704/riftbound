using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.CardCatalog;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
var assemblies = new[] { typeof(CoreRuleEngine).Assembly, typeof(CommandReceiptDto).Assembly, typeof(OfficialCardCatalog).Assembly, typeof(PostgresMatchRecoveryStore).Assembly };
var loaded = new { baseDirectory = AppContext.BaseDirectory, actualRuleInputs = RuleInputIdentity.Current,
    assemblies = assemblies.Select(a => new { name = a.GetName().Name, path = a.Location,
        sha256 = Hash(File.ReadAllBytes(a.Location)), mvid = a.ManifestModule.ModuleVersionId }).ToArray() };
if (args is ["--loaded-inputs"]) { Console.WriteLine(JsonSerializer.Serialize(loaded, json)); return; }
if (args is ["--quote", var framePath, var actor, var requestPath]) {
    using var document = Read(framePath);
    var state = document.RootElement.GetProperty("authoritativeState").Deserialize<MatchState>(json)!;
    var request = JsonSerializer.Deserialize<PlayCostPreviewRequestDto>(File.ReadAllText(requestPath), json)!;
    Check(RuleInputIdentity.IsCurrentState(state) && request.SnapshotTick == state.Tick
        && ResolutionResult.BuildPrompts(state)[actor].PromptId == request.PromptId, "Actual native request must match the retained original state and private prompt.");
    var quote = new CoreRuleEngine().PreviewPlayCard(state, actor, request);
    Console.WriteLine(JsonSerializer.Serialize(new { quote, loaded, originalStateSha256 = MatchStateHasher.Hash(state) }, json)); return;
}
Check(args.Length == 5 && args[0] == "--verify", "Use --verify originalSqlRoot newOutput nativeRootOrDash exactCaseCount.");
var home = Path.GetFullPath(args[1]); var output = Path.GetFullPath(args[2]); var native = args[3]; var expected = int.Parse(args[4]);
Check(expected is 12 or 13 && !File.Exists(output), "Only the two declared original candidates and a fresh result.");
var receipts = Directory.GetFiles(home, "receipt.json", SearchOption.AllDirectories).Order().ToArray();
Check(receipts.Length == expected, "Every original finite SQL case is present.");
var settings = new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
Check(settings.Host == "127.0.0.1" && settings.Port == 55486 && settings.Database == "riftbound_acceptance" && settings.Username == "codex_riftbound_audit", "Only the existing dedicated audit database.");
settings.Options = "-c default_transaction_read_only=on";
await using var source = NpgsqlDataSource.Create(settings.ConnectionString); await using var connection = await source.OpenConnectionAsync();
Check((string)(await new NpgsqlCommand("show transaction_read_only", connection).ExecuteScalarAsync())! == "on", "Actual read-only connection.");
var totals = new Dictionary<string, int> { ["rooms"] = 0, ["commands"] = 0, ["events"] = 0, ["authority"] = 0,
    ["snapshots"] = 0, ["prompts"] = 0, ["originalPrefixReplays"] = 0, ["nativeEquivalentReplays"] = 0, ["actualRefusals"] = 0 };
var results = new List<object>();
using var nativeIndex = native == "-" ? null : Read(Path.Combine(native, "index.json"));
foreach (var receiptPath in receipts) {
    using var receipt = Read(receiptPath); var r = receipt.RootElement; var folder = Path.GetDirectoryName(receiptPath)!;
    var room = r.GetProperty("room").GetString()!; var branch = r.GetProperty("branch").GetString()!;
    var count = r.GetProperty("originalAcceptedInputs").GetInt32(); var rejected = r.GetProperty("deliberateTamperRecoveryRejected").GetBoolean();
    Check(r.GetProperty("coldRecoveries").GetInt32() == count && Same(r.GetProperty("actualRuleInputs"), JsonSerializer.SerializeToElement(RuleInputIdentity.Current, json)), "Every receipt binds the actual current runtime and original cold history.");
    using var originalDocument = Read(Path.Combine(folder, $"prefix-{count:D2}-original-frame.json.gz"));
    var original = originalDocument.RootElement.Deserialize<MatchRecoveryFrame>(json)!;
    Check(original.IsConsistent && original.Commands.Count == count && original.Commands.All(c => c.Accepted && c.RuleInputs == RuleInputIdentity.Current)
        && original.OpeningSeed != 0 && original.ReplayInitialState is { Tick: 0, Status: "EMPTY", Seats.Count: 0, CardObjects.Count: 0 }, "All original commands, private seed and empty origin.");
    var actual = (await new PostgresMatchRecoveryStore(source).LoadAsync(room, default))!;
    Check(Same(JsonSerializer.SerializeToElement(actual.Commands, json), JsonSerializer.SerializeToElement(original.Commands, json))
        && Same(JsonSerializer.SerializeToElement(actual.Events, json), JsonSerializer.SerializeToElement(original.Events, json))
        && actual.OpeningSeed == original.OpeningSeed && MatchStateHasher.Hash(actual.ReplayInitialState!) == MatchStateHasher.Hash(original.ReplayInitialState!), "No accepted log, event, seed or replay origin is rewritten.");
    using var sealedRows = Read(Path.Combine(folder, rejected ? "actual-corrupt-seven-tables.json.gz" : "original-final-seven-tables.json.gz"));
    foreach (var table in new[] { "matches", "match_players", "command_log", "game_events", "state_snapshots", "snapshots", "action_prompts" }) {
        using var query = new NpgsqlCommand($"select coalesce(json_agg(t order by row_to_json(t)::text),'[]'::json)::text from (select * from {table} where match_id=@room)t", connection);
        query.Parameters.AddWithValue("room", room); using var rows = JsonDocument.Parse((string)(await query.ExecuteScalarAsync())!);
        Check(Same(rows.RootElement, sealedRows.RootElement.GetProperty(table)), "Every original actual SQL field, null, omission and row: " + table);
    }
    foreach (var command in original.Commands) {
        var n = original.Commands.TakeWhile(c => c != command).Count() + 1;
        using var prefixDocument = Read(Path.Combine(folder, $"prefix-{n:D2}-original-frame.json.gz"));
        var prefix = prefixDocument.RootElement.Deserialize<MatchRecoveryFrame>(json)!; var state = prefix.AuthoritativeState!;
        Check(prefix.Commands.Count == n && prefix.OpeningSeed == original.OpeningSeed && RuleInputIdentity.IsCurrentState(state), "Every original prefix retains exact identity and private opening seed.");
        var replay = await MatchActionLogReplayer.VerifyFinalStateAsync(original.ReplayInitialState!, original.Commands.Take(n).ToArray(), state,
            new CoreRuleEngine(), default, original.Events.Where(e => e.Sequence <= command.CompletedEventSequence).ToArray());
        Check(replay.IsMatch, "Every complete original command/event prefix replays: " + string.Join(";", replay.Errors)); totals["originalPrefixReplays"]++;
        var visible = state.PendingRuleChoice?.Request.Preview ?? state;
        foreach (var view in prefix.PlayerViews.Values) {
            Check(state.Seats.ContainsKey(view.PlayerId), "Only actual historical seats receive private views.");
            foreach (var payload in new[] { JsonSerializer.SerializeToElement(view.Snapshot, json), JsonSerializer.SerializeToElement(view.Prompt, json) }) {
                var text = payload.GetRawText();
                foreach (var enemy in visible.Seats.Keys.Where(p => p != view.PlayerId))
                foreach (var id in visible.PlayerZones[enemy].Hand.Concat(visible.PlayerZones[enemy].MainDeck).Concat(visible.PlayerZones[enemy].RuneDeck))
                    Check(!text.Contains(JsonSerializer.Serialize(id), StringComparison.Ordinal), "Independent opponent hidden-zone identity boundary from original checkpoint or literal stored preview.");
                Check(!text.Contains("\"flowPlay\"", StringComparison.Ordinal), "Private Flow generation receipt is never projected.");
            }
        }
        totals["snapshots"] += prefix.PlayerViews.Count; totals["prompts"] += prefix.PlayerViews.Count; totals["authority"]++;
    }
    var final = original.AuthoritativeState!; var zones = final.PlayerZones["alice"];
    if (!rejected) {
        var flow = r.GetProperty("scenario").GetString()!.StartsWith("lightning-rush-flow", StringComparison.Ordinal);
        Check((flow ? zones.Banished : zones.Graveyard).Contains("PARENT") && final.CardObjects["PARENT"].ObjectGeneration == 2 && final.StackItems.Count == 0, "Owner-correct final original card generation and zone.");
        if (branch == "flow-control") Check(zones.MainDeck.Count == 7 && zones.Hand.Count == 0 && final.PlayerZones["bob"].Hand.Count == 1,
            "Original physical owner keeps its untouched deck; new controller actually draws from its own deck.");
        if (branch.Contains("counter", StringComparison.Ordinal)) Check(zones.MainDeck.Count == 7 && zones.Hand.Count == 0,
            "Both original counter destinations are replaced without executing the Flow look.");
    } else {
        var errors = await MatchActionLogReplayer.ValidateRecoveryFrameAsync(actual, new CoreRuleEngine(), default);
        Check(errors.Count > 0, "Actual retained SQL tampering is independently refused again."); totals["actualRefusals"]++;
    }
    if (nativeIndex is not null) foreach (var entry in nativeIndex.RootElement.GetProperty("entries").EnumerateArray().Where(e => e.GetProperty("branch").GetString() == branch)) {
        using var wire = Read(entry.GetProperty("outputCommandPath").GetString()!); var index = entry.GetProperty("commandIndex").GetInt32();
        var originalCommand = original.Commands[index]; var raw = originalCommand.RawCommand!.Value;
        Check(wire.RootElement.GetProperty("cmdType").GetString() == originalCommand.CommandType
            && wire.RootElement.GetProperty("promptId").GetString() == raw.GetProperty("promptId").GetString()
            && wire.RootElement.GetProperty("snapshotTick").GetInt64() == originalCommand.StartedTick, "Actual native packet stamps its original private prompt and tick.");
        var commands = original.Commands.Select((c, i) => i == index ? c with { RawCommand = wire.RootElement.Clone() } : c).ToArray();
        var replay = await MatchActionLogReplayer.VerifyFinalStateAsync(original.ReplayInitialState!, commands, final, new CoreRuleEngine(), default, original.Events);
        Check(replay.IsMatch, "The actual native button packet independently reproduces the complete original accepted history: " + string.Join(";", replay.Errors)); totals["nativeEquivalentReplays"]++;
    }
    totals["rooms"]++; totals["commands"] += count; totals["events"] += original.Events.Count;
    results.Add(new { branch, room, commands = count, events = original.Events.Count, originalOpeningSeed = original.OpeningSeed, deliberateTamperRefused = rejected });
}
Check(totals["commands"] == (expected == 13 ? 90 : 79) && totals["authority"] == totals["commands"]
    && totals["originalPrefixReplays"] == totals["commands"] && totals["actualRefusals"] == 4, "Exact original finite current candidate totals.");
if (nativeIndex is not null) Check(totals["nativeEquivalentReplays"] == nativeIndex.RootElement.GetProperty("entries").GetArrayLength(), "Every original native packet was independently consumed once.");
await File.WriteAllTextAsync(output, JsonSerializer.Serialize(new { status = "PASS_INDEPENDENT_ORIGINAL_LIGHTNING_RUSH_SQL_SEVEN_TABLES_ALL_PREFIXES_AND_ACTUAL_REFUSALS",
    actualReadOnlyConnection = true, actualLoadedFourAssemblies = loaded, totals, rooms = results,
    actualNativeCommandsAreOfflineControlAndReplayEquivalenceNotLiveSubmission = nativeIndex is not null,
    previousFailedCandidatesNotPromoted = true, visiblePairPhysicalWindowsAndWholePrintingRemainOpen = true }, json));
Console.WriteLine("PASS independent original Lightning Rush SQL: " + JsonSerializer.Serialize(totals));

static JsonDocument Read(string path) {
    var raw = File.ReadAllBytes(path); if (path.EndsWith(".gz", StringComparison.Ordinal)) {
        using var input = new GZipStream(new MemoryStream(raw), CompressionMode.Decompress); using var result = new MemoryStream(); input.CopyTo(result); raw = result.ToArray(); }
    return JsonDocument.Parse(raw);
}
static string Hash(byte[] bytes) => Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant();
static bool Same(JsonElement a, JsonElement b) => JsonNode.DeepEquals(JsonNode.Parse(a.GetRawText()), JsonNode.Parse(b.GetRawText()));
static void Check(bool value, string reason) { if (!value) throw new Exception(reason); }
