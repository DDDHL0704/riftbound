from pathlib import Path
import datetime, hashlib, json, os, subprocess, xml.etree.ElementTree as E
root = Path('/Users/dinghaolin/MyProjects/riftbound'); w = Path(__file__).resolve().parent
load = lambda p: json.loads(p.read_text()); sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
native = load(w/'native-actual-sql62-controls-v2/actual-native-control-terminal-v2.json')
sources = native['sourceHashes']; assert all(sha(root/p) == h for p, h in sources.items())
old = load(w/'current-family-control-continuity-security-and-six-original-games-focus-v11/plan.json')
methods = old['shards'][0]['methods']; tokens = sorted({m if '.FullGameEndToEndTests.' in m else m.rsplit('.', 1)[0] for m in methods})
out = w/'final-current-family-source-controls-security-and-six-original-games-focus-v12'; assert not out.exists()
args = ['python3', 'scripts/test-rules.py', 'focus', '--include-games', '--output', str(out)]
for token in tokens: args.extend(['--match', token])
proof = dict(status='RUNNING_FINAL_CURRENT_FAMILY_FOCUS', startedAtUtc=now(), actualCommand=args, sourceHashes=sources, originalSixGames=[m for m in methods if '.FullGameEndToEndTests.' in m])
try:
    with (w/'final-current-family-focus-original-console-v12.log').open('xb') as log:
        process = subprocess.Popen(args, cwd=root, stdout=log, stderr=subprocess.STDOUT)
        power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(process.pid)])
        proof['exitCode'] = process.wait(); power.wait(timeout=10)
    assert proof['exitCode'] == 0
    summary = load(out/'summary.json'); plan = load(out/'plan.json')
    assert summary['status'] == 'PASSED' and summary['total'] == 715 and len(plan['shards'][0]['methods']) == 444 and plan['discoveredMethods'] == 7741
    assert plan['shards'][0]['methods'] == methods
    ns = {'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
    names = [r.get('testName') for r in E.parse(out/'focus/results.trx').findall('.//t:UnitTestResult', ns)]
    new = [n for n in names if '.LightningRush' in n]; assert len(new) == 76
    runtime = root/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0'
    helper = w/'independent-sql-native-source-v1/bin/Release/net10.0/LightningRushIndependentSqlNativeV1.dll'
    measured = json.loads(subprocess.check_output(['/Users/dinghaolin/.dotnet/dotnet', 'exec', '--depsfile', str(runtime/'Riftbound.ConformanceTests.deps.json'),
        '--runtimeconfig', str(runtime/'Riftbound.ConformanceTests.runtimeconfig.json'), str(helper), '--loaded-inputs'], cwd=runtime))
    pub = load(w/'current-rule-sql62-frozen-inputs-v2.json')
    assert measured['actualRuleInputs'] == pub['actualRuleInputs']
    for a in measured['assemblies']:
        assert Path(a['path']) == runtime/(a['name']+'.dll') and a['sha256'] == pub['runtimeFiles'][a['name']+'.dll']
    proof.update(status='PASS_FINAL_CURRENT_FAMILY_715_CASES444_METHODS_76_NEW_CASES_AND_SIX_ORIGINAL_COMPLETE_GAMES', summary=summary,
                 newCaseNames=sorted(new), actualLoadedFourAssemblies=measured, originalExactMethodSelectionRetained=True,
                 trxSha256=sha(out/'focus/results.trx'), actualTestAssemblySha256=sha(runtime/'Riftbound.ConformanceTests.dll'))
    assert proof['actualTestAssemblySha256'] == plan['testAssemblySha256']
except BaseException as error:
    proof.update(status='FAILED_FINAL_CURRENT_FOCUS_ORIGINALS_RETAINED', errorType=type(error).__name__, error=str(error)); raise
finally:
    proof.update(finishedAtUtc=now(), allCurrentSourceHashesStable=all(sha(root/p) == h for p, h in sources.items()),
                 allNativeRuntimeHashesStable=all(sha(root/'clients/godot/.godot/mono/temp/bin/Debug'/p) == h for p, h in native['nativeManagedRuntimeFiles'].items()))
    with (w/'final-current-family-focus-owner-terminal-v12.json').open('x') as f: json.dump(proof, f, ensure_ascii=False, indent=2)
assert proof['allCurrentSourceHashesStable'] and proof['allNativeRuntimeHashesStable']
print(proof['status'], flush=True)
