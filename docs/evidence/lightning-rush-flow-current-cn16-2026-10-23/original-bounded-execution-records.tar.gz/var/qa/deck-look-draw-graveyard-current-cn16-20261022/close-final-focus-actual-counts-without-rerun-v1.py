from pathlib import Path
import datetime, hashlib, json, subprocess, xml.etree.ElementTree as E
root = Path('/Users/dinghaolin/MyProjects/riftbound'); w = Path(__file__).resolve().parent
load = lambda p: json.loads(p.read_text()); sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
owner = load(w/'final-current-family-focus-owner-terminal-v12.json')
summary = load(w/'final-current-family-source-controls-security-and-six-original-games-focus-v12/summary.json')
plan = load(w/'final-current-family-source-controls-security-and-six-original-games-focus-v12/plan.json')
old = load(w/'current-family-control-continuity-security-and-six-original-games-focus-v11/plan.json')
assert owner['exitCode'] == 0 and owner['status'] == 'FAILED_FINAL_CURRENT_FOCUS_ORIGINALS_RETAINED' and owner['errorType'] == 'AssertionError'
assert owner['allCurrentSourceHashesStable'] and owner['allNativeRuntimeHashesStable'] and summary['status'] == 'PASSED'
methods = set(plan['shards'][0]['methods']); before = set(old['shards'][0]['methods'])
extra = {
 'Riftbound.ConformanceTests.SeaMonsterHookGuardTests.SeaMonsterHookMainActionPlayCardPromptExposesNoTargetChoices',
 'Riftbound.ConformanceTests.SeaMonsterHookGuardTests.SeaMonsterHookPlayCardRejectsInvalidInputsWithoutMutation',
 'Riftbound.ConformanceTests.SeaMonsterHookGuardTests.SeaMonsterHookPlayCardStalePromptReplayAfterPermanentConfirmationUsesRejectedCacheWithoutMutation',
 'Riftbound.ConformanceTests.SeaMonsterHookGuardTests.SeaMonsterHookPlayCardWithNoTargetsConfirmsDirectlyToBase'}
assert methods == before | extra and len(methods) == 448 and plan['discoveredMethods'] == 7741
ns = {'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
trx = w/'final-current-family-source-controls-security-and-six-original-games-focus-v12/focus/results.trx'
rows = E.parse(trx).findall('.//t:UnitTestResult', ns); new = [r.get('testName') for r in rows if '.LightningRush' in r.get('testName')]
assert len(rows) == summary['total'] and all(r.get('outcome') == 'Passed' for r in rows) and len(new) == 76
runtime = root/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0'
helper = w/'independent-sql-native-source-v1/bin/Release/net10.0/LightningRushIndependentSqlNativeV1.dll'
measurement = json.loads(subprocess.check_output(['/Users/dinghaolin/.dotnet/dotnet', 'exec', '--depsfile', str(runtime/'Riftbound.ConformanceTests.deps.json'),
    '--runtimeconfig', str(runtime/'Riftbound.ConformanceTests.runtimeconfig.json'), str(helper), '--loaded-inputs'], cwd=runtime))
pub = load(w/'current-rule-sql62-frozen-inputs-v2.json'); assert measurement['actualRuleInputs'] == pub['actualRuleInputs']
for a in measurement['assemblies']: assert Path(a['path']) == runtime/(a['name']+'.dll') and a['sha256'] == pub['runtimeFiles'][a['name']+'.dll']
assert sha(runtime/'Riftbound.ConformanceTests.dll') == plan['testAssemblySha256'] and all(sha(root/p) == h for p,h in owner['sourceHashes'].items())
result = dict(status='PASS_ACTUAL_FINAL_FOCUS_ALL_ORIGINAL_SELECTION_PLUS_FOUR_ADJACENT_METHODS_NO_RERUN',
    atUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(), actualSummary=summary, actualMethods=len(methods),
    allOriginal444SelectedMethodsRetained=True, additionalAdjacentFourMethods=sorted(extra),
    originalOwnerFailure='The test runner returned zero and every case passed. The new owner incorrectly expected the prior444 methods while requesting the entire SeaMonsterHookGuardTests class; this legitimately selected four additional existing methods. The actual original output and failed owner remain unchanged.',
    originalFailedOwnerPath=str(w/'final-current-family-focus-owner-terminal-v12.json'), originalTestRunnerNotRerun=True,
    newCases=76, newMethods=23, newCaseNames=sorted(new), originalSixFullGameMethods=owner['originalSixGames'],
    actualLoadedFourAssemblies=measurement, actualTestAssemblySha256=sha(runtime/'Riftbound.ConformanceTests.dll'), trxSha256=sha(trx),
    all3373SourceHashesStable=True, allNativeRuntimeHashesStable=True, wholeCardOrGoalCertified=False)
with (w/'final-current-family-focus-actual-positive-output-independent-closure-v1.json').open('x') as f: json.dump(result, f, ensure_ascii=False, indent=2)
print(result['status'], summary['total'], len(methods), flush=True)
