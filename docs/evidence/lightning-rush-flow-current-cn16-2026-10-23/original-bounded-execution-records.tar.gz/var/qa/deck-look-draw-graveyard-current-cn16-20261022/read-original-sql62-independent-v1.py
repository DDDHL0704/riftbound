from pathlib import Path
import ast, datetime, fcntl, hashlib, json, os, plistlib, resource, socket, subprocess
resource.setrlimit(resource.RLIMIT_CORE, (0, 0)); os.umask(0o077)
root = Path('/Users/dinghaolin/MyProjects/riftbound'); w = Path(__file__).resolve().parent
load = lambda p: json.loads(p.read_text()); sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
pg = Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin'); cluster = root/'var/qa/permanent-play-here-base-20261017/postgres'
sock = Path('/tmp/rft-here-family-20261018-55486')
tables = ['matches', 'match_players', 'command_log', 'game_events', 'state_snapshots', 'snapshots', 'action_prompts']
read_env = dict(os.environ, PGOPTIONS='-c default_transaction_read_only=on')
source = root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes = [n for n in ast.parse(source.read_text()).body if isinstance(n, ast.FunctionDef) and n.name in {'query', 'rooms', 'digests', 'observe_lock'}]
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(source), 'exec'), globals())
native = w/'native-actual-sql62-controls-v2'; native_terminal = load(native/'actual-native-control-terminal-v2.json')
assert native_terminal['status'].startswith('PASS_') and native_terminal['nativeResult']['commands'] == 51
assert all(native_terminal[k] for k in ['allSourceHashesStable', 'allNativeRuntimeHashesStable', 'allFrozenBackendRuntimeHashesStable', 'helperHashStable'])
helper = w/'independent-sql-native-source-v1/bin/Release/net10.0/LightningRushIndependentSqlNativeV1.dll'
helper_sources = {str(p.relative_to(w)): sha(p) for p in (w/'independent-sql-native-source-v1').rglob('*') if p.is_file()}
cases = [(1, 12, '-'), (2, 13, str(native))]
pubs = {version: load(w/f'current-rule-sql62-frozen-inputs-v{version}.json') for version, _, _ in cases}
guard = (root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a'); fcntl.flock(guard, fcntl.LOCK_EX|fcntl.LOCK_NB)
proof = dict(status='RUNNING_READONLY_INDEPENDENT_BOTH_ORIGINAL_SQL62_CANDIDATES', startedAtUtc=now(), lockAtStart=observe_lock(),
             helperSourceAndBuildHashes=helper_sources, currentSourceHashes=native_terminal['sourceHashes'],
             noApiOrNewGameOrDatabaseCopy=True, previousTwelveNotRelabeledAsFinalThirteen=True)
started = False; power = None; audit = native_rooms = before_audit = before_native = None
try:
    assert subprocess.run([str(pg/'pg_ctl'), '-D', str(cluster), 'status'], capture_output=True).returncode == 3
    with socket.socket() as s: assert s.connect_ex(('127.0.0.1', 15847)) != 0
    for pub in pubs.values():
        assert all(sha(Path(pub['runtimeRoot'])/p) == h for p, h in pub['runtimeFiles'].items())
    power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())])
    sock.mkdir(exist_ok=True)
    subprocess.run([str(pg/'pg_ctl'), '-D', str(cluster), '-l', str(w/'independent-sql62-readonly-postgres-v1.log'), '-o',
                    f'-p 55486 -h 127.0.0.1 -k {sock}', '-w', 'start'], capture_output=True, check=True); started = True
    audit = rooms('riftbound_acceptance'); native_rooms = rooms('riftbound_here_native')
    assert len(audit) == 422 and len(native_rooms) == 99
    before_audit = digests('riftbound_acceptance', audit); before_native = digests('riftbound_here_native', native_rooms)
    proof.update(all422AuditBefore=before_audit, all99NativeBefore=before_native, originalRoomCounts=dict(audit=len(audit), native=len(native_rooms)))
    results = []
    for version, count, native_root in cases:
        pub = pubs[version]; runtime = Path(pub['runtimeRoot'])
        prefix = ['/Users/dinghaolin/.dotnet/dotnet', 'exec', '--depsfile', str(runtime/'Riftbound.PostgresAcceptance.deps.json'),
                  '--runtimeconfig', str(runtime/'Riftbound.PostgresAcceptance.runtimeconfig.json'), str(helper)]
        measurement = json.loads(subprocess.check_output(prefix+['--loaded-inputs'], cwd=runtime))
        assert measurement == pub['actualLoadedFourAssemblies']
        result = w/f'independent-original-sql62-v{version}-result-v1.json'
        args = prefix + ['--verify', str(w/f'real-sql62-v{version}/lightning-rush-flow'), str(result), native_root, str(count)]
        with (w/f'independent-original-sql62-v{version}-console-v1.log').open('xb') as log:
            code = subprocess.run(args, cwd=runtime, env=dict(os.environ, ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit',
                                  DOTNET_DbgEnableMiniDump='0'), stdout=log, stderr=subprocess.STDOUT, timeout=240).returncode
        assert code == 0, (version, code)
        actual = load(result)
        assert actual['status'].startswith('PASS_') and actual['actualReadOnlyConnection']
        assert actual['actualLoadedFourAssemblies'] == measurement and actual['totals']['rooms'] == count
        assert actual['totals']['nativeEquivalentReplays'] == (51 if version == 2 else 0)
        results.append(dict(version=version, actualCommand=args, actualExitCode=code, resultPath=str(result), resultSha256=sha(result),
                            actualRuleInputs=pub['actualRuleInputs'], totals=actual['totals']))
    proof.update(status='PASS_INDEPENDENT_BOTH_ORIGINAL_SQL62_CANDIDATES_AND_51_ACTUAL_NATIVE_REPLAYS', results=results)
except BaseException as error:
    proof.update(status='FAILED_INDEPENDENT_SQL62_READER_ALL_ORIGINALS_RETAINED', errorType=type(error).__name__, error=str(error)); raise
finally:
    if started:
        if before_audit is not None:
            proof.update(all422AuditSevenTablesExact=digests('riftbound_acceptance', audit) == before_audit,
                         all99NativeSevenTablesExact=digests('riftbound_here_native', native_rooms) == before_native,
                         originalAuditRoomListExact=rooms('riftbound_acceptance') == audit, originalNativeRoomListExact=rooms('riftbound_here_native') == native_rooms)
        proof['ownPostgresSmartStopped'] = subprocess.run([str(pg/'pg_ctl'), '-D', str(cluster), '-m', 'smart', '-w', '-t', '20', 'stop'], capture_output=True).returncode == 0
    if power is not None and power.poll() is None: power.terminate(); power.wait(timeout=10)
    proof.update(finishedAtUtc=now(), lockAtEnd=observe_lock(), allCurrentSourceHashesStable=all(sha(root/p) == h for p, h in native_terminal['sourceHashes'].items()),
                 allNativeRuntimeHashesStable=all(sha(root/'clients/godot/.godot/mono/temp/bin/Debug'/p) == h for p, h in native_terminal['nativeManagedRuntimeFiles'].items()),
                 allFrozenRuntimeHashesStable=all(sha(Path(pub['runtimeRoot'])/p) == h for pub in pubs.values() for p, h in pub['runtimeFiles'].items()),
                 allHelperSourceAndBuildHashesStable=all(sha(w/p) == h for p, h in helper_sources.items()))
    with (w/'independent-original-sql62-owner-terminal-v1.json').open('x') as f: json.dump(proof, f, ensure_ascii=False, indent=2)
    fcntl.flock(guard, fcntl.LOCK_UN)
assert all(proof[k] for k in ['all422AuditSevenTablesExact', 'all99NativeSevenTablesExact', 'originalAuditRoomListExact', 'originalNativeRoomListExact',
                            'ownPostgresSmartStopped', 'allCurrentSourceHashesStable', 'allNativeRuntimeHashesStable', 'allFrozenRuntimeHashesStable', 'allHelperSourceAndBuildHashesStable'])
print(proof['status'], [r['totals'] for r in proof['results']], flush=True)
