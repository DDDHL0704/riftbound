from pathlib import Path
import ast,datetime,hashlib,json,os,plistlib,resource,subprocess
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
s=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py';nodes=[n for n in ast.parse(s.read_text()).body if isinstance(n,ast.FunctionDef)and n.name=='observe_lock'];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(s),'exec'),globals())
old=json.loads((w/'native-actual-sql62-controls-v2/actual-native-control-terminal-v2.json').read_text());sources=old['sourceHashes'];native=root/'clients/godot/.godot/mono/temp/bin/Debug';bits=old['nativeManagedRuntimeFiles'];assert all(sha(root/p)==h for p,h in sources.items())and all(sha(native/p)==h for p,h in bits.items())
out=w/'locked-native-own-viewport-probe-v1';out.mkdir();image=out/'actual-focused-trigger-overlay.png';args=['/Users/dinghaolin/.local/share/riftbound-tools/godot-4.7.2/Godot_mono.app/Contents/MacOS/Godot','--path',str(root/'clients/godot'),'res://scenes/debug/FocusedPromptOverlayProof.tscn','--','--riftbound-focused-overlay-proof=trigger','--riftbound-proof-capture='+str(image)]
proof=dict(status='RUNNING_BOUNDED_LOCKED_NATIVE_OWN_VIEWPORT_RENDER_PROBE',startedAtUtc=now(),lockAtStart=observe_lock(),actualCommand=args,headless=False,noOperatingSystemScreenCaptureOrUnlockRequest=True,noSecurityOrPowerSettingChanges=True,staticExistingControlFixtureNotNewGameplayOrVisiblePairCertification=True,sourceHashes=sources,nativeManagedRuntimeFiles=bits);process=None
try:
 with(out/'actual-godot-original-console.log').open('xb')as log:
  process=subprocess.Popen(args,cwd=root,stdout=log,stderr=subprocess.STDOUT)
  proof['ownPid']=process.pid
  try:proof['actualExitCode']=process.wait(timeout=35)
  except subprocess.TimeoutExpired:
   process.terminate()
   try:process.wait(timeout=8)
   except subprocess.TimeoutExpired:process.kill();process.wait(timeout=5)
   proof['timedOutAndOnlyOwnedProcessStopped']=True;raise
 assert proof['actualExitCode']==0 and image.is_file()and image.read_bytes().startswith(b'\x89PNG\r\n\x1a\n')
 proof.update(status='PASS_ACTUAL_NONHEADLESS_NATIVE_OWN_VIEWPORT_IMAGE_WITH_LOCK_OBSERVATIONS',actualOwnViewportImage=dict(path=str(image.relative_to(root)),sha256=sha(image),bytes=image.stat().st_size),actualImageStillNeedsVisualRead=True)
except BaseException as e:
 proof.update(status='FAILED_BOUNDED_NATIVE_OWN_VIEWPORT_RENDER_PROBE_ORIGINAL_RETAINED',errorType=type(e).__name__,error=str(e));raise
finally:
 proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),all3373SourcesStable=all(sha(root/p)==h for p,h in sources.items()),allNativeRuntimeFilesStable=all(sha(native/p)==h for p,h in bits.items()),onlyOwnedGodotProcessStopped=process is None or process.poll()is not None)
 with(out/'actual-owned-viewport-probe-terminal-v1.json').open('x')as f:json.dump(proof,f,indent=2)
assert proof['all3373SourcesStable']and proof['allNativeRuntimeFilesStable']and proof['onlyOwnedGodotProcessStopped']
print(proof['status'],proof['actualOwnViewportImage'],flush=True)
