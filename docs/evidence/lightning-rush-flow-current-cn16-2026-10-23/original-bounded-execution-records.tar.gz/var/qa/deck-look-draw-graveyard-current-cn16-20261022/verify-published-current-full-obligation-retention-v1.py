from pathlib import Path
import collections,gzip,hashlib,json
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;ev=root/'docs/evidence/lightning-rush-flow-current-cn16-2026-10-23';load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
current=load(w/'final-coherent-current-governance-v1.json');previous=load(root/'var/qa/wild-claw-reflexive-current-cn16-20261022/final-coherent-current-governance-v1.json')
assert current['governanceValid']and current['semanticCoverageCertified']is False and not current['errors']
assert current['currentReviewCount']==168 and len(current['remainingObligations'])==17384
old_ids={r['id']for r in previous['remainingObligations']};new_ids={r['id']for r in current['remainingObligations']};assert len(old_ids)==17291 and len(new_ids)==17384 and old_ids<=new_ids
branches=load(ev/'seventy-six-exact-behavior-branches.json')['branches'];gates=load(root/'docs/evidence/global-2026-drawings-source-supplement-2026-10-23/seventeen-new-source-obligations.json')['gates']
expected={'BRANCH:lightning-rush-flow-current-cn16-2026-10-23:'+b['id']for b in branches}|{'GATE:'+g['id']for g in gates};assert len(expected)==93 and new_ids-old_ids==expected
m=load(root/'docs/audit/current-manifest.json');old=json.loads(gzip.decompress((w/'prior-coherent-publication-v1/current-manifest.json.gz').read_bytes()));reviews=load(root/m['inputs']['reviews']['path']);old_reviews=json.loads(gzip.decompress((w/'prior-coherent-publication-v1/review-decisions.json.gz').read_bytes()))
assert len(m['reviewContexts'])==83 and len(reviews['reviews'])==168 and reviews['reviews'][:-1]==old_reviews['reviews']
assert m['acceptanceGates'][:252]==old['acceptanceGates'] and m['acceptanceGates'][252:]==gates and len(m['acceptanceGates'])==269
assert m['laterSourceDeltas']==old['laterSourceDeltas'] and len(m['laterSourceDeltas'])==7 and m['certificationScope']==old['certificationScope']
archived=json.loads(gzip.decompress((ev/'all-original82-complete-contexts.json.gz').read_bytes()));assert archived==old['reviewContexts']
refreshed=json.loads(gzip.decompress((ev/'sixty-nine-input-refreshes-complete-old-contexts.json.gz').read_bytes()));ids={r['id']for r in refreshed};assert len(ids)==69
for r in refreshed:assert r['oldCompleteContext']==old['reviewContexts'][r['id']]
for k,c in old['reviewContexts'].items():
 now=m['reviewContexts'][k];assert now.get('verificationSources')==c.get('verificationSources')and('verificationSources'in now)==('verificationSources'in c)
 if k not in ids:assert now==c
assert sum(k not in ids for k in old['reviewContexts'])==13
cards=load(root/m['inputs']['cards']['path']);old_cards=load(root/old['inputs']['cards']['path']);assert len(cards['records'])==len(old_cards['records'])==1740
assert [r['id']for r in cards['records']]==[r['id']for r in old_cards['records']]
changed=[]
for a,b in zip(old_cards['records'],cards['records']):
 if a!=b:
  assert a['id']=='VEN-156'and a['activeCardNo']is None and b['activeCardNo']=='VEN·156'
  assert {k:v for k,v in a.items()if k!='activeCardNo'}=={k:v for k,v in b.items()if k!='activeCardNo'};changed.append(a['id'])
assert changed==['VEN-156']and m['inputs']['rules']==old['inputs']['rules']and m['inputs']['corpus']==old['inputs']['corpus']
assert current['counts']['combinedExactPrintingNumbers']==1740 and current['counts']['activeCatalogEntries']==1037 and current['counts']['enSourceCountGap']==8
supplement=load(root/'docs/evidence/global-2026-drawings-source-supplement-2026-10-23/source-manifest.json');assert len(supplement['knownEnglishImagePrintings'])==6 and len(supplement['separateUnresolvedSourceGroups'])==17
assert supplement['existingKdaFiveGateIds']==[g['id']for g in old['acceptanceGates']if g['id'].startswith('GLOBAL_KDA_COUTURE_')]
result=dict(status='PASS_ALL17291_OLD_OBLIGATION_IDS_PLUS76_BEHAVIORS_AND17_SEPARATE_SOURCE_GATES_ONLY',oldRemainingObligations=17291,newBehaviorBranches=76,newSourceGates=17,currentRemainingObligations=17384,
 currentReviews=168,currentContexts=83,currentGates=269,existingSevenVersionDeltasExact=True,allOldReviewObjectsAndGatesAndDatesAndScopeExact=True,all82CompleteOldContextsArchived=True,only69CurrentImplementationInputPinsRefreshed=True,other13WholeContextObjectsAndAllOptionalVerificationRefsExact=True,
 original1740CatalogIndexAnd14293RuleIdentitiesNotReplaced=True,sixNewPreciseImagePrintingsAndElevenFurtherGroupsSupplementedNotMergedOrDropped=True,allOriginalCardStatusesAndSourceVersionsAndDatesExact=True,onlyRuntimeBindingVEN156Added=True,
 allNewBehaviorDecisionStatesOpen=True,semanticCoverageCertified=False,newFixedFullAndNativeProductsAndWholeGoalRemainOpen=True,governanceOutputSha256=sha(w/'final-coherent-current-governance-v1.json'))
assert all(b['decision']['state']=='OPEN'and b['wholePrintingCertified']is False for b in branches)
with(w/'final-publication-complete-obligation-and-original-context-retention-v1.json').open('x')as f:json.dump(result,f,indent=2)
print(result['status'],flush=True)
