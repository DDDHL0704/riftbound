from pathlib import Path
import collections, copy, datetime, gzip, hashlib, io, json, subprocess, tarfile, xml.etree.ElementTree as E

root = Path('/Users/dinghaolin/MyProjects/riftbound'); w = Path(__file__).resolve().parent
base = '5edb12e57576358f3ef4a9f9d6da92c313f12437'
identity = 'lightning-rush-flow-current-cn16-2026-10-23'
document = 'docs/LIGHTNING_RUSH_FLOW_CURRENT_CN16_AUDIT_2026-10-23.md'
ev = root/'docs/evidence'/identity; mp = root/'docs/audit/current-manifest.json'
load = lambda p: json.loads(p.read_text()); sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
def pin(p, role=None):
    value = dict(path=p.relative_to(root).as_posix(), sha256=sha(p))
    if role: value['role'] = role
    return value
def write(p, value):
    with p.open('x') as f: json.dump(value, f, ensure_ascii=False, indent=2)

assert subprocess.check_output(['git','rev-parse','HEAD'], cwd=root, text=True).strip() == base
check = load(w/'sole-check-owner-terminal-v1.json')
assert check['status'] == 'PASS_SOLE_COHERENT_LIGHTNING_RUSH_CHECK13633_CASES7600_METHODS'
assert check['exitCode'] == 0 and check['all3373SourceHashesAndModesStable'] and check['allCapturedConformanceAndNativeRuntimeInputsStable']
start = json.loads(gzip.decompress((w/'sole-check-start-inputs-v1.json.gz').read_bytes()))
assert all(sha(root/p) == v['sha256'] and oct((root/p).stat().st_mode & 0o777) == v['mode'] for p,v in start['all3373SourceHashesAndModes'].items())
focus = load(w/'final-current-family-focus-actual-positive-output-independent-closure-v1.json')
assert focus['actualSummary']['total'] == 723 and focus['actualMethods'] == 448 and focus['newCases'] == 76
prep = load(w/'seventy-six-exact-executed-branches-and-current-source-preparation-v1.json')
assert len(prep['cases']) == 76 and len(prep['newMethods']) == 23 and len(prep['sourceRuleRecordIds']) == 128 and not prep['primaryTextUnmatched']
sql = load(w/'independent-original-sql62-v2-result-v1.json')
assert sql['totals'] == dict(rooms=13,commands=90,events=171,authority=90,snapshots=167,prompts=167,originalPrefixReplays=90,nativeEquivalentReplays=51,actualRefusals=4)
sql_old = load(w/'independent-original-sql62-v1-result-v1.json')
assert sql_old['totals'] == dict(rooms=12,commands=79,events=149,authority=79,snapshots=146,prompts=146,originalPrefixReplays=79,nativeEquivalentReplays=0,actualRefusals=4)
sql_owner = load(w/'real-sql62-owner-terminal-v2.json'); independent = load(w/'independent-original-sql62-owner-terminal-v1.json')
assert sql_owner['originalAcceptedInputs'] == sql_owner['actualColdRecoveries'] == 90 and sql_owner['actualRealDbRefusals'] == 4
assert all(independent[k] for k in ['all422AuditSevenTablesExact','all99NativeSevenTablesExact','originalAuditRoomListExact','originalNativeRoomListExact','ownPostgresSmartStopped','allCurrentSourceHashesStable','allNativeRuntimeHashesStable','allFrozenRuntimeHashesStable','allHelperSourceAndBuildHashesStable'])
assert sql_owner['actualRuleInputs'] == focus['actualLoadedFourAssemblies']['actualRuleInputs'] == sql['actualLoadedFourAssemblies']['actualRuleInputs']
controls = load(w/'native-actual-sql62-controls-v2/actual-native-control-terminal-v2.json')
assert controls['nativeResult'] == dict(commands=51,playComposers=17,actualBackendPrices=18,actualFlowOriginLabels=9,offlineControlAndReplayEquivalenceOnly=True,visiblePairAndPhysicalWindowsRemainOpen=True)
assert controls['actualExitCode'] == 0 and controls['allSourceHashesStable'] and controls['allNativeRuntimeHashesStable']
tools = load(w/'all-existing-python-tool-tests-terminal-v1.json'); assert tools['exitCode'] == 0 and tools['actualTests'] == 74
old_sql = json.loads(subprocess.check_output(['git','show',base+':tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'], cwd=root))
new_sql = load(root/'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json')
assert new_sql['cases'][:61] == old_sql['cases'] and new_sql['cases'][61:] == [dict(id='lightning-rush-flow',sourceType='LightningRushFlowSqlAcceptance')]
source_round = root/'var/qa/current-cn-source-readback-20261023'
cn = load(source_round/'current-complete-cn-full-row-and-qa-readback-v1.json')
assert cn['actualRows'] == cn['uniqueApiIds'] == 1504 and cn['allFullRowsAndQaValuesNullsExactlyRegistered'] and not cn['changedApiIds'] and not cn['addedApiIds'] and not cn['missingRegisteredApiIds']
versions = load(source_round/'current-cn-rule-directory-and-known-source-versions-v1.json')
assert versions['unchangedKnownDocuments'] == 16 and versions['conditionalNotModifiedResponses'] == 1
catalog_path = root/'data/official/card-catalog.zh-CN.json'; catalog = load(catalog_path)
before_catalog = json.loads(subprocess.check_output(['git','show',base+':data/official/card-catalog.zh-CN.json'], cwd=root))
assert len(catalog['cards']) == 1037 and len(before_catalog['cards']) == 1036
assert catalog['cards'][:-1] == before_catalog['cards'] and catalog['cards'][-1] == cn['currentExactNextFlow37859FullRow']
assert catalog['scopedAdditions'][:-1] == before_catalog['scopedAdditions']
assert all(catalog[k] == v for k,v in before_catalog.items() if k not in {'cards','total','scopedAdditions'})
current_row_hash = hashlib.sha256(json.dumps(catalog['cards'][-1],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert current_row_hash == '049508b53db67fd69036060253f077cb20151df98792c9df91fc91260636ff42'
n = root/'var/qa/fixed5edb1-early-native-20261023'
prior_full = load(n/'ci5edb1-entire-full-independent-verification-v1.json')
assert prior_full['fixedCommit'] == base and prior_full['runId'] == 39810044243 and len(prior_full['jobs']) == 11 and set(prior_full['jobs'].values()) == {'success'}
assert (prior_full['actualCases'],prior_full['actualMethods'],prior_full['sql']['caseCount']) == (13706,7718,61)
prior_main = load(n/'bounded-current-default-main-normal-score-network-wild-and-original-replay-summary-v1.json')
assert prior_main['fixedCommit'] == base and prior_main['status'].startswith('PASS_') and prior_main['ownedApiAndPostgresStopped']
m = load(mp); old = copy.deepcopy(m); rp = root/m['inputs']['reviews']['path']; reviews = load(rp); old_reviews = copy.deepcopy(reviews)
binding = load(w/'current82-existing-context-input-pin-change-before-publication-v1.json')
assert sha(mp) == binding['manifestSha256'] and (len(reviews['reviews']),len(m['reviewContexts']),len(m['acceptanceGates']),len(m['laterSourceDeltas'])) == (167,82,252,7)
assert json.loads(gzip.decompress((w/'all-original82-contexts-before-lightning-rush-refresh-v1.json.gz').read_bytes())) == m['reviewContexts']
assert not ev.exists(); ev.mkdir()
prior = w/'prior-coherent-publication-v1'; prior.mkdir()
for p in [mp,rp,root/'docs/PROJECT_STATUS.md']:
    (prior/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
retention = dict(atUtc=now(),status='PASS_ORIGINAL_TESTS_SOURCE_CHECK_SQL_NATIVE_RETENTION',baseCommit=base,
    actualCheckCases=13633,actualCheckMethods=7600,actualCheckOutcomes={'Passed':13633},allPrior13557CheckCaseNames7577MethodsRetainedPlus76Cases23MethodsOnly=True,
    all3373SourceHashesAndModesAndConformanceNativeRuntimeHashesStable=True,all1811OriginalConformanceFilesAccounted=True,allOther1806OriginalFilesByteExact=True,
    onlyFiveOriginalFilesScopedCalibrations=start['onlyFiveOriginalFilesScopedRegistrationMetadataAndSourceIdentityCalibration'],
    allChangedOriginalFileMethodDeclarationsTheoryAttributesAndAssertCountsRetained=True,allNineFullGameSourceHashes=start['allNineFullGameSourceHashes'],
    all143OriginalFullMethods151Cases110Pairs11DecksSeed424242AndVictoryReplayAssertionsRetained=True,
    finalFocusedCases=723,finalFocusedMethods=448,newCases=76,newMethods=23,affectedOriginalFullGameMethods=focus['originalSixFullGameMethods'],
    finalFocusOriginalOwnerWrongExpected444CountRetainedActual448MethodsAllPassedNoRerun=True,
    everyUnsupportedAndIntermediateFailureAndExecutedOwnBitsRetained=True,originalNativeProbePrimaryButtonLookupFailureRetained=True,
    allOriginal61SqlCaseObjectsAndOrderExact=True,currentSqlCases=62,independentFinalSql=sql['totals'],independentEarlierSql=sql_old['totals'],
    actualNative51Controls17Composers18BackendQuotes9FlowCues=True,actualNativePacketsIndependentlyReplayFullOriginalHistories=True,
    offlineControlsAndReplayEquivalenceNotLiveOrVisibleAcceptance=True,noAcceptedHistoryOrPrivateSeedRewrite=True,noOldDevelopmentGameMigration=True,
    preceding5edbAll11ActualFull13706Cases7718Methods61SqlIndependent=True,preceding5edbHeadlessMainNormalScoreNetworkAndWildEvidenceSeparate=True,
    precedingN46SoleCheck13556PassOnePinFailureNotRelabeled=True,expectedNextFixedFullCases=13782,expectedNextFixedFullMethods=7741,wholePrintingOrGoalCertified=False)
write(w/'final-original-tests-source-check-sql-and-native-retention-v1.json',retention)
copies = {
 'final-original-tests-source-check-sql-and-native-retention.json':w/'final-original-tests-source-check-sql-and-native-retention-v1.json',
 'sole-check-owner-terminal.json':w/'sole-check-owner-terminal-v1.json','sole-check-inputs.json.gz':w/'sole-check-start-inputs-v1.json.gz',
 'final723-focus-independent-actual-output-closure.json':w/'final-current-family-focus-actual-positive-output-independent-closure-v1.json',
 'exact76-branch-preparation.json':w/'seventy-six-exact-executed-branches-and-current-source-preparation-v1.json',
 'current128-existing-primary-rule-ids-and-flow829-preparation.json':w/'current23-complete-source-preparation-existing-rule-ids-flow829-control-and-private-choice-v1.json',
 'current-source-date-region-and-distinct-global-printing-preparation.json':w/'current23-source-preparation-current-flow829-page127-and-distinct-printing-v1.json',
 'current16-rule-source-versions.json':source_round/'current-cn-rule-directory-and-known-source-versions-v1.json',
 'current1504-full-row-qa-versions.json':source_round/'current-complete-cn-full-row-and-qa-readback-v1.json',
 'actual-card-face-and-general-flow-faq2-visual.json':w/'actual-card-face-and-current-general-flow-faq-page2-visual-disposition-v1.json',
 'actual-core108124355-physical-pages-visual.json':w/'current-core108124355-shared-control-physical-pages-actual-visual-disposition-v1.json',
 'current-finite70-runtime-presence55-outside15.json':w/'current-finite70-runtime-presence-and-open-consumers-v1.json',
 'current-finite15-flow-one-runtime-fourteen-open.json':w/'current-finite15-flow-presence-one-bounded-consumer-fourteen-open-v1.json',
 'all-original74-python-tool-tests-terminal.json':w/'all-existing-python-tool-tests-terminal-v1.json',
 'final13-real-sql-room-writer.json':w/'real-sql62-owner-terminal-v2.json',
 'independent-final90-inputs171-events167-views51-native4-refusals.json':w/'independent-original-sql62-v2-result-v1.json',
 'independent-earlier12-rooms79-inputs-bound-to-earlier-candidate.json':w/'independent-original-sql62-v1-result-v1.json',
 'independent-both25-rooms169-original-inputs-owner.json':w/'independent-original-sql62-owner-terminal-v1.json',
 'actual51-native-controls17-composers18-real-prices.json':w/'native-actual-sql62-controls-v2/actual-native-control-terminal-v2.json',
 'earlier-completed-runtime-retirement-exact-aliases-and-unique-archive.json':w/'retire-only-completed-earlier-sql62-runtime-v1.json',
 'locked-native-own-viewport-static-and-ci-pair-visual-disposition.json':w/'locked-native-gpu-own-viewport-static-and-actual-ci-pair-visual-disposition-v1.json',
 'locked-fixed5edb-actual-ci-pair-own-viewport-terminal.json':w/'locked-fixed5edb-ci-pair-original-final-viewports-v1/actual-locked-fixed-ci-pair-own-viewports-terminal-v1.json',
 'locked-fixed5edb-native-a-final-victory.png':w/'locked-fixed5edb-ci-pair-original-final-viewports-v1/actual-native-a-original-final.png',
 'locked-fixed5edb-native-b-final-defeat.png':w/'locked-fixed5edb-ci-pair-original-final-viewports-v1/actual-native-b-original-final-result.png',
 'all-original82-complete-contexts.json.gz':w/'all-original82-contexts-before-lightning-rush-refresh-v1.json.gz',
 'preceding-fixed5edb-complete-full.json':n/'ci5edb1-entire-full-independent-verification-v1.json',
 'preceding-fixed5edb-nine-original-artifacts-receipt.json':n/'ci5edb1-all-nine-original-artifacts-receipt-v1.json',
 'preceding-fixed5edb-bounded-main-score-network-wild-replay.json':n/'bounded-current-default-main-normal-score-network-wild-and-original-replay-summary-v1.json'}
for name,p in copies.items(): (ev/name).write_bytes(p.read_bytes())
paths = {p for p in w.rglob('*') if p.is_file()}
runtime_roots = [w/'current-rule-sql62-runtime-v1',w/'current-rule-sql62-runtime-v2']
def generated(p):
    return any(p.is_relative_to(r) for r in runtime_roots) or any(x in {'bin','obj','__pycache__','.godot'} or x.endswith('.app') for x in p.parts)
secrets = set()
def collect(value):
    if isinstance(value,dict):
        for k,v in value.items():
            if k.lower() in {'playerkey','reconnecttoken','accesstoken','authorization'} and isinstance(v,str) and len(v)>=16: secrets.add(v.encode())
            else: collect(v)
    elif isinstance(value,list):
        for v in value: collect(v)
for p in paths:
    if generated(p): continue
    if p.name.endswith(('.json','.json.gz','.ndjson','.ndjson.gz','.jsonl.gz')):
        try:
            raw=p.read_bytes();raw=gzip.decompress(raw) if p.suffix=='.gz' else raw
            if '.ndjson' in p.name or '.jsonl' in p.name:
                for line in raw.decode().splitlines():
                    if line.strip(): collect(json.loads(line))
            else: collect(json.loads(raw))
        except (OSError,ValueError,UnicodeDecodeError): pass
canonical={sha(ev/name):dict(externalEvidencePath=pin(ev/name)['path']) for name in copies}; rows=[];members={};excluded=[]
for p in sorted(paths):
    name=p.relative_to(root).as_posix();raw=p.read_bytes();inspect=raw;reason=None
    if p.suffix=='.gz':
        try:inspect=gzip.decompress(raw)
        except OSError:pass
    if generated(p):reason='GENERATED_FROZEN_RUNTIME_OR_HELPER_BUILD_NOT_DUPLICATED'
    elif p.suffix in {'.zip','.png','.pdf'}:reason='ORIGINAL_OFFICIAL_RENDER_OR_RUNTIME_ARCHIVE_HASH_PIN_ONLY_NO_DUPLICATE_BINARY'
    elif p.suffix=='.env' or any('profile' in x.lower() for x in p.parts) or p.name.startswith('session-'):reason='PRIVATE_QA_SESSION_LOCAL_ONLY'
    if any(s in inspect for s in secrets):reason='PRIVATE_AUTH_VALUES_LOCAL_ONLY'
    digest=hashlib.sha256(raw).hexdigest()
    if reason:excluded.append(dict(path=name,bytes=len(raw),sha256=digest,reason=reason));continue
    target=canonical.get(digest)
    if target is None:target=dict(archiveMember=name);canonical[digest]=target;members[name]=p
    rows.append(dict(path=name,bytes=len(raw),sha256=digest,**target))
archive=ev/'original-bounded-execution-records.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as t:
    for name,p in sorted(members.items()):
        raw=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(raw);info.mode=p.stat().st_mode&0o777;info.mtime=0;t.addfile(info,io.BytesIO(raw))
with tarfile.open(archive,'r:gz') as t:
    assert set(t.getnames())==set(members)
    for row in rows:
        raw=t.extractfile(row['archiveMember']).read() if 'archiveMember'in row else (root/row['externalEvidencePath']).read_bytes()
        assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
write(ev/'archive-map.json',dict(atUtc=now(),archive=pin(archive),originalPathsWithExactCanonicalPayload=rows,localOnlyExclusions=excluded,
    allMemberBytesHashesClosedSetVerified=True,equalPayloadsStoredOnlyOnceIncludingReadableEvidenceFiles=True,
    originalFailedOwnBitArchivesRetainedByteExact=True,noAppInstallerSdkFrozenRuntimeAuthProfileOrPdfRenderCopies=True))
changed_source_paths=set(subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines())
implementation_paths=[p for p in start['all3373SourceHashesAndModes'] if p.startswith('src/') and (p.endswith('CoreRuleEngine.Flow.cs') or p.endswith('MatchSession.LightningRushScenario.cs') or p in changed_source_paths)]
implementation_paths.append('data/official/card-catalog.zh-CN.json')
verification_paths=['tests/Riftbound.ConformanceTests/'+p for p in ['LightningRushDeckDrawFlowTests.cs','LightningRushDeckBoundaryTests.cs','LightningRushFlowPaymentTests.cs','LightningRushFlowRecoveryTests.cs','LightningRushOtherPermissionTests.cs','LightningRushScenarioTests.cs','LightningRushSourceIdentityTests.cs','Fixtures/lightning-rush-source.json','CardCatalogBaselineTests.cs','VendettaAmbushTests.cs','AhriCombatMightTests.cs','WildClawSourceIdentityTests.cs','Cn16RuleInputSelectionTests.cs']]
verification_paths+=['tests/Riftbound.PostgresAcceptance/'+p for p in ['LightningRushFlowSqlAcceptance.cs','Program.cs','SqlAcceptanceCases.json']]
verification_paths+=['scripts/tests/test_sql_ci_gate.py','clients/godot/scripts/debug/LightningRushInteractionProof.cs','clients/godot/scenes/debug/LightningRushInteractionProof.tscn']
source_manifest=dict(schemaVersion=1,id=identity,atUtc=now(),region='CN',language='zh-CN',applicableAsOf='2026-10-23',adoptedCoreEffectiveDate='2026-10-16',baseCommit=base,
    issue='https://github.com/DDDHL0704/riftbound/issues/93',
    scope='CN API37859 VEN-156 only: private top3 optional actual draw, unchosen cards directly to graveyard, resource-only Flow2+ANY1 from own graveyard with ordinary timing, confirmed chain-exit replacement, independent recovery and original logs. Four bounded private deck-choice control transfers retain casting declaration and physical generation. Whole printings, other14 Flow consumers and all unclosed sources remain open.',
    exactPrintings=['VEN-156'],exactSourceApiId=37859,runtimeCardNo='VEN·156',printedFace='VEN·156/166 SC',separateGlobalPrintingNotReviewed='VEN-156/166',
    exactCurrentApiRowCanonicalSha256=current_row_hash,rowHashEncoding='JSON_SORT_KEYS_COMPACT_SEPARATORS_UTF8_ENSURE_ASCII_FALSE',currentRawRowAcquiredAtUtc=cn['atUtc'],exactPerPrintingPublicationDate=None,exactPerPrintingEffectiveDate=None,exactCardQaValue=None,
    sourceRuleRecords=prep['sourceRuleRecordIds'],exactCurrentPrimaryRuleTextSha256=prep['sourceRuleTextsSha256'],currentCoreSha256=prep['coreSha256'],
    coreUrl='https://cdn.playloltcg.com/lol/2026/10/2026-10-10/a21ead876c6b44d6abe386b6ae54ea28.pdf',coreSourceUpdatedDate='2026-10-10',
    cardFaceUrl='https://cdn.playloltcg.com/lol/card/20260709/dd4789796ed94e549485963bcd9af6cb.png',cardFaceSha256='916e66e07ff9a6badbb0b2bbd6a0fa1391a0d0f1aee905c433a51ee501fa4855',
    currentCompleteCn1504FullRowsAndQaUnchanged=True,all16KnownDocumentsRetained=True,faqPhysicalPages1_2_3_4OnlyBoundedRead=True,
    generalFlowFaqPage2NotSpecificVen156Qa=True,individualDatesNotInferredFromUrlSetReleaseAcquisitionOrHttpDate=True,
    oldRuntimeCatalogRawSha256=hashlib.sha256(subprocess.check_output(['git','show',base+':data/official/card-catalog.zh-CN.json'],cwd=root)).hexdigest(),newRuntimeCatalogRawSha256=sha(catalog_path),
    onlyOnePreviouslyKnownSourcePrintingAddedToRuntime=True,newSourceVersionDeltaClaimed=False,
    implementation=[pin(root/p,'implementation') for p in sorted(set(implementation_paths))],verificationSources=[pin(root/p,'verification-source') for p in verification_paths],
    actualDebugAndSqlRuleInputs=sql_owner['actualRuleInputs'],soleCheckCases=13633,soleCheckMethods=7600,soleCheckOutcomes={'Passed':13633},
    finalFocusedCases=723,finalFocusedMethods=448,newCases=76,newMethods=23,affectedOriginalFullGameMethods=focus['originalSixFullGameMethods'],
    actualIndependentFinalSql=sql['totals'],earlierTwelveRoomsBoundToEarlierInputs=sql_old['totals'],actualHeadlessProductionControls=51,actualPlayComposers=17,actualBackendPrices=18,actualFlowOriginCues=9,
    nativePacketsIndependentlyReplayEntireOriginalHistoriesNotLiveSubmission=True,nativeAssemblyEmptyLoadedLocationRetainedMvidMatchesDiskCandidateNotClaimedDirectMemorySha=True,
    nextFixedFullExpectedCases=13782,nextFixedFullExpectedMethods=7741,sqlManifestCases=62,
    wholeScopeRetained=dict(printings=1740,ruleRecords=14293,activeCatalog=1037,outsideActive=703,cnRows=1504,enGap=8,cnNews=139,kdaExactPrintingGates=5),
    originalFinite70DeckConsumersRetainedRuntime55Outside15NotCertification=True,finite15FlowConsumersOnlyOneBoundedOther14Open=True,
    expectedRemainingObligations=17384,separateNewGlobalDrawingsSourceGroups=17,sixSupplementalPreciseEnglishImagePrintings=6,elevenFurtherIdentityOrTreatmentGroupsOpen=True,separateNewGlobalSourceManifest=pin(root/'docs/evidence/global-2026-drawings-source-supplement-2026-10-23/source-manifest.json','source-manifest'),preceding5edbActualAll11Full13706_7718_61ClosedSeparately=True,
    separateLockedGpuOwnViewportEvidence=pin(ev/'locked-native-own-viewport-static-and-ci-pair-visual-disposition.json'),lockedOwnViewportImagesAreOldFixed5edbNotNewFlowCandidate=True,old66InputFinalRoomOnlyConnectionMetadataChangedNotGameHistory=True,
    precedingMainReceiptOpenFullFieldIsItsEarlierHistoricalObservationLaterFullReceiptClosesOnlyItsExactCommit=True,
    newFixedFullCurrentNativePairScoreReplayVisibleAndPhysicalWindows='OPEN',semanticCoverageCertified=False,archive=pin(archive),archiveMap=pin(ev/'archive-map.json'))
write(ev/'source-manifest.json',source_manifest);sp=pin(ev/'source-manifest.json','source-manifest')
branches=[]
for c in prep['cases']:
    branches.append(dict(id=c['id'],sourceRefs=c['exactPrintingSubjects']+c['existingCanonicalRuleIds'],sourceManifest=sp,state='RECORDED',
      boundedCase={'actualExecutedCase':c['actualExecutedCase'],'method':c['method'],'issue':'https://github.com/DDDHL0704/riftbound/issues/93'},
      semanticReview={'state':'BOUNDED_CURRENT_CN_PRIVATE_DRAW_DIRECT_GRAVE_RESOURCE_FLOW_AND_FOUR_CONTROL_TRANSFERS'},
      implementation={'state':'FINITE_SHARED_FLOW_COST_SOURCE_EXIT_RECEIPT_PRIVATE_CHOICE_AND_STACK_CONTINUITY_NO_DSL_OR_MIGRATION'},
      testExecution={'state':'ACTUAL76_NEW23_METHODS_FOCUS723_448_CHECK13633_7600_SIX_ORIGINAL_FULL_GAMES_SQL90_COLD90_NATIVE51_INDEPENDENT_ALL_ORIGINAL_PREFIXES'},
      fixedCommitCi={'state':'PENDING_NEW_FIXED_FULL'},productAcceptance={'state':'OPEN_NEW_FIXED_MAIN_PAIR_NETWORK_NORMAL_SCORE_REPLAY_VISIBLE_AND_PHYSICAL_WINDOWS'},
      decision={'state':'OPEN','reason':'Only bounded source, unit, real database and offline native control/replay evidence. New fixed full and required products remain independent.'},
      wholePrintingCertified=False,existingAcceptanceGateDependencies=['FIXED_CURRENT_CANDIDATE_FULL','VISIBLE_PAIRED_SQL_NETWORK_SCORE_REPLAY','USER_WINDOWS_RUNTIME']))
write(ev/'seventy-six-exact-behavior-branches.json',dict(branches=branches))
refreshed=[];allowed=set(implementation_paths)
for name,c in m['reviewContexts'].items():
    changes=[]
    for ref in c['implementation']:
        actual=sha(root/ref['path'])
        if actual!=ref['sha256']:assert ref['path']in allowed;changes.append(dict(path=ref['path'],before=ref['sha256'],after=actual));ref['sha256']=actual
    if changes:
        refreshed.append(dict(id=name,changes=changes,oldCompleteContext=old['reviewContexts'][name]))
        c.update(currentImplementationCommit=base,currentImplementationIncludesUncommittedChanges=True,ciState='PENDING',currentLightningRushFlowInputRefresh=dict(sourceManifest=sp,onlyCurrentInputPinRefreshNotNewWholeSemanticCertification=True,allOldEvidenceAndOptionalVerificationReferencesRetained=True,newFixedFullAndProducts='OPEN'))
assert len(refreshed)==69 and {x['id'] for x in refreshed}=={x['id'] for x in binding['changes']}
for name,c in m['reviewContexts'].items():
    assert c.get('verificationSources')==old['reviewContexts'][name].get('verificationSources') and ('verificationSources'in c)==('verificationSources'in old['reviewContexts'][name])
    if name not in {x['id']for x in refreshed}:assert c==old['reviewContexts'][name]
(ev/'sixty-nine-input-refreshes-complete-old-contexts.json.gz').write_bytes(gzip.compress(json.dumps(refreshed,ensure_ascii=False,indent=2).encode(),mtime=0))
m['reviewContexts'][identity]=dict(evidenceCommit=base,currentImplementationCommit=base,currentImplementationIncludesUncommittedChanges=True,ciState='PENDING',ciReceipts=[],region='CN',language='zh-CN',applicableAsOf='2026-10-23',adoptedCoreEffectiveDate='2026-10-16',sourceManifest=sp,implementation=source_manifest['implementation'],verificationSources=source_manifest['verificationSources'],branches=branches,evidence=[pin(ev/'final-original-tests-source-check-sql-and-native-retention.json','focus-check-and-retention'),pin(ev/'independent-final90-inputs171-events167-views51-native4-refusals.json','independent-original-sql-and-native-equivalence'),pin(ev/'actual51-native-controls17-composers18-real-prices.json','headless-production-controls-not-visible')])
reviews['reviews'].append(dict(id=identity,scope=source_manifest['scope'],subjects=['VEN-156'],ruleRecords=prep['sourceRuleRecordIds'],status='BOUNDED_CN_FLOW_PRIVATE_DRAW_DIRECT_GRAVE_AND_SHARED_CONTROL_PASS_NEW_FIXED_FULL_AND_PRODUCTS_OPEN',sourceManifest=sp,auditDocument=document,
    validation=dict(newCases=76,newMethods=23,soleCheckCases=13633,soleCheckMethods=7600,focusedCases=723,focusedMethods=448,originalFullGameMethods=6,independentSql=sql['totals'],wholeCardCertification=False),
    exclusions=['Separate GLOBAL VEN-156/166 not certified','All other14 Flow consumers, multi/nonresource costs and self-instruction exits require their own review','Whole CN printing, all source gaps and final effective changes remain open','New fixed full and actual current default Main paired network normal score replay remain separate from offline controls','Visible paired windows and physical Windows remain open','All original red executions, fixture preparation failures and owner/probe errors retained','No old development-game migration or accepted-history rewrite']))
supplement_dir=root/'docs/evidence/global-2026-drawings-source-supplement-2026-10-23'
supplement=load(supplement_dir/'source-manifest.json');supplement_gates=load(supplement_dir/'seventeen-new-source-obligations.json')
assert supplement['sourceGroupCount']==17 and supplement['sixClearlyObservedImagePrintingsCount']==6 and supplement['remainingIdentityOrTreatmentGroups']==11
assert len(supplement_gates['gates'])==17 and supplement['currentCoreAndTournamentPdfBytesExact'] and supplement['globalRulesHubFullBodyExact'] and supplement['existingKdaFaqTenCompleteOriginalSurfacesByteExact']
assert not({g['id']for g in supplement_gates['gates']}&{g['id']for g in m['acceptanceGates']})
m['acceptanceGates']+=supplement_gates['gates']
m['currentGlobal2026DrawingsSourceSupplement']=dict(sourceManifest=pin(supplement_dir/'source-manifest.json','source-manifest'),newSourceGapGateIds=[g['id']for g in supplement_gates['gates']],sixNewExactEnglishImagePrintings=[r['observedPrintedIdentity']for r in supplement['knownEnglishImagePrintings']],elevenOtherIdentityOrTreatmentGroupsRemainOpen=True,allOriginal1740CatalogIndexAnd14293RulesEightEnglishGapAnd139CnNewsRetained=True,oldKdaFiveGatesUnchanged=True,separateFromSevenKnownRuleOrCatalogVersionDeltas=True,noGameplayRuntimeAdoption=True)
assert reviews['reviews'][:-1]==old_reviews['reviews'] and m['acceptanceGates'][:len(old['acceptanceGates'])]==old['acceptanceGates'] and len(m['acceptanceGates'])==269 and m['laterSourceDeltas']==old['laterSourceDeltas'] and m['certificationScope']==old['certificationScope']
rp.write_text(json.dumps(reviews,ensure_ascii=False,indent=2)+'\n');m['inputs']['reviews']['sha256']=sha(rp)
old_ledger=load(root/old['inputs']['cards']['path']);ledger=copy.deepcopy(old_ledger);row=next(r for r in ledger['records']if r['id']=='VEN-156');assert row['activeCardNo']is None;row['activeCardNo']='VEN·156'
assert all(a==b for a,b in zip(ledger['records'],old_ledger['records'])if a['id']!='VEN-156')
assert {k:v for k,v in row.items()if k!='activeCardNo'}=={k:v for k,v in next(r for r in old_ledger['records']if r['id']=='VEN-156').items()if k!='activeCardNo'}
update=dict(recordedAtUtc=now(),sourceDateAndSourceUniverseUnchanged=True,newExactRuntimeRegistration='VEN·156',exactCnApiId=37859,individualPublicationAndEffectiveDates=None,newReviewCertifications=0,priorRuntimeRows=1036,currentRuntimeRows=1037,allExisting1740PrintingIdsAndSourceVersionsAndConfirmationDatesRetained=True,sourceManifest=sp)
ledger.update(previousLightningRushRuntimeBindingLedger=old['inputs']['cards'],priorRuntimeBindingUpdateBeforeLightningRush=old_ledger['runtimeBindingUpdate'],runtimeBindingUpdate=update)
write(ev/'all-card-ledger.json',ledger);m['inputs']['cards']=pin(ev/'all-card-ledger.json','current-card-ledger')
summary=load(root/old['inputs']['summary']['path']);old_summary=copy.deepcopy(summary);summary.update(activeCatalogEntries=1037,outsideActiveCatalog=703,previousLightningRushRuntimeBindingSummary=old['inputs']['summary'],priorRuntimeBindingUpdateBeforeLightningRush=old_summary['runtimeBindingUpdate'],runtimeBindingUpdate=update)
write(ev/'index-summary.json',summary);m['inputs']['summary']=pin(ev/'index-summary.json','current-card-summary');m['inputs']['active']['sha256']=sha(catalog_path)
coverage=load(root/old['cardCoverageManifest']['path']);old_coverage=copy.deepcopy(coverage);coverage['counts'].update(activeCatalogEntries=1037,outsideActiveCatalog=703)
coverage.update(previousLightningRushRuntimeBindingCoverage=old['cardCoverageManifest'],priorRuntimeBindingUpdateBeforeLightningRush=old_coverage['runtimeBindingUpdate'],runtimeBindingUpdate=update,currentCardLedger=m['inputs']['cards'],activeRuntimeCatalog=m['inputs']['active'],previousCurrentScopedReviewDecisionsBeforeLightningRush=old_coverage['currentScopedReviewDecisions'],currentScopedReviewDecisions=m['inputs']['reviews'],currentLightningRushScopedSourceManifest=sp)
assert coverage['scopedReviewDecisions']==old_coverage['scopedReviewDecisions']
for k in ('date','snapshotDate','confirmedAt','confirmedAtUtc','applicability','supplementalUnmatchedPrintingCandidates'):assert coverage.get(k)==old_coverage.get(k) and (k in coverage)==(k in old_coverage)
write(ev/'source-coverage.json',coverage);m['cardCoverageManifest']=pin(ev/'source-coverage.json','current-card-coverage')
m['currentLightningRushFlowInputChange']=dict(sourceManifest=sp,auditDocument=document,issue='https://github.com/DDDHL0704/riftbound/issues/93',onlyNewBoundedBranches=76,all167OldReviews82ContextIdentities252GatesSevenDeltasRetained=True,all82CompleteOldContextsArchived69InputRefreshes13WholeObjectsExact=True,allOldOptionalVerificationSourcePresenceAndValuesExact=True,onlyOnePreviouslyKnownCnRuntimePrintingAdded=True,original17291RemainingIdsMustRemain=True,expectedRemainingObligations=17384,newFixedFullAndProducts='OPEN',wholePrintingOrGoalComplete=False)
m['precedingFixed5edb1ActualCompleteFullCiReadback']=pin(ev/'preceding-fixed5edb-complete-full.json')
m['precedingFixed5edb1BoundedMainScoreNetworkWildAndOriginalReplay']=pin(ev/'preceding-fixed5edb-bounded-main-score-network-wild-replay.json')
assert (len(reviews['reviews']),len(m['reviewContexts']),len(m['acceptanceGates']),len(m['laterSourceDeltas']))==(168,83,269,7)
mp.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
write(ev/'publication-original-governance-retention.json',dict(atUtc=now(),oldReviews=167,oldContexts=82,oldGates=252,oldDeltas=7,oldRemainingIds=17291,newBehaviorBranches=76,newSeparateGlobalSourceGates=17,currentGates=269,expectedRemainingObligations=17384,completeOldContextsArchived=82,explicitCurrentInputRefreshedContexts=69,otherWholeContextObjectsExact=13,allOriginalReviewObjectsGatesDeltasCertificationScopeOptionalVerificationReferencesAndSourceDatesRetained=True,semanticCoverageCertified=False))
(root/document).write_text((w/'final-audit-prose-v1.md').read_text())
status=root/'docs/PROJECT_STATUS.md';old_status=gzip.decompress((prior/'PROJECT_STATUS.md.gz').read_bytes()).decode();heading='# 当前项目状态\n\n';assert old_status.startswith(heading)
status.write_text(heading+(w/'final-status-prose-v1.md').read_text()+old_status[len(heading):])
print('PUBLISHED boundedCN76/23;focus723/448;check13633/7600;SQL90/171/167/51;168reviews83contexts269gates7deltas;17291+76+17=17384;1037active703outside;newfixedfull/products OPEN',flush=True)
