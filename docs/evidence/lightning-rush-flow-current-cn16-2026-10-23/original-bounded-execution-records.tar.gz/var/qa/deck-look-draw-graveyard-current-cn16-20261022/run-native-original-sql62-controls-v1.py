from pathlib import Path
import ast, datetime, hashlib, json, os, plistlib, resource, socket, subprocess
resource.setrlimit(resource.RLIMIT_CORE, (0, 0)); os.umask(0o077)
root = Path('/Users/dinghaolin/MyProjects/riftbound'); w = Path(__file__).resolve().parent
load = lambda p: json.loads(p.read_text()); sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
observe_source = root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes = [n for n in ast.parse(observe_source.read_text()).body if isinstance(n, ast.FunctionDef) and n.name == 'observe_lock']
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(observe_source), 'exec'), globals())
pub = load(w/'current-rule-sql62-frozen-inputs-v2.json'); runtime = Path(pub['runtimeRoot'])
terminal = load(w/'real-sql62-owner-terminal-v2.json')
assert terminal['status'].startswith('PASS_') and terminal['originalAcceptedInputs'] == 90 and terminal['ownPostgresSmartStopped']
assert all(sha(runtime/p) == h for p, h in pub['runtimeFiles'].items())
changed = [p for p, v in pub['sourceInputHashes'].items() if sha(root/p) != v['sha256']]
assert changed == [], changed
new = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=root, text=True).splitlines()
paths = sorted(set(pub['sourceInputHashes']) | {p for p in new if p.startswith(('src/', 'tests/', 'clients/', 'scripts/', 'data/official/'))})
sources = {p: sha(root/p) for p in paths}
native = root/'clients/godot/.godot/mono/temp/bin/Debug'
native_inputs = {str(p.relative_to(native)): sha(p) for p in native.rglob('*') if p.is_file()}
helper = w/'independent-sql-native-source-v1/bin/Release/net10.0/LightningRushIndependentSqlNativeV1.dll'
quote_prefix = ['/Users/dinghaolin/.dotnet/dotnet', 'exec', '--depsfile', str(runtime/'Riftbound.PostgresAcceptance.deps.json'),
                '--runtimeconfig', str(runtime/'Riftbound.PostgresAcceptance.runtimeconfig.json'), str(helper)]
measured = json.loads(subprocess.check_output(quote_prefix + ['--loaded-inputs'], cwd=runtime))
assert measured == pub['actualLoadedFourAssemblies']
out = w/'native-actual-sql62-controls-v1'; out.mkdir(exist_ok=False)
entries = []
for folder in sorted((w/'real-sql62-v2/lightning-rush-flow').iterdir()):
    receipt = load(folder/'receipt.json')
    for command in sorted(folder.glob('input-*-original-command.json')):
        number = int(command.name.split('-')[1]); raw = load(command); prompt = folder/f'input-{number:02d}-prompt.json'
        assert raw['cmdType'] in {'PLAY_CARD', 'PAY_COST', 'PASS_PRIORITY', 'CHOOSE_CARDS'}
        entry = dict(branch=receipt['branch'], commandIndex=number, playerId=load(prompt)['playerId'],
                     originalCommandPath=str(command), promptPath=str(prompt), beforeFramePath=str(folder/f'prefix-{number:02d}-original-frame.json.gz'),
                     outputCommandPath=str(out/f"{receipt['branch']}-{number:02d}-native-command.json"))
        entry['originalInputHashes'] = {k: sha(Path(entry[k])) for k in ['originalCommandPath', 'promptPath', 'beforeFramePath']}
        entries.append(entry)
assert len(entries) == 51
(out/'index.json').write_text(json.dumps(dict(actualRuleInputs=pub['actualRuleInputs'], quoteCommandPrefix=quote_prefix, entries=entries), ensure_ascii=False, indent=2))
args = ['/Users/dinghaolin/.local/share/riftbound-tools/godot-4.7.2/Godot_mono.app/Contents/MacOS/Godot', '--headless', '--path',
        str(root/'clients/godot'), 'res://scenes/debug/LightningRushInteractionProof.tscn', '--', '--evidence='+str(out)]
proof = dict(status='RUNNING_ORIGINAL_SQL62_NATIVE_CONTROLS', startedAtUtc=now(), lockAtStart=observe_lock(), actualCommand=args,
             sourceHashes=sources, nativeManagedRuntimeFiles=native_inputs, actualLoadedBackend=measured, helperSha256=sha(helper),
             originalSqlGameplayCommands=len(entries), visiblePairOrLiveNativeSubmissionClaimed=False)
power = None
try:
    with socket.socket() as s: assert s.connect_ex(('127.0.0.1', 15847)) != 0
    power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())])
    with (out/'actual-godot-original-console.log').open('xb') as log:
        code = subprocess.run(args, cwd=root, stdout=log, stderr=subprocess.STDOUT, timeout=150).returncode
    proof['actualExitCode'] = code
    log = (out/'actual-godot-original-console.log').read_text()
    assert code == 0 and 'LIGHTNING_RUSH_NATIVE_INTERACTION_PASS: 51 ' in log and 'ERROR:' not in log
    result = load(out/'native-result.json'); assert result['commands'] == 51
    loaded = load(out/'actual-loaded-client-assemblies.json'); assert len(loaded['assemblies']) == 2
    for a in loaded['assemblies']:
        assert Path(a['candidateDiskPath']) == native/(a['name']+'.dll') and a['candidateDiskSha256'] == native_inputs[a['name']+'.dll']
        assert a['mvid'] == a['candidateDiskMvid'] and a['actualReportedLocation'] in ['', a['candidateDiskPath']]
    packets = []
    for entry in entries:
        actual = load(Path(entry['outputCommandPath'])); original = load(Path(entry['originalCommandPath']))
        assert actual['cmdType'] == original['cmdType'] and actual['promptId'] == original['promptId'] and actual['snapshotTick'] == original['snapshotTick']
        assert all(sha(Path(entry[k])) == h for k, h in entry['originalInputHashes'].items())
        packets.append(dict(branch=entry['branch'], commandIndex=entry['commandIndex'], nativeSha256=sha(Path(entry['outputCommandPath'])),
                            originalPromptAndTickExact=True, completeCommandSemanticEquivalencePendingIndependentReplay=True))
    proof.update(status='PASS_51_ACTUAL_NATIVE_CONTROLS_WITH_ACTUAL_FROZEN_BACKEND_PRICE_REQUESTS', nativeResult=result,
                 actualLoadedClientAssemblies=loaded, packets=packets, independentReplayStillPending=True)
except BaseException as error:
    proof.update(status='FAILED_NATIVE_CONTROL_PROOF_ORIGINALS_RETAINED', errorType=type(error).__name__, error=str(error)); raise
finally:
    if power is not None and power.poll() is None: power.terminate(); power.wait(timeout=10)
    proof.update(finishedAtUtc=now(), lockAtEnd=observe_lock(), allSourceHashesStable=all(sha(root/p) == h for p, h in sources.items()),
                 allNativeRuntimeHashesStable=all(sha(native/p) == h for p, h in native_inputs.items()),
                 allFrozenBackendRuntimeHashesStable=all(sha(runtime/p) == h for p, h in pub['runtimeFiles'].items()), helperHashStable=sha(helper) == proof['helperSha256'])
    with (out/'actual-native-control-terminal-v1.json').open('x') as f: json.dump(proof, f, ensure_ascii=False, indent=2)
assert all(proof[k] for k in ['allSourceHashesStable', 'allNativeRuntimeHashesStable', 'allFrozenBackendRuntimeHashesStable', 'helperHashStable'])
print(proof['status'], proof['nativeResult'], flush=True)
