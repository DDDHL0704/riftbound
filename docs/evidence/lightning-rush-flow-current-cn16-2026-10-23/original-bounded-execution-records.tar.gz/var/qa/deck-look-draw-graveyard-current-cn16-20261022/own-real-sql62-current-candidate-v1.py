# -*- coding: utf-8 -*-
from pathlib import Path
import ast, datetime, fcntl, gzip, hashlib, json, os, plistlib, resource, socket, subprocess
resource.setrlimit(resource.RLIMIT_CORE, (0, 0)); os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
source=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes=[n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}]
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),globals())
baseline=load(root/'var/qa/lightning-rush-flow-current-cn16-20261022/post-preparation-corrected-candidate-v2/current-rule-sql62-frozen-inputs-v1.json')
original_paths=list(baseline['sourceInputHashes'])
new_paths=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines()
new_paths=[p for p in new_paths if p.startswith(('src/','tests/','clients/','scripts/','data/official/'))]
paths=sorted(set(original_paths+new_paths))
inputs={p:{'sha256':sha(root/p),'mode':oct((root/p).stat().st_mode&0o777)} for p in paths}
assert len(original_paths)==3360 and len(new_paths)>0 and len(inputs)==len(original_paths)+len(set(new_paths)-set(original_paths))
def current_inputs():return all(sha(root/p)==v['sha256'] and oct((root/p).stat().st_mode&0o777)==v['mode'] for p,v in inputs.items())
build=root/'tests/Riftbound.PostgresAcceptance/bin/Debug/net10.0';r=w/'current-rule-sql62-runtime-v1';r.mkdir()
frozen={}
for p in build.rglob('*'):
 if p.is_file():
  rel=p.relative_to(build);dest=r/rel;dest.parent.mkdir(parents=True,exist_ok=True);subprocess.run(['/bin/cp','-c',str(p),str(dest)],check=True);assert p.read_bytes()==dest.read_bytes();frozen[str(rel)]=sha(dest)
assert len(frozen)>=89 and not (r/'Riftbound.PostgresAcceptance.deps.json').is_symlink() and not (r/'Riftbound.PostgresAcceptance.runtimeconfig.json').is_symlink()
probe=root/'var/qa/fixed55fdb-early-native-20261022/ordinary-ci-pair-attempt-v2/selected-actual-native-history-reader-source-v2/bin/Release/net10.0/Fixed55fdbNativeHistoryReaderV2.dll'
measurement=json.loads(subprocess.check_output(['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(r/'Riftbound.PostgresAcceptance.deps.json'),'--runtimeconfig',str(r/'Riftbound.PostgresAcceptance.runtimeconfig.json'),str(probe),'--loaded-inputs'],cwd=r,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0')))
assert Path(measurement['baseDirectory'])==r and len(measurement['assemblies'])==4
for a in measurement['assemblies']:assert Path(a['path'])==r/(a['name']+'.dll') and a['sha256']==frozen[a['name']+'.dll'] and a['mvid']
manifest=load(root/'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json');old=json.loads(subprocess.check_output(['git','show','5edb12e5:tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'],cwd=root))
assert len(manifest['cases'])==62 and len(old['cases'])==61 and manifest['cases'][:61]==old['cases'] and manifest['cases'][61:]==[{'id':'lightning-rush-flow','sourceType':'LightningRushFlowSqlAcceptance'}]
pub={'atUtc':now(),'baseCommit':'5edb12e57576358f3ef4a9f9d6da92c313f12437','includesDeclaredUncommittedLightningRushChanges':True,'runtimeRoot':str(r),'runtimeFiles':frozen,'sourceInputHashes':inputs,'actualLoadedFourAssemblies':measurement,'actualRuleInputs':measurement['actualRuleInputs'],'manifest62Original61Retained':True,'oldProbeOnlyMeasuresLoadedInputsNoOldGameplayVerdictReused':True}
(w/'current-rule-sql62-frozen-inputs-v1.json').write_text(json.dumps(pub,indent=2))
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof={'status':'RUNNING_CURRENT_CANDIDATE_LIGHTNING_RUSH_FLOW_SQL62','startedAtUtc':now(),'actualLoadedFourAssemblies':measurement,'sourceInputCount':len(inputs),'lockAtStart':observe_lock(),'actualDatabase':'riftbound_acceptance','onlyNewSql62SelectedAllOriginal61Retained':True};started=False;power=None;audit=native=before_audit=before_native=None
try:
 assert current_inputs() and all(sha(r/p)==h for p,h in frozen.items())
 assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid
 sock.mkdir(exist_ok=True);subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'real-sql62-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 audit=rooms('riftbound_acceptance');native=rooms('riftbound_here_native');assert len(audit)==397 and len(native)==99
 before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',native)
 output=w/'real-sql62-v1';assert not output.exists();args=['/Users/dinghaolin/.dotnet/dotnet',str(r/'Riftbound.PostgresAcceptance.dll'),'--lightning-rush-flow-only'];proof['actualCommand']=args
 with (w/'real-sql62-v1.log').open('xb') as log:code=subprocess.run(args,cwd=r,env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit',RIFTBOUND_POSTGRES_EVIDENCE=str(output),DOTNET_DbgEnableMiniDump='0'),stdout=log,stderr=subprocess.STDOUT,timeout=600).returncode
 proof['actualExitCode']=code;assert code==0
 receipts=[load(p) for p in sorted((output/'lightning-rush-flow').glob('*/receipt.json'))]
 assert len(receipts)==12 and sum(d['deliberateTamperRecoveryRejected'] for d in receipts)==4 and all(d['coldRecoveries']==d['originalAcceptedInputs'] and d['actualRuleInputs']==pub['actualRuleInputs'] for d in receipts)
 assert set(rooms('riftbound_acceptance'))==set(audit)|{d['room'] for d in receipts} and rooms('riftbound_here_native')==native
 proof.update(status='PASS_CURRENT_CANDIDATE_SQL62_TWELVE_ORIGINAL_ROOMS_AND_FOUR_ACTUAL_COLD_REFUSALS',receipts=receipts,actualRuleInputs=pub['actualRuleInputs'],originalAcceptedInputs=sum(d['originalAcceptedInputs'] for d in receipts),actualColdRecoveries=sum(d['coldRecoveries'] for d in receipts),actualRealDbRefusals=4,controlledScenariosNotOrdinaryFullGameOrNativeVisibleAcceptance=True)
except BaseException as e:
 proof.update(status='FAILED_CURRENT_CANDIDATE_SQL62_ALL_ORIGINALS_RETAINED',errorType=type(e).__name__,error=str(e));raise
finally:
 if started:
  if before_audit is not None:
   proof['allOriginal397AuditSevenTablesExact']=digests('riftbound_acceptance',audit)==before_audit;proof['allOriginal99NativeSevenTablesExact']=digests('riftbound_here_native',native)==before_native;proof['actualAuditRoomsAtStop']=rooms('riftbound_acceptance');proof['actualNativeRoomsAtStop']=rooms('riftbound_here_native')
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None and power.poll() is None:power.terminate();power.wait(timeout=10)
 proof.update(allCurrentSourceHashesAndModesStable=current_inputs(),finishedAtUtc=now(),lockAtEnd=observe_lock(),allFrozenRuntimeHashesStable=all(sha(r/p)==h for p,h in frozen.items()),actualLoaderMetadataRetained=True)
 with (w/'real-sql62-owner-terminal-v1.json').open('x') as f:json.dump(proof,f,indent=2)
 fcntl.flock(guard,fcntl.LOCK_UN)
assert proof['allOriginal397AuditSevenTablesExact'] and proof['allOriginal99NativeSevenTablesExact'] and proof['ownPostgresSmartStopped'] and proof['allCurrentSourceHashesAndModesStable'] and proof['allFrozenRuntimeHashesStable']
print(proof['status'],proof['originalAcceptedInputs'],proof['actualColdRecoveries'],flush=True)
