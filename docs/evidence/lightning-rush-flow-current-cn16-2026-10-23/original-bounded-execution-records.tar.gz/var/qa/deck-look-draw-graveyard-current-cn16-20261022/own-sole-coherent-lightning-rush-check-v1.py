from pathlib import Path
import collections, datetime, gzip, hashlib, json, os, re, resource, subprocess, xml.etree.ElementTree as E, zipfile
resource.setrlimit(resource.RLIMIT_CORE, (0, 0)); os.umask(0o077)
root = Path('/Users/dinghaolin/MyProjects/riftbound'); w = Path(__file__).resolve().parent
base = '5edb12e57576358f3ef4a9f9d6da92c313f12437'
load = lambda p: json.loads(p.read_text()); sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == base
focus = load(w/'final-current-family-focus-actual-positive-output-independent-closure-v1.json')
assert focus['status'].startswith('PASS_') and focus['actualSummary']['total'] == 723 and focus['newCases'] == 76
native = load(w/'native-actual-sql62-controls-v2/actual-native-control-terminal-v2.json')
pins = {p: dict(sha256=sha(root/p), mode=oct((root/p).stat().st_mode & 0o777)) for p in native['sourceHashes']}
assert len(pins) == 3373 and all(pins[p]['sha256'] == h for p, h in native['sourceHashes'].items())
before = load(w/'current23-before-new-lightning-rush-source-tests-and-governance-inputs-v1.json')
original = {p:h for p,h in before['sourceAndTestFiles'].items() if p.startswith('tests/Riftbound.ConformanceTests/')}
assert len(original) == 1811
changed = [p for p,h in original.items() if sha(root/p) != h]
assert set(changed) == {'tests/Riftbound.ConformanceTests/'+n for n in ['AhriCombatMightTests.cs', 'CardCatalogBaselineTests.cs', 'Cn16RuleInputSelectionTests.cs', 'VendettaAmbushTests.cs', 'WildClawSourceIdentityTests.cs']}
for path in changed:
    old = subprocess.check_output(['git', 'show', base+':'+path], cwd=root, text=True); current = (root/path).read_text()
    assert re.findall(r'public (?:async )?(?:void|Task|ValueTask) (\w+)\(', current) == re.findall(r'public (?:async )?(?:void|Task|ValueTask) (\w+)\(', old)
    assert re.findall(r'\[(?:Fact|Theory|InlineData|MemberData)[^\]]*\]', current, re.S) == re.findall(r'\[(?:Fact|Theory|InlineData|MemberData)[^\]]*\]', old, re.S)
    assert len(re.findall(r'\bAssert\.', current)) == len(re.findall(r'\bAssert\.', old))
assert len(before['fullGameSourcePaths']) == 9 and all(sha(root/p) == before['sourceAndTestFiles'][p] for p in before['fullGameSourcePaths'])
ns = {'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def rows(raw):
    doc = E.fromstring(raw); definitions = {d.get('id'):d.find('t:TestMethod', ns).attrib for d in doc.findall('.//t:UnitTest', ns)}
    return [dict(name=r.get('testName'), method=definitions[r.get('testId')]['className']+'.'+definitions[r.get('testId')]['name'], outcome=r.get('outcome')) for r in doc.findall('.//t:UnitTestResult', ns)]
prior = load(root/'var/qa/fixed5edb1-early-native-20261023/ci5edb1-entire-full-independent-verification-v1.json')
assert prior['fixedCommit'] == base and (prior['actualCases'], prior['actualMethods'], prior['sql']['caseCount']) == (13706,7718,61)
artifact = next(a for a in prior['artifacts'] if a['name'] == 'conformance-results'); assert sha(Path(artifact['path'])) == artifact['sha256']
old_rows = []
with zipfile.ZipFile(artifact['path']) as z:
    for name in z.namelist():
        if name.endswith('/results.trx'): old_rows += rows(z.read(name))
assert len(old_rows) == 13706 and all(r['outcome'] == 'Passed' for r in old_rows)
smokes = {'Riftbound.ConformanceTests.FullGameEndToEndTests.OfficialDeckMidgamePaysRumbleReducedGraveyardMechanicalPaymentAndScoreVictoryActionLogReplaysToFinalStateHash',
          'Riftbound.ConformanceTests.FullGameEndToEndTests.OfficialLowCurveDecksReachScoreVictoryAfterRealBattleThroughServerPrompts'}
baseline = [r for r in old_rows if '.FullGameEndToEndTests.' not in r['method'] or r['method'] in smokes]
assert len(baseline) == 13557 and len({r['method'] for r in baseline}) == 7577
new = collections.Counter(focus['newCaseNames']); assert sum(new.values()) == 76
runtime = {}
for role, folder in [('Conformance', root/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0'), ('Native', root/'clients/godot/.godot/mono/temp/bin/Debug')]:
    runtime[role] = {str(p.relative_to(root)):sha(p) for p in folder.rglob('*') if p.is_file() and '/net10.0/var/qa/' not in str(p)}
test = root/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0/Riftbound.ConformanceTests.dll'
assert sha(test) == focus['actualTestAssemblySha256']
start = dict(atUtc=now(), baseCommit=base, all3373SourceHashesAndModes=pins, all1811OriginalConformanceFiles=original,
             onlyFiveOriginalFilesScopedRegistrationMetadataAndSourceIdentityCalibration=changed, allOther1806OriginalConformanceFilesByteExact=True,
             allOriginalChangedFileMethodDeclarationsTheoryRowsAndAssertCountsRetained=True, allNineFullGameSourceHashes={p:before['sourceAndTestFiles'][p] for p in before['fullGameSourcePaths']},
             all143OriginalCompleteMethods151Cases110Pairs11DecksSeed424242AndVictoryReplayAssertionsRetained=True,
             actualFourLoadedAssemblies=focus['actualLoadedFourAssemblies'], actualRuntimeInputs=runtime,
             previousActualFixedFull13706Cases7718Methods61SqlSeparate=True, baselineCaseNames=sorted(r['name'] for r in baseline), newCaseNames=sorted(new.elements()),
             expectedCheckCases=13633, expectedCheckMethods=7600, expectedDiscoveryMethods=7741, expectedNextFixedFullCases=13782,
             newCases=76, newMethods=23, noDatabaseConnectionForThisCheck=True, wholeCardOrGoalCertified=False)
manifest = w/'sole-check-start-inputs-v1.json.gz'; assert not manifest.exists()
manifest.write_bytes(gzip.compress(json.dumps(start, indent=2).encode(), mtime=0))
out = w/'sole-check-v1'; assert not out.exists()
args = ['python3','scripts/test-rules.py','check','--output',str(out)]; env = dict(os.environ); env.pop('ConnectionStrings__Riftbound', None)
proof = dict(status='RUNNING_SOLE_COHERENT_LIGHTNING_RUSH_CHECK', startedAtUtc=now(), baseCommit=base, actualCommand=args,
             sourceInputs=len(pins), runtimeInputCounts={k:len(v) for k,v in runtime.items()}, startManifestSha256=sha(manifest))
print('SOLE_CHECK_STARTED_EXPECT13633_CASES7600_METHODS_3373_SOURCES', flush=True)
try:
    with (w/'sole-check-original-console-v1.log').open('xb') as log:
        process = subprocess.Popen(args, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
        with (w/'sole-check-running-owner-v1.json').open('x') as f: json.dump(dict(proof, ownerPid=os.getpid(), runnerPid=process.pid), f, indent=2)
        power = subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(process.pid)])
        proof['exitCode'] = process.wait(); power.wait(timeout=10)
    if proof['exitCode'] == 0:
        summary = load(out/'summary.json'); plan = load(out/'plan.json'); actual = rows((out/'check/results.trx').read_bytes())
        assert summary['status'] == 'PASSED' and summary['total'] == 13633 and len(actual) == 13633
        assert collections.Counter(r['name'] for r in actual) == collections.Counter(r['name'] for r in baseline) + new
        assert all(r['outcome'] == 'Passed' for r in actual) and plan['discoveredMethods'] == 7741 and len(plan['shards'][0]['methods']) == 7600
        proof.update(status='PASS_SOLE_COHERENT_LIGHTNING_RUSH_CHECK13633_CASES7600_METHODS', summary=summary,
                     allOriginal13557CheckCaseNamesAnd7577MethodsRetainedPlus76Cases23MethodsOnly=True, trxSha256=sha(out/'check/results.trx'))
    else: proof['status'] = 'FAILED_SOLE_COHERENT_LIGHTNING_RUSH_CHECK_ORIGINALS_RETAINED'
finally:
    proof.update(finishedAtUtc=now(), all3373SourceHashesAndModesStable=all(sha(root/p) == v['sha256'] and oct((root/p).stat().st_mode & 0o777) == v['mode'] for p,v in pins.items()),
                 allCapturedConformanceAndNativeRuntimeInputsStable=all(sha(root/p) == h for group in runtime.values() for p,h in group.items()))
    with (w/'sole-check-owner-terminal-v1.json').open('x') as f: json.dump(proof, f, indent=2)
print(proof['status'], flush=True)
assert proof['exitCode'] == 0 and proof['all3373SourceHashesAndModesStable'] and proof['allCapturedConformanceAndNativeRuntimeInputsStable']
