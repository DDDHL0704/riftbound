from pathlib import Path
import ast,datetime,errno,fcntl,gzip,hashlib,json,os,plistlib,pty,resource,socket,subprocess,threading,time,urllib.request
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;n=root/'var/qa/fixed5edb1-early-native-20261023';out=w/'locked-fixed5edb-ci-pair-original-final-viewports-v1';out.mkdir()
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486');tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
s=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py';nodes=[x for x in ast.parse(s.read_text()).body if isinstance(x,ast.FunctionDef)and x.name in{'query','rooms','digests','observe_lock'}];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(s),'exec'),globals())
pub=load(n/'frozen-fixed5edb1-native-composition-v1.json');api_runtime=Path(pub['apiRuntimeRoot']);helpers=Path(pub['helperRuntimeRoot']);previous=load(n/'ordinary-ci-pair-v1/live-current-ci-main-owner-terminal-v5.json');room=previous['room'];assert room=='N27-RETARGET-EAAB9DDBA9'and previous['totalCommands']==66 and previous['events']==405
native=load(w/'native-actual-sql62-controls-v2/actual-native-control-terminal-v2.json');current_sources=native['sourceHashes'];assert all(sha(root/p)==h for p,h in current_sources.items())
def frozen():
 return all(sha(api_runtime/p)==h for p,h in pub['runtimeFiles'].items())and all(sha(helpers/p)==h for p,h in pub['helperRuntimeFiles'].items())and all(sha(Path(a['app'])/p)==h for a in pub['nativeApps']for p,h in pub['ciManagedAndPckPayloads'].items())
assert frozen()
for role in ['a','b']:
 original=n/'ordinary-ci-pair-v1'/f'session-{role}.json';p=load(original);assert p['roomId']==room and p['playerKey']and p['reconnectToken'];(out/f'private-session-{role}.json').write_bytes(original.read_bytes())
def seven():
 return {t:json.loads(query('riftbound_here_native',f"select coalesce(json_agg(t order by row_to_json(t)::text),'[]'::json)::text from (select * from {t} where match_id='{room}')t"))for t in tables}
def save(name,obj):
 p=out/name
 with p.open('x')as f:json.dump(obj,f,indent=2)
def export(label):
 target=out/(label+'-original-frame.json.gz');args=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(helpers/'Riftbound.Api.deps.json'),'--runtimeconfig',str(helpers/'Riftbound.Api.runtimeconfig.json'),str(helpers/'FixedNativeFrameExport.dll'),room,str(target)]
 metadata=json.loads(subprocess.check_output(args,cwd=helpers,env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit;Options=-c default_transaction_read_only=on',DOTNET_DbgEnableMiniDump='0')));assert metadata['actualRuleInputs']==pub['actualRuleInputs'];save(label+'-actual-loader-metadata.json',metadata)
 frame=json.loads(gzip.decompress(target.read_bytes()));assert frame['isConsistent']and not frame['validationErrors']and len(frame['commands'])==66 and len(frame['events'])==405 and frame['authoritativeState']['ruleInputs']==pub['actualRuleInputs'];return frame
clients=[];pumps={};api=None;started=False;audit=other_native=None;before_audit=before_other=before_rows=before_frame=None
proof=dict(status='RUNNING_LOCKED_NONHEADLESS_FIXED_CI_PAIR_ORIGINAL_FINISHED_MATCH_VIEWPORTS',startedAtUtc=now(),lockAtStart=observe_lock(),fixedClientCommit=pub['fixedCommit'],fixedClientCiRun=pub['fixedCiRun'],actualBackendRuleInputs=pub['actualRuleInputs'],room=room,original66Commands405EventsAndPrivateSeedWillNotBeRewritten=True,noNewMatchOrGameplayCommandOrDatabaseCopy=True,ownViewportCaptureNotDesktopInputOrHumanVisibleAcceptance=True,doesNotCertifyNewLightningRushRuntime=True,ownedClients=[])
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
try:
 assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket()as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(out/'own-postgres-original.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 audit=rooms('riftbound_acceptance');all_native=rooms('riftbound_here_native');assert len(audit)==422 and len(all_native)==99 and room in all_native;other_native=[x for x in all_native if x!=room];before_audit=digests('riftbound_acceptance',audit);before_other=digests('riftbound_here_native',other_native);before_rows=seven();before_frame=export('before-cold-native-gpu-restore');(out/'before-original-seven-tables.json.gz').write_bytes(gzip.compress(json.dumps(before_rows).encode(),mtime=0))
 env=dict(os.environ,ASPNETCORE_ENVIRONMENT='Production',ASPNETCORE_URLS='http://127.0.0.1:15847',ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit',DOTNET_DbgEnableMiniDump='0');env.pop('DOTNET_STARTUP_HOOKS',None)
 with(out/'own-fixed-api-original.log').open('xb')as log:api=subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet',str(api_runtime/'Riftbound.Api.dll')],cwd=api_runtime,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 deadline=time.monotonic()+25
 while True:
  assert api.poll()is None
  try:
   with urllib.request.urlopen('http://127.0.0.1:15847/health',timeout=.5)as response:health=json.load(response)
   assert health['persistenceMode']=='postgres'and health['environment']=='Production';break
  except OSError:
   assert time.monotonic()<deadline;time.sleep(.15)
 proof.update(ownApiPid=api.pid,actualHealth=health)
 for role in ['a','b']:
  app=Path(next(a['app']for a in pub['nativeApps']if a['label']==role));subprocess.run(['codesign','--verify','--deep','--strict',str(app)],capture_output=True,check=True)
  image=out/f'actual-native-{role}-original-final.png';args=[str(app/'Contents/MacOS/符文战场'),'--resolution','1280x720','--max-fps','30','--quit-after','1200','--','--riftbound-server=http://127.0.0.1:15847','--riftbound-session-file='+str(out/f'private-session-{role}.json'),'--riftbound-smoke-connect-only','--riftbound-visual-screenshot='+str(image)]
  master,slave=pty.openpty();logpath=out/f'actual-native-{role}-original-console.log';stream=logpath.open('xb',buffering=0);environment=dict(os.environ,DOTNET_DbgEnableMiniDump='0');environment.pop('DOTNET_STARTUP_HOOKS',None)
  process=subprocess.Popen(args,cwd='/tmp',env=environment,stdin=subprocess.DEVNULL,stdout=slave,stderr=slave,start_new_session=True);os.close(slave)
  def drain(fd=master,sink=stream):
   try:
    while True:
     try:block=os.read(fd,65536)
     except OSError as error:
      if error.errno==errno.EIO:break
      raise
     if not block:break
     sink.write(block)
   finally:os.close(fd);sink.close()
  pump=threading.Thread(target=drain,daemon=True);pump.start();pumps[process.pid]=pump;clients.append((process,role,logpath,image));proof['ownedClients'].append(dict(pid=process.pid,role=role,actualCommand=args,nonHeadless=True,all373ActualCiManagedAndPckPayloadHashesVerified=True))
 deadline=time.monotonic()+55
 while True:
  if all(png.exists()and png.stat().st_size>1000 and 'Visual screenshot saved:'in log.read_text(errors='replace')and 'Snapshot' in log.read_text(errors='replace')for _,_,log,png in clients):break
  assert all(p.poll()is None for p,_,_,_ in clients),'An original native process exited before returning its actual viewport.'
  assert time.monotonic()<deadline,'Actual defaultMain own-viewport image deadline exceeded.';time.sleep(.25)
 proof['bothProcessesAliveAtOwnViewportCapture']=all(p.poll()is None for p,_,_,_ in clients)
 for p,role,log,image in clients:
  assert image.read_bytes().startswith(b'\x89PNG\r\n\x1a\n');text=log.read_text(errors='replace');assert 'ERROR:'not in text and 'Unhandled exception'not in text
  proof.setdefault('actualOwnViewportImages',[]).append(dict(role=role,path=str(image.relative_to(root)),sha256=sha(image),bytes=image.stat().st_size,actualPixelsStillNeedVisualRead=True))
  p.terminate();p.wait(timeout=15);pumps[p.pid].join(timeout=5);assert p.returncode==0 and 'Termination requested; exiting through Godot.'in log.read_text(errors='replace')
 after_frame=export('after-both-cold-native-gpu-restores');assert all(before_frame[k]==after_frame[k]for k in ['commands','events','authoritativeState','openingSeed','replayInitialState'])
 after_rows=seven();(out/'after-original-seven-tables.json.gz').write_bytes(gzip.compress(json.dumps(after_rows).encode(),mtime=0))
 for t in tables[2:]:assert after_rows[t]==before_rows[t]
 changes=[]
 for t,allowed in [('matches',{'updated_at'}),('match_players',{'reconnect_token_hash','connection_state','updated_at'})]:
  assert len(before_rows[t])==len(after_rows[t])
  for old,new in zip(before_rows[t],after_rows[t]):
   fields={k for k in old.keys()|new.keys()if old.get(k)!=new.get(k)or(k in old)!=(k in new)};assert fields<=allowed,(t,fields);changes.append(dict(table=t,fields=sorted(fields)))
 proof.update(status='PASS_TWO_ACTUAL_FIXED_CI_NONHEADLESS_MAIN_OWN_VIEWPORTS_SAME_ORIGINAL_FINAL_MATCH_LOCK_OBSERVATIONS',originalCommands=66,originalEvents=405,originalAuthoritySeedInitialAndCompleteHistoryExact=True,allOriginalFiveGameplayTablesExact=True,onlyExpectedConnectionMetadataFieldsChanged=changes,actualDefaultMainNativePixelsNotHardwareInputAcceptance=True)
except BaseException as error:
 proof.update(status='FAILED_LOCKED_CI_NATIVE_OWN_VIEWPORT_PROOF_ALL_ORIGINALS_RETAINED',errorType=type(error).__name__,error=str(error));raise
finally:
 for p,_,_,_ in clients:
  if p.poll()is None:
   p.terminate()
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:p.kill();p.wait(timeout=5)
  pumps[p.pid].join(timeout=5)
 if api is not None and api.poll()is None:api.terminate();api.wait(timeout=15)
 if started:
  if before_audit is not None:proof.update(all422AuditSevenTablesExact=digests('riftbound_acceptance',audit)==before_audit,allOther98NativeSevenTablesExact=digests('riftbound_here_native',other_native)==before_other,noNewAuditOrNativeRoom=rooms('riftbound_acceptance')==audit and set(rooms('riftbound_here_native'))==set(other_native)|{room})
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),allCurrent3373SourcesStable=all(sha(root/p)==h for p,h in current_sources.items()),allCurrentNativeDebugRuntimeFilesStable=all(sha(root/'clients/godot/.godot/mono/temp/bin/Debug'/p)==h for p,h in native['nativeManagedRuntimeFiles'].items()),allFixedApiHelpersAndBoth373PayloadsStable=frozen(),onlyOwnedProcessesStopped=all(p.poll()is not None for p,_,_,_ in clients)and(api is None or api.poll()is not None),noNewAppInstallerSdkOrDatabaseCopies=True)
 save('actual-locked-fixed-ci-pair-own-viewports-terminal-v1.json',proof);fcntl.flock(guard,fcntl.LOCK_UN)
assert all(proof[k]for k in ['all422AuditSevenTablesExact','allOther98NativeSevenTablesExact','noNewAuditOrNativeRoom','ownPostgresSmartStopped','allCurrent3373SourcesStable','allCurrentNativeDebugRuntimeFilesStable','allFixedApiHelpersAndBoth373PayloadsStable','onlyOwnedProcessesStopped'])
print(proof['status'],proof.get('actualOwnViewportImages'),flush=True)
