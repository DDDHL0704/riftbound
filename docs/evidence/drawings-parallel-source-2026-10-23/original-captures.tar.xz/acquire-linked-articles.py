from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from urllib.error import HTTPError
from urllib.parse import urlsplit, urlunsplit
from urllib.request import Request, urlopen
import gzip
import hashlib
import json
import re

Q = Path(__file__).resolve().parent
ROOT = Q.parents[2]
BASE = ROOT / 'docs/evidence/global-2026-drawings-source-supplement-2026-10-23'
originals = [json.loads(s) for s in gzip.decompress((BASE/'three-original-http-pages.jsonl.gz').read_bytes()).decode().splitlines()]
old = next(r for r in originals if 'riftbounds-2026-drawings' in r['url'])
known_images = json.loads((BASE/'actual-five-product-images-six-exact-identities.json').read_text())['images']
known_by_url = {x['url']: x for x in known_images}
NOW = lambda: datetime.now(timezone.utc).isoformat()


class Article(HTMLParser):
    def __init__(self):
        super().__init__(); self.text=[]; self.images=[]; self.links=[]
    def handle_data(self, data):
        if data.strip(): self.text.append(data.strip())
    def handle_starttag(self, tag, attrs):
        a=dict(attrs)
        if tag=='img':self.images.append(a)
        if tag=='a' and 'href' in a:self.links.append(a['href'])


def fetch(item):
    label,url,etag=item
    record=dict(label=label,url=url,startedAtUtc=NOW(),requestIfNoneMatch=etag)
    headers={'User-Agent':'Mozilla/5.0 Riftbound source audit'}
    if etag:headers['If-None-Match']=etag
    try:
        try:
            response=urlopen(Request(url,headers=headers),timeout=25)
        except HTTPError as error:
            if error.code!=304:raise
            response=error
        with response:
            raw=response.read();record.update(httpStatus=response.status,resolvedUrl=response.url,
                responseHeaders={k:v for k,v in response.headers.items() if k.lower()in('date','content-type','etag','last-modified','location')},acquiredAtUtc=NOW())
        if record['httpStatus']==304:
            record.update(reusedExactOriginalArchive='docs/evidence/global-2026-drawings-source-supplement-2026-10-23/three-original-http-pages.jsonl.gz',reusedOriginalRawSha256=old['rawSha256'])
            raw=old['originalUtf8'].encode()
        else:
            packed=gzip.compress(raw,mtime=0)
            with(Q/(label+'.html.gz')).open('xb')as f:f.write(packed)
            record.update(archivePath=label+'.html.gz',archiveSha256=hashlib.sha256(packed).hexdigest())
        record.update(rawBytes=len(raw),rawSha256=hashlib.sha256(raw).hexdigest())
        m=re.search(r'<script id="__NEXT_DATA__"[^>]*>(.*?)</script>',raw.decode())
        page=json.loads(m.group(1))['props']['pageProps']['page']
        bodies=[b['richText']['body']for b in page['blades']if isinstance(b.get('richText'),dict)and 'body'in b['richText']]
        article=Article()
        for body in bodies:article.feed(body)
        images=[]
        for attrs in article.images:
            u=attrs.get('src','');parts=urlsplit(u);base=urlunsplit((parts.scheme,parts.netloc,parts.path,'',''))
            images.append(dict(attributes=attrs,exactAssetUrl=base,existingImage=known_by_url.get(base)))
        record.update(title=page.get('title'),locale=page.get('locale'),contentId=page.get('id'),declaredPublication=page.get('displayedPublishDate'),bodyHtml=bodies,
            bodyHtmlSha256=[hashlib.sha256(b.encode()).hexdigest()for b in bodies],text='\n'.join(article.text),images=images,links=article.links,hreflangs=page.get('hreflangs'))
        if label=='drawings-en':record['sameBodyAsOriginal']=bodies==[old['bodyHtml']]
    except Exception as error:
        record.update(failedAtUtc=NOW(),error=type(error).__name__+': '+str(error))
    with(Q/(label+'.receipt.json')).open('x')as f:json.dump(record,f,ensure_ascii=False,indent=2)
    print(label,record.get('httpStatus'),record.get('locale'),len(record.get('images',[])),record.get('error',''),flush=True)
    return record


items=[('drawings-en',old['url'],old['headers']['Etag'])]
items.extend(('drawings-'+h['locale'],h['url'],None)for h in old['originalPageData']['hreflangs']if h['locale']in('zh-cn','zh-tw','ko-kr'))
items.append(('products-2027-en','https://playriftbound.com/en-us/news/announcements/products-and-sets-into-2027/',None))
with ThreadPoolExecutor(max_workers=2)as pool:records=list(pool.map(fetch,items))
summary=[{k:r.get(k)for k in('label','httpStatus','title','locale','declaredPublication','bodyHtmlSha256','sameBodyAsOriginal','images','links','error')}for r in records]
with(Q/'linked-article-summary.json').open('x')as f:json.dump(summary,f,ensure_ascii=False,indent=2)
