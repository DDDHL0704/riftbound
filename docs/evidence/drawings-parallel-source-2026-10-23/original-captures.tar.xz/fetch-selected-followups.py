from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen
import gzip
import hashlib
import json
import re

Q = Path(__file__).resolve().parent
t1 = json.loads((Q/'t1-collection-en.receipt.json').read_text())['mappedPage']
items = [('t1-'+h['locale'], h['url'], 'html') for h in t1['hreflangs'] if h['locale'] in ('zh-cn','zh-tw','ko-kr')]
items += [
    ('t1-player-previous-render', 'https://cmsassets.rgpub.io/sanity/images/dsfx7636/news_live/8ed88a16e1b47185c773672e7e6c647167e1ecf4-1327x1220.jpg', 'jpg'),
    ('gift-previous-product-render', 'https://cmsassets.rgpub.io/sanity/images/dsfx7636/news_live/c29867848499a536072d5a4cc34082b9e28dc500-2880x1620.jpg', 'jpg')]
now = lambda: datetime.now(timezone.utc).isoformat()


def acquire(item):
    label, url, suffix = item
    record = dict(label=label, url=url, startedAtUtc=now())
    try:
        try:
            response = urlopen(Request(url, headers={'User-Agent': 'Mozilla/5.0 Riftbound source audit'}), timeout=25)
        except HTTPError as error:
            response = error
        with response:
            raw = response.read()
            record.update(httpStatus=response.status, resolvedUrl=response.url,
                          responseHeaders=dict(response.headers), acquiredAtUtc=now())
        payload = raw if suffix == 'jpg' else gzip.compress(raw, mtime=0)
        name = label + ('.jpg' if suffix == 'jpg' else '.html.gz')
        with (Q/name).open('xb') as stream:
            stream.write(payload)
        record.update(rawSha256=hashlib.sha256(raw).hexdigest(), rawBytes=len(raw),
                      archivePath=name, archiveSha256=hashlib.sha256(payload).hexdigest())
        if suffix == 'html':
            match = re.search(r'<script id="__NEXT_DATA__"[^>]*>(.*?)</script>', raw.decode())
            if match:
                data = json.loads(match.group(1))
                record.update(nextPage=data.get('page'), nextLocale=data.get('locale'),
                              mappedPage=data['props']['pageProps'].get('page'))
    except Exception as error:
        record.update(error=type(error).__name__+': '+str(error), failedAtUtc=now())
    with (Q/(label+'.receipt.json')).open('x') as stream:
        json.dump(record, stream, ensure_ascii=False, indent=2)
    print(label, record.get('httpStatus'), record.get('rawBytes'), record.get('error',''), flush=True)


with ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(acquire, items))
