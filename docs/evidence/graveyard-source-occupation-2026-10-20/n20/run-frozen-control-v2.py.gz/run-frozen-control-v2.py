import datetime
import hashlib
import json
import os
import pathlib
import plistlib
import subprocess

os.umask(0o077)
n = pathlib.Path(__file__).resolve().parent
candidate = n.parent / 'destruction-fixed-e262-20261020'
root = n.parents[2]
publication = json.loads((candidate / 'fixed-api-publication-v1.json').read_text())
runtime = n / 'current-fixed-probe-v2/bin/Release/net10.0'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
files = {str(p.relative_to(n)): sha(p) for p in runtime.iterdir() if p.is_file()}
files.update({str(p.relative_to(n)): sha(p) for p in [n / 'current-fixed-probe-v2/Program.cs', n / 'current-fixed-probe-v2/probe.csproj', pathlib.Path(__file__)]})
out = n / 'controlled-probe-verification-v2.json'
assert not out.exists()

def locked():
    raw = plistlib.loads(subprocess.check_output(['/usr/sbin/ioreg', '-n', 'Root', '-d', '1', '-a']))
    return [{'rootLocked': x.get('IOConsoleLocked'), 'sessions': [u['CGSSessionScreenIsLocked'] for u in x.get('IOConsoleUsers', []) if 'CGSSessionScreenIsLocked' in u]}
            for x in (raw if isinstance(raw, list) else [raw])]

def verify():
    assert all(sha(n / p) == digest for p, digest in files.items())
    assert all(sha(root / p) == digest for p, digest in publication['sourceInputHashes'].items())
    for name in ['Riftbound.Engine.dll', 'Riftbound.Contracts.dll', 'Riftbound.CardCatalog.dll']:
        assert sha(runtime / name) == publication['runtimeFiles'][name]

proof = {'status': 'RUNNING_NOT_ACCEPTANCE', 'fixedCommit': publication['fixedCommit'], 'startedAtUtc': now(),
         'actualExpectedRuleInputs': publication['actualRuleInputs'], 'frozenInputs': files, 'lockAtStart': locked(),
         'ordinaryBlankOpeningRealSqlNativeVisibleWholeCardCertified': False}
process = power = None
try:
    verify()
    output = n / 'actual-controlled-v2'
    assert not output.exists()
    with (n / 'controlled-probe-execution-v2.log').open('x') as log:
        process = subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet', str(runtime / 'probe.dll'), str(output)], cwd=runtime,
                                   stdout=log, stderr=subprocess.STDOUT)
        power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(process.pid)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        proof.update(ownProbePid=process.pid, boundIdleSleepAssertionPid=power.pid)
        code = process.wait(timeout=180)
    proof['exitCode'] = code
    assert code == 0, 'Original controlled prefix and error log retained.'
    receipt = json.loads((output / 'receipt.json').read_text())
    assert receipt['status'] == 'PASS_CONTROLLED_REAL_COMMAND_PHOENIX_LEAVE_REENTER_AND_OLD_TRIGGER_NOOP'
    assert receipt['actualRuleInputs'] == publication['actualRuleInputs']
    proof.update(status='PASS_CURRENT_FIXED_CONTROLLED_LEGAL_REENTRY_ORIGINAL_REPLAY', actualReceipt=receipt,
                 originalFrameSha256=sha(output / 'legal-reentry-original-frame.json.gz'))
except BaseException as error:
    proof.update(status='FAILED_ORIGINAL_CONTROLLED_PREFIX_RETAINED', errorType=type(error).__name__, errorMessage=str(error))
    raise
finally:
    if process is not None and process.poll() is None:
        process.terminate(); process.wait(timeout=20)
    if power is not None:
        power.wait(timeout=10)
        proof['boundIdleSleepAssertionEnded'] = power.poll() is not None
    verify()
    proof.update(finishedAtUtc=now(), lockAtEnd=locked(), allFrozenInputsAndAll3302CurrentSourcesStillExact=True)
    out.write_text(json.dumps(proof, indent=2) + '\n')
print(proof['status'], flush=True)
