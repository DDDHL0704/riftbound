import hashlib
import json
import pathlib
import sys

source = pathlib.Path(sys.argv[1]).resolve()
expected = json.loads((source.parent / "publisher-pre-execution-python-parser-diagnostic-v1.json").read_text(encoding="utf-8"))["sourceSha256"]
raw = source.read_bytes()
assert hashlib.sha256(raw).hexdigest() == expected
code = compile(raw, str(source), "exec")
exec(code, {"__file__": str(source), "__name__": "__main__"})
