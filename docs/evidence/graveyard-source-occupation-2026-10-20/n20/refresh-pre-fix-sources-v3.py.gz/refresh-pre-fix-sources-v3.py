import concurrent.futures,datetime,gzip,hashlib,json,pathlib,tempfile,urllib.request
n=pathlib.Path(__file__).resolve().parent;root=n.parents[2]
old=json.loads((root/'data/official/upstream/2026-10-16/source-refresh-20261015T160523Z/card-catalog.zh-CN.json').read_text())['cards']
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda raw:hashlib.sha256(raw).hexdigest()
base='https://lol-api.playloltcg.com';jobs=[('rules-directory',base+'/xcx/gameRule/getGameRuleList',{'pageNum':1,'pageSize':1000},None)]
for label,name in [('phoenix','不朽凤凰'),('decree','帝国谕令'),('guillotine','诺克萨斯断头台'),('windwall','风之障壁'),('repulse','击退'),('quick-counter','极速反制')]:
 jobs.append((label,base+'/xcx/card/searchCardCraftWeb',{'pageNum':1,'pageSize':100,'searchContent':name,'cardCategoryList':[],'cardColorList':[],'rarityList':[],'productCodeList':[]},None))
jobs += [('core','https://cdn.playloltcg.com/lol/2026/10/2026-10-10/a21ead876c6b44d6abe386b6ae54ea28.pdf',None,'var/qa/colorless-token-haste-20261016/DOC-01-current.pdf'),('faq','https://cdn.playloltcg.com/lol/2026/08/2026-08-13/612b1cd53f9f41baaf3c8734c1881a3b.pdf',None,'var/qa/porobot-20261015/resume-DOC-06.pdf')]
def acquire(job):
 label,url,payload,canonical=job
 receipt=n/('source-receipt-'+label+'-v3.json');assert not receipt.exists()
 r={'label':label,'url':url,'request':payload,'startedAtUtc':now(),'region':'CN','language':'zh-CN','individualPublicationDate':None,'individualEffectiveDate':None}
 try:
  req=urllib.request.Request(url,data=None if payload is None else json.dumps(payload,ensure_ascii=False).encode(),headers={'Content-Type':'application/json','User-Agent':'Riftbound official source audit'})
  with urllib.request.urlopen(req,timeout=30) as response:
   r.update(httpStatus=response.status,httpDate=response.headers.get('Date'),resolvedUrl=response.url)
   if canonical:
    digest=hashlib.sha256();size=0
    with tempfile.NamedTemporaryFile(dir=n,delete=False) as temp:
     path=pathlib.Path(temp.name)
     while True:
      chunk=response.read(1024*1024)
      if not chunk:break
      digest.update(chunk);size+=len(chunk);temp.write(chunk)
    original=root/canonical
    r.update(rawBytes=size,rawSha256=digest.hexdigest(),canonical=canonical,matchesRetainedCanonical=digest.hexdigest()==sha(original.read_bytes()))
    if r['matchesRetainedCanonical']:path.unlink();r['noDuplicatePdfRetained']=True
    else:
     target=n/(label+'-changed-'+digest.hexdigest()[:16]+'.pdf');path.rename(target);r['newVersionRequiresSeparateDeltaReview']=str(target.relative_to(root))
   else:
    raw=response.read();data=json.loads(raw);assert data['code']==0
    path=n/(label+'-pre-fix-refresh-v3.json.gz');assert not path.exists();path.write_bytes(gzip.compress(raw,mtime=0))
    result=data['result'];rows=result if isinstance(result,list) else result['list']
    r.update(rawBytes=len(raw),rawSha256=sha(raw),path=str(path.relative_to(root)),returnedRows=len(rows),reportedTotal=None if isinstance(result,list) else result['total'])
    if label!='rules-directory':
     r['exactRows']=[{'apiId':v['id'],'cardNo':v['cardNo'],'name':v['cardName'],'entireRowMatchesCn16':v==next((p for p in old if p['id']==v['id']),None),'fullRawRowSha256':sha(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())} for v in rows]
    else:
     prior=json.loads(gzip.decompress((root/'var/qa/phoenix-destroy-source-20261020/rules-directory.json.gz').read_bytes()))['result']
     prior=prior if isinstance(prior,list) else prior['list']
     r['allDirectoryRowsExactToPreviousIntake']=rows==prior
  r['status']='ACQUIRED_AND_EXACT_VERSION_COMPARED'
 except BaseException as error:
  r.update(status='FAILED_ACQUISITION_OR_LOCAL_ADAPTER_NOT_SOURCE_ABSENCE',errorType=type(error).__name__,errorMessage=str(error))
 finally:
  r['receivedAtUtc']=now();receipt.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
 return r
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:records=list(pool.map(acquire,jobs))
proof={'status':'CURRENT_PRIMARY_CN_SOURCE_REFRESH_BEFORE_NEXT_BOUNDED_FIX','region':'CN','language':'zh-CN','applicableRulesBaseline':'2026-10-16','records':records,'allOriginalSourceDatesUniversesAndTemporalDeltasRetained':True,'newRuntimeRuleOrCanonicalSourceAdoption':False,'earlierTwoNewCardFaceReadbackManifest':'var/qa/graveyard-lifecycle-source-followup-20261020/current-source-intake-v1.json'}
(n/'pre-fix-current-source-refresh-v3.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
assert all(r['status']=='ACQUIRED_AND_EXACT_VERSION_COMPARED' for r in records)
print([(r['label'],r.get('returnedRows'),r.get('matchesRetainedCanonical'),r.get('allDirectoryRowsExactToPreviousIntake'),all(q['entireRowMatchesCn16'] for q in r.get('exactRows',[]))) for r in records])
