import copy
import datetime
import gzip
import hashlib
import importlib.util
import json
import os
import pathlib
import subprocess
import xml.etree.ElementTree as ET

root = pathlib.Path.cwd()
work = pathlib.Path(__file__).resolve().parent
evidence = root / 'docs/evidence/graveyard-source-occupation-2026-10-20'
identity = 'graveyard-source-reference-occupation-and-original-generation-2026-10-20'
base = 'e262ebf164e448cc9738d94db8e557f302cfc295'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())

def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def pin(path, role=None):
    return {'path': str(path.relative_to(root)), 'sha256': sha(path), 'role': role or path.stem}

assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == base
assert not evidence.exists()
check = load(work / 'only-check-retention-and-disposition-v1.json')
terminal = load(work / 'only-check-terminal-integrity-v1.json')
assert check['status'] == 'SOLE_CHECK_ALL_CASES_PASS' and check['failed'] == check['skipped'] == 0
assert check['cases'] == 13107 and check['methods'] == 7467 and check['all7NewSourceOccupationCasesPassed']
assert check['all13100OriginalCaseMultisetRetained'] and check['all7464OriginalMethodsRetained']
assert terminal['allDeclaredInputsAndRuntimeFilesStable'] and terminal['boundIdleSleepAssertionEnded']
focus = load(work / 'affected-original-full-games-and-shared-consumers-v5-verification.json')
assert focus['cases'] == 133 and focus['methods'] == 63 and len(focus['actualOriginalFullGames']) == 4
assert all(sha(root / p) == value for p, value in focus['sourceHashes'].items())
retention = load(work / 'all-e262-test-tool-and-original-fullgame-source-retention-v1.json')
assert not retention['changedOriginalPaths'] and retention['originalFullGameMethodCount'] == 143
current_sources = load(work / 'pre-fix-current-source-refresh-v3.json')
assert all(row['status'] == 'ACQUIRED_AND_EXACT_VERSION_COMPARED' for row in current_sources['records'])
assert all(row.get('matchesRetainedCanonical', True) for row in current_sources['records'])
assert all(all(card['entireRowMatchesCn16'] for card in row.get('exactRows', [])) for row in current_sources['records'])
fixed_path = root / 'var/qa/destruction-fixed-e262-20261020'
fixed = load(fixed_path / 'locked-fixed-candidate-continuation-checkpoint-v2.json')
assert fixed['status'].startswith('PASS_BOUNDED_LOCKED_FIXED')
old_native_current = fixed['actualServerReleaseRuleInputs']
manifest_path = root / 'docs/audit/current-manifest.json'
reviews_path = root / 'docs/evidence/rules-reaudit-2026-10-11/review-decisions.json'
prior = load(manifest_path); original_reviews = load(reviews_path)
assert len(prior['reviewContexts']) == 57 and len(prior['acceptanceGates']) == 234 and len(original_reviews['reviews']) == 142
old_ids = set(json.loads(gzip.decompress((root / 'docs/evidence/destruction-graveyard-2026-10-20/remaining-obligation-ids.json.gz').read_bytes())))
assert len(old_ids) == 16903
(work / 'pre-occupation-original-current-manifest.json.gz').write_bytes(gzip.compress(manifest_path.read_bytes(), mtime=0))
(work / 'pre-occupation-original-review-decisions.json.gz').write_bytes(gzip.compress(reviews_path.read_bytes(), mtime=0))
ordinary_work = root / 'var/qa/graveyard-source-ordinary-continuation-20261020'
ordinary = load(ordinary_work / 'ordinary-two-format-original-prefix-closure-v1.json')
assert ordinary['acceptedCommands'] == 232 and ordinary['events'] == 964 and ordinary['coldRestores'] == 10 and ordinary['originalNextCommandsMatched'] == 8
assert ordinary['actualRuleInputs'] == check['actualConformanceDebugRuleInputs']
evidence.mkdir(parents=True)
archives = []
exclude = {'bin', 'obj', '__pycache__', 'fixed-api', 'frozen-sql-v1', 'native-current'}
raw = {'.json', '.jsonl', '.gz', '.zip', '.png', '.jpg', '.jpeg', '.webp'}
text = {'.py', '.cs', '.csproj', '.trx', '.log', '.md', '.c', '.txt', '.yml', '.yaml'}
for folder, prefix in [(work, 'n20'), (fixed_path, 'candidate-e262'), (ordinary_work, 'ordinary-prefix')]:
    for path in sorted(folder.rglob('*')):
        relative = path.relative_to(folder)
        if not path.is_file() or exclude & set(relative.parts) or any(p.endswith('.app') for p in relative.parts):
            continue
        if path.suffix not in raw | text:
            continue
        compressed = path.suffix in text
        target = evidence / prefix / relative
        if compressed:
            target = target.with_name(target.name + '.gz')
        target.parent.mkdir(parents=True, exist_ok=True)
        if compressed:
            target.write_bytes(gzip.compress(path.read_bytes(), mtime=0))
        else:
            os.link(path, target)
        archives.append({'originalPath': str(path.relative_to(root)), 'originalSha256': sha(path),
                         'originalBytes': path.stat().st_size, 'canonical': pin(target),
                         'gzipOriginalBytes': compressed, 'samePhysicalFileHardlinked': not compressed})

ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
trx = work / 'only-check/check/results.trx'
tree = ET.parse(trx)
defs = {u.get('id'): u.find('t:TestMethod', ns) for u in tree.findall('.//t:UnitTest', ns)}
observations = []
for row in tree.findall('.//t:UnitTestResult', ns):
    method = defs[row.get('testId')]
    full = method.get('className').split(',')[0] + '.' + method.get('name')
    if '.DestructionGraveyardSourceOccupationTests.' not in full:
        continue
    observations.append({'key': hashlib.sha256((full + '\n' + row.get('testName')).encode()).hexdigest(),
                         'method': full, 'actualCaseName': row.get('testName'), 'outcome': row.get('outcome'),
                         'sourceTrxSha256': sha(trx)})
assert len(observations) == 7 and len({r['method'] for r in observations}) == 3
branch_specs = [
    ('SIBLING_SKILL_REFERENCES_DO_NOT_OCCUPY_THE_SOURCE_CARD', 'Both paid skills independently reference the same graveyard card; either original order permits the first normal effect play.',
     [r['key'] for r in observations if 'SiblingEarnedSkills' in r['method']]),
    ('LEGIT_SOURCE_REENTRY_NEW_CONFIRMATION_AND_OLD_GENERATION_NOOP', 'Actual extra-cost destruction creates a new graveyard incarnation and its own confirmation. Declining it never lets the old paid ability borrow that new incarnation.',
     [r['key'] for r in observations if 'SiblingEarnedSkills' in r['method'] and 'reenter: True' in r['actualCaseName']]),
    ('REAL_STACK_CARD_OCCUPATION_REJECTION_REMAINS_ATOMIC', 'A real spell card occupying the stack still rejects duplicate play without state or event changes.',
     [r['key'] for r in observations if 'ActualSpellCardOccupyingStack' in r['method']]),
    ('TYPED_SKILL_DESCRIPTORS_DO_NOT_CREATE_CHOSEN_COUNTER_TARGETS', 'The two typed skills have ability descriptors. Spell-only and chosen-friendly-unit counter previews and commands remain independently rejected for these automatic references.',
     [r['key'] for r in observations if 'TypedAutomaticSkills' in r['method']])]
assert [len(row[2]) for row in branch_specs] == [4, 2, 1, 2]
source_records = load(work / 'current-core-source-reference-readback-v1.json')['clauses']
source_records += load(work / 'current-core-cost-instruction-and-counter-scope-readback-v2.json')['additionalCostAndNonTargetSourceClauses']
printings = ['OGN-037/298', 'OGN-221/298', 'OGN-254/298', 'UNL-180/219', 'UNL-142/219', 'OGN-064/298', 'UNL-106/219', 'SFD-045/221', 'OGN-010/298']
parents = load(root / 'docs/evidence/destruction-graveyard-2026-10-20/source-manifest.json')['existingParentObligationIds']
source_refs = sorted(set(printings + [row['exactUnifiedRuleId'] for row in source_records]
                         + [p.removeprefix('CARD:').removeprefix('RULE:') for p in parents]))
source_manifest = {
    'recordedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'region': 'CN', 'language': 'zh-CN',
    'applicableAsOf': '2026-10-16', 'observedAtAsiaShanghai': '2026-10-20', 'baseCommit': base,
    'includesExplicitUncommittedImplementation': True, 'exactPrintings': printings, 'sourceRefs': source_refs,
    'existing22ParentObligationIds': parents,
    'currentNineRequestSourceRefresh': pin(evidence / 'n20/pre-fix-current-source-refresh-v3.json'),
    'additionalTwoCardApisAndOriginalPixels': pin(evidence / 'n20/current-source-intake-v1.json'),
    'additionalTwoOriginalCardFaceReadback': pin(evidence / 'n20/source-pixel-readback-v1.json'),
    'currentCoreClauses': pin(evidence / 'n20/current-core-source-reference-readback-v1.json'),
    'costInstructionAndNonTargetClauses': pin(evidence / 'n20/current-core-cost-instruction-and-counter-scope-readback-v2.json'),
    'otherFiniteTypedStackConsumersRemainOpen': pin(evidence / 'n20/shared-typed-stack-finite-consumer-followup-v2.json'),
    'unchangedSourceBytesNotNewTemporalDelta': True, 'unknownSinglePrintingDatesRemainNull': True,
    'originalE262ControlledCounterexample': pin(evidence / 'n20/original-prefix-independent-verification-v2.json'),
    'currentConformanceDebugRuleInputs': check['actualConformanceDebugRuleInputs'],
    'priorFixedE262ReleaseRuleInputsOnly': old_native_current,
    'oldE262LockedNativeSqlProofOnly': pin(evidence / 'candidate-e262/locked-fixed-candidate-continuation-checkpoint-v2.json'),
    'separateRuntimeVersionsNeverInterchanged': True, 'currentControlledLifecycleCases': 7,
    'currentSiblingTwoFormatOrdinaryPrefixProof': pin(evidence / 'ordinary-prefix/ordinary-two-format-original-prefix-closure-v1.json'),
    'additionalExactLegionCurrentSourceReceipt': pin(evidence / 'ordinary-prefix/legion-current-source-receipt-v2.json'),
    'newSiblingRealSql': 'OPEN', 'ordinaryLegitimateReentry': 'OPEN', 'currentVisibleNativeProduct': 'OPEN', 'newFixedFull': 'PENDING',
    'physicalWindows': 'OPEN', 'wholePrintingCertified': False, 'semanticCoverageCertified': False}
write(evidence / 'source-manifest.json', source_manifest)
source_pin = pin(evidence / 'source-manifest.json')
matrix = {'status': 'CURRENT_SEVEN_CONTROLLED_CASES_PRECISE_BRANCH_MATRIX_NOT_WHOLE_CARD_CERTIFICATION',
          'actualRuleInputs': check['actualConformanceDebugRuleInputs'], 'observations': observations,
          'branches': [{'id': name, 'scope': scope, 'actualCaseKeys': keys} for name, scope, keys in branch_specs],
          'ordinarySiblingTwoFormatPrefixWitnesses': pin(evidence / 'ordinary-prefix/ordinary-two-format-original-prefix-closure-v1.json'),
          'siblingSqlOtherOrdinaryBranchesAndVisibleScopeStillOpen': True}
write(evidence / 'bounded-behavior-matrix.json', matrix)
matrix_pin = pin(evidence / 'bounded-behavior-matrix.json')
evidence_paths = [evidence / 'n20/only-check-retention-and-disposition-v1.json',
                  evidence / 'n20/affected-original-full-games-and-shared-consumers-v5-verification.json',
                  evidence / 'n20/all-e262-test-tool-and-original-fullgame-source-retention-v1.json',
                  evidence / 'n20/original-prefix-independent-verification-v2.json',
                  evidence / 'n20/focus-first-four-failures-new-test-scope-disposition-v1.json',
                  evidence / 'candidate-e262/locked-fixed-candidate-continuation-checkpoint-v2.json',
                  evidence / 'ordinary-prefix/ordinary-two-format-original-prefix-closure-v1.json',
                  evidence / 'ordinary-prefix/independent-core-original-verification-v3.json',
                  evidence / 'ordinary-prefix/independent-china-original-verification-v3.json',
                  evidence / 'ordinary-prefix/original-v1-prefix-independent-verification-v1.json']
check_text = (f"唯一check共{check['cases']}例/{check['methods']}个唯一方法全过、零失败零跳过；"
              f"原13100例多重集合和7464方法保留，新增7例/3方法全过。{check['declaredSourceInputCount']}源码输入、"
              f"{check['runtimeFileCount']}执行载荷在检查期间保持精确一致，没有第二次check")
doc_path = root / 'docs/GRAVEYARD_SOURCE_OCCUPATION_AUDIT_2026-10-20.md'
doc = (work / doc_path.name).read_text().replace('@CHECK_RESULT@', check_text)
doc = doc.replace('@GOVERNANCE_RESULT@', '统一清单现143审查、58上下文、235门禁、16908剩余义务；原142审查、57上下文快照、234门禁、16903义务及五来源增量完整保留，治理0错误，全量语义未认证')
assert '@CHECK_' not in doc and '@GOVERNANCE_' not in doc
doc += '\n[精确来源与运行身份](evidence/graveyard-source-occupation-2026-10-20/source-manifest.json) · [限定行为及实际用例矩阵](evidence/graveyard-source-occupation-2026-10-20/bounded-behavior-matrix.json)\n'
doc_path.write_text(doc)
reviews = copy.deepcopy(original_reviews)
reviews['reviews'].append({'id': identity, 'scope': 'CN/zh-CN current core effective2026-10-16; independent skill source/card occupation and original graveyard incarnations only.',
    'status': 'LIMITED_CURRENT_SEVEN_CASES133_ADJACENT_TWO_FORMAT_ORDINARY_PREFIX_SOLECHECK_PASS_SQL_FIXEDFULL_PRODUCT_OPEN',
    'subjects': printings, 'ruleRecords': [row['id'] for row in source_records], 'pendingRuleRecords': [],
    'sourceManifest': source_pin, 'auditDocument': str(doc_path.relative_to(root)),
    'evidence': [str(p.relative_to(root)) for p in evidence_paths] + [matrix_pin['path']],
    'exclusions': ['WHOLE_PRINTING_OTHER_CONSUMERS_AND_GLOBAL_SOURCE_GAPS', 'NEW_SIBLING_REAL_SQL_AND_OTHER_ORDINARY_BRANCHES', 'CURRENT_FIXED_FULL', 'VISIBLE_NATIVE_PRODUCT', 'PHYSICAL_WINDOWS']})
write(reviews_path, reviews)
spec = importlib.util.spec_from_file_location('governance', root / 'scripts/audit/check-project-governance.py')
checker = importlib.util.module_from_spec(spec); spec.loader.exec_module(checker)
revision = checker.digest(checker.gameplay_inputs(root))
manifest = copy.deepcopy(prior); rebindings = []
for key, context in manifest['reviewContexts'].items():
    changes = []
    for field in ['implementation', 'verificationSources']:
        for ref in context.get(field, []):
            current = sha(root / ref['path'])
            if current != ref['sha256']:
                changes.append({'field': field, 'path': ref['path'], 'previousSha256': ref['sha256'], 'currentSha256': current})
                ref['sha256'] = current
    context.setdefault('implementationPinUpdates', []).append({'batch': identity, 'changes': changes,
        'previousCurrentMetadata': {f: context.get(f) for f in ['currentInputRevision', 'currentImplementationCommit', 'currentImplementationIncludesUncommittedChanges']},
        'previousEntireContextPreservedIn': str((evidence / 'n20/pre-occupation-original-current-manifest.json.gz').relative_to(root)),
        'scope': 'Explicit current pin rebind only. Original evidence versions, semantic ranges and dates retained; new fixed full required.'})
    context.update(currentInputRevision=revision, currentImplementationCommit=base, currentImplementationIncludesUncommittedChanges=True,
                   ciState='PENDING', revalidationReason='Shared stack source/card occupation and typed-ability classification changed.')
    rebindings.append({'review': key, 'previousContextSha256': checker.digest(prior['reviewContexts'][key]), 'pinChanges': changes})
branches = [{'id': name, 'sourceRefs': source_refs, 'sourceManifest': source_pin, 'state': 'RECORDED', 'branchScope': scope,
    'decision': {'state': 'OPEN', 'reason': 'Limited current controlled behavior, two exact-format sibling ordinary prefixes and independent safety guards. New fixed full, real SQL, other ordinary branches and current visible/physical product remain open.'},
    'semanticReview': 'LIMITED_CURRENT_CN_EXACT_SOURCE_AND_BRANCHES', 'implementation': 'SHARED_TYPED_SKILL_SOURCE_CARD_OCCUPATION_AND_GENERATION_GUARDS',
    'testExecution': 'CURRENT_SEVEN_CASES133_ADJACENT_FOUR_ORIGINAL_SCORE_GAMES_AND_SOLECHECK_PASS',
    'ordinaryTestExecution': 'TWO_EXACT_FORMAT_BLANK_SEED0_SIBLING_PREFIXES_INDEPENDENTLY_READ' if name == 'SIBLING_SKILL_REFERENCES_DO_NOT_OCCUPY_THE_SOURCE_CARD' else 'OPEN',
    'realSql': 'OPEN',
    'actualCaseKeys': keys, 'actualTestMatrix': matrix_pin, 'fixedCommitCi': 'PENDING_NEW_FIXED_FULL', 'productAcceptance': 'OPEN',
    'wholePrintingCertified': False, 'remaining': ['CORRESPONDING_REAL_SQL', 'OTHER_ORDINARY_BRANCHES', 'NEW_FIXED_FULL', 'VISIBLE_NATIVE_CONTROLS_PAIRED_RECONNECT_NORMAL_SCORE_REPLAY', 'PHYSICAL_WINDOWS', 'OTHER_CONSUMERS_AND_WHOLE_PRINTING']}
    for name, scope, keys in branch_specs]
manifest['inputs']['reviews'] = pin(reviews_path, prior['inputs']['reviews'].get('role', 'reviews'))
manifest['reviewContexts'][identity] = {'evidenceCommit': base, 'currentImplementationCommit': base,
    'currentImplementationIncludesUncommittedChanges': True, 'evidenceCommitScope': 'Basee262 plus exact declared source/test inputs. Prior e262 Release/native remains a separate version.',
    'currentInputRevision': revision, 'ciState': 'PENDING', 'ciReceipts': [], 'region': 'CN', 'language': 'zh-CN', 'applicableAsOf': '2026-10-16',
    'sourceManifest': source_pin, 'implementation': [pin(root / p, 'implementation') for p in ['src/Riftbound.Engine/CoreRuleEngine.cs', 'src/Riftbound.Engine/StackObjectRules.cs']],
    'verificationSources': [pin(root / 'tests/Riftbound.ConformanceTests/DestructionGraveyardSourceOccupationTests.cs', 'verification')],
    'evidence': [pin(p) for p in evidence_paths] + [matrix_pin], 'branches': branches}
manifest['acceptanceGates'].append({'id': 'GRAVEYARD_SOURCE_OCCUPATION_FIXED_FULL_SIBLING_SQL_VISIBLE_AND_WINDOWS', 'state': 'OPEN',
    'region': 'CN', 'language': 'zh-CN', 'sourceManifest': source_pin, 'requirement': 'Current fixed full all original cases/methods/Theories/143 games110pairs seeds/replay and45 SQL execution identities; additionally current sibling real SQL, remaining ordinary branches, current visible paired native and physical Windows. Two-format sibling ordinary prefixes are separately passed.',
    'semanticReview': 'LIMITED_BRANCHES_ONLY', 'implementation': 'SHARED_ABILITY_SOURCE_CARD_OCCUPATION',
    'testExecution': 'CURRENT_SEVEN_AND133_ADJACENT_TWO_ORDINARY_PREFIXES_AND_SOLECHECK_PASS', 'fixedCommitCi': 'PENDING', 'productAcceptance': 'OPEN', 'wholePrintingCertified': False})
manifest['currentGraveyardSourceOccupationInputChange'] = source_pin
write(manifest_path, manifest)
result = checker.current_audit(root, manifest)
assert result['governanceValid'], result['errors']
new_ids = {row['id'] for row in result['remainingObligations']}
assert old_ids <= new_ids and len(new_ids - old_ids) == 5 and len(new_ids) == 16908
assert reviews['reviews'][:-1] == original_reviews['reviews']
assert manifest['acceptanceGates'][:-1] == prior['acceptanceGates']
assert manifest['laterSourceDeltas'] == prior['laterSourceDeltas']
assert set(parents) <= new_ids
write(evidence / 'current-context-rebindings.json', {'previousEntireContextSnapshot': pin(evidence / 'n20/pre-occupation-original-current-manifest.json.gz'),
    'all57OriginalContextsPreservedBeforeExplicitRebind': True, 'rebindings': rebindings, 'currentInputRevision': revision})
write(evidence / 'unified-obligation-retention.json', {'priorRemainingObligations': 16903, 'currentRemainingObligations': len(new_ids),
    'all16903OriginalIdsAnd22OldParentsRetained': True, 'newObligationIds': sorted(new_ids - old_ids),
    'all142OldSemanticReviewDictionariesExact': True, 'all57OriginalContextsPreservedBeforeExplicitRebind': True,
    'all234OldGateDictionariesAndFiveSourceDeltasExact': True, 'currentReviews': 143, 'currentContexts': 58, 'currentGates': 235,
    'allOriginal1740Printings36HistoricalDocuments14293BlocksDatesEn8GapsCn236DispositionsAndOtherSourceGapsRetained': True, 'semanticCoverageCertified': False})
(evidence / 'remaining-obligation-ids.json.gz').write_bytes(gzip.compress(json.dumps(sorted(new_ids), ensure_ascii=False, indent=2).encode() + b'\n', mtime=0))
write(evidence / 'governance-validation.json', {'governanceValid': True, 'errors': [], 'remainingObligationCount': len(new_ids),
    'remainingIds': pin(evidence / 'remaining-obligation-ids.json.gz'), 'currentInputRevision': revision, 'semanticCoverageCertified': False})
write(evidence / 'archive-map.json', {'records': archives, 'noNativePackageRuntimeWholeCheckoutDatabaseOrDuplicatePdfCopied': True})
status = root / 'docs/PROJECT_STATUS.md'; old_status = status.read_text(); assert old_status.startswith('# 当前项目状态\n')
intro = f'''\n2026-10-20 当前批次：[技能来源引用与墓地再次进入](GRAVEYARD_SOURCE_OCCUPATION_AUDIT_2026-10-20.md)。CN/zh-CN、生效基线10-16，14项规则目录、六张精确API牌及当前核心/FAQ重新取得不变，另实看破败之咒和残酷复活卡面。旧固定e262受控原9命令8接受/1拒绝、22事件及独立原回放证明：第二条已付费技能被误当成卡牌占用堆叠。仅补两个新技能的共享类型识别和出牌占用区别，无卡牌特例、迁移或DSL。\n\n新增7例/3方法、相邻133例/63唯一方法及4个受影响原完整得分/回放用例通过。{check_text}。1858原测试/工具/夹具字节和执行位、九份FullGame143方法、110配对及原种子/胜利/回放断言保留，45默认SQL身份/原序/断言和四片工作流未改。初始新测试四条失败、普通/受控门禁范围、方法计数及原生读取器旧具体案例假设分别保留并明确纠正，不改写旧原局。\n\n代码改动前固定e262 Release591dc123锁屏SQL6/648命令2772事件、44冷恢复36原下一命令20拒绝；默认Main双端结果7/12、真实过期投降重试8/19、双生产网关冷恢复正常8:0（46/308）、真实socket及15身份拒绝/0泄露与独立全部历史字段/null/原回放通过。原172/178/184审计子集和35原生七表直接补核不变，当前190/39只读后全部七表不变，专用库正常停止。此旧固定实证不提升本批新Debug或新固定候选。\n\n统一清单143审查/58上下文/235门禁/16908义务，原16903义务、142审查、57上下文快照、234门禁和五来源增量完整保留，治理0错误；全量语义未认证。新双技能普通空白开局在两赛制以派生合法牌组/原seed0共232命令964事件、10冷恢复8原下一命令及独立全历史私有视图/回放通过；三张SFD018填充改为破败之咒逐项声明，原81后续意图及原root牌组/夹具未改。首轮迅捷时机假设的92命令91接受/1原子拒绝407事件独立验证并保留。再次入墓仍受控范围，对应新真实SQL、其他普通分支/消费者/复制/控制/替代、全部来源缺口、新固定full、当前可见原生/双端及Windows实机分别OPEN。锁屏持续执行，仅最新可用e262 A/B和两平台各一规范包，无新SDK/整份checkout/数据库，用户Godot34426未触碰。Goal active / NOT READY。\n\n以下保留此前批次原始限定记录；当前范围以上述精确收据为准。\n'''
status.write_text('# 当前项目状态\n' + intro + old_status[len('# 当前项目状态\n'):])
write(work / 'canonical-source-occupation-publication-v1.json', {'status': 'CANONICAL_LIMITED_SOURCE_OCCUPATION_REVIEW_WRITTEN',
    'reviews': 143, 'contexts': 58, 'gates': 235, 'remainingObligations': 16908, 'newFixedFullSiblingRealSqlOtherOrdinaryBranchesVisibleWindows': 'OPEN'})
print('CANONICAL_LIMITED_SOURCE_OCCUPATION_REVIEW_143_58_235_16908_WRITTEN', flush=True)
