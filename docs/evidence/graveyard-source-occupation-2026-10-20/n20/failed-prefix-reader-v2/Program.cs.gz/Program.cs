using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Nodes;
using Riftbound.CardCatalog;
using Riftbound.Contracts;
using Riftbound.Engine;

if (args.Length != 1) throw new Exception("A fresh evidence directory is required.");
var output = Path.GetFullPath(args[0]);
Directory.CreateDirectory(output);
var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
var catalog = await OfficialCardCatalog.LoadDefaultAsync();
const string phoenix = "OGN·037/298";
const string ruin = "UNL-180/219";
const string revive = "UNL-142/219";
const string poro = "OGN·210/298";
var cards = new Dictionary<string, CardObjectState>();
var locations = new Dictionary<string, ObjectLocationState>();
void Add(string id, string no, string owner, string zone, string? field = null)
{
    var row = catalog.Cards.Single(c => c.CardNo == no); var tags = new List<string>();
    if (row.CardCategoryNameList.Any(c => c.Contains("单位", StringComparison.Ordinal))) tags.Add(CardObjectTags.UnitCard);
    if (row.CardCategoryNameList.Any(c => c.Contains("法术", StringComparison.Ordinal))) tags.Add(CardObjectTags.SpellCard);
    if (row.CardCategoryNameList.Contains("战场")) tags.Add(P6TokenFactoryCatalog.BattlefieldCardTag);
    tags.AddRange(row.CardColorList.Select(color => "COLOR:" + color));
    cards[id] = new(id, cardNo: no, power: row.Power.GetValueOrDefault(), manaCost: row.Energy.GetValueOrDefault(), ownerId: owner, controllerId: owner, tags: tags);
    locations[id] = new(owner, zone, field);
}
Add("PHOENIX", phoenix, "P1", "GRAVEYARD");
Add("RUIN", ruin, "P1", "HAND"); Add("REVIVE", revive, "P1", "HAND");
Add("OWN", poro, "P1", "BATTLEFIELD", "F"); Add("ENEMY", poro, "P2", "BATTLEFIELD", "OTHER");
Add("F", "OGN·278/298", "P1", "BATTLEFIELD", "F"); Add("OTHER", "OGN·294/298", "P2", "BATTLEFIELD", "OTHER");
var initial = new MatchState("CONTROLLED-LEGAL-PHOENIX-REENTRY-E262", 0, 5, "P1", new Dictionary<string, string> { ["P1"] = "P1", ["P2"] = "P2" },
    status: MatchStatuses.InProgress, phase: MatchPhases.Main, timingState: TimingStates.NeutralOpen,
    cardObjects: cards, objectLocations: locations,
    playerZones: new Dictionary<string, PlayerZones> {
        ["P1"] = PlayerZones.Empty with { Hand = ["RUIN", "REVIVE"], Graveyard = ["PHOENIX"], Battlefields = ["F", "OWN"] },
        ["P2"] = PlayerZones.Empty with { Battlefields = ["OTHER", "ENEMY"] } },
    runePools: new Dictionary<string, RunePool> {
        ["P1"] = new(40, 40, new Dictionary<string, int> { ["red"] = 20, ["yellow"] = 10, ["purple"] = 10 }),
        ["P2"] = new(30, 30, new Dictionary<string, int> { ["red"] = 20, ["orange"] = 10 }) }) { CardPlays = new(5, [], []) };
var journalPath = Path.GetFullPath(Environment.GetEnvironmentVariable("RIFTBOUND_ORIGINAL_FAILED_JOURNAL") ?? throw new Exception("Exact original journal required."));
var raw = await File.ReadAllTextAsync(journalPath);
var entries = JsonSerializer.Deserialize<List<MatchJournalEntry>>(raw, json) ?? throw new Exception("Original attempts required.");
if (!JsonNode.DeepEquals(JsonNode.Parse(raw), JsonSerializer.SerializeToNode(entries, json))) throw new Exception("Every original field/null must survive typed read exactly.");
if (entries.Count != 9 || entries.Count(e => e.Accepted) != 8 || entries[^1].Accepted || entries[^1].CommandType != "PLAY_CARD"
    || entries[^1].ErrorMessage != "PLAY_CARD source is already pending on the stack." || entries[^1].StartedTick != entries[^1].CompletedTick
    || entries[^1].StartedEventSequence != entries[^1].CompletedEventSequence) throw new Exception("Exact original accepted/rejected prefix required.");
var last = entries[^1]; var commands = entries.Select(e => new RecoveredCommand(e.PlayerId, e.ClientIntentId, e.CommandType, e.RawCommand,
    e.StartedTick, e.CompletedTick, e.StartedEventSequence, e.CompletedEventSequence, e.Accepted, e.ErrorMessage) { RuleInputs = e.RuleInputs }).ToArray();
var events = entries.SelectMany(e => e.Events.Select((ev,i) => new RecoveredEvent(e.StartedEventSequence+i+1,e.CompletedTick,i,ev))).ToArray();
var state = last.AuthoritativeState; var sequence = last.CompletedEventSequence;
var views = state.Seats.Keys.ToDictionary(id => id, id => new RecoveredPlayerView(id,state.Tick,sequence,last.Snapshots[id],state.Tick,sequence,last.Prompts[id]));
var spectator = MatchReplayRedactor.BuildSpectatorFrame(state.RoomId,state.Tick,sequence,[],state);
var errors = MatchRecoveryValidator.Validate(state.RoomId,sequence,commands,events,views,state,state.Tick,spectator);
if (errors.Count != 0) throw new Exception("Original accepted state and rejected-intent frame validation: " + string.Join(';',errors));
var frame = new MatchRecoveryFrame(state.RoomId,state.Tick,sequence,commands,events,views,errors,state,initial,spectator);
var ordinaryGateErrors = await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame,new CoreRuleEngine(),default);
var expectedOrdinaryErrors = new[] {
    "action-log replay initial state turn number 5 must be 1",
    "action-log replay initial state rune pool for P1 must be empty",
    "action-log replay initial state rune pool for P2 must be empty",
    "action-log replay initial state zones for P1 must be empty",
    "action-log replay initial state zones for P2 must be empty",
    "action-log replay initial state score players must match seats",
    "action-log replay initial state experience players must match seats",
    "action-log replay initial state card objects must be empty",
    "action-log replay initial state object locations must be empty",
    "action-log replay initial state status IN_PROGRESS must be SEATING",
    "action-log replay initial state phase MAIN must be ROOM",
    "action-log replay initial state timing state NEUTRAL_OPEN must be ROOM"
};
if (!ordinaryGateErrors.Order(StringComparer.Ordinal).SequenceEqual(expectedOrdinaryErrors.Order(StringComparer.Ordinal)))
    throw new Exception("The independent ordinary blank-opening gate must still reject this exact declared controlled initial position without widening its checks.");
var controlledReplay = await MatchActionLogReplayer.VerifyFinalStateAsync(initial,commands,state,new CoreRuleEngine(),default,events);
if (!controlledReplay.IsMatch) throw new Exception("All original controlled commands, rejected intent, events and final state must replay: " + string.Join(';',controlledReplay.Errors));
if (state.StackItems.Count != 1 || state.StackItems[0].GraveyardPlay?.Source != new ObjectBinding("PHOENIX",0)
    || state.PendingEffectPlay?.Parent.GraveyardPlay?.Source != new ObjectBinding("PHOENIX",0)
    || state.PendingEffectPlay.Sources.GetValueOrDefault("PHOENIX",-1) != 0 || state.CardObjects["PHOENIX"].ObjectGeneration != 0
    || !state.PlayerZones["P1"].Graveyard.Contains("PHOENIX")) throw new Exception("Independent original pending source/generation/zone proof failed.");
var leading = events.Count(e => e.Event.Kind == "TRIGGER_CONFIRMED");
if (leading != 2) throw new Exception("Both original one-mana/red leading fees must have been confirmed.");
await using(var file=new FileStream(Path.Combine(output,"original-nine-command-failed-prefix-frame.json.gz"),FileMode.CreateNew))
await using(var zip=new GZipStream(file,CompressionLevel.SmallestSize)) await JsonSerializer.SerializeAsync(zip,frame,json);
var result = new { status="PASS_INDEPENDENT_CONTROLLED_REPLAY_ORIGINAL_NINE_COMMAND_PREFIX_AND_ORDINARY_GATE_REJECTION",
    accepted=8,rejected=1,events=events.Length,originalEveryFieldAndNullRoundtripExact=true,originalRejectedStateAndSequenceAtomic=true,
    originalTwoLeadingConfirmations=leading,originalCurrentGraveyardSourceAndRemainingSkillBothGenerationZero=true,
    fullOriginalControlledReplayMatched=true, ordinaryBlankOpeningGateCorrectlyRejected=true, ordinaryGateErrors,actualRuleInputs=RuleInputIdentity.Current,declaredControlledInitialPosition=true,
    semanticBugNotFixed=true,ordinarySqlNativeWholeCardCertified=false };
await File.WriteAllTextAsync(Path.Combine(output,"receipt.json"),JsonSerializer.Serialize(result,json));
Console.WriteLine(JsonSerializer.Serialize(result,json));
