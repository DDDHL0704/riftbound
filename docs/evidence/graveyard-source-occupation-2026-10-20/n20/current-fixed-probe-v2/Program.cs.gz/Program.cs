using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Nodes;
using Riftbound.CardCatalog;
using Riftbound.Contracts;
using Riftbound.Engine;

if (args.Length != 1) throw new Exception("A fresh evidence directory is required.");
var output = Path.GetFullPath(args[0]);
Directory.CreateDirectory(output);
var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
var catalog = await OfficialCardCatalog.LoadDefaultAsync();
const string phoenix = "OGN·037/298";
const string ruin = "UNL-180/219";
const string revive = "UNL-142/219";
const string poro = "OGN·210/298";
var cards = new Dictionary<string, CardObjectState>();
var locations = new Dictionary<string, ObjectLocationState>();
void Add(string id, string no, string owner, string zone, string? field = null)
{
    var row = catalog.Cards.Single(c => c.CardNo == no); var tags = new List<string>();
    if (row.CardCategoryNameList.Any(c => c.Contains("单位", StringComparison.Ordinal))) tags.Add(CardObjectTags.UnitCard);
    if (row.CardCategoryNameList.Any(c => c.Contains("法术", StringComparison.Ordinal))) tags.Add(CardObjectTags.SpellCard);
    if (row.CardCategoryNameList.Contains("战场")) tags.Add(P6TokenFactoryCatalog.BattlefieldCardTag);
    tags.AddRange(row.CardColorList.Select(color => "COLOR:" + color));
    cards[id] = new(id, cardNo: no, power: row.Power.GetValueOrDefault(), manaCost: row.Energy.GetValueOrDefault(), ownerId: owner, controllerId: owner, tags: tags);
    locations[id] = new(owner, zone, field);
}
Add("PHOENIX", phoenix, "P1", "GRAVEYARD");
Add("RUIN", ruin, "P1", "HAND"); Add("REVIVE", revive, "P1", "HAND");
Add("OWN", poro, "P1", "BATTLEFIELD", "F"); Add("ENEMY", poro, "P2", "BATTLEFIELD", "OTHER");
Add("F", "OGN·278/298", "P1", "BATTLEFIELD", "F"); Add("OTHER", "OGN·294/298", "P2", "BATTLEFIELD", "OTHER");
var initial = new MatchState("CONTROLLED-LEGAL-PHOENIX-REENTRY-E262", 0, 5, "P1", new Dictionary<string, string> { ["P1"] = "P1", ["P2"] = "P2" },
    status: MatchStatuses.InProgress, phase: MatchPhases.Main, timingState: TimingStates.NeutralOpen,
    cardObjects: cards, objectLocations: locations,
    playerZones: new Dictionary<string, PlayerZones> {
        ["P1"] = PlayerZones.Empty with { Hand = ["RUIN", "REVIVE"], Graveyard = ["PHOENIX"], Battlefields = ["F", "OWN"] },
        ["P2"] = PlayerZones.Empty with { Battlefields = ["OTHER", "ENEMY"] } },
    runePools: new Dictionary<string, RunePool> {
        ["P1"] = new(40, 40, new Dictionary<string, int> { ["red"] = 20, ["yellow"] = 10, ["purple"] = 10 }),
        ["P2"] = new(30, 30, new Dictionary<string, int> { ["red"] = 20, ["orange"] = 10 }) }) { CardPlays = new(5, [], []) };
var journal = new Journal();
var session = new MatchSession(initial, new CoreRuleEngine(), journal);
var state = initial;
var checkpoints = new List<object>();
async Task<ResolutionResult> Act(string actor, GameCommand command)
{
    var name = "legal-reentry-" + journal.Entries.Count;
    var fields = JsonSerializer.SerializeToNode(command, command.GetType(), json)!.AsObject();
    fields["promptId"] = session.PromptFor(actor).PromptId; fields["snapshotTick"] = state.Tick;
    var result = await session.SubmitAsync(actor, name, command, JsonSerializer.SerializeToElement(fields, json), default);
    if (!result.Accepted) throw new Exception("Original intent rejected: " + result.ErrorMessage);
    state = result.State;
    var sequence = journal.Entries[^1].CompletedEventSequence;
    var snapshots = ResolutionResult.BuildSnapshots(state); var prompts = ResolutionResult.BuildPrompts(state);
    var views = state.Seats.Keys.ToDictionary(id => id, id => new RecoveredPlayerView(id, state.Tick, sequence, snapshots[id], state.Tick, sequence, prompts[id]));
    var spectator = MatchReplayRedactor.BuildSpectatorFrame(state.RoomId, state.Tick, sequence, [], state);
    var commands = journal.Commands(); var events = journal.Events();
    var errors = MatchRecoveryValidator.Validate(state.RoomId, sequence, commands, events, views, state, state.Tick, spectator);
    if (errors.Count != 0) throw new Exception("Original accepted state recovery: " + string.Join(';', errors));
    session = MatchSession.Restore(new(state.RoomId, state.Tick, sequence, commands, events, views, errors, state, initial, spectator), new CoreRuleEngine(), journal);
    checkpoints.Add(new { command = command.CmdType, state.Tick, hash = MatchStateHasher.Hash(state), phoenixGeneration = state.CardObjects["PHOENIX"].ObjectGeneration,
        state.PendingPayment, state.PendingEffectPlay, stack = state.StackItems.Select(i => new { i.StackItemId, i.SourceObjectId, i.GraveyardPlay }).ToArray() });
    return result;
}
async Task<ResolutionResult> Top() { await Act(state.PriorityPlayerId!, new PassPriorityCommand()); return await Act(state.PriorityPlayerId!, new PassPriorityCommand()); }
void Check(bool condition, string reason) { if (!condition) throw new Exception(reason); }
try
{
    await Act("P1", new PlayCardCommand("RUIN", ruin, [])); await Top();
    Check(state.TriggerQueue.Count == 2 && state.TriggerQueue.All(t => t.GraveyardPlay?.Source == new ObjectBinding("PHOENIX", 0)), "Two actually earned triggers retain the same original graveyard incarnation.");
    await Act("P1", new OrderTriggersCommand(OrderedTriggerIds: state.TriggerQueue.Select(t => t.TriggerId).ToArray()));
    for (var i = 0; i < 2; i++)
    {
        var cost = state.PendingPayment ?? throw new Exception("Both leading confirmations are required.");
        Check(cost.ManaCost == 1 && cost.PowerCostByTrait.GetValueOrDefault("red") == 1, "Each earned skill has its independent printed leading cost.");
        await Act("P1", new PayCostCommand(cost.PaymentId, cost.PaymentWindow, ["PAY"]));
    }
    Check(state.StackItems.Count == 2 && state.PendingPayment is null, "Both real costs are confirmed before responses.");
    await Top();
    Check(state.PendingEffectPlay is not null && state.StackItems.Count == 1, "First old skill opens normal shared effect play while the second remains earned.");
    await Act("P1", new PlayCardCommand("PHOENIX", phoenix, []));
    Check(state.PlayerZones["P1"].Base.Contains("PHOENIX") && state.CardObjects["PHOENIX"].ObjectGeneration == 1, "Original Phoenix actually leaves its graveyard through legal play.");
    var remaining = state.StackItems.Single().StackItemId;
    if (state.PriorityPlayerId != "P1") await Act(state.PriorityPlayerId!, new PassPriorityCommand());
    await Act("P1", new PlayCardCommand("REVIVE", revive, ["OWN"], OptionalCosts: ["DESTROY_FRIENDLY_UNIT:PHOENIX"]));
    Check(state.PlayerZones["P1"].Graveyard.Contains("PHOENIX") && state.CardObjects["PHOENIX"].ObjectGeneration == 2, "Actual additional destruction cost returns the physical Phoenix as a new graveyard incarnation.");
    await Top();
    Check(state.PendingEffectPlay is not null, "The actual response opens its own normal effect play.");
    await Act("P1", new PlayCardCommand("OWN", poro, []));
    Check(state.StackItems.Count == 1 && state.StackItems[0].StackItemId == remaining
        && state.StackItems[0].GraveyardPlay?.Source == new ObjectBinding("PHOENIX", 0), "The earned second skill survives both actual zone changes with its old generation.");
    var last = await Top();
    Check(state.PendingEffectPlay is null && state.StackItems.Count == 0 && state.TriggerQueue.Count == 0
        && state.PlayerZones["P1"].Graveyard.Contains("PHOENIX") && state.CardObjects["PHOENIX"].ObjectGeneration == 2,
        "The old skill resolves as no-op and cannot borrow the later graveyard entry.");
    Check(last.Events.Any(e => e.Kind == "TRIGGER_RESOLVED") && !last.Events.Any(e => e.Kind == "CARD_PLAYED"), "The original earned skill resolves without another Phoenix play.");
    var sequence = journal.Entries[^1].CompletedEventSequence;
    var views = state.Seats.Keys.ToDictionary(id => id, id => new RecoveredPlayerView(id, state.Tick, sequence,
        session.SnapshotFor(id), state.Tick, sequence, session.PromptFor(id)));
    var spectator = MatchReplayRedactor.BuildSpectatorFrame(state.RoomId, state.Tick, sequence, [], state);
    var frame = new MatchRecoveryFrame(state.RoomId, state.Tick, sequence, journal.Commands(), journal.Events(), views, [], state, initial, spectator);
    var errors = await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame, new CoreRuleEngine(), default);
    Check(errors.Count == 0, "Entire original accepted action/event/state replay: " + string.Join(';', errors));
    await using (var file = new FileStream(Path.Combine(output, "legal-reentry-original-frame.json.gz"), FileMode.CreateNew))
    await using (var zip = new GZipStream(file, CompressionLevel.SmallestSize)) await JsonSerializer.SerializeAsync(zip, frame, json);
    await File.WriteAllTextAsync(Path.Combine(output, "receipt.json"), JsonSerializer.Serialize(new { status = "PASS_CONTROLLED_REAL_COMMAND_PHOENIX_LEAVE_REENTER_AND_OLD_TRIGGER_NOOP",
        commands = journal.Commands().Length, events = journal.Events().Length, actualRuleInputs = RuleInputIdentity.Current,
        originalInitialPositionDeclaredControlled = true, noStateMutationAfterInitialPosition = true, fullOriginalReplayMatched = true,
        ordinaryBlankOpeningRealSqlNativeVisibleWholeCardCertified = false }, json));
    Console.WriteLine("PASS_CONTROLLED_REAL_COMMAND_PHOENIX_LEAVE_REENTER_AND_OLD_TRIGGER_NOOP");
}
finally
{
    await File.WriteAllTextAsync(Path.Combine(output, "original-command-attempts.json"), JsonSerializer.Serialize(journal.Entries, json));
    await File.WriteAllTextAsync(Path.Combine(output, "original-accepted-checkpoints.json"), JsonSerializer.Serialize(checkpoints, json));
}

sealed class Journal : IMatchJournal
{
    public List<MatchJournalEntry> Entries { get; } = [];
    public ValueTask RecordAsync(MatchJournalEntry entry, CancellationToken token) { Entries.Add(entry); return ValueTask.CompletedTask; }
    public RecoveredCommand[] Commands() => Entries.Select(e => new RecoveredCommand(e.PlayerId, e.ClientIntentId, e.CommandType, e.RawCommand,
        e.StartedTick, e.CompletedTick, e.StartedEventSequence, e.CompletedEventSequence, e.Accepted, e.ErrorMessage) { RuleInputs = e.RuleInputs }).ToArray();
    public RecoveredEvent[] Events() => Entries.SelectMany(e => e.Events.Select((ev, i) => new RecoveredEvent(e.StartedEventSequence + i + 1, e.CompletedTick, i, ev))).ToArray();
}
