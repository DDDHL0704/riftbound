import datetime
import hashlib
import json
import os
import pathlib
import plistlib
import subprocess

n = pathlib.Path(__file__).resolve().parent
r = n.parents[2]
pg = pathlib.Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin')
cluster = r / 'var/qa/permanent-play-here-base-20261017/postgres'
sock = pathlib.Path('/tmp/rft-here-family-20261018-55486')
dotnet = '/Users/dinghaolin/.dotnet/dotnet'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
write = lambda p, value: p.write_text(json.dumps(value, indent=2) + '\n')
publication = load(n / 'fixed-api-publication-v1.json')
fixed = publication['fixedCommit']
identity = publication['actualRuleInputs']
api = reader = n / 'fixed-api'
reader_command = publication['readerCommand']
tables = ['matches', 'match_players', 'command_log', 'game_events', 'state_snapshots', 'snapshots', 'action_prompts']

def environment(db):
    assert db in {'riftbound_acceptance', 'riftbound_here_native'}
    return dict(os.environ, ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=' + db + ';Username=codex_riftbound_audit',
                RIFTBOUND_FIXED_ACCEPTANCE_ROOT=str(n))

def query(db, sql):
    return subprocess.check_output([str(pg / 'psql'), '-XAt', '-h', '127.0.0.1', '-p', '55486', '-U',
                                    'codex_riftbound_audit', '-d', db, '-v', 'ON_ERROR_STOP=1', '-c', sql]).decode().strip()

def rooms(db):
    return query(db, 'select match_id from matches order by match_id').splitlines()

def digests(db, ids=None):
    ids = rooms(db) if ids is None else ids
    where = 'where match_id=ANY(ARRAY[' + ','.join("'" + value.replace("'", "''") + "'" for value in ids) + ']::text[])'
    result = {}
    for table in tables:
        command = [str(pg / 'psql'), '-XAt', '-h', '127.0.0.1', '-p', '55486', '-U', 'codex_riftbound_audit', '-d', db,
                   '-v', 'ON_ERROR_STOP=1', '-v', 'FETCH_COUNT=8', '-c',
                   f'select row_to_json(t)::text from {table} t {where} order by row_to_json(t)::text']
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        digest = hashlib.sha256(); size = 0
        for chunk in iter(lambda: process.stdout.read(1024 * 1024), b''):
            digest.update(chunk); size += len(chunk)
        error = process.stderr.read()
        assert process.wait() == 0, error.decode(errors='replace')[:1000]
        if not size:
            digest.update(b'\n')
        result[table] = digest.hexdigest()
    return result

def lock_observation():
    raw = plistlib.loads(subprocess.check_output(['/usr/sbin/ioreg', '-n', 'Root', '-d', '1', '-a']))
    return {'atUtc': now(), 'roots': [{'rootLocked': entry.get('IOConsoleLocked'),
            'sessions': [user['CGSSessionScreenIsLocked'] for user in entry.get('IOConsoleUsers', []) if 'CGSSessionScreenIsLocked' in user]}
            for entry in (raw if isinstance(raw, list) else [raw])], 'unknownIsNotUnlocked': True}

def verify_fixed():
    assert fixed == 'e262ebf164e448cc9738d94db8e557f302cfc295'
    assert all(sha(api / path) == digest for path, digest in publication['runtimeFiles'].items())
    assert all(sha(r / path) == digest for path, digest in publication['sourceInputHashes'].items())
    assert all(sha(n / path) == digest for path, digest in publication['readerInputs'].items())
    assert json.loads(subprocess.check_output(reader_command + ['identity-print'], env=environment('riftbound_here_native'), cwd=api, text=True)) == identity

verify_fixed()
