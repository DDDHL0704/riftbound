import fcntl
import json
import os
import runpy
import subprocess
from pathlib import Path

os.umask(0o077)
n = Path(__file__).resolve().parent
c = runpy.run_path(str(n / 'fixed_e262_gateway_common.py'))
sha, load, write, now = [c[k] for k in ['sha', 'load', 'write', 'now']]
last = load(n / 'fixed-socket-identity-verification-v1.json')
assert last['status'].startswith('PASS') and last['ownPostgresSmartStopped']
runtime = n / 'fixed-api'
files = {str(p.relative_to(n)): sha(p) for p in runtime.rglob('*') if p.is_file()}
for p in [n / 'fixed-native-independent-reader/Program.cs', n / 'fixed-native-independent-reader/reader.csproj']:
    files[str(p.relative_to(n))] = sha(p)
originals = ['exported-graceful-original-frame.json.gz', 'exported-stale-retry-v2-original-frame.json.gz',
             'score-paired-after-continuation-original-frame.json.gz', 'score-paired-before-restart-original-frame.json.gz']
for name in originals:
    files[name] = sha(n / name)
for dll in ['Riftbound.Engine.dll', 'Riftbound.CardCatalog.dll', 'Riftbound.Contracts.dll', 'Riftbound.Persistence.dll']:
    assert sha(runtime / dll) == c['publication']['runtimeFiles'][dll]
manifest = n / 'fixed-native-independent-reader-inputs-v1.json'
assert not manifest.exists()
write(manifest, {'fixedCommit': c['fixed'], 'files': files, 'actualRuleInputs': c['identity']})
out = n / 'fixed-native-independent-verification-v1.json'
assert not out.exists()
proof = {'startedAtUtc': now(), 'fixedCommit': c['fixed'], 'actualRuleInputs': c['identity'],
         'status': 'RUNNING_NOT_ACCEPTANCE', 'lockAtStart': c['lock_observation'](),
         'readerInputsSha256': sha(manifest), 'originalFramesNeverRewritten': True,
         'visibleNativeControlsAndPairedClients': 'OPEN', 'physicalWindows': 'OPEN'}
guard = (n.parent / 'ravenbloom-paired-20261018/without-desktop.lock').open('a')
fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
write(out, proof)
pg, cluster, sock = [c[k] for k in ['pg', 'cluster', 'sock']]
started = False
power = None
try:
    assert subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), 'status'], capture_output=True).returncode == 3
    power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    proof.update(ownRunnerPid=os.getpid(), boundIdleSleepAssertionPid=power.pid)
    subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-l', str(n / 'fixed-native-independent-postgres-v1.log'),
                    '-o', f'-p 55486 -h 127.0.0.1 -k {sock}', '-w', 'start'], check=True, capture_output=True)
    started = True
    native = c['rooms']('riftbound_here_native')
    audit = c['rooms']('riftbound_acceptance')
    assert len(native) == 39 and len(audit) == 190
    before_native = c['digests']('riftbound_here_native')
    before_audit = c['digests']('riftbound_acceptance')
    proof.update(priorNativeRooms=native, priorAuditRooms=audit, priorNativeSevenTables=before_native, priorAuditSevenTables=before_audit)
    write(out, proof)
    result = subprocess.run([c['dotnet'], 'exec', '--depsfile', str(runtime/'Riftbound.Api.deps.json'), '--runtimeconfig', str(runtime/'Riftbound.Api.runtimeconfig.json'), str(runtime/'independentnative.dll'), 'validate-readonly-fixed-native-originals-v1'],
                            cwd=runtime, env=c['environment']('riftbound_here_native'), capture_output=True, text=True, timeout=180)
    log = n / 'fixed-native-independent-reader-v1.log'
    with log.open('x') as stream:
        stream.write(result.stdout + result.stderr)
    proof['readerExitCode'] = result.returncode
    assert result.returncode == 0
    reader = json.loads(result.stdout)
    assert reader['status'].startswith('PASS') and reader['actualRuleInputs'] == c['identity']
    write(n / 'fixed-native-independent-reader-result-v1.json', reader)
    assert c['digests']('riftbound_here_native') == before_native
    assert c['digests']('riftbound_acceptance') == before_audit
    assert c['rooms']('riftbound_here_native') == native and c['rooms']('riftbound_acceptance') == audit
    proof.update(status=reader['status'], independentActualReadOnlyResult=reader,
                 all39NativeAnd190AuditRoomsSevenTablesUnchanged=True, noNewRoomOrSeedOrHistoryRewrite=True)
except BaseException as error:
    proof.update(status='FAILED_OR_INTERRUPTED_ORIGINALS_RETAINED', errorType=type(error).__name__)
    raise
finally:
    if started:
        proof['ownPostgresSmartStopped'] = subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-m', 'smart', '-w', '-t', '20', 'stop'], capture_output=True).returncode == 0
    if power is not None:
        if power.poll() is None:
            power.terminate()
            power.wait(timeout=10)
        proof['boundIdleSleepAssertionEnded'] = power.poll() is not None
    assert all(sha(n / p) == h for p, h in files.items())
    c['verify_fixed']()
    proof.update(finishedAtUtc=now(), lockAtEnd=c['lock_observation'](), allFrozenReaderAndNativeRuntimeFilesStillExact=True, originalDatabaseRetained=cluster.exists())
    write(out, proof)
    fcntl.flock(guard, fcntl.LOCK_UN)
print(proof['status'], flush=True)
