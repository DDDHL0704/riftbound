using System.Collections.Concurrent;
using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using Riftbound.Contracts;
using Riftbound.GodotClient;

if (!OperatingSystem.IsMacOS()) throw new Exception("This bounded runner records Mac background acceptance only.");
if (args.Length != 1 || args[0] != "fixede262-paired-score-restart") throw new Exception("Exact bounded gate required.");
var root = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "../../../../"));
if (!File.Exists(Path.Combine(root,"fixed-api-publication-v1.json"))) throw new Exception("Frozen publication missing.");
var output = Path.Combine(root,"score-network-evidence");
if (Directory.Exists(output)) throw new Exception("Never overwrite original pair evidence or retry its accepted prefix.");
Directory.CreateDirectory(output);
using var deadline = new CancellationTokenSource(TimeSpan.FromSeconds(600));
var ct = deadline.Token;
var suffix = Guid.NewGuid().ToString("N")[..12];
var room = "LOCKED-E262-SCORE-"+suffix;
await using var a = new Side("locka"+suffix, room, ct);
await using var b = new Side("lockb"+suffix, room, ct);
var sides = new[] { a,b };
await a.Connect(); await b.Connect();
using var fixture = JsonDocument.Parse(await File.ReadAllBytesAsync(Path.Combine(AppContext.BaseDirectory,"Fixtures/copied-duel-insight-openings.json"),ct));
var recipes = fixture.RootElement.GetProperty("branches")[0].GetProperty("acceptedCommands");
var accepted = new List<CommandReceiptDto>();
var timeline = new List<object>();
for (var i=0;i<2;i++)
{
    var command = JsonNode.Parse(recipes[i].GetProperty("rawCommand").GetRawText())!.AsObject();
    command.Remove("promptId"); command.Remove("snapshotTick");
    accepted.Add(await sides[i].Submit(command));
    await PairTick(accepted[^1].ServerTick);
}
foreach (var side in sides)
{
    accepted.Add(await side.Submit(new JsonObject { ["cmdType"]="READY" }));
    await PairTick(accepted[^1].ServerTick);
}
await Until(()=>sides.Any(s=>s.Enabled("MULLIGAN")),"actual ordinary mulligan");
CheckPrivateHands();
var before = sides.Select(s=>new { s.Handle, snapshot=s.Snapshot, prompt=s.Prompt, snapshots=s.SnapshotCount, prompts=s.PromptCount }).ToArray();
Console.WriteLine("PAIR_READY_FOR_RESTART "+JsonSerializer.Serialize(new {room,acceptedCommands=accepted.Count}));
Console.Out.Flush();
if (await Console.In.ReadLineAsync(ct) != "API_RESTARTED") throw new Exception("Expected own API restart handshake.");
await Task.WhenAll(sides.Select(s=>s.Restored.Task.WaitAsync(ct)));
await Until(()=>sides.All(s=>s.Hub.IsConnected && s.Restores==1),"both authenticated sessions restored");
await Until(()=>Enumerable.Range(0,2).All(i=>sides[i].SnapshotCount>before[i].snapshots && sides[i].PromptCount>before[i].prompts),"both fresh private views and prompts received");
for (var i=0;i<2;i++)
{
    var side=sides[i];
    if (side.SnapshotCount<=before[i].snapshots || side.PromptCount<=before[i].prompts
        || !Equal(side.Snapshot,before[i].snapshot) || !Equal(side.Prompt,before[i].prompt))
        throw new Exception("Both private views and original prompts must survive cold restart exactly.");
}
CheckPrivateHands();
var afterRestore=sides.Select(s=>new {s.Handle,snapshot=s.Snapshot,prompt=s.Prompt}).ToArray();
for (var i=0;i<2;i++)
{
    await Until(()=>sides.Any(s=>s.Enabled("MULLIGAN")),"original next mulligan choice");
    var side=sides.First(s=>s.Enabled("MULLIGAN"));
    accepted.Add(await side.Submit(new JsonObject { ["cmdType"]="MULLIGAN",["handObjectIds"]=new JsonArray() }));
    await PairTick(accepted[^1].ServerTick);
}
await Until(()=>sides.Any(s=>s.Enabled("END_TURN")),"ordinary main phase after both original choices");
var active=sides.Single(s=>s.Enabled("END_TURN"));
var turn=active.Snapshot.GetProperty("turnNumber").GetInt32();
accepted.Add(await active.Submit(new JsonObject {["cmdType"]="END_TURN"}));
await PairTick(accepted[^1].ServerTick);
if (sides.Any(s=>s.Snapshot.GetProperty("turnNumber").GetInt32()!=turn+1)) throw new Exception("Original next EndTurn did not advance normally.");
// Cooperative protocol acceptance: one actual Student conquers then holds; B passes.
// Every command remains an authenticated ordinary server intent. No seed, state or history injection.
var playedStudent=false;
for(var step=0;step<500 && !sides.All(Finished);step++)
{
    foreach(var side in sides)side.CheckErrors();
    if(sides.Any(side=>side.Snapshot.GetProperty("turnNumber").GetInt32()>90))throw new Exception("Bounded normal-score turn limit.");
    Side? actor=null;JsonObject? command=null;
    foreach(var tempo in new[]{"PASS_PRIORITY","PASS_FOCUS","PASS"})
    {
        actor=sides.FirstOrDefault(side=>side.Enabled(tempo));
        if(actor is not null){command=new JsonObject{["cmdType"]=tempo};break;}
    }
    if(command is null)
    {
        actor=sides.FirstOrDefault(side=>side.Enabled("ORDER_TRIGGERS"));
        if(actor is not null)command=new JsonObject{["cmdType"]="ORDER_TRIGGERS",["orderedTriggerIds"]=JsonNode.Parse(Candidate(actor,"ORDER_TRIGGERS").GetProperty("metadata").GetProperty("orderedTriggerIds").GetRawText())};
    }
    if(command is null && a.Enabled("PLAY_CARD") && !playedStudent)
    {
        var candidate=Candidate(a,"PLAY_CARD");
        var requirements=candidate.GetProperty("metadata").GetProperty("sourceRequirements");
        foreach(var requirement in requirements.EnumerateArray())
        {
            var id=requirement.GetProperty("sourceObjectId").GetString()!;
            var card=a.Snapshot.GetProperty("players").GetProperty(a.Handle).GetProperty("objects").GetProperty(id);
            if(card.GetProperty("cardNo").GetString()!="OGN·103/298")continue;
            var intent=new PlayCardCommand(id,"OGN·103/298",[]);
            var prompt=a.Prompt;
            var quote=await a.Hub.PreviewPlayCardAsync(room,new PlayCostPreviewRequestDto("score-"+Guid.NewGuid().ToString("N"),prompt.GetProperty("promptId").GetString()!,prompt.GetProperty("snapshotTick").GetInt64(),intent),ct);
            if(!quote.IsValid || !quote.CanPay)continue;
            actor=a;command=JsonSerializer.SerializeToNode(intent, new JsonSerializerOptions(JsonSerializerDefaults.Web))!.AsObject();
            playedStudent=true;break;
        }
    }
    if(command is null && a.Enabled("MOVE_UNIT") && playedStudent)
    {
        foreach(var requirement in Candidate(a,"MOVE_UNIT").GetProperty("metadata").GetProperty("sourceRequirements").EnumerateArray())
        {
            if(requirement.GetProperty("origin").GetString()!="BASE")continue;
            var id=requirement.GetProperty("sourceObjectId").GetString()!;
            var card=a.Snapshot.GetProperty("players").GetProperty(a.Handle).GetProperty("objects").GetProperty(id);
            if(card.GetProperty("cardNo").GetString()!="OGN·103/298")continue;
            if(requirement.GetProperty("requiredOptionalCosts").GetArrayLength()!=0)continue;
            var choices=requirement.GetProperty("destinationChoices").EnumerateArray().Where(x=>x.GetProperty("id").GetString()!.StartsWith("BATTLEFIELD:",StringComparison.Ordinal)).ToArray();
            if(choices.Length==0)continue;
            actor=a;command=new JsonObject{["cmdType"]="MOVE_UNIT",["sourceObjectId"]=id,["origin"]="BASE",["destination"]=choices[0].GetProperty("id").GetString()};break;
        }
    }
    if(command is null && !playedStudent && a.Enabled("TAP_RUNE"))
    {
        var player=a.Snapshot.GetProperty("players").GetProperty(a.Handle);
        var studentInHand=player.GetProperty("zones").GetProperty("hand").EnumerateArray().Any(id=>player.GetProperty("objects").GetProperty(id.GetString()!).GetProperty("cardNo").GetString()=="OGN·103/298");
        if(studentInHand){actor=a;command=new JsonObject{["cmdType"]="TAP_RUNE",["sourceObjectId"]=Candidate(a,"TAP_RUNE").GetProperty("sources")[0].GetProperty("id").GetString()};}
    }
    if(command is null)
    {
        actor=sides.FirstOrDefault(side=>side.Enabled("END_TURN"));
        if(actor is not null)command=new JsonObject{["cmdType"]="END_TURN"};
    }
    if(actor is null || command is null)throw new Exception("Unhandled original server prompt: "+string.Join(",",sides.Select(side=>side.Prompt.GetProperty("type").GetString())));
    accepted.Add(await actor.Submit(command));await PairTick(accepted[^1].ServerTick);CheckPrivateHands();
}
if(!sides.All(Finished) || accepted.Any(x=>x.CmdType=="SURRENDER"))throw new Exception("Original normal-score completion missing.");
var finalScores=sides.ToDictionary(side=>side.Handle,side=>side.Snapshot.GetProperty("players").GetProperty(side.Handle).GetProperty("score").GetInt32());
if(sides.Any(side=>side.Snapshot.GetProperty("timing").GetProperty("winnerPlayerId").GetString()!=a.Handle) || finalScores[a.Handle]<8)throw new Exception("Ordinary scoring threshold was not reached by the Student side.");
var timelinePath=Path.Combine(output,"original-private-wire-timeline.json.gz");
await using(var file=File.Create(timelinePath))
{
    File.SetUnixFileMode(timelinePath,UnixFileMode.UserRead|UnixFileMode.UserWrite);
    await using var zip=new GZipStream(file,CompressionLevel.SmallestSize);
    await JsonSerializer.SerializeAsync(zip,timeline,cancellationToken:ct);
}
bool Finished(Side side)=>side.Snapshot.GetProperty("timing").GetProperty("roomStatus").GetString()=="FINISHED";
JsonElement Candidate(Side side,string action)=>side.Prompt.GetProperty("candidates").EnumerateArray().Single(c=>c.GetProperty("enabled").GetBoolean() && c.GetProperty("action").GetString()==action);

var privatePath=Path.Combine(output,"original-paired-wire-views.json.gz");
await using (var file=File.Create(privatePath))
{
    File.SetUnixFileMode(privatePath,UnixFileMode.UserRead|UnixFileMode.UserWrite);
    await using var zip=new GZipStream(file,CompressionLevel.SmallestSize);
    await JsonSerializer.SerializeAsync(zip,new {room,before,afterRestore,final=sides.Select(s=>new {s.Handle,snapshot=s.Snapshot,prompt=s.Prompt}),accepted},cancellationToken:ct);
}
foreach (var side in sides) side.CheckErrors();
var receipt=new {status="PASS",room,acceptedCommands=accepted.Count,ordinaryLegalDecks=2,
    actualProductionNativeGateway=true,twoAuthorizedClients=true,actualApiRestart=true,
    bothPrivateViewsAndPromptsExact=true,privateHandRedaction=true,originalPostRestartMulligans=2,originalNextEndTurns=1,
    restores=sides.Select(s=>s.Restores).ToArray(),freshSnapshots=sides.Select(s=>s.SnapshotCount).ToArray(),
    originalWireViewsSha256=Convert.ToHexString(SHA256.HashData(await File.ReadAllBytesAsync(privatePath,ct))).ToLowerInvariant(),
    noSeedOrStateInjection=true,noVisibleControlsOrWindowsClaim=true,cooperativeUncontestedStudentConquestAndHoldOnly=true,normalScoreThresholdObservedBothSides=true,finalScores,originalWireTimelineSha256=Convert.ToHexString(SHA256.HashData(await File.ReadAllBytesAsync(timelinePath,ct))).ToLowerInvariant(),wireSteps=timeline.Count};
await File.WriteAllTextAsync(Path.Combine(output,"receipt.json"),JsonSerializer.Serialize(receipt,new JsonSerializerOptions {WriteIndented=true}),ct);
Console.WriteLine("PAIR_RESTORED_AND_CONTINUED "+JsonSerializer.Serialize(receipt));

bool Equal(JsonElement x,JsonElement y)=>JsonNode.DeepEquals(JsonNode.Parse(x.GetRawText()),JsonNode.Parse(y.GetRawText()));
async Task Until(Func<bool> predicate,string label)
{
    while(!predicate())
    {
        foreach(var side in sides) side.CheckErrors();
        await Task.Delay(20,ct);
    }
}
async Task PairTick(long tick)
{
    await Until(()=>sides.All(s=>s.Snapshot.GetProperty("tick").GetInt64()==tick && s.Prompt.TryGetProperty("snapshotTick",out var t) && t.GetInt64()==tick),"both current wire views");
    timeline.Add(new { tick, views=sides.Select(s=>new {s.Handle,snapshot=s.Snapshot,prompt=s.Prompt}).ToArray() });
}
void CheckPrivateHands()
{
    foreach(var viewer in sides)
    {
        var other=sides.Single(s=>s!=viewer);
        var actualHand=other.Snapshot.GetProperty("players").GetProperty(other.Handle).GetProperty("zones").GetProperty("hand");
        var opponent=viewer.Snapshot.GetProperty("players").GetProperty(other.Handle);
        var zones=opponent.GetProperty("zones");
        if(actualHand.GetArrayLength()==0 || zones.GetProperty("hand").GetArrayLength()!=0
            || zones.GetProperty("handHidden").GetInt32()!=actualHand.GetArrayLength()
            || actualHand.EnumerateArray().Any(id=>opponent.GetProperty("objects").TryGetProperty(id.GetString()!,out _)))
            throw new Exception("Private opponent hand identity boundary failed.");
    }
}

sealed class Side : IAsyncDisposable
{
    readonly CancellationToken ct;
    readonly string room;
    readonly string key="locked-private-"+Guid.NewGuid().ToString("N");
    readonly object gate=new();
    readonly ConcurrentQueue<string> errors=new();
    JsonElement snapshot,prompt;
    string? reconnectToken;
    public string Handle {get;}
    public RiftboundGameHubClient Hub {get;}=new("http://127.0.0.1:15839");
    public TaskCompletionSource Restored {get;}=new(TaskCreationOptions.RunContinuationsAsynchronously);
    public int SnapshotCount,PromptCount,Restores;
    public JsonElement Snapshot {get {lock(gate)return snapshot;}}
    public JsonElement Prompt {get {lock(gate)return prompt;}}
    public Side(string handle,string room,CancellationToken ct)
    {
        Handle=handle;this.room=room;this.ct=ct;
        Hub.ServerMessageReceived+=(kind,message)=>
        {
            if(message.Payload is not JsonElement p)return;
            lock(gate)
            {
                if(kind=="Joined") reconnectToken=p.GetProperty("reconnectToken").GetString();
                if(kind=="Snapshot"){snapshot=p.Clone();Interlocked.Increment(ref SnapshotCount);}
                if(kind=="Prompt"){prompt=p.Clone();Interlocked.Increment(ref PromptCount);}
                if(kind=="Error") errors.Enqueue("Actual server error: "+p.GetProperty("code").GetString());
            }
        };
        Hub.StatusChanged+=status=>
        {
            if(status=="Reconnecting" && Hub.IsConnected)errors.Enqueue("Stale transport remained actionable.");
            if(status=="Recovery failed")errors.Enqueue("Authenticated restoration failed.");
            if(status=="Connected")Restored.TrySetResult();
        };
        Hub.RestoreSession+=async()=>
        {
            Interlocked.Increment(ref Restores);
            var auth=await Hub.AuthenticateAsync(Handle,key,ct);
            if(!auth.Authenticated)throw new Exception("Recovery authentication failed.");
            await Hub.ReconnectAsync(room,Handle,reconnectToken!,ct);
            await Hub.RequestSnapshotAsync(room,Handle,ct);
        };
    }
    public async Task Connect()
    {
        await Hub.StartAsync(ct);
        var auth=await Hub.AuthenticateAsync(Handle,key,ct);
        if(!auth.Authenticated)throw new Exception("Initial authentication failed.");
        await Hub.JoinRoomAsync(room,Handle,null,ct);
        await Hub.RequestSnapshotAsync(room,Handle,ct);
        while(reconnectToken is null || SnapshotCount==0 || PromptCount==0){CheckErrors();await Task.Delay(20,ct);}
    }
    public bool Enabled(string action)
    {
        var p=Prompt;
        return p.ValueKind==JsonValueKind.Object && p.GetProperty("actionable").GetBoolean()
            && p.TryGetProperty("candidates",out var candidates)
            && candidates.EnumerateArray().Any(c=>c.GetProperty("action").GetString()==action && c.GetProperty("enabled").GetBoolean());
    }
    public async Task<CommandReceiptDto> Submit(JsonObject command)
    {
        var p=Prompt;
        command["promptId"]=p.GetProperty("promptId").GetString();command["snapshotTick"]=p.GetProperty("snapshotTick").GetInt64();
        var receipt=await Hub.SubmitIntentAsync(room,Handle,"locked-"+Guid.NewGuid().ToString("N"),JsonSerializer.SerializeToElement(command),ct);
        if(!receipt.Accepted)throw new Exception("Ordinary wire command rejected: "+receipt.CmdType+" "+receipt.ErrorCode);
        return receipt;
    }
    public void CheckErrors(){if(errors.TryPeek(out var error))throw new Exception(error);}
    public ValueTask DisposeAsync()=>Hub.DisposeAsync();
}
