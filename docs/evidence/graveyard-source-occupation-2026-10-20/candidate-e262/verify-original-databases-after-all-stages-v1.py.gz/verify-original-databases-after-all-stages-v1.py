import fcntl,json,os,subprocess
from fixed_e262_native_common import *
os.umask(0o077)
out=n/'cross-stage-original-database-and-input-integrity-v1.json';assert not out.exists()
last=load(n/'fixed-native-independent-verification-v2.json');assert last['status'].startswith('PASS') and last['ownPostgresSmartStopped']
sql=load(n/'real-sql-verification-v1.json');assert sql['status'].startswith('PASS') and sql['ownPostgresSmartStopped']
prior=n.parent/'destruction-graveyard-implementation-20261020';old1=load(prior/'real-sql-verification-v1.json');old2=load(prior/'real-sql-verification-v2.json')
guard=(r/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof={'status':'RUNNING_NOT_ACCEPTANCE','fixedCommit':fixed,'actualRuleInputs':identity,'startedAtUtc':now(),'lockAtStart':lock_observation(),'sourceInputCount':len(publication['sourceInputHashes'])}
started=False;power=None
try:
 verify_fixed();assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(n/'cross-stage-readonly-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 os.environ['PGOPTIONS']='-c default_transaction_read_only=on'
 assert query('riftbound_acceptance','show transaction_read_only')=='on'
 assert query('riftbound_here_native','show transaction_read_only')=='on'
 assert len(rooms('riftbound_acceptance'))==190 and len(rooms('riftbound_here_native'))==39
 for label,baseline in [('old172',old1),('old178',old2),('fixed184',sql)]:
  assert digests('riftbound_acceptance',baseline['priorAuditRooms'])==baseline['priorAuditSevenTables'],label
  assert digests('riftbound_here_native',baseline['priorNativeRooms'])==baseline['priorNativeSevenTables'],label
 assert digests('riftbound_acceptance')==last['priorAuditSevenTables']
 assert digests('riftbound_here_native')==last['priorNativeSevenTables']
 verify_fixed()
 proof.update(status='PASS_ALL_ORIGINAL172_178_184_AUDIT_AND35_NATIVE_SUBSETS_AND_ALL190_39_CURRENT_ROOMS_SEVEN_TABLES_EXACT',
  allOriginalAuditSubsets172178184SevenTablesExact=True,allOriginal35NativeRoomsSevenTablesExact=True,
  allCurrent190AuditAnd39NativeRoomsSevenTablesExactToIndependentReadOnlyBaseline=True,
  all3302FixedSourcesAndFrozenApiInputsStillExact=True,bothDatabaseConnectionsReadOnlyEnforced=True,
  allOriginalGameSeedsAcceptedRejectedHistoryAndPrivateViewsRetained=True,rootSourceStillExactBeforeNextFix=True,
  visibleNativeControlsPairedWindows='OPEN')
except BaseException as error:
 proof.update(status='FAILED_ORIGINALS_RETAINED',errorType=type(error).__name__,errorMessage=str(error));raise
finally:
 if started:proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None:
  if power.poll() is None:power.terminate();power.wait(timeout=10)
  proof['boundIdleSleepAssertionEnded']=power.poll() is not None
 verify_fixed();proof.update(finishedAtUtc=now(),lockAtEnd=lock_observation(),originalDatabaseRetained=cluster.exists());write(out,proof);fcntl.flock(guard,fcntl.LOCK_UN)
print(proof['status'],flush=True)
