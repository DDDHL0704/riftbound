import datetime
import hashlib
import json
import os
import pathlib
import shutil
import subprocess

os.umask(0o077)
n = pathlib.Path(__file__).resolve().parent
r = n.parents[2]
dotnet = '/Users/dinghaolin/.dotnet/dotnet'
fixed = 'e262ebf164e448cc9738d94db8e557f302cfc295'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
write = lambda p, d: p.write_text(json.dumps(d, indent=2) + '\n')
inputs = load(n / 'fixed-commit-inputs-v1.json')
assert inputs['fixedCommit'] == fixed
proof = {'status': 'BUILDING_EXACT_FIXED_API_SQL_AND_READERS', 'fixedCommit': fixed, 'startedAtUtc': now(),
         'noGodotSdkOrProjectBuild': True, 'noWholeCheckoutOrNewDatabase': True, 'builds': []}
out = n / 'fixed-api-sql-build-verification-v1.json'
assert not out.exists()

def verify_sources():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=r, text=True).strip() == fixed
    assert all(sha(r / p) == h for p, h in inputs['sourceInputHashes'].items())

process = power = None
try:
    verify_sources()
    power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())])
    proof.update(ownRunnerPid=os.getpid(), boundIdleSleepAssertionPid=power.pid)
    for project, target in [('src/Riftbound.Api/Riftbound.Api.csproj', 'fixed-api'),
                            ('tests/Riftbound.PostgresAcceptance/Riftbound.PostgresAcceptance.csproj', 'frozen-sql-v1')]:
        assert not (n / target).exists()
        with (n / (target + '-publish-v1.log')).open('x') as log:
            process = subprocess.Popen([dotnet, 'publish', project, '-c', 'Release', '-o', str(n / target), '-v:q', '--nologo'],
                                       cwd=r, stdout=log, stderr=subprocess.STDOUT)
            code = process.wait(timeout=300)
        proof['builds'].append({'project': project, 'target': target, 'exitCode': code})
        assert code == 0, target
    native = n.parent / 'hwei-fixed-08fd-20261020'
    previous = n.parent / 'destruction-graveyard-implementation-20261020'
    for source, project, target, replacements in [
        (native / 'native-frame-reader', 'nativeframe.csproj', 'fixed-api',
         [('fixed-api-publication-v2.json', 'fixed-commit-inputs-v1.json')]),
        (native / 'fixed-native-independent-reader', 'reader.csproj', 'fixed-api',
         [('fixed-api-publication-v3.json', 'fixed-api-publication-v1.json')]),
        (previous / 'independent-reader-v2', 'reader.csproj', 'frozen-sql-v1',
         [('frozen-sql-v2', 'frozen-sql-v1'), ('actual-sql-partition-v2', 'actual-sql-partition-v1')])]:
        folder = n / source.name
        folder.mkdir()
        for filename in ['Program.cs', project]:
            raw = (source / filename).read_text()
            for old, new in replacements:
                raw = raw.replace(old, new)
            (folder / filename).write_text(raw)
        with (n / (source.name + '-build-v1.log')).open('x') as log:
            process = subprocess.Popen([dotnet, 'build', str(folder / project), '-c', 'Release', '-v:q', '--nologo'],
                                       cwd=r, stdout=log, stderr=subprocess.STDOUT)
            code = process.wait(timeout=300)
        proof['builds'].append({'project': str((folder / project).relative_to(n)), 'exitCode': code})
        assert code == 0, source.name
        for path in (folder / 'bin/Release/net10.0').glob('*'):
            if path.suffix in {'.dll', '.pdb'}:
                shutil.copy2(path, n / target / path.name)
    api = n / 'fixed-api'
    sql = n / 'frozen-sql-v1'
    probe = previous / 'identity-probe/bin/Debug/net10.0/probe.dll'
    identities = {name: json.loads(subprocess.check_output([dotnet, str(probe), str(folder)], cwd=folder, text=True))
                  for name, folder in [('api', api), ('sql', sql)]}
    assert identities['api']['actualRuleInputs'] == identities['sql']['actualRuleInputs']
    shared = ['Riftbound.Engine.dll', 'Riftbound.Contracts.dll', 'Riftbound.CardCatalog.dll', 'Riftbound.Persistence.dll']
    assert all(sha(api / p) == sha(sql / p) for p in shared)
    commands = [dotnet, 'exec', '--depsfile', str(api / 'Riftbound.Api.deps.json'),
                '--runtimeconfig', str(api / 'Riftbound.Api.runtimeconfig.json'), str(api / 'nativeframe.dll')]
    environment = dict(os.environ, RIFTBOUND_FIXED_ACCEPTANCE_ROOT=str(n))
    assert json.loads(subprocess.check_output(commands + ['identity-print'], cwd=api, env=environment, text=True)) == identities['api']['actualRuleInputs']
    verify_sources()
    for target, folder, identity in [('fixed-api-publication-v1.json', api, identities['api']),
                                      ('frozen-sql-publication-inputs-v1.json', sql, identities['sql'])]:
        write(n / target, {'fixedCommit': fixed, 'baseCommit': fixed, 'actualRuleInputs': identity['actualRuleInputs'],
             'actualLoadedModules': identity['modules'], 'runtimeFiles': {str(p.relative_to(folder)): sha(p) for p in folder.rglob('*') if p.is_file()},
             'sourceInputHashes': inputs['sourceInputHashes'], 'readerCommand': commands if folder == api else
             [dotnet, 'exec', '--depsfile', str(sql / 'Riftbound.PostgresAcceptance.deps.json'), '--runtimeconfig',
              str(sql / 'Riftbound.PostgresAcceptance.runtimeconfig.json'), str(sql / 'reader.dll')],
             'readerInputs': {str(p.relative_to(n)): sha(p) for name in ['native-frame-reader', 'fixed-native-independent-reader', 'independent-reader-v2']
                              for p in (n / name).iterdir() if p.is_file()},
             'sourceInputsSha256': sha(n / 'fixed-commit-inputs-v1.json'), 'publishedAtUtc': now(),
             'compiledFromExactCleanFixedCommit': True, 'separateFromPrecommitResults': True})
    old = load(previous / 'frozen-sql-publication-inputs-v2.json')
    proof.update(status='PASS_EXACT_FIXED_API_SQL_AND_READERS_PUBLISHED', actualRuleInputs=identities['api']['actualRuleInputs'],
                 allFourSharedApiSqlModulesByteExact=True, all3302FixedSourcesStillExact=True,
                 precommitSqlIdentityExact=old['actualRuleInputs'] == identities['sql']['actualRuleInputs'],
                 precommitFourSharedModuleBytesExact=all(old['runtimeFiles'][p] == sha(sql / p) for p in shared),
                 visibleAndPhysicalWindows='OPEN')
except BaseException as error:
    proof.update(status='FAILED_BUILD_PREFIX_RETAINED', errorType=type(error).__name__, errorMessage=str(error))
    raise
finally:
    if process is not None and process.poll() is None:
        process.terminate(); process.wait(timeout=30)
    if power is not None:
        if power.poll() is None:
            power.terminate(); power.wait(timeout=10)
        proof['boundIdleSleepAssertionEnded'] = power.poll() is not None
    proof['finishedAtUtc'] = now()
    write(out, proof)
print(json.dumps(proof, indent=2), flush=True)
