import datetime
import fcntl
import hashlib
import json
import os
import pathlib
import plistlib
import subprocess

os.umask(0o077)
work = pathlib.Path(__file__).resolve().parent
root = work.parents[2]
runtime = work / 'frozen-sql-v1'
pg = pathlib.Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin')
cluster = root / 'var/qa/permanent-play-here-base-20261017/postgres'
socket = pathlib.Path('/tmp/rft-here-family-20261018-55486')
dotnet = '/Users/dinghaolin/.dotnet/dotnet'
tables = ['matches', 'match_players', 'command_log', 'game_events', 'state_snapshots', 'snapshots', 'action_prompts']
publication_path = work / 'frozen-sql-publication-inputs-v1.json'
publication = json.loads(publication_path.read_text())
output = work / 'real-sql-verification-v1.json'
assert not output.exists(), 'Never replace an original SQL attempt.'

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

def write(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)

def frozen():
    assert all(sha(runtime / p) == h for p, h in publication['runtimeFiles'].items())
    assert all(sha(root / p) == h for p, h in publication['sourceInputHashes'].items())
    assert all(sha(work / p) == h for p, h in publication['readerInputs'].items())
    assert json.loads(subprocess.check_output(reader_command('identity-print'), cwd=runtime, text=True)) == publication['actualRuleInputs']

def reader_command(mode):
    return [dotnet, 'exec', '--depsfile', str(runtime / 'Riftbound.PostgresAcceptance.deps.json'),
            '--runtimeconfig', str(runtime / 'Riftbound.PostgresAcceptance.runtimeconfig.json'), str(runtime / 'reader.dll'), mode]

def query(database, sql):
    return subprocess.check_output([str(pg / 'psql'), '-XAt', '-h', '127.0.0.1', '-p', '55486',
                                   '-U', 'codex_riftbound_audit', '-d', database, '-v', 'ON_ERROR_STOP=1', '-c', sql])

def rooms(database):
    return query(database, 'select match_id from matches order by match_id').decode().splitlines()

def digests(database, ids):
    where = 'where match_id=ANY(ARRAY[' + ','.join("'" + v.replace("'", "''") + "'" for v in ids) + ']::text[])'
    result = {}
    for table in tables:
        arguments = [str(pg / 'psql'), '-XAt', '-h', '127.0.0.1', '-p', '55486', '-U', 'codex_riftbound_audit',
                     '-d', database, '-v', 'ON_ERROR_STOP=1', '-v', 'FETCH_COUNT=8', '-c',
                     f'select row_to_json(t)::text from {table} t {where} order by row_to_json(t)::text']
        process = subprocess.Popen(arguments, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        digest = hashlib.sha256(); size = 0
        for chunk in iter(lambda: process.stdout.read(1024 * 1024), b''):
            digest.update(chunk); size += len(chunk)
        error = process.stderr.read(); assert process.wait() == 0, error.decode(errors='replace')[:1000]
        if not size:
            digest.update(b'\n')
        result[table] = digest.hexdigest()
    return result

def locked():
    raw = plistlib.loads(subprocess.check_output(['/usr/sbin/ioreg', '-n', 'Root', '-d', '1', '-a']))
    return {'atUtc': now(), 'roots': [{'rootLocked': v.get('IOConsoleLocked'),
            'sessions': [u['CGSSessionScreenIsLocked'] for u in v.get('IOConsoleUsers', []) if 'CGSSessionScreenIsLocked' in u]}
            for v in (raw if isinstance(raw, list) else [raw])], 'unknownIsNotUnlocked': True}

frozen()
guard = (root / 'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a')
fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
proof = {'status': 'RUNNING_NOT_ACCEPTANCE', 'startedAtUtc': now(), 'baseCommit': publication['baseCommit'], 'fixedCommit': publication['fixedCommit'],
         'includesUncommittedImplementation': False, 'actualRuleInputs': publication['actualRuleInputs'],
         'frozenPublicationSha256': sha(publication_path), 'runnerSourceSha256': sha(pathlib.Path(__file__)),
         'lockAtStart': locked(), 'visibleNativeAndPhysicalWindows': 'OPEN',
         'scope': 'Six original blank seed0 destruction/graveyard branches in two named engine formats. Actual one-case CI dispatcher partition44of45; NOT all four production CI partitions, complete SQL suite, complete game or whole-card certification.'}
write(output, proof)
started = False
power = process = None
try:
    assert subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), 'status'], capture_output=True).returncode == 3
    power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    proof.update(ownRunnerPid=os.getpid(), boundIdleSleepAssertionPid=power.pid)
    subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-l', str(work / 'own-postgres-v1.log'), '-o',
                    f'-p 55486 -h 127.0.0.1 -k {socket}', '-w', 'start'], check=True, capture_output=True)
    started = True
    audit = rooms('riftbound_acceptance'); native = rooms('riftbound_here_native')
    assert len(audit) == 184 and len(native) == 35, 'Reconcile live room baseline before writing.'
    before_audit = digests('riftbound_acceptance', audit)
    before_native = digests('riftbound_here_native', native)
    proof.update(priorAuditRooms=audit, priorNativeRooms=native, priorAuditSevenTables=before_audit,
                 priorNativeSevenTables=before_native, actualPostgresVersion=query('riftbound_acceptance', 'select version()').decode().strip())
    write(output, proof)
    env = dict(os.environ, ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit',
               RIFTBOUND_POSTGRES_EVIDENCE=str(work / 'actual-sql-partition-v1'), RIFTBOUND_DESTRUCTION_SQL_WORK=str(work))
    env['GITHUB_SHA'] = publication['fixedCommit']

    def run(arguments, filename):
        global process
        with (work / filename).open('x') as log:
            process = subprocess.Popen(arguments, cwd=runtime, env=env, stdout=log, stderr=subprocess.STDOUT)
            proof['ownAcceptancePid'] = process.pid; write(output, proof)
            code = process.wait(timeout=5400)
        assert code == 0, (code, filename)

    run([dotnet, str(runtime / 'Riftbound.PostgresAcceptance.dll'), '--ci-partition', '44', '45'], 'real-sql-writer-v1.log')
    partition_path = work / 'actual-sql-partition-v1/partition-receipt.json'
    partition = json.loads(partition_path.read_text())
    assert partition['status'] == 'REAL_POSTGRES_PARTITION_COMPLETE' and partition['fixedCommit'] == publication['fixedCommit']
    assert partition['partitionIndex'] == 44 and partition['partitionCount'] == 45
    assert len(partition['orderedDefaultCases']) == 45 and partition['expectedCases'] == partition['completedCases'] == ['destruction-graveyard']
    for item in partition['runtimeAssemblies']:
        assert publication['runtimeFiles'][item['file']] == item['sha256']
    for item in partition['outputFiles']:
        path = partition_path.parent / item['path']
        assert path.stat().st_size == item['bytes'] and sha(path) == item['sha256']
    receipt_path = partition_path.parent / 'destruction-graveyard/receipt.json'
    receipt = json.loads(receipt_path.read_text()); rows = receipt['results']
    assert receipt['status'] == 'REAL_POSTGRES_ORIGINAL_DESTRUCTION_GRAVEYARD_SIX_BRANCHES_COLD_REPLAY_PASS'
    assert len(rows) == 6 and {(x['format'], x['profile']) for x in rows} == {
        (f, p) for f in ['CoreRules', 'ChinaStandard20260724'] for p in ['SELF_PAY', 'DECREE_PAY', 'DECREE_DECLINE']}
    assert all(x['originalOpeningCommands'] == 82 and x['originalBlankSeed'] == 0 and x['originalFullReplayMatched']
               and x['originalPrivateViewsAndPromptsExact'] and x['noStateSeedOrHistoryInjection']
               and x['ruleInputs'] == publication['actualRuleInputs'] and x['coldRestores'] >= 4
               and x['atomicRejections'] == (2 if x['profile'] == 'SELF_PAY' else 4) for x in rows)
    added = sorted(set(rooms('riftbound_acceptance')) - set(audit))
    assert added == sorted(x['room'] for x in rows) and len(rooms('riftbound_acceptance')) == 190
    assert rooms('riftbound_here_native') == native
    assert digests('riftbound_acceptance', audit) == before_audit and digests('riftbound_here_native', native) == before_native
    current = rooms('riftbound_acceptance'); before_read = digests('riftbound_acceptance', current)
    proof.update(writerComplete=True, originalPartitionReceiptSha256=sha(partition_path)); write(output, proof)
    run(reader_command('independent-readonly'), 'independent-actual-sql-reader-v1.log')
    reader = json.loads((work / 'independent-actual-sql-reader-v1.log').read_text())
    assert reader['status'] == 'PASS_ACTUAL_INDEPENDENT_READONLY_DESTRUCTION_ORIGINAL_FRAMES' and len(reader['checks']) == 6
    assert reader['actualRuleInputs'] == publication['actualRuleInputs']
    assert rooms('riftbound_acceptance') == current and rooms('riftbound_here_native') == native
    assert digests('riftbound_acceptance', current) == before_read and digests('riftbound_here_native', native) == before_native
    write(work / 'independent-actual-sql-reader-result-v1.json', reader)
    proof.update(status='PASS_REAL_SQL_SIX_ORIGINALS_PARTITION_DISPATCH_AND_INDEPENDENT_READONLY_FULL_REPLAY',
                 branches=6, commands=sum(x['commands'] for x in rows), events=sum(x['events'] for x in rows),
                 coldRestores=sum(x['coldRestores'] for x in rows), originalNextCommandsMatched=sum(x['originalNextCommandsMatched'] for x in rows),
                 atomicRejections=sum(x['atomicRejections'] for x in rows), originalReceiptSha256=sha(receipt_path),
                 newOriginalRooms=added, all184PriorAuditAnd35NativeRoomsSevenTablesExact=True,
                 independentAll190AuditAnd35NativeRoomsSevenTablesUnchanged=True, observedAuditRooms=190, observedNativeRooms=35,
                 newRoomSevenTables=digests('riftbound_acceptance', added),
                 originalFrameHashes={p.name: sha(p) for p in receipt_path.parent.glob('*.json.gz')})
except BaseException as error:
    proof.update(status='FAILED_OR_INTERRUPTED_ORIGINAL_PREFIX_RETAINED', errorType=type(error).__name__, errorMessage=str(error))
    raise
finally:
    if process is not None and process.poll() is None:
        process.terminate(); process.wait(timeout=30)
    if started:
        proof['ownPostgresSmartStopped'] = subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-m', 'smart', '-w', '-t', '20', 'stop'], capture_output=True).returncode == 0
    if power is not None:
        if power.poll() is None:
            power.terminate(); power.wait(timeout=10)
        proof['boundIdleSleepAssertionEnded'] = power.poll() is not None
    frozen()
    proof.update(finishedAtUtc=now(), lockAtEnd=locked(), allFrozenRuntimeAndHarnessInputsStillExact=True, originalDatabaseRetained=cluster.exists())
    write(output, proof)
    fcntl.flock(guard, fcntl.LOCK_UN)
print(proof['status'], flush=True)
