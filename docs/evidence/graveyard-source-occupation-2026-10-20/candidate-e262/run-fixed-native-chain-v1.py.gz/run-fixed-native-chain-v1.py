import datetime
import hashlib
import json
import os
import pathlib
import signal
import subprocess
import time

os.umask(0o077)
n = pathlib.Path(__file__).resolve().parent
r = n.parents[2]
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
load = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
out = n / 'fixed-native-chain-verification-v1.json'
assert not out.exists()
assert load(n / 'current-native-headless-boot-verification.json')['status'] == 'CURRENT_FIXED_DEFAULT_MAIN_HEADLESS_BOOT_PASS'
assert load(n / 'fixed-background-native-build-v1.json')['status'].startswith('FIXED_NATIVE_GATEWAY_AND_ACTUAL_NET8')
assert load(n / 'prior-native-pair-retirement.json')['status'] == 'ONLY_LATEST_E262_NATIVE_PAIR_AND_TWO_CANONICAL_ARCHIVES_RETAINED'
stages = [
    ('run-fixed-exported-native-result-v1.py', 'exported-graceful-pair-verification.json'),
    ('run-fixed-exported-stale-retry-v1.py', 'exported-stale-retry-v2-verification-v1.json'),
    ('run-fixed-score-without-desktop-v1.py', 'score-without-desktop-verification.json'),
    ('run-fixed-socket-identity-v1.py', 'fixed-socket-identity-verification-v1.json'),
    ('verify-fixed-native-originals-readonly-v1.py', 'fixed-native-independent-verification-v1.json')]
files = [n / 'fixed_e262_native_common.py', n / 'fixed_e262_gateway_common.py', pathlib.Path(__file__)] + [n / s for s, _ in stages]
frozen = {str(p.relative_to(n)): sha(p) for p in files}
proof = {'status': 'WAITING_CURRENT_EXACT_FIXED_SQL', 'startedAtUtc': now(), 'ownRunnerPid': os.getpid(),
         'fixedCommit': 'e262ebf164e448cc9738d94db8e557f302cfc295', 'frozenNativeHarnessInputs': frozen,
         'actualNewVisibleControlsAndPhysicalWindows': 'OPEN', 'stages': []}

def write():
    temporary = out.with_suffix('.tmp')
    temporary.write_text(json.dumps(proof, indent=2) + '\n')
    temporary.replace(out)

def interrupted(signum, frame):
    raise InterruptedError('Only this exact acceptance chain interrupted.')

signal.signal(signal.SIGTERM, interrupted)
signal.signal(signal.SIGINT, interrupted)
write()
process = None
try:
    deadline = time.monotonic() + 5400
    while time.monotonic() < deadline:
        sql = load(n / 'real-sql-verification-v1.json')
        if sql['status'] != 'RUNNING_NOT_ACCEPTANCE':
            break
        time.sleep(2)
    else:
        raise TimeoutError('Actual fixed SQL evidence still incomplete; no native acceptance claimed.')
    assert sql['fixedCommit'] == proof['fixedCommit'] and sql['status'].startswith('PASS_REAL_SQL_SIX_ORIGINALS')
    assert sql['ownPostgresSmartStopped'] and sql['allFrozenRuntimeAndHarnessInputsStillExact']
    proof['fixedSqlReceiptSha256'] = sha(n / 'real-sql-verification-v1.json')
    for script, receipt in stages:
        assert all(sha(n / p) == h for p, h in frozen.items())
        assert not (n / receipt).exists()
        proof.update(status='RUNNING_NOT_ACCEPTANCE', currentStage=script)
        write()
        with (n / (script + '.runner.log')).open('x') as log:
            process = subprocess.Popen(['python3', str(n / script)], cwd=r, stdout=log, stderr=subprocess.STDOUT)
            proof['ownStagePid'] = process.pid
            write()
            code = process.wait(timeout=900)
        row = {'script': script, 'exitCode': code, 'finishedAtUtc': now()}
        if (n / receipt).exists():
            result = load(n / receipt)
            row.update(receipt=receipt, receiptSha256=sha(n / receipt), status=result.get('status'))
        proof['stages'].append(row)
        write()
        assert code == 0 and row.get('status', '').startswith('PASS')
        assert result['ownPostgresSmartStopped']
    proof.update(status='PASS_FIXED_EXPORTED_RESULT_STALE_RETRY_GATEWAY_COLD_SCORE_SOCKET_AND_INDEPENDENT_REAL_SQL_REPLAY',
                 allNativeHarnessInputsStillExact=all(sha(n / p) == h for p, h in frozen.items()),
                 visibleAndPhysicalWindows='OPEN')
except BaseException as error:
    proof.update(status='FAILED_OR_INTERRUPTED_CHAIN_ORIGINAL_PREFIX_RETAINED', errorType=type(error).__name__, errorMessage=str(error))
    raise
finally:
    if process is not None and process.poll() is None:
        process.terminate()
        process.wait(timeout=30)
    proof['finishedAtUtc'] = now()
    write()
print(proof['status'], flush=True)
