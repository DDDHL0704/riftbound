from fixed_e262_native_common import *

gateway = load(n / 'fixed-background-native-build-v1.json')
assert gateway['status'] == 'FIXED_NATIVE_GATEWAY_AND_ACTUAL_NET8_CURRENT_CI_CONTRACTS_BUILT_NO_GODOT_SDK'
assert gateway['fixedCommit'] == fixed
base_verify = verify_fixed

def verify_fixed():
    base_verify()
    assert all(sha(n / path) == digest for path, digest in gateway['files'].items())
    assert all(sha(n / path) == digest for path, digest in gateway['sourceFiles'].items())
    assert sha(n / 'score-network/bin/Release/net8.0/Riftbound.Contracts.dll') == gateway['nativeContractsSha256']

verify_fixed()
