# coding: utf-8
"""Two production native gateways, own API cold restart, original SQL replay; no UI."""
import fcntl, hashlib, json, os, runpy, selectors, signal, socket, subprocess, time, urllib.request
from pathlib import Path

os.umask(0o077)
n=Path(__file__).resolve().parent
base=runpy.run_path(str(n/'fixed_e262_gateway_common.py'))
sha,load,write,now,query,digests,rooms,environment,lock_observation,verify_fixed=[base[k] for k in
    ['sha','load','write','now','query','digests','rooms','environment','lock_observation','verify_fixed']]
pg,cluster,sock,api,reader,dotnet=[base[k] for k in ['pg','cluster','sock','api','reader','dotnet']]
runtime=n/'score-network/bin/Release/net8.0'
reader=n/'fixed-api'
identity=base['identity']
manifest=n/'score-without-desktop-inputs.json'
if not manifest.exists():
    files={str(p.relative_to(n)):sha(p) for p in runtime.rglob('*') if p.is_file()}
    files.update({str(p.relative_to(n)):sha(p) for p in reader.rglob('*') if p.is_file()})
    for p in [n/'native-frame-reader/Program.cs',n/'native-frame-reader/nativeframe.csproj',n/'score-network/Program.cs',n/'score-network/score.csproj',Path(__file__)]: files[str(p.relative_to(n))]=sha(p)
    write(manifest,{'baseFixedInputsSha256':sha(n/'fixed-background-native-build-v1.json'),'files':files,'actualRuleInputs':identity})
fixed=load(manifest)
def verify():
    verify_fixed()
    assert sha(n/'fixed-background-native-build-v1.json')==fixed['baseFixedInputsSha256']
    assert all(sha(n/p)==digest for p,digest in fixed['files'].items())
    assert json.loads(subprocess.check_output(base['reader_command']+['identity-print'],env=environment('riftbound_here_native'),text=True))==identity
verify()
assert load(n/'real-sql-verification-v1.json')['status'].startswith('PASS')
checkpoint=n/'score-without-desktop-checkpoint.json'
if checkpoint.exists():
    saved=load(checkpoint)
    assert saved['fixedInputsSha256']==sha(manifest) and sha(n/saved['receipt'])==saved['receiptSha256']
    assert load(n/saved['receipt'])['status']=='PASS'
    print('EXISTING_VERIFIED_PAIRED_RECEIPT_REUSED'); raise SystemExit(0)
for _ in range(1800):
    dependency=n/'exported-stale-retry-v2-verification-v1.json'
    if dependency.exists():
        saved=load(dependency)
        if saved['status']!='RUNNING_NOT_ACCEPTANCE':break
    time.sleep(2)
else:raise AssertionError('Actual exported native stale retry still pending.')
assert saved['status'].startswith('PASS') and saved['ownPostgresSmartStopped']
guard=(n.parent/'ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
out=n/'score-without-desktop-verification.json';assert not out.exists()
proof={'startedAtUtc':now(),'fixedCommit':base['publication']['fixedCommit'],'actualRuleInputs':identity,
    'fixedInputsSha256':sha(manifest),'lockAtStart':lock_observation(),'noDesktopDependency':True,
    'noVisibleControlsOrWindowsClaim':True,'priorActualNativeRetryReceiptSha256':sha(dependency),'normalScorePathScope':'Cooperative unopposed Student conquest and hold using server-authorized original ordinary intents; not a broad card or format certificate.'}
write(out,proof)
api_process=None;pair=None;started=False;logs=[];power=None
def start_api():
    with socket.socket() as port_guard:
        port_guard.settimeout(.5)
        assert port_guard.connect_ex(('127.0.0.1',15839))!=0,'Do not take over another listening process.'
    log=n/('score-api-'+str(len(proof.get('ownApiPids',[])))+'.log')
    fd=os.open(log,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    process=subprocess.Popen([dotnet,str(api/'Riftbound.Api.dll')],cwd=api,
        env=dict(environment('riftbound_here_native'),ASPNETCORE_ENVIRONMENT='Production',ASPNETCORE_URLS='http://127.0.0.1:15839'),
        stdout=fd,stderr=subprocess.STDOUT,start_new_session=True)
    os.close(fd);proof.setdefault('ownApiPids',[]).append(process.pid)
    for _ in range(100):
        assert process.poll() is None,'Own fixed API exited.'
        try:
            with urllib.request.urlopen('http://127.0.0.1:15839/health',timeout=1) as response:health=json.load(response)
            assert health['persistenceMode']=='postgres' and health['environment']=='Production'
            listeners=subprocess.check_output(['/usr/sbin/lsof','-tiTCP:15839','-sTCP:LISTEN'],text=True).splitlines()
            assert set(listeners)=={str(process.pid)},'Health must belong to the own new API PID.'
            return process
        except (OSError,TimeoutError):time.sleep(.1)
    process.terminate();process.wait(timeout=20);raise AssertionError('Own API did not become ready.')
def frame(room,stage,expected_commands):
    path=n/('score-paired-'+stage+'-original-frame.json.gz');assert not path.exists()
    before=digests('riftbound_here_native',[room])
    evidence=json.loads(subprocess.check_output(base['reader_command']+['native-frame',room,str(path)],
        cwd=reader,env=environment('riftbound_here_native'),text=True))
    path.chmod(0o600)
    assert evidence['commands']==expected_commands and evidence['actualRuleInputs']==identity and evidence['originalNonZeroPrivateSeedPreserved']
    assert before==digests('riftbound_here_native',[room]),'Read/replay cannot change any original row.'
    return dict(evidence,originalFrameSha256=sha(path),allSevenTablesUnchangedByReader=True)
def interrupted(signum,frame):raise InterruptedError('Own runner interrupted.')
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
try:
    power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    proof.update(ownRunnerPid=os.getpid(),boundIdleSleepAssertionPid=power.pid,temporaryIdleAssertionEndsWithRunner=True)
    assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
    subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(n/'score-without-desktop-postgres.log'),'-o',
        f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],check=True,capture_output=True);started=True
    native=rooms('riftbound_here_native');audit=rooms('riftbound_acceptance');assert len(native)==37 and len(audit)==190
    native_before=digests('riftbound_here_native',native);audit_before=digests('riftbound_acceptance')
    proof.update(priorNativeRooms=native,prior190AuditRooms=audit,priorNativeSevenTables=native_before,priorAuditSevenTables=audit_before)
    write(out,proof)
    api_process=start_api()
    pair=subprocess.Popen([dotnet,str(runtime/'score.dll'),'fixede262-paired-score-restart'],cwd=runtime,
        stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1,start_new_session=True)
    proof['ownPairPid']=pair.pid
    selector=selectors.DefaultSelector();selector.register(pair.stdout,selectors.EVENT_READ)
    timeout=time.monotonic()+120;ready=None
    while time.monotonic()<timeout:
        if not selector.select(timeout=1):
            assert pair.poll() is None,'Actual pair helper exited before its original mulligan checkpoint.';continue
        line=pair.stdout.readline()
        if not line:raise AssertionError('Pair helper exited before cold-restart checkpoint.')
        logs.append(line)
        if line.startswith('PAIR_READY_FOR_RESTART '):ready=json.loads(line.removeprefix('PAIR_READY_FOR_RESTART '));break
    selector.close();assert ready is not None and ready['acceptedCommands']==4
    proof['originalBeforeRestartReplay']=frame(ready['room'],'before-restart',4)
    stopped_at=time.monotonic();api_process.terminate();api_process.wait(timeout=20)
    proof['oldApiGracefulStopBeforeColdRestart']=True
    api_process=start_api();proof['actualApiDowntimeSeconds']=time.monotonic()-stopped_at
    pair.stdin.write('API_RESTARTED\n');pair.stdin.flush()
    tail,_=pair.communicate(timeout=600);logs.append(tail)
    proof['pairExitCode']=pair.returncode;assert pair.returncode==0,'Retain original pair prefix and failed output.'
    receipt=load(n/'score-network-evidence/receipt.json')
    assert receipt['status']=='PASS' and receipt['room']==ready['room'] and receipt['acceptedCommands']>=7 and receipt['normalScoreThresholdObservedBothSides']
    assert receipt['restores']==[1,1] and receipt['privateHandRedaction'] and receipt['bothPrivateViewsAndPromptsExact']
    proof.update(wireReceipt=receipt,originalAfterContinuationReplay=frame(ready['room'],'after-continuation',receipt['acceptedCommands']))
    api_process.terminate();api_process.wait(timeout=20);proof['ownFinalApiGracefulStop']=True
    proof.update(all37PriorNativeRoomsSevenTablesExact=native_before==digests('riftbound_here_native',native),
        all190AuditRoomsSevenTablesExact=audit_before==digests('riftbound_acceptance'))
    assert proof['all37PriorNativeRoomsSevenTablesExact'] and proof['all190AuditRoomsSevenTablesExact']
    assert set(rooms('riftbound_here_native'))-set(native)=={ready['room']}
    import gzip
    before_frame=json.loads(gzip.decompress((n/'score-paired-before-restart-original-frame.json.gz').read_bytes()))
    after_frame=json.loads(gzip.decompress((n/'score-paired-after-continuation-original-frame.json.gz').read_bytes()))
    assert after_frame['commands'][:4]==before_frame['commands'] and after_frame['events'][:len(before_frame['events'])]==before_frame['events']
    assert after_frame['replayInitialState']==before_frame['replayInitialState'] and after_frame['openingSeed']==before_frame['openingSeed']!=0
    assert not any(row['commandType']=='SURRENDER' for row in after_frame['commands'])
    events=after_frame['events']
    assert any(event['event']['kind']=='MATCH_WON' for event in events)
    assert not any(event['event']['kind']=='BURNOUT_APPLIED' for event in events)
    assert not any(event['event']['payload'].get('reason')=='SURRENDER' for event in events if event['event']['kind']=='MATCH_WON')
    assert sum(event['event']['payload']['amount'] for event in events if event['event']['kind']=='SCORE_GAINED')>=8
    original_wire=n/'score-network-evidence/original-paired-wire-views.json.gz'
    assert sha(original_wire)==receipt['originalWireViewsSha256']
    wire=json.loads(gzip.decompress(original_wire.read_bytes()))
    for key,frame_value in [('before',before_frame),('afterRestore',before_frame),('final',after_frame)]:
        for side in wire[key]:
            player=side['Handle'];stored=frame_value['playerViews'][player]
            assert side['snapshot']==stored['snapshot'] and side['prompt']==stored['prompt']
    timeline=n/'score-network-evidence/original-private-wire-timeline.json.gz'
    assert sha(timeline)==receipt['originalWireTimelineSha256']
    steps=json.loads(gzip.decompress(timeline.read_bytes()))
    assert len(steps)==len(after_frame['commands'])==receipt['wireSteps']
    for step in steps:
        assert all(view['snapshot']['tick']==view['prompt']['snapshotTick']==step['tick'] for view in step['views'])
        for own in step['views']:
            other=next(view for view in step['views'] if view['Handle']!=own['Handle'])
            hand=other['snapshot']['players'][other['Handle']]['zones']['hand']
            opponent=own['snapshot']['players'][other['Handle']]
            assert opponent['zones']['hand']==[] and opponent['zones']['handHidden']==len(hand)
            assert not (set(hand)&set(opponent['objects']))
    proof.update(actualScoreFinishBothPrivateFinalViewsAndPromptsEqualStoredFrame=True,
        allPrivateTimelineTicksAndOpponentHandRedactionChecked=True,originalPrivateTimelineSha256=sha(timeline),
        originalNonzeroPrivateSeedAndFourCommandPrefixRetained=True,noBurnoutOrSurrender=True,
        originalFullReplayPassed=True,finalScores=receipt['finalScores'])
    proof.update(newOriginalRoomSevenTables=digests('riftbound_here_native',[ready['room']]),status='PASS',observedNativeRooms=38,observedAuditRooms=190)
except BaseException as error:
    proof.update(status='FAILED_OR_INTERRUPTED_ORIGINAL_EVIDENCE_RETAINED',errorType=type(error).__name__)
    raise
finally:
    if pair is not None and pair.poll() is None:
        pair.terminate()
        try:tail,_=pair.communicate(timeout=20);logs.append(tail)
        except subprocess.TimeoutExpired:pair.kill();tail,_=pair.communicate();logs.append(tail);proof['ownPairNeededKill']=True
    with os.fdopen(os.open(n/'score-network.log',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600),'w') as stream:stream.write(''.join(logs))
    if api_process is not None and api_process.poll() is None:api_process.terminate();api_process.wait(timeout=20);proof['ownApiGracefulStopInFinally']=True
    if started:
        result=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True)
        proof['ownPostgresSmartStopped']=result.returncode==0
    if power is not None:
        if power.poll() is None:power.terminate();power.wait(timeout=10)
        proof['boundIdleSleepAssertionEnded']=power.poll() is not None
    verify();proof.update(finishedAtUtc=now(),lockAtEnd=lock_observation(),fixedFilesStillExact=True,originalDatabaseRetained=cluster.exists())
    write(out,proof)
    if proof.get('status')=='PASS':
        assert proof.get('ownPostgresSmartStopped')
        write(checkpoint,{'fixedInputsSha256':sha(manifest),'receipt':out.name,'receiptSha256':sha(out)})
    fcntl.flock(guard,fcntl.LOCK_UN)
print('TWO_PRODUCTION_NATIVE_CLIENTS_COLD_RESTORE_NORMAL_SCORE_ORIGINAL_FULL_REPLAY_PASS')
