using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.Engine;
using Riftbound.Persistence;

if (!args.SequenceEqual(new[] { "validate-readonly-fixed-native-originals-v1" })) throw new Exception("Exact bounded gate required.");
var root = Path.GetFullPath(Environment.GetEnvironmentVariable("RIFTBOUND_FIXED_ACCEPTANCE_ROOT") ?? throw new Exception("Exact fixed evidence root required."));
var settings = new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
if (settings.Host != "127.0.0.1" || settings.Port != 55486 || settings.Database != "riftbound_here_native"
    || settings.Username != "codex_riftbound_audit") throw new Exception("Only the existing dedicated native database.");
settings.Options = "-c default_transaction_read_only=on";
await using var source = NpgsqlDataSource.Create(settings.ConnectionString);
var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
using var publication = JsonDocument.Parse(File.ReadAllText(Path.Combine(root, "fixed-api-publication-v1.json")));
if (!JsonNode.DeepEquals(JsonSerializer.SerializeToNode(RuleInputIdentity.Current, json),
        JsonNode.Parse(publication.RootElement.GetProperty("actualRuleInputs").GetRawText())))
    throw new Exception("Actual reader rule identity differs from frozen Release.");
var originals = new[] {
    ("exported-graceful-original-frame.json.gz", 7, 12, "MULLIGAN"),
    ("exported-stale-retry-v2-original-frame.json.gz", 8, 19, "SURRENDER"),
    ("score-paired-after-continuation-original-frame.json.gz", 45, 359, "NONE")
};
var checks = new List<object>();
foreach (var (file, commands, events, rejectedKind) in originals)
{
    using var zip = new GZipStream(File.OpenRead(Path.Combine(root, file)), CompressionMode.Decompress);
    var frozen = await JsonSerializer.DeserializeAsync<MatchRecoveryFrame>(zip, json) ?? throw new Exception("Original native frame missing.");
    var actual = await new PostgresMatchRecoveryStore(source).LoadAsync(frozen.RoomId, default) ?? throw new Exception("Original SQL room missing.");
    if (!JsonNode.DeepEquals(JsonSerializer.SerializeToNode(actual, json), JsonSerializer.SerializeToNode(frozen, json)))
        throw new Exception("Actual stored fields, nulls, original command order, events or private views differ from frozen original.");
    if (!actual.IsConsistent || actual.Commands.Count != commands || actual.Events.Count != events || actual.OpeningSeed == 0
        || actual.AuthoritativeState?.RuleInputs != RuleInputIdentity.Current || actual.ReplayInitialState is not { Tick: 0 } blank
        || blank.CardObjects.Count != 0) throw new Exception("Exact original native case invariant failed.");
    var rejected = actual.Commands.Where(command => !command.Accepted).ToArray();
    if (rejectedKind == "NONE")
    {
        if (rejected.Length != 0 || actual.Commands.Any(command => command.CommandType == "SURRENDER"))
            throw new Exception("The normal score case must retain its entirely accepted non-surrender intents.");
    }
    else if (rejected.Length != 1 || rejected[0].CommandType != rejectedKind
        || rejected[0].StartedTick != rejected[0].CompletedTick
        || rejected[0].StartedEventSequence != rejected[0].CompletedEventSequence)
        throw new Exception("Actual rejection must preserve state tick and event sequence atomically.");
    if (rejectedKind == "SURRENDER")
    {
        var surrender = actual.Commands.Where(command => command.CommandType == "SURRENDER").ToArray();
        if (surrender.Length != 2 || surrender[0].Accepted || !surrender[1].Accepted
            || surrender[0].RawCommand is not { } firstRaw || surrender[1].RawCommand is not { } secondRaw
            || firstRaw.GetProperty("snapshotTick").GetInt64() != 2
            || secondRaw.GetProperty("snapshotTick").GetInt64() != 5)
            throw new Exception("The native retry must preserve the actual original old and new prompt ticks.");
    }
    var errors = await MatchActionLogReplayer.ValidateRecoveryFrameAsync(actual, new CoreRuleEngine(), default);
    if (errors.Count != 0) throw new Exception("Original accepted and rejected action history replay failed: " + string.Join(';', errors));
    checks.Add(new { room = actual.RoomId, originalFrame = file, commands, events, rejectedCommands = rejected.Length,
        storedAndFrozenAllFieldsExact = true, originalNonzeroPrivateSeedPreserved = true, fullOriginalActionEventStateReplay = true });
}
Console.WriteLine(JsonSerializer.Serialize(new { status = "PASS_INDEPENDENT_ACTUAL_READONLY_THREE_NATIVE_ORIGINALS_AND_REJECTED_RETRY", checks,
    actualRuleInputs = RuleInputIdentity.Current, noHistorySeedOrStateRewrite = true, visibleAndPhysicalWindows = "OPEN" }, json));
