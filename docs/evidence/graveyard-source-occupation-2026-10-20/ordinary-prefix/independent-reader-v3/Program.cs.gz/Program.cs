using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using Riftbound.CardCatalog;
using Riftbound.Contracts;
using Riftbound.Engine;

var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
try
{
    if (args.Length != 2 || File.Exists(args[1])) throw new Exception("Original input directory and fresh receipt required.");
    var folder = Path.GetFullPath(args[0]);
    using var recipe = JsonDocument.Parse(await File.ReadAllTextAsync("tests/Riftbound.ConformanceTests/Fixtures/destruction-graveyard-openings.json"));
    var phoenix = recipe.RootElement.GetProperty("phoenixObjectId").GetString()!;
    var inputFiles = Directory.GetFiles(folder, "*.json.gz").Order(StringComparer.Ordinal).ToArray();
    var originalHashes = inputFiles.ToDictionary(p => p, Hash);
    var journalNode = await Read(Path.Combine(folder, "original-command-attempts.json.gz"));
    var journal = journalNode.Deserialize<MatchJournalEntry[]>(json)!;
    Equal(journalNode, JsonSerializer.SerializeToNode(journal, json), "All original journal fields and nulls survive typed read.");
    Check(journal.Length == 116 && journal.All(e => e.Accepted), "All 116 original commands accepted, without discarded failures.");
    foreach (var entry in journal)
    {
        entry.ValidateRuleInputs();
        Check(entry.RuleInputs == RuleInputIdentity.Current && entry.OpeningSeed == 0, "Actual identity and original zero seed retained in every historical row.");
        Equal(JsonSerializer.SerializeToNode(entry.Snapshots, json), JsonSerializer.SerializeToNode(ResolutionResult.BuildSnapshots(entry.AuthoritativeState), json), "Every original private snapshot matches its own historical state.");
        Equal(JsonSerializer.SerializeToNode(entry.Prompts, json), JsonSerializer.SerializeToNode(ResolutionResult.BuildPrompts(entry.AuthoritativeState), json), "Every original prompt matches its own historical state.");
    }
    var rows = recipe.RootElement.GetProperty("openingIntents").EnumerateArray().ToArray();
    for (var i = 0; i < 82; i++)
    {
        var expected = GameCommandJsonMapper.Map(rows[i].GetProperty("rawCommand"));
        if (i == 0)
        {
            var deck = (SubmitDeckCommand)expected;
            Check(deck.MainDeck.Count(c => c == "SFD·018/221") == 3, "Original exact filler identity.");
            expected = deck with { MainDeck = deck.MainDeck.Select(c => c == "SFD·018/221" ? "UNL-180/219" : c).ToArray() };
        }
        var actual = GameCommandJsonMapper.Map(journal[i].RawCommand!.Value);
        Check(journal[i].PlayerId == rows[i].GetProperty("playerId").GetString(), "Original actor sequence.");
        Equal(JsonSerializer.SerializeToNode(expected, expected.GetType(), json), JsonSerializer.SerializeToNode(actual, actual.GetType(), json), "Original next 81 intent values and explicitly derived first deck.");
    }
    var catalog = await OfficialCardCatalog.LoadDefaultAsync();
    foreach (var entry in journal.Where(e => e.CommandType == CommandTypes.SubmitDeck))
    {
        var deck = (SubmitDeckCommand)GameCommandJsonMapper.Map(entry.RawCommand!.Value);
        foreach (var format in new[] { OfficialDeckFormat.CoreRules, OfficialDeckFormat.ChinaStandard20260724 })
        {
            var valid = OfficialDeckValidator.Validate(new(deck.LegendCardNo, deck.ChampionCardNo, deck.MainDeck, deck.RuneDeck, deck.Battlefields), catalog, format);
            Check(valid.IsValid, "Original actual submitted deck in both exact formats: " + string.Join(';', valid.Errors));
        }
    }
    var frames = new Dictionary<string, MatchRecoveryFrame>();
    foreach (var file in inputFiles.Where(p => p.EndsWith("-original-frame.json.gz", StringComparison.Ordinal)))
    {
        var node = await Read(file); var frame = node.Deserialize<MatchRecoveryFrame>(json)!;
        Equal(node, JsonSerializer.SerializeToNode(frame, json), "All original frame fields and nulls preserved.");
        Check(frame.ReplayInitialState is { Tick: 0, Seed: 0 } initial && initial.CardObjects.Count == 0, "Actual blank initial state, no injected position.");
        Check(frame.AuthoritativeState!.RuleInputs == RuleInputIdentity.Current && frame.ValidationErrors.Count == 0, "Original input identity and ordinary recovery shape.");
        var errors = await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame, new CoreRuleEngine(), default);
        Check(errors.Count == 0, Path.GetFileName(file) + ": original full action/event/final-state replay " + string.Join(';', errors));
        frames.Add(Path.GetFileName(file), frame);
    }
    var paid = frames["two-original-skills-paid-original-frame.json.gz"].AuthoritativeState!;
    Check(paid.StackItems.Count == 2 && paid.PendingPayment is null && paid.PlayerZones["P1"].Graveyard.Contains(phoenix), "Two fully earned and paid independent skills while actual card remains in graveyard.");
    Check(paid.StackItems.All(s => s.GraveyardPlay!.Source == new ObjectBinding(phoenix, 3)
        && s.TriggerCost!.Mana == 1 && s.TriggerCost.Power == 1), "Both printed fees and exact original incarnation bound.");
    var payCommands = journal.Where(e => e.CommandType == CommandTypes.PayCost).Select(e => (PayCostCommand)GameCommandJsonMapper.Map(e.RawCommand!.Value)).ToArray();
    Check(payCommands.Length == 3 && payCommands[0].PaymentChoiceIds!.SequenceEqual(["DECLINE"])
        && payCommands.Skip(1).All(c => c.PaymentChoiceIds!.SequenceEqual(["PAY"]))
        && payCommands.Select(c => c.PaymentId).Distinct().Count() == 3, "First self skill declined, next two printed fees independently confirmed.");
    var pending = frames["original-effect-play-with-sibling-original-frame.json.gz"].AuthoritativeState!;
    Check(pending.PendingEffectPlay!.Parent.GraveyardPlay!.Source == new ObjectBinding(phoenix, 3)
        && pending.StackItems.Single().GraveyardPlay!.Source == new ObjectBinding(phoenix, 3), "Current effect-play parent and surviving sibling bind original source independently.");
    var finalFrame = frames["final-original-frame.json.gz"]; var final = finalFrame.AuthoritativeState!;
    Check(finalFrame.Commands.Count == 116 && finalFrame.Events.Count == 482 && final.Status == MatchStatuses.InProgress
        && final.PlayerZones["P1"].Base.Contains(phoenix) && final.CardObjects[phoenix].ObjectGeneration == 4
        && final.StackItems.Count == 0 && final.TriggerQueue.Count == 0 && final.PendingEffectPlay is null && final.PendingPayment is null,
        "Actual ordinary original source play succeeds; sibling later finishes without a second play.");
    var commands = journal.Select(e => new RecoveredCommand(e.PlayerId, e.ClientIntentId, e.CommandType, e.RawCommand,
        e.StartedTick, e.CompletedTick, e.StartedEventSequence, e.CompletedEventSequence, e.Accepted, e.ErrorMessage) { RuleInputs = e.RuleInputs }).ToArray();
    var events = journal.SelectMany(e => e.Events.Select((ev, i) => new RecoveredEvent(e.StartedEventSequence + i + 1, e.CompletedTick, i, ev))).ToArray();
    Equal(JsonSerializer.SerializeToNode(commands, json), JsonSerializer.SerializeToNode(finalFrame.Commands, json), "Every original raw command, prompt/tick, identity and order equals final frame.");
    Equal(JsonSerializer.SerializeToNode(events, json), JsonSerializer.SerializeToNode(finalFrame.Events, json), "Every original event value and sequence equals final frame.");
    Check(journal[^1].Events.All(e => e.Kind != "CARD_PLAYED") && journal[^1].Events.Any(e => e.Kind == "TRIGGER_RESOLVED"), "Last old sibling resolves without borrowing new incarnation.");
    foreach (var pair in originalHashes) Check(Hash(pair.Key) == pair.Value, "All original inputs unchanged by independent reader.");
    await File.WriteAllTextAsync(args[1], JsonSerializer.Serialize(new { status = "PASS_INDEPENDENT_ORDINARY_TWO_SKILLS_ORIGINAL_JOURNAL_PRIVATE_HISTORY_AND_COMPLETE_REPLAY",
        commands = 116, events = 482, originalJournalRows = journal.Length, originalFrames = frames.Count,
        actualRuleInputs = final.RuleInputs, originalHashes, allOriginalFieldsNullsAndEveryHistoricalPrivateView = true,
        originalBlankSeedAndNext81IntentsPreserved = true, firstDeckThreeFillerSubstitutionsExplicit = true,
        bothDecksValidInBothFormats = true, twoIndependentFeesAndOriginalGenerationPlay = true,
        lastSiblingResolvedWithoutAnotherPlay = true, noNewGameplayOrOriginalHistoryRewrite = true,
        sqlVisibleReentryWholePrintingCertified = false }, json));
    Console.WriteLine("PASS_INDEPENDENT_ORDINARY_TWO_SKILLS_ORIGINAL_JOURNAL_PRIVATE_HISTORY_AND_COMPLETE_REPLAY");
}
catch (Exception error) { Console.Error.WriteLine(error); Environment.ExitCode = 1; }

async Task<JsonNode> Read(string path)
{
    await using var f = File.OpenRead(path); await using var z = new GZipStream(f, CompressionMode.Decompress);
    return await JsonNode.ParseAsync(z) ?? throw new Exception("Original JSON required.");
}
static string Hash(string path) => Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(path)));
static void Check(bool value, string reason) { if (!value) throw new Exception(reason); }
static void Equal(JsonNode? a, JsonNode? b, string reason) => Check(JsonNode.DeepEquals(a, b), reason);
