using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Nodes;
using Riftbound.CardCatalog;
using Riftbound.Contracts;
using Riftbound.Engine;

if (args.Length != 2) throw new Exception("Fresh output and exact format required.");
var output = Path.GetFullPath(args[0]);
if (Directory.Exists(output)) throw new Exception("Original outputs must not be replaced.");
Directory.CreateDirectory(output);
var format = Enum.Parse<OfficialDeckFormat>(args[1]);
var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
using var recipe = JsonDocument.Parse(await File.ReadAllTextAsync("tests/Riftbound.ConformanceTests/Fixtures/destruction-graveyard-openings.json"));
var initial = MatchReplayInitialStateBuilder.FromSeats("ordinary-sibling-source-v1-" + format,
    new Dictionary<string, string> { ["P1"] = "P1", ["P2"] = "P2" });
Check(initial.Tick == 0 && initial.Seed == 0 && initial.CardObjects.Count == 0, "Actual blank initial and original zero seed.");
var engine = new CoreRuleEngine(); var journal = new Journal();
var options = new MatchSessionOptions(AllowLegacyReadyWithoutDeck: false, DeckFormat: format);
IMatchSession session = new MatchSession(initial, engine, journal, NoopMatchPlayerStore.Instance, options);
var state = initial; var coldCount = 0; var nextMatches = 0; var afterCold = false;
var milestones = new List<object>();
MatchRecoveryFrame Frame()
{
    var sequence = journal.Entries[^1].CompletedEventSequence;
    var snapshots = ResolutionResult.BuildSnapshots(state); var prompts = ResolutionResult.BuildPrompts(state);
    var views = initial.Seats.Keys.ToDictionary(p => p, p => new RecoveredPlayerView(p, state.Tick, sequence,
        snapshots[p], state.Tick, sequence, prompts[p]));
    var spectator = MatchReplayRedactor.BuildSpectatorFrame(initial.RoomId, state.Tick, sequence, [], state);
    var errors = MatchRecoveryValidator.Validate(initial.RoomId, sequence, journal.Commands(), journal.Events(), views, state, state.Tick, spectator);
    return new(initial.RoomId, state.Tick, sequence, journal.Commands(), journal.Events(), views, errors, state, initial, spectator);
}
async Task Act(string actor, GameCommand command)
{
    if (command is SubmitDeckCommand deck)
    {
        var catalog = await OfficialCardCatalog.LoadDefaultAsync();
        foreach (var f in new[] { OfficialDeckFormat.CoreRules, OfficialDeckFormat.ChinaStandard20260724 })
        {
            var valid = OfficialDeckValidator.Validate(new(deck.LegendCardNo, deck.ChampionCardNo, deck.MainDeck, deck.RuneDeck, deck.Battlefields), catalog, f);
            Check(valid.IsValid, string.Join(';', valid.Errors));
        }
    }
    var intent = "ordinary-sibling-v1-" + journal.Entries.Count;
    var fields = JsonSerializer.SerializeToNode(command, command.GetType(), json)!.AsObject();
    fields["promptId"] = session.PromptFor(actor).PromptId; fields["snapshotTick"] = state.Tick;
    var raw = JsonSerializer.SerializeToElement(fields, json);
    var expected = afterCold ? await engine.ResolveAsync(state, new(intent, actor, command.CmdType), command, default) : null;
    var result = command switch {
        SubmitDeckCommand deck => await session.SubmitDeckAsync(actor, intent, deck, raw, default),
        ReadyCommand => await session.ReadyAsync(actor, intent, raw, default),
        _ => await session.SubmitAsync(actor, intent, command, raw, default) };
    Check(result.Accepted, command.CmdType + ": " + result.ErrorMessage);
    if (afterCold)
    {
        Check(expected!.Accepted && MatchStateHasher.Hash(expected.State) == MatchStateHasher.Hash(result.State)
            && JsonNode.DeepEquals(JsonSerializer.SerializeToNode(expected.Events), JsonSerializer.SerializeToNode(result.Events)), "Original next command remains equal after cold restore.");
        nextMatches++;
    }
    state = result.State; afterCold = false;
    Check(Frame().ValidationErrors.Count == 0, "Accepted command retained valid recovery shape.");
}
async Task Cold(string label)
{
    var before = Frame(); Check(before.ValidationErrors.Count == 0, "Ordinary frame shape.");
    var original = JsonSerializer.SerializeToNode(before, json);
    var restored = JsonSerializer.Deserialize<MatchRecoveryFrame>(JsonSerializer.Serialize(before, json), json)!;
    Check(JsonNode.DeepEquals(original, JsonSerializer.SerializeToNode(restored, json)), "Every original field and null survives typed roundtrip.");
    var errors = await MatchActionLogReplayer.ValidateRecoveryFrameAsync(restored, engine, default);
    Check(errors.Count == 0, label + ": full original ordinary opening/action/event replay " + string.Join(';', errors));
    var previous = session;
    session = MatchSession.Restore(restored, engine, journal, NoopMatchPlayerStore.Instance, options);
    foreach (var player in initial.Seats.Keys)
    {
        Check(JsonNode.DeepEquals(JsonSerializer.SerializeToNode(previous.SnapshotFor(player)), JsonSerializer.SerializeToNode(session.SnapshotFor(player))), "Private snapshot restored.");
        Check(JsonNode.DeepEquals(JsonSerializer.SerializeToNode(previous.PromptFor(player)), JsonSerializer.SerializeToNode(session.PromptFor(player))), "Private prompt restored.");
    }
    coldCount++; afterCold = true;
    await Save(label + "-original-frame.json.gz", before);
    milestones.Add(new { label, state.Tick, commands = before.Commands.Count, events = before.Events.Count, hash = MatchStateHasher.Hash(state) });
}
async Task Save(string name, object value)
{
    await using var file = new FileStream(Path.Combine(output, name), FileMode.CreateNew);
    await using var zip = new GZipStream(file, CompressionLevel.SmallestSize);
    await JsonSerializer.SerializeAsync(zip, value, value.GetType(), json);
}
async Task Resources(int mana, int red)
{
    while (state.RunePools["P1"].Mana < mana)
    {
        var rune = state.PlayerZones["P1"].Base.FirstOrDefault(id => state.CardObjects[id].Tags.Contains(CardObjectTags.RuneCard) && !state.CardObjects[id].IsExhausted);
        Check(rune is not null, "Enough actual ready runes for this new ordinary prefix.");
        await Act("P1", new TapRuneCommand(rune!));
    }
    while (state.RunePools["P1"].PowerByTrait.GetValueOrDefault("red") < red)
    {
        var rune = state.PlayerZones["P1"].Base.FirstOrDefault(id => state.CardObjects[id].Tags.Contains(CardObjectTags.RuneCard) && state.CardObjects[id].Tags.Contains("COLOR:red"));
        Check(rune is not null, "Enough actual red runes for independent leading fees.");
        if (!state.CardObjects[rune!].IsExhausted) await Act("P1", new TapRuneCommand(rune!));
        await Act("P1", new RecycleRuneCommand(rune!));
    }
}
async Task Top() { await Act(state.PriorityPlayerId!, new PassPriorityCommand()); await Act(state.PriorityPlayerId!, new PassPriorityCommand()); }
async Task Pay()
{
    var payment = state.PendingPayment ?? throw new Exception("Independent leading confirmation required.");
    Check(payment.ManaCost == 1 && payment.PowerCostByTrait.GetValueOrDefault("red") == 1, "Original printed leading fee.");
    await Resources(1, 1); await Act("P1", new PayCostCommand(payment.PaymentId, payment.PaymentWindow, ["PAY"]));
}
try
{
    foreach (var row in recipe.RootElement.GetProperty("openingIntents").EnumerateArray())
        await Act(row.GetProperty("playerId").GetString()!, GameCommandJsonMapper.Map(row.GetProperty("rawCommand")));
    Check(journal.Entries.Count == 82, "Original 82 intents retained without seed/deck edits.");
    await Cold("original-82-prefix");
    Console.WriteLine(JsonSerializer.Serialize(new { phase = "original-82-prefix", state.Turn, pool = state.RunePools["P1"], hand = state.PlayerZones["P1"].Hand }, json));
    var phoenix = recipe.RootElement.GetProperty("phoenixObjectId").GetString()!;
    var extra = state.PlayerZones["P1"].Hand.First(id => state.CardObjects[id].CardNo == "OGN·010/298");
    var field = state.ObjectLocations[phoenix].BattlefieldObjectId!;
    await Resources(3, 1);
    await Act("P1", new PlayCardCommand(extra, "OGN·010/298", [], OptionalCosts: [HasteOptionalCostNames.HasteReady]));
    Check(!state.CardObjects[extra].IsExhausted, "Real extra cost enters active.");
    await Act("P1", new MoveUnitCommand(extra, "BASE", "BATTLEFIELD:" + field));
    for (var i = 0; i < 4; i++)
    {
        var actor = initial.Seats.Keys.FirstOrDefault(p => ResolutionResult.BuildPrompts(state)[p].Candidates?.Any(c => c.Action == CommandTypes.PassFocus) == true);
        if (actor is null) break; await Act(actor, new PassFocusCommand());
    }
    await Resources(1, 1);
    var ray = recipe.RootElement.GetProperty("selfRayIntent");
    await Act("P1", GameCommandJsonMapper.Map(ray.GetProperty("rawCommand"))); await Top();
    Check(state.PlayerZones["P1"].Graveyard.Contains(phoenix) && state.CardObjects[phoenix].ObjectGeneration == 3, "Actual self spell first graveyard incarnation.");
    await Pay(); await Cold("first-original-skill-paid");
    if (state.PriorityPlayerId != "P1") await Act(state.PriorityPlayerId!, new PassPriorityCommand());
    await Resources(1, 1);
    var secondRay = state.PlayerZones["P1"].Hand.First(id => state.CardObjects[id].CardNo == "OGN·009/298");
    await Act("P1", new PlayCardCommand(secondRay, "OGN·009/298", [extra])); await Top();
    Check(state.PlayerZones["P1"].Graveyard.Contains(extra) && state.StackItems.Count == 2, "Second actual spell earns another skill while original remains.");
    Check(state.StackItems.All(s => s.GraveyardPlay?.Source == new ObjectBinding(phoenix, 3)), "Both references bind the same original graveyard generation.");
    await Pay(); await Cold("two-original-skills-paid"); await Top();
    Check(state.PendingEffectPlay is not null && state.StackItems.Count == 1, "Shared effect play opens with sibling remaining.");
    await Cold("original-effect-play-with-sibling");
    await Act("P1", new PlayCardCommand(phoenix, "OGN·037/298", []));
    Check(state.PlayerZones["P1"].Base.Contains(phoenix) && state.CardObjects[phoenix].ObjectGeneration == 4, "Ordinary original Phoenix play accepts despite sibling reference.");
    await Top();
    Check(state.StackItems.Count == 0 && state.TriggerQueue.Count == 0 && state.PendingEffectPlay is null && state.PendingPayment is null, "Old sibling independently finishes without borrowing new source.");
    await Cold("final");
    await File.WriteAllTextAsync(Path.Combine(output, "receipt.json"), JsonSerializer.Serialize(new { status = "PASS_ORDINARY_BLANK_ORIGINAL_DECKS_SEED_AND_ACTUAL_TWO_SKILLS_SHARED_PLAY",
        format, commands = journal.Commands().Length, events = journal.Events().Length, coldCount, nextMatches, actualRuleInputs = state.RuleInputs,
        original82IntentsDecksAndSeedRetained = true, noStateMutation = true, completeOrdinaryOriginalReplayMatched = true,
        sqlOrVisibleProductOrReentryOrWholePrintingCertified = false }, json));
    Console.WriteLine("PASS_ORDINARY_BLANK_ORIGINAL_DECKS_SEED_AND_ACTUAL_TWO_SKILLS_SHARED_PLAY");
}
finally
{
    await Save("original-command-attempts.json.gz", journal.Entries);
    await Save("last-original-frame.json.gz", Frame());
    await File.WriteAllTextAsync(Path.Combine(output, "milestones.json"), JsonSerializer.Serialize(milestones, json));
}
static void Check(bool value, string message) { if (!value) throw new Exception(message); }
sealed class Journal : IMatchJournal
{
    public List<MatchJournalEntry> Entries { get; } = [];
    public ValueTask RecordAsync(MatchJournalEntry e, CancellationToken token) { Entries.Add(e); return ValueTask.CompletedTask; }
    public RecoveredCommand[] Commands() => Entries.Select(e => new RecoveredCommand(e.PlayerId, e.ClientIntentId, e.CommandType, e.RawCommand,
        e.StartedTick, e.CompletedTick, e.StartedEventSequence, e.CompletedEventSequence, e.Accepted, e.ErrorMessage) { RuleInputs = e.RuleInputs }).ToArray();
    public RecoveredEvent[] Events() => Entries.SelectMany(e => e.Events.Select((ev, i) => new RecoveredEvent(e.StartedEventSequence + i + 1, e.CompletedTick, i, ev))).ToArray();
}
