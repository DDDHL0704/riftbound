from pathlib import Path
import collections, datetime, gzip, hashlib, json, re, subprocess, types, xml.etree.ElementTree as ET, zipfile

w=Path(__file__).resolve().parent;root=w.parents[2];fixed='39eacb2e22ce365c2d56750382518bfcd1bdf32a'
load=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
run=load(w/'actual-ci-39520536954-snapshot-v6.json');downloads=load(w/'ci-39e-original-artifacts-download-receipt-v1.json')
assert run['headSha']==fixed and run['status']=='completed' and run['conclusion']=='success' and len(run['jobs'])==11 and all(j['status']=='completed' and j['conclusion']=='success' for j in run['jobs'])
artifacts={a['name']:a for a in downloads['artifacts']}
for a in artifacts.values():assert sha((root/a['path']).read_bytes())==a['sha256']
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def collect(path,check=False):
 cases=collections.Counter();methods=set();matrices=[];hashes={}
 with zipfile.ZipFile(path) as z:
  if check:
   assert z.read('ci-rule-suite-commit.txt').decode().strip()==fixed
   plan=json.loads(z.read('ci-rules/plan.json'));summary=json.loads(z.read('ci-rules/summary.json'))
   assert summary['profile']=='full' and summary['status']=='PASSED' and summary['total']==13368
   planned=[m for s in plan['shards'] for m in s['methods']];assert len(planned)==len(set(planned))==plan['discoveredMethods']==7642
  for name in z.namelist():
   if not name.endswith('/results.trx'):continue
   raw=z.read(name);hashes[name]=sha(raw);doc=ET.fromstring(raw);actual=set()
   defs={d.attrib['id']:d.find('t:TestMethod',ns).attrib for d in doc.findall('.//t:UnitTest',ns)}
   counters=doc.find('.//t:Counters',ns).attrib;assert int(counters['total'])==int(counters['passed']) and counters['failed']=='0' and counters['notExecuted']=='0'
   for row in doc.findall('.//t:UnitTestResult',ns):
    assert row.attrib['outcome']=='Passed';d=defs[row.attrib['testId']];method=d['className']+'.'+d['name'];methods.add(method);actual.add(method);cases[row.attrib['testName']]+=1
    for output in row.findall('.//t:StdOut',ns):
     for line in (output.text or '').splitlines():
      if line.startswith('PRECONSTRUCTED_MATRIX '):matrices.append(json.loads(line[len('PRECONSTRUCTED_MATRIX '):]))
   if check:assert actual==set(next(s['methods'] for s in plan['shards'] if s['name']==name.split('/')[-2]))
  if check:assert methods==set(planned) and sum(cases.values())==13368
 return cases,methods,matrices,hashes
current=collect(root/artifacts['conformance-results']['path'],True)
prior=load(w/'ci-c2-entire-full-independent-verification-v2.json')
old=next(a for a in prior['artifacts'] if a['name']=='conformance-results');assert sha((root/old['path']).read_bytes())==old['sha256'];before=collect(root/old['path'])
assert sum(before[0].values())==13368 and len(before[1])==7642 and not before[0]-current[0] and before[1]<=current[1]
assert sum((current[0]-before[0]).values())==0 and len(current[1]-before[1])==0
assert len(current[2])==1;matrix=current[2][0]
decks=json.loads(gzip.decompress((root/'var/qa/graveyard-source-fixed-candidate-20261020/native-visible-v1/live-api-eleven-preconstructed-decks-original.json.gz').read_bytes()));ids=[d['id'] for d in decks]
pairs={a+'-vs-'+b for a in ids for b in ids if a!=b}
assert len(ids)==11 and matrix['seed']==424242 and matrix['deckCount']==11 and matrix['pairCount']==110 and set(matrix['completed'])==pairs and all(re.fullmatch('[0-9a-f]{64}',h) for h in matrix['completed'].values())
full_methods={m for m in current[1] if m.startswith('Riftbound.ConformanceTests.FullGameEndToEndTests.')};assert len(full_methods)==143 and full_methods=={m for m in before[1] if m.startswith('Riftbound.ConformanceTests.FullGameEndToEndTests.')}
sql_dir=w/'ci-39e-independent-sql-members-v1';sql_dir.mkdir(exist_ok=True)
for index in range(4):
 target=sql_dir/str(index);target.mkdir(exist_ok=True)
 with zipfile.ZipFile(root/artifacts['postgres-partition-'+str(index)]['path']) as z:
  assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in z.namelist());
  for n in z.namelist():
   if n.endswith('/'):continue
   p=target/n;p.parent.mkdir(parents=True,exist_ok=True)
   if p.exists():assert p.read_bytes()==z.read(n)
   else:p.write_bytes(z.read(n))
manifest=sql_dir/'exact-fixed-39e-sql-manifest.json';manifest.write_bytes(subprocess.check_output(['git','show',fixed+':tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'],cwd=root))
module=types.ModuleType('exact_fixed_39e_gate');exec(compile(subprocess.check_output(['git','show',fixed+':scripts/sql-ci-gate.py'],cwd=root),'<exact-fixed-39e-gate>','exec'),module.__dict__)
sql=module.verify(fixed,manifest,sql_dir,dict.fromkeys(['scope','postgres_partitions','native_network'],'success'))
assert sql['caseCount']==49
with zipfile.ZipFile(root/artifacts['postgres-results']['path']) as z:assert json.loads(z.read('result.json'))==sql
with zipfile.ZipFile(root/artifacts['full-verification-gate']['path']) as z:
 gate=json.loads(z.read('result.json'));assert gate['commit']==fixed and gate['status']=='FIXED_COMMIT_FULL_CHILD_JOBS_ALL_SUCCEEDED' and all(v=='success' for v in gate['jobs'].values())
with zipfile.ZipFile(root/artifacts['native-network-results']['path']) as z:
 network={n:z.read(n).decode() for n in z.namelist()};assert all('error' not in n.lower() for n in network)
 assert network['commit.txt'].strip()==fixed
 log=network['native-network.log'];evidence=next(json.loads(line[len('NATIVE_ROOM_IDENTITY_EVIDENCE '):]) for line in log.splitlines() if line.startswith('NATIVE_ROOM_IDENTITY_EVIDENCE '))
 assert evidence['rejectedActions']==15 and evidence['leakedPrivateMessages']==0 and evidence['validReconnectTokenWasSupplied']
 assert 'Native canonical room identity passed:' in log and 'Native network recovery passed: socket loss, authenticated room restore, fresh snapshot, rejected-token guard.' in log
result={'status':'FIXED_39E_FULL_ORIGINALS_AND_INDEPENDENT_SQL_GATE_VERIFIED','atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commit':fixed,'runId':39520536954,'jobs':{j['name']:j['conclusion'] for j in run['jobs']},'actualCases':13368,'actualMethods':7642,'original13368Cases7642MethodsRetained':True,'addedCases':list((current[0]-before[0]).elements()),'addedMethods':sorted(current[1]-before[1]),'fullGameMethods':143,'matrix':matrix,'allOriginalPairIdsAndSeedRetained':True,'trxSha256':current[3],'sql':sql,'originalNetwork':evidence,'artifacts':downloads['artifacts'],'subsequentF059And64678AndCurrentUncommittedFixNotCovered':True,'wholePrintingVisiblePhysicalWindowsAndGoalComplete':False}
(w/'ci-39e-entire-full-independent-verification-v1.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS 39E actual13368/7642; all13368/7642 exact retained;143 original full/110pairs/11decks/424242;all49SQL independent gate;network15/0')
