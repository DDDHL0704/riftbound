using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

Check(args.Length==2&&!File.Exists(args[1]),"Exact evidence directory and fresh independent output required.");
var work=Path.GetFullPath(args[0]);var output=Path.GetFullPath(args[1]);var json=new JsonSerializerOptions(JsonSerializerDefaults.Web){WriteIndented=true};
var settings=new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));Check(settings.Host=="127.0.0.1"&&settings.Port==55486&&settings.Database=="riftbound_acceptance"&&settings.Username=="codex_riftbound_audit","Only own audit database.");settings.Options="-c default_transaction_read_only=on";await using var source=NpgsqlDataSource.Create(settings.ConnectionString);
var results=new List<object>();var rooms=new List<string>();var totalStates=0;var totalSnapshots=0;var totalPrompts=0;var totalCommands=0;var totalEvents=0;var rejections=0;
foreach(var branch in new[]{"owner-play","decline"})
{
    var directory=Path.Combine(work,"revealed-hand-prompt-order",branch);using var receipt=JsonDocument.Parse(File.ReadAllText(Path.Combine(directory,"receipt.json")));var room=receipt.RootElement.GetProperty("room").GetString()!;rooms.Add(room);
    var played=branch=="owner-play";
    var initial=JsonSerializer.Deserialize<MatchState>(File.ReadAllText(Path.Combine(directory,"explicit-original-controlled-initial.json")),json)!;
    var frame=await new PostgresMatchRecoveryStore(source).LoadAsync(room,default)??throw new Exception("Real retained SQL frame required.");using var original=Read(Path.Combine(directory,"final-original-frame.json.gz"));
    Check(Same(original.RootElement,JsonSerializer.SerializeToElement(frame,json)),"Every original final SQL frame field/null/omission equals the actual independent read.");
    Check(frame.IsConsistent&&frame.Commands.Count==receipt.RootElement.GetProperty("commands").GetInt32()&&frame.Events.Count==receipt.RootElement.GetProperty("events").GetInt32()&&initial.RoomId==room&&initial.Tick==0&&initial.RuleInputs==RuleInputIdentity.Current&&frame.AuthoritativeState!.RuleInputs==RuleInputIdentity.Current,"Exact controlled initial and current frozen identity.");
    Check(frame.ReplayInitialState is {Tick:0,CardObjects.Count:0}&&!Same(JsonSerializer.SerializeToElement(initial,json),JsonSerializer.SerializeToElement(frame.ReplayInitialState,json)),"Original blank replay metadata remains separate; explicit original controlled initial is supplied only to the independent replay.");
    using var intents=JsonDocument.Parse(File.ReadAllText(Path.Combine(directory,"all-original-accepted-intents.json")));Check(intents.RootElement.GetArrayLength()==frame.Commands.Count,"All original intents retained.");
    for(var i=0;i<frame.Commands.Count;i++)Check(frame.Commands[i].Accepted&&frame.Commands[i].RuleInputs==RuleInputIdentity.Current&&frame.Commands[i].PlayerId==intents.RootElement[i].GetProperty("actor").GetString()&&Same(frame.Commands[i].RawCommand!.Value,intents.RootElement[i].GetProperty("rawCommand")),"Every actor/full raw command and identity equals the original accepted input.");
    var states=new Dictionary<(long,long),MatchState>();var counts=new Dictionary<string,int>();
    await using(var connection=await source.OpenConnectionAsync())
    {
        Check((string)(await new NpgsqlCommand("show transaction_read_only",connection).ExecuteScalarAsync())! =="on","Actual read-only SQL session.");
        await using(var q=new NpgsqlCommand("select last_event_sequence,payload::text from state_snapshots where match_id=@room order by id",connection))
        {
            q.Parameters.AddWithValue("room",room);await using var rows=await q.ExecuteReaderAsync();
            while(await rows.ReadAsync())
            {
                var raw=rows.GetString(1);var state=JsonSerializer.Deserialize<MatchState>(raw,json)!;
                Check(JsonNode.DeepEquals(JsonNode.Parse(raw),JsonSerializer.SerializeToNode(state,json))&&state.RuleInputs==RuleInputIdentity.Current&&states.TryAdd((state.Tick,rows.GetInt64(0)),state),"All original authority fields/nulls, current identity and tick/event-sequence identity survive independent read.");
                if(state.PendingEffectPlay?.RevealedHand is { } hand)
                {
                    var pending=state.PendingEffectPlay;
                    Check(hand.OwnerId=="P2"&&hand.BattlefieldId=="BF"&&hand.BattlefieldGeneration==0&&hand.Cards.Count==3&&hand.Cards.Keys.ToHashSet().SetEquals(new[]{"ALTERNATE_UNIT","SPELL","U"})&&hand.Cards.Values.All(v=>v==0),"Literal original revealed hand identity set and exact battlefield binding.");
                    Check(pending.IgnoreAllCosts&&pending.IgnoreBaseMana&&pending.IgnoreBasePower&&pending.SourceZone=="HAND"&&pending.DestinationPolicy=="SPECIFIED_BATTLEFIELD"&&pending.Parent.SourceObjectId=="C"&&pending.Parent.CardNo=="UNL-139/219"&&pending.Parent.TargetObjectIds.SequenceEqual(new[]{"BF"}),"Literal original source, all-cost permission and fixed destination.");
                    Check(pending.PlayerId==(hand.Choosing?"P1":"P2")&&pending.Optional==hand.Choosing&&pending.Sources.Keys.ToHashSet().SetEquals(hand.Choosing?new[]{"ALTERNATE_UNIT","U"}:new[]{"U"}),"Original selector and owner-confirmation stages have their independent literal actor, optionality and legal source set.");
                }
            }
        }
        Check(states.Count==frame.Commands.Count&&frame.Commands.All(c=>states.ContainsKey((c.CompletedTick,c.CompletedEventSequence))),"Each accepted command retains its exact authoritative historical row.");
        var latest=frame.Commands.GroupBy(c=>c.CompletedTick).Select(g=>g.OrderBy(c=>c.CompletedEventSequence).Last()).ToArray();var expected=latest.SelectMany(c=>new[]{"P1","P2"}.Select(p=>(c.CompletedTick,c.CompletedEventSequence,p))).ToHashSet();
        foreach(var table in new[]{"snapshots","action_prompts"})
        {
            var column=table=="snapshots"?"snapshot_tick":"prompt_tick";await using(var constraint=new NpgsqlCommand($"select pg_get_constraintdef(oid) from pg_constraint where conrelid='{table}'::regclass and contype='u'",connection))Check((string)(await constraint.ExecuteScalarAsync())! ==$"UNIQUE (match_id, player_id, {column})","Actual existing private storage key is viewer/tick.");
            await using var q=new NpgsqlCommand($"select player_id,last_event_sequence,payload::text from {table} where match_id=@room order by id",connection);q.Parameters.AddWithValue("room",room);await using var rows=await q.ExecuteReaderAsync();var actual=new HashSet<(long,long,string)>();
            while(await rows.ReadAsync())
            {
                var actor=rows.GetString(0);var sequence=rows.GetInt64(1);var raw=rows.GetString(2);using var doc=JsonDocument.Parse(raw);var tick=doc.RootElement.GetProperty(table=="snapshots"?"tick":"snapshotTick").GetInt64();Check(states.TryGetValue((tick,sequence),out var state)&&actual.Add((tick,sequence,actor)),"Each private original row binds its original authority, sequence, tick and viewer.");
                var typed=table=="snapshots"?JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<SnapshotDto>(raw,json),json):JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<ActionPromptDto>(raw,json),json);Check(JsonNode.DeepEquals(JsonNode.Parse(raw),typed),"Every private field/null and conditional omission survives typed read.");
                var projection=table=="snapshots"?JsonSerializer.SerializeToNode(ResolutionResult.BuildSnapshots(state!)[actor],json):JsonSerializer.SerializeToNode(ResolutionResult.BuildPrompts(state!)[actor],json);Check(JsonNode.DeepEquals(JsonNode.Parse(raw),projection),"Every original private value equals its exact historical state projection.");
                var other=actor=="P1"?"P2":"P1";var visible=state!.PendingEffectPlay?.RevealedHand?.Cards.Keys.ToHashSet()??new HashSet<string>();
                foreach(var id in state.PlayerZones[other].MainDeck.Concat(state.PlayerZones[other].Hand).Except(visible))Check(!raw.Contains("\""+id+"\"",StringComparison.Ordinal),"Literal opponent hidden identity absent outside the original reveal window.");
                Check(!raw.Contains("\"HIDDEN_DECK\"",StringComparison.Ordinal)&&!doc.RootElement.TryGetProperty("openingSeed",out _),"Unrelated original deck identity and private opening seed never leak.");
                if(table=="action_prompts"&&actor=="P1"&&state.PendingEffectPlay?.RevealedHand is {Choosing:true})
                {
                    var candidate=doc.RootElement.GetProperty("candidates").EnumerateArray().Single(c=>c.GetProperty("action").GetString()=="CHOOSE_CARDS");
                    Check(candidate.GetProperty("metadata").GetProperty("viewedCards").EnumerateArray().Select(c=>c.GetProperty("id").GetString()).SequenceEqual(new[]{"ALTERNATE_UNIT","SPELL","U"}),"Literal stable ordinal list is independently verified in the actual retained JSONB prompt.");
                }
            }
            Check(actual.SetEquals(expected),"Both players retain exactly the latest original projection at each tick according to the actual existing key; no missing historical authority.");counts[table]=actual.Count;
        }
    }
    foreach(var pair in states)
    {
        var commands=frame.Commands.Where(c=>c.CompletedEventSequence<=pair.Key.Item2).ToArray();var events=frame.Events.Where(e=>e.Sequence<=pair.Key.Item2).ToArray();
        var verified=await MatchActionLogReplayer.VerifyFinalStateAsync(initial,commands,pair.Value,new CoreRuleEngine(),default,events);Check(verified.IsMatch,"Every original authority history independently replays from its exact original controlled initial: "+string.Join(';',verified.Errors));
    }
    foreach(var phase in new[]{"before-reveal","revealed-choice"}.Concat(played?new[]{"owner-confirmation"}:Array.Empty<string>()))
    {
        using var doc=Read(Path.Combine(directory,phase+"-original-frame.json.gz"));var originalFrame=doc.RootElement.Deserialize<MatchRecoveryFrame>(json)!;
        Check(Same(JsonSerializer.SerializeToElement(frame.Commands.Take(originalFrame.Commands.Count),json),doc.RootElement.GetProperty("commands"))&&Same(JsonSerializer.SerializeToElement(frame.Events.Take(originalFrame.Events.Count),json),doc.RootElement.GetProperty("events")),"Every original checkpoint retains its complete exact accepted action/event prefix.");
        var state=originalFrame.AuthoritativeState!;
        Check(MatchRecoveryValidator.Validate(room,originalFrame.LastEventSequence,originalFrame.Commands,originalFrame.Events,originalFrame.PlayerViews,state,originalFrame.CurrentTick).Count==0,"Original SQL checkpoint is independently valid before any forgery.");
        if(phase=="before-reveal")Check(state.PendingEffectPlay is null,"Original spell has not yet revealed its opponent's hand.");
        else
        {
            var pending=state.PendingEffectPlay!;
            var forged=new List<PendingEffectPlayState>{
                pending with {PlayerId=pending.PlayerId=="P1"?"P2":"P1"},
                pending with {IgnoreAllCosts=false},
                pending with {DestinationPolicy="ANY_BATTLEFIELD"},
                pending with {Sources=new Dictionary<string,long>{{"U",99}}},
                pending with {RevealedHand=pending.RevealedHand! with {OwnerId="P1"}},
                pending with {RevealedHand=pending.RevealedHand! with {BattlefieldGeneration=99}},
                pending with {Sources=new Dictionary<string,long>{{"SPELL",0}}},
                pending with {Optional=!pending.Optional}};
            foreach(var bad in forged)
            {
                Check(MatchRecoveryValidator.Validate(room,originalFrame.LastEventSequence,originalFrame.Commands,originalFrame.Events,originalFrame.PlayerViews,state with {PendingEffectPlay=bad},originalFrame.CurrentTick).Count>0,"Independent literal actor, cost, destination, generation, owner, battlefield, nonunit or optionality forgery rejects.");rejections++;
            }
        }
    }
    var final=frame.AuthoritativeState!;
    Check(final.PendingEffectPlay is null&&final.PendingCardChoice is null&&final.PendingPayment is null&&final.StackItems.Count==0&&final.Status==MatchStatuses.InProgress,"No residual original spell or permission window.");
    Check(final.PlayerZones["P2"].Hand.SequenceEqual(played?new[]{"ALTERNATE_UNIT","SPELL"}:new[]{"U","ALTERNATE_UNIT","SPELL"})&&final.PlayerZones["P2"].Base.SequenceEqual(new[]{"ALLY"})&&final.PlayerZones["P2"].MainDeck.SequenceEqual(new[]{"HIDDEN_DECK"})&&final.RunePools["P2"]==RunePool.Empty,"Original unselected hand order, untouched additional-sacrifice unit, private deck and empty owner pool remain literal.");
    Check(frame.Events.Count(e=>e.Event.Kind=="HAND_REVEALED")==1&&frame.Events.Count(e=>e.Event.Kind=="STATUS_EFFECT_APPLIED")== (played?1:0)&&frame.Events.All(e=>e.Event.Kind!="UNIT_DESTROYED"),"Exactly one reveal, conditional stun and no additional-cost sacrifice.");
    var selections=frame.Commands.Where(c=>c.RawCommand!.Value.GetProperty("cmdType").GetString()=="CHOOSE_CARDS").ToArray();
    Check(selections.Length==1&&selections[0].PlayerId=="P1"&&selections[0].RawCommand!.Value.GetProperty("choiceWindow").GetString()=="REVEALED_HAND_PLAY"&&selections[0].RawCommand!.Value.GetProperty("chosenObjectIds").EnumerateArray().Select(i=>i.GetString()).SequenceEqual(played?new[]{"U"}:Array.Empty<string>()),"Original effect controller selected only the literal unit or declined with zero cards.");
    var plays=frame.Commands.Where(c=>c.RawCommand!.Value.GetProperty("cmdType").GetString()=="PLAY_CARD").ToArray();Check(plays.Length==(played?2:1),"Exactly the original spell and, only if selected, its owner's unit play.");
    if(played)
    {
        var raw=plays[1].RawCommand!.Value;
        Check(plays[1].PlayerId=="P2"&&raw.GetProperty("sourceObjectId").GetString()=="U"&&raw.GetProperty("cardNo").GetString()=="OGN·208/298"&&raw.GetProperty("destination").GetString()=="BATTLEFIELD:BF"&&final.PlayerZones["P2"].Battlefields.Contains("U")&&final.ObjectLocations["U"].BattlefieldObjectId=="BF"&&final.CardObjects["U"].UntilEndOfTurnEffects.Contains("STUNNED"),"Original selected Cold-Blooded Noble is played by its owner at the fixed field and stunned without the forbidden additional sacrifice.");
    }
    totalStates+=states.Count;totalSnapshots+=counts["snapshots"];totalPrompts+=counts["action_prompts"];totalCommands+=frame.Commands.Count;totalEvents+=frame.Events.Count;results.Add(new{branch,room,commands=frame.Commands.Count,events=frame.Events.Count,states=states.Count,snapshots=counts["snapshots"],prompts=counts["action_prompts"],allFieldsAndEveryOriginalActionEventReplayExact=true});
}
await File.WriteAllTextAsync(output,JsonSerializer.Serialize(new{status="PASS_INDEPENDENT_CURRENT_REVEALED_HAND_ORDINAL_PROMPT_OWNER_PLAY_DECLINE_ALL_HISTORY_PRIVATE_FIELDS_EVERY_ORIGINAL_REPLAY",rooms,cases=2,commands=totalCommands,events=totalEvents,authoritativeHistoricalStates=totalStates,privateSnapshots=totalSnapshots,privatePrompts=totalPrompts,independentStructuralRejections=rejections,actualRuleInputs=RuleInputIdentity.Current,results,actualReadOnlyConnection=true,originalBlankReplayMetadataNotRewritten=true,visibleNormalOpeningWindowsOrWholePrintingAcceptance=false},json));
Console.WriteLine($"REVEALED_HAND_INDEPENDENT_PASS {totalCommands} commands {totalEvents} events {totalStates} states {totalSnapshots} snapshots {totalPrompts} prompts {rejections} structural rejects");
bool Same(JsonElement left,JsonElement right)=>JsonNode.DeepEquals(JsonNode.Parse(left.GetRawText()),JsonNode.Parse(right.GetRawText()));
static JsonDocument Read(string path){using var zip=new GZipStream(File.OpenRead(path),CompressionMode.Decompress);return JsonDocument.Parse(zip);}
static void Check(bool value,string message){if(!value)throw new Exception(message);}
