from pathlib import Path
import collections, datetime, gzip, hashlib, json, re, subprocess, xml.etree.ElementTree as ET

w=Path(__file__).resolve().parent;root=w.parents[2]
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
owner=load(w/'only-check-owner-terminal-v1.json');start=load(w/'only-check-start-inputs-v1.json');plan=load(w/'only-check-v1/plan.json')
assert owner['exitCode']==1 and owner['status']=='CHECK_FAILED_OR_INTERRUPTED_ORIGINAL_OUTPUT_RETAINED'
for field in ['all3323SourceHashesUnchanged','allSourceModesUnchanged','allConformanceInputPayloadsUnchanged','all23NativePayloadsUnchanged','boundIdleAssertionEnded']:assert owner[field],field
assert plan['discoveredMethods']==7646 and sum(len(s['methods']) for s in plan['shards'])==7505
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def read(path,failed_allowed=False):
 tree=ET.parse(path);defs={d.attrib['id']:d.find('t:TestMethod',ns).attrib for d in tree.findall('.//t:UnitTest',ns)};cases=collections.Counter();methods=set();failed=set();passed=set()
 for row in tree.findall('.//t:UnitTestResult',ns):
  d=defs[row.attrib['testId']];method=d['className']+'.'+d['name'];cases[row.attrib['testName']]+=1;methods.add(method)
  if row.attrib['outcome']=='Failed':assert failed_allowed;failed.add(method)
  else:assert row.attrib['outcome']=='Passed';passed.add(method)
 counters=tree.find('.//t:Counters',ns).attrib;assert int(counters['total'])==sum(cases.values()) and counters['notExecuted']=='0'
 return cases,methods,failed,passed,counters
baseline=root/start['originalBaselineTrx'];current=w/'only-check-v1/check/results.trx'
old_cases,old_methods,_,_,old_counts=read(baseline);cases,methods,failed,passed,counts=read(current,True)
expected_failed={'Riftbound.ConformanceTests.Cn16RuleInputSelectionTests.ActualPackagedInputsSelectTheCurrentCnCoreWithoutCertifyingAllItsSemantics','Riftbound.ConformanceTests.AhriCombatMightTests.PromotionKeepsEveryHistoricalRuntimeRecordAndItsExactSource'}
assert failed==expected_failed and counts['failed']=='2' and counts['passed']=='13229' and counts['total']=='13231'
assert sum(old_cases.values())==13230 and len(old_methods)==7504 and not old_cases-cases and old_methods<=methods
added=cases-old_cases;new_methods=methods-old_methods;assert sum(added.values())==len(new_methods)==1 and all('.RevealedHandPromptOrderTests.' in n for n in added) and new_methods<=passed
assert len(methods)==7505 and methods=={m for s in plan['shards'] for m in s['methods']}
focus_path=w/'focus-post-check-exact-source-expectations-v1/focus/results.trx';fc,fm,ff,fp,fcounts=read(focus_path)
assert not ff and expected_failed<=fp and len(fm)==15 and sum(fc.values())==38
changed={p for p,h in start['sourceInputHashes'].items() if sha(root/p)!=h}
expected_changed={'tests/Riftbound.ConformanceTests/AhriCombatMightTests.cs','tests/Riftbound.ConformanceTests/Cn16RuleInputSelectionTests.cs'}
assert changed==expected_changed and len(start['sourceInputHashes'])==3323
assert all(oct((root/p).stat().st_mode&0o777)==mode for p,mode in start['sourceInputModes'].items())
prior=w/'post-only-check-before-exact-source-expectation-refresh-v1';corrections=[]
for rel in sorted(changed):
 path=root/rel;before=gzip.decompress((prior/(path.name+'.gz')).read_bytes()).decode();after=path.read_text()
 assert collections.Counter(re.findall(r'Assert\.(\w+)\s*\(',before))==collections.Counter(re.findall(r'Assert\.(\w+)\s*\(',after))
 assert re.findall(r'\[(?:Fact|Theory|InlineData)\b[^\]]*\]',before)==re.findall(r'\[(?:Fact|Theory|InlineData)\b[^\]]*\]',after)
 assert re.findall(r'public\s+(?:async\s+)?(?:Task|void)\s+(\w+)\s*\(',before)==re.findall(r'public\s+(?:async\s+)?(?:Task|void)\s+(\w+)\s*\(',after)
 if path.name=='AhriCombatMightTests.cs':
  a=after.index('            // DOC-10-P002-B005 through B008');b=after.index('            ["UNL-081/219"]',a);assert after[:a]+after[b:]==before
 else:
  assert '9706138cf5ec1795ad41dc689632603bb0530807f81420362fc3fe770d2874e9' in after and 'PriorCn16Catalog' in after and 'd5dbe0401fc52312c0f9033702b8090ff4063499db878706317dc259d051ac29' in after
 corrections.append({'path':rel,'beforeSha256':hashlib.sha256(before.encode()).hexdigest(),'afterSha256':sha(path),'allOriginalMethodsTheoryRowsAndAssertCallCountsRetained':True})
pub=load(w/'current-integrated-sql-frozen-inputs-v1.json');runtime=Path(pub['runtimeRoot']);assert all(sha(runtime/p)==h for p,h in pub['runtimeFiles'].items())
full=load(w/'original-full-tests-sql-and-focus-union-retention-v1.json')
assert full['originalFullMethods']==143 and full['original110Pairs11Decks424242Retained']
for p,v in full['allFullGameSources'].items():assert sha(root/p)==v['newSha256']
old_sql=json.loads(subprocess.check_output(['git','show',start['baseCommit']+':tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'],cwd=root));sql=load(root/'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json');assert len(old_sql['cases'])==50 and sql['cases'][:50]==old_sql['cases'] and len(sql['cases'])==51
remediation={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'TWO_EXACT_SOURCE_EXPECTATIONS_REMEDIATED_FOCUS38_15_PASS_ALL_ORIGINAL_ASSERTIONS_RETAINED_NEW_FIXED_FULL_REQUIRED','onlyCheckOriginalFailureCount':2,'onlyChangedSourcesAfterCheck':corrections,'focusedCases':38,'focusedMethods':15,'focusedTrxSha256':sha(focus_path),'oldGoldenHistorical1009RecordsAndEveryOtherFieldStillAsserted':True,'newExactCurrentErratumWhitelistOnlyUNL139CardEffect':True,'oldPrior9706CatalogMismatchGuardRetainedAndRetiredEefCn16CatalogGuardAdded':True,'allActualGameAndSqlFrozenInputsUnchanged':True,'all89FrozenIntegratedSqlFilesExact':True,'noSecondCheck':True,'finalSourceHashes':{p:sha(root/p) for p in start['sourceInputHashes']},'newFixedFullRequired':True}
with (w/'post-only-check-exact-source-expectation-remediation-v1.json').open('x') as f:json.dump(remediation,f,indent=2);f.write('\n')
result={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'CHECK_COMPLETE_TWO_SOURCE_EXPECTATIONS_REMEDIATED_BY_FOCUS_EXACT_CASE_METHOD_PARITY_PASS','oldCasesPreserved':True,'oldMethodsPreserved':True,'frozenInputsUnchangedDuringOnlyCheck':True,'frozenInputsUnchanged':True,'failed':2,'skipped':0,'profile':'check','baseCommit':start['baseCommit'],'actualCases':13231,'actualMethods':7505,'passed':13229,'fullDiscoveryMethodsNotExecutedCount':7646,'allOriginal13230CaseNameCountMultisetAnd7504MethodsPreserved':True,'newCases':1,'newMethods':1,'addedCases':list(added.elements()),'addedMethods':sorted(new_methods),'failedMethods':sorted(failed),'all143FullMethodsNineSources110Pairs11Decks424242AndOriginalAssertionsRetained':True,'allOriginal50SqlIdentitiesAndOrderRetainedOnly51stAppended':True,'all3323SourceHashesModes1419ConformanceAnd23NativeStableThroughoutOnlyCheck':True,'baselineTrxSha256':sha(baseline),'actualTrxSha256':sha(current),'actualTestAssemblySha256':plan['testAssemblySha256'],'onlyOneCheckForCoherentBatch':True,'postOnlyCheckRemediation':{'path':str((w/'post-only-check-exact-source-expectation-remediation-v1.json').relative_to(root)),'sha256':sha(w/'post-only-check-exact-source-expectation-remediation-v1.json'),'focusedCases':38,'focusedMethods':15,'state':'FOCUS_GREEN_NEW_FIXED_FULL_PENDING'},'owner':owner,'wholePrintingOrAuditCertified':False}
with (w/'check-original-case-method-and-input-retention-v1.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print('SOLECHECK13231/7505:13229passed2original-source-expectationfailures0skip; all13230/7504 retained+1/1; correctedfocus38/15;game/sql/source/143full/110pairs/seed retained;no secondcheck;newfixedfull pending')
