from pathlib import Path
import copy, datetime, gzip, hashlib, json, re, tarfile

root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
w35=root/'var/qa/deck-play-ordered-observation-20261021'
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(path,value):
 with path.open('x') as stream:json.dump(value,stream,ensure_ascii=False,indent=2);stream.write('\n')
def pin(path,role=None):
 value={'path':str(path.relative_to(root)),'sha256':sha(path)}
 if role:value['role']=role
 return value

check=load(w/'check-original-case-method-and-input-retention-v1.json')
sql=load(w/'actual-current-integrated-five-sql-owner-terminal-v1.json')
source=load(w/'current-optional-and-hand-exact-source-scope-review-v1.json')
frozen=load(w/'current-integrated-sql-frozen-inputs-v1.json')
remediation=load(w/'post-only-check-exact-source-expectation-remediation-v1.json')
final_focus=load(w/'final-focus-after-exact-source-remediation-union-v1.json')
assert check['status']=='CHECK_COMPLETE_TWO_SOURCE_EXPECTATIONS_REMEDIATED_BY_FOCUS_EXACT_CASE_METHOD_PARITY_PASS' and check['actualCases']==13231 and check['actualMethods']==7505
assert check['failed']==2 and check['passed']==13229 and remediation['focusedCases']==38 and remediation['focusedMethods']==15
assert final_focus['distinctCases']==171 and final_focus['distinctMethods']==86
assert sql['status'].startswith('PASS_CURRENT_INTEGRATED_FIVE_') and sql['commands']==36 and sql['events']==94 and sql['ownPostgresSmartStopped']
assert sql['allOriginal255AuditSevenTablesExactAtStop'] and sql['allOriginal54NativeSevenTablesExactAtStop']
assert sum(r['readback']['authoritativeHistoricalStates'] for r in sql['independentReaders'])==36
assert sum(r['readback']['privateSnapshots'] for r in sql['independentReaders'])==72
assert all(sha(root/p)==h for p,h in remediation['finalSourceHashes'].items())
mp=root/'docs/audit/current-manifest.json';manifest=load(mp);rp=root/manifest['inputs']['reviews']['path'];reviews=load(rp)
assert len(reviews['reviews'])==153 and len(manifest['reviewContexts'])==68 and len(manifest['acceptanceGates'])==245 and len(manifest['laterSourceDeltas'])==7
prior=w/'prior-coherent-publication-governance-v1'
for path in [mp,rp,root/'docs/PROJECT_STATUS.md']:assert gzip.decompress((prior/(path.name+'.gz')).read_bytes())==path.read_bytes()
old_manifest=copy.deepcopy(manifest);old_reviews=copy.deepcopy(reviews)
stale=json.loads(gzip.decompress((prior/'four-complete-current-contexts-before-refresh.json.gz').read_bytes()))
assert len(stale)==4 and all(manifest['reviewContexts'][r['id']]==r['oldCompleteContext'] for r in stale)
ev=root/'docs/evidence/optional-observed-revealed-hand-2026-10-21';ev.mkdir(exist_ok=False)
standalone={
 'check-original-case-method-and-input-retention.json':w/'check-original-case-method-and-input-retention-v1.json',
 'original-full-tests-sql-and-focus-retention.json':w/'original-full-tests-sql-and-focus-union-retention-v1.json',
 'real-integrated-five-sql-terminal.json':w/'actual-current-integrated-five-sql-owner-terminal-v1.json',
 'independent-optional-all-history.json':w/'independent-current-integrated-optional-all-history-v1.json',
 'independent-hand-all-history.json':w/'independent-current-integrated-hand-all-history-v1.json',
 'current-exact-source-scope-review.json':w/'current-optional-and-hand-exact-source-scope-review-v1.json',
 'supporting-void-field-open-source-gap.json':w/'supporting-void-field-exact-provenance-and-open-disposition-v1.json',
 'supporting-void-field-issue-exact-body-readback.json':w/'supporting-void-field-catalog-issue-exact-body-verification-v1.json',
 'all-five-controlled-branches-no-damage.json':w/'all-five-current-controlled-branches-no-damage-events-v1.json',
 'completed-helper-staging-retirement.json':w/'completed-helper-generated-staging-retirement-v1.json',
 'post-only-check-source-expectation-remediation.json':w/'post-only-check-exact-source-expectation-remediation-v1.json',
 'final-focus-after-source-remediation-union.json':w/'final-focus-after-exact-source-remediation-union-v1.json',
 'prior39e-full-independent.json':w35/'ci-39e-entire-full-independent-verification-v1.json',
 'priorf059-full-independent.json':w35/'ci-f059-entire-full-independent-verification-v1.json',
 'prior39e-terminal-hash-comparison.json':w35/'ci-39e-vs-c2-original-terminal-hash-comparison-v1.json',
 'priorf059-terminal-hash-comparison.json':w35/'ci-f059-vs-39e-original-terminal-hash-comparison-v1.json',
 'preceding64678-headless-ci-native-subscope.json':w35/'current-fixed64678-ci-native-combined-subscope-readback-v1.json',
 'latest-only-native-retirement.json':w35/'superseded-fixed39e-native-pair-and-two-archives-retirement-v1.json',
 'completed39e-extraction-retirement.json':w35/'ci-39e-completed-duplicate-extraction-retirement-v1.json',
 'completedf059-extraction-retirement.json':w35/'ci-f059-completed-duplicate-extraction-retirement-v1.json'
}
for name,path in standalone.items():(ev/name).write_bytes(path.read_bytes())
focus=load(w/'original-full-tests-sql-and-focus-union-retention-v1.json');focus.update(newMethodNames=check['addedMethods'],newConformanceCases=1,newConformanceMethods=1,wholePrintingCertified=False,finalDistinctFocusCases=171,finalDistinctFocusMethods=86,postOnlyCheckSourceExpectationCorrection=pin(ev/'post-only-check-source-expectation-remediation.json'));write(ev/'focus-executed-distinct-scope.json',focus)
refresh={'atUtc':now(),'status':'FOUR_CURRENT_IMPLEMENTATION_INPUT_BINDINGS_ONLY_REFRESH_OLD_COMPLETE_CONTEXTS_SCOPES_AND_EVIDENCE_RETAINED','records':[{'id':r['id'],'changes':r['changes']} for r in stale],'oldWholeObjectsRetainedAsOriginalArchiveMembers':True,'historicalVerificationSourcesAndSourceDatesNotRebound':True,'noSemanticPromotion':True}
write(ev/'four-current-input-only-context-refresh.json',refresh)

members=[];excluded=[]
for path in sorted(w.rglob('*')):
 if not path.is_file():continue
 parts=path.relative_to(w).parts
 if {'bin','obj'}&set(parts) or any('-runtime-' in x or '-identity-probe-' in x for x in parts[:-1]):continue
 if path.name=='publish-optional-hand-coherent-batch-owner-v1.log':
  excluded.append({'path':str(path.relative_to(root)),'reason':'Running publication own stdout is not a test input/result; retain complete final stdout separately after publication'});continue
 members.append(path)
extra=[
 'next-revealed-hand-current-source-intake-v1.json','next-revealed-hand-current-original-api-response-v1.json.gz','next-hand-current-official-errata-and-faq-readback-v1.json',
 'frozen-fixed64678-native-composition-v1.json','fixed64678-clean-api-frozen-inputs-v1.json','fixed64678-api-actual-rule-inputs-v1.json','native-app-inputs.json','current-native-headless-boot-verification.json',
 'live-current-ci-main-ready-v2.json','live-current-ci-main-stop-v2.json','live-current-ci-main-owner-terminal-v2.json','current-fixed64678-ci-main-pair-owner-v1.log',
 'independent-fixed64678-native-history-result-v4.json','independent-fixed64678-native-history-run-v3.json','independent-fixed64678-native-history-run-v4.json',
 'current-fixed64678-ci-main-independent-owner-v1.log','current-fixed64678-ci-main-independent-owner-v2.log','independent-fixed64678-native-history-v3.log','independent-fixed64678-native-history-v4.log',
 'fixed64678-native-history-reader-frozen-v1.json','fixed64678-native-history-reader-frozen-v2.json','fixed64678-native-history-reader-v2-first-build-source-original.cs.gz','build-fixed64678-native-history-reader-v2.log','build-fixed64678-native-history-reader-v2-corrected-v1.log',
 'superseded-fixed39e-native-original-file-manifest-v1.json.gz','ci-39e-completed-duplicate-extraction-exact-original-member-manifest-v1.json.gz','ci-f059-completed-duplicate-extraction-exact-original-member-manifest-v1.json.gz',
 'exact-fixed-39e-sql-manifest-original-v1.json','exact-fixed-f059-sql-manifest-original-v1.json',
 'ci-39e-original-artifacts-download-receipt-v1.json','ci-f059-original-artifacts-download-receipt-v1.json','ci-39e-complete-backend-artifact-metadata-v1.json','ci-f059-complete-backend-artifact-metadata-v1.json',
 'actual-ci-39520536954-snapshot-v6.json','actual-ci-39530834010-terminal-snapshot-v1.json','verify-completed-fixed39e-full-originals-v1.py','verify-completed-fixedf059-full-originals-v1.py',
 'run-fixed64678-ci-main-pair-v1.py','run-independent-fixed64678-native-history-v1.py','run-independent-fixed64678-native-history-v2.py'
]
members.extend(w35/p for p in extra)
for prefix in ['ci-39e-complete-originals-v1','ci-f059-complete-originals-v1']:
 members.extend(sorted((w35/prefix).glob('*.zip')))
for folder in ['fixed64678-native-history-reader-source-v1','fixed64678-native-history-reader-source-v2']:
 members.extend(p for p in (w35/folder).iterdir() if p.is_file())
members.extend(sorted((w35/'actual-safe-native-main-v2').glob('*.json.gz')))
for folder in ['actual-safe-native-prefix-v2','actual-safe-normal-score-continuation-v2']:
 members.extend(p for p in (w35/folder).glob('*.json') if not p.name.startswith('session-'))
safe=[]
for path in members:
 assert path.is_file(),path
 raw=path.read_bytes()
 try:plain=gzip.decompress(raw) if path.suffix=='.gz' else raw
 except (OSError,EOFError):plain=raw
 if re.search(rb'"(?:playerKey|reconnectToken|sessionToken|password)"\s*:\s*"[^"\s]+"',plain,re.I):excluded.append({'path':str(path.relative_to(root)),'bytes':len(raw),'sha256':sha(path),'reason':'Credential-bearing operational original retained locally'});continue
 safe.append(path)
assert len(safe)==len(set(safe))
archive=ev/'completed-optional-hand-originals.tar.xz';rows=[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in safe]
with tarfile.open(archive,'x:xz',preset=6) as tar:
 for path in safe:tar.add(path,arcname=str(path.relative_to(root)),recursive=False)
with tarfile.open(archive,'r:xz') as tar:
 assert {p.name for p in tar.getmembers()}=={r['path'] for r in rows}
 for row in rows:
  raw=tar.extractfile(row['path']).read();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
write(ev/'archive-map.json',{'atUtc':now(),'archive':pin(archive),'members':rows,'explicitOperationalOrRunningPublicationExclusionsRetainedLocally':excluded,'allMemberBytesHashesAndClosedSetVerified':True,'runtimeApplicationsInstallersAndPrimaryPdfOriginalsRetainedLocallyNotDuplicated':True,'nextExhaustedLegendPrototypeNotPartOfThisBatch':True})
implementation=[pin(root/p,'implementation') for p in ['src/Riftbound.Engine/CoreRuleEngine.RevealedHandPlay.cs','data/official/card-catalog.zh-CN.json']]
verification=[pin(root/p,'verification-source') for p in ['tests/Riftbound.ConformanceTests/RevealedHandPromptOrderTests.cs','tests/Riftbound.ConformanceTests/OfficialRevealedHandPlayTests.cs','tests/Riftbound.ConformanceTests/AhriCombatMightTests.cs','tests/Riftbound.ConformanceTests/Cn16RuleInputSelectionTests.cs','tests/Riftbound.PostgresAcceptance/CandlelitPrivateLookSqlAcceptance.cs','tests/Riftbound.PostgresAcceptance/RevealedHandPromptOrderSqlAcceptance.cs','tests/Riftbound.PostgresAcceptance/Program.cs','tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json','scripts/tests/test_sql_ci_gate.py']]
sm={'atUtc':now(),'status':'BOUNDED_CN16_OPTIONAL3_HAND2_SQL_ONLY_CHECK_TWO_SOURCE_EXPECTATIONS_REMEDIATED_FOCUS_GREEN_NEW_FIXED_FULL_PRODUCT_OPEN','region':'CN','language':'zh-CN','observedAsOf':'2026-10-21','adoptedCoreEffectiveDate':'2026-10-16','exactCurrentSourceReview':source,'baseCommit':frozen['parentCommit'],'implementationIncludesDeclaredUncommittedChanges':True,'actualRuleInputs':sql['actualRuleInputs'],'implementation':implementation,'verificationSources':verification,'runtimeCatalogOnlyExactBoneRow34682CardEffectAdopted':True,'allOriginal50SqlIdentitiesAndOrderRetainedOnly51stAppended':'revealed-hand-prompt-order','allOriginal153ReviewObjectsRetained':True,'fourOnlyCurrentImplementationBindingsRefreshed':pin(ev/'four-current-input-only-context-refresh.json'),'archive':pin(archive),'wholePrintingCertified':False,'fixedCommitFullCurrentVisibleHardwarePairAndPhysicalWindows':'OPEN','preceding64678NativeNotNew237RuntimeProductAcceptance':True,'noOldDevelopmentMatchMigration':True}
sm.update(onlyCheckActualOutcome={'passed':13229,'failed':2,'skipped':0},postOnlyCheckSourceExpectationRemediation=pin(ev/'post-only-check-source-expectation-remediation.json'))
write(ev/'source-manifest.json',sm);sp=pin(ev/'source-manifest.json','source-manifest')
identity='optional-observed-revealed-hand-current-cn16-2026-10-21';assert identity not in manifest['reviewContexts']
subjects=source['subjectPrintings']+['OGN-296/298'];rules=source['ruleRecords'];open_rules=source['openSupportingFieldSourceGapRuleRecords']
reviews['reviews'].append({'id':identity,'scope':'Only three current optional observed permissions and two revealed-hand owner-play/decline branches, stable prompts and exact Bone effective-text adoption; the supporting Void Gate effective-text gap remains separately OPEN.','subjects':subjects,'ruleRecords':rules,'pendingRuleRecords':open_rules,'status':'BOUNDED_OPTIONAL3_HAND2_SQL36_94_CHECK13229PASS_2SOURCE_EXPECTATIONS_REMEDIATED_FOCUS38_SEPARATE_VOID_GATE_GAP_FULL_PRODUCT_OPEN','sourceManifest':sp,'auditDocument':'docs/OPTIONAL_OBSERVED_REVEALED_HAND_CURRENT_CN16_AUDIT_2026-10-21.md','validation':{'newConformanceCases':1,'newConformanceMethods':1,'distinctFocusCases':171,'distinctFocusMethods':86,'checkCases':13231,'checkMethods':7505,'checkPassed':13229,'checkFailed':2,'postCheckRemediationFocusCases':38,'postCheckRemediationFocusMethods':15,'sqlCommands':36,'sqlEvents':94,'sqlColdRecoveries':36,'allOriginal50SqlIdentitiesAnd143FullMethodsRetained':True,'wholeCardCertification':False},'exclusions':source['exclusions']+['Void Gate runtime adoption and damage semantics','Exhausted Reksai source confirmation behavior']})
branches=[]
for original in source['boundedBehaviorBranches']:
 branches.append({**original,'state':'RECORDED','sourceManifest':sp,'semanticReview':{'state':'BOUNDED_CURRENT_SOURCE_BRANCH_REVIEW','wholeClauseOrPrintingCertified':False},'implementation':{'state':'EXISTING_SHARED_FLOW_WITH_ONLY_ORDINAL_PROMPT_DERIVATION_AND_EXACT_BONE_CATALOG_CORRECTION'},'testExecution':{'state':'ACTUAL_FOCUS_SQL_COLD_DEDUP_INDEPENDENT_ALL_HISTORY_AND_REPLAY_PASS'},'fixedCommitCi':{'state':'PENDING_NEW_FIXED_FULL'},'productAcceptance':{'state':'OPEN'},'decision':{'state':'OPEN','reason':'Bounded evidence does not close new fixed full, all semantic branches or final candidate product acceptance.'},'wholePrintingCertified':False,'existingAcceptanceGateDependencies':['DECK_OBSERVATION_FAMILY_ALL_APPLICABLE_CONSUMERS','FIXED_CURRENT_CANDIDATE_FULL','USER_WINDOWS_RUNTIME']})
gap=source['separateSupportingFieldCatalogGap'];branches.append({'id':gap['id'],'state':'OPEN','sourceRefs':gap['sourceRefs'],'sourceManifest':sp,'issue':gap['issue'],'semanticReview':{'state':'SOURCE_GAP_CONFIRMED_RUNTIME_AND_DAMAGE_BRANCH_REVIEW_OPEN'},'implementation':{'state':'NOT_YET_ADOPTED'},'testExecution':{'state':'NO_DAMAGE_OCCURRED_IN_CURRENT_CONTROLLED_FIXTURES_NOT_A_DAMAGE_TEST'},'fixedCommitCi':{'state':'OPEN'},'productAcceptance':{'state':'OPEN'},'decision':{'state':'OPEN','reason':'Exact official new text is missing from effective catalog; all relevant implementation and execution evidence remains required.'},'wholePrintingCertified':False})
manifest['reviewContexts'][identity]={'evidenceCommit':frozen['parentCommit'],'currentImplementationCommit':frozen['parentCommit'],'currentImplementationIncludesUncommittedChanges':True,'ciState':'PENDING','ciReceipts':[],'region':'CN','language':'zh-CN','applicableAsOf':'2026-10-21','adoptedCoreEffectiveDate':'2026-10-16','sourceManifest':sp,'implementation':implementation,'verificationSources':verification,'evidence':[pin(ev/'focus-executed-distinct-scope.json','focus'),pin(ev/'check-original-case-method-and-input-retention.json','check'),pin(ev/'real-integrated-five-sql-terminal.json','sql'),pin(ev/'independent-optional-all-history.json','independent-sql'),pin(ev/'independent-hand-all-history.json','independent-sql')],'branches':branches}
for row in stale:
 context=manifest['reviewContexts'][row['id']]
 for change in row['changes']:
  matches=[p for p in context['implementation'] if p['path']==change['path']];assert len(matches)==1 and matches[0]['sha256']==change['oldSha256'];matches[0]['sha256']=change['currentSha256']
 context.update(currentImplementationCommit=frozen['parentCommit'],currentImplementationIncludesUncommittedChanges=True,ciState='PENDING',currentOptionalHandInputRefresh=pin(ev/'four-current-input-only-context-refresh.json','current-input-refresh'))
deck=next(g for g in manifest['acceptanceGates'] if g['id']=='DECK_OBSERVATION_FAMILY');deck['currentOptionalAndRevealedHandBoundedFix']=sp;deck['currentOptionalHandBoundary']='Six bounded behavior/source-adoption branches recorded; whole family, new fixed full and current visible/physical Windows remain OPEN. Earlier adjacent finding remains as originally recorded.'
sources=next(g for g in manifest['acceptanceGates'] if g['id']=='SOURCE_GAPS_AND_EFFECTIVE_DELTAS');sources['currentSupportingVoidGateEffectiveTextGap']=pin(ev/'supporting-void-field-open-source-gap.json','separate-open-current-source-adoption-gap')
manifest['inputs']['active']['sha256']=sha(root/manifest['inputs']['active']['path'])
manifest['currentOptionalObservedAndRevealedHandInputChange']=sp
manifest['precedingFixed39eActualCompleteFullCiReadback']=pin(ev/'prior39e-full-independent.json','prior-fixed-full')
manifest['precedingFixedF059ActualCompleteFullCiReadback']=pin(ev/'priorf059-full-independent.json','prior-fixed-full')
manifest['precedingFixed64678BoundedHeadlessCiNativeReadback']=pin(ev/'preceding64678-headless-ci-native-subscope.json','preceding-fixed-headless-native-subscope')
assert reviews['reviews'][:153]==old_reviews['reviews']
assert all(manifest['reviewContexts'][k]==v for k,v in old_manifest['reviewContexts'].items() if k not in {x['id'] for x in stale})
for i,gate in enumerate(manifest['acceptanceGates']):
 if gate['id'] not in {'DECK_OBSERVATION_FAMILY','SOURCE_GAPS_AND_EFFECTIVE_DELTAS'}:assert gate==old_manifest['acceptanceGates'][i]
 else:
  for key,value in old_manifest['acceptanceGates'][i].items():assert gate[key]==value
assert manifest['certificationScope']==old_manifest['certificationScope'] and manifest['laterSourceDeltas']==old_manifest['laterSourceDeltas'] and manifest['cardCoverageManifest']==old_manifest['cardCoverageManifest']
rp.write_text(json.dumps(reviews,ensure_ascii=False,indent=2)+'\n');manifest['inputs']['reviews']['sha256']=sha(rp);mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
text=(w/'optional-hand-audit-draft-v1.md').read_text().replace('{{SOLE_CHECK_RESULT}}',(w/'only-check-actual-result-prose-v1.md').read_text().strip()).replace('{{GOVERNANCE_RESULT}}','本批154限定审查、69上下文、245门禁、七来源增量。原153审查完整原样；64上下文完全原样，四上下文只刷新当前实现输入绑定，完整前版、旧证据、验证源和日期保留。243其他门禁原值不变，两个既有门禁仅追加限定结果/独立OPEN来源缺口，全部旧字段与状态保留。统一义务原16955身份全留，追加六限定分支及一独立OPEN缺口至16962；不提升整卡或全量认证。')
assert '{{SOLE_CHECK_RESULT}}' not in text and '{{GOVERNANCE_RESULT}}' not in text
doc=root/'docs/OPTIONAL_OBSERVED_REVEALED_HAND_CURRENT_CN16_AUDIT_2026-10-21.md';assert not doc.exists();doc.write_text(text)
status=root/'docs/PROJECT_STATUS.md';previous=status.read_text();prefix='# 当前项目状态\n\n';assert previous.startswith(prefix)
lead=(w/'optional-hand-status-lead-v1.md').read_text()
status.write_text(prefix+lead+previous[len(prefix):])
write(ev/'publication-original-obligation-retention.json',{'atUtc':now(),'status':'BOUNDED_OPTIONAL_HAND_RECORDS_PUBLISHED_WITH_VOID_GATE_OPEN_NOT_GOAL_COMPLETION','allOriginal153ReviewsExact':True,'allUnaffected64ContextsExact':True,'fourOnlyCurrentImplementationBindingRefreshes':refresh['records'],'all243OtherGatesExactAndTwoExistingGatesOldFieldsRetained':True,'original16955ObligationIdsMustRemain':True,'expectedNewObligations':7,'allSourceDatesScopesDeltasCoverageAndUniverseRetained':True,'sourceManifest':sp,'archiveMembers':len(rows),'archiveBytes':archive.stat().st_size})
print('Published154 reviews69contexts245gates;153 original reviews/64contexts exact;four input-only refreshes; +6 bounded branches and one OPEN gap; archive',len(rows),archive.stat().st_size)
