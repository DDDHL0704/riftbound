using Npgsql;
if(args.Length!=1)throw new Exception("Fresh bounded output required.");
await using var source=NpgsqlDataSource.Create(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound")??throw new Exception("Real own SQL required."));
await NocturneOptionalSqlPrototype.RunAsync(source,args[0]);
