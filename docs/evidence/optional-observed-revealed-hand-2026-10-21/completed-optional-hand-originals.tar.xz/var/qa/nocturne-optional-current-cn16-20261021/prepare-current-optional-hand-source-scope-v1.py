from pathlib import Path
import datetime, hashlib, json

root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
w35=root/'var/qa/deck-play-ordered-observation-20261021'
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=load(root/'docs/audit/current-manifest.json');corpus=load(root/m['inputs']['corpus']['path']);records={r['id']:r for r in corpus['records']}
rules=['DOC-01-P041-B013','DOC-01-P050-B012','DOC-01-P059-B002','DOC-01-P059-B009','DOC-01-P059-B010','DOC-01-P075-B015','DOC-09-P020-B001','DOC-09-P020-B002','DOC-09-P020-B003','DOC-10-P002-B005','DOC-10-P002-B006','DOC-10-P002-B007','DOC-10-P002-B008']
open_rules=['DOC-16-P012-B006','DOC-16-P012-B007']
assert all(r in records for r in rules+open_rules)
support=load(w/'current-hand-supporting-exact-api-source-intake-v1.json');assert len(support['cards'])==4
assert {r['exactApiId'] for r in support['cards'] if r['allKeysValuesPresenceAndNullsEqualCatalogAfterExplicitKnownApiNormalization']}=={31208,31314,31444}
assert next(r for r in support['cards'] if r['exactApiId']==31542)['allKeysValuesPresenceAndNullsEqualCatalogAfterExplicitKnownApiNormalization'] is False
bone=load(w/'bone-current-official-new-vs-old-source-review-v1.json');void=load(w/'supporting-void-field-exact-provenance-and-open-disposition-v1.json')
assert void['noNewLiveSourceVersion'] and void['frozenN33RuntimeAndRunningOnlyCheckNotMutated']
assert load(w/'all-five-current-controlled-branches-no-damage-events-v1.json')['status']=='NO_DAMAGE_EVENTS_IN_ANY_CURRENT_FIVE_CONTROLLED_ORIGINAL_FRAMES'
pin=lambda p:{'path':str(p.relative_to(root)),'sha256':sha(p)}
branches=[
 {'id':'observed-affordable-optional-decline','sourceRefs':['OGN-194/298','OGN-291/298','DOC-01-P059-B002','DOC-01-P059-B009']},
 {'id':'observed-unaffordable-optional-decline','sourceRefs':['OGN-194/298','OGN-291/298','DOC-01-P059-B002','DOC-01-P059-B009']},
 {'id':'observed-decline-first-play-second','sourceRefs':['OGN-194/298','OGN-291/298','DOC-01-P041-B013','DOC-01-P059-B002']},
 {'id':'revealed-hand-stable-ordinal-cold-prompt-owner-confirmation-and-stun','sourceRefs':['UNL-139/219','OGN-208/298','DOC-01-P050-B012','DOC-09-P020-B001','DOC-09-P020-B002','DOC-09-P020-B003','DOC-10-P002-B005','DOC-10-P002-B006']},
 {'id':'revealed-hand-optional-decline-returns-privacy','sourceRefs':['UNL-139/219','DOC-10-P002-B005','DOC-10-P002-B006']},
 {'id':'bone-exact-current-erratum-catalog-adoption','sourceRefs':['UNL-139/219','DOC-10-P002-B005','DOC-10-P002-B006','DOC-10-P002-B007','DOC-10-P002-B008']}
]
result={
 'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'status':'BOUNDED_CURRENT_CN16_OPTIONAL_OBSERVED_PERMISSION_AND_REVEALED_HAND_PRESENTATION_SOURCE_REVIEW_WITH_SEPARATE_VOID_GATE_GAP',
 'region':'CN','language':'zh-CN','applicableCoreDate':'2026-10-16',
 'currentSourceManifestAndAllPriorSourceDatesUnchanged':True,
 'subjectPrintings':['OGN-194/298','OGN-291/298','UNL-139/219','OGN-208/298'],
 'supportingControlledObjectsNotWholeCardCertification':['OGN-004/298','OGN-096/298','OGN-296/298'],
 'ruleRecords':rules,'openSupportingFieldSourceGapRuleRecords':open_rules,
 'exactOriginalRuleTextHashes':{r:hashlib.sha256(records[r]['text'].encode()).hexdigest() for r in rules+open_rules},
 'currentSourceEvidence':[pin(p) for p in [w/'current-nocturne-optional-original-source-intake-v1.json',w35/'next-revealed-hand-current-source-intake-v1.json',w/'current-hand-supporting-exact-api-source-intake-v1.json',w/'bone-current-official-new-vs-old-source-review-v1.json',w/'current-source-optional-scope-and-visible-page-readback-v1.json']],
 'newCompletePhysicalCorePagesActuallyViewed':[{'page':n,**pin(w/'bone-current-primary-pages-v1'/f'core-p{n}.png')} for n in [50,75]],
 'retainedCompleteFAQAndErrataPhysicalPageReadback':bone['completePhysicalPrimaryPagesActuallyViewed'],
 'noNewOfficialSourceVersionDiscovered':True,'officialSourceDeltaCountRemainsSeven':True,
 'separateRuntimeCatalogAdoption':{'oldRawFileSha256':m['inputs']['active']['sha256'],'newRawFileSha256':sha(root/'data/official/card-catalog.zh-CN.json'),'exactRowId':34682,'exactField':'cardEffect','exactPrinting':'UNL-139/219','currentNonemptyApiErrataAndPrimaryExplicitNewTextMatch':True,'oldCatalogMatchesPrimaryExplicitOldText':True,'oldAcquisitionPublicationAndEffectiveDatesNotOverwritten':True},
 'boundedBehaviorBranches':branches,
 'separateSupportingFieldCatalogGap':{'id':'supporting-void-gate-current-official-erratum-not-yet-adopted','sourceRefs':['OGN-296/298',*open_rules],'state':'OPEN','issue':load(w/'supporting-void-field-catalog-issue-exact-body-verification-v1.json')['url'],'evidence':pin(w/'supporting-void-field-exact-provenance-and-open-disposition-v1.json'),'noDamageInAnyCurrentControlledBranch':pin(w/'all-five-current-controlled-branches-no-damage-events-v1.json'),'originalSourceVersionAndRunningFrozenInputsRetained':True,'notRuntimeSemanticCertification':True},
 'sourceReadButNotNewlyCertified':['DOC-01-P075-B015 delayed play battlefield timing; this batch does not certify all related interactions','DOC-09-P020-B009 through B012 exhausted Reksai capture and failure during confirmation remain a separate remaining branch'],
 'exclusions':['Whole printings, standby, copies, absent-field and played-unit replacement/prevention interactions','Initial simultaneous replacement-choice ordering rights','All other finite observation consumers and unresolved source gaps','Final current fixed complete CI, visible hardware controls and paired clients, and physical Windows'],
 'noOldDevelopmentMatchMigration':True,'wholePrintingOrGlobalCertification':False,
 'initialSupportingRowPreflightFailureRetained':'All-four-normalized-equal assertion failed before any scope result was written; the exact fourth-row source gap was independently reviewed and registered, never coerced to equal'
}
path=w/'current-optional-and-hand-exact-source-scope-review-v1.json';assert not path.exists();path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(result['status'],len(rules),'bounded rule records',len(branches),'bounded branches and one separate OPEN source gap')
