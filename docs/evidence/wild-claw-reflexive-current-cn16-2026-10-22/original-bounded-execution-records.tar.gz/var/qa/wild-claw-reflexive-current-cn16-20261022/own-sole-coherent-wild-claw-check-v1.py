from pathlib import Path
import collections,datetime,gzip,hashlib,json,os,resource,subprocess,xml.etree.ElementTree as E
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
base='008a064047aa746e579396a79fba6c9950842023';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==base
before=json.loads(gzip.decompress((w/'before-any-next-gameplay-or-catalog-change-original-inputs-v1.json.gz').read_bytes()))
inputs=load(w/'post-preparation-corrected-candidate-v2/native-actual-sql-choice-controls-v4/actual-native-control-terminal-v4.json')['sourceHashes'];assert len(inputs)==3360
pins={p:{'sha256':sha(root/p),'mode':oct((root/p).stat().st_mode&0o777)} for p in inputs};assert all(pins[p]['sha256']==h for p,h in inputs.items())
old=before['all1806CurrentOriginalConformanceFiles'];assert len(old)==1806
changed=[p for p,v in old.items() if pins[p]!=v];assert set(changed)=={'tests/Riftbound.ConformanceTests/CardCatalogBaselineTests.cs','tests/Riftbound.ConformanceTests/VendettaAmbushTests.cs','tests/Riftbound.ConformanceTests/AhriCombatMightTests.cs'}
for path in changed:
 prior=subprocess.check_output(['git','show',base+':'+path],cwd=root,text=True);expected=prior.replace('1035','1036')
 if path.endswith('CardCatalogBaselineTests.cs'):
  expected=expected.replace('834','835').replace('BehaviorTemplateIds.Recycle, 65, 65, 0, 0, 53, 53, 0','BehaviorTemplateIds.Recycle, 66, 66, 0, 0, 54, 54, 0').replace('BehaviorTemplateIds.Banish, 22, 22, 0, 0, 18, 18, 0','BehaviorTemplateIds.Banish, 23, 23, 0, 0, 19, 19, 0')
 if path.endswith('AhriCombatMightTests.cs'):expected=expected.replace('Assert.Equal(26, current.Cards.Count(c => !historical.Cards.Any(old => old.CardNo == c.CardNo)))','Assert.Equal(27, current.Cards.Count(c => !historical.Cards.Any(old => old.CardNo == c.CardNo)))')
 assert (root/path).read_text()==expected
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def cases(p):return collections.Counter(x.get('testName') for x in E.parse(p).findall('.//t:UnitTestResult',ns))
previous=root/'var/qa/deck-play-pending-before-parent-20261022';original=cases(previous/'sole-check-v1/check/results.trx');assert sum(original.values())==13497
extra=collections.Counter({n:c for n,c in cases(previous/'final-current-family-and-all-old-focus-v10/focus/results.trx').items() if '.RecoveryRejectsMalformedSuspendedDeckQueuesBeforeInspectingTheirOrder(' in n}) if (previous/'final-current-family-and-all-old-focus-v10/focus/results.trx').exists() else None
if extra is None or sum(extra.values())!=3:
 candidates=[]
 for q in previous.glob('*/focus/results.trx'):
  values=collections.Counter({n:c for n,c in cases(q).items() if '.RecoveryRejectsMalformedSuspendedDeckQueuesBeforeInspectingTheirOrder(' in n})
  if sum(values.values())==3:candidates.append((q,values))
 assert candidates;extra=candidates[-1][1]
baseline=original+extra;assert sum(baseline.values())==13500
focus=w/'final-current-family-source-recovery-and-five-original-games-focus-v14';assert load(focus/'summary.json')['total']==795
new=collections.Counter({n:c for n,c in cases(focus/'focus/results.trx').items() if '.WildClaw' in n});assert sum(new.values())==57
runtime={};excluded='tests/Riftbound.ConformanceTests/bin/Debug/net10.0/var/qa/'
for role,folder in [('Conformance',root/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0'),('Native',root/'clients/godot/.godot/mono/temp/bin/Debug')]:runtime[role]={str(p.relative_to(root)):sha(p) for p in folder.rglob('*') if p.is_file() and not str(p.relative_to(root)).startswith(excluded)}
r=root/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0';probe=root/'var/qa/fixed55fdb-early-native-20261022/ordinary-ci-pair-attempt-v2/selected-actual-native-history-reader-source-v2/bin/Release/net10.0/Fixed55fdbNativeHistoryReaderV2.dll'
measured=json.loads(subprocess.check_output(['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(r/'Riftbound.ConformanceTests.deps.json'),'--runtimeconfig',str(r/'Riftbound.ConformanceTests.runtimeconfig.json'),str(probe),'--loaded-inputs'],cwd=r))
sql=load(w/'post-preparation-corrected-candidate-v2/current-rule-sql61-frozen-inputs-v1.json');assert measured['actualRuleInputs']==sql['actualRuleInputs'] and len(measured['assemblies'])==4
for a in measured['assemblies']:assert Path(a['path'])==r/(a['name']+'.dll') and a['sha256']==runtime['Conformance'][str(Path(a['path']).relative_to(root))] and a['mvid']
start={'atUtc':now(),'baseCommit':base,'all3360SourceHashesAndModes':pins,'original1806ConformanceFiles':old,'onlyThreeOriginalFilesExactRegistrationLiteralCalibrations':changed,'allOther1803OriginalConformanceFilesAndAllNineFullSourcesByteExact':True,'all143OriginalFullMethods151Cases110Pairs11Decks424242AndAssertionsRetained':True,'actualRuntimeInputs':runtime,'actualFourLoadedAssemblies':measured,'oldSoleCheck13497NameBaselineIncludesItsOriginalOneFailureNotRelabelledPass':True,'retainedThreeEarlierFinalCases':sorted(extra.elements()),'expectedCheckCases':13557,'expectedCheckMethods':7577,'expectedDiscoveryMethods':7718,'expectedFullCases':13706,'newCases':57,'newMethods':17,'baselineCaseNames':sorted(baseline.elements()),'newCaseNames':sorted(new.elements()),'sql194And43NativeOriginalIndependentReadbackSeparate':True,'wholeCardOrGoalCertified':False}
manifest=w/'sole-check-start-inputs-v1.json.gz';assert not manifest.exists();manifest.write_bytes(gzip.compress(json.dumps(start,indent=2).encode(),mtime=0))
out=w/'sole-check-v1';assert not out.exists();args=['python3','scripts/test-rules.py','check','--output',str(out)];env=dict(os.environ);env.pop('ConnectionStrings__Riftbound',None)
proof={'status':'RUNNING_SOLE_WILD_CLAW_CHECK','startedAtUtc':now(),'baseCommit':base,'command':args,'sourceInputs':len(pins),'conformanceRuntimeFiles':len(runtime['Conformance']),'nativeRuntimeFiles':len(runtime['Native']),'startManifestSha256':sha(manifest)}
print('SOLE_CHECK_STARTED_EXPECT13557_CASES7577_METHODS_3360_SOURCES',flush=True)
try:
 with (w/'sole-check-original-console-v1.log').open('xb') as stream:
  process=subprocess.Popen(args,cwd=root,stdout=stream,stderr=subprocess.STDOUT,env=env);proof['runnerPid']=process.pid
  (w/'sole-check-running-owner-v1.json').write_text(json.dumps(dict(proof,ownerPid=os.getpid()),indent=2))
  power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(process.pid)]);proof['exitCode']=process.wait();power.wait(timeout=10)
 if proof['exitCode']==0:
  summary=load(out/'summary.json');plan=load(out/'plan.json');actual=cases(out/'check/results.trx');assert summary['status']=='PASSED' and summary['total']==13557 and actual==baseline+new
  assert plan['discoveredMethods']==7718 and sum(len(s['methods']) for s in plan['shards'])==7577
  proof.update(status='PASS_SOLE_COHERENT_WILD_CLAW_CHECK13557_CASES7577_METHODS',summary=summary,exactOriginal13500CaseNamesRetainedPlus57Only=True,trxSha256=sha(out/'check/results.trx'))
 else:proof['status']='FAILED_SOLE_WILD_CLAW_CHECK_ORIGINAL_OUTPUTS_RETAINED'
finally:
 proof.update(finishedAtUtc=now(),all3360SourceHashesAndModesStable=all(sha(root/p)==v['sha256'] and oct((root/p).stat().st_mode&0o777)==v['mode'] for p,v in pins.items()),allCapturedConformanceAndNativeRuntimeInputsStable=all(sha(root/p)==h for group in runtime.values() for p,h in group.items()))
 (w/'sole-check-owner-terminal-v1.json').write_text(json.dumps(proof,indent=2)+'\n')
print(proof['status'],flush=True)
assert proof['exitCode']==0 and proof['all3360SourceHashesAndModesStable'] and proof['allCapturedConformanceAndNativeRuntimeInputsStable']
