from pathlib import Path
import collections, datetime, gzip, hashlib, json, os, subprocess, xml.etree.ElementTree as ET
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
start=json.loads(gzip.decompress((w/'sole-check-start-inputs-v1.json.gz').read_bytes()))
old=json.loads((w/'sole-check-owner-terminal-v1.json').read_text())
assert old['exitCode']==1 and old['all3360SourceHashesAndModesStable'] and old['allCapturedConformanceAndNativeRuntimeInputsStable']
path='tests/Riftbound.ConformanceTests/Cn16RuleInputSelectionTests.cs'
prior=(w/'actual-sole-check-failed-current-catalog-pin-original-source.cs').read_text()
expected=prior.replace('// Exact UNL-139/219, OGN·296/298 and four DOC-16-P009-B004 Teemo errata; authority/scope unchanged.', '// Prior errata retained; exact CN37785 / VEN·089 added. Authority and scope are unchanged.').replace('Assert.Equal("e7455edc32d43f8253a9d0c6fedb83c347bebafbef064f9b8dffaaabc4b4d266", RuleInputIdentity.Current.CatalogSha256);','Assert.Equal("b04ddc91471924f8ba19913d50b87094089804271ef272f292c98bbcfd102298", RuleInputIdentity.Current.CatalogSha256);')
assert (root/path).read_text()==expected
pins={p:{'sha256':sha(root/p),'mode':oct((root/p).stat().st_mode&0o777)} for p in start['all3360SourceHashesAndModes']}
changes=[p for p in pins if pins[p]!=start['all3360SourceHashesAndModes'][p]];assert changes==[path]
for group in start['actualRuntimeInputs'].values():
    assert all(sha(root/p)==digest for p,digest in group.items())
output=w/'post-sole-check-exact-catalog-pin-and-source-identity-focus-v15';assert not output.exists()
command=['python3','scripts/test-rules.py','focus','--match','Cn16RuleInputSelectionTests','--match','WildClawSourceIdentityTests','--output',str(output)]
proof={'status':'RUNNING_EXACT_CATALOG_EXPECTATION_CORRECTION_FOCUS_NOT_SECOND_CHECK','startedAtUtc':now(),'command':command,'originalSoleCheckOutcomes':{'Passed':13556,'Failed':1},'onlyChangedSinceOriginalCheck':changes,'all3360CurrentSourceHashesAndModes':pins,'allBackendGameplayAndNativeSourcesByteExactOriginalCheck':True}
env=dict(os.environ);env.pop('ConnectionStrings__Riftbound',None)
try:
    with (w/'post-sole-check-exact-catalog-pin-focus-original-console-v1.log').open('xb') as f:
        process=subprocess.Popen(command,cwd=root,stdout=f,stderr=subprocess.STDOUT,env=env)
        power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(process.pid)])
        proof['exitCode']=process.wait();power.wait(timeout=10)
    assert proof['exitCode']==0
    ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};doc=ET.parse(output/'focus/results.trx');rows=doc.findall('.//t:UnitTestResult',ns)
    assert len(rows)==7 and all(r.get('outcome')=='Passed' for r in rows)
    names=sorted(r.get('testName') for r in rows);assert 'Riftbound.ConformanceTests.Cn16RuleInputSelectionTests.ActualPackagedInputsSelectTheCurrentCnCoreWithoutCertifyingAllItsSemantics' in names
    assert sum('.Cn16RuleInputSelectionTests.' in n for n in names)==3 and sum('.WildClawSourceIdentityTests.' in n for n in names)==4
    changed_runtime=[p for p,digest in start['actualRuntimeInputs']['Conformance'].items() if sha(root/p)!=digest]
    assert set(changed_runtime)=={'tests/Riftbound.ConformanceTests/bin/Debug/net10.0/Riftbound.ConformanceTests.dll','tests/Riftbound.ConformanceTests/bin/Debug/net10.0/Riftbound.ConformanceTests.pdb'}
    assert all(sha(root/p)==h for p,h in start['actualRuntimeInputs']['Native'].items())
    proof.update(status='PASS_EXACT_CURRENT_CATALOG_PIN_AND_ALL_SEVEN_CURRENT_OLD_IDENTITY_REFUSALS_NO_SECOND_CHECK',cases=7,methods=7,caseNames=names,trxSha256=sha(output/'focus/results.trx'),exactTwoConformanceAssemblyChanges=changed_runtime,allOther1418OldConformanceAnd23NativeRuntimeInputsStable=True)
finally:
    proof.update(finishedAtUtc=now(),all3360CurrentSourcesAndModesStable=all(sha(root/p)==v['sha256'] and oct((root/p).stat().st_mode&0o777)==v['mode'] for p,v in pins.items()))
    terminal=w/'post-sole-check-exact-catalog-pin-focus-terminal-v1.json';assert not terminal.exists();terminal.write_text(json.dumps(proof,indent=2)+'\n')
print(proof['status'],flush=True)
