from pathlib import Path
import datetime,hashlib,json,os,plistlib,subprocess
os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
original=json.loads((w/'current-rule-sql61-frozen-inputs-v1.json').read_text())
changed=[p for p,v in original['sourceInputHashes'].items() if sha(root/p)!=v['sha256']]
assert changed==['clients/godot/scripts/debug/WildClawInteractionProof.cs'],changed
sql=json.loads((w/'real-sql61-owner-terminal-v1.json').read_text());assert sql['status'].startswith('PASS_') and sql['originalAcceptedInputs']==194 and sql['actualRealDbRefusals']==4 and sql['ownPostgresSmartStopped']
f=w/'native-actual-sql-choice-controls-v2';f.mkdir(exist_ok=False)
rows=json.loads((w/'native-actual-sql-choice-controls-v1/index.json').read_text())
for row in rows:
 row['outputCommandPath']=str(f/Path(row['outputCommandPath']).name)
 for key,name in [('originalCommandPath','sourceOriginalCommandSha256'),('promptPath','sourcePromptSha256'),('snapshotPath','sourceSnapshotSha256')]:assert sha(Path(row[key]))==row[name]
(f/'index.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
native=root/'clients/godot/.godot/mono/temp/bin/Debug';native_inputs={str(p.relative_to(native)):sha(p) for p in native.rglob('*') if p.is_file()}
sources={p:sha(root/p) for p in original['sourceInputHashes']}
args=['/Users/dinghaolin/.local/share/riftbound-tools/godot-4.7.2/Godot_mono.app/Contents/MacOS/Godot','--headless','--path',str(root/'clients/godot'),'res://scenes/debug/WildClawInteractionProof.tscn','--','--evidence='+str(f)]
proof={'status':'RUNNING_ACTUAL_NATIVE_CONTROL_CHOICES','startedAtUtc':now(),'actualCommand':args,'backendRuleInputs':original['actualRuleInputs'],'backendRuntimeUnchanged':all(sha(Path(original['runtimeRoot'])/p)==h for p,h in original['runtimeFiles'].items()),'onlySourceDifferenceFromSqlRun':changed,'sourceHashes':sources,'nativeManagedRuntimeFiles':native_inputs,'originalChoiceRows':len(rows),'visibleWindowsOrLiveNativeSubmissionClaimed':False}
try:
 with (f/'actual-godot-original-console.log').open('xb') as out:code=subprocess.run(args,cwd=root,stdout=out,stderr=subprocess.STDOUT,timeout=90).returncode
 log=(f/'actual-godot-original-console.log').read_text();proof['actualExitCode']=code
 assert code==0 and 'WILD_CLAW_NATIVE_INTERACTION_PASS: 43 ' in log and 'ERROR:' not in log
 loaded=json.loads((f/'actual-loaded-client-assemblies.json').read_text());assert len(loaded['assemblies'])==2
 for a in loaded['assemblies']:
  path=Path(a['path']);assert path==native/(a['name']+'.dll') and a['sha256']==native_inputs[a['name']+'.dll'] and a['mvid']
 packets=[]
 for row in rows:
  emitted=Path(row['outputCommandPath']);actual=json.loads(emitted.read_text());expected=json.loads(Path(row['originalCommandPath']).read_text());assert actual==expected
  packets.append({'originalCommandPath':row['originalCommandPath'],'nativeCommandPath':str(emitted),'sha256':sha(emitted),'completeLiteralRawSchemaValuesPromptTickAndOrderEqual':True})
 proof.update(status='PASS_43_ACTUAL_NATIVE_PRODUCTION_CONTROL_COMMANDS_MATCH_THEIR_ORIGINAL_SQL_INTENTS',actualLoadedClientAssemblies=loaded,packets=packets,nativeOutputReplayThroughBackendStillPendingIndependentReader=True)
except BaseException as e:
 proof.update(status='FAILED_ACTUAL_NATIVE_PROOF_ORIGINALS_RETAINED',errorType=type(e).__name__,error=str(e));raise
finally:
 proof.update(finishedAtUtc=now(),all3360SourceHashesStable=all(sha(root/p)==h for p,h in sources.items()),allNativeRuntimeHashesStable=all(sha(native/p)==h for p,h in native_inputs.items()))
 (f/'actual-native-control-terminal-v2.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
assert proof['all3360SourceHashesStable'] and proof['allNativeRuntimeHashesStable']
print(proof['status'])
