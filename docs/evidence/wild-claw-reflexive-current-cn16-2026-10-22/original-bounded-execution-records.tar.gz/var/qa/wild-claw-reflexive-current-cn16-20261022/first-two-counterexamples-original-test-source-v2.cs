using Riftbound.Contracts;
using Riftbound.Engine;
using Xunit;

namespace Riftbound.ConformanceTests;

public sealed class WildClawPendingReflexiveTests
{
    internal const string WildClaw = "VEN·089";

    [Theory]
    [InlineData("OGN·096/298")]
    [InlineData("SFD·042/221")]
    public async Task PrivateUnitOrGearSelectionStagesTheCardBeforeTheParentOffersOptionalReflexiveCreation(string selectedCard)
    {
        var known = DeckPlaySequenceTests.TopCard(SingleDeckPlaySequenceTests.Position(SingleDeckPlaySequenceTests.Reinforce), "P1_TOP", selectedCard);
        known = DeckPlaySequenceTests.TopCard(known, "N1", "OGN·048/298");
        var control = await new CoreRuleEngine().ResolveAsync(known, new("known-consumer-control", "P1", CommandTypes.PlayCard),
            new PlayCardCommand("PARENT", SingleDeckPlaySequenceTests.Reinforce, []), default);
        Assert.True(control.Accepted, control.ErrorMessage);
        var initial = known with { CardObjects = new Dictionary<string, CardObjectState>(known.CardObjects) {
            ["PARENT"] = known.CardObjects["PARENT"] with { CardNo = WildClaw, ManaCost = 7 } } };
        var viewed = initial.PlayerZones["P1"].MainDeck.Take(5).ToArray();
        var driver = new StandbyDefendObserverTests.Driver(initial);
        await driver.Act("P1", new PlayCardCommand("PARENT", WildClaw, []));
        await driver.Top();
        var choice = Assert.IsType<PendingCardChoiceState>(driver.State.PendingCardChoice);
        Assert.Equal(viewed, choice.ContextObjectIds);
        Assert.Contains("P1_TOP", choice.LegalObjectIds);
        Assert.DoesNotContain("N1", choice.LegalObjectIds);
        Assert.Equal(0, choice.RequiredCount);
        await DeckPlaySequenceTests.Select(driver, "P1_TOP");
        Assert.Contains(driver.State.StackItems, item => item.SourceObjectId == "PARENT");
        Assert.NotNull(Assert.Single(driver.State.StackItems, item => item.SourceObjectId == "P1_TOP").DeckPlayPendingCard);
        Assert.Equal("STACK", driver.State.ObjectLocations["P1_TOP"].Zone);
        Assert.Equal(2, driver.State.CardObjects["P1_TOP"].ObjectGeneration);
        Assert.False(driver.State.CardObjects["P1_TOP"].IsEmpowered);
        Assert.Null(driver.State.PendingEffectPlay);
        var creation = Assert.IsType<PendingPaymentState>(driver.State.PendingPayment);
        Assert.Equal("P1", creation.PlayerId);
        Assert.Equal("DECK_REFLEXIVE_CREATE", creation.PaymentWindow);
        Assert.Equal(new[] { "CREATE", "DECLINE" }, creation.LegalPaymentChoiceIds);
        Assert.All(viewed.Where(id => id != "P1_TOP"), id => Assert.Contains(id, driver.State.PlayerZones["P1"].MainDeck));
        await RideTheWindCurrentMovementTests.Replay(initial, driver);
    }
}
