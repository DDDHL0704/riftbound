from pathlib import Path
import ast,datetime,fcntl,hashlib,json,os,plistlib,resource,socket,subprocess
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
source=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes=[n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}]
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),globals())
child=w/'post-preparation-corrected-candidate-v2';native=load(child/'native-actual-sql-choice-controls-v4/actual-native-control-terminal-v4.json');assert native['status'].startswith('PASS_') and len(native['packets'])==43
source_hashes=native['sourceHashes'];assert len(source_hashes)==3360
reader=w/'independent-sql61-originals-source-v1';ownfiles={str(p):sha(p) for p in reader.rglob('*') if p.is_file() and 'obj' not in p.parts};dll=reader/'bin/Release/net10.0/IndependentWildClawOriginalsV1.dll'
groups=[]
for path in [w,child]:
 pub=load(path/'current-rule-sql61-frozen-inputs-v1.json');r=Path(pub['runtimeRoot']);assert len(pub['runtimeFiles'])==89
 args=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(r/'Riftbound.PostgresAcceptance.deps.json'),'--runtimeconfig',str(r/'Riftbound.PostgresAcceptance.runtimeconfig.json'),str(dll)]
 measured=json.loads(subprocess.check_output(args+['--loaded-inputs'],cwd=r,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0')))
 assert Path(measured['baseDirectory'])==r and measured['actualRuleInputs']==pub['actualRuleInputs']
 for a in measured['assemblies']:assert Path(a['path'])==r/(a['name']+'.dll') and a['sha256']==pub['runtimeFiles'][a['name']+'.dll'] and a['mvid']
 groups.append({'path':path,'runtime':r,'publication':pub,'args':args,'measured':measured})
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof={'status':'RUNNING_BOTH_ORIGINAL_SQL61_CANDIDATES_READ_ONLY','startedAtUtc':now(),'lockAtStart':observe_lock(),'twoDistinctActualInputIdentities':[g['measured'] for g in groups],'earlierPartialFailedProductFlowNotPromoted':True};started=False;power=None;before_audit=before_native=None;audit=natives=None
try:
 assert all(sha(root/p)==h for p,h in source_hashes.items())
 for g in groups:assert all(sha(g['runtime']/p)==h for p,h in g['publication']['runtimeFiles'].items())
 assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid
 sock.mkdir(exist_ok=True);subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'independent-both-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 audit=rooms('riftbound_acceptance');natives=rooms('riftbound_here_native');assert len(audit)==397 and len(natives)==94
 before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',natives)
 results=[]
 for g in groups:
  path=g['path'];out=path/'independent-sql61-all-originals-result-v1.json';assert not out.exists()
  log=path/'independent-sql61-all-originals-console-v1.log'
  with log.open('xb') as stream:code=subprocess.run(g['args']+[str(path),str(out)],cwd=g['runtime'],env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit',DOTNET_DbgEnableMiniDump='0'),stdout=stream,stderr=subprocess.STDOUT,timeout=600).returncode
  assert code==0,log
  result=load(out);assert result['actualLoadedFourAssemblies']['actualRuleInputs']==g['publication']['actualRuleInputs'] and result['actualReadOnlyConnection']
  results.append({'path':str(out),'sha256':sha(out),'actualTotals':result['totals'],'rooms':len(result['rooms'])})
 assert sum(r['actualTotals']['commands'] for r in results)==328 and sum(r['actualTotals']['native'] for r in results)==43 and sum(r['actualTotals']['actualCorruptRoomRefusals'] for r in results)==4
 proof.update(status='PASS_BOTH_ORIGINAL_CANDIDATES_28_ROOMS_328_INPUTS_43_NATIVE_AND_FOUR_REAL_REFUSALS',results=results)
except BaseException as e:
 proof.update(status='FAILED_INDEPENDENT_BOTH_ORIGINAL_SQL61_READBACK_ALL_INPUTS_RETAINED',errorType=type(e).__name__,error=str(e));raise
finally:
 if started:
  if before_audit is not None:proof.update(all397AuditRoomsSevenTablesExact=digests('riftbound_acceptance',audit)==before_audit,all94NativeRoomsSevenTablesExact=digests('riftbound_here_native',natives)==before_native)
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None and power.poll() is None:power.terminate();power.wait(timeout=10)
 proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),all3360RootSourcesStable=all(sha(root/p)==h for p,h in source_hashes.items()),allOwnReaderFilesStable=all(sha(Path(p))==h for p,h in ownfiles.items()),both89FileRuntimeSetsStable=all(all(sha(g['runtime']/p)==h for p,h in g['publication']['runtimeFiles'].items()) for g in groups))
 (w/'independent-both-sql61-owner-terminal-v1.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');fcntl.flock(guard,fcntl.LOCK_UN)
assert proof['all397AuditRoomsSevenTablesExact'] and proof['all94NativeRoomsSevenTablesExact'] and proof['ownPostgresSmartStopped'] and proof['all3360RootSourcesStable'] and proof['allOwnReaderFilesStable'] and proof['both89FileRuntimeSetsStable']
print(proof['status'])
