# -*- coding: utf-8 -*-
from pathlib import Path
from urllib.request import Request,urlopen
import datetime,gzip,hashlib,json,math
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((root/'docs/audit/current-manifest.json').read_text());before_ref=next(d['after'] for d in reversed(m['laterSourceDeltas']) if d['kind']=='cn_cards');before_bytes=(root/before_ref['path']).read_bytes();before_rows=json.loads(before_bytes)['data'];before={c['id']:c for c in before_rows};assert len(before)==1504
url='https://lol-api.playloltcg.com/xcx/card/searchCardCraftWeb';records=[];rows=[];total=None;limit=1000;page=1;failure=None
try:
 while True:
  assert page<=30,'Bounded source intake cannot make unbounded pages.'
  body={'pageNum':page,'pageSize':limit,'searchContent':'','cardCategoryList':[],'cardColorList':[],'rarityList':[],'productCodeList':[]};record={'url':url,'request':body,'startedAtUtc':now(),'region':'CN','language':'zh-CN'}
  with urlopen(Request(url,json.dumps(body).encode(),{'Content-Type':'application/json','User-Agent':'RiftboundOfficialAudit/1.0','Cache-Control':'no-cache'}),timeout=40) as r:raw=r.read(8*1024*1024+1);assert len(raw)<=8*1024*1024;record.update(httpStatus=r.status,responseHeaders={k:v for k,v in r.headers.items() if k.lower() in {'date','age','etag','content-type','last-modified','cache-control'}})
  x=json.loads(raw);batch=x['result']['list'];n=int(x['result']['total']);record.update(receivedAtUtc=now(),rawBytes=len(raw),rawSha256=sha(raw),originalUtf8=raw.decode(),reportedTotal=n,returnedRows=len(batch),exactApiIds=[c['id'] for c in batch]);records.append(record)
  if total is None:total=n
  assert total==n and batch,'Actual page must conserve reported total and provide data.'
  rows.extend(batch)
  if len(rows)>=total:break
  page+=1
 current={c['id']:c for c in rows};assert len(rows)==len(current)==total,'Every original row and exact API id must appear once.'
except BaseException as e:failure={'errorType':type(e).__name__,'error':str(e),'atUtc':now()};current={c['id']:c for c in rows}
archive=w/'current-complete-cn-original-pages-v1.jsonl.gz';assert not archive.exists()
with gzip.GzipFile(filename=str(archive),mode='wb',mtime=0) as f:
 for record in records:f.write((json.dumps(record,ensure_ascii=False)+'\n').encode())
proof={'atUtc':now(),'status':'CURRENT_COMPLETE_CN_PUBLIC_CARD_SOURCE_ROWS_RECONFIRMED_ONLY' if failure is None else 'CURRENT_CN_SOURCE_PARTIAL_GAP_PREFIX_RETAINED','region':'CN','language':'zh-CN','applicableReviewDate':'2026-10-22','before':before_ref,'beforeExactOriginalSha256':sha(before_bytes),'reportedTotal':total,'actualRows':len(rows),'uniqueApiIds':len(current),'pageCount':len(records),'completeSourceIdentityConservation':failure is None,'failure':failure,'originalArchive':{'path':str(archive.relative_to(root)),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())},'pages':[{k:v for k,v in record.items() if k!='originalUtf8'} for record in records],'allFullRowsAndQaValuesNullsExactlyRegistered':current==before and failure is None,'addedApiIds':sorted(current.keys()-before.keys()),'missingRegisteredApiIds':sorted(before.keys()-current.keys()),'changedApiIds':[k for k in sorted(current.keys()&before.keys()) if current[k]!=before[k]],'currentLab34762FullRowExactRegistered':current.get(34762)==before[34762],'newSourceChangesNeedSeparateImpactBeforeRuntimeAdoption':True,'publicationAndGameEffectiveDatesNotInferredFromHttpAcquisition':True,'allPriorDatesUniverse1740Outside705EnglishGap8And139CnNewsRetained':True,'noCurrentCheckSourceInputsOrRuntimeCatalogMutated':True,'semanticCoverageCertified':False}
with (w/'current-complete-cn-full-row-and-qa-readback-v1.json').open('x') as f:json.dump(proof,f,ensure_ascii=False,indent=2);f.write('\n')
print('CN full source',proof['status'],'pages',len(records),'actual',len(rows),'unique',len(current),'total',total,'fullRowExact',proof['allFullRowsAndQaValuesNullsExactlyRegistered'],'added',proof['addedApiIds'],'missing',proof['missingRegisteredApiIds'],'changed',proof['changedApiIds'],flush=True)
