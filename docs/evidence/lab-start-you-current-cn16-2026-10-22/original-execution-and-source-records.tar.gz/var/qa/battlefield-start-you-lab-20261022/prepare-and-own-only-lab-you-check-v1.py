# -*- coding: utf-8 -*-
from pathlib import Path
import ast,datetime,hashlib,json,os,plistlib,resource,subprocess
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
parent='3f2dc4025834ec649d786646c2d2e72f3483a1d5';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==parent
pub=load(w/'current-lab-you-sql59-frozen-inputs-v2.json');inputs=pub['all3342SourceHashes'];modes=pub['all3342SourceModes'];assert len(inputs)==3342 and all(sha(root/p)==h and oct((root/p).stat().st_mode&0o777)==modes[p] for p,h in inputs.items())
sql=load(w/'current-lab-you-sql59-owner-terminal-v1.json');reader=load(w/'independent-lab-you-sql-owner-terminal-v1.json');readback=load(w/'independent-lab-you-sql-result-v1.json')
assert sql['currentSql59ExitCode']==0 and sql['allOriginal339AuditSevenTablesExact'] and sql['allOriginal76NativeSevenTablesExact'] and sql['ownPostgresSmartStopped']
assert reader['independentReaderExitCode']==0 and reader['allOriginal345AuditSevenTablesExact'] and reader['allOriginal76NativeSevenTablesExact'] and reader['ownPostgresSmartStopped'] and readback['histories']==32 and readback['snapshots']==readback['prompts']==58 and readback['refused']==4
focus=w/'final-all-hub-start-native-and-two-original-full-v4';summary=load(focus/'summary.json');plan=load(focus/'plan.json');assert summary['status']=='PASSED' and summary['total']==392 and plan['discoveredMethods']==7684 and sum(len(s['methods']) for s in plan['shards'])==285
assert (w/'all-independent-tool-tests-before-check-v1.log').read_text().rstrip().endswith('OK')
baseline=load(root/'var/qa/battlefield-start-controller-20261022/only-check-start-inputs-v1.json')
paths={k:{str(p.relative_to(root)):sha(p) for p in (root/folder).rglob('*') if p.is_file() and not str(p.relative_to(root)).startswith(baseline['excludedGeneratedOutputDirectory']+'/')} for k,folder in [('Conformance','tests/Riftbound.ConformanceTests/bin/Debug/net10.0'),('Native','clients/godot/.godot/mono/temp/bin/Debug')]}
assert len(paths['Conformance'])==1419 and len(paths['Native'])==23 and set(paths['Conformance'])==set(baseline['actualConformanceRuntimeFileHashes']) and set(paths['Native'])==set(baseline['actualNativeRuntimeFileHashes'])
runtime=root/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0';probe=root/'var/qa/fixed3f2dc-early-native-20261022/fixed3f2dc-native-history-reader-runtime-v1/Fixed3f2dcNativeHistoryReaderV1.dll'
actual=json.loads(subprocess.check_output(['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(runtime/'Riftbound.ConformanceTests.deps.json'),'--runtimeconfig',str(runtime/'Riftbound.ConformanceTests.runtimeconfig.json'),str(probe),'--loaded-inputs'],cwd=runtime,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0')))
assert Path(actual['baseDirectory'])==runtime and len(actual['assemblies'])==4
for a in actual['assemblies']:assert Path(a['path'])==runtime/(a['name']+'.dll') and a['sha256']==paths['Conformance'][str((runtime/(a['name']+'.dll')).relative_to(root))] and a['mvid']
definition=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py';nodes=[n for n in ast.parse(definition.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='observe_lock'];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(definition),'exec'),globals())
start={'atUtc':now(),'baseCommit':parent,'includesDeclaredUncommittedChanges':True,'sourceInputCount':3342,'sourceInputHashes':inputs,'sourceInputModes':modes,'excludedGeneratedOutputDirectory':baseline['excludedGeneratedOutputDirectory'],'actualConformanceRuntimeFileCount':1419,'actualConformanceRuntimeFileHashes':paths['Conformance'],'actualNativeRuntimeFileCount':23,'actualNativeRuntimeFileHashes':paths['Native'],'actualLoadedDebugBaseFourAssembliesAndRuleInputs':actual,'originalBaselineTrx':'var/qa/battlefield-start-controller-20261022/only-check-v1/check/results.trx','expectedCases':13436,'expectedMethods':7543,'onlyOneCheckForCoherentLabYouBatch':True,'original1802ConformanceFilesRetainedExceptDeclaredOneHubExpectedFieldAddition':True,'allNineOriginalFullSources143Methods110Pairs11Decks424242VictoryReplayAssertionsByteExact':True,'new25Cases3Methods':True,'finalFocusActual392Cases285MethodsIncludesBothOriginalFullGames':True,'focusDiscoveryAllSuiteMethods':7684,'focusSelectedMethods':285,'actualSql59_32Inputs32ColdFourRefusalsAndIndependent32Histories58PrivateEach':True,'allIndependent74ToolTestsPassedBeforeThisCheckFinalInput':True,'originalN41CheckOneFailureRetainedNotRelabeledAsGreen':True,'ordinaryFullGameVisibleAndWindowsNotInferredFromControlledSql':True,'parallelUntrackedClientsWebAndDotClaudeNotThisBatch':subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).splitlines(),'lockAtStart':observe_lock()}
start['originalBaselineTrxSha256']=sha(root/start['originalBaselineTrx'])
with (w/'only-check-start-inputs-v1.json').open('x') as f:json.dump(start,f,indent=2)
output=w/'only-check-v1';terminal=w/'only-check-owner-terminal-v1.json';assert not output.exists() and not terminal.exists()
command=['python3','scripts/test-rules.py','check','--output',str(output)];proof={'startedAtUtc':now(),'command':command,'lockAtStart':start['lockAtStart'],'currentDebugRuleInputs':actual['actualRuleInputs']}
print('SOLE_LAB_YOU_CHECK_STARTED_3342_SOURCES_1419_CONFORMANCE_23_NATIVE',flush=True)
try:
 with (w/'only-check-console-v1.log').open('xb') as log:
  child=subprocess.Popen(command,cwd=root,stdout=log,stderr=subprocess.STDOUT);power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(child.pid)]);proof['exitCode']=child.wait();power.wait(timeout=10)
finally:
 proof.update(finishedAtUtc=now(),lockAtStop=observe_lock(),all3342SourceHashesAndModesStable=all(sha(root/p)==h and oct((root/p).stat().st_mode&0o777)==modes[p] for p,h in inputs.items()),all1419ConformanceRuntimeInputsStable=all(sha(root/p)==h for p,h in paths['Conformance'].items()),all23NativeDebugRuntimeInputsStable=all(sha(root/p)==h for p,h in paths['Native'].items()))
 with terminal.open('x') as f:json.dump(proof,f,indent=2)
print(json.dumps(proof),flush=True)
assert proof['exitCode']==0 and all(proof[k] for k in ['all3342SourceHashesAndModesStable','all1419ConformanceRuntimeInputsStable','all23NativeDebugRuntimeInputsStable'])
