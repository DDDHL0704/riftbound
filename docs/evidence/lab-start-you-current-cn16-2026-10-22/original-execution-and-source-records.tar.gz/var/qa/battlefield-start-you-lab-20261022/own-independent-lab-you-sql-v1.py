# -*- coding: utf-8 -*-
from pathlib import Path
import ast,datetime,fcntl,hashlib,json,os,plistlib,resource,shutil,socket,subprocess
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486');tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
source=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py';nodes=[n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),globals())
pub=load(w/'current-lab-you-sql59-frozen-inputs-v2.json');previous=load(w/'current-lab-you-sql59-owner-terminal-v1.json')
assert previous['status']=='PASS_CURRENT_WIP_LAB_YOU_SQL59_32_ORIGINAL_INPUTS32_COLD_AND_FOUR_ACTUAL_SQL_REFUSALS' and previous['ownPostgresSmartStopped'] and previous['allOriginal339AuditSevenTablesExact'] and previous['allOriginal76NativeSevenTablesExact'] and len(previous['actualAuditRoomsAtStop'])==345 and len(previous['actualNativeRoomsAtStop'])==76
r=Path(pub['runtimeRoot']);frozen=pub['runtimeFiles'];assert len(frozen)==89 and all(sha(r/p)==h for p,h in frozen.items())
probe=root/'var/qa/fixed3f2dc-early-native-20261022/fixed3f2dc-native-history-reader-runtime-v1/Fixed3f2dcNativeHistoryReaderV1.dll';command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(r/'Riftbound.PostgresAcceptance.deps.json'),'--runtimeconfig',str(r/'Riftbound.PostgresAcceptance.runtimeconfig.json'),str(probe),'--loaded-inputs'];measurement=json.loads(subprocess.check_output(command,cwd=r,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0')))
assert Path(measurement['baseDirectory'])==r and measurement['actualRuleInputs']==pub['actualRuleInputs'] and len(measurement['assemblies'])==4
for a in measurement['assemblies']:assert Path(a['path'])==r/(a['name']+'.dll') and a['sha256']==frozen[a['name']+'.dll'] and a['mvid']
def current_inputs():return all(sha(root/p)==h and oct((root/p).stat().st_mode&0o777)==pub['all3342SourceModes'][p] for p,h in pub['all3342SourceHashes'].items())
own=w/'independent-lab-you-controller-reader-source-v1/bin/Release/net10.0/IndependentLabYouControllerReaderV1.dll';assert own.is_file();own_bits={str(p.relative_to(w)):sha(p) for p in [own,own.with_suffix('.pdb')]}
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof={'status':'RUNNING_INDEPENDENT_CURRENT_LAB_YOU_SQL32_ORIGINAL_HISTORY','startedAtUtc':now(),'baseCommit':pub['baseCommit'],'includesDeclaredUncommittedFiniteLabChanges':True,'actualLoadedFourAssemblies':measurement,'actualRuntimeFiles':frozen,'sourceInputCount':len(pub['all3342SourceHashes']),'sharedFrozenRuntimeReusedWithoutAnotherCopy':True,'lockAtStart':observe_lock(),'actualDatabase':'riftbound_acceptance','noLiveWriterOrMatchAction':True,'ownReaderBits':own_bits};started=False;power=None;audit=native=before_audit=before_native=None
try:
 assert current_inputs()
 assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid;sock.mkdir(exist_ok=True);subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'independent-lab-you-sql-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 audit=rooms('riftbound_acceptance');native=rooms('riftbound_here_native');assert audit==previous['actualAuditRoomsAtStop'] and native==previous['actualNativeRoomsAtStop'];before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',native)
 result=w/'independent-lab-you-sql-result-v1.json';assert not result.exists();args=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(r/'Riftbound.PostgresAcceptance.deps.json'),'--runtimeconfig',str(r/'Riftbound.PostgresAcceptance.runtimeconfig.json'),str(own),str(w/'real-sql-lab-you-v1'),str(result)];proof['actualCommand']=args
 with (w/'independent-lab-you-sql-v1.log').open('xb') as log:code=subprocess.run(args,cwd=r,env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit',DOTNET_DbgEnableMiniDump='0'),stdout=log,stderr=subprocess.STDOUT,timeout=180).returncode
 proof['independentReaderExitCode']=code;assert code==0;d=load(result);assert d['histories']==32 and d['snapshots']==d['prompts']==58 and d['refused']==4 and d['actualRuleInputs']==pub['actualRuleInputs'] and len(d['actualLoadedAssemblies'])==4
 for a in d['actualLoadedAssemblies']:assert Path(a['path'])==r/(a['name']+'.dll') and a['sha256']==frozen[a['name']+'.dll'] and a['mvid']
 assert rooms('riftbound_acceptance')==audit and rooms('riftbound_here_native')==native
 proof.update(status=d['status'],actualRuleInputs=pub['actualRuleInputs'],resultSha256=sha(result),independentOriginalHistories=32,privateSnapshots=58,privatePrompts=58,actualRefusals=4,actualEvents=d['eventCount'],noRoomOrHistoricalInputRewritten=True)

except BaseException as e:
 proof.update(status='FAILED_INDEPENDENT_FIXED3f2dc_NETWORK_READER_ALL_ORIGINALS_RETAINED',errorType=type(e).__name__,error=str(e));raise
finally:
 if started:
  if before_audit is not None:
   proof['allOriginal345AuditSevenTablesExact']=digests('riftbound_acceptance',audit)==before_audit;proof['allOriginal76NativeSevenTablesExact']=digests('riftbound_here_native',native)==before_native;proof['actualAuditRoomsAtStop']=rooms('riftbound_acceptance');proof['actualNativeRoomsAtStop']=rooms('riftbound_here_native')
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None and power.poll() is None:power.terminate();power.wait(timeout=10)
 proof.update(all3342DeclaredSourceHashesAndModesStable=current_inputs(),finishedAtUtc=now(),lockAtEnd=observe_lock(),all89FrozenRuntimeHashesStable=all(sha(r/p)==h for p,h in frozen.items()),actualLoaderMetadataRetained=True,allOwnReaderBitsStable=all(sha(w/p)==h for p,h in own_bits.items()))
 with (w/'independent-lab-you-sql-owner-terminal-v1.json').open('x') as f:json.dump(proof,f,indent=2)
 fcntl.flock(guard,fcntl.LOCK_UN)
assert proof['allOriginal345AuditSevenTablesExact'] and proof['allOriginal76NativeSevenTablesExact'] and proof['ownPostgresSmartStopped'] and proof['all89FrozenRuntimeHashesStable'];print(proof['status'],flush=True)
