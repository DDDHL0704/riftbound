# -*- coding: utf-8 -*-
from pathlib import Path
import ast,datetime,fcntl,hashlib,json,os,plistlib,resource,shutil,socket,subprocess
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486');tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
source=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py';nodes=[n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),globals())
prior=root/'var/qa/fixed3f2dc-early-native-20261022';pub=load(prior/'frozen-fixed3f2dc-native-composition-v1.json');previous=load(prior/'controlled-frost-native-independent-owner-terminal-v2.json')
assert previous['status']=='PASS_INDEPENDENT_CURRENT_CONTROLLED_FROST_SIX_ORIGINAL_NATIVE_HISTORY_ELEVEN_PRIVATE_VIEWS_AND_FULL_REPLAY' and previous['ownPostgresSmartStopped'] and previous['allOriginal338AuditSevenTablesExact'] and previous['allOriginal76NativeSevenTablesExact'] and len(previous['actualAuditRoomsAtStop'])==338 and len(previous['actualNativeRoomsAtStop'])==76
reader=load(prior/'fixed3f2dc-native-history-reader-frozen-v1.json');r=Path(reader['runtimeRoot']);frozen=reader['runtimeFiles'];assembly='BrokenOriginalLabRealSqlV1'
assert len(frozen)==48 and all(sha(r/p)==h for p,h in frozen.items()) and all(frozen[p]==h for p,h in pub['runtimeFiles'].items())
own=w/'broken-original-lab-real-sql-source-v1/bin/Release/net10.0'/(assembly+'.dll');assert own.is_file();own_bits={str(p.relative_to(w)):sha(p) for p in [own,own.with_suffix('.pdb')]}
probe=r/(reader['assembly']+'.dll');command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(r/'Riftbound.Api.deps.json'),'--runtimeconfig',str(r/'Riftbound.Api.runtimeconfig.json'),str(probe),'--loaded-inputs'];measurement=json.loads(subprocess.check_output(command,cwd=r,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0')))
assert Path(measurement['baseDirectory'])==r and measurement['actualRuleInputs']==pub['actualRuleInputs'] and len(measurement['assemblies'])==4
for a in measurement['assemblies']:assert Path(a['path'])==r/(a['name']+'.dll') and a['sha256']==frozen[a['name']+'.dll'] and a['mvid']
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof={'status':'RUNNING_ORIGINAL_FIXED3f2dc_BROKEN_LAB_THREE_SQL_INPUT_COUNTEREXAMPLE','startedAtUtc':now(),'fixedCommit':pub['fixedCommit'],'actualLoadedFourAssemblies':measurement,'actualRuntimeFiles':frozen,'ownReaderBits':own_bits,'sharedFrozenRuntimeReusedWithoutAnotherCopy':True,'lockAtStart':observe_lock(),'actualDatabase':'riftbound_acceptance','actualThreeOriginalInputsWrittenToOneNewControlledRoom':True};started=False;power=None;audit=native=before_audit=before_native=None
try:
 assert all(sha(root/p)==h for p,h in load(Path(pub['apiBuildInputsManifest']))['allDeclaredApiGameplaySourceInputsExactFixedCommit'].items())
 assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid;sock.mkdir(exist_ok=True);subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'original-broken-lab-sql-postgres-v2.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 audit=rooms('riftbound_acceptance');native=rooms('riftbound_here_native');assert audit==previous['actualAuditRoomsAtStop'] and native==previous['actualNativeRoomsAtStop'];before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',native)
 output=w/'original-broken-lab-real-sql-v1';assert not output.exists();args=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(r/'Riftbound.Api.deps.json'),'--runtimeconfig',str(r/'Riftbound.Api.runtimeconfig.json'),str(own),str(output)];proof['actualCommand']=args
 with (w/'original-broken-lab-sql-v1.log').open('xb') as log:code=subprocess.run(args,cwd=r,env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit',DOTNET_DbgEnableMiniDump='0'),stdout=log,stderr=subprocess.STDOUT,timeout=90).returncode
 proof['actualOriginalCounterexampleExitCode']=code;assert code==0;result=output/'original-real-sql-counterexample.json';d=load(result);assert d['originalAcceptedInputs']==3 and d['actualRuleInputs']==pub['actualRuleInputs'] and d['actualRecoveryErrorCode']=='RECOVERY_INCONSISTENT' and set(rooms('riftbound_acceptance'))==set(audit)|{d['room']} and rooms('riftbound_here_native')==native
 proof.update(status=d['status'],room=d['room'],resultSha256=sha(result),actualOriginalColdRegistryRefusal=True,originalAcceptedInputs=3,actualCompleteValidationErrors=d['actualOriginalValidationErrors'])

except BaseException as e:
 proof.update(status='FAILED_INDEPENDENT_FIXED3f2dc_NETWORK_READER_ALL_ORIGINALS_RETAINED',errorType=type(e).__name__,error=str(e));raise
finally:
 if started:
  if before_audit is not None:
   proof['allOriginal338AuditSevenTablesExact']=digests('riftbound_acceptance',audit)==before_audit;proof['allOriginal76NativeSevenTablesExact']=digests('riftbound_here_native',native)==before_native;proof['actualAuditRoomsAtStop']=rooms('riftbound_acceptance');proof['actualNativeRoomsAtStop']=rooms('riftbound_here_native')
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None and power.poll() is None:power.terminate();power.wait(timeout=10)
 proof.update(allOriginal252ApiSourceInputsStable=all(sha(root/p)==h for p,h in load(Path(pub['apiBuildInputsManifest']))['allDeclaredApiGameplaySourceInputsExactFixedCommit'].items()),finishedAtUtc=now(),lockAtEnd=observe_lock(),all48FrozenRuntimeHashesStable=all(sha(r/p)==h for p,h in frozen.items()),actualLoaderMetadataRetained=True,allOwnReaderBitsStable=all(sha(w/p)==h for p,h in own_bits.items()))
 with (w/'original-broken-lab-sql-owner-terminal-v1.json').open('x') as f:json.dump(proof,f,indent=2)
 fcntl.flock(guard,fcntl.LOCK_UN)
assert proof['allOriginal338AuditSevenTablesExact'] and proof['allOriginal76NativeSevenTablesExact'] and proof['ownPostgresSmartStopped'] and proof['all48FrozenRuntimeHashesStable'];print(proof['status'],flush=True)
