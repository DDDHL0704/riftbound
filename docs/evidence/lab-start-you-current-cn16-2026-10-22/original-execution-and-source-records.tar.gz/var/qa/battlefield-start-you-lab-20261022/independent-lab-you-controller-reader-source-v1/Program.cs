using System.IO.Compression;
using System.Reflection;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
Check(args.Length == 2 && !File.Exists(args[1]), "Original evidence and unused output required.");
var settings = new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
Check(settings.Host == "127.0.0.1" && settings.Port == 55486 && settings.Database == "riftbound_acceptance", "Only own actual audit database.");
settings.Options = "-c default_transaction_read_only=on";
await using var source = NpgsqlDataSource.Create(settings.ConnectionString);
await using var connection = await source.OpenConnectionAsync();
Check((string)(await new NpgsqlCommand("show transaction_read_only", connection).ExecuteScalarAsync())! == "on", "Actual connection is read-only.");
var store = new PostgresMatchRecoveryStore(source);
var branches = new[] { "normal", "decline", "actor-and-context", "actor-context-and-event", "no-history", "wrong-inputs" };
var results = new List<object>();
var histories = 0; var snapshots = 0; var prompts = 0; var refused = 0; var eventCount = 0;
foreach (var branch in branches)
{
    var folder = Path.Combine(args[0], "battlefield-start-lab-you", branch);
    using var receipt = JsonDocument.Parse(File.ReadAllText(Path.Combine(folder, "receipt.json")));
    var room = receipt.RootElement.GetProperty("room").GetString()!;
    var count = branch == "normal" ? 7 : 5;
    Check(receipt.RootElement.GetProperty("originalAcceptedInputs").GetInt32() == count
        && receipt.RootElement.GetProperty("controlledScenarioExplicitlyRecordedNotAnOrdinaryMatch").GetBoolean(), "Explicit original controlled scenario, not an ordinary game claim.");
    var entries = Enumerable.Range(1, count).Select(i => Read<MatchJournalEntry>(Path.Combine(folder, $"entry-{i:D2}-original-before-persist.json.gz"))).ToArray();
    var first = Read<MatchRecoveryFrame>(Path.Combine(folder, "prefix-01-original-frame.json.gz"));
    Check(first.ReplayInitialState is { Tick: 0, Status: "EMPTY", Seats.Count: 0 } && first.OpeningSeed != 0
        && first.ReplayInitialState.Seed == first.OpeningSeed, "Original empty opening and private seed, no fabricated final seats.");
    var replaySession = new MatchSession(first.ReplayInitialState!, new CoreRuleEngine(), NoopMatchJournal.Instance);
    for (var i = 0; i < entries.Length; i++)
    {
        var original = entries[i];
        var frame = Read<MatchRecoveryFrame>(Path.Combine(folder, $"prefix-{i + 1:D2}-original-frame.json.gz"));
        Check(original.RoomId == room && frame.IsConsistent && frame.Commands.Count == i + 1
            && frame.OpeningSeed == first.OpeningSeed && original.OpeningSeed == first.OpeningSeed
            && original.RuleInputs == RuleInputIdentity.Current && original.AuthoritativeState.RuleInputs == RuleInputIdentity.Current,
            "Every original prefix and original pre-persist input binds actual running rules, catalog, implementation and seed.");
        Check(Same(original.AuthoritativeState, frame.AuthoritativeState), "Complete original pre-persist state equals saved actual cold SQL frame.");
        for (var j = 0; j <= i; j++)
        {
            var command = frame.Commands[j]; var entry = entries[j];
            Check(command.PlayerId == entry.PlayerId && command.ClientIntentId == entry.ClientIntentId && command.CommandType == entry.CommandType
                && command.StartedTick == entry.StartedTick && command.CompletedTick == entry.CompletedTick
                && command.StartedEventSequence == entry.StartedEventSequence && command.CompletedEventSequence == entry.CompletedEventSequence
                && command.Accepted == entry.Accepted && command.ErrorMessage == entry.ErrorMessage && Same(command.RawCommand, entry.RawCommand)
                && command.RuleInputs == entry.RuleInputs, "Every original actor, intent, raw payload, outcome, tick and event span is exact.");
        }
        Check(frame.PlayerViews.Count == original.Snapshots.Count && original.Snapshots.Count == original.Prompts.Count, "No synthetic earlier player projection.");
        foreach (var view in frame.PlayerViews.Values)
        {
            Check(Same(view.Snapshot, original.Snapshots[view.PlayerId]) && Same(view.Prompt, original.Prompts[view.PlayerId]), "All private fields, nulls and conditional omissions equal original pre-persist values.");
            Check(Same(view.Snapshot, ResolutionResult.BuildSnapshots(original.AuthoritativeState)[view.PlayerId])
                && Same(view.Prompt, ResolutionResult.BuildPrompts(original.AuthoritativeState)[view.PlayerId]), "Exact original viewer projection values.");
            foreach (var other in original.AuthoritativeState.Seats.Keys.Where(p => p != view.PlayerId))
                foreach (var id in original.AuthoritativeState.PlayerZones[other].Hand.Concat(original.AuthoritativeState.PlayerZones[other].MainDeck))
                    Check(!JsonSerializer.Serialize(new { view.Snapshot, view.Prompt }, json).Contains("\"" + id + "\"", StringComparison.Ordinal), "Opponent hidden hand/deck identities absent.");
            snapshots++; prompts++;
        }
        var recovered = frame.Commands[^1]; ResolutionResult step;
        if (recovered.CommandType == "ROOM_SEAT")
        {
            var method = typeof(MatchSession).GetMethod("ReplayRoomSeatAsync", BindingFlags.Instance | BindingFlags.NonPublic)!;
            step = await (ValueTask<ResolutionResult>)method.Invoke(replaySession, new object[] { recovered, CancellationToken.None })!;
        }
        else if (recovered.CommandType == "DEV_SEED_SCENARIO:battlefield-turn-start-destroy-draw")
            step = await replaySession.SeedScenarioAsync(recovered.PlayerId, recovered.ClientIntentId, "battlefield-turn-start-destroy-draw", recovered.RawCommand!.Value, default);
        else
            step = await replaySession.SubmitAsync(recovered.PlayerId, recovered.ClientIntentId, GameCommandJsonMapper.Map(recovered.RawCommand!.Value), recovered.RawCommand!.Value, default);
        Check(step.Accepted == original.Accepted && step.ErrorMessage == original.ErrorMessage && Same(step.State, original.AuthoritativeState), "Every sequential original action replays every original state field and null exactly.");
        Check(step.Events.Count == original.Events.Count, "Every original event count exact.");
        for (var j = 0; j < step.Events.Count; j++) Check(JsonNode.DeepEquals(EventNode(step.Events[j]), EventNode(original.Events[j])), "Every original event kind, description and full payload exact.");
        var errors = await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame, new CoreRuleEngine(), default);
        Check(errors.Count == 0, "Every complete original prefix passes strict recovery replay: " + string.Join(';', errors));
        histories++; eventCount += original.Events.Count;
    }
    var active = entries[3].AuthoritativeState; var skill = active.StackItems.Single();
    Check(active.TurnPlayerId == "bob" && active.Phase == "TURN_START" && active.TurnStartStep == "SCORE"
        && skill.ControllerId == "bob" && skill.BattlefieldStart is { ControllerId: "bob", CardNo: "UNL-209/219", Damage: 0, DrawCount: 1 }
        && active.CardObjects[skill.SourceObjectId].ControllerId == "bob"
        && active.PendingCardChoice is { PlayerId: "bob" } c && c.LegalObjectIds.Contains("P2-BATTLEFIELD-ROSE-SACRIFICE"),
        "Literal CN190.6.d/191.5: actual Bob controlled Lab birth and optional local destruction decision, before any draw.");
    Check(entries.Take(4).Select(e=>e.PlayerId).SequenceEqual(new[]{"alice","bob","alice","alice"})
        && entries[4].PlayerId=="bob"&&entries[4].CommandType=="CHOOSE_CARDS",
        "Both original seats, declared scene and original Alice turn end are followed by actual Bob's cost choice.");
    if(branch!="decline")Check(entries[4].AuthoritativeState.StackItems.Single().ControllerId=="bob"
        && entries[4].AuthoritativeState.StackItems.Single().TriggerCost?.DestructionTarget?.ObjectId=="P2-BATTLEFIELD-ROSE-SACRIFICE"
        && entries[4].AuthoritativeState.PlayerZones["bob"].Hand.Count==0,"The paid original cost precedes responses and any draw.");
    var current = await store.LoadAsync(room, default) ?? throw new Exception("Actual original room required.");
    var expectedFrame = Read<MatchRecoveryFrame>(Path.Combine(folder, (branch is "normal" or "decline") ? "original-final-resolved-frame.json.gz" : "actual-rejected-frame-after-deliberate-tamper.json.gz"));
    Check(Same(current, expectedFrame), "Every actual current SQL frame field equals saved original outcome, including deliberate corruption.");
    using var expectedRows = ReadDocument(Path.Combine(folder, (branch is "normal" or "decline") ? "original-all-seven-tables-after-normal-resolution.json.gz" : "actual-all-seven-tables-after-deliberate-tamper.json.gz"));
    foreach (var table in new[] { "matches", "match_players", "command_log", "game_events", "state_snapshots", "snapshots", "action_prompts" })
    {
        await using var q = new NpgsqlCommand($"select coalesce(json_agg(t order by row_to_json(t)::text),'[]'::json)::text from (select * from {table} where match_id=@room)t", connection);
        q.Parameters.AddWithValue("room", room);
        using var actualRows = JsonDocument.Parse((string)(await q.ExecuteScalarAsync())!);
        Check(Same(actualRows.RootElement, expectedRows.RootElement.GetProperty(table)), "All seven actual stored tables remain exact, no restore of corrupted data for passing.");
    }
    using var historyRows = ReadDocument(Path.Combine(folder, (branch is "normal" or "decline") ? "original-all-seven-tables-after-normal-resolution.json.gz" : "original-all-seven-tables-before-any-tamper.json.gz"));
    foreach (var row in historyRows.RootElement.GetProperty("state_snapshots").EnumerateArray())
    {
        var entry = entries.Single(e => e.CompletedTick == row.GetProperty("state_tick").GetInt64() && e.CompletedEventSequence == row.GetProperty("last_event_sequence").GetInt64());
        Check(Same(row.GetProperty("payload"), JsonSerializer.SerializeToElement(entry.AuthoritativeState, json)), "Every original historical SQL authority equals its original pre-persist input.");
    }
    foreach (var table in new[] { "snapshots", "action_prompts" })
        foreach (var row in historyRows.RootElement.GetProperty(table).EnumerateArray())
        {
            var tick = row.GetProperty(table == "snapshots" ? "snapshot_tick" : "prompt_tick").GetInt64(); var actor = row.GetProperty("player_id").GetString()!;
            var entry = entries.Single(e => e.CompletedTick == tick && e.CompletedEventSequence == row.GetProperty("last_event_sequence").GetInt64());
            var value = table == "snapshots" ? JsonSerializer.SerializeToElement(entry.Snapshots[actor], json) : JsonSerializer.SerializeToElement(entry.Prompts[actor], json);
            Check(Same(row.GetProperty("payload"), value), "Every original persisted private history is exact.");
        }
    var failures = await MatchActionLogReplayer.ValidateRecoveryFrameAsync(current, new CoreRuleEngine(), default);
    if (branch is "normal" or "decline")
    {
        Check(failures.Count == 0 && current.AuthoritativeState is { Phase: "MAIN", StackItems.Count: 0 }
            && current.AuthoritativeState.PlayerZones["bob"].Hand.Count==(branch=="normal"?2:1)
            && current.AuthoritativeState.PlayerZones["alice"].Hand.Count==0
            && current.AuthoritativeState.PlayerZones["bob"].Graveyard.Contains("P2-BATTLEFIELD-ROSE-SACRIFICE")== (branch=="normal")
            && current.AuthoritativeState.PlayerZones["bob"].Battlefields.Contains("P2-BATTLEFIELD-ROSE-SACRIFICE")== (branch=="decline")
            && current.AuthoritativeState.CardObjects.ContainsKey("P2-OTHER")
            && current.AuthoritativeState.CardObjects["P2-BATTLEFIELD-AAA-OFFSITE"].Damage==0,
            "Literal accepted pay/decline outcome: actual Bob receives extra draw only for the confirmed paid skill; real offsite field remains intact.");
        if(branch=="normal")Check(entries.Skip(5).Select(e=>e.PlayerId).SequenceEqual(new[]{"bob","alice"})
            && entries.Skip(5).All(e=>e.CommandType=="PASS_PRIORITY"),"Both original captured-controller-first response inputs precede resolution.");

    }
    else
    {
        Check(failures.Count > 0, "Actual deliberate corruption must fail independent readback.");
        var rejected = false;
        try { await new InMemoryMatchSessionRegistry(new CoreRuleEngine(), NoopMatchJournal.Instance, store).GetOrCreateAsync(room, default); }
        catch (MatchSessionException error) when (error.Code == ErrorCodes.RecoveryInconsistent) { rejected = true; }
        Check(rejected, "Actual registry rejects without any writer."); refused++;
        if (branch is "actor-and-context" or "actor-context-and-event") Check(current.IsConsistent, "Consistent forged projections are rejected by original history, not projection mismatch.");
        if (branch == "actor-and-context") Check(failures.Any(e => e.Contains("differs from its original trigger birth", StringComparison.Ordinal)), "Original actor anchor independently rejects.");
        if (branch == "actor-context-and-event") Check(failures.Any(e => e.Contains("replayed event", StringComparison.Ordinal)) && failures.Any(e => e.Contains("final state hash", StringComparison.Ordinal)), "Even forged original-event actor fails exact original input replay.");
        if (branch == "no-history") Check(current.Commands.Count == 0 && current.Events.Count == 0 && failures.Any(e => e.Contains("one original journaled trigger birth", StringComparison.Ordinal)), "Absent history is rejected before empty-command early return.");
        if (branch == "wrong-inputs") Check(current.AuthoritativeState!.RuleInputs!.ImplementationSha256 == new string('a', 64)
            && current.AuthoritativeState.RuleInputs != RuleInputIdentity.Current && failures.Any(e => e.Contains("rule input identity", StringComparison.Ordinal)), "Self-consistent wrong implementation identity cannot execute.");
    }
    results.Add(new { room, branch, originalInputs = entries.Length, actualIndependentHistoryReplays = entries.Length, rejectionErrors = failures });
    Console.WriteLine($"INDEPENDENT_LAB_YOU_ORIGINAL_HISTORY_PASS {branch} {entries.Length}");
}
Check(histories == 32 && snapshots == 58 && prompts == 58 && refused == 4, "Complete bounded original history counts, no branch omitted.");
var actualAssemblies = new[] { typeof(CoreRuleEngine).Assembly, typeof(GameCommand).Assembly, typeof(Riftbound.CardCatalog.OfficialCardCatalog).Assembly, typeof(PostgresMatchJournal).Assembly };
var result = new { status = "PASS_INDEPENDENT_REAL_SQL32_ORIGINAL_LAB_HISTORIES58_PRIVATE_SNAPSHOTS58_PROMPTS_AND_FOUR_ACTUAL_REFUSALS", histories, snapshots, prompts, eventCount, refused, actualRuleInputs = RuleInputIdentity.Current, results,
    baseDirectory = AppContext.BaseDirectory, actualLoadedAssemblies = actualAssemblies.Select(a => new { name = a.GetName().Name, path = a.Location, mvid = a.ManifestModule.ModuleVersionId, sha256 = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(a.Location))).ToLowerInvariant() }),
    actualReadOnlyConnection = true, allSevenActualTablesRetainOriginalNormalOrDeliberatelyCorruptedOutcome = true, everyOriginalPrePersistInputAndColdPrefixReplayed = true,
    controlledScenarioNotOrdinaryFullMatch = true, visibleNativeAndWindowsAcceptance = false };
await File.WriteAllTextAsync(args[1], JsonSerializer.Serialize(result, json));
Console.WriteLine($"PASS independent original histories={histories} private={snapshots}/{prompts} refusals={refused}");
T Read<T>(string path) { using var document = ReadDocument(path); return document.RootElement.Deserialize<T>(json)!; }
static JsonDocument ReadDocument(string path) { using var zip = new GZipStream(File.OpenRead(path), CompressionMode.Decompress); return JsonDocument.Parse(zip); }
bool Same<TA, TB>(TA a, TB b) => JsonNode.DeepEquals(JsonSerializer.SerializeToNode(a, json), JsonSerializer.SerializeToNode(b, json));
JsonNode EventNode(GameEvent value)
{
    var node = JsonSerializer.SerializeToNode(value, json)!;
    if (value.Kind == "RUNE_POOL_CLEARED" && node["payload"]?["playerIds"] is JsonArray ids)
        node["payload"]!["playerIds"] = new JsonArray(ids.Select(i => i!.GetValue<string>()).Order(StringComparer.Ordinal).Select(i => JsonValue.Create(i)).ToArray());
    return node;
}
static void Check(bool value, string reason) { if (!value) throw new Exception(reason); }
