# -*- coding: utf-8 -*-
from pathlib import Path
import collections,datetime,gzip,hashlib,json,subprocess,xml.etree.ElementTree as ET
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
pin=lambda p:{'path':str(p.relative_to(root)),'sha256':sha(p)}
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def read(path):
 doc=ET.parse(path);defs={r.get('id'):r.find('t:TestMethod',ns).attrib for r in doc.findall('.//t:UnitTest',ns)};rows=doc.findall('.//t:UnitTestResult',ns)
 return rows,collections.Counter(r.get('testName') for r in rows),{defs[r.get('testId')]['className']+'.'+defs[r.get('testId')]['name'] for r in rows}
start=load(w/'only-check-start-inputs-v1.json');end=load(w/'only-check-owner-terminal-v1.json')
assert end['exitCode']==0 and all(end[k] for k in ['all3342SourceHashesAndModesStable','all1419ConformanceRuntimeInputsStable','all23NativeDebugRuntimeInputsStable'])
baseline=root/start['originalBaselineTrx'];assert sha(baseline)==start['originalBaselineTrxSha256'];trx=w/'only-check-v1/check/results.trx'
rows,counts,methods=read(trx);oldrows,oldcounts,oldmethods=read(baseline)
assert (len(rows),len(methods),len(oldrows),len(oldmethods))==(13436,7543,13411,7540)
assert collections.Counter(r.get('outcome') for r in rows)=={'Passed':13436}
assert collections.Counter(r.get('outcome') for r in oldrows)=={'Passed':13410,'Failed':1}
assert not(oldcounts-counts) and oldmethods<=methods
added=counts-oldcounts;added_methods=methods-oldmethods
assert sum(added.values())==25 and len(added_methods)==3 and all('.DuskRoseLabControllerYouTests.' in name for name in added)
focus=w/'final-all-hub-start-native-and-two-original-full-v4';fr,fc,fm=read(focus/'focus/results.trx')
assert len(fr)==392 and len(fm)==285 and all(r.get('outcome')=='Passed' for r in fr)
assert collections.Counter(r.get('testName') for r in fr if '.DuskRoseLabControllerYouTests.' in r.get('testName'))==added
fulls=sorted(m for m in fm if '.FullGameEndToEndTests.' in m);assert len(fulls)==2
assert sha(focus/'focus/results.trx')=='ac487b4f2de1ac47d19713807c8459b7be62ef72a3f74530d92d97049094c03e'
red,_,redmethods=read(w/'focus-lab-you-initial-v2/focus/results.trx')
assert len(red)==25 and len(redmethods)==3 and collections.Counter(r.get('outcome') for r in red)=={'Passed':16,'Failed':9}
assert all('.OriginalLabTriggerBirthAndStrictReplayRejectConsistentlyForgedControllers(' in r.get('testName') for r in red if r.get('outcome')=='Failed')
original=json.loads(gzip.decompress((w/'original-before-lab-you-all-conformance-files-retention-v2.json.gz').read_bytes()))
files=original['allOriginalTrackedConformanceFiles'];assert len(files)==1802 and original['originalTrackedCSharpCount']==508
hub='tests/Riftbound.ConformanceTests/GameHubJoinTests.cs'
assert all(sha(root/p)==record['sha256'] and oct((root/p).stat().st_mode&0o777)==record['mode'] for p,record in files.items() if p!=hub)
oldhub=subprocess.check_output(['git','show',start['baseCommit']+':'+hub],cwd=root).decode();newhub=(root/hub).read_text()
old='Assert.Equal(["P2-BATTLEFIELD-AAA-OFFSITE", "P2-BATTLEFIELD-ROSE-LAB"], Assert.IsAssignableFrom<IReadOnlyList<string>>(p2Zones["battlefields"]));'
new='Assert.Equal(["P2-BATTLEFIELD-AAA-OFFSITE", "P2-BATTLEFIELD-ROSE-LAB", "P2-OTHER"], Assert.IsAssignableFrom<IReadOnlyList<string>>(p2Zones["battlefields"]));'
assert hashlib.sha256(oldhub.encode()).hexdigest()==files[hub]['sha256'] and oldhub.count(old)==1 and newhub==oldhub.replace(old,new,1)
full_sources={p:record for p,record in files.items() if Path(p).name.startswith('FullGameEndToEndTests') and p.endswith('.cs')};assert len(full_sources)==9
assert all(sha(root/p)==record['sha256'] for p,record in full_sources.items())
assert len(start['sourceInputHashes'])==3342 and all(sha(root/p)==h and oct((root/p).stat().st_mode&0o777)==start['sourceInputModes'][p] for p,h in start['sourceInputHashes'].items())
oldsql=json.loads(subprocess.check_output(['git','show',start['baseCommit']+':tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'],cwd=root));sql=load(root/'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json')
assert len(oldsql['cases'])==58 and sql['cases'][:58]==oldsql['cases'] and sql['cases'][58:]==[{'id':'battlefield-start-lab-you','sourceType':'BattlefieldStartLabYouSqlAcceptance'}]
independent=load(w/'independent-lab-you-sql-result-v1.json');reader=load(w/'independent-lab-you-sql-owner-terminal-v1.json');writer=load(w/'current-lab-you-sql59-owner-terminal-v1.json');broken=load(w/'original-broken-lab-sql-owner-terminal-v1.json')
assert [independent[k] for k in ['histories','snapshots','prompts','eventCount','refused']]==[32,58,58,91,4]
assert writer['originalAcceptedInputs']==writer['actualColdRecoveries']==32 and writer['actualRealDbRefusals']==4 and writer['currentSql59ExitCode']==0
assert reader['independentReaderExitCode']==0 and reader['allOriginal345AuditSevenTablesExact'] and reader['allOriginal76NativeSevenTablesExact'] and reader['ownPostgresSmartStopped']
assert broken['actualOriginalColdRegistryRefusal'] and broken['originalAcceptedInputs']==3 and broken['ownPostgresSmartStopped']
assert (w/'all-independent-tool-tests-before-check-v1.log').read_text().rstrip().endswith('OK')
branches=load(w/'twenty-five-exact-lab-you-behavior-branch-preparation-v2.json');assert len(branches['cases'])==25 and {c['actualExecutedCase'] for c in branches['cases']}==set(added)
result={'atUtc':now(),'status':'SOLE_LAB_YOU_CHECK13436_CASES7543_METHODS_ALL_PASS_ORIGINAL13411_7540_RETAINED_25_NEW3_METHODS','checkStartedOnCommit':start['baseCommit'],'currentHeadObservedSeparately':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'includesDeclaredUncommittedLabChanges':True,'actualCases':13436,'actualMethods':7543,'outcomes':dict(collections.Counter(r.get('outcome') for r in rows)),'originalCaseCount':13411,'originalMethodCount':7540,'oldExactCaseMultisetAndMethodsRetained':True,'originalN41OneFailedCaseAndRunNotRelabeled':True,'newCases':25,'newMethods':3,'newCaseIdentities':sorted(added.elements()),'newMethodNames':sorted(added_methods),'finalAdjacentCases':392,'finalAdjacentMethods':285,'finalOriginalAffectedFullMethods':fulls,'firstRedOriginalOutcomes':{'Passed':16,'Failed':9},'all1802OriginalConformanceFilesWith1801ByteExactAndOnlyOneDeclaredHubExpectedPhysicalFieldAddition':True,'allOriginalTestMethodsTheoryRowsAndAssertionsRetained':True,'allNineOriginalFullSourcesByteExact':full_sources,'all143PublicFullMethods110PairIds11DecksSeed424242AndVictoryReplayAssertionsRetained':True,'currentAll143And110FixedFullNotClaimedByCheck':True,'actualDebugRuleInputs':start['actualLoadedDebugBaseFourAssembliesAndRuleInputs']['actualRuleInputs'],'actualWipReleaseSqlRuleInputs':independent['actualRuleInputs'],'sqlOriginal58IdentitiesOrderAndClassesRetainedOnly59Added':True,'actualRealSqlInputs':32,'actualRealSqlColdRecoveries':32,'independentSqlHistories':32,'independentSqlPrivateSnapshots':58,'independentSqlPrivatePrompts':58,'independentSqlEvents':91,'independentActualDbRefusals':4,'allOriginal345Audit76NativeSevenTablesRetained':True,'originalBrokenLabThreeInputRealSqlColdRefusalPreserved':pin(w/'original-broken-lab-sql-owner-terminal-v1.json'),'onlyCheckTrx':pin(trx),'originalBaselineTrx':pin(baseline),'all3342SourcesAndModes1419Conformance23NativeStable':True,'soleCheckNoDatabaseConnectionProvidedActualSqlOnlyFromDedicated59':True,'all74IndependentToolTestsPassedBeforeCheck':True,'parallelCommittedAndUnstagedWebNotCertifiedByOriginalCheck':pin(w/'parallel-web-commit-during-original-frozen-check-observation-v1.json'),'onlyOneCheckForThisCoherentBatch':True,'newFixedFullAndNewCurrentNativeVisiblePairedAndPhysicalWindows':'OPEN','wholePrintingOrGoalCertified':False}
f=w/'final-only-check-original-retention-v1.json';assert not f.exists();f.write_text(json.dumps(result,indent=2))
print('PASS sole13436/7543 original13411/7540 exact+25/3;focus392/285;1802original files onlyoneassert field addition;9full sources143/110/11/424242 retained;SQL32cold32 independent32/58/58/91 four refusals;3342/1419/23 stable;newfixedfull/productsOPEN',flush=True)
