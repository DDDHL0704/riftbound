# -*- coding: utf-8 -*-
from pathlib import Path
import datetime,gzip,hashlib,json,zipfile
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;source=root/'var/qa/fixed3f2dc-early-native-20261022';sha=lambda b:hashlib.sha256(b).hexdigest()
closure=json.loads((source/'early-fixed3f2dc-native-and-controlled-frost-acceptance-closure-v1.json').read_text());assert closure['ordinaryMain']['commands']==71 and closure['controlledFrost']['commands']==6 and not closure['goalComplete']
excluded_roots={'fixed3f2dc-api-gameplay-closure-runtime-v1','fixed3f2dc-native-helpers-runtime-v1','fixed3f2dc-native-history-reader-runtime-v1','fixed3f2dc-native-network-net8-runtime-v1','executed-own-native-readers-and-drivers-v1'}
# Read auth files only to reject any accidental credential value from the publication set.
secret_values=set();private_files=[]
for p in source.rglob('*'):
 if p.is_file() and p.name.startswith('session-') and p.suffix=='.json':
  private_files.append(str(p.relative_to(root)));d=json.loads(p.read_text());secret_values.update(v for k,v in d.items() if k in {'playerKey','reconnectToken'} and isinstance(v,str) and len(v)>8)
files=[]
for p in source.rglob('*'):
 if not p.is_file() or p.is_symlink():continue
 rel=p.relative_to(source);parts=rel.parts
 if any(part.endswith('.app') or part in {'bin','obj'} for part in parts) or parts[0] in excluded_roots:continue
 if parts[0]=='native-current' and not (len(parts)>1 and parts[1]=='ci-logs'):continue
 if p.name.startswith('session-') or p.name.endswith('.rotating-next') or p.suffix in {'.dll','.pdb','.zip'}:continue
 if p.suffix not in {'.py','.cs','.csproj','.c','.json','.gz','.log','.md','.txt','.js'}:continue
 raw=p.read_bytes();plain=gzip.decompress(raw) if p.suffix=='.gz' else raw
 assert all(secret.encode() not in plain for secret in secret_values),'Private credential appeared in '+str(rel)
 files.append((p,rel.as_posix(),raw))
assert files and len({n for _,n,_ in files})==len(files)
archive=w/'preceding-fixed3f2dc-native-originals-v1.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x') as z:
 for p,name,raw in sorted(files,key=lambda r:r[1]):z.writestr(name,raw,compress_type=zipfile.ZIP_STORED if p.suffix=='.gz' else zipfile.ZIP_DEFLATED)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())=={n for _,n,_ in files}
 for p,name,raw in files:assert z.read(name)==raw and p.read_bytes()==raw
proof={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PRECEDING_FIXED3f2dc_NATIVE_ORIGINALS_CLOSED_SET_BYTE_EXACT_NO_AUTH_FILES_OR_VALUES','archivePath':str(archive.relative_to(root)),'archiveSha256':sha(archive.read_bytes()),'archiveBytes':archive.stat().st_size,'members':[{'member':name,'originalPath':str(p.relative_to(root)),'bytes':len(raw),'sha256':sha(raw)} for p,name,raw in sorted(files,key=lambda r:r[1])],'privateSessionFilesExcludedByPurpose':private_files,'authValueScanPassed':True,'nativeAppsInstallersFrozenRuntimeAndExecutedBinaryDirectoriesExcludedFromPublicationNotDeleted':True,'allFiveMainAndTwoFrostNativeLogsOriginalFailedSourcesOriginalFramesAndIndependentReadersIncluded':True,'fullVisibleWindowsAndWholeCardScopeNotInflated':True,'actualLockBoundariesRetainedAndNotClaimedContinuouslyLocked':True}
with (w/'preceding-fixed3f2dc-native-original-archive-map-v1.json').open('x') as f:json.dump(proof,f,indent=2);f.write('\n')
print('Closed-set native archive',len(files),'members',archive.stat().st_size,'bytes; raw bytes+CRC exact; private auth excluded; no apps/runtime binary duplication.')
