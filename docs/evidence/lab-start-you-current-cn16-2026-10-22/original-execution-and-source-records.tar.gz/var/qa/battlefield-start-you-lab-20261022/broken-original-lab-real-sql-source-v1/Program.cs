using System.IO.Compression;
using System.Text.Json;
using Npgsql;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

Check(args.Length == 1 && !Directory.Exists(args[0]), "Only a fresh original counterexample output.");
var output = Path.GetFullPath(args[0]); Directory.CreateDirectory(output);
var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
Check(RuleInputIdentity.Current.IdentitySha256 == "c84397d6277d445f8d052fcfa2972d7d73acfe15e62ea3f37fd5d379ca9c0fcf", "Actual pre-fix fixed3f2dc runtime required.");
var settings = new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
Check(settings.Host == "127.0.0.1" && settings.Port == 55486 && settings.Database == "riftbound_acceptance" && settings.Username == "codex_riftbound_audit", "Own existing audit database only.");
await using var source = NpgsqlDataSource.Create(settings.ConnectionString);
var room = "LAB-YOU-OLD-BROKEN-" + Guid.NewGuid().ToString("N");
var journal = new OriginalJournal(new PostgresMatchJournal(source), output);
var players = new PostgresMatchPlayerStore(source); var store = new PostgresMatchRecoveryStore(source);
var session = new MatchSession(room, new CoreRuleEngine(), journal, players);
await session.EnsurePlayerAsync("alice", default); await session.EnsurePlayerAsync("bob", default);
const string scenario = "battlefield-turn-start-destroy-draw";
var seeded = await session.SeedScenarioAsync("alice", "original-broken-lab-seed", scenario,
    JsonSerializer.SerializeToElement(new { cmdType = "DEV_SEED_SCENARIO", scenarioId = scenario }), default);
Check(seeded.Accepted && journal.Entries.Count == 3, "Both original atomic seats and one original recorded scenario accepted.");
var frame = await store.LoadAsync(room, default) ?? throw new Exception("Original actual SQL frame required.");
Check(frame.Commands.Count == 3 && !frame.IsConsistent && frame.ValidationErrors.Count > 0,
    "The actual pre-fix original SQL frame must expose the original invalid position.");
Check(frame.ValidationErrors.Any(e => e.Contains("P2-OTHER", StringComparison.Ordinal))
    && !frame.AuthoritativeState!.CardObjects.ContainsKey("P2-OTHER")
    && frame.AuthoritativeState.ObjectLocations["P2-BATTLEFIELD-AAA-OFFSITE"].BattlefieldObjectId == "P2-OTHER",
    "The original offsite unit references the exact missing physical field, not a rules/version mismatch.");
await Save("original-broken-lab-three-input-frame.json.gz", frame);
var raw = new Dictionary<string, JsonElement>();
await using (var connection = await source.OpenConnectionAsync())
{
    foreach (var table in new[] { "matches", "match_players", "command_log", "game_events", "state_snapshots", "snapshots", "action_prompts" })
    {
        await using var q = new NpgsqlCommand($"select coalesce(json_agg(t order by row_to_json(t)::text),'[]'::json)::text from (select * from {table} where match_id=@room)t", connection);
        q.Parameters.AddWithValue("room", room); using var value = JsonDocument.Parse((string)(await q.ExecuteScalarAsync())!); raw[table] = value.RootElement.Clone();
    }
}
await Save("original-broken-lab-all-seven-tables.json.gz", raw);
var rejected = false;
try { await new InMemoryMatchSessionRegistry(new CoreRuleEngine(), journal, store, players).GetOrCreateAsync(room, default); }
catch (MatchSessionException e) when (e.Code == ErrorCodes.RecoveryInconsistent) { rejected = true; }
Check(rejected && journal.Entries.Count == 3, "Actual cold registry recovery refuses original malformed SQL without accepting another input.");
await File.WriteAllTextAsync(Path.Combine(output, "original-real-sql-counterexample.json"), JsonSerializer.Serialize(new {
    status = "CONFIRMED_ORIGINAL_FIXED3f2dc_LAB_SCENARIO_MISSING_OTHER_REAL_SQL_COLD_REFUSAL",
    room, originalAcceptedInputs = 3, actualDatabase = settings.Database, actualRuleInputs = RuleInputIdentity.Current,
    actualOriginalValidationErrors = frame.ValidationErrors, actualRecoveryErrorCode = ErrorCodes.RecoveryInconsistent,
    noVersionMismatchCause = true, noOriginalRoomOrHistoryRewritten = true,
    controlledScenarioNotAnOrdinaryGame = true, expectedMissingFieldCounterexampleNotAProductPass = true
}, json));
Console.WriteLine("CONFIRMED_ORIGINAL_LAB_THREE_SQL_INPUTS_MISSING_OTHER_AND_ACTUAL_COLD_REFUSAL");
async Task Save(string name, object value)
{
    await using var zip = new GZipStream(new FileStream(Path.Combine(output, name), FileMode.CreateNew), CompressionLevel.SmallestSize);
    await JsonSerializer.SerializeAsync(zip, value, value.GetType(), json);
}
static void Check(bool value, string reason) { if (!value) throw new Exception(reason); }

sealed class OriginalJournal(PostgresMatchJournal inner, string output) : IMatchRoomSeatJournal
{
    public List<MatchJournalEntry> Entries { get; } = [];
    async Task Save(MatchJournalEntry entry)
    {
        await using var zip = new GZipStream(new FileStream(Path.Combine(output, $"entry-{Entries.Count + 1:D2}-original-before-persist.json.gz"), FileMode.CreateNew), CompressionLevel.SmallestSize);
        await JsonSerializer.SerializeAsync(zip, entry, new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true });
    }
    public async ValueTask RecordAsync(MatchJournalEntry entry, CancellationToken ct) { await Save(entry); await inner.RecordAsync(entry, ct); Entries.Add(entry); }
    public async ValueTask RecordRoomSeatAsync(MatchJournalEntry entry, string hash, CancellationToken ct) { await Save(entry); await inner.RecordRoomSeatAsync(entry, hash, ct); Entries.Add(entry); }
}
