import ast
import concurrent.futures
import datetime
import gzip
import hashlib
import html
import html.parser
import json
from pathlib import Path
import re
import urllib.request

ROOT=Path('/Users/dinghaolin/MyProjects/riftbound');Q=Path(__file__).resolve().parent;OUT=Q/'four-image-posts';OUT.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
helper=ROOT/'var/qa/official-news-body-20261016/remaining-110/parse-image-posts.py'
defs=[n for n in ast.parse(helper.read_text()).body if isinstance(n,(ast.ClassDef,ast.FunctionDef))]
ns={'html':html,'re':re};exec(compile(ast.Module(body=defs,type_ignores=[]),str(helper),'exec'),ns)
balanced=ns['balanced'];js_string=ns['js_string'];Meta=ns['Meta']
prior=json.loads((ROOT/'docs/evidence/news-body-source-observation-2026-10-16/four-static-image-posts-scoped-review.json').read_text())['records']
retry={r['id']:r for r in json.loads((Q/'news-gap-retry-v3/all-retry-receipts.json').read_text())}
def one(old):
    r=retry[old['id']];p=ROOT/r['rawPath'];compressed=p.read_bytes();assert sha(compressed)==r['compressedSha256']
    raw=gzip.decompress(compressed);assert sha(raw)==r['rawSha256'];source=raw.decode('utf-8')
    match=re.search(r'picture_page_info_list\s*:\s*(\[)',source);assert match,old['id']
    assert not any(s in source for s in ['环境异常','完成验证','访问过于频繁'])
    literal=balanced(source,match.start(1),'[',']');entries=[];pos=1
    while pos<len(literal)-1:
        if literal[pos]=='{':
            entry=balanced(literal,pos,'{','}');cdn=re.search(r"^\{\s*cdn_url\s*:\s*('(?:\\.|[^'\\])*'|\"(?:\\.|[^\"\\])*\")",entry);assert cdn
            entries.append({'ordinal':len(entries)+1,'url':js_string(cdn[1]),'rawEntryLiteralSha256':sha(entry.encode())});pos+=len(entry)
        else:pos+=1
    assert len(entries)==1
    meta=Meta();meta.feed(source);caption=re.sub(r'\\x([0-9a-fA-F]{2})',lambda m:chr(int(m[1],16)),meta.values.get('og:description',''))
    o={'id':old['id'],'url':old['url'],'roundApplicableAsOf':'2026-10-21','region':'CN','language':'zh-CN',
        'rawOriginalPath':r['rawPath'],'rawOriginalSha256':r['rawSha256'],'literalListSha256':sha(literal.encode()),
        'captionSha256':sha(caption.encode()),'primaryImages':entries,'priorLiteralListSha256':old['literalListSha256'],
        'priorCaptionSha256':old['captionSha256'],'allImageListLiteralBytesExact':sha(literal.encode())==old['literalListSha256'],
        'captionExact':sha(caption.encode())==old['captionSha256'],'imageUrlExact':entries[0]['url']==old['image']['url'],
        'freshImageAttemptedAtUtc':now(),'firstPublicationIndependentlyConfirmed':None,'effectiveDateIndependentlyConfirmed':None,
        'noJavascriptExecutedOrChallengeBypassed':True}
    url=entries[0]['url'];req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 Riftbound official-source audit'})
    with urllib.request.urlopen(req,timeout=40) as res:data=res.read();o.update(imageResolvedUrl=res.url,imageHttpStatus=res.status)
    o.update(freshImageReceivedAtUtc=now(),imageSha256=sha(data),imageBytes=len(data),imageBytesExact=data==(ROOT/old['image']['path']).read_bytes(),
        imageMatchesOldVerifiedHash=sha(data)==old['image']['sha256'])
    if o['imageBytesExact'] and o['imageMatchesOldVerifiedHash']:o['verifiedExistingExactImagePath']=old['image']['path']
    else:
        dest=OUT/(old['id']+'.original-image');dest.write_bytes(data);o['changedCurrentImagePath']=str(dest.relative_to(ROOT))
    o.update(status='CURRENT_STATIC_LITERAL_CAPTION_AND_IMAGE_RECONFIRMED_ONLY',
        priorBoundedSurfaceDisposition=old['disposition'],remainingDynamicAndOtherTemplateSurfaces='OPEN',
        wholeSourceOrPrintingCertified=False)
    (OUT/(old['id']+'.receipt.json')).write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'id':o['id'],'sameList':o['allImageListLiteralBytesExact'],'sameCaption':o['captionExact'],'sameImage':o['imageBytesExact']},ensure_ascii=False),flush=True);return o
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:rows=list(pool.map(one,prior))
summary={'status':'FOUR_KNOWN_IMAGE_POST_TEMPLATES_RECONCILED_NOT_JS_CONTENT_GAPS_OR_ALL_SOURCE_CERTIFICATION',
    'recordedAtUtc':now(),'roundApplicableAsOf':'2026-10-21','records':rows,'all4LiteralCaptionImageExact':all(r['allImageListLiteralBytesExact'] and r['captionExact'] and r['imageBytesExact'] and r['imageMatchesOldVerifiedHash'] for r in rows),
    'originalGenericExtractorFailureReceiptsRetained':True,'allOtherRuntimeSourceSurfacesRemainOpen':True}
(OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(summary['status'],summary['all4LiteralCaptionImageExact'],flush=True)
