import sys
sys.dont_write_bytecode = True
import concurrent.futures
import gzip
import datetime
import hashlib
import json
import math
import pathlib
import re
import urllib.request
import time

ROOT = pathlib.Path('/Users/dinghaolin/MyProjects/riftbound')
Q = ROOT / 'var/qa/source-round-20261021'
OUT = Q / 'cards'
OUT.mkdir(exist_ok=True)
sys.path.insert(0, str(ROOT / 'scripts/audit'))
from gallery_coverage import merge_gallery_views
FROZEN = Q / 'prior-adapters'
receipts = []
def digest(data): return hashlib.sha256(data).hexdigest()
def write(name, value): (OUT / (name + '.gz')).write_bytes(gzip.compress((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode(),mtime=0))
def get(url, name, body=None):
    request = urllib.request.Request(url, json.dumps(body).encode() if body is not None else None,
        headers={'Content-Type': 'application/json', 'User-Agent': 'Mozilla/5.0'})
    errors = []
    for attempt in range(3):
        try:
            with urllib.request.urlopen(request, timeout=45) as res:
                raw = res.read(); headers = {k: res.headers[k] for k in ('Date', 'ETag', 'Age', 'Cache-Control', 'Last-Modified') if k in res.headers}
            break
        except Exception as error:
            errors.append({'attemptedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'error': type(error).__name__ + ': ' + str(error)})
            if attempt == 2:
                (OUT / (name + '.error.json')).write_text(json.dumps({'url': url, 'request': body, 'errors': errors}, indent=2) + '\n')
                raise
            time.sleep(2 * (attempt + 1))
    path = OUT / (name+'.gz'); path.write_bytes(gzip.compress(raw,mtime=0))
    row = {'url': url, 'request': body, 'fetchedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'path': str(path.relative_to(ROOT)), 'sha256': digest(raw), 'bytes': len(raw), 'losslessGzipRawResponse': True, 'compressedSha256': digest(path.read_bytes()), 'responseHeaders': headers, 'priorAttempts': errors}
    receipts.append(row)
    (OUT / (name + '.receipt.json')).write_text(json.dumps(row, ensure_ascii=False, indent=2) + '\n')
    return raw

def parse(url, name, body=None): return json.loads(get(url, name, body))
def compare(old, current, key):
    before = {v[key]: v for v in old}; after = {v[key]: v for v in current}
    return {'addedIds': sorted(after.keys() - before.keys()), 'unreturnedPriorIds': sorted(before.keys() - after.keys()),
        'changed': [{'id': identity, 'fields': {k: {'before': before[identity].get(k), 'after': after[identity].get(k)}
            for k in before[identity].keys() | after[identity].keys() if before[identity].get(k) != after[identity].get(k)}}
            for identity in sorted(before.keys() & after.keys()) if before[identity] != after[identity]],
        'oldEntriesNeverImportedIntoCurrentResponse': True, 'semanticsCertified': False}

cn_url = 'https://lol-api.playloltcg.com/xcx/card/searchCardCraftWeb'
params = dict(pageNum=1, pageSize=100, searchContent='', cardCategoryList=[], cardColorList=[], rarityList=[], productCodeList=[])
first = parse(cn_url, 'cn-page-001.json', params); assert first['code'] == 0
total = first['result']['total']
def cn_page(i):
    row = parse(cn_url, f'cn-page-{i:03}.json', {**params, 'pageNum': i})
    assert row['code'] == 0
    return row['result']
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    pages = [first['result']] + list(pool.map(cn_page, range(2, math.ceil(total / 100) + 1)))
assert all(p['total'] == total for p in pages)
cn = sorted([c for p in pages for c in p['list']], key=lambda c: c['id'])
assert len(cn) == len({c['id'] for c in cn}) == total
old_cn = json.loads((FROZEN / 'card-catalog.zh-CN.json').read_text())
cn_delta = compare(old_cn['cards'], cn, 'id')
write('cn-source-delta.json', cn_delta)
write('card-catalog.zh-CN.json', {'source': cn_url, 'fetchedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'total': total, 'cards': cn, 'firstPublicationAndEffectiveDatesIndependentlyConfirmed': None,
    'scope': 'Exact current raw CN records; no semantic certification or active runtime catalog update.'})
write('card-qa.zh-CN.json', {'source': cn_url, 'entries': [{'id': c['id'], 'cardNo': c['cardNo'],
    'cardQaList': c.get('cardQaList'), 'fieldPresent': 'cardQaList' in c} for c in cn],
    'note': 'Null or empty API QA does not imply no FAQ in official documents or linked rule-case articles.'})
print('CN current exact entries:', total, 'added:', len(cn_delta['addedIds']), 'changed:', len(cn_delta['changed']), flush=True)

base = 'https://content.publishing.riotgames.com/publishing-content/v2.0/public/channel/riftbound_website/list/riftbound_gallery_cards?locale=en_US&limit=200&from='
first_en = parse(base + '0', 'en-page-0000.json'); en_total = first_en['metadata']['totalItems']
def en_page(offset): return parse(base + str(offset), f'en-page-{offset:04}.json')
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    en_pages = [first_en] + list(pool.map(en_page, range(200, en_total, 200)))
assert all(p['metadata']['totalItems'] == en_total for p in en_pages)
raw_records = [c for p in en_pages for c in p['data']]
old_en = json.loads((FROZEN / 'card-gallery.en-US.json').read_text())
old_ids = {c['id'] for c in old_en['cards']}; returned_ids = {c['id'] for c in raw_records}
rechecks = []
if old_ids - returned_ids:
    narrow_base = base.replace('limit=200', 'limit=100')
    def narrow(offset): return parse(narrow_base + str(offset), f'en-narrow-{offset:04}.json')
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        rechecks = list(pool.map(narrow, range(0, en_total, 100)))
    assert all(p['metadata']['totalItems'] == en_total for p in rechecks)
whole_url = base.replace('limit=200', 'limit=' + str(max(2000, en_total))) + '0'
whole = parse(whole_url, 'en-whole.json')
gallery_url = 'https://playriftbound.com/en-us/card-gallery/'
raw_html = get(gallery_url, 'en-gallery.html').decode()
match = re.search(r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>', raw_html)
assert match, 'Official SSR structured state missing'
structured = json.loads(match.group(1)); write('en-gallery-next.json', structured)
gallery = next(b for b in structured['props']['pageProps']['page']['blades'] if b['type'] == 'riftboundCardGallery')
ssr = gallery['cards']['items']
records, coverage = merge_gallery_views([
    dict(name='pagination', reportedTotal=en_total, records=raw_records),
    dict(name='narrowRechecks', reportedTotal=en_total, records=[c for p in rechecks for c in p['data']]),
    dict(name='wholeList', reportedTotal=whole['metadata']['totalItems'], records=whole['data']),
    dict(name='pageSsr', reportedTotal=gallery['cards']['async']['metadata']['totalItems'], records=ssr)])
en_delta = compare(old_en['cards'], records, 'id')
write('card-gallery.en-US.json', {'source': gallery_url, 'fetchedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'reportedTotal': en_total, 'returnedEntries': len(records), 'reportedMinusReturned': en_total - len(records),
    'coverageComparisons': coverage, 'sets': gallery['sets']['items'], 'cards': records,
    'semanticsCertified': False, 'previousRecordsNotImportedAsCurrent': True})
write('receipts.json', sorted(receipts, key=lambda r: r['path']))
write('source-deltas.json', {'cn': cn_delta, 'en': en_delta, 'activeRuntimeOrRuleInputsChanged': False,
    'perPrintingApplicabilityAndSemanticReview': 'OPEN', 'sourceUniverseReductionPermitted': False})
summary = {'status': 'FULL_CURRENT_CN_AND_EN_PUBLIC_VIEWS_FETCHED_RECONCILED_NOT_SEMANTIC_CERTIFICATION',
    'cnReported': total, 'cnReturned': len(cn), 'cnAdded': len(cn_delta['addedIds']), 'cnChanged': len(cn_delta['changed']),
    'cnUnreturnedPrior': len(cn_delta['unreturnedPriorIds']), 'enReported': en_total, 'enReturned': len(records),
    'enReportedMinusReturned': en_total - len(records), 'enAdded': len(en_delta['addedIds']), 'enChanged': len(en_delta['changed']),
    'enUnreturnedPrior': len(en_delta['unreturnedPriorIds']), 'apiQaNonempty': sum(bool(c.get('cardQaList')) for c in cn),
    'rawResponses': len(receipts), 'priorIdentitiesRetainedInOriginalEvidence': True, 'runtimeCatalogUpdated': False}
write('summary.json', summary); print(json.dumps(summary, ensure_ascii=False), flush=True)
