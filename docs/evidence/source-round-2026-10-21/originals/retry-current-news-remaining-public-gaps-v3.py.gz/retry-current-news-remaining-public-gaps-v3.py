import ast
import concurrent.futures
import datetime
import gzip
import hashlib
import html.parser
import json
from pathlib import Path
import subprocess
import urllib.parse

ROOT=Path('/Users/dinghaolin/MyProjects/riftbound');Q=Path(__file__).resolve().parent;OUT=Q/'news-gap-retry-v3';OUT.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(n,d):(OUT/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
helper=Q/'reparse-retained-news-originals-readonly-v2.py';nodes=ast.parse(helper.read_text()).body
old_parser=ROOT/'var/qa/cn-effective-20261016/news/parse-articles-v3.py'
definition=next(n for n in ast.parse(old_parser.read_text()).body if isinstance(n,ast.ClassDef) and n.name=='Article')
ns={'html':html,'sha':sha};exec(compile(ast.Module(body=[definition],type_ignores=[]),str(old_parser),'exec'),ns)
defs=[n for n in nodes if isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name in ('LiteralRoot','extract')]
exec(compile(ast.Module(body=defs,type_ignores=[]),str(helper),'exec'),ns);extract=ns['extract']
prior_index=ROOT/'docs/evidence/news-body-source-observation-2026-10-16/all-130-article-transitive-media-inventory.json'
prior={r['id']:r for r in json.loads(prior_index.read_text())['records']}
records=json.loads((Q/'news-reparsed-v2/all-current-news-original-readback-v2.json').read_text())
todo=[r for r in records if not r['status'].startswith('READONLY_COMPLETE') and urllib.parse.urlparse(r['url']).scheme=='https' and r['url']!='https://playloltcg.com/rules.html']
assert len(todo)==20
def one(r):
    o={'id':r['id'],'url':r['url'],'attemptedAtUtc':now(),'roundApplicableAsOf':'2026-10-21','region':'CN','language':'zh-CN',
        'firstPublicationIndependentlyConfirmed':None,'effectiveDateIndependentlyConfirmed':None,
        'previousOriginalReceipt':r['originalReceipt'],'normalTlsValidationNoBypass':True,'attemptsThisRetryPass':1}
    args=['/usr/bin/curl','--silent','--show-error','--fail','--location','--compressed','--max-time','40','--user-agent','Mozilla/5.0 Riftbound official-source audit',r['url']]
    try:
        p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45)
        raw=p.stdout;path=OUT/(r['id']+'.original.gz');path.write_bytes(gzip.compress(raw,mtime=0))
        o.update(exitCode=p.returncode,stderr=p.stderr.decode(errors='replace'),receivedAtUtc=now(),rawPath=str(path.relative_to(ROOT)),
            rawSha256=sha(raw),rawBytes=len(raw),compressedSha256=sha(path.read_bytes()))
        if p.returncode!=0:o['status']='SOURCE_ACCESS_GAP_RETRY_FAILED_ORIGINAL_BYTES_RETAINED'
        else:
            current=extract(raw);body=current.pop('bodyText');bp=OUT/(r['id']+'.body.txt.gz');bp.write_bytes(gzip.compress(body.encode(),mtime=0))
            o.update(status='FETCHED_COMPLETE_LITERAL_ROOT_WITH_NORMAL_TLS_RETRY_NOT_CERTIFICATION',**current,bodyTextPath=str(bp.relative_to(ROOT)))
            if r['id'] in prior:
                pr=prior[r['id']];oldraw=(ROOT/pr['rawPath']).read_bytes();assert sha(oldraw)==pr['rawSha256'];old=extract(oldraw)
                o.update(priorRawPath=pr['rawPath'],priorRawSha256=pr['rawSha256'],
                    literalRootMatchesPrior=current['literalRootSha256']==old['literalRootSha256'],
                    bodyTextMatchesPrior=current['bodyTextSha256']==old['bodyTextSha256'],
                    imagesAllAttributesAndOrderMatchPrior=current['images']==old['images'],linksAndOrderMatchPrior=current['links']==old['links'])
            else:o['priorCompleteRootUnavailable']=True
    except Exception as e:o.update(status='RETRY_ACQUISITION_OR_EXTRACTION_GAP',receivedAtUtc=now(),errorType=type(e).__name__,error=str(e))
    save(r['id']+'.receipt.json',o);print(json.dumps({'id':r['id'],'status':o['status'],'sameRoot':o.get('literalRootMatchesPrior')},ensure_ascii=False),flush=True);return o
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool: retried=list(pool.map(one,todo))
save('all-retry-receipts.json',retried)
summary={'status':'ONE_BOUNDED_NORMAL_TLS_PUBLIC_GAP_RETRY_PASS_NOT_SOURCE_ABSENCE_OR_SEMANTIC_CERTIFICATION','recordedAtUtc':now(),
    'attempted':len(retried),'completeRoots':sum(r['status'].startswith('FETCHED_COMPLETE') for r in retried),
    'changedLiteralRootIds':[r['id'] for r in retried if r.get('literalRootMatchesPrior') is False],
    'changedTextIds':[r['id'] for r in retried if r.get('bodyTextMatchesPrior') is False],
    'remainingGaps':[{'id':r['id'],'url':r['url'],'status':r['status']} for r in retried if not r['status'].startswith('FETCHED_COMPLETE')],
    'original139AcquisitionAndCorrectedReadbackUnmodified':True,'allMediaBytesAndSemanticCertification':False,
    'rulesIndexAliasAndMiniappRouteRetainSeparateExplicitDisposition':True}
save('summary.json',summary);print(json.dumps(summary,ensure_ascii=False),flush=True)
