import ast
import datetime
import gzip
import hashlib
import html.parser
import json
from pathlib import Path

ROOT = Path('/Users/dinghaolin/MyProjects/riftbound')
Q = Path(__file__).resolve().parent
IN = Q/'news'
OUT = Q/'news-reparsed-v2'
assert (IN/'summary.json').is_file(), 'Wait for original acquisition owner terminal; do not edit its inputs'
OUT.mkdir(exist_ok=False)
sha = lambda b: hashlib.sha256(b).hexdigest()
def save(name,obj): (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
parser_path = ROOT/'var/qa/cn-effective-20261016/news/parse-articles-v3.py'
definition = next(n for n in ast.parse(parser_path.read_text()).body if isinstance(n,ast.ClassDef) and n.name=='Article')
namespace={'html':html}
exec(compile(ast.Module(body=[definition],type_ignores=[]),str(parser_path),'exec'),namespace)
Article=namespace['Article']
class LiteralRoot(Article):
    def __init__(self,source):
        super().__init__(); self.source=source; self.line_starts=[0]; self.start=None; self.end=None
        for i,c in enumerate(source):
            if c=='\n': self.line_starts.append(i+1)
    def absolute_source_position(self):
        line,col=self.getpos(); return self.line_starts[line-1]+col
    def handle_starttag(self,tag,attrs):
        before=self.found; super().handle_starttag(tag,attrs)
        if self.found and not before: self.start=self.absolute_source_position()
    def handle_endtag(self,tag):
        before=self.done; super().handle_endtag(tag)
        if self.done and not before: self.end=self.source.index('>',self.absolute_source_position())+1
def extract(raw):
    source=raw.decode('utf-8'); p=LiteralRoot(source); p.feed(source)
    assert p.found and p.done and p.start is not None and p.end is not None, 'No complete js_content root'
    images=[{'url':r.get('data-src') or r.get('src'),**r} for r in p.images if r.get('data-src') or r.get('src')]
    text='\n'.join(p.text); assert text or images, 'Empty article root'
    return {'literalRootSha256':sha(source[p.start:p.end].encode()),'literalRootCharacters':p.end-p.start,
        'bodyTextSha256':sha(text.encode()),'bodyTextCharacters':len(text),'bodyText':text,
        'images':images,'links':p.urls,'articleRootFoundAndClosed':True}
prior_index=ROOT/'docs/evidence/news-body-source-observation-2026-10-16/all-130-article-transitive-media-inventory.json'
previous={r['id']:r for r in json.loads(prior_index.read_text())['records']}; assert len(previous)==130
initials=json.loads((IN/'current-complete-source-attempt-receipts.json').read_text())
assert len(initials)==139 and len({r['id'] for r in initials})==139
input_hashes={str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in IN.iterdir() if p.is_file()}
records=[]
for r in initials:
    receipt=IN/(r['id']+'.receipt.json'); assert json.loads(receipt.read_text())==r
    o={'id':r['id'],'url':r['url'],'originalAcquisitionStatus':r['status'],
        'originalReceipt':{'path':str(receipt.relative_to(ROOT)),'sha256':sha(receipt.read_bytes())},
        'allListingRows':r['allListingRows'],'roundApplicableAsOf':'2026-10-21','region':'CN','language':'zh-CN',
        'firstPublicationIndependentlyConfirmed':None,'effectiveDateIndependentlyConfirmed':None,
        'sourceApplicabilityAndSemanticReview':'OPEN','originalAcquisitionAndFailuresNeverRewritten':True}
    if 'path' not in r:
        o.update(status='ORIGINAL_ACQUISITION_GAP_RETAINED',originalErrorType=r.get('errorType'),originalError=r.get('error'))
        records.append(o); continue
    compressed=(ROOT/r['path']).read_bytes(); assert sha(compressed)==r['compressedSha256']
    raw=gzip.decompress(compressed); assert len(raw)==r['bytes'] and sha(raw)==r['sha256']
    o.update(rawOriginalPath=r['path'],rawOriginalSha256=r['sha256'],rawOriginalBytes=r['bytes'])
    try:
        current=extract(raw); text=current.pop('bodyText')
        body_path=OUT/(r['id']+'.body.txt.gz'); body_path.write_bytes(gzip.compress(text.encode(),mtime=0))
        o.update(status='READONLY_COMPLETE_LITERAL_ROOT_EXTRACTED_FROM_SAME_ORIGINAL_BYTES_NOT_CERTIFICATION',
            **current,bodyTextPath=str(body_path.relative_to(ROOT)))
        if r['id'] in previous:
            prev=previous[r['id']]; p=ROOT/prev['rawPath']; oldraw=p.read_bytes(); assert sha(oldraw)==prev['rawSha256']
            old=extract(oldraw)
            o.update(priorRawPath=prev['rawPath'],priorRawSha256=prev['rawSha256'],
                literalRootMatchesPrior=current['literalRootSha256']==old['literalRootSha256'],
                bodyTextMatchesPrior=current['bodyTextSha256']==old['bodyTextSha256'],
                imagesAllAttributesAndOrderMatchPrior=current['images']==old['images'],
                linksAndOrderMatchPrior=current['links']==old['links'])
        else: o['priorCompleteRootUnavailable']=True
    except Exception as e:
        o.update(status='READONLY_EXTRACTION_GAP_WITH_ORIGINAL_BYTES_RETAINED',errorType=type(e).__name__,error=str(e))
    records.append(o)
assert input_hashes=={str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in IN.iterdir() if p.is_file()}
save('original-input-hashes.json',input_hashes)
save('all-current-news-original-readback-v2.json',records)
summary={'status':'READONLY_CORRECTED_EXTRACTOR_COMPLETE_ORIGINAL_READBACK_NOT_REFETCH_OR_SEMANTIC_CERTIFICATION',
    'recordedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'roundApplicableAsOf':'2026-10-21',
    'original139SourceIdentities':len(records),'originalInputFilesFrozenAndUnchanged':len(input_hashes),
    'completeRoots':sum(r['status'].startswith('READONLY_COMPLETE') for r in records),
    'changedLiteralRootIds':[r['id'] for r in records if r.get('literalRootMatchesPrior') is False],
    'changedTextIds':[r['id'] for r in records if r.get('bodyTextMatchesPrior') is False],
    'changedImageAttributeIds':[r['id'] for r in records if r.get('imagesAllAttributesAndOrderMatchPrior') is False],
    'remainingAcquisitionOrExtractionGaps':[{'id':r['id'],'url':r['url'],'status':r['status'],'error':r.get('error',r.get('originalError'))} for r in records if not r['status'].startswith('READONLY_COMPLETE')],
    'correctedToolFailure':'LiteralRoot.offset method collided with HTMLParser offset integer; corrected helper name only',
    'noHttpRefetchOrOriginalSourceMutation':True,'originalFailureReceiptsPreserved':True,
    'remoteImageBytesDynamicMediaAndWholePrintingSemanticCertification':False}
save('summary.json',summary)
print(json.dumps(summary,ensure_ascii=False),flush=True)
