import ast
import concurrent.futures
import datetime
import gzip
import hashlib
import html
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import urllib.parse
import urllib.request

ROOT=Path('/Users/dinghaolin/MyProjects/riftbound');Q=Path(__file__).resolve().parent;OUT=Q/'global-supplement';OUT.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest(); now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(n,d):(OUT/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
extractor=ROOT/'scripts/audit/snapshot-global-rules.py';tree=ast.parse(extractor.read_text());defs=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in ('article_body','Body')]
ns={'html':html,'HTMLParser':HTMLParser};exec(compile(ast.Module(body=defs,type_ignores=[]),str(extractor),'exec'),ns);article_body=ns['article_body']
discovery=json.loads((Q/'supplemental-known-global-source-discovery-v2.json').read_text())
first=json.loads((Q/'rules/global-receipts.json').read_text());resolved={r['resolvedUrl']:r for r in first}
priors={}
def collect(o,source):
    if isinstance(o,dict):
        if isinstance(o.get('url'),str) and o.get('bodyHtmlSha256'):priors.setdefault(o['url'],{}).setdefault(o['bodyHtmlSha256'],set()).add(source)
        for v in o.values():collect(v,source)
    elif isinstance(o,list):
        for v in o:collect(v,source)
for p in discovery['inspectedFiles']:collect(json.loads((ROOT/p).read_text()),p)
aliases=[{'requestedKnownUrl':u,'actualFreshResolvedUrl':resolved[u]['resolvedUrl'],
    'freshOriginalRequestedUrl':resolved[u]['url'],'freshOriginalResponsePath':resolved[u]['path'],
    'freshOriginalResponseSha256':resolved[u]['sha256'],'bodyHtmlSha256':resolved[u]['bodyHtmlSha256'],
    'evidenceScope':'Exact current HTTP redirect target already fetched this round; no separate second fetch claimed'}
    for u in discovery['notYetFetchedThisRound'] if u in resolved]
save('eight-already-fetched-exact-redirect-targets.json',aliases)
todo=[u for u in discovery['notYetFetchedThisRound'] if u not in resolved];assert len(todo)==8
class Links(HTMLParser):
    def __init__(self):super().__init__();self.urls=[]
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if tag=='a' and a.get('href'):self.urls.append(a['href'])
def one(url):
    key=sha(url.encode())[:16];o={'url':url,'attemptedAtUtc':now(),'roundApplicableAsOf':'2026-10-21','region':'GLOBAL',
        'requestedLanguage':urllib.parse.urlparse(url).path.split('/')[1],
        'languageAndCnApplicabilityRequireExplicitBodyDisposition':True,'firstPublicationIndependentlyConfirmed':None,
        'effectiveDateIndependentlyConfirmed':None,'semanticCertification':False}
    try:
        req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 Riftbound official-source audit'})
        with urllib.request.urlopen(req,timeout=40) as r:raw=r.read();o.update(resolvedUrl=r.url,httpStatus=r.status,
            headers={k:r.headers[k] for k in ('Date','Content-Type','Last-Modified','ETag') if k in r.headers})
        p=OUT/(key+'.html.gz');p.write_bytes(gzip.compress(raw,mtime=0));o.update(status='FETCHED_CURRENT_ORIGINAL_BYTES',receivedAtUtc=now(),
            rawPath=str(p.relative_to(ROOT)),rawSha256=sha(raw),rawBytes=len(raw),compressedSha256=sha(p.read_bytes()))
        s=raw.decode('utf-8');match=re.search(r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>',s,re.S)
        assert match,'Structured official page missing';structured=json.loads(match.group(1));page=structured['props']['pageProps']['page']
        body=article_body(page);o.update(title=page.get('title'),displayedPublishDate=page.get('displayedPublishDate'),
            revision=page.get('analytics',{}).get('rev'),contentBladeTypes=[b.get('type') for b in page.get('blades',[])],
            actualPagePropsLocale=structured['props']['pageProps'].get('locale'))
        links=Links();links.feed(s);o['exactObservedNewsLinks']=sorted(set(urllib.parse.urljoin(o['resolvedUrl'],u).split('#')[0] for u in links.urls
            if '/news/' in urllib.parse.urlparse(urllib.parse.urljoin(o['resolvedUrl'],u)).path))
        if body:
            p=OUT/(key+'.body.html.gz');p.write_bytes(gzip.compress(body.encode(),mtime=0));h=sha(body.encode())
            o.update(status='FETCHED_COMPLETE_ARTICLE_BODY_NOT_SEMANTIC_CERTIFICATION',bodyPath=str(p.relative_to(ROOT)),bodyHtmlSha256=h,
                matchesAnyRecordedExactBodyHash=h in priors.get(url,{}),priorRecordedBodyHashes={k:sorted(v) for k,v in priors.get(url,{}).items()})
        else:
            assert urllib.parse.urlparse(url).path.rstrip('/')=='/en-us/news','No expected article body'
            o.update(status='FETCHED_CURRENT_NEWS_INDEX_NOT_ARTICLE_OR_ALL_HISTORY',exactStructuredPageSha256=sha(json.dumps(page,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()))
    except Exception as e:o.update(status='SOURCE_ACCESS_OR_EXTRACTION_GAP_OR_UNKNOWN_REDIRECT',receivedAtUtc=now(),errorType=type(e).__name__,error=str(e))
    save(key+'.receipt.json',o);print(json.dumps({'url':url,'status':o['status'],'sameKnownBody':o.get('matchesAnyRecordedExactBodyHash')},ensure_ascii=False),flush=True);return o
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:records=list(pool.map(one,todo))
save('all-eight-fresh-global-page-receipts.json',records)
summary={'status':'KNOWN_SUPPLEMENTAL_GLOBAL_URLS_AND_CURRENT_NEWS_INDEX_READBACK_OLD20_CRAWL_LIMITATION_CORRECTED',
    'recordedAtUtc':now(),'freshAdditionalFetches':len(records),'knownUrlExactRedirectTargetsAlreadyFetched':len(aliases),
    'gaps':[r['url'] for r in records if r['status'].startswith('SOURCE_')],
    'bodyHashNotPreviouslyBoundOrChanged':[r['url'] for r in records if r.get('matchesAnyRecordedExactBodyHash') is False],
    'original20SourcesAndFirst31UrlReceiptsUnmodified':True,'fullGlobalNewsHistoryAndTransitiveMediaNotCertified':True,
    'noRuntimeInputsOrOldSourceApplicabilityChanged':True}
save('summary.json',summary);print(json.dumps(summary,ensure_ascii=False),flush=True)
