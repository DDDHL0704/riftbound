import concurrent.futures
import datetime
import gzip
import hashlib
import html
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import urllib.parse
import urllib.request

ROOT = Path('/Users/dinghaolin/MyProjects/riftbound')
Q = ROOT / 'var/qa/source-round-20261021'
OUT = Q / 'rules'
OUT.mkdir(exist_ok=False)
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b): return hashlib.sha256(b).hexdigest()
def digest_file(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda: f.read(1048576), b''): h.update(b)
    return h.hexdigest()
def load(p): return json.loads((ROOT / p).read_text())
def save(name, obj):
    (OUT / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')
def gzsave(p, raw): p.write_bytes(gzip.compress(raw, mtime=0))

corpus = load('docs/evidence/rules-reaudit-2026-10-11/official-corpus.json')
cn_prior = {r['url']: r for r in load('var/qa/cn-effective-20261016/whole-rule-source-readback/cn-receipts.json')}
global_frozen = {r['url']: r for r in load('data/official/upstream/2026-10-12/global-rules-sources.json')['records']}
global_latest = {r['url']: r for r in load('docs/evidence/cn-effective-2026-10-16/global-first-receipts.json')}
known = {**cn_prior, **global_frozen}
for url, row in global_latest.items():
    if row.get('path') and row.get('sha256'): known[url] = row

def acquire(url, name, body=None, prior=None):
    row = {'url': url, 'request': body, 'attemptedAtUtc': now(),
           'region': 'CN' if 'playloltcg.com' in urllib.parse.urlparse(url).netloc else 'GLOBAL',
           'language': 'zh-CN' if 'playloltcg.com' in urllib.parse.urlparse(url).netloc else 'en-US',
           'roundApplicableAsOf': '2026-10-21', 'timezone': 'Asia/Shanghai',
           'firstPublicationIndependentlyConfirmed': None, 'effectiveDateIndependentlyConfirmed': None,
           'semanticCertification': False, 'runtimeAuthorityAdopted': False}
    target = OUT / (name + '.gz')
    assert not target.exists()
    try:
        req = urllib.request.Request(urllib.parse.quote(url, safe=':/?=&%'),
            data=None if body is None else json.dumps(body).encode(),
            headers={'User-Agent': 'Mozilla/5.0 Riftbound official-source audit', 'Content-Type': 'application/json'})
        h = hashlib.sha256(); size = 0; prefix = b''
        with urllib.request.urlopen(req, timeout=45) as res, target.open('xb') as rawfile:
            row.update(resolvedUrl=res.url, httpStatus=res.status,
                responseHeaders={k: res.headers[k] for k in ('Date','ETag','Age','Cache-Control','Last-Modified','Content-Length','Content-Type') if k in res.headers})
            with gzip.GzipFile(filename='', mode='wb', fileobj=rawfile, mtime=0) as sink:
                while True:
                    b = res.read(262144)
                    if not b: break
                    if len(prefix) < 5: prefix = (prefix + b)[:5]
                    h.update(b); size += len(b); sink.write(b)
        row.update(receivedAtUtc=now(), sha256=h.hexdigest(), bytes=size,
            path=str(target.relative_to(ROOT)), losslessGzipRawResponse=True,
            compressedSha256=digest_file(target), status='FETCHED_CURRENT_ORIGINAL_BYTES_NOT_CERTIFICATION',
            kind='pdf' if prefix == b'%PDF-' else 'other')
        prior = prior or known.get(url)
        if prior:
            oldpath = ROOT / prior.get('path', prior.get('localPath', '--none--'))
            row['priorReference'] = {'path': str(oldpath.relative_to(ROOT)), 'sha256': prior.get('sha256')}
            row['matchesPriorRawBytes'] = row['sha256'] == prior.get('sha256')
            if row['matchesPriorRawBytes'] and oldpath.is_file() and digest_file(oldpath) == row['sha256']:
                row.update(path=str(oldpath.relative_to(ROOT)), losslessGzipRawResponse=False,
                    freshNetworkReadbackReusesVerifiedExactExistingBytes=True,
                    identicalTemporaryCompressedCopyRetired={'path': str(target.relative_to(ROOT)),
                        'sha256': row['compressedSha256'], 'bytes': target.stat().st_size})
                target.unlink()
                row.pop('compressedSha256')
    except Exception as e:
        row.update(status='SOURCE_ACCESS_OR_ACQUISITION_GAP', receivedAtUtc=now(), errorType=type(e).__name__, error=str(e))
        if target.exists():
            row['partialOriginalBytes'] = {'path': str(target.relative_to(ROOT)), 'compressedBytes': target.stat().st_size,
                'compressedSha256': digest_file(target), 'complete': False}
    save(name + '.receipt.json', row)
    return row

def raw(row):
    p = ROOT / row['path']
    return gzip.decompress(p.read_bytes()) if row['losslessGzipRawResponse'] else p.read_bytes()

directory = acquire('https://lol-api.playloltcg.com/xcx/gameRule/getGameRuleList', 'cn-rules-directory.json', {'pageNum': 1, 'pageSize': 1000})
assert directory['status'].startswith('FETCHED_')
listed = json.loads(raw(directory)); assert listed['code'] == 0 and isinstance(listed['result'], list)
listed_rows = listed['result']; assert len({r['ruleDocUrl'] for r in listed_rows}) == len(listed_rows)
old_dir_path = ROOT / 'var/qa/graveyard-lifecycle-source-followup-20261020/rules-directory-pre-fix-refresh-v3.json.gz'
old_dir = json.loads(gzip.decompress(old_dir_path.read_bytes()))['result']
save('cn-directory-comparison.json', {'currentListed': len(listed_rows), 'previousListed': len(old_dir),
    'allOriginalRowsAndOrderExact': listed_rows == old_dir, 'before': old_dir, 'after': listed_rows,
    'originalCorpusCount': len(corpus['documents']), 'unlistedHistoricalSourcesRetained': [r['id'] for r in corpus['documents'] if r['url'] not in {v['ruleDocUrl'] for v in listed_rows}],
    'semanticCertification': False})
docs = {d['url']: d for d in corpus['documents']}
for r in listed_rows:
    if r['ruleDocUrl'] not in docs:
        docs[r['ruleDocUrl']] = {'id': 'CN-NEW-' + sha(r['ruleDocUrl'].encode())[:16], 'url': r['ruleDocUrl'], 'title': r['ruleName'], 'updated': r.get('updateDate')}
def cn_one(doc):
    row = acquire(doc['url'], doc['id'] + '.pdf')
    row.update(id=doc['id'], exactFrozenSourceIdentity=doc, currentListing=next((r for r in listed_rows if r['ruleDocUrl'] == doc['url']), None),
        historicalSupersededSourceRetained=doc['url'] not in {r['ruleDocUrl'] for r in listed_rows})
    if row['status'].startswith('FETCHED_') and row['kind'] != 'pdf': row['status'] = 'SOURCE_CONTENT_GAP_EXPECTED_PDF'
    save(doc['id'] + '.receipt.json', row)
    print(json.dumps({'id': doc['id'], 'status': row['status'], 'sameBytes': row.get('matchesPriorRawBytes')}, ensure_ascii=False), flush=True)
    return row
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool: cn_rows = list(pool.map(cn_one, docs.values()))
save('cn-receipts.json', cn_rows)

class Links(HTMLParser):
    def __init__(self): super().__init__(); self.links = []
    def handle_starttag(self, tag, attrs):
        if tag == 'a' and dict(attrs).get('href'): self.links.append(dict(attrs)['href'])
def article_body(page):
    parts = []
    for blade in page.get('blades', []):
        if blade.get('type') == 'articleRichText': parts.append(blade['richText']['body'])
        elif blade.get('type') == 'articleRichTextAccordion':
            parts.extend('<h2>' + html.escape(v) + '</h2>' for v in blade.get('header', {}).values() if isinstance(v, str))
            for group in blade['groups']: parts += ['<h3>' + html.escape(group['label']) + '</h3>', group['content']['body']]
    return '\n'.join(parts)
def eligible(url):
    p = urllib.parse.urlparse(url)
    return ((p.hostname == 'cmsassets.rgpub.io' and p.path.endswith('.pdf')) or
        p.hostname in ('playriftbound.com','riftbound.leagueoflegends.com') and
        any(s in p.path for s in ('patch-notes','errata','faq-and-clarifications','rules-faq','rules-changelog','rules-hub')))
def global_one(url):
    key = 'GLOBAL-' + sha(url.encode())[:16]
    row = acquire(url, key)
    links = []
    if row['status'].startswith('FETCHED_') and row['kind'] != 'pdf':
        try:
            text = raw(row).decode('utf-8'); lp = Links(); lp.feed(text); links = lp.links
            match = re.search(r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>', text, re.S)
            if not match: raise ValueError('No expected structured official page')
            page = json.loads(match.group(1))['props']['pageProps']['page']; body = article_body(page)
            if not body: raise ValueError('No extracted official article body')
            bpath = OUT / (key + '.body.html.gz'); gzsave(bpath, body.encode())
            prior = global_latest.get(url, global_frozen.get(url, {})); old_body = prior.get('bodyHtml')
            row.update(kind='article', title=page.get('title'), displayedPublishDate=page.get('displayedPublishDate'),
                revision=page.get('analytics', {}).get('rev'), contentBladeTypes=[b.get('type') for b in page.get('blades',[])],
                bodyPath=str(bpath.relative_to(ROOT)), bodyHtmlSha256=sha(body.encode()),
                bodyMatchesLatestPrior=body == old_body if old_body is not None else None,
                bodyMatchesFrozenOctober12=body == global_frozen[url].get('bodyHtml') if url in global_frozen else None)
        except Exception as e: row.update(status='SOURCE_EXTRACTION_GAP_WITH_ORIGINAL_BYTES_RETAINED', extractionErrorType=type(e).__name__, extractionError=str(e))
    row['newUrlNotInFrozenInventory'] = url not in global_frozen
    save(key + '.receipt.json', row)
    print(json.dumps({'url': url, 'status': row['status'], 'sameBody': row.get('bodyMatchesLatestPrior'), 'sameBytes': row.get('matchesPriorRawBytes')}, ensure_ascii=False), flush=True)
    return row, [urllib.parse.urljoin(row.get('resolvedUrl', url), link).split('#')[0] for link in links]
pending = list(dict.fromkeys(list(global_frozen) + list(global_latest)))
seen = set(); global_rows = []
while pending:
    batch = [u for u in pending if u not in seen]; pending = []; seen.update(batch)
    assert len(seen) <= 90, 'Discovery exceeded finite rule source boundary; preserve receipts and inspect'
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool: results = list(pool.map(global_one, batch))
    for row, links in results:
        global_rows.append(row)
        for url in links:
            if eligible(url) and url not in seen and url not in pending: pending.append(url)
save('global-receipts.json', global_rows)
summary = {'status': 'CURRENT_DATE_FULL_KNOWN_RULE_SOURCE_UNIVERSE_FETCH_ATTEMPT_NOT_SEMANTIC_CERTIFICATION',
    'recordedAtUtc': now(), 'roundApplicableAsOf': '2026-10-21', 'timezone': 'Asia/Shanghai',
    'cnCurrentlyListed': len(listed_rows), 'cnOriginalCorpus': len(corpus['documents']), 'cnAttempted': len(cn_rows),
    'cnChangedPdfBytes': [r['id'] for r in cn_rows if r.get('matchesPriorRawBytes') is False],
    'cnGaps': [r['id'] for r in cn_rows if not r['status'].startswith('FETCHED_')],
    'globalOriginalSources': len(global_frozen), 'globalAttempted': len(global_rows),
    'globalChangedLatestBodies': [r['url'] for r in global_rows if r.get('bodyMatchesLatestPrior') is False],
    'globalChangedPdfBytes': [r['url'] for r in global_rows if r.get('kind') == 'pdf' and r.get('matchesPriorRawBytes') is False],
    'globalNewUrls': [r['url'] for r in global_rows if r['newUrlNotInFrozenInventory']],
    'globalGaps': [r['url'] for r in global_rows if not r['status'].startswith('FETCHED_')],
    'allOldSourceIdentitiesRetained': True, 'originalSixDeltasUnmodified': True,
    'activeRuntimeInputsChanged': False, 'sourceUniverseReduced': False, 'allSemanticsCertified': False}
save('summary.json', summary)
print(json.dumps(summary, ensure_ascii=False), flush=True)
