import ast
import concurrent.futures
import datetime
import gzip
import hashlib
import html.parser
import json
import math
from pathlib import Path
import urllib.parse
import urllib.request

ROOT = Path('/Users/dinghaolin/MyProjects/riftbound')
Q = Path(__file__).resolve().parent
OUT = Q / 'news'
OUT.mkdir(exist_ok=False)
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
sha = lambda b: hashlib.sha256(b).hexdigest()
def save(name, obj): (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def get(url, name, body=None):
    row = {'url':url,'request':body,'attemptedAtUtc':now(),'roundApplicableAsOf':'2026-10-21',
        'region':'CN','language':'zh-CN','timezone':'Asia/Shanghai','firstPublicationIndependentlyConfirmed':None,
        'effectiveDateIndependentlyConfirmed':None,'semanticReview':'OPEN','runtimeAuthorityChanged':False}
    try:
        req = urllib.request.Request(urllib.parse.quote(url,safe=':/?=&%'),
            data=None if body is None else json.dumps(body).encode(),
            headers={'User-Agent':'Mozilla/5.0 Riftbound official-source audit','Content-Type':'application/json'})
        with urllib.request.urlopen(req,timeout=40) as r:
            raw = r.read(); row.update(resolvedUrl=r.url,httpStatus=r.status,
                responseHeaders={k:r.headers[k] for k in ('Date','ETag','Last-Modified','Content-Type') if k in r.headers})
        p = OUT/(name+'.gz'); assert not p.exists(); p.write_bytes(gzip.compress(raw,mtime=0))
        row.update(status='FETCHED_ORIGINAL_BYTES_NOT_SEMANTIC_CERTIFICATION',receivedAtUtc=now(),path=str(p.relative_to(ROOT)),
            sha256=sha(raw),bytes=len(raw),compressedSha256=sha(p.read_bytes()),losslessGzipOriginalBytes=True)
        return row,raw
    except Exception as e:
        row.update(status='SOURCE_GAP_NORMAL_TLS_FETCH_ERROR',receivedAtUtc=now(),errorType=type(e).__name__,error=str(e))
        return row,None

parser_path = ROOT/'var/qa/cn-effective-20261016/news/parse-articles-v3.py'
tree = ast.parse(parser_path.read_text())
definition = next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name == 'Article')
namespace = {'html':html}
exec(compile(ast.Module(body=[definition],type_ignores=[]),str(parser_path),'exec'),namespace)
Article = namespace['Article']
class LiteralRoot(Article):
    def __init__(self,source):
        super().__init__(); self.source=source; self.line_starts=[0]; self.start=None; self.end=None
        for i,c in enumerate(source):
            if c=='\n': self.line_starts.append(i+1)
    def offset(self):
        line,col=self.getpos(); return self.line_starts[line-1]+col
    def handle_starttag(self,tag,attrs):
        was_found=self.found; super().handle_starttag(tag,attrs)
        if self.found and not was_found: self.start=self.offset()
    def handle_endtag(self,tag):
        was_done=self.done; super().handle_endtag(tag)
        if self.done and not was_done: self.end=self.source.index('>',self.offset())+1
def extract(raw):
    source=raw.decode('utf-8'); p=LiteralRoot(source); p.feed(source)
    assert p.found and p.done and p.start is not None and p.end is not None
    images=[{'url':r.get('data-src') or r.get('src'),**r} for r in p.images if r.get('data-src') or r.get('src')]
    body='\n'.join(p.text)
    assert body or images
    return {'literalRootSha256':sha(source[p.start:p.end].encode()),'literalRootCharacters':p.end-p.start,
        'bodyTextSha256':sha(body.encode()),'bodyTextCharacters':len(body),'text':body,'images':images,'links':p.urls,
        'articleRootFoundAndClosed':True}

listing=[]; listing_receipts=[]
api='https://lol-api.playloltcg.com/xcx/information/page'
receipt,raw=get(api,'official-news-page1.json',{'pageNum':1,'pageSize':100})
assert raw is not None; first=json.loads(raw); assert first['code']==0
total=first['result']['total']; listing+=first['result']['list']; listing_receipts.append(receipt)
for n in range(2,math.ceil(total/100)+1):
    r,b=get(api,f'official-news-page{n}.json',{'pageNum':n,'pageSize':100})
    assert b is not None; d=json.loads(b); assert d['code']==0 and d['result']['total']==total
    listing+=d['result']['list']; listing_receipts.append(r)
assert len(listing)==total
prior=[]
for n in (1,2): prior+=json.loads((ROOT/f'var/qa/official-news-body-20261016/news-page{n}.json').read_text())['result']['list']
identity=lambda r:(r['name'],r['jumpUrl'])
old={identity(r):r for r in prior}; new={identity(r):r for r in listing}
assert len(old)==len(prior) and len(new)==len(listing)
delta={'status':'CURRENT_COMPLETE_LISTING_METADATA_COMPARISON_NOT_BODY_OR_APPLICABILITY_CERTIFICATION',
    'recordedAtUtc':now(),'roundApplicableAsOf':'2026-10-21','reportedTotal':total,'returned':len(listing),
    'priorRows':len(prior),'allOriginalRowsAndOrderExact':listing==prior,'listingReceipts':listing_receipts,
    'added':[v for k,v in new.items() if k not in old],'unreturnedPrior':[v for k,v in old.items() if k not in new],
    'changed':[{'before':old[k],'after':v} for k,v in new.items() if k in old and old[k]!=v],
    'sourceUniverseReduced':False,'semanticCertification':False}
save('listing-delta.json',delta)
previous_media=json.loads((ROOT/'docs/evidence/news-body-source-observation-2026-10-16/all-130-article-transitive-media-inventory.json').read_text())
previous={r['id']:r for r in previous_media['records']}
assert len(previous)==130
unique={r['jumpUrl']:r for r in reversed(listing) if r['jumpUrl']}
save('listing-unique-source-identities.json',{'listedRows':listing,'uniqueSourceUrls':list(unique),'old130RootIds':list(previous)})
def one(item):
    url,row=item; ident='CN-NEWS-'+sha(url.encode())[:16]
    rec,raw=get(url,ident+'.html')
    rec.update(id=ident,allListingRows=[v for v in listing if v['jumpUrl']==url],publishedAsListed=row.get('pushDate'))
    if raw is not None:
        try:
            current=extract(raw); text=current.pop('text')
            text_path=OUT/(ident+'.body.txt.gz'); text_path.write_bytes(gzip.compress(text.encode(),mtime=0))
            rec.update(status='FETCHED_COMPLETE_LITERAL_ARTICLE_ROOT_NOT_SEMANTIC_CERTIFICATION',
                **current,bodyTextPath=str(text_path.relative_to(ROOT)),extractorSourceSha256=sha(parser_path.read_bytes()))
            prev=previous.get(ident)
            if prev:
                p=ROOT/prev['rawPath']; oldraw=p.read_bytes(); assert sha(oldraw)==prev['rawSha256']
                oldroot=extract(oldraw)
                rec.update(priorOriginalRawPath=str(p.relative_to(ROOT)),priorOriginalRawSha256=prev['rawSha256'],
                    literalRootMatchesPrior=current['literalRootSha256']==oldroot['literalRootSha256'],
                    bodyTextMatchesPrior=current['bodyTextSha256']==oldroot['bodyTextSha256'],
                    imageAttributesAndOrderMatchesPrior=current['images']==oldroot['images'],
                    linksAndOrderMatchesPrior=current['links']==oldroot['links'])
            else: rec['priorCompleteRootUnavailable']=True
        except Exception as e:
            rec.update(status='SOURCE_EXTRACTION_GAP_WITH_ORIGINAL_RESPONSE_RETAINED',extractionErrorType=type(e).__name__,extractionError=str(e))
    save(ident+'.receipt.json',rec)
    print(json.dumps({'id':ident,'title':row['name'],'status':rec['status'],'sameLiteralRoot':rec.get('literalRootMatchesPrior')},ensure_ascii=False),flush=True)
    return rec
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool: records=list(pool.map(one,unique.items()))
save('current-complete-source-attempt-receipts.json',records)
summary={'status':'FULL_CURRENT_LISTED_NEWS_URLS_ATTEMPTED_NOT_SEMANTIC_MEDIA_OR_APPLICABILITY_CERTIFICATION',
    'recordedAtUtc':now(),'roundApplicableAsOf':'2026-10-21','reportedAndReturnedListingRows':total,
    'uniqueSourceUrlsAttempted':len(records),'priorCompleteRootCount':len(previous),
    'completeLiteralRoots':sum(r['status'].startswith('FETCHED_COMPLETE_LITERAL') for r in records),
    'changedLiteralRootIds':[r['id'] for r in records if r.get('literalRootMatchesPrior') is False],
    'changedTextIds':[r['id'] for r in records if r.get('bodyTextMatchesPrior') is False],
    'changedImageAttributeIds':[r['id'] for r in records if r.get('imageAttributesAndOrderMatchesPrior') is False],
    'gaps':[{'id':r['id'],'url':r['url'],'status':r['status']} for r in records if not r['status'].startswith('FETCHED_COMPLETE_LITERAL')],
    'allOriginalSourceIdentitiesAndPriorEvidenceRetained':True,'remoteImageBytesAndDynamicMediaNotRecertified':True,
    'sourceUniverseReduced':False,'activeRuntimeAuthorityChanged':False,'wholePrintingSemanticCertification':False}
save('summary.json',summary); print(json.dumps(summary,ensure_ascii=False),flush=True)
