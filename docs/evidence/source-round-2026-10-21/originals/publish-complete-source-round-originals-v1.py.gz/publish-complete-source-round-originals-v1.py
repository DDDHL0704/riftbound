import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import tarfile

root=Path('/Users/dinghaolin/MyProjects/riftbound')
work=Path(__file__).resolve().parent
out=root/'docs/evidence/source-round-2026-10-21'
assert not out.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(p.read_bytes())
def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
def pin(path,role):return {'path':str(path.relative_to(root)),'sha256':sha(path.read_bytes()),'role':role}
source=load(work/'finite-current21-source-disposition-and-manifest-v1.json')
assert source['news']['listedAndAttemptedUrls']==139 and source['cards']['enGapRetained']==8
assert load(work/'post-retirement-independent-original-byte-readback-v1.json')['originalHttpResponses']==142
secrets=[]
for folder in ('fixed-reversal-native-locked-20261020','native-signalr-runtime-patch-fixed-43d5b84e-20261020'):
    for p in (root/'var/qa'/folder).rglob('session*.json'):
        if any(part in {'bin','obj'} or part.endswith('.app') for part in p.parts):continue
        d=load(p)
        for key in ('playerKey','reconnectToken'):
            if isinstance(d,dict) and isinstance(d.get(key),str) and len(d[key])>=8:secrets.append(d[key].encode())
assert len(secrets)>=4
text={'.py','.txt','.log','.tsv'}
keep={'.json','.gz','.png','.xz'}|text
files=[];excluded=[]
for p in sorted(work.rglob('*')):
    if not p.is_file():continue
    rel=p.relative_to(work)
    if any(part in {'__pycache__','prior-adapters'} for part in rel.parts) or p.name.startswith('ci-') or p.name=='open-issues-before-next-source-family-batch-v1.json':
        excluded.append({'path':str(p.relative_to(root)),'reason':'Existing prior source wrappers, issue context or CI metadata retained locally; exact source originals and compact adapters published separately'})
        continue
    if p.suffix not in keep:continue
    raw=p.read_bytes()
    if p.suffix=='.gz':blocks=[gzip.decompress(raw)]
    elif p.name.endswith('.tar.xz'):
        with tarfile.open(p,'r:xz') as tar:blocks=[tar.extractfile(m).read() for m in tar if m.isfile()]
    else:blocks=[raw]
    assert not any(s in b for s in secrets for b in blocks),str(rel)
    assert p.stat().st_size<10*2**20,str(rel)
    files.append((p,rel,raw))
records=[]
for p,rel,raw in files:
    compressed=p.suffix in text
    dest=out/'originals'/rel
    if compressed:dest=dest.with_name(dest.name+'.gz')
    dest.parent.mkdir(parents=True,exist_ok=True)
    if compressed:dest.write_bytes(gzip.compress(raw,mtime=0))
    else:os.link(p,dest)
    assert (gzip.decompress(dest.read_bytes()) if compressed else dest.read_bytes())==raw
    records.append({'originalPath':str(p.relative_to(root)),'originalSha256':sha(raw),'originalBytes':len(raw),
        'canonical':pin(dest,'source-round-original-evidence'),'gzipOriginalBytes':compressed,'samePhysicalFileHardlinked':not compressed})
mapping={r['originalPath']:r['canonical'] for r in records}
def rebind(value):
    if isinstance(value,list):return [rebind(v) for v in value]
    if not isinstance(value,dict):return value
    if 'path' in value and 'sha256' in value and value['path'] in mapping:
        target=mapping[value['path']]
        assert (root/value['path']).is_file() and sha((root/value['path']).read_bytes())==value['sha256']
        assert not next(r for r in records if r['originalPath']==value['path'])['gzipOriginalBytes']
        return {**{k:rebind(v) for k,v in value.items() if k not in ('path','sha256')},'path':target['path'],'sha256':target['sha256']}
    return {k:rebind(v) for k,v in value.items()}
manifest=rebind(source)
manifest['originalComposedManifest']=mapping[str((work/'finite-current21-source-disposition-and-manifest-v1.json').relative_to(root))]
manifest['originalArchivePathsInsideAcquisitionReceiptsAreHistoricalAndResolvedByArchiveMap']=True
manifest['archiveMap']='docs/evidence/source-round-2026-10-21/archive-map.json'
write(out/'source-manifest.json',manifest)
write(out/'archive-map.json',{'createdAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'allOriginalBytesHashesAndHardlinkInodesVerified':True,'privateProfilesAndKnownActualAuthValuesNotPublished':True,
    'all142RetiredOriginalHttpResponsesRemainByteRecoverableInPublishedTarXz':True,
    'originalAcquisitionParserRetryFailuresPreserved':True,'records':records,'excludedStillRetainedLocally':excluded,
    'newSdkCheckoutDatabaseRuntimeOrInstallersCreated':False})
print('PUBLISHED_CURRENT21_ALL_SOURCE_ORIGINALS_AND_PRECISE_DISPOSITION',len(records),sum(r['originalBytes'] for r in records),flush=True)
