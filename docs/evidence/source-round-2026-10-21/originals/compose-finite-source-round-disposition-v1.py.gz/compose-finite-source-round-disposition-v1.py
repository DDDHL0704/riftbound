import collections
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import tarfile

root=Path('/Users/dinghaolin/MyProjects/riftbound')
work=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(path,value,compact=False):
    with path.open('x') as f: json.dump(value,f,ensure_ascii=False,indent=None if compact else 2,separators=(',',':') if compact else None);f.write('\n')
def pin(path,role): return {'path':str(path.relative_to(root)),'sha256':sha(path.read_bytes()),'role':role}
now=datetime.datetime.now(datetime.timezone.utc).isoformat()

# Preserve each complete dictionary and key presence. These are checker adapters,
# never a replacement for the original compressed HTTP response or old evidence.
before=load(work/'prior-adapters/card-gallery.en-US.json')
after=json.loads(gzip.decompress((work/'cards/en-whole.json.gz').read_bytes()))
assert len(before['cards'])==len(after['data'])==1408
a={r['id']:r for r in before['cards']};b={r['id']:r for r in after['data']}
assert set(a)==set(b)
changes=[]
for identity in a:
    fields=[k for k in a[identity].keys()|b[identity].keys() if (k in a[identity])!=(k in b[identity]) or a[identity].get(k)!=b[identity].get(k)]
    if fields: changes.append({'id':identity,'fields':fields})
assert changes==[{'id':'rad-044-167','fields':['flags']}]
assert a['rad-044-167']['flags']==[{'id':'new','label':'New'}] and 'flags' not in b['rad-044-167']
write(work/'en-before-full-rows-checker-adapter-v1.json',{'cards':before['cards']},compact=True)
write(work/'en-after-full-rows-checker-adapter-v1.json',{'metadata':after['metadata'],'data':after['data']},compact=True)

listing=load(work/'news/listing-unique-source-identities.json')['listedRows']
delta=load(work/'news/listing-delta.json')
prior=[]
for n in (1,2): prior+=load(root/f'var/qa/official-news-body-20261016/news-page{n}.json')['result']['list']
assert len(listing)==139 and len(prior)==138 and len(delta['added'])==1 and delta['changed']==delta['unreturnedPrior']==[]
added=delta['added'][0]
assert [r for r in listing if r['jumpUrl']!=added['jumpUrl']]==prior
assert added['jumpUrl']=='https://mp.weixin.qq.com/s/11k9oH0Ib6KexrKrVBIv9w'
rows=load(work/'news-reparsed-v2/all-current-news-original-readback-v2.json')
retries={r['id']:r for r in load(work/'news-gap-retry-v3/all-retry-receipts.json')}
static={r['id']:r for r in load(work/'four-image-posts/summary.json')['records']}
assert len(rows)==len({r['id'] for r in rows})==139 and len(static)==4
old_ids=set(load(work/'news/listing-unique-source-identities.json')['old130RootIds'])
records=[]
for row in rows:
    current=retries.get(row['id'],row)
    if not current.get('articleRootFoundAndClosed') and row.get('articleRootFoundAndClosed'): current=row
    if current.get('articleRootFoundAndClosed'):
        if row['id'] in old_ids:
            assert current['literalRootMatchesPrior'] and current['bodyTextMatchesPrior'] and current['imagesAllAttributesAndOrderMatchPrior'] and current['linksAndOrderMatchPrior']
            disposition='CURRENT_OLD_LITERAL_ROOT_TEXT_IMAGE_ATTRIBUTES_AND_LINK_ORDER_EXACT'
        else:
            assert row['id']=='CN-NEWS-d7e10972978590af'
            disposition='NEW_COMPLETE_IMAGE_ONLY_ARTICLE_ROOT_PRIMARY_IMAGE_VISUALLY_REVIEWED_FUTURE_EVENT_SURFACE'
    elif row['id'] in static:
        s=static[row['id']]
        assert s['allImageListLiteralBytesExact'] and s['captionExact'] and s['imageBytesExact']
        disposition='OLD_STATIC_LITERAL_IMAGE_LIST_CAPTION_AND_PRIMARY_IMAGE_BYTES_EXACT'
    else:
        disposition={
            'CN-NEWS-4316592c21720ace':'CURRENT_RULES_HUB_ALIAS_SAME_RAW_BYTES_NOT_MISSING_SEPARATE_HISTORICAL_QA',
            'CN-NEWS-baf84eaf1a3284a3':'OLD_OFFICIAL_LEGACY_URL_NORMAL_TLS_ACCESS_GAP_RETAINED',
            'CN-NEWS-92d3cd4106bc1173':'OLD_OFFICIAL_LEGACY_URL_NORMAL_TLS_ACCESS_GAP_RETAINED',
            'CN-NEWS-472f8954155e1040':'CURRENT_WECHAT_VERIFICATION_PAGE_OLD_COMPLETE_BODY_RETAINED_ACCESS_OPEN',
            'CN-NEWS-e27c9267fb11ea99':'MINIAPP_RELATIVE_ROUTE_PUBLIC_HTTPS_BODY_NOT_AVAILABLE_SOURCE_OPEN',
        }[row['id']]
    records.append({'id':row['id'],'url':row['url'],'disposition':disposition,
        'recordedOriginalReadback':pin(work/'news-reparsed-v2/all-current-news-original-readback-v2.json','original-corrected-readback'),
        'normalRetryReceipt':pin(work/'news-gap-retry-v3'/(row['id']+'.receipt.json'),'normal-public-retry') if row['id'] in retries else None,
        'staticTemplateReceipt':pin(work/'four-image-posts'/(row['id']+'.receipt.json'),'static-template') if row['id'] in static else None,
        'oldSourceDatesAndFullTransitiveMediaObligationsUnchanged':True,'wholeSourceOrPrintingCertified':False})
counts=collections.Counter(r['disposition'] for r in records)
assert counts['CURRENT_OLD_LITERAL_ROOT_TEXT_IMAGE_ATTRIBUTES_AND_LINK_ORDER_EXACT']==129
assert counts['OLD_STATIC_LITERAL_IMAGE_LIST_CAPTION_AND_PRIMARY_IMAGE_BYTES_EXACT']==4

idx=load(work/'completed-news-originals-index-v1.json')
archive=work/'completed-news-originals-v1.tar.xz'
lookup={r['retiredMaterializedPath']:r for r in idx['records']}
alias=next(r for r in rows if r['id']=='CN-NEWS-4316592c21720ace')
with tarfile.open(archive,'r:xz') as tar:
    raw=tar.extractfile(lookup[alias['rawOriginalPath']]['archiveMember']).read()
assert sha(raw)==alias['rawOriginalSha256']=='574cfebe168c9dedd2f9099b7ea604550c8fe9ecca62383abaad80710893ac2b'
directory=json.loads(gzip.decompress((work/'rules/cn-rules-directory.json.gz').read_bytes()))
assert directory['code']==0 and len(directory['result'])==14
pdf_refs=[]
for n in range(1,17):
    p=work/'rules'/f'DOC-{n:02}.pdf.receipt.json';r=load(p)
    assert r['matchesPriorRawBytes'] and r['freshNetworkReadbackReusesVerifiedExactExistingBytes']
    original=root/r['path'];assert original.is_file() and sha(original.read_bytes())==r['sha256']
    pdf_refs.append(pin(p,'fresh-pdf-readback-with-verified-existing-raw-byte-identity'))
activity=load(work/'new-activity-source/visual-current-date-and-finite-identity-disposition-v1.json')
assert len(activity['finiteIntakeObligations'])==4
result={'recordedAtUtc':now,'status':'CURRENT21_SOURCE_SCOPE_AND_139_PRECISE_DISPOSITIONS_RECONCILED_NOT_CERTIFICATION',
    'round':{'id':'CN-GLOBAL-source-observation-2026-10-21','applicableAsOf':'2026-10-21','timezone':'Asia/Shanghai',
        'regionalAuthority':'CN/zh-CN','globalSources':'GLOBAL en-US and separately recorded localized zh-CN; no automatic CN regional precedence',
        'runtimeAdoptedCoreEffectiveDate':'2026-10-16','previousCertificationScopeAndAllSourceDatesPreserved':True},
    'cards':{'sourceOriginalAndFullKeyPresenceReadback':pin(work/'independent-current-card-original-and-presence-readback-v1.json','all26-original-http-and-full-row-readback'),
        'cnReturned':1504,'cnAllCurrentRowsAndKeyPresenceExactAgainstCn20':True,'cnQaField':'EXPLICIT_NULL_ALL1504_NOT_NO_FAQ_PROOF',
        'enReported':1416,'enReturned':1408,'enGapRetained':8,'oneChange':{'id':'rad-044-167','printing':'RAD-044/167','field':'flags','presentBefore':True,'valueBefore':[{'id':'new','label':'New'}],'presentAfter':False,'valueAfter':'ABSENT_NOT_NULL',
            'allOtherValuesAndKeyPresenceExact':True,'interpretation':'Listing badge removal only; no inferred publication/effective date; existing Unit/Gear source discrepancy issue35 remains open'},
        'initialHelperAfterNullWasGetRepresentationForAbsentFieldOriginalReceiptRetained':True,
        'beforeAdapter':pin(work/'en-before-full-rows-checker-adapter-v1.json','full-exact-old-rows-wrapper-only'),
        'afterAdapter':pin(work/'en-after-full-rows-checker-adapter-v1.json','full-exact-current-rows-wrapper-only')},
    'rules':{'currentCnListedDocuments':14,'originalCnDocumentsRetainedAndReacquired':16,'verifiedExistingOriginalPdfRefs':pdf_refs,
        'all16CnPdfBytesExact':True,'originalGlobalSources':20,'firstCrawlRequestedUrls':31,'elevenNewUrlStringsAreBodyExactAliases':True,
        'knownSupplementalArticleOrLocaleSources':7,'additionalFreshPageFetchesIncludingNewsIndex':8,'initial31PlusFresh8DistinctAttemptUrls':39,
        'globalPriorBodiesAndFourPdfsExact':True,'priorHashAndNormalTlsRetryReconciliation':pin(work/'supplemental-prior-hash-and-localized-retry-reconciliation-v1.json','supplemental-old-hash-and-localized-retry'),
        'firstOld20CrawlCompletenessLabelIsScopedAndSupplementedNotRewritten':True,'allGlobalHistoryTransitiveMediaOrDynamicSurfacesCertified':False},
    'news':{'listedAndAttemptedUrls':139,'old138ListingRowsAndRelativeOrderExact':True,'listingChangedOrRemovedOldRows':0,'newListedRow':added,
        'initialExtractorAndBoundedRetryFailuresPreserved':True,'finiteDispositions':records,'dispositionCounts':dict(counts),
        'allPrior236NewsPrintingAndTransitiveMediaObligationsRetained':True,'currentRulesHubAliasExactHtmlSha256':sha(raw),
        'newActivityPreciseVisualAndDateIdentityDisposition':pin(work/'new-activity-source/visual-current-date-and-finite-identity-disposition-v1.json','finite-new-activity-surface'),
        'fourNewFiniteIntakeObligations':activity['finiteIntakeObligations'],'futureEventIsNotBlanketRadianceLegalityDate':True},
    'storage':{'originalHttpEntityArchive':pin(archive,'lossless-original-http-entities'),'archiveIndex':pin(work/'completed-news-originals-index-v1.json','retired-materialization-member-map'),
        'postRetirementIndependentRawAndOriginalGzipReadback':pin(work/'post-retirement-independent-original-byte-readback-v1.json','all142-original-http-and267-original-input-readback'),
        'retiredMaterializedPathsAreNotClaimedStillPresent':True},
    'runtimeCatalogRuleAuthorityAndAcceptedHistoriesChangedByThisSourceRound':False,
    'allOldSixDeltas1740Printings14293BlocksEn8GapCn236DispositionsRetained':True,'wholePrintingAndGlobalSemanticCertification':False}
write(work/'finite-current21-source-disposition-and-manifest-v1.json',result)
print(result['status'],dict(counts),flush=True)
