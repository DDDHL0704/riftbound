import datetime
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import sys
import tarfile

ROOT=Path('/Users/dinghaolin/MyProjects/riftbound');Q=Path(__file__).resolve().parent
assert (Q/'news/summary.json').is_file() and (Q/'news-reparsed-v2/summary.json').is_file()
assert (Q/'news-gap-retry-v3/summary.json').is_file() and (Q/'four-image-posts/summary.json').is_file()
sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
paths=sorted((Q/'news').glob('CN-NEWS-*.html.gz'))+sorted((Q/'news-gap-retry-v3').glob('CN-NEWS-*.original.gz'))
assert paths and len(paths)==len(set(paths))
before_free=shutil.disk_usage(ROOT).free
rows=[]
for p in paths:
    compressed=p.read_bytes();raw=gzip.decompress(compressed)
    assert gzip.compress(raw,mtime=0)==compressed,'Original gzip bytes must be exactly recoverable too'
    rows.append({'retiredMaterializedPath':str(p.relative_to(ROOT)),
        'archiveMember':str(p.relative_to(Q))[:-3],'rawHttpEntityBytes':len(raw),'rawSha256':sha(raw),
        'originalGzipBytes':len(compressed),'originalGzipSha256':sha(compressed)})
index={'status':'EXACT_ORIGINAL_HTTP_ENTITIES_AND_ORIGINAL_GZIP_RECONSTRUCTION_INDEX',
    'createdAtUtc':now(),'pythonVersion':sys.version,'originalGzipRecipe':{'function':'gzip.compress','mtime':0,'compresslevel':9},
    'records':rows,'allOriginalReceiptAndParserFailureFilesRetained':True,
    'noSourceCatalogTestsRuntimeHistoryOrDatabaseDeletion':True}
index_bytes=(json.dumps(index,ensure_ascii=False,indent=2)+'\n').encode()
archive=Q/'completed-news-originals-v1.tar.xz';assert not archive.exists()
def add(arc,name,data):
    info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o600;arc.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'w:xz',preset=6) as arc:
    add(arc,'original-bytes-index.json',index_bytes)
    for p,row in zip(paths,rows):add(arc,row['archiveMember'],gzip.decompress(p.read_bytes()))
with tarfile.open(archive,'r:xz') as arc:
    assert arc.getnames()==['original-bytes-index.json']+[r['archiveMember'] for r in rows]
    assert arc.extractfile('original-bytes-index.json').read()==index_bytes
    for p,row in zip(paths,rows):
        raw=arc.extractfile(row['archiveMember']).read();original=p.read_bytes()
        assert len(raw)==row['rawHttpEntityBytes'] and sha(raw)==row['rawSha256']
        assert gzip.compress(raw,mtime=0)==original and sha(original)==row['originalGzipSha256']
verified={'status':'PASS_EVERY_ARCHIVE_MEMBER_AND_ORIGINAL_GZIP_BYTES_EXACT_BEFORE_RETIREMENT',
    'verifiedAtUtc':now(),'archivePath':str(archive.relative_to(ROOT)),'archiveSha256':sha(archive.read_bytes()),
    'archiveBytes':archive.stat().st_size,'originalGzipFiles':len(rows),
    'originalGzipBytes':sum(r['originalGzipBytes'] for r in rows),'originalHttpEntityBytes':sum(r['rawHttpEntityBytes'] for r in rows),
    'originalContentSha256AndOriginalCompressedBytesBothRecoverable':True,
    'onlyCompletedOwnDuplicatedMaterializationsRetired':True,'nativeAppsInstallersToolsTestsSourcesAndOriginalDatabaseUntouched':True}
for name,data in [('completed-news-originals-index-v1.json',index),('completed-news-originals-before-retirement-proof-v1.json',verified)]:
    with (Q/name).open('x') as f:f.write(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
for p,row in zip(paths,rows):
    assert p.is_file() and sha(p.read_bytes())==row['originalGzipSha256'];p.unlink()
assert all(not p.exists() for p in paths)
receipt={**verified,'status':'PASS_COMPLETED_ORIGINAL_BYTES_RETAINED_IN_VERIFIED_LOSSLESS_ARCHIVE_ONLY_REDUNDANT_MATERIALIZATIONS_RETIRED',
    'retiredAtUtc':now(),'availableBytesBefore':before_free,'availableBytesAfter':shutil.disk_usage(ROOT).free,
    'logicalMaterializationBytesMinusArchiveBytes':verified['originalGzipBytes']-verified['archiveBytes'],
    'beforeAfterFreeSpaceMayIncludeOtherConcurrentSystemActivity':True,
    'oldAcquisitionReceiptsRetainOriginalPathsAndTemporalClaimsWithThisExplicitRetirementMap':True,
    'nextReadbackUsesArchiveMembersNoNeedToRefetchOrMaterializeAllBodies':True}
with (Q/'completed-news-originals-retirement-v1.json').open('x') as f:f.write(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(receipt,ensure_ascii=False),flush=True)
