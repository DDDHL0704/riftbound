# -*- coding: utf-8 -*-
from pathlib import Path
from datetime import datetime, timezone
import collections, gzip, hashlib, json, os, resource, subprocess, xml.etree.ElementTree as ET
resource.setrlimit(resource.RLIMIT_CORE, (0, 0)); os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');qa=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.now(timezone.utc).isoformat();load=lambda p:json.loads(p.read_text())
base='55fdbabf8731fec795c26584985bd31cc0bcca32';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==base
before=json.loads(gzip.decompress((qa/'before-any-gameplay-edit-original-inputs-v1.json.gz').read_bytes()))
sql=load(qa/'current-rule-sql60-frozen-inputs-v1.json');actual_sql=load(qa/'real-sql60-owner-terminal-v1.json')
assert actual_sql['status'].startswith('PASS_CURRENT_CANDIDATE_SQL60') and actual_sql['originalAcceptedInputs']==actual_sql['actualColdRecoveries']==126
paths=list(sql['sourceInputHashes']);assert len(paths)==3350
inputs={p:{'sha256':sha(root/p),'mode':oct((root/p).stat().st_mode&0o777)} for p in paths}
sql_delta={p for p in paths if inputs[p]!=sql['sourceInputHashes'][p]};assert sql_delta=={'clients/godot/scripts/debug/DeckPendingParentInteractionProof.cs'}
old_tests=before['originalConformanceFiles'];assert len(old_tests)==1804
changed_original={p for p,v in old_tests.items() if inputs[p]!=v};assert changed_original=={'tests/Riftbound.ConformanceTests/FullGameEndToEndTests.cs'}
full_path='tests/Riftbound.ConformanceTests/FullGameEndToEndTests.cs';old=subprocess.check_output(['git','show',base+':'+full_path],cwd=root,text=True)
expected=old.replace('else if (result.State.StackItems.LastOrDefault()?.DeckPlaySequence is { Kind: "OPPONENT_REVEAL_PLAY" or "SINGLE_PUBLIC_PLAY" } revealed',
 'else if (result.State.StackItems.SingleOrDefault(i => i.StackItemId == result.State.PendingCardChoice?.DeckContext?.StackItemId)\n                        is { DeckPlaySequence: { Kind: "OPPONENT_REVEAL_PLAY" or "SINGLE_PUBLIC_PLAY" } revealed } parent').replace('                        var parent = result.State.StackItems.Last();\n','')
assert (root/full_path).read_text()==expected
assert load(qa/'shared-pending-observed-focus-v6/summary.json')['total']==164
assert load(qa/'final-new-scenarios-and-staging-focus-v8/summary.json')['total']==48
tool=load(qa/'tooling-tests-original-final-chunk-v1.json');assert tool['exit_code']==0 and 'Ran 74 tests' in tool['output'] and tool['output'].rstrip().endswith('OK')
native=qa/'native-actual-sql-choice-controls-v2';index=load(native/'index.json');assert len(index)==22 and all(Path(x['outputCommandPath']).is_file() for x in index)
native_assembly=root/'clients/godot/.godot/mono/temp/bin/Debug/Riftbound.GodotClient.dll';assert sha(native_assembly)==load(native/'input-identity-v1.json')['nativeGodotAssemblySha256']
prior=load(root/'var/qa/main-initial-snapshot-reconnect-race-20261022/only-check-start-inputs-v1.json');excluded=prior['excludedGeneratedOutputDirectory']
runtime={}
for name,folder in [('Conformance',root/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0'),('Native',root/'clients/godot/.godot/mono/temp/bin/Debug')]:
 runtime[name]={str(p.relative_to(root)):sha(p) for p in folder.rglob('*') if p.is_file() and not str(p.relative_to(root)).startswith(excluded+'/')}
assert len(runtime['Conformance'])==1419 and len(runtime['Native'])==22
r=root/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0';probe=root/'var/qa/fixed55fdb-early-native-20261022/ordinary-ci-pair-attempt-v2/selected-actual-native-history-reader-source-v2/bin/Release/net10.0/Fixed55fdbNativeHistoryReaderV2.dll'
measurement=json.loads(subprocess.check_output(['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(r/'Riftbound.ConformanceTests.deps.json'),'--runtimeconfig',str(r/'Riftbound.ConformanceTests.runtimeconfig.json'),str(probe),'--loaded-inputs'],cwd=r,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0')))
assert Path(measurement['baseDirectory'])==r and measurement['actualRuleInputs']==sql['actualRuleInputs'] and len(measurement['assemblies'])==4
for a in measurement['assemblies']:assert Path(a['path'])==r/(a['name']+'.dll') and a['sha256']==runtime['Conformance'][str(Path(a['path']).relative_to(root))] and a['mvid']
start={'atUtc':now(),'baseCommit':base,'all3350SourceHashesAndModes':inputs,'original1804ConformanceFiles':old_tests,'onlyOneOriginalFileExactFourLineActiveParentOracleCalibration':full_path,'allOther1803OriginalFilesByteExact':True,'actualRuntimeInputs':runtime,'actualFourLoadedAssembliesAndRuleInputs':measurement,'expectedCases':13497,'expectedMethods':7559,'originalBaselineTrx':before['originalCasesTrx'],'originalBaselineTrxSha256':sha(root/before['originalCasesTrx']),'newCases':48,'newMethods':9,'sourceScope':'Finite shared instructed deck-play pending stage and repeated observation ordering; WildClaw not adopted.','actual12RoomSql126ColdAndFourRefusalsSeparate':True,'actual22HeadlessProductionControlsSeparate':True,'tooling74Passed':True,'wholePrintingOrGoalCertified':False}
manifest=qa/'sole-check-start-inputs-v1.json.gz';assert not manifest.exists();manifest.write_bytes(gzip.compress(json.dumps(start,indent=2).encode(),mtime=0))
out=qa/'sole-check-v1';assert not out.exists();command=['python3','scripts/test-rules.py','check','--output',str(out)];env=dict(os.environ);env.pop('ConnectionStrings__Riftbound',None)
terminal={'status':'RUNNING_SOLE_PENDING_PARENT_CHECK','startedAtUtc':now(),'baseCommit':base,'command':command,'startManifestSha256':sha(manifest)}
print('SOLE_CHECK_STARTED_EXPECT13497_CASES7559_METHODS_3350_SOURCES_1419_CONFORMANCE_22_NATIVE',flush=True)
try:
 with (qa/'sole-check-console-v1.log').open('xb') as log:
  child=subprocess.Popen(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,env=env);terminal['testRunnerPid']=child.pid
  (qa/'sole-check-running-owner-v1.json').write_text(json.dumps(dict(terminal,ownerPid=os.getpid()),indent=2))
  power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(child.pid)]);terminal['exitCode']=child.wait();power.wait(timeout=10)
 if terminal['exitCode']==0:
  summary=load(out/'summary.json');assert summary['status']=='PASSED' and summary['total']==13497
  plan=load(out/'plan.json');assert plan['discoveredMethods']==7700 and sum(len(s['methods']) for s in plan['shards'])==7559
  ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
  def cases(p):
   d=ET.parse(p);return collections.Counter(x.get('testName') for x in d.findall('.//t:UnitTestResult',ns))
  earlier=cases(root/before['originalCasesTrx']);current=cases(out/'check/results.trx');assert sum(earlier.values())==13449 and sum(current.values())==13497 and not(earlier-current)
  added=current-earlier;assert sum(added.values())==48 and all('.DeckPlayPendingBeforeParentTests.' in n or '.DeckPlayPendingScenarioTests.' in n for n in added)
  terminal.update(status='PASS_SOLE_COHERENT_PENDING_PARENT_CHECK13497_CASES7559_METHODS',summary=summary,original13449CasesExactRetained=True,addedCaseNames=sorted(added.elements()),trxSha256=sha(out/'check/results.trx'))
 else:terminal['status']='FAILED_SOLE_PENDING_PARENT_CHECK_ORIGINALS_RETAINED'
finally:
 terminal.update(finishedAtUtc=now(),all3350SourcesAndModesStable=all(sha(root/p)==v['sha256'] and oct((root/p).stat().st_mode&0o777)==v['mode'] for p,v in inputs.items()),all1419ConformanceAnd22NativeRuntimeInputsStable=all(sha(root/p)==h for group in runtime.values() for p,h in group.items()))
 with (qa/'sole-check-owner-terminal-v1.json').open('x') as f:json.dump(terminal,f,indent=2)
print(json.dumps(terminal),flush=True)
assert terminal['exitCode']==0 and terminal['all3350SourcesAndModesStable'] and terminal['all1419ConformanceAnd22NativeRuntimeInputsStable']
