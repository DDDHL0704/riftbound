# -*- coding: utf-8 -*-
from pathlib import Path
import copy,datetime,gzip,hashlib,io,json,re,subprocess,tarfile
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
native=root/'var/qa/fixed55fdb-early-native-20261022';fresh=root/'var/qa/wild-claw-current-cn16-20261022';base='55fdbabf8731fec795c26584985bd31cc0bcca32'
load=lambda p:json.loads(p.read_text());now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def pin(p,role=None):
 v={'path':str(p.relative_to(root)),'sha256':sha(p)}
 if role:v['role']=role
 return v
def write(p,v):
 with p.open('x') as f:json.dump(v,f,ensure_ascii=False,indent=2)
assert not (w/'malformed-suspended-context-correction-pending-v1.json').exists(), 'The48-case draft is superseded: finish malformed-context safety correction and use the final51-case publisher.'
contract=load(w/'next-coherent-publication-contract-v1.json')
check=load(w/'sole-check-owner-terminal-v1.json');assert check['status']=='PASS_SOLE_COHERENT_PENDING_PARENT_CHECK13497_CASES7559_METHODS'
assert check['exitCode']==0 and check['all3350SourcesAndModesStable'] and check['all1419ConformanceAnd22NativeRuntimeInputsStable']
retained=load(w/'final-original-test-and-input-retention-v1.json');assert retained['actualCases']==13497 and retained['actualMethods']==7559 and retained['newCases']==48
start=json.loads(gzip.decompress((w/'sole-check-start-inputs-v1.json.gz').read_bytes()))
assert all(sha(root/p)==v['sha256'] for p,v in start['all3350SourceHashesAndModes'].items())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==base
sql=load(w/'independent-sql60-original-result-v1.json');assert sql['totals']=={'commands':126,'events':384,'authority':126,'snapshots':240,'prompts':240,'native':22,'originalPrefixReplays':126,'actualCorruptRoomRefusals':4}
sql_owner=load(w/'independent-sql60-owner-terminal-v1.json');assert sql_owner['ownPostgresSmartStopped'] and sql_owner['all357AuditSevenTablesExact'] and sql_owner['all88NativeSevenTablesExact']
prep=load(w/'forty-eight-exact-pending-parent-branches-and-current-rule-preparation-v1.json');assert len(prep['cases'])==48 and len(prep['newMethods'])==9 and len(prep['sourceRuleRecordIds'])==13
previous_full=root/'var/qa/fixed68ba1-early-native-20261022/ci68ba1-entire-full-independent-verification-v1.json';old_full=load(previous_full)
assert (old_full['actualCases'],old_full['actualMethods'],old_full['sql']['caseCount'])==(13598,7691,59) and len(old_full['jobs'])==11 and all(v=='success' for v in old_full['jobs'].values())
previous_native=native/'fixed55fdb-current-native-normal-score-network-paid-lab-and-original-replay-closure-v2.json';assert previous_native.exists()
current_full_path=native/'ci55fdb-entire-full-independent-verification-v1.json';current_full=load(current_full_path) if current_full_path.exists() else None
if current_full:assert (current_full['actualCases'],current_full['actualMethods'],current_full['sql']['caseCount'])==(13598,7691,59) and len(current_full['jobs'])==11 and all(v=='success' for v in current_full['jobs'].values())
mp=root/'docs/audit/current-manifest.json';m=load(mp);old=copy.deepcopy(m);rp=root/m['inputs']['reviews']['path'];reviews=load(rp);old_reviews=copy.deepcopy(reviews)
binding=load(w/'current-existing-context-input-pin-change-before-publication-v2.json');assert sha(mp)==binding['currentManifestSha256']
assert (len(reviews['reviews']),len(m['reviewContexts']),len(m['acceptanceGates']),len(m['laterSourceDeltas']))==(165,80,252,7)
assert json.loads(gzip.decompress((w/'all-original80-contexts-before-pending-parent-refresh-v1.json.gz').read_bytes()))==m['reviewContexts']
prior=w/'prior-coherent-publication-v1';prior.mkdir()
for p in [mp,rp,root/'docs/PROJECT_STATUS.md']:(prior/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
identity='deck-pending-before-parent-current-cn16-2026-10-22';document='docs/DECK_PENDING_BEFORE_PARENT_CURRENT_CN16_AUDIT_2026-10-22.md';ev=root/'docs/evidence/deck-pending-before-parent-current-cn16-2026-10-22';ev.mkdir()
runtime_roots=[Path(load(w/'current-rule-sql60-frozen-inputs-v1.json')['runtimeRoot'])]
np=load(native/'frozen-fixed55fdb-native-composition-v1.json');runtime_roots.extend(Path(np[k]) for k in ['apiRuntimeRoot','helperRuntimeRoot','networkRuntimeRoot'])
paths={p for folder in [w,native] for p in folder.rglob('*') if p.is_file()}
paths.update([previous_full,fresh/'current-cn-rule-directory-and-known-source-versions-v1.json',fresh/'current-complete-cn-full-row-and-qa-readback-v1.json',fresh/'current-complete-cn-original-pages-v1.jsonl.gz'])
def generated(p):return any(p.is_relative_to(folder) for folder in runtime_roots) or any(x in {'bin','obj','__pycache__','native-current','.godot'} or x.endswith('.app') for x in p.parts)
secrets=set()
def collect(v):
 if isinstance(v,dict):
  for k,a in v.items():
   if k.lower() in {'playerkey','reconnecttoken'} and isinstance(a,str) and len(a)>=16:secrets.add(a.encode())
   else:collect(a)
 elif isinstance(v,list):
  for a in v:collect(a)
for p in paths:
 if generated(p):continue
 if p.name.endswith(('.json','.json.gz','.ndjson','.ndjson.gz')):
  try:
   raw=p.read_bytes();raw=gzip.decompress(raw) if p.suffix=='.gz' else raw
   if '.ndjson' in p.name:
    for line in raw.decode().splitlines():
     if line.strip():collect(json.loads(line))
   else:collect(json.loads(raw))
  except (ValueError,OSError,UnicodeDecodeError):pass
canonical={};members={};rows=[];excluded=[]
for p in sorted(paths):
 name=str(p.relative_to(root));reason=None
 if generated(p):reason='EXISTING_FROZEN_RUNTIME_APP_DEPENDENCY_OR_GENERATED_BUILD_NOT_DUPLICATED'
 elif p.suffix=='.zip':reason='SINGLE_ORIGINAL_BACKEND_ZIP_RETAINED_LOCALLY_HASH_PINNED_NO_SECOND_COPY'
 elif p.name.endswith(('.html','.html.gz')):reason='PRIMARY_FULL_HTML_LOCAL_ONLY_HASH_METADATA_RETAINED'
 elif p.suffix=='.env' or any('profile' in x.lower() for x in p.parts) or p.name.startswith('session-'):reason='PRIVATE_QA_SESSION_LOCAL_ONLY'
 if reason:
  excluded.append({'path':name,'bytes':p.stat().st_size,'sha256':sha(p),'reason':reason});continue
 raw=p.read_bytes();inspect=raw
 if p.suffix=='.gz':
  try:inspect=gzip.decompress(raw)
  except OSError:pass
 digest=hashlib.sha256(raw).hexdigest()
 if any(s in inspect for s in secrets):excluded.append({'path':name,'bytes':len(raw),'sha256':digest,'reason':'PRIVATE_SESSION_AUTH_VALUE_LOCAL_ONLY'});continue
 member=canonical.get(digest)
 if member is None:canonical[digest]=name;member=name;members[name]=p
 rows.append({'path':name,'bytes':len(raw),'sha256':digest,'archiveMember':member})
archive=ev/'original-execution-source-and-bounded-native-records.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as t:
 for name,p in sorted(members.items()):
  raw=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(raw);info.mode=p.stat().st_mode&0o777;info.mtime=0;t.addfile(info,io.BytesIO(raw))
with tarfile.open(archive,'r:gz') as t:
 assert set(t.getnames())==set(members)
 for row in rows:
  raw=t.extractfile(row['archiveMember']).read();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
write(ev/'archive-map.json',{'atUtc':now(),'archive':pin(archive),'originalPathsWithExactCanonicalMember':rows,'localOnlyExclusions':excluded,'allMemberBytesHashesAndClosedSetVerified':True,'equalPayloadsStoredOnlyOnce':True,'noInstallerAppSdkDependencyProfileOrFullHtmlCopies':True})
copies={
 'final-original-test-and-input-retention.json':w/'final-original-test-and-input-retention-v1.json',
 'sole-check-original-owner-terminal.json':w/'sole-check-owner-terminal-v1.json',
 'current-exact-four-consumer-official-full-rows.json':w/'exact-four-current-official-consumer-full-rows-v1.json',
 'current-nocturne-full-api-nonnull-errata-and-visual-authority.json':w/'exact-current-nocturne-static-observation-consumer-v1.json',
 'current-cn16-all-sixteen-source-version-readback.json':fresh/'current-cn-rule-directory-and-known-source-versions-v1.json',
 'current-cn1504-complete-full-row-and-qa-readback.json':fresh/'current-complete-cn-full-row-and-qa-readback-v1.json',
 'exact-rule-pages-visual-readback.json':w/'cn337-354-page-visual-disposition-v1.json',
 'forty-eight-exact-behavior-branch-preparation.json':w/'forty-eight-exact-pending-parent-branches-and-current-rule-preparation-v1.json',
 'real-sql-original-writer-twelve-rooms.json':w/'real-sql60-owner-terminal-v1.json',
 'independent-original-sql126-prefixes240-private-rows-and22-native-packets.json':w/'independent-sql60-original-result-v1.json',
 'independent-sql-owner-all357-and88-seven-tables-exact.json':w/'independent-sql60-owner-terminal-v1.json',
 'actual-native22-production-control-terminal-and-packets.json':w/'native-actual-sql-choice-controls-v2/actual-native-production-control-terminal-and-packets-v1.json',
 'original80-complete-contexts-before-refresh.json.gz':w/'all-original80-contexts-before-pending-parent-refresh-v1.json.gz',
 'preceding-fixed68ba1-complete-full.json':previous_full,
 'preceding-fixed55-native-normal-score-network-lab-original-replay.json':previous_native}
if current_full:copies['preceding-fixed55-complete-full.json']=current_full_path
for name,p in copies.items():(ev/name).write_bytes(p.read_bytes())
implementation_paths=['src/Riftbound.Engine/CoreRuleEngine.DeckPlaySequence.cs','src/Riftbound.Engine/CoreRuleEngine.DeckObservation.cs','src/Riftbound.Engine/CoreRuleEngine.EffectPlay.cs','src/Riftbound.Engine/CoreRuleEngine.cs','src/Riftbound.Engine/MatchRecovery.cs','src/Riftbound.Engine/MatchSession.cs','src/Riftbound.Engine/MatchSession.DeckPendingScenario.cs']
verification_paths=['tests/Riftbound.ConformanceTests/DeckPlayPendingBeforeParentTests.cs','tests/Riftbound.ConformanceTests/DeckPlayPendingScenarioTests.cs','tests/Riftbound.ConformanceTests/DeckPlaySequenceTests.cs','tests/Riftbound.ConformanceTests/SingleDeckPlaySequenceTests.cs','tests/Riftbound.ConformanceTests/DeckPlayObservationOrderTests.cs','tests/Riftbound.ConformanceTests/FullGameEndToEndTests.cs','tests/Riftbound.PostgresAcceptance/DeckPendingParentSqlAcceptance.cs','tests/Riftbound.PostgresAcceptance/Program.cs','tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json','scripts/tests/test_sql_ci_gate.py','clients/godot/scripts/debug/DeckPendingParentInteractionProof.cs','clients/godot/scenes/debug/DeckPendingParentInteractionProof.tscn']
source_manifest={'schemaVersion':1,'id':identity,'atUtc':now(),'region':'CN','language':'zh-CN','applicableAsOf':'2026-10-22','adoptedCoreEffectiveDate':'2026-10-16','baseCommit':base,'issue':'https://github.com/DDDHL0704/riftbound/issues/91','scope':'Current two-seat instructed deck plays enter real pending stack slots before the resolving parent continues. Preserve parent completion, insertion-order confirmation, optional decline, private observation, repeats and later observed permissions. Only these bounded branches are reviewed; Wild Claw is not registered.','exactPrintings':['OGN-025/298','OGN-062/298','OGN-115/298','SFD-188/221','OGN-194/298'],'sourceRuleRecords':prep['sourceRuleRecordIds'],'exactCurrentPrimaryRuleTextSha256':prep['sourceRuleTextsSha256'],'currentCoreSha256':'d6fd7140f106f9b5b3dc0d5817fd040110fe870a6da9ee335ba7f4f70f892d11','coreUrl':'https://cdn.playloltcg.com/lol/2026/10/2026-10-10/a21ead876c6b44d6abe386b6ae54ea28.pdf','coreSourceUpdatedDate':'2026-10-10','exactPerPrintingPublicationAndEffectiveDatesIndependentlyConfirmed':False,'sourceDatesNotInferredFromAcquisitionOrHttpDate':True,'all16KnownDocumentsAnd1504CompleteRowsQaReadBackUnchanged':True,'currentNocturneRuntimeTextExactNonNullApiErrataAndOriginsPdfPage6':True,'newSourceVersionOrRuntimeCatalogAdopted':False,'implementation':[pin(root/p,'implementation') for p in implementation_paths],'verificationSources':[pin(root/p,'verification-source') for p in verification_paths],'actualDebugAndSqlRuleInputs':sql['actualLoadedFourAssemblies']['actualRuleInputs'],'soleCheckCases':13497,'soleCheckMethods':7559,'newCases':48,'newMethods':9,'newSqlIdentity':60,'original59SqlObjectsAndOrderExact':True,'actualSqlInputsAndColdRecoveries':126,'actualIndependentSql':sql['totals'],'affectedOriginalFullGameMethodsPassed':4,'actualHeadlessNativeControlWindows':22,'nativeRawPacketsExactlyOriginalSqlIntentsNoNewLiveSubmissionClaim':True,'newFixedFullExpectedCases':13646,'newFixedFullExpectedMethods':7700,'newFixedFullActualCiPairScoreReplayVisibleAndPhysicalWindows':'OPEN','wholeScopeRetained':{'printings':1740,'ruleRecords':14293,'activeCatalog':1035,'outsideActive':705,'cnRawRows':1504,'enGap':8,'cnNews':139,'kdaExactPrintingGates':5},'allOldReviewsContextsGatesDeltasAndHistoricalFindingsRetained':True,'expectedRemainingObligations':17231,'archive':pin(archive),'archiveMap':pin(ev/'archive-map.json'),'semanticCoverageCertified':False}
write(ev/'source-manifest.json',source_manifest);sp=pin(ev/'source-manifest.json','source-manifest')
branches=[]
for case in prep['cases']:
 branches.append({'id':case['id'],'sourceRefs':case['exactPrintingSubjects']+prep['sourceRuleRecordIds'],'sourceManifest':sp,'state':'RECORDED','boundedCase':{'actualExecutedCase':case['actualExecutedCase'],'issue':'https://github.com/DDDHL0704/riftbound/issues/91'},'semanticReview':{'state':'BOUNDED_CN337_354_PENDING_BEFORE_PARENT_AND_LATER_OBSERVATION_INSERTION_ORDER'},'implementation':{'state':'FINITE_SHARED_PENDING_SLOTS_CAPTURED_PARENT_RESUME_AND_EXECUTION_ORDER_NO_DSL_OR_OLD_GAME_MIGRATION'},'testExecution':{'state':'ACTUAL48_NEW9_METHODS_SOLE13497_7559_FOUR_ORIGINAL_FULL_GAMES_SQL126_COLD126_AND22_NATIVE_PACKET_ORIGINAL_PREFIX_READBACK'},'fixedCommitCi':{'state':'PENDING_NEW_FIXED_FULL'},'productAcceptance':{'state':'OPEN_NEW_FIXED_CANDIDATE_NATIVE_PAIR_NORMAL_SCORE_COMPLETE_REPLAY_VISIBLE_AND_PHYSICAL_WINDOWS'},'decision':{'state':'OPEN','reason':'Bounded source and execution evidence only; fixed full and necessary products remain independent. No whole-card certification.'},'wholePrintingCertified':False,'existingAcceptanceGateDependencies':['FIXED_CURRENT_CANDIDATE_FULL','VISIBLE_PAIRED_SQL_NETWORK_SCORE_REPLAY','USER_WINDOWS_RUNTIME']})
write(ev/'forty-eight-exact-behavior-branches.json',{'branches':branches})
refreshed=[]
allowed=set(implementation_paths)|{'tests/Riftbound.ConformanceTests/FullGameEndToEndTests.cs'}
for name,c in m['reviewContexts'].items():
 changes=[]
 for ref in c['implementation']:
  actual=sha(root/ref['path'])
  if actual!=ref['sha256']:
   assert ref['path'] in allowed;changes.append({'path':ref['path'],'before':ref['sha256'],'after':actual});ref['sha256']=actual
 if changes:
  refreshed.append({'id':name,'changes':changes,'oldCompleteContext':old['reviewContexts'][name]})
  c.update(currentImplementationCommit=base,currentImplementationIncludesUncommittedChanges=True,ciState='PENDING',currentDeckPendingParentInputRefresh={'sourceManifest':sp,'onlyCurrentInputPinRefreshNotNewWholeSemanticCertification':True,'allOldEvidenceAndVerificationReferencesRetained':True,'newFixedFullAndProducts':'OPEN'})
assert len(refreshed)==64 and {v['id'] for v in refreshed}=={v['id'] for v in binding['changes']}
for name,c in m['reviewContexts'].items():
 assert c.get('verificationSources')==old['reviewContexts'][name].get('verificationSources') and ('verificationSources'in c)==('verificationSources'in old['reviewContexts'][name])
 if name not in {v['id'] for v in refreshed}:assert c==old['reviewContexts'][name]
(ev/'sixty-four-input-refreshes-complete-old-contexts.json.gz').write_bytes(gzip.compress(json.dumps(refreshed,ensure_ascii=False,indent=2).encode(),mtime=0))
m['reviewContexts'][identity]={'evidenceCommit':base,'currentImplementationCommit':base,'currentImplementationIncludesUncommittedChanges':True,'ciState':'PENDING','ciReceipts':[],'region':'CN','language':'zh-CN','applicableAsOf':'2026-10-22','adoptedCoreEffectiveDate':'2026-10-16','sourceManifest':sp,'implementation':source_manifest['implementation'],'verificationSources':source_manifest['verificationSources'],'branches':branches,'evidence':[pin(ev/n,role) for n,role in [('final-original-test-and-input-retention.json','focus-check-and-retention'),('independent-original-sql126-prefixes240-private-rows-and22-native-packets.json','independent-sql-original-history-and-native-packets'),('actual-native22-production-control-terminal-and-packets.json','headless-production-controls-not-visible')]]}
reviews['reviews'].append({'id':identity,'scope':source_manifest['scope'],'subjects':source_manifest['exactPrintings'],'ruleRecords':prep['sourceRuleRecordIds'],'status':'BOUNDED_CURRENT_CN_PENDING_BEFORE_PARENT_SOURCE_TEST_SQL_NATIVE_READBACK_PASS_NEW_FIXED_FULL_AND_PRODUCTS_OPEN','sourceManifest':sp,'auditDocument':document,'validation':{'newCases':48,'newMethods':9,'onlyCheckCases':13497,'onlyCheckMethods':7559,'onlyCheckOutcomes':{'Passed':13497},'affectedOriginalFullGameMethods':4,'sqlInputs':126,'sqlColdRecoveries':126,'independentAuthorityHistories':126,'independentPrivateSnapshots':240,'independentPrivatePrompts':240,'independentEvents':384,'actualCorruptRoomRefusals':4,'actualHeadlessNativeControlWindows':22,'wholePrintingCertified':False},'exclusions':['Wild Claw, its optional reflexive empowerment creation/confirmation and all unreviewed consumers remain OPEN.','Declared controlled positions and headless controls do not certify ordinary deck construction, visible paired windows, physical Windows or new fixed full.','All original1740 printings14293 rules705 outside-active8English139newsKDA5 and source gaps remain.','Original compilation, focus, fixture and first native-QA failures remain recorded; no original execution is relabeled.']})
assert reviews['reviews'][:165]==old_reviews['reviews'] and m['acceptanceGates']==old['acceptanceGates'] and m['laterSourceDeltas']==old['laterSourceDeltas'] and m['certificationScope']==old['certificationScope']
rp.write_text(json.dumps(reviews,ensure_ascii=False,indent=2)+'\n');m['inputs']['reviews']['sha256']=sha(rp)
m['currentDeckPendingParentInputChange']={'sourceManifest':sp,'auditDocument':document,'issue':'https://github.com/DDDHL0704/riftbound/issues/91','onlyNewBoundedBranches':48,'all165OldReviews80ContextIdentities252GatesSevenDeltasRetained':True,'all80CompleteOldContextsArchived64CurrentInputRefreshes16WholeObjectsExact':True,'allOldOptionalVerificationSourcePresenceAndValuesExact':True,'original17183RemainingIdsMustRemain':True,'expectedRemainingObligations':17231,'newFixedFullCurrentNativePairScoreReplayVisibleAndPhysicalWindows':'OPEN','wholePrintingOrGoalComplete':False}
m['precedingFixed68ba1ActualCompleteFullCiReadback']=pin(ev/'preceding-fixed68ba1-complete-full.json')
m['precedingFixed55fdbBoundedNativeMainNormalScoreNetworkLabAndOriginalReplay']=pin(ev/'preceding-fixed55-native-normal-score-network-lab-original-replay.json')
if current_full:m['precedingFixed55fdbActualCompleteFullCiReadback']=pin(ev/'preceding-fixed55-complete-full.json')
assert (len(reviews['reviews']),len(m['reviewContexts']),len(m['acceptanceGates']),len(m['laterSourceDeltas']))==(166,81,252,7)
mp.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
write(ev/'publication-original-governance-retention.json',{'atUtc':now(),'oldReviews':165,'oldContexts':80,'oldGates':252,'oldDeltas':7,'oldRemainingIds':17183,'newBehaviorBranches':48,'expectedRemainingObligations':17231,'completeOldContextsArchived':80,'explicitCurrentInputRefreshedContexts':64,'otherWholeContextObjectsExact':16,'allOriginalReviewsGatesDeltasCertificationScopeAndOptionalVerificationSourcePresenceValuesExact':True,'semanticCoverageCertified':False})
full_sentence='固定55fdb完整CI39748320406实际11项成功，独立13598/7691及59SQL。' if current_full else '固定55fdb完整CI39748320406仍待实际整次终态，已有子任务不代替完整通过。'
text='''# 牌堆效果待处理出牌与来源结算顺序的限定修复

本批CN/zh-CN、适用2026-10-22，核心10-16生效。精确四消费者、魔腾非空勘误、十三原文块和全部来源日期见[来源manifest](evidence/deck-pending-before-parent-current-cn16-2026-10-22/source-manifest.json)。官网14当前目录行、16份保留文档及1504完整API行/QA未换版。魔腾原卡面文字与运行目录不同，但其非空errata、现行《起源》勘误物理第6页和核心370.1.c.1均支持已采用文字，未把原卡面当成当前勘误。未新增来源版本或运行卡牌，狂野钩爪仍未注册。Goal active / NOT READY。

[#91](https://github.com/DDDHL0704/riftbound/issues/91)的原55fdb实现中，增援、虚空猛冲、暴怒冲动和光明未来重复执行时，第一轮已被要求打出的牌仍留在放逐区，第二轮查看提示已经出现。四个新反例均在缺少待处理项目的断言失败；光明未来先完成每名玩家放逐/回收选择的对照通过。现行354要求先进入待处理结算链，再完成仍在结算的来源，337要求按加入顺序确认、常驻牌确认后立即结算，确认不让过优先权。

共享流程现在在实际打出指示时建立真正的待处理项目：增援等在回收/抽取余牌前建立，光明未来在全部选择和回收之后按原对手优先顺序建立。后续重复执行保留先前项目，选择使用捕获的来源项目身份继续结算，不依赖最后一个堆栈元素。来源完成后才确认牌；无法支付的返回放逐区，原费用、目标、服务端权威与独立校验保留。第二轮魔腾观察权限也不能越过第一轮待处理牌，公共堆栈与实际确认顺序一致。同轮观察权限仍在原打出指示之前。

新48例/9方法，包括拒绝伪造来源/队列/代数/控制者/位置/顺序、双方提前出牌或让过、两轮选择的放弃及魔腾支付/放弃。定向164/69通过，四条受影响原完整胜利/回放通过；新增六场景最初把已记录tick1状态交给从tick0起计的独立驱动而失败，随后直接保留原session及原设置输入，最终48/9全过。所有原失败TRX/日志保留，没有回填通过。全1804原Conformance文件中1803份逐字不变，只校准FullGame隐藏信息预期中精确捕获来源的定位；原断言、方法、Theory、九完整源码方法集合、143完整方法/151例/110配对/十一牌组/424242及胜利与回放保留。

唯一check13497/7559全过零跳过，原13449用例多重集合完整加48，发现7700方法；3350源/模式、1419Conformance与22实际原生Debug文件全程稳定，四实际加载路径/SHA/MVID和输入身份精确。旧23文件预检仅因当前少GodotSharpEditor.dll失败，尚未创建测试输出或启动test-rules；记录实际22文件后才启动本批唯一check，未补回无用编辑器依赖，不推定缺失原因。74工具测试通过。check不代表本机执行了全部143完整对局。

真实SQL仅追加第60身份，原59对象/顺序完整。十二新房从两条原子入座、原EMPTY和真实私有种子开始，六种显式受控场景、126输入/126冷恢复，四个独立房间故意损坏当前状态与投影后实际冷拒绝；损坏房保留，不修复成通过。独立只读读者核对全部七表、126历史、240私有快照、240提示、384事件及每条原始前缀；原字段/null/省略、原种子和日志保持。原345审计88原生七表不变；新增后357审计88原生七表在独立回读中原样，专用库正常停止。

实际Godot实例对22个原SQL提示窗口触发生产选择/确认按钮，拒绝前轮待处理牌、未观察尾牌、未完成必选、网络处理中重复和过期窗口。首轮测试误把唯一必选项的合法自动选择当成不完整，原失败源码与实际自有程序集保留；只校准该测试前提，产品控件未改。最终22窗口退出0且无Godot错误；输出全部六个原始字段与原SQL意图完全一致，再由冻结当前后端从原始前缀逐条回放。这是无窗口控件与回读，未冒称新的线上提交、可见窗口或Windows实机。

前68ba1完整CI39729791774实际11项成功，独立13598/7691、59SQL；原13585/7684精确加13/7，143完整/151例、110配对/11牌组/424242和原15网络拒绝零泄露及双端无刷新到tick2完整。'''+full_sentence+'''

固定55fdb实际CI默认Main普通局冷恢复后两端连接中SIGTERM正常，原局正常8:0共74输入417事件、独立74历史143快照143提示与完整回放；两网络局3输入3事件及独立3/4/4；实验室三次同进程冷恢复、支付7/24和独立7/13/13通过。这些是前固定候选的限定实证，不覆盖本批新规则输入或可见/Windows。锁状态依原件记录，不声称全程实际锁定；后台工作不要求解锁。

原165审查、80完整上下文、252门禁、七增量和17183义务完整。64当前输入绑定显式刷新待新full，其中一项原将FullGame验证源码列为implementation；其余16整对象与全部旧可选验证引用存在性和值原样。只新增48限定行为至17231、166审查81上下文，semanticCoverageCertified=false；1740印次14293条款、705目录外、八英文、139新闻与K/DA五精确门禁不减。只保留最新可用A/B、每平台一包、各一份SDK/模板；自有执行源码/程序集小归档，依赖和安装包不复制，原数据库及有意义失败保留。

新固定full预期13646/7700、60SQL；当前固定CI包、双端重连、正常得分与全原始回放、可见控件/双窗及Windows实机分别OPEN。狂野钩爪的可选内嵌强化创建/确认、其他尚未语义闭合消费者和全部来源缺口继续处理。局部通过不替代全量完成，Goal保持active。
'''
(root/document).write_text(text)
status_path=root/'docs/PROJECT_STATUS.md';old_status=gzip.decompress((prior/'PROJECT_STATUS.md.gz').read_bytes()).decode();heading='# 当前项目状态\n\n';assert old_status.startswith(heading)
status='2026-10-22 本批：[牌堆效果待处理出牌与来源顺序](DECK_PENDING_BEFORE_PARENT_CURRENT_CN16_AUDIT_2026-10-22.md)。四原Echo缺待处理反例失败后，实际打出指示即建立项目，来源继续/完成后按加入顺序确认；第二轮魔腾不能越过第一轮项目。当前16文档1504完整行/QA未换版，魔腾非空勘误及当前PDF优先，狂野钩爪未注册。48/9、定向164/69、四原完整胜利/回放、74工具和唯一check13497/7559通过；原13449全留，3350/1419/22稳定。原1804文件只改一处隐藏信息来源定位，全部方法/Theory/143完整151例110配对11牌组424242与断言保留。\n\nSQL原59身份只加60，十二原局126输入126冷，独立126历史240快照240提示384事件及四实际拒绝；22生产Godot控件输出完整六字段等于原SQL意图并逐前缀回放。原345审计88原生七表不变，现357/88独立只读全原，库停止。首次编译/定向/场景驱动/原生QA与预检失败留原件，无第二check。前68完整13598/7691/59独立全11成功；'+full_sentence+'固定55普通74/417正常8:0/独立74/143/143、网络3/4/4、Lab7/24三冷及独立7/13/13限定保留，不覆盖新规则或可见/Windows。\n\n原165审查80上下文252门禁7增量17183义务全留，64绑定显式待新full、16整对象和全部旧可选验证引用原样；加48至17231、166审查81上下文，语义false，全1740/14293/705/八英文/139新闻/KDA五门禁保留。仅最新A/B及每平台一包，SDK/模板各一份。新固定full预期13646/7700和60SQL、当前产品与全量Goal OPEN / NOT READY。\n\n以下原批按原范围与当时终态保留。\n\n'
status_path.write_text(heading+status+old_status[len(heading):])
print('PUBLISHED bounded48/9;166reviews81contexts252gates7deltas;17183oldIDs+48 expected17231;64pins16wholecontexts; independentgovernance pending',flush=True)
