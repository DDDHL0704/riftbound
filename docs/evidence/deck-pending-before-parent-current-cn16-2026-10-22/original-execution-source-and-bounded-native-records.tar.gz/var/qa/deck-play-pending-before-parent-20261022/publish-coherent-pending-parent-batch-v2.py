# -*- coding: utf-8 -*-
from pathlib import Path
import copy,datetime,gzip,hashlib,io,json,re,subprocess,tarfile
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
native=root/'var/qa/fixed55fdb-early-native-20261022';fresh=root/'var/qa/wild-claw-current-cn16-20261022';base='55fdbabf8731fec795c26584985bd31cc0bcca32'
load=lambda p:json.loads(p.read_text());now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def pin(p,role=None):
 v={'path':str(p.relative_to(root)),'sha256':sha(p)}
 if role:v['role']=role
 return v
def write(p,v):
 with p.open('x') as f:json.dump(v,f,ensure_ascii=False,indent=2)
current=w/'post-check-corrected-candidate-v1'
check=load(w/'sole-check-owner-terminal-v1.json')
assert check['status']=='FAILED_SOLE_PENDING_PARENT_CHECK_ORIGINALS_RETAINED' and check['exitCode']==1
assert check['all3350SourcesAndModesStable'] and check['all1419ConformanceAnd22NativeRuntimeInputsStable']
retained=load(w/'final-after-sole-check-corrections-original-retention-v2.json')
assert retained['actualOutcomes']=={'Passed':13496,'Failed':1} and retained['newCases']==51 and retained['newMethods']==10
assert retained['finalFocusedCases']==280 and retained['affectedOriginalFullGameMethodsPassed']==5 and retained['allThreeIndependentMalformedOriginalExceptionsNowExplicitRecoveryErrors']
final_inputs=json.loads(gzip.decompress((w/'final-four-corrections-source-inputs-v1.json.gz').read_bytes()))
assert len(final_inputs['all3350CurrentSourceHashesAndModes'])==3350
for p,v in final_inputs['all3350CurrentSourceHashesAndModes'].items():
 assert sha(root/p)==v['sha256'] and oct((root/p).stat().st_mode&0o777)==v['mode']
assert len(final_inputs['exactFourChangedSinceOriginalSoleCheck'])==4
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==base
sql=load(current/'independent-sql60-original-result-v1.json')
assert sql['totals']=={'commands':126,'events':384,'authority':126,'snapshots':240,'prompts':240,'native':22,'originalPrefixReplays':126,'actualCorruptRoomRefusals':4}
sql_owner=load(current/'independent-sql60-owner-terminal-v1.json')
assert sql_owner['ownPostgresSmartStopped'] and sql_owner['all369AuditSevenTablesExact'] and sql_owner['all88NativeSevenTablesExact'] and sql_owner['all89FrozenRuntimeHashesStable']
assert sql_owner['actualLoadedFourAssemblies']['actualRuleInputs']==retained['actualFourLoadedAssembliesAndRuleInputs']['actualRuleInputs']
native22=load(current/'native-actual-sql-choice-controls-v2/actual-native-production-control-terminal-and-packets-v1.json')
assert native22['actualExitCode']==0 and len(native22['packets'])==22 and native22['independentFrozenBackendAllOriginal126PrefixReplayActualPass']
assert native22['actualBackendRuleInputs']==sql['actualLoadedFourAssemblies']['actualRuleInputs']
prep=load(w/'fifty-one-exact-pending-parent-branches-and-current-rule-preparation-v3.json')
assert len(prep['cases'])==51 and len(prep['newMethods'])==10 and len(prep['sourceRuleRecordIds'])==13
assert next(c for c in prep['cases'] if '.BrightFutureFinishesAllBanish' in c['actualExecutedCase'])['exactPrintingSubjects']==['OGN-115/298']
previous_full=root/'var/qa/fixed68ba1-early-native-20261022/ci68ba1-entire-full-independent-verification-v1.json';old_full=load(previous_full)
assert (old_full['actualCases'],old_full['actualMethods'],old_full['sql']['caseCount'])==(13598,7691,59) and len(old_full['jobs'])==11 and all(v=='success' for v in old_full['jobs'].values())
previous_native=native/'fixed55fdb-current-native-normal-score-network-paid-lab-and-original-replay-closure-v2.json';assert previous_native.exists()
current_full_path=native/'ci55fdb-entire-full-independent-verification-v1.json';current_full=load(current_full_path) if current_full_path.exists() else None
if current_full:assert (current_full['actualCases'],current_full['actualMethods'],current_full['sql']['caseCount'])==(13598,7691,59) and len(current_full['jobs'])==11 and all(v=='success' for v in current_full['jobs'].values())
mp=root/'docs/audit/current-manifest.json';m=load(mp);old=copy.deepcopy(m);rp=root/m['inputs']['reviews']['path'];reviews=load(rp);old_reviews=copy.deepcopy(reviews)
binding=load(w/'current-existing-context-input-pin-change-before-publication-v2.json');assert sha(mp)==binding['currentManifestSha256']
assert (len(reviews['reviews']),len(m['reviewContexts']),len(m['acceptanceGates']),len(m['laterSourceDeltas']))==(165,80,252,7)
assert json.loads(gzip.decompress((w/'all-original80-contexts-before-pending-parent-refresh-v1.json.gz').read_bytes()))==m['reviewContexts']
prior=w/'prior-coherent-publication-v2';prior.mkdir()
for p in [mp,rp,root/'docs/PROJECT_STATUS.md']:(prior/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
identity='deck-pending-before-parent-current-cn16-2026-10-22';document='docs/DECK_PENDING_BEFORE_PARENT_CURRENT_CN16_AUDIT_2026-10-22.md';ev=root/'docs/evidence/deck-pending-before-parent-current-cn16-2026-10-22';ev.mkdir()
runtime_roots=[Path(load(w/'current-rule-sql60-frozen-inputs-v1.json')['runtimeRoot']),Path(load(current/'current-rule-sql60-frozen-inputs-v1.json')['runtimeRoot'])]
np=load(native/'frozen-fixed55fdb-native-composition-v1.json');runtime_roots.extend(Path(np[k]) for k in ['apiRuntimeRoot','helperRuntimeRoot','networkRuntimeRoot'])
paths={p for folder in [w,native] for p in folder.rglob('*') if p.is_file()}
paths.update([previous_full,fresh/'current-cn-rule-directory-and-known-source-versions-v1.json',fresh/'current-complete-cn-full-row-and-qa-readback-v1.json',fresh/'current-complete-cn-original-pages-v1.jsonl.gz'])
def generated(p):return any(p.is_relative_to(folder) for folder in runtime_roots) or any(x in {'bin','obj','__pycache__','native-current','.godot'} or x.endswith('.app') for x in p.parts)
secrets=set()
def collect(v):
 if isinstance(v,dict):
  for k,a in v.items():
   if k.lower() in {'playerkey','reconnecttoken'} and isinstance(a,str) and len(a)>=16:secrets.add(a.encode())
   else:collect(a)
 elif isinstance(v,list):
  for a in v:collect(a)
for p in paths:
 if generated(p):continue
 if p.name.endswith(('.json','.json.gz','.ndjson','.ndjson.gz')):
  try:
   raw=p.read_bytes();raw=gzip.decompress(raw) if p.suffix=='.gz' else raw
   if '.ndjson' in p.name:
    for line in raw.decode().splitlines():
     if line.strip():collect(json.loads(line))
   else:collect(json.loads(raw))
  except (ValueError,OSError,UnicodeDecodeError):pass
canonical={};members={};rows=[];excluded=[]
for p in sorted(paths):
 name=str(p.relative_to(root));reason=None
 if generated(p):reason='EXISTING_FROZEN_RUNTIME_APP_DEPENDENCY_OR_GENERATED_BUILD_NOT_DUPLICATED'
 elif p.suffix=='.zip':reason='SINGLE_ORIGINAL_BACKEND_ZIP_RETAINED_LOCALLY_HASH_PINNED_NO_SECOND_COPY'
 elif p.name.endswith(('.html','.html.gz')):reason='PRIMARY_FULL_HTML_LOCAL_ONLY_HASH_METADATA_RETAINED'
 elif p.suffix=='.env' or any('profile' in x.lower() for x in p.parts) or p.name.startswith('session-'):reason='PRIVATE_QA_SESSION_LOCAL_ONLY'
 if reason:
  excluded.append({'path':name,'bytes':p.stat().st_size,'sha256':sha(p),'reason':reason});continue
 raw=p.read_bytes();inspect=raw
 if p.suffix=='.gz':
  try:inspect=gzip.decompress(raw)
  except OSError:pass
 digest=hashlib.sha256(raw).hexdigest()
 if any(s in inspect for s in secrets):excluded.append({'path':name,'bytes':len(raw),'sha256':digest,'reason':'PRIVATE_SESSION_AUTH_VALUE_LOCAL_ONLY'});continue
 member=canonical.get(digest)
 if member is None:canonical[digest]=name;member=name;members[name]=p
 rows.append({'path':name,'bytes':len(raw),'sha256':digest,'archiveMember':member})
archive=ev/'original-execution-source-and-bounded-native-records.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as t:
 for name,p in sorted(members.items()):
  raw=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(raw);info.mode=p.stat().st_mode&0o777;info.mtime=0;t.addfile(info,io.BytesIO(raw))
with tarfile.open(archive,'r:gz') as t:
 assert set(t.getnames())==set(members)
 for row in rows:
  raw=t.extractfile(row['archiveMember']).read();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
write(ev/'archive-map.json',{'atUtc':now(),'archive':pin(archive),'originalPathsWithExactCanonicalMember':rows,'localOnlyExclusions':excluded,'allMemberBytesHashesAndClosedSetVerified':True,'equalPayloadsStoredOnlyOnce':True,'noInstallerAppSdkDependencyProfileOrFullHtmlCopies':True})
copies={
 'final-original-test-and-input-retention.json':w/'final-after-sole-check-corrections-original-retention-v2.json',
 'sole-check-original-owner-terminal.json':w/'sole-check-owner-terminal-v1.json',
 'exact-four-post-check-corrections.json':w/'post-sole-check-four-exact-correction-paths-v1.json',
 'final3350-source-hashes-and-modes.json.gz':w/'final-four-corrections-source-inputs-v1.json.gz',
 'malformed-context-original-exceptions.json':w/'independent-observed-malformed-context-review-v1.json',
 'malformed-context-current-proper-refusals.json':current/'independent-observed-malformed-context-review-v2.json',
 'malformed-context-red-to-current-green-disposition.json':current/'independent-malformed-context-red-to-current-green-disposition-v1.json',
 'current-exact-four-consumer-official-full-rows.json':w/'exact-four-current-official-consumer-full-rows-v1.json',
 'current-nocturne-full-api-nonnull-errata-and-visual-authority.json':w/'exact-current-nocturne-static-observation-consumer-v1.json',
 'current-cn16-all-sixteen-source-version-readback.json':fresh/'current-cn-rule-directory-and-known-source-versions-v1.json',
 'current-cn1504-complete-full-row-and-qa-readback.json':fresh/'current-complete-cn-full-row-and-qa-readback-v1.json',
 'exact-rule-pages-visual-readback.json':w/'cn337-354-page-visual-disposition-v1.json',
 'fifty-one-exact-behavior-branch-preparation.json':w/'fifty-one-exact-pending-parent-branches-and-current-rule-preparation-v3.json',
 'real-sql-original-writer-twelve-rooms.json':current/'real-sql60-owner-terminal-v1.json',
 'independent-original-sql126-prefixes240-private-rows-and22-native-packets.json':current/'independent-sql60-original-result-v1.json',
 'independent-sql-owner-all369-and88-seven-tables-exact.json':current/'independent-sql60-owner-terminal-v1.json',
 'actual-native22-production-control-terminal-and-packets.json':current/'native-actual-sql-choice-controls-v2/actual-native-production-control-terminal-and-packets-v1.json',
 'original80-complete-contexts-before-refresh.json.gz':w/'all-original80-contexts-before-pending-parent-refresh-v1.json.gz',
 'preceding-fixed68ba1-complete-full.json':previous_full,
 'preceding-fixed55-native-normal-score-network-lab-original-replay.json':previous_native}
if current_full:copies['preceding-fixed55-complete-full.json']=current_full_path
for name,p in copies.items():(ev/name).write_bytes(p.read_bytes())
implementation_paths=['src/Riftbound.Engine/CoreRuleEngine.DeckPlaySequence.cs','src/Riftbound.Engine/CoreRuleEngine.DeckObservation.cs','src/Riftbound.Engine/CoreRuleEngine.EffectPlay.cs','src/Riftbound.Engine/CoreRuleEngine.cs','src/Riftbound.Engine/MatchRecovery.cs','src/Riftbound.Engine/MatchSession.cs','src/Riftbound.Engine/MatchSession.DeckPendingScenario.cs']
verification_paths=['tests/Riftbound.ConformanceTests/DeckPlayPendingBeforeParentTests.cs','tests/Riftbound.ConformanceTests/DeckPlayPendingScenarioTests.cs','tests/Riftbound.ConformanceTests/DeckPlaySequenceTests.cs','tests/Riftbound.ConformanceTests/SingleDeckPlaySequenceTests.cs','tests/Riftbound.ConformanceTests/DeckPlayObservationOrderTests.cs','tests/Riftbound.ConformanceTests/FullGameEndToEndTests.cs','tests/Riftbound.ConformanceTests/Fixtures/p2-preflight-play-berserk-impulse-play-opponent-top-unit.fixture.json','tests/Riftbound.PostgresAcceptance/DeckPendingParentSqlAcceptance.cs','tests/Riftbound.PostgresAcceptance/Program.cs','tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json','scripts/tests/test_sql_ci_gate.py','clients/godot/scripts/debug/DeckPendingParentInteractionProof.cs','clients/godot/scenes/debug/DeckPendingParentInteractionProof.tscn']
source_manifest={'schemaVersion':1,'id':identity,'atUtc':now(),'region':'CN','language':'zh-CN','applicableAsOf':'2026-10-22','adoptedCoreEffectiveDate':'2026-10-16','baseCommit':base,'issue':'https://github.com/DDDHL0704/riftbound/issues/91','scope':'Current two-seat instructed deck plays enter real pending stack slots before the resolving parent continues. Preserve parent completion, insertion-order confirmation, optional decline, private observation, repeats and later observed permissions. Only these bounded branches are reviewed; Wild Claw is not registered.','exactPrintings':['OGN-025/298','OGN-062/298','OGN-115/298','SFD-188/221','OGN-194/298'],'sourceRuleRecords':prep['sourceRuleRecordIds'],'exactCurrentPrimaryRuleTextSha256':prep['sourceRuleTextsSha256'],'currentCoreSha256':'d6fd7140f106f9b5b3dc0d5817fd040110fe870a6da9ee335ba7f4f70f892d11','coreUrl':'https://cdn.playloltcg.com/lol/2026/10/2026-10-10/a21ead876c6b44d6abe386b6ae54ea28.pdf','coreSourceUpdatedDate':'2026-10-10','exactPerPrintingPublicationAndEffectiveDatesIndependentlyConfirmed':False,'sourceDatesNotInferredFromAcquisitionOrHttpDate':True,'all16KnownDocumentsAnd1504CompleteRowsQaReadBackUnchanged':True,'currentNocturneRuntimeTextExactNonNullApiErrataAndOriginsPdfPage6':True,'newSourceVersionOrRuntimeCatalogAdopted':False,'implementation':[pin(root/p,'implementation') for p in implementation_paths],'verificationSources':[pin(root/p,'verification-source') for p in verification_paths],'actualDebugAndSqlRuleInputs':sql['actualLoadedFourAssemblies']['actualRuleInputs'],'soleCheckCases':13497,'soleCheckMethods':7559,'soleCheckOutcomes':{'Passed':13496,'Failed':1},'soleCheckBeforeFinalFourCorrectionsNotCurrentGreen':True,'finalFocusedCases':280,'finalFocusedMethods':126,'exactFourPostCheckCorrectionPaths':final_inputs['exactFourChangedSinceOriginalSoleCheck'],'newCases':51,'newMethods':10,'newSqlIdentity':60,'original59SqlObjectsAndOrderExact':True,'actualSqlInputsAndColdRecoveries':126,'actualIndependentSql':sql['totals'],'affectedOriginalFullGameMethodsPassed':5,'actualHeadlessNativeControlWindows':22,'nativeRawPacketsExactlyOriginalSqlIntentsNoNewLiveSubmissionClaim':True,'newFixedFullExpectedCases':13649,'newFixedFullExpectedMethods':7701,'newFixedFullActualCiPairScoreReplayVisibleAndPhysicalWindows':'OPEN','wholeScopeRetained':{'printings':1740,'ruleRecords':14293,'activeCatalog':1035,'outsideActive':705,'cnRawRows':1504,'enGap':8,'cnNews':139,'kdaExactPrintingGates':5},'allOldReviewsContextsGatesDeltasAndHistoricalFindingsRetained':True,'expectedRemainingObligations':17234,'archive':pin(archive),'archiveMap':pin(ev/'archive-map.json'),'semanticCoverageCertified':False}
write(ev/'source-manifest.json',source_manifest);sp=pin(ev/'source-manifest.json','source-manifest')
branches=[]
for case in prep['cases']:
 branches.append({'id':case['id'],'sourceRefs':case['exactPrintingSubjects']+prep['sourceRuleRecordIds'],'sourceManifest':sp,'state':'RECORDED','boundedCase':{'actualExecutedCase':case['actualExecutedCase'],'issue':'https://github.com/DDDHL0704/riftbound/issues/91'},'semanticReview':{'state':'BOUNDED_CN337_354_PENDING_BEFORE_PARENT_AND_LATER_OBSERVATION_INSERTION_ORDER'},'implementation':{'state':'FINITE_SHARED_PENDING_SLOTS_CAPTURED_PARENT_RESUME_AND_EXECUTION_ORDER_NO_DSL_OR_OLD_GAME_MIGRATION'},'testExecution':{'state':'ACTUAL_FINAL51_NEW10_METHODS_FOCUS280_126_FIVE_ORIGINAL_FULL_GAMES_FRESH_SQL126_COLD126_NATIVE22_ORIGINAL_PREFIX_READBACK_ORIGINAL_SOLE_CHECK13496_PASS_ONE_FAILURE_RETAINED'},'fixedCommitCi':{'state':'PENDING_NEW_FIXED_FULL'},'productAcceptance':{'state':'OPEN_NEW_FIXED_CANDIDATE_NATIVE_PAIR_NORMAL_SCORE_COMPLETE_REPLAY_VISIBLE_AND_PHYSICAL_WINDOWS'},'decision':{'state':'OPEN','reason':'Bounded source and execution evidence only; fixed full and necessary products remain independent. No whole-card certification.'},'wholePrintingCertified':False,'existingAcceptanceGateDependencies':['FIXED_CURRENT_CANDIDATE_FULL','VISIBLE_PAIRED_SQL_NETWORK_SCORE_REPLAY','USER_WINDOWS_RUNTIME']})
write(ev/'fifty-one-exact-behavior-branches.json',{'branches':branches})
refreshed=[]
allowed=set(implementation_paths)|{'tests/Riftbound.ConformanceTests/FullGameEndToEndTests.cs'}
for name,c in m['reviewContexts'].items():
 changes=[]
 for ref in c['implementation']:
  actual=sha(root/ref['path'])
  if actual!=ref['sha256']:
   assert ref['path'] in allowed;changes.append({'path':ref['path'],'before':ref['sha256'],'after':actual});ref['sha256']=actual
 if changes:
  refreshed.append({'id':name,'changes':changes,'oldCompleteContext':old['reviewContexts'][name]})
  c.update(currentImplementationCommit=base,currentImplementationIncludesUncommittedChanges=True,ciState='PENDING',currentDeckPendingParentInputRefresh={'sourceManifest':sp,'onlyCurrentInputPinRefreshNotNewWholeSemanticCertification':True,'allOldEvidenceAndVerificationReferencesRetained':True,'newFixedFullAndProducts':'OPEN'})
assert len(refreshed)==64 and {v['id'] for v in refreshed}=={v['id'] for v in binding['changes']}
for name,c in m['reviewContexts'].items():
 assert c.get('verificationSources')==old['reviewContexts'][name].get('verificationSources') and ('verificationSources'in c)==('verificationSources'in old['reviewContexts'][name])
 if name not in {v['id'] for v in refreshed}:assert c==old['reviewContexts'][name]
(ev/'sixty-four-input-refreshes-complete-old-contexts.json.gz').write_bytes(gzip.compress(json.dumps(refreshed,ensure_ascii=False,indent=2).encode(),mtime=0))
m['reviewContexts'][identity]={'evidenceCommit':base,'currentImplementationCommit':base,'currentImplementationIncludesUncommittedChanges':True,'ciState':'PENDING','ciReceipts':[],'region':'CN','language':'zh-CN','applicableAsOf':'2026-10-22','adoptedCoreEffectiveDate':'2026-10-16','sourceManifest':sp,'implementation':source_manifest['implementation'],'verificationSources':source_manifest['verificationSources'],'branches':branches,'evidence':[pin(ev/n,role) for n,role in [('final-original-test-and-input-retention.json','focus-check-and-retention'),('independent-original-sql126-prefixes240-private-rows-and22-native-packets.json','independent-sql-original-history-and-native-packets'),('actual-native22-production-control-terminal-and-packets.json','headless-production-controls-not-visible')]]}
reviews['reviews'].append({'id':identity,'scope':source_manifest['scope'],'subjects':source_manifest['exactPrintings'],'ruleRecords':prep['sourceRuleRecordIds'],'status':'BOUNDED_CURRENT_CN_PENDING_BEFORE_PARENT_SOURCE_TEST_SQL_NATIVE_READBACK_PASS_NEW_FIXED_FULL_AND_PRODUCTS_OPEN','sourceManifest':sp,'auditDocument':document,'validation':{'newCases':51,'newMethods':10,'onlyCheckCases':13497,'onlyCheckMethods':7559,'onlyCheckOutcomes':{'Passed':13496,'Failed':1},'originalCheckBeforeFourFinalCorrections':True,'finalFocusedCases':280,'finalFocusedMethods':126,'affectedOriginalFullGameMethods':5,'sqlInputs':126,'sqlColdRecoveries':126,'independentAuthorityHistories':126,'independentPrivateSnapshots':240,'independentPrivatePrompts':240,'independentEvents':384,'actualCorruptRoomRefusals':4,'actualHeadlessNativeControlWindows':22,'wholePrintingCertified':False},'exclusions':['Wild Claw, its optional reflexive empowerment creation/confirmation and all unreviewed consumers remain OPEN.','Declared controlled positions and headless controls do not certify ordinary deck construction, visible paired windows, physical Windows or new fixed full.','All original1740 printings14293 rules705 outside-active8English139newsKDA5 and source gaps remain.','Original compilation, focus, fixture and first native-QA failures remain recorded; no original execution is relabeled.']})
assert reviews['reviews'][:165]==old_reviews['reviews'] and m['acceptanceGates']==old['acceptanceGates'] and m['laterSourceDeltas']==old['laterSourceDeltas'] and m['certificationScope']==old['certificationScope']
rp.write_text(json.dumps(reviews,ensure_ascii=False,indent=2)+'\n');m['inputs']['reviews']['sha256']=sha(rp)
m['currentDeckPendingParentInputChange']={'sourceManifest':sp,'auditDocument':document,'issue':'https://github.com/DDDHL0704/riftbound/issues/91','onlyNewBoundedBranches':51,'all165OldReviews80ContextIdentities252GatesSevenDeltasRetained':True,'all80CompleteOldContextsArchived64CurrentInputRefreshes16WholeObjectsExact':True,'allOldOptionalVerificationSourcePresenceAndValuesExact':True,'original17183RemainingIdsMustRemain':True,'expectedRemainingObligations':17234,'newFixedFullCurrentNativePairScoreReplayVisibleAndPhysicalWindows':'OPEN','wholePrintingOrGoalComplete':False}
m['precedingFixed68ba1ActualCompleteFullCiReadback']=pin(ev/'preceding-fixed68ba1-complete-full.json')
m['precedingFixed55fdbBoundedNativeMainNormalScoreNetworkLabAndOriginalReplay']=pin(ev/'preceding-fixed55-native-normal-score-network-lab-original-replay.json')
if current_full:m['precedingFixed55fdbActualCompleteFullCiReadback']=pin(ev/'preceding-fixed55-complete-full.json')
assert (len(reviews['reviews']),len(m['reviewContexts']),len(m['acceptanceGates']),len(m['laterSourceDeltas']))==(166,81,252,7)
mp.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
write(ev/'publication-original-governance-retention.json',{'atUtc':now(),'oldReviews':165,'oldContexts':80,'oldGates':252,'oldDeltas':7,'oldRemainingIds':17183,'newBehaviorBranches':51,'expectedRemainingObligations':17234,'completeOldContextsArchived':80,'explicitCurrentInputRefreshedContexts':64,'otherWholeContextObjectsExact':16,'allOriginalReviewsGatesDeltasCertificationScopeAndOptionalVerificationSourcePresenceValuesExact':True,'semanticCoverageCertified':False})
full_sentence='固定55fdb完整CI39748320406实际11项成功，独立13598例/7691方法及59SQL。' if current_full else '固定55fdb完整CI39748320406仍待实际整次终态，已有子任务不代替完整通过。'
text=(w/'final-audit-prose-v2.md').read_text().replace('{{PRECEDING55_FULL}}',full_sentence)
assert '{{' not in text and '13,496通过、1失败' in text
(root/document).write_text(text)
status_path=root/'docs/PROJECT_STATUS.md';old_status=gzip.decompress((prior/'PROJECT_STATUS.md.gz').read_bytes()).decode();heading='# 当前项目状态\n\n';assert old_status.startswith(heading)
status=(w/'final-status-prose-v2.md').read_text().replace('{{PRECEDING55_FULL}}',full_sentence)
status_path.write_text(heading+status+old_status[len(heading):])
print('PUBLISHED final51/10; solecheck13496pass1failure retained;166reviews81contexts252gates7deltas;17183oldIDs+51expected17234;64pins16wholecontexts; independent governance pending',flush=True)
