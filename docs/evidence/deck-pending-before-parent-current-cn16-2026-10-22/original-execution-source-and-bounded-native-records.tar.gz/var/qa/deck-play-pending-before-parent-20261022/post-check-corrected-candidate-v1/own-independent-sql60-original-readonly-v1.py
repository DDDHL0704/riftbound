# -*- coding: utf-8 -*-
from pathlib import Path
import ast,datetime,fcntl,gzip,hashlib,json,os,plistlib,resource,socket,subprocess
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486');tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
source=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py';nodes=[n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),globals())
pub=load(w/'current-rule-sql60-frozen-inputs-v1.json');previous=load(w/'real-sql60-owner-terminal-v1.json');assert previous['status'].startswith('PASS_CURRENT_CANDIDATE_SQL60') and previous['ownPostgresSmartStopped']
r=Path(pub['runtimeRoot']);frozen=pub['runtimeFiles'];assert len(frozen)==89 and all(sha(r/p)==h for p,h in frozen.items())
own=w/'independent-sql60-originals-source-v1/bin/Release/net10.0/IndependentSql60OriginalsV1.dll';bits={str(p.relative_to(w)):sha(p) for p in [own,own.with_suffix('.pdb'),w/'independent-sql60-originals-source-v1/Program.cs',w/'independent-sql60-originals-source-v1/IndependentSql60OriginalsV1.csproj']}
args=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(r/'Riftbound.PostgresAcceptance.deps.json'),'--runtimeconfig',str(r/'Riftbound.PostgresAcceptance.runtimeconfig.json'),str(own)]
measurement=json.loads(subprocess.check_output(args+['--loaded-inputs'],cwd=r,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0')))
assert Path(measurement['baseDirectory'])==r and measurement['actualRuleInputs']==pub['actualRuleInputs'] and len(measurement['assemblies'])==4
for a in measurement['assemblies']:assert Path(a['path'])==r/(a['name']+'.dll') and a['sha256']==frozen[a['name']+'.dll'] and a['mvid']
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof={'status':'RUNNING_INDEPENDENT_SQL60_READONLY_ORIGINAL_ROWS_AND22_NATIVE_PACKETS','startedAtUtc':now(),'actualLoadedFourAssemblies':measurement,'ownReaderInputBits':bits,'frozenRuntimeReusedWithoutAnotherDependencyCopy':True,'lockAtStart':observe_lock(),'database':'riftbound_acceptance','noLiveWriterOrMatchAction':True};started=False;power=None;before_audit=before_native=audit=native=None
try:
 assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid;sock.mkdir(exist_ok=True)
 subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'independent-sql60-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 audit=rooms('riftbound_acceptance');native=rooms('riftbound_here_native');assert audit==previous['actualAuditRoomsAtStop'] and native==previous['actualNativeRoomsAtStop'] and len(audit)==369 and len(native)==88
 before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',native)
 output=w/'independent-sql60-original-result-v1.json';assert not output.exists();command=args+[str(w),str(output)];proof['actualCommand']=command
 with (w/'independent-sql60-original-v1.log').open('xb') as log:code=subprocess.run(command,cwd=r,env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit',DOTNET_DbgEnableMiniDump='0'),stdout=log,stderr=subprocess.STDOUT,timeout=180).returncode
 proof['actualExitCode']=code;assert code==0
 result=load(output);assert result['totals']['commands']==result['totals']['originalPrefixReplays']==126 and result['totals']['native']==22 and result['totals']['actualCorruptRoomRefusals']==4
 proof.update(status=result['status'],resultSha256=sha(output),allOriginal126PrefixesAnd22ExactNativePacketsIndependentlyReplayed=True,actualReadOnlyConnection=True)
except BaseException as e:
 proof.update(status='FAILED_INDEPENDENT_SQL60_ORIGINALS_RETAINED',errorType=type(e).__name__,error=str(e));raise
finally:
 if started:
  if before_audit is not None:
   proof['all369AuditSevenTablesExact']=digests('riftbound_acceptance',audit)==before_audit;proof['all88NativeSevenTablesExact']=digests('riftbound_here_native',native)==before_native
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None and power.poll() is None:power.terminate();power.wait(timeout=10)
 proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),all89FrozenRuntimeHashesStable=all(sha(r/p)==h for p,h in frozen.items()),allOwnReaderInputsStable=all(sha(w/p)==h for p,h in bits.items()))
 with (w/'independent-sql60-owner-terminal-v1.json').open('x') as f:json.dump(proof,f,indent=2)
 fcntl.flock(guard,fcntl.LOCK_UN)
assert proof['all369AuditSevenTablesExact'] and proof['all88NativeSevenTablesExact'] and proof['ownPostgresSmartStopped'] and proof['all89FrozenRuntimeHashesStable'] and proof['allOwnReaderInputsStable']
print(proof['status'],flush=True)
