# -*- coding: utf-8 -*-
from pathlib import Path
import collections,datetime,gzip,hashlib,json,re,subprocess,xml.etree.ElementTree as ET,zipfile
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
start=json.loads(gzip.decompress((w/'sole-check-start-inputs-v1.json.gz').read_bytes()));end=load(w/'sole-check-owner-terminal-v1.json')
assert end['status']=='PASS_SOLE_COHERENT_PENDING_PARENT_CHECK13497_CASES7559_METHODS' and end['exitCode']==0
assert end['all3350SourcesAndModesStable'] and end['all1419ConformanceAnd22NativeRuntimeInputsStable'] and end['startManifestSha256']==sha(w/'sole-check-start-inputs-v1.json.gz')
for p,v in start['all3350SourceHashesAndModes'].items():assert sha(root/p)==v['sha256'] and oct((root/p).stat().st_mode&0o777)==v['mode']
for group in start['actualRuntimeInputs'].values():assert all(sha(root/p)==h for p,h in group.items())
old=start['original1804ConformanceFiles'];changed={p for p,v in old.items() if sha(root/p)!=v['sha256']};assert len(old)==1804 and changed=={'tests/Riftbound.ConformanceTests/FullGameEndToEndTests.cs'}
path=next(iter(changed));before=subprocess.check_output(['git','show',start['baseCommit']+':'+path],cwd=root,text=True);after=(root/path).read_text()
expected=before.replace('else if (result.State.StackItems.LastOrDefault()?.DeckPlaySequence is { Kind: "OPPONENT_REVEAL_PLAY" or "SINGLE_PUBLIC_PLAY" } revealed',
 'else if (result.State.StackItems.SingleOrDefault(i => i.StackItemId == result.State.PendingCardChoice?.DeckContext?.StackItemId)\n                        is { DeckPlaySequence: { Kind: "OPPONENT_REVEAL_PLAY" or "SINGLE_PUBLIC_PLAY" } revealed } parent').replace('                        var parent = result.State.StackItems.Last();\n','')
assert after==expected and collections.Counter(re.findall(r'Assert\.[A-Za-z]+',before))==collections.Counter(re.findall(r'Assert\.[A-Za-z]+',after))
full_sources=[p for p in old if Path(p).name.startswith('FullGameEndToEndTests') and p.endswith('.cs')];assert len(full_sources)==9
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def trx(p):
 d=ET.parse(p);defs={t.get('id'):t.find('t:TestMethod',ns).attrib for t in d.findall('.//t:UnitTest',ns)};rows=d.findall('.//t:UnitTestResult',ns)
 return collections.Counter(t.get('testName') for t in rows),{defs[t.get('testId')]['className']+'.'+defs[t.get('testId')]['name'] for t in rows},collections.Counter(t.get('outcome') for t in rows)
old_trx=root/start['originalBaselineTrx'];assert sha(old_trx)==start['originalBaselineTrxSha256'];prior=trx(old_trx);actual=trx(w/'sole-check-v1/check/results.trx');new=trx(w/'final-new-scenarios-and-staging-focus-v8/focus/results.trx')
assert sum(prior[0].values())==13449 and len(prior[1])==7550 and prior[2]=={'Passed':13449}
assert sum(actual[0].values())==13497 and len(actual[1])==7559 and actual[2]=={'Passed':13497}
assert not(prior[0]-actual[0]) and prior[1]<=actual[1] and actual[0]-prior[0]==new[0] and actual[1]-prior[1]==new[1]
assert sum(new[0].values())==48 and len(new[1])==9 and new[2]=={'Passed':48}
discovered={line.strip().split('(',1)[0] for line in (w/'sole-check-v1/discovery.log').read_text().splitlines() if line.startswith('    ') and line.strip()}
assert len(discovered)==7700 and all(n.startswith('Riftbound.ConformanceTests.') for n in discovered)
full={n for n in discovered if '.FullGameEndToEndTests.' in n};assert len(full)==143
prior_full=load(root/'var/qa/fixed68ba1-early-native-20261022/ci68ba1-entire-full-independent-verification-v1.json');original_artifact=next(a for a in prior_full['artifacts'] if a['name']=='conformance-results');assert sha(Path(original_artifact['path']))==original_artifact['sha256']
old_full_methods=set();old_full_cases=0
with zipfile.ZipFile(original_artifact['path']) as z:
 for name in z.namelist():
  if not name.endswith('/results.trx'):continue
  d=ET.fromstring(z.read(name));defs={t.get('id'):t.find('t:TestMethod',ns).attrib for t in d.findall('.//t:UnitTest',ns)}
  for row in d.findall('.//t:UnitTestResult',ns):
   method=defs[row.get('testId')]['className']+'.'+defs[row.get('testId')]['name']
   if '.FullGameEndToEndTests.' in method:old_full_methods.add(method);old_full_cases+=1
assert full==old_full_methods and old_full_cases==151 and prior_full['matrix']['seed']==424242 and prior_full['matrix']['deckCount']==11 and prior_full['matrix']['pairCount']==110 and len(prior_full['matrix']['completed'])==110
earlier_focus=trx(w/'current-family-and-affected-original-games-focus-v7/focus/results.trx');early_full={m for m in earlier_focus[1] if '.FullGameEndToEndTests.' in m};assert len(early_full)==4
d=ET.parse(w/'current-family-and-affected-original-games-focus-v7/focus/results.trx');assert all(row.get('outcome')=='Passed' for row in d.findall('.//t:UnitTestResult',ns) if '.FullGameEndToEndTests.' in row.get('testName',''))
sql_manifest=load(root/'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json');before_sql=json.loads(subprocess.check_output(['git','show',start['baseCommit']+':tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'],cwd=root))
assert len(sql_manifest['cases'])==60 and sql_manifest['cases'][:59]==before_sql['cases'] and sql_manifest['cases'][59:]==[{'id':'deck-pending-parent','sourceType':'DeckPendingParentSqlAcceptance'}]
network='tests/Riftbound.NativeNetworkSmoke/Program.cs';assert (root/network).read_bytes()==subprocess.check_output(['git','show',start['baseCommit']+':'+network],cwd=root)
sql=load(w/'independent-sql60-original-result-v1.json');assert sql['totals']=={'commands':126,'events':384,'authority':126,'snapshots':240,'prompts':240,'native':22,'originalPrefixReplays':126,'actualCorruptRoomRefusals':4}
owner=load(w/'independent-sql60-owner-terminal-v1.json');assert owner['all357AuditSevenTablesExact'] and owner['all88NativeSevenTablesExact'] and owner['ownPostgresSmartStopped']
tool=load(w/'tooling-tests-original-final-chunk-v1.json');assert tool['exit_code']==0 and 'Ran 74 tests' in tool['output'] and tool['output'].rstrip().endswith('OK')
native=load(w/'native-actual-sql-choice-controls-v2/actual-native-production-control-terminal-and-packets-v1.json');assert native['actualExitCode']==0 and len(native['packets'])==22 and 'ERROR:' not in native['actualOutput']
result={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_ORIGINAL13449_CASES7550_METHODS_RETAINED_PLUS48_9_SOLE13497_7559_AND_CURRENT_SQL_NATIVE_ORIGINAL_HISTORY','baseCommit':start['baseCommit'],'actualCases':13497,'actualMethods':7559,'actualOutcomes':dict(actual[2]),'newCases':48,'newMethods':9,'allOriginalCaseNamesMultiplicityAndMethodsExactRetained':True,'all1803OtherOriginalConformanceFilesAndTheirTheoryRowsByteExact':True,'onlyOneOriginalFileExactActiveParentLookupCalibrationNoAssertionRemoved':path,'allNineFullSourcesMethodDeclarationsTheoryDataAndAssertionCallsRetained':True,'originalFullMethodNames':sorted(full),'originalFullMethods':143,'originalFullCases':151,'originalPairs':110,'originalDecks':11,'originalSeed':424242,'originalVictoryAndReplayAssertionsRetained':True,'affectedOriginalFullGameMethodsPassed':sorted(early_full),'doesNotClaimAll143FullGamesExecutedLocally':True,'all3350SourceHashesAndModesStable':True,'all1419Conformance22NativeActualRuntimeHashesStable':True,'actualFourLoadedAssembliesAndRuleInputs':start['actualFourLoadedAssembliesAndRuleInputs'],'original59SqlObjectsAndOrderRetainedOnly60Added':True,'originalNativeNetworkProgramAnd15RejectsAndPeerGuardsSourceByteExact':True,'actualSql':sql['totals'],'actualNativeControlPackets':22,'nativePacketsExactlyOriginalSqlRawNoNewLiveSubmissionClaim':True,'all357Audit88NativeSevenTablesExactAndOwnedPostgresStopped':True,'toolingTests':74,'originalFailuresNotRelabeled':True,'currentFixedFullVisibleNativePairWindowsAndWholeGoal':'OPEN','wholePrintingCertified':False,'checkTrxSha256':sha(w/'sole-check-v1/check/results.trx'),'startManifestSha256':sha(w/'sole-check-start-inputs-v1.json.gz')}
p=w/'final-original-test-and-input-retention-v1.json';assert not p.exists();p.write_text(json.dumps(result,indent=2))
print('PASS sole13497/7559; old13449/7550 exact+48/9;1803exact+onepreciselookup;143/151/110/11/424242 all retained;126/240/240/384 originals and22native;all357/88 seven tables exact; no wholecertification',flush=True)
