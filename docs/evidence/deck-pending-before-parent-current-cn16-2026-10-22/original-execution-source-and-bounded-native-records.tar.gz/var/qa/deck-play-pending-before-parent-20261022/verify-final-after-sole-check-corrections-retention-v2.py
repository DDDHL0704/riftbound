# -*- coding: utf-8 -*-
from pathlib import Path
import collections,datetime,gzip,hashlib,json,re,subprocess,xml.etree.ElementTree as ET,zipfile
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;current=w/'post-check-corrected-candidate-v1'
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
start=json.loads(gzip.decompress((w/'sole-check-start-inputs-v1.json.gz').read_bytes()));end=load(w/'sole-check-owner-terminal-v1.json')
assert end['status']=='FAILED_SOLE_PENDING_PARENT_CHECK_ORIGINALS_RETAINED' and end['exitCode']==1 and end['all3350SourcesAndModesStable'] and end['all1419ConformanceAnd22NativeRuntimeInputsStable']
final_inputs=json.loads(gzip.decompress((w/'final-four-corrections-source-inputs-v1.json.gz').read_bytes()));inputs=final_inputs['all3350CurrentSourceHashesAndModes'];assert len(inputs)==3350
for p,v in inputs.items():assert sha(root/p)==v['sha256'] and oct((root/p).stat().st_mode&0o777)==v['mode']
assert {p for p in inputs if inputs[p]!=start['all3350SourceHashesAndModes'][p]}==set(final_inputs['exactFourChangedSinceOriginalSoleCheck']) and len(final_inputs['exactFourChangedSinceOriginalSoleCheck'])==4
old=start['original1804ConformanceFiles'];fixture='tests/Riftbound.ConformanceTests/Fixtures/p2-preflight-play-berserk-impulse-play-opponent-top-unit.fixture.json';full_path='tests/Riftbound.ConformanceTests/FullGameEndToEndTests.cs'
assert len(old)==1804 and {p for p,v in old.items() if sha(root/p)!=v['sha256']}=={fixture,full_path}
before=subprocess.check_output(['git','show',start['baseCommit']+':'+full_path],cwd=root,text=True)
expected=before.replace('else if (result.State.StackItems.LastOrDefault()?.DeckPlaySequence is { Kind: "OPPONENT_REVEAL_PLAY" or "SINGLE_PUBLIC_PLAY" } revealed',
 'else if (result.State.StackItems.SingleOrDefault(i => i.StackItemId == result.State.PendingCardChoice?.DeckContext?.StackItemId)\n                        is { DeckPlaySequence: { Kind: "OPPONENT_REVEAL_PLAY" or "SINGLE_PUBLIC_PLAY" } revealed } parent').replace('                        var parent = result.State.StackItems.Last();\n','')
assert (root/full_path).read_text()==expected
before_fixture=json.loads(subprocess.check_output(['git','show',start['baseCommit']+':'+fixture],cwd=root));after_fixture=load(root/fixture);expected_fixture=json.loads(json.dumps(before_fixture))
for key in ['eventKinds','events']:
 a=expected_fixture['expected'][key];node=a.pop(11);a.insert(9,node)
 assert collections.Counter(json.dumps(v,sort_keys=True) for v in a)==collections.Counter(json.dumps(v,sort_keys=True) for v in before_fixture['expected'][key])
assert after_fixture==expected_fixture
full_sources=[p for p in old if Path(p).name.startswith('FullGameEndToEndTests') and p.endswith('.cs')];assert len(full_sources)==9
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def trx(p):
 d=ET.parse(p);defs={t.get('id'):t.find('t:TestMethod',ns).attrib for t in d.findall('.//t:UnitTest',ns)};rows=d.findall('.//t:UnitTestResult',ns)
 return rows,collections.Counter(t.get('testName') for t in rows),{defs[t.get('testId')]['className']+'.'+defs[t.get('testId')]['name'] for t in rows},collections.Counter(t.get('outcome') for t in rows)
prior=trx(root/start['originalBaselineTrx']);actual=trx(w/'sole-check-v1/check/results.trx');old_new=trx(w/'final-new-scenarios-and-staging-focus-v8/focus/results.trx');focus=trx(w/'post-sole-check-final-safety-and-fixture-focus-v10/focus/results.trx')
assert len(prior[0])==13449 and len(prior[2])==7550 and actual[3]=={'Passed':13496,'Failed':1} and len(actual[0])==13497 and len(actual[2])==7559
assert not(prior[1]-actual[1]) and prior[2]<=actual[2] and actual[1]-prior[1]==old_new[1]
failure='Riftbound.ConformanceTests.ConformanceFixtureRunnerTests.CoreRuleEnginePlaysBerserkImpulseOpponentTopUnit'
assert [r.get('testName') for r in actual[0] if r.get('outcome')=='Failed']==[failure]
assert len(focus[0])==280 and len(focus[2])==126 and focus[3]=={'Passed':280} and focus[1][failure]==1
new_rows=[r for r in focus[0] if '.DeckPlayPendingBeforeParentTests.'in r.get('testName','') or '.DeckPlayPendingScenarioTests.'in r.get('testName','')];new_names=collections.Counter(r.get('testName') for r in new_rows)
assert len(new_rows)==51 and not(old_new[1]-new_names) and sum((new_names-old_new[1]).values())==3
discovered={line.strip().split('(',1)[0] for line in (w/'post-sole-check-final-safety-and-fixture-focus-v10/discovery.log').read_text().splitlines() if line.startswith('    ') and line.strip()};assert len(discovered)==7701
full={n for n in discovered if '.FullGameEndToEndTests.'in n};assert len(full)==143
ci=load(root/'var/qa/fixed68ba1-early-native-20261022/ci68ba1-entire-full-independent-verification-v1.json');a=next(v for v in ci['artifacts'] if v['name']=='conformance-results');assert sha(Path(a['path']))==a['sha256'];old_full=set();old_full_cases=0
with zipfile.ZipFile(a['path']) as z:
 for name in z.namelist():
  if not name.endswith('/results.trx'):continue
  d=ET.fromstring(z.read(name));defs={t.get('id'):t.find('t:TestMethod',ns).attrib for t in d.findall('.//t:UnitTest',ns)}
  for row in d.findall('.//t:UnitTestResult',ns):
   method=defs[row.get('testId')]['className']+'.'+defs[row.get('testId')]['name']
   if '.FullGameEndToEndTests.'in method:old_full.add(method);old_full_cases+=1
assert full==old_full and old_full_cases==151 and ci['matrix']['seed']==424242 and ci['matrix']['deckCount']==11 and ci['matrix']['pairCount']==len(ci['matrix']['completed'])==110
games=trx(w/'final-corrected-five-original-full-games-focus-v11/focus/results.trx');assert len(games[0])==len(games[2])==5 and games[3]=={'Passed':5}
manifest=load(root/'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json');old_manifest=json.loads(subprocess.check_output(['git','show',start['baseCommit']+':tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'],cwd=root));assert len(manifest['cases'])==60 and manifest['cases'][:59]==old_manifest['cases']
network='tests/Riftbound.NativeNetworkSmoke/Program.cs';assert (root/network).read_bytes()==subprocess.check_output(['git','show',start['baseCommit']+':'+network],cwd=root)
sql=load(current/'independent-sql60-original-result-v1.json');assert sql['totals']=={'commands':126,'events':384,'authority':126,'snapshots':240,'prompts':240,'native':22,'originalPrefixReplays':126,'actualCorruptRoomRefusals':4}
sql_owner=load(current/'independent-sql60-owner-terminal-v1.json');assert sql_owner['all369AuditSevenTablesExact'] and sql_owner['all88NativeSevenTablesExact'] and sql_owner['ownPostgresSmartStopped'] and sql_owner['all89FrozenRuntimeHashesStable']
malformed=load(current/'independent-observed-malformed-context-review-v2.json');assert len(malformed)==3 and all(not r['threw'] and any('invalid observed deck play permission'in e for e in r['errors']) for r in malformed)
tool=load(w/'tooling-tests-original-final-chunk-v1.json');assert tool['exit_code']==0 and 'Ran 74 tests'in tool['output']
r=root/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0';probe=root/'var/qa/fixed55fdb-early-native-20261022/ordinary-ci-pair-attempt-v2/selected-actual-native-history-reader-source-v2/bin/Release/net10.0/Fixed55fdbNativeHistoryReaderV2.dll'
loaded=json.loads(subprocess.check_output(['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(r/'Riftbound.ConformanceTests.deps.json'),'--runtimeconfig',str(r/'Riftbound.ConformanceTests.runtimeconfig.json'),str(probe),'--loaded-inputs'],cwd=r))
assert Path(loaded['baseDirectory'])==r and loaded['actualRuleInputs']==sql['actualLoadedFourAssemblies']['actualRuleInputs'] and len(loaded['assemblies'])==4
for a in loaded['assemblies']:assert Path(a['path'])==r/(a['name']+'.dll') and a['sha256']==sha(Path(a['path'])) and a['mvid']
result={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_FINAL_FOUR_CORRECTIONS_51_CASES10_METHODS_FOCUS280_126_FIVE_ORIGINAL_FULL_AND_FRESH_SQL_NATIVE_READBACK_ORIGINAL_CHECK_ONE_FAILURE_RETAINED',
 'baseCommit':start['baseCommit'],'actualCases':13497,'actualMethods':7559,'actualOutcomes':dict(actual[3]),'originalSoleCheckBeforeFinalCorrectionsNotCurrentInputGreen':True,'originalCheckFailedCase':failure,'newCases':51,'newMethods':10,'finalFocusedCases':280,'finalFocusedMethods':126,
 'onlyFourPostCheckCorrectionPaths':final_inputs['exactFourChangedSinceOriginalSoleCheck'],'allOther3346SourceFilesExact':True,'all3350FinalSourceHashesAndModesVerified':True,'original13449Cases7550MethodsAllRetainedPlusOriginal48DuringCheckAndFinalThreeCases':True,
 'all1802OtherOriginalConformanceFilesTheoryAndMethodsByteExact':True,'onlyTwoOriginalFilesExactParentLookupAndEventNodeReorderPreserveAllAssertionNodes':True,'allNineFullSources143Methods151Cases110Pairs11Decks424242AndVictoryReplayAssertionsRetained':True,'currentFullMethods':sorted(full),
 'affectedOriginalFullGamesAfterFinalCorrections':sorted(games[2]),'affectedOriginalFullGameMethodsPassed':5,'currentDiscoveryMethods':7701,'expectedCurrentFixedFullCases':13649,'expectedCurrentFixedFullMethods':7701,'expectedCurrentSqlIdentities':60,
 'original59SqlObjectsAndOrderExact':True,'nativeNetwork15RejectAndPeerProgramSourceByteExact':True,'actualCurrentSql':sql['totals'],'actualFourLoadedAssembliesAndRuleInputs':loaded,'all369Audit88NativeSevenTablesExactAndOwnPostgresStopped':True,'oldOriginal126ColdAnd22NativeNotRelabeledNewCandidate':True,
 'allThreeIndependentMalformedOriginalExceptionsNowExplicitRecoveryErrors':True,'toolingTests':74,'oneOriginalCheckNoSecondCheckAndAllFailuresRetained':True,'oldAndFinalActualRuntimeInputsAndSourceHashesSeparatelyRetained':True,'newFixedFullCurrentCiNativeVisiblePairAndPhysicalWindows':'OPEN','wholePrintingCertified':False}
p=w/'final-after-sole-check-corrections-original-retention-v2.json';assert not p.exists();p.write_text(json.dumps(result,indent=2));print('PASS final51/10 focus280/126+5originalfull; fresh126/240/240/384 and22native; threeproperrefusals; all369/88 exact; originalsolecheck13496pass1fixturefailure retained; no secondcheck; newfixedfull13649/7701/60 OPEN',flush=True)
