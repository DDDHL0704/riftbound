using System.IO.Compression;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
var assemblies = new[] { typeof(CoreRuleEngine).Assembly, typeof(GameCommand).Assembly,
    typeof(Riftbound.CardCatalog.OfficialCardCatalog).Assembly, typeof(PostgresMatchJournal).Assembly };
var loaded = new { baseDirectory = AppContext.BaseDirectory, actualRuleInputs = RuleInputIdentity.Current,
    assemblies = assemblies.Select(a => new { name = a.GetName().Name, path = a.Location, mvid = a.ManifestModule.ModuleVersionId,
        sha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(a.Location))).ToLowerInvariant() }).ToArray() };
if (args.SequenceEqual(new[] { "--loaded-inputs" })) { Console.WriteLine(JsonSerializer.Serialize(loaded, json)); return; }
Check(args.Length == 2, "Exact original evidence root and new output required.");
var work = Path.GetFullPath(args[0]); var output = Path.GetFullPath(args[1]); Check(!File.Exists(output), "Never overwrite a result.");
using var publication = JsonDocument.Parse(File.ReadAllText(Path.Combine(work, "current-rule-sql60-frozen-inputs-v1.json")));
Check(Path.GetFullPath(publication.RootElement.GetProperty("runtimeRoot").GetString()!) == AppContext.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar)
    && Same(publication.RootElement.GetProperty("actualRuleInputs"), JsonSerializer.SerializeToElement(RuleInputIdentity.Current, json)), "The actual four loaded game assemblies and rule inputs must bind the frozen current candidate.");
foreach (var a in loaded.assemblies)
    Check(Path.GetDirectoryName(a.path) == loaded.baseDirectory.TrimEnd(Path.DirectorySeparatorChar)
        && publication.RootElement.GetProperty("runtimeFiles").GetProperty(a.name + ".dll").GetString() == a.sha256 && a.mvid != Guid.Empty,
        "Each actual loaded path/SHA/MVID belongs to the measured candidate, without a dependency fallback.");
var settings = new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
Check(settings.Host == "127.0.0.1" && settings.Port == 55486 && settings.Database == "riftbound_acceptance" && settings.Username == "codex_riftbound_audit", "Only the owned existing audit database.");
settings.Options = "-c default_transaction_read_only=on"; await using var source = NpgsqlDataSource.Create(settings.ConnectionString);
var nativeDirectory = Path.Combine(work, "native-actual-sql-choice-controls-v2");
using var nativeIndex = JsonDocument.Parse(File.ReadAllText(Path.Combine(nativeDirectory, "index.json")));
var nativeByOriginal = nativeIndex.RootElement.EnumerateArray().ToDictionary(r => Path.GetFullPath(r.GetProperty("originalCommandPath").GetString()!), r => r.Clone());
Check(nativeByOriginal.Count == 22, "Exactly 22 real production control outputs belong to original SQL prompts.");
var commandFields = new[] { "roomId", "accepted", "playerId", "faqVersion", "rawCommand", "ruleInputs", "commandType", "startedTick", "errorMessage", "completedTick", "clientIntentId", "rulesetVersion", "rulesAuditStatus", "startedEventSequence", "completedEventSequence" };
var counts = new Dictionary<string, int> { ["commands"] = 0, ["events"] = 0, ["authority"] = 0, ["snapshots"] = 0, ["prompts"] = 0, ["native"] = 0, ["originalPrefixReplays"] = 0, ["actualCorruptRoomRefusals"] = 0 };
var results = new List<object>();
foreach (var folder in Directory.GetDirectories(Path.Combine(work, "real-sql60-v1", "deck-pending-parent")).Order(StringComparer.Ordinal))
{
    using var receipt = JsonDocument.Parse(File.ReadAllText(Path.Combine(folder, "receipt.json"))); var declared = receipt.RootElement;
    var branch = declared.GetProperty("branch").GetString()!; var room = declared.GetProperty("room").GetString()!;
    var bad = declared.GetProperty("deliberateTamperRecoveryRejected").GetBoolean();
    using var beforeRows = Read(Path.Combine(folder, bad ? "actual-corrupt-seven-tables.json.gz" : "original-final-seven-tables.json.gz"));
    var tables = new Dictionary<string, JsonElement>();
    await using (var connection = await source.OpenConnectionAsync())
    {
        foreach (var table in new[] { "matches", "match_players", "command_log", "game_events", "state_snapshots", "snapshots", "action_prompts" })
        {
            await using var query = new NpgsqlCommand($"select coalesce(json_agg(t order by row_to_json(t)::text),'[]'::json)::text from (select * from {table} where match_id=@room)t", connection);
            query.Parameters.AddWithValue("room", room); using var rows = JsonDocument.Parse((string)(await query.ExecuteScalarAsync())!);
            Check(Same(rows.RootElement, beforeRows.RootElement.GetProperty(table)), "All seven actual tables equal the original sealed SQL rows, including IDs, hashes, metadata, nulls and omissions.");
            tables[table] = rows.RootElement.Clone();
        }
    }
    var originals = Directory.GetFiles(folder, "entry-*-original-before-persist.json.gz").Order(StringComparer.Ordinal).Select(p => { using var d = Read(p); return d.RootElement.Clone(); }).ToArray();
    Check(originals.Length == declared.GetProperty("originalAcceptedInputs").GetInt32() && originals.Length == declared.GetProperty("coldRecoveries").GetInt32(), "Every literal original input has a cold recovery and a before-persist original.");
    var commandRows = tables["command_log"].EnumerateArray().OrderBy(r => r.GetProperty("id").GetInt64()).ToArray();
    var eventRows = tables["game_events"].EnumerateArray().OrderBy(r => r.GetProperty("event_sequence").GetInt64()).ToArray();
    Check(commandRows.Length == originals.Length, "No accepted original input is added, removed or relabeled.");
    var eventOffset = 0; var expectedAuthority = new Dictionary<(long, long), JsonElement>();
    var expectedPrivate = new Dictionary<(string Table, long Tick, string Actor), (long Sequence, JsonElement Payload)>();
    for (var n = 0; n < originals.Length; n++)
    {
        var e = originals[n]; var row = commandRows[n]; var payload = row.GetProperty("payload");
        Check(payload.EnumerateObject().Select(p => p.Name).Order().SequenceEqual(commandFields.Order()), "The complete original command payload schema is literal and exact.");
        foreach (var field in commandFields) Check(Same(payload.GetProperty(field), e.GetProperty(field)), "Every raw command field, null and conditional presence equals its original before-persist input.");
        Check(row.GetProperty("player_id").GetString() == e.GetProperty("playerId").GetString()
            && row.GetProperty("client_intent_id").GetString() == e.GetProperty("clientIntentId").GetString()
            && row.GetProperty("accepted").GetBoolean() && Same(row.GetProperty("rule_inputs"), e.GetProperty("ruleInputs")), "Column and payload actor, intent, accepted state and full input identity agree.");
        var start = e.GetProperty("startedEventSequence").GetInt64(); var end = e.GetProperty("completedEventSequence").GetInt64(); var tick = e.GetProperty("completedTick").GetInt64();
        var originalEvents = e.GetProperty("events").EnumerateArray().ToArray(); Check(end - start == originalEvents.Length, "Every original input owns its exact event span.");
        for (var i = 0; i < originalEvents.Length; i++)
        {
            var actual = eventRows[eventOffset++];
            Check(actual.GetProperty("event_sequence").GetInt64() == start + i + 1 && actual.GetProperty("event_tick").GetInt64() == tick
                && actual.GetProperty("event_order").GetInt32() == i && Same(actual.GetProperty("payload"), originalEvents[i])
                && actual.GetProperty("event_type").GetString() == originalEvents[i].GetProperty("kind").GetString(), "Every original event kind, description, complete payload and sequence/tick/order is unchanged.");
        }
        expectedAuthority[(tick, end)] = e.GetProperty("authoritativeState").Clone();
        foreach (var (table, property) in new[] { ("snapshots", "snapshots"), ("action_prompts", "prompts") })
            foreach (var view in e.GetProperty(property).EnumerateObject()) expectedPrivate[(table, tick, view.Name)] = (end, view.Value.Clone());
    }
    Check(eventOffset == eventRows.Length, "No unowned or removed original event.");
    counts["commands"] += originals.Length; counts["events"] += eventOffset;
    var last = originals[^1]; var lastKey = (last.GetProperty("completedTick").GetInt64(), last.GetProperty("completedEventSequence").GetInt64());
    var authorityRows = tables["state_snapshots"].EnumerateArray().ToArray();
    Check(authorityRows.Length == expectedAuthority.Count, "All independently expected original historical states remain stored.");
    foreach (var row in authorityRows)
    {
        var key = (row.GetProperty("state_tick").GetInt64(), row.GetProperty("last_event_sequence").GetInt64());
        Check(expectedAuthority.ContainsKey(key), "No synthetic or missing authority history.");
        if (!bad || key != lastKey) Check(Same(row.GetProperty("payload"), expectedAuthority[key]), "Every uncorrupted authoritative history equals the entire original before-persist state.");
        counts["authority"]++;
    }
    foreach (var table in new[] { "snapshots", "action_prompts" })
    {
        var keys = new HashSet<(string, long, string)>();
        foreach (var row in tables[table].EnumerateArray())
        {
            var tick = row.GetProperty(table == "snapshots" ? "snapshot_tick" : "prompt_tick").GetInt64(); var actor = row.GetProperty("player_id").GetString()!;
            var key = (table, tick, actor); Check(keys.Add(key) && expectedPrivate.TryGetValue(key, out _), "Each private row has its original viewer and tick.");
            var expected = expectedPrivate[key]; Check(row.GetProperty("last_event_sequence").GetInt64() == expected.Sequence, "Same-tick latest-private-row sequence is exact; no fabricated earlier viewer.");
            if (!bad || tick != lastKey.Item1) Check(Same(row.GetProperty("payload"), expected.Payload), "Every complete original private payload, null and omission is retained.");
            counts[table == "snapshots" ? "snapshots" : "prompts"]++;
        }
        Check(keys.SetEquals(expectedPrivate.Keys.Where(k => k.Table == table)), "Exact original private row key set.");
    }
    var frame = (await new PostgresMatchRecoveryStore(source).LoadAsync(room, default))!;
    Check(frame.OpeningSeed == declared.GetProperty("originalPrivateSeed").GetInt64() && frame.OpeningSeed != 0
        && frame.ReplayInitialState is { Status: "EMPTY", Seats.Count: 0, CardObjects.Count: 0 }, "Actual original private seed and EMPTY origin remain, without migration.");
    var replay = new MatchSession(frame.ReplayInitialState!, new CoreRuleEngine(), NoopMatchJournal.Instance);
    for (var n = 0; n < originals.Length; n++)
    {
        var original = originals[n]; var c = frame.Commands[n]; var raw = c.RawCommand!.Value;
        var originalPath = Path.GetFullPath(Path.Combine(folder, $"input-{n:D2}-original-command.json"));
        if (nativeByOriginal.TryGetValue(originalPath, out var native))
        {
            using var actual = JsonDocument.Parse(File.ReadAllText(native.GetProperty("outputCommandPath").GetString()!));
            Check(Same(actual.RootElement, raw), "The actual Godot production control output has exactly the same complete raw schema, nulls, values, prompt, tick and object order as the original SQL intent.");
            raw = actual.RootElement.Clone(); counts["native"]++;
        }
        ResolutionResult result;
        if (c.CommandType == "ROOM_SEAT")
        {
            Check(n < 2 && c.PlayerId == (n == 0 ? "alice" : "bob") && raw.EnumerateObject().Count() == 3
                && raw.GetProperty("seat").GetString() == (n == 0 ? "P1" : "P2"), "Literal original reserved server-seat input and its three-field raw schema.");
            var method = typeof(MatchSession).GetMethod("ReplayRoomSeatAsync", BindingFlags.Instance | BindingFlags.NonPublic)!;
            result = await (ValueTask<ResolutionResult>)method.Invoke(replay, new object[] { c, CancellationToken.None })!;
        }
        else if (c.CommandType.StartsWith("DEV_SEED_SCENARIO:", StringComparison.Ordinal))
        {
            Check(n == 2 && c.CommandType == "DEV_SEED_SCENARIO:" + declared.GetProperty("scenario").GetString(), "The controlled setup is an explicit original input, not an unlogged replacement opening.");
            result = await replay.SeedScenarioAsync(c.PlayerId, c.ClientIntentId, c.CommandType["DEV_SEED_SCENARIO:".Length..], raw, default);
        }
        else result = await replay.SubmitAsync(c.PlayerId, c.ClientIntentId, GameCommandJsonMapper.Map(raw), raw, default);
        Check(result.Accepted == c.Accepted && result.ErrorMessage == c.ErrorMessage && result.State.Tick == c.CompletedTick,
            "Every original input, including native emitted commands, retains accepted/error/tick behavior in independent sequential replay.");
        Check(Same(JsonSerializer.SerializeToElement(result.State, json), original.GetProperty("authoritativeState")), "Every original replayed prefix equals its complete original pre-persist state, even in later deliberately corrupted rooms.");
        Check(Same(JsonSerializer.SerializeToElement(result.Events, json), original.GetProperty("events")), "Every original prefix replays the complete literal original event sequence.");
        counts["originalPrefixReplays"]++;
    }
    var errors = await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame, new CoreRuleEngine(), default);
    Check(bad ? errors.Count > 0 : frame.IsConsistent && errors.Count == 0, "All eight original normal rooms pass complete recovery; all four actual deliberate-corruption rooms remain refused.");
    if (bad) counts["actualCorruptRoomRefusals"]++;
    results.Add(new { room, branch, originalCommands = originals.Length, originalEvents = eventOffset, actualCorruptRoomRefused = bad,
        originalHistoryReplayBeforeDeliberateTamperStillExact = true, noAcceptedHistoryRewriteOrDatabaseWrite = true });
    Console.WriteLine($"INDEPENDENT_SQL60_ORIGINAL_PASS {branch} commands={originals.Length} nativeTotal={counts["native"]} rejected={bad}");
}
Check(results.Count == 12 && counts["commands"] == counts["originalPrefixReplays"] && counts["commands"] == 126
    && counts["native"] == 22 && counts["actualCorruptRoomRefusals"] == 4, "Exact original rooms, inputs, native packets, prefix replays and genuine refusals.");
var proof = new { status = "PASS_INDEPENDENT_SQL60_ALL126_ORIGINAL_PREFIXES22_NATIVE_PACKETS_AND_FOUR_ACTUAL_REFUSALS", actualReadOnlyConnection = true,
    actualLoadedFourAssemblies = loaded, totals = counts, rooms = results, normalRooms = 8, deliberatelyCorruptRefusedRooms = 4,
    nativePacketBackendReadbackReplaysEquivalentOriginalRawNoNewLiveSubmission = true,
    allOriginalFieldsNullConditionalOmissionsAndRowKeysRetained = true, originalSeedAndEmptyOpeningRetained = true,
    fixedFullVisiblePairedWindowsAndWholeCardCertification = false };
await File.WriteAllTextAsync(output, JsonSerializer.Serialize(proof, json)); Console.WriteLine(proof.status);
static JsonDocument Read(string path) { using var zip = new GZipStream(File.OpenRead(path), CompressionMode.Decompress); return JsonDocument.Parse(zip); }
static bool Same(JsonElement a, JsonElement b) => JsonNode.DeepEquals(JsonNode.Parse(a.GetRawText()), JsonNode.Parse(b.GetRawText()));
static void Check(bool value, string reason) { if (!value) throw new InvalidOperationException(reason); }
