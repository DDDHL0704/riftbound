using System.IO.Compression;
using System.Text.Json;
using Riftbound.Engine;
var options=new JsonSerializerOptions(JsonSerializerDefaults.Web);
using var zip=new GZipStream(File.OpenRead(args[0]),CompressionMode.Decompress);
var frame=await JsonSerializer.DeserializeAsync<MatchRecoveryFrame>(zip,options)??throw new Exception("Original frame required.");
var state=frame.AuthoritativeState!;var p=state.PendingEffectPlay!;var permission=p.Parent.ObservedPlayPermission!;var original=permission.Suspended!;
var results=new List<object>();
foreach(var kind in new[]{"negative-index","null-queue","null-entry"}){
 var c=original.Parent.DeckPlaySequence!;
 c=kind switch{"negative-index"=>c with{PlayIndex=-1},"null-queue"=>c with{Queue=null!},_=>c with{Queue=c.Queue.Select((v,i)=>i==c.PlayIndex?null!:v).ToArray()}};
 var bad=state with{PendingEffectPlay=p with{Parent=p.Parent with{ObservedPlayPermission=permission with{Suspended=original with{Parent=original.Parent with{DeckPlaySequence=c}}}}}};
 try{var errors=MatchRecoveryValidator.Validate(frame.RoomId,frame.LastEventSequence,[],[],new Dictionary<string,RecoveredPlayerView>(),bad,bad.Tick);results.Add(new{kind,threw=false,errors=errors.ToArray()});}
 catch(Exception e){results.Add(new{kind,threw=true,type=e.GetType().FullName,message=e.Message});}
}
await File.WriteAllTextAsync(args[1],JsonSerializer.Serialize(results,new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(results));
