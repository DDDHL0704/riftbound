# -*- coding: utf-8 -*-
from pathlib import Path
import datetime, gzip, hashlib, json, os, subprocess, zipfile

os.umask(0o077)
w = Path(__file__).resolve().parent
run_id = 39748320406
fixed = '55fdbabf8731fec795c26584985bd31cc0bcca32'
sha = lambda data: hashlib.sha256(data).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
folder = w / 'ci55fdb-complete-originals-v1'
folder.mkdir(exist_ok=False)
receipts = []
def fetch(endpoint, label):
    errors = []
    for attempt in range(1, 4):
        proc = subprocess.run(['gh', 'api', 'repos/DDDHL0704/riftbound/' + endpoint], capture_output=True, timeout=55)
        if proc.returncode == 0:
            value = json.loads(proc.stdout)
            p = w / ('ci55fdb-' + label + '-original-v1.json.gz')
            assert not p.exists()
            p.write_bytes(gzip.compress(proc.stdout, mtime=0))
            assert gzip.decompress(p.read_bytes()) == proc.stdout
            receipts.append({'role': label, 'path': str(p), 'rawSha256': sha(proc.stdout), 'compressedSha256': sha(p.read_bytes()), 'priorTransportAttempts': errors})
            return value
        errors.append({'attempt': attempt, 'returnCode': proc.returncode, 'stderrSha256': sha(proc.stderr), 'partialBytes': len(proc.stdout), 'partialSha256': sha(proc.stdout)})
    raise RuntimeError('Three transport attempts failed: ' + label)
run = fetch(f'actions/runs/{run_id}', 'terminal')
assert run['head_sha'] == fixed and run['status'] == 'completed' and run['conclusion'] == 'success'
jobs = fetch(f'actions/runs/{run_id}/jobs?per_page=100', 'all11-jobs')
assert len(jobs['jobs']) == 11 and all(j['status'] == 'completed' and j['conclusion'] == 'success' for j in jobs['jobs'])
metadata = fetch(f'actions/runs/{run_id}/artifacts?per_page=100', 'backend-artifacts')
names = ['postgres-partition-' + str(i) for i in range(4)] + ['postgres-results', 'native-network-results', 'verification-scope', 'conformance-results', 'full-verification-gate']
artifacts = []
try:
    for name in names:
        a = next(a for a in metadata['artifacts'] if a['name'] == name)
        assert not a['expired'] and a['workflow_run']['head_sha'] == fixed
        attempts = []
        for attempt in range(1, 4):
            target = folder / (name + ('' if attempt == 1 else '-attempt-' + str(attempt)) + '.zip')
            assert not target.exists()
            with target.open('xb') as out:
                proc = subprocess.run(['gh', 'api', f'repos/DDDHL0704/riftbound/actions/artifacts/{a["id"]}/zip'], stdout=out, stderr=subprocess.PIPE, timeout=170)
            data = target.read_bytes()
            valid = proc.returncode == 0 and len(data) == a['size_in_bytes'] and 'sha256:' + sha(data) == a['digest']
            attempts.append({'attempt': attempt, 'returnCode': proc.returncode, 'bytes': len(data), 'sha256': sha(data), 'stderrSha256': sha(proc.stderr), 'backendSizeAndDigestMatch': valid})
            if valid:
                with zipfile.ZipFile(target) as z: assert z.testzip() is None
                break
            target.unlink()
        else: raise RuntimeError('Three exact artifact transports failed: ' + name)
        artifacts.append({'name': name, 'id': a['id'], 'path': str(target), 'bytes': len(data), 'sha256': sha(data), 'backendDigest': a['digest'], 'allZipCrcVerified': True, 'attempts': attempts})
        print(name, 'BACKEND_SIZE_SHA256_ALL_CRC_PASS', flush=True)
    assert len(artifacts) == 9
    proof = {'status': 'COMPLETED_FIXED55FDB_ALL11_SUCCESS_NINE_ORIGINAL_VERIFICATION_ZIPS_TRANSPORT_VALIDATED_SEMANTIC_GATE_READBACK_PENDING', 'atUtc': now(), 'fixedCommit': fixed, 'runId': run_id, 'metadataReceipts': receipts, 'jobs': {j['name']: j['conclusion'] for j in jobs['jobs']}, 'artifacts': artifacts, 'nativePackagesNotRedownloaded': True}
    (w / 'ci55fdb-all-nine-original-artifacts-receipt-v1.json').write_text(json.dumps(proof, indent=2))
except BaseException as error:
    (w / 'ci55fdb-original-download-partial-or-failure-v1.json').write_text(json.dumps({'atUtc': now(), 'fixedCommit': fixed, 'runId': run_id, 'metadataReceipts': receipts, 'completedOriginalArtifacts': artifacts, 'errorType': type(error).__name__, 'error': str(error), 'noPreviouslyValidPayloadOrNativePackageDeleted': True}, indent=2))
    raise
print(proof['status'], flush=True)
