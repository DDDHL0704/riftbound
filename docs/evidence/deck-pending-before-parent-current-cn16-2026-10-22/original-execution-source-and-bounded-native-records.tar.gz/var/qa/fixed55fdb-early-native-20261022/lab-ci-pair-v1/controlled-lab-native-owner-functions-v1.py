# -*- coding: utf-8 -*-
def frozen():
 assert all(sha(api_runtime/p)==h for p,h in pub['runtimeFiles'].items())
 assert all(sha(helpers/p)==h for p,h in pub['helperRuntimeFiles'].items())
 assert all(sha(Path(pub['networkRuntimeRoot'])/p)==h for p,h in pub['networkRuntimeFiles'].items())
 assert all(sha(root/p)==h for p,h in pub['networkSourceHashes'].items())
 assert all(sha(root/p)==h for p,h in load(Path(pub['apiBuildInputsManifest']))['allDeclaredApiGameplaySourceInputsExactFixedCommit'].items())
 assert all(sha(Path(a['app'])/p)==h for a in pub['nativeApps'] for p,h in pub['ciManagedAndPckPayloads'].items())

def start_api(index):
 global api
 frozen();log=w/('live-controlled-lab-api-'+str(index)+'-v3.log');env=dict(os.environ,ASPNETCORE_ENVIRONMENT='Development',ASPNETCORE_URLS='http://127.0.0.1:15847',ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit',DOTNET_DbgEnableMiniDump='0');env.pop('DOTNET_STARTUP_HOOKS',None)
 with log.open('xb') as stream:api=subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet',str(api_runtime/'Riftbound.Api.dll')],cwd=api_runtime,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 until=time.monotonic()+20
 while time.monotonic()<until:
  assert api.poll() is None
  try:
   with urllib.request.urlopen('http://127.0.0.1:15847/health',timeout=.5) as response:health=json.load(response)
   assert health['persistenceMode']=='postgres' and health['environment']=='Development'
   assert set(subprocess.check_output(['/usr/sbin/lsof','-tiTCP:15847','-sTCP:LISTEN'],text=True).splitlines())=={str(api.pid)}
   proof['ownedApiProcesses'].append({'pid':api.pid,'index':index,'health':health,'log':log.name,'atUtc':now()});return
  except OSError:time.sleep(.1)
 raise AssertionError('Owned frozen API did not become ready')

def export(name):
 target=evidence/(name+'.json.gz');assert not target.exists()
 args=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(helpers/'Riftbound.Api.deps.json'),'--runtimeconfig',str(helpers/'Riftbound.Api.runtimeconfig.json'),str(helpers/'FixedNativeFrameExport.dll'),room,str(target)]
 env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit;Options=-c default_transaction_read_only=on',DOTNET_DbgEnableMiniDump='0')
 raw=subprocess.check_output(args,cwd=helpers,env=env);metadata=json.loads(raw);assert metadata['actualRuleInputs']==pub['actualRuleInputs'];checkpoint(name+'-metadata.json',metadata)
 frame=json.loads(gzip.decompress(target.read_bytes()));assert frame['isConsistent'] and not frame['validationErrors'] and frame['authoritativeState']['ruleInputs']==pub['actualRuleInputs'];return frame

def count():
 assert room is not None and re.fullmatch('N42-LAB-[0-9A-F]{10}',room)
 return int(query('riftbound_here_native',"select count(*) from command_log where match_id='"+room+"'"))

def launch(role, label, frames, action=None):
    app = Path(next(a['app'] for a in pub['nativeApps'] if a['label'] == role))
    subprocess.run(['codesign', '--verify', '--deep', '--strict', str(app)], check=True, capture_output=True)
    log = w / ('current55fdb-pty-ci-native-' + label + '-v3.log')
    args = [str(app / 'Contents/MacOS/符文战场'), '--headless', '--max-fps', '60', '--quit-after', str(frames), '--', '--riftbound-server=http://127.0.0.1:15847', '--riftbound-session-file=' + str(profiles / ('session-' + role + '.json')), '--riftbound-smoke-connect-only']
    if action: args += ['--riftbound-smoke-ui-action=' + action, '--riftbound-smoke-ui-submit']
    env = dict(os.environ, DOTNET_DbgEnableMiniDump='0')
    env.pop('DOTNET_STARTUP_HOOKS', None)
    master, slave = pty.openpty()
    stream = log.open('xb', buffering=0)
    p = subprocess.Popen(args, cwd='/tmp', env=env, stdin=subprocess.DEVNULL, stdout=slave, stderr=slave, start_new_session=True)
    os.close(slave)
    def drain():
        try:
            while True:
                try: data = os.read(master, 65536)
                except OSError as e:
                    if e.errno == errno.EIO: break
                    raise
                if not data: break
                stream.write(data)
        finally:
            os.close(master)
            stream.close()
    pump = threading.Thread(target=drain, daemon=True)
    pumps[p.pid] = pump
    pump.start()
    record = {'role': role, 'label': label, 'pid': p.pid, 'actualCommand': args, 'log': log.name, 'action': action, 'nativeProcessOwnsPtyStdoutOnlyNoDesktopOrInputEvents': True, 'all373FixedCiPayloadsAndSignatureVerified': True}
    proof['ownedNativeProcesses'].append(record)
    clients.append((p, record, log))
    return p, record, log

def native_wait(predicate,why,seconds=40,alive=()):
 until=time.monotonic()+seconds
 while not predicate():
  assert time.monotonic()<until,why
  assert api is not None and api.poll() is None,why+' API exited'
  assert all(p.poll() is None for p in alive),why+' native process exited'
  time.sleep(.1)

def log_count(path,channel):return path.read_text(errors='replace').count('[b]'+channel+'[/b]') if path.exists() else 0

def wait_exit(item, timeout):
    p, record, log = item
    code = p.wait(timeout=timeout)
    pumps[p.pid].join(timeout=10)
    assert not pumps[p.pid].is_alive(), 'Native PTY log must reach EOF.'
    record.update(exitCode=code, logSha256=sha(log), ptyFullyDrained=True)
    assert code == 0, 'Native default Main failed.'
    raw = log.read_text(errors='replace')
    assert 'ERROR:' not in raw and 'Unhandled exception' not in raw, 'Original native error log retained; no pass from exit code alone.'
