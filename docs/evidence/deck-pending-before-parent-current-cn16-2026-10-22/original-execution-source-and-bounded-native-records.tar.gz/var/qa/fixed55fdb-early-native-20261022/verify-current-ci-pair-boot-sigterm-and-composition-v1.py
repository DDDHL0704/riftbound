from pathlib import Path
from datetime import datetime, timezone
import hashlib, importlib.util, json, subprocess, sys

sys.dont_write_bytecode = True
root = Path('/Users/dinghaolin/MyProjects/riftbound'); qa = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
fixed = '55fdbabf8731fec795c26584985bd31cc0bcca32'; run_id = 39748320406
manifest_path = qa/'native-app-inputs.json'; native = load(manifest_path)
pub = load(qa/'fixed55fdb-native-helper-and-network-frozen-v1.json')
downloads = load(qa/'current-fixed-native-download-original-result-v1.json')
assert native['fixedCommit'] == pub['fixedCommit'] == downloads['fixedCommit'] == fixed and native['runId'] == downloads['runId'] == run_id
assert len(native['ciManagedAndPckPayloads']) == 373 and len(native['apps']) == 2
assert len(downloads['artifacts']) == 2 and all(a['allOuterZipCrcVerified'] and a['backendDigest'] == 'sha256:'+a['actualSha256'] and sha(qa/'native-current'/a['filename']) == a['actualSha256'] for a in downloads['artifacts'])
spec = importlib.util.spec_from_file_location('current_committed_desktop_gate', root/'clients/godot/tools/ci-desktop.py')
gate = importlib.util.module_from_spec(spec); spec.loader.exec_module(gate)
records = []
for entry in native['apps']:
    app = Path(entry['app']); executable = app/'Contents/MacOS/符文战场'
    assert entry['bundleId'] == 'com.riftbound.qa.current-55fdbabf.'+entry['label']
    assert all(sha(app/p) == h for p, h in native['ciManagedAndPckPayloads'].items())
    subprocess.run(['codesign', '--verify', '--deep', '--strict', str(app)], capture_output=True, check=True)
    profile = qa/('never-written-default-boot-'+entry['label']+'-v1.json'); assert not profile.exists()
    log = qa/('current-ci-default-main-natural-'+entry['label']+'-v1.log')
    command = [str(executable), '--headless', '--max-fps', '60', '--quit-after', '120', '--', '--riftbound-ephemeral-session', '--riftbound-server=http://127.0.0.1:1', '--riftbound-session-file='+str(profile)]
    with log.open('xb') as out:
        process = subprocess.run(command, cwd='/tmp', stdout=out, stderr=subprocess.STDOUT, timeout=45)
    text = log.read_text(errors='replace')
    assert process.returncode == 0 and 'Client booted.' in text and 'Official catalog loaded: 1035 cards.' in text and 'ERROR:' not in text and not profile.exists()
    signal_log = qa/('current-ci-default-main-sigterm-'+entry['label']+'-v1.log')
    gate.verify_macos_sigterm_shutdown(executable, signal_log, qa)
    assert 'Termination requested; exiting through Godot.' in signal_log.read_text() and 'ERROR:' not in signal_log.read_text()
    assert all(sha(app/p) == h for p, h in native['ciManagedAndPckPayloads'].items())
    records.append({'role': entry['label'], 'app': str(app), 'executable': str(executable), 'actualCommand': command,
                    'naturalExitCode': process.returncode, 'naturalLogSha256': sha(log), 'sigtermGuardPassed': True,
                    'sigtermLogSha256': sha(signal_log), 'ephemeralProfileNeverWritten': True, 'all373CiPayloadsAndSignatureExact': True})
ci_signal = qa/'native-current/ci-logs/mac/exported-sigterm.log'
assert 'Termination requested; exiting through Godot.' in ci_signal.read_text() and 'ERROR:' not in ci_signal.read_text()
proof = {'atUtc': datetime.now(timezone.utc).isoformat(), 'status': 'ACTUAL_FIXED55FDB_CI_PAIR_DEFAULT_MAIN_NATURAL_AND_SIGTERM_ALL_CLEAN_373_PAYLOADS_EACH_NOT_VISIBLE_OR_WINDOWS',
         'fixedCommit': fixed, 'fixedCiRun': run_id, 'records': records, 'ciMacosSigtermLogSha256': sha(ci_signal),
         'sourceNativeInputManifestSha256': sha(manifest_path), 'actualRuleInputsOfMatchingFrozenApi': pub['actualRuleInputs'],
         'serverNotStartedAndNoDatabaseActionInThisBootGate': True, 'old68PairRetirementNowPermittedAfterNoProcessOwnerCheck': True,
         'prepareConsoleShortLabelHad55fdbc5bTypoButAllManifestBackendAndLoadedFixedCommitValuesAreFull55fdbabf': True,
         'physicalWindowsVisiblePairAndWholeFullStillSeparateOpen': True, 'semanticCoverageCertified': False}
output = qa/'current-native-headless-boot-and-sigterm-verification-v1.json'; assert not output.exists(); output.write_text(json.dumps(proof, indent=2)+'\n')
pub.update(status='FROZEN_FIXED55FDB_API46_HELPERS87_NETWORK22_AND_ACTUAL_CI_PAIR373_EACH_DEFAULT_MAIN_NATURAL_SIGTERM_VERIFIED',
           nativeApps=native['apps'], ciManagedAndPckPayloads=native['ciManagedAndPckPayloads'], nativeAppManifest=str(manifest_path),
           nativeAppManifestSha256=sha(manifest_path), currentDefaultBootAndSigtermResultSha256=sha(output),
           nativePackagesNotYetDownloaded=False)
target = qa/'frozen-fixed55fdb-native-composition-v1.json'; assert not target.exists(); target.write_text(json.dumps(pub, indent=2)+'\n')
print(proof['status'], flush=True)
