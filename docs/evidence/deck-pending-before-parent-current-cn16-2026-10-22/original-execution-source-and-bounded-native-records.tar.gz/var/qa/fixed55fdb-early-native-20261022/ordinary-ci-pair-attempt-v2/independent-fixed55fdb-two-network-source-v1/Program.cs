using System.IO.Compression;
using System.Reflection;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

Check(args.Length==2&&!File.Exists(args[1]),"Original real-network evidence and new independent result required.");
var work=Path.GetFullPath(args[0]);var json=new JsonSerializerOptions(JsonSerializerDefaults.Web){WriteIndented=true};
using var receipt=JsonDocument.Parse(File.ReadAllText(Path.Combine(work,"live-current-ci-main-owner-terminal-v3.json")));
Check(receipt.RootElement.GetProperty("fixedCommit").GetString()=="55fdbabf8731fec795c26584985bd31cc0bcca32"&&Same(receipt.RootElement.GetProperty("actualRuleInputs"),JsonSerializer.SerializeToElement(RuleInputIdentity.Current,json)),"Exact fixed55fdb production runtime and original network evidence inputs required.");
var originalRoom=receipt.RootElement.GetProperty("networkOriginalEvidence").GetProperty("room").GetString()!;
var peerRoom=receipt.RootElement.GetProperty("newPeerWireEvidence").GetProperty("room").GetString()!;
var firstActor="native"+originalRoom["NETWORK-".Length..];var secondActor="seatpeer"+peerRoom["NETWORK-SEAT-".Length..];
var settings=new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
Check(settings.Host=="127.0.0.1"&&settings.Port==55486&&settings.Database=="riftbound_here_native"&&settings.Username=="codex_riftbound_audit","Only own native SQL database.");settings.Options="-c default_transaction_read_only=on";
await using var source=NpgsqlDataSource.Create(settings.ConnectionString);var outcomes=new List<object>();var totals=new Dictionary<string,int>{{"commands",0},{"events",0},{"authority",0},{"snapshots",0},{"prompts",0}};
foreach(var room in new[]{originalRoom,peerRoom}){
 var isPeer=room==peerRoom;var actors=isPeer?new[]{firstActor,secondActor}:new[]{firstActor};var label=isPeer?"peer":"original";
 using var saved=Read(Path.Combine(work,$"actual-safe-native-main-v2/current-network-{room}-original-frame-v2.json.gz"));
 var frame=await new PostgresMatchRecoveryStore(source).LoadAsync(room,default)??throw new Exception("Actual original frame required.");
 Check(Same(saved.RootElement,JsonSerializer.SerializeToElement(frame,json))&&frame.IsConsistent&&frame.ValidationErrors.Count==0,"Every saved original frame field/null/omission equals independent SQL read.");
 Check(frame.Commands.Count==actors.Length&&frame.Events.Count==actors.Length&&frame.OpeningSeed!=0&&frame.ReplayInitialState is{Status:"EMPTY",Seats.Count:0,Tick:0}&&frame.AuthoritativeState!.RuleInputs==RuleInputIdentity.Current,"Exact original EMPTY origin, private seed, current rules and expected server-only inputs.");
 var states=new Dictionary<(long,long),MatchState>();var counts=new Dictionary<string,int>();
 await using(var connection=await source.OpenConnectionAsync()){
  Check((string)(await new NpgsqlCommand("show transaction_read_only",connection).ExecuteScalarAsync())! =="on","Independent connection actually read-only.");
  using var raw=Read(Path.Combine(work,$"actual-safe-native-main-v2/current-network-{room}-all-seven-original-tables-v2.json.gz"));
  foreach(var table in new[]{"matches","match_players","command_log","game_events","state_snapshots","snapshots","action_prompts"}){
   await using var q=Query(connection,$"select coalesce(jsonb_agg(to_jsonb(t)),'[]'::jsonb)::text from (select * from {table} where match_id=@room)t");
   using var current=JsonDocument.Parse((string)(await q.ExecuteScalarAsync())!);
   var expected=raw.RootElement.GetProperty("originalRows").GetProperty(table);
   Check(expected.GetArrayLength()==current.RootElement.GetArrayLength()&&expected.EnumerateArray().All(e=>current.RootElement.EnumerateArray().Count(v=>Same(e,v))==1),"Every original complete seven-table row retained, independent of SQL member/row ordering.");counts[table]=expected.GetArrayLength();
  }
  await using(var q=Query(connection,"select last_event_sequence,payload::text from state_snapshots where match_id=@room order by state_tick,last_event_sequence"))
  await using(var rows=await q.ExecuteReaderAsync())while(await rows.ReadAsync()){
   var text=rows.GetString(1);var state=JsonSerializer.Deserialize<MatchState>(text,json)!;Check(JsonNode.DeepEquals(JsonNode.Parse(text),JsonSerializer.SerializeToNode(state,json))&&state.RuleInputs==RuleInputIdentity.Current&&states.TryAdd((state.Tick,rows.GetInt64(0)),state),"All authoritative history fields/nulls/omissions and exact current input binding.");
  }
  Check(states.Count==actors.Length&&states[(1,1)].Seats.Count==1&&states[(1,1)].Seats[firstActor]=="P1"&&(!isPeer||!states[(1,1)].Seats.ContainsKey(secondActor)),"Literal first-player-only origin is retained; no later player is invented in earlier history.");
  var expectedPrivate=states.SelectMany(s=>s.Value.Seats.Keys.Select(actor=>(actor,s.Key.Item1,s.Key.Item2))).ToHashSet();
  foreach(var table in new[]{"snapshots","action_prompts"}){
   var seen=new HashSet<(string,long,long)>();await using var q=Query(connection,$"select player_id,last_event_sequence,payload::text from {table} where match_id=@room order by id");await using var rows=await q.ExecuteReaderAsync();
   while(await rows.ReadAsync()){
    var actor=rows.GetString(0);var text=rows.GetString(2);using var document=JsonDocument.Parse(text);var tick=document.RootElement.GetProperty(table=="snapshots"?"tick":"snapshotTick").GetInt64();var seq=rows.GetInt64(1);
    Check(states.TryGetValue((tick,seq),out var state)&&seen.Add((actor,tick,seq))&&state.Seats.ContainsKey(actor),"Every private key binds the actual original authority and existing viewer.");
    var typed=table=="snapshots"?JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<SnapshotDto>(text,json),json):JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<ActionPromptDto>(text,json),json);
    var projected=table=="snapshots"?JsonSerializer.SerializeToNode(ResolutionResult.BuildSnapshots(state!)[actor],json):JsonSerializer.SerializeToNode(ResolutionResult.BuildPrompts(state!)[actor],json);
    Check(JsonNode.DeepEquals(JsonNode.Parse(text),typed)&&JsonNode.DeepEquals(JsonNode.Parse(text),projected),"Complete private values/nulls/omissions and original projection exact.");
    Check(!document.RootElement.TryGetProperty("openingSeed",out _)&&!document.RootElement.TryGetProperty("reconnectToken",out _)&&!document.RootElement.TryGetProperty("playerKey",out _),"Original private views contain no private seed or credential field.");
   }
   Check(seen.SetEquals(expectedPrivate),"All actual viewers at all original ticks retained under existing private key, with no fabricated second-player tick1.");totals[table=="snapshots"?"snapshots":"prompts"]+=seen.Count;
  }
 }
 var replay=new MatchSession(frame.ReplayInitialState!,new CoreRuleEngine(),NoopMatchJournal.Instance);var method=typeof(MatchActionLogReplayer).GetMethod("ReplayCommandAsync",BindingFlags.Static|BindingFlags.NonPublic)!;
 for(var i=0;i<actors.Length;i++){
  var command=frame.Commands[i];var raw=command.RawCommand!.Value;var slot=i==0?"P1":"P2";
  Check(command.Accepted&&command.ErrorMessage is null&&command.CommandType=="ROOM_SEAT"&&command.PlayerId==actors[i]&&command.ClientIntentId=="room-seat:"+slot&&command.StartedTick==i&&command.CompletedTick==i+1&&command.StartedEventSequence==i&&command.CompletedEventSequence==i+1&&raw.EnumerateObject().Count()==3&&raw.GetProperty("playerId").GetString()==actors[i]&&raw.GetProperty("cmdType").GetString()=="ROOM_SEAT"&&raw.GetProperty("seat").GetString()==slot,"Literal original authenticated actors, assigned seats, reserved intents and exact server raw schema/spans.");
  var result=await(ValueTask<ResolutionResult>)method.Invoke(null,new object[]{replay,command,CancellationToken.None})!;
  Check(result.Accepted&&result.ErrorMessage is null&&Same(JsonSerializer.SerializeToElement(result.State,json),JsonSerializer.SerializeToElement(states[(command.CompletedTick,command.CompletedEventSequence)],json)),"Every original command prefix replays to its entire original historical state.");
  var events=frame.Events.Where(e=>e.Sequence>command.StartedEventSequence&&e.Sequence<=command.CompletedEventSequence).Select(e=>e.Event).ToArray();Check(Same(JsonSerializer.SerializeToElement(result.Events,json),JsonSerializer.SerializeToElement(events,json)),"All original event kinds, descriptions and full payloads replay exactly.");
 }
 Check((await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame,new CoreRuleEngine(),default)).Count==0,"Complete strict original recovery and replay pass, without a live room action.");
 totals["commands"]+=frame.Commands.Count;totals["events"]+=frame.Events.Count;totals["authority"]+=states.Count;outcomes.Add(new{room,actualAllSevenTableCounts=counts,allOriginalFieldsAndEveryHistoryAndReplayExact=true});
 NpgsqlCommand Query(NpgsqlConnection c,string sql){var q=new NpgsqlCommand(sql,c);q.Parameters.AddWithValue("room",room);return q;}
}
Check(totals["commands"]==3&&totals["events"]==3&&totals["authority"]==3&&totals["snapshots"]==4&&totals["prompts"]==4,"Exact two original network-room coverage, no ordinary full-game claim.");
var output=new{status="PASS_INDEPENDENT_FIXED55fdb_TWO_REAL_NETWORK_ROOMS_ALL_SEVEN_TABLES_THREE_ORIGINAL_PREFIXES_FOUR_PRIVATE_HISTORIES_AND_FULL_REPLAY",actualRuleInputs=RuleInputIdentity.Current,totals,rooms=outcomes,newPeerOnlyNoSnapshotRequestOrRetry=true,originalCanonicalNetworkExplicitSnapshotRequestsAndAll15GuardsRetained=true,actualReadOnlyConnection=true,noWriterRerunOrMatchMigration=true,notAdditionalFullGameVisibleOrPhysicalWindowsAcceptance=true};await File.WriteAllTextAsync(args[1],JsonSerializer.Serialize(output,json));Console.WriteLine(output.status);
bool Same(JsonElement a,JsonElement b)=>JsonNode.DeepEquals(JsonNode.Parse(a.GetRawText()),JsonNode.Parse(b.GetRawText()));
static JsonDocument Read(string path){using var zip=new GZipStream(File.OpenRead(path),CompressionMode.Decompress);return JsonDocument.Parse(zip);}
static void Check(bool value,string reason){if(!value)throw new Exception(reason);}
