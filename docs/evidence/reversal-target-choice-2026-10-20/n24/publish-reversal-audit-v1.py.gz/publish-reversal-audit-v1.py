import copy
import datetime
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import zipfile

work = Path(__file__).resolve().parent
root = work.parents[2]
fixed43 = root / 'var/qa/native-signalr-runtime-patch-fixed-43d5b84e-20261020'
fixed653 = root / 'var/qa/conditional-counter-payment-fixed-a653e547-20261020'
evidence = root / 'docs/evidence/reversal-target-choice-2026-10-20'
base = '43d5b84e867eb09ca0570ed8774832ce70b04d87'
identity = 'reversal-optional-target-choices-and-shared-control-2026-10-20'
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as out:
        out.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def pin(path, role=None):
    return {'path': str(path.relative_to(root)), 'sha256': sha(path), 'role': role or path.stem}

assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == base
assert not evidence.exists()
check = load(work / 'only-check-retention-and-disposition-v1.json')
assert check['passed'] == check['totalCases'] == 13166 and check['uniqueMethods'] == 7490
assert check['allSourceAndRuntimeInputsStableThroughTerminal'] and check['allOriginal13139CaseMultisetAnd7479MethodsPreserved']
sql = load(work / 'current-real-sql-combined-original-writer-and-independent-readback-v1.json')
assert sql['commands'] == 222 and sql['events'] == 1252 and sql['originalStates'] == 222
assert sql['originalPrivateSnapshots'] == sql['originalPrompts'] == 428
assert sql['allOriginal209Audit45NativeAndAfterReadAll213Audit45NativeSevenTablesExact']
native = load(fixed43 / 'fixed-native-visible-controls-and-normal-score-publication-v1.json')
assert native['commands'] == 80 and native['events'] == 533 and native['actualNativeCommands'] == 25
owner = load(fixed43 / 'fixed-native-control-owner-v1.json')
assert owner['ownApiGracefulExitCode'] == 0 and owner['ownPostgresSmartStopped'] and owner['boundIdleAssertionEnded']
assert owner['allOriginal209AuditSevenTablesExactAtStop'] and owner['allOriginal44NativeSevenTablesExactAtStop']
full653 = load(fixed653 / 'fixed-a653-full-ci-terminal-independent-original-readback-v1.json')
assert full653['actualCompletedSuccessfulJobs'] == 11 and full653['actualCases'] == 13288 and full653['actualUniqueMethods'] == 7620
tools = load(work / 'python-verification-tools-v2.json')
assert tools['exitCode'] == 0 and tools['actualTestsRun'] == 73
calibration = load(work / 'post-check-tool-manifest-identity-calibration-v2.json')
assert calibration['toolExitCode'] == 0 and calibration['allOther3311DeclaredSourcesAnd1401RuntimeFilesExactAfterToolTests']
assert sha(root / calibration['changedSourcePath']) == calibration['afterSha256']
manifest_path = root / 'docs/audit/current-manifest.json'
reviews_path = root / 'docs/evidence/rules-reaudit-2026-10-11/review-decisions.json'
prior, old_reviews = load(manifest_path), load(reviews_path)
assert len(prior['reviewContexts']) == 61 and len(prior['acceptanceGates']) == 239 and len(old_reviews['reviews']) == 146
original_ids = set(load(root / 'docs/evidence/native-signalr-runtime-patch-2026-10-20/remaining-obligation-ids.json'))
assert len(original_ids) == 16918 and not prior['semanticCoverageCertified']
for path, name in [(manifest_path, 'prior-entire-current-manifest.json.gz'), (reviews_path, 'prior-entire-review-decisions.json.gz')]:
    target = work / name
    assert not target.exists()
    target.write_bytes(gzip.compress(path.read_bytes(), mtime=0))

profiles = [fixed43 / 'session-a.json', fixed43 / 'session-b.json',
    fixed43 / 'actual-native-control-prefix-v1/session-native-a.json', fixed43 / 'actual-native-control-prefix-v1/session-native-b.json']
secrets = [load(p)[key].encode() for p in profiles for key in ['playerKey', 'reconnectToken']]
assert len(secrets) == 8 and all(len(s) > 10 for s in secrets)
source_exts = {'.py', '.cs', '.csproj', '.gd', '.c', '.trx', '.log', '.ndjson', '.md', '.txt'}
raw_exts = {'.json', '.gz', '.png', '.jpg', '.jpeg', '.webp', '.zip'}
excluded = {'bin', 'obj', '__pycache__', 'data', 'Fixtures', 'Sql', 'fixed-api', 'reader-runtime',
    'current-payment-reader-runtime-v3', 'normal-score-reader-runtime-v4', 'runtime', 'runtime-v3', 'runtime-v4', 'native-payment-prefix'}
archive = []

def archive_file(path, group, folder, verify_only):
    rel = path.relative_to(folder)
    if (path in profiles or path.name.startswith('session-') or 'draft' in path.name
        or any(p in excluded or p.endswith('.app') or p.startswith(('out-v', 'sql-runtime-', 'sql-readonly-runtime-', 'sql-independent-reader-build-')) for p in rel.parts)
        or path.name.endswith(('.deps.json', '.runtimeconfig.json'))
        or path.name in {'mac-ci-artifact.zip', 'windows-ci-artifact.zip'} or path.suffix not in source_exts | raw_exts):
        return
    raw = path.read_bytes()
    if path.suffix == '.gz':
        blocks = [gzip.decompress(raw)]
    elif path.suffix == '.zip' and not raw:
        # Retain the documented original failed zero-byte network download as a
        # failed download, never as an inspected successful archive.
        assert path.name == '39397913669-native-network-results.zip'
        blocks = [raw]
    elif path.suffix == '.zip':
        with zipfile.ZipFile(path) as z:
            assert z.testzip() is None
            blocks = [z.read(n) for n in z.namelist() if not n.endswith('/')]
    else:
        blocks = [raw]
    assert not any(s in b for s in secrets for b in blocks), str(rel)
    if verify_only:
        return
    compressed = path.suffix in source_exts
    target = evidence / group / rel
    if compressed:
        target = target.with_name(target.name + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    assert not target.exists()
    if compressed:
        target.write_bytes(gzip.compress(raw, mtime=0))
    else:
        os.link(path, target)
    assert (gzip.decompress(target.read_bytes()) if compressed else target.read_bytes()) == raw
    assert target.stat().st_size < 10 * 2**20
    archive.append({'originalPath': str(path.relative_to(root)), 'originalSha256': sha(path), 'originalBytes': len(raw),
        'canonical': pin(target), 'gzipOriginalBytes': compressed, 'samePhysicalFileHardlinked': not compressed})

inputs = []
for folder, group in [(work, 'n24'), (fixed43, 'fixed43')]:
    inputs.extend((p, group, folder) for p in sorted(folder.rglob('*')) if p.is_file())
for p in fixed653.glob('*'):
    if p.is_file() and (p.name.startswith('fixed-a653-') or p.name.startswith('verify-fixed-a653-')):
        inputs.append((p, 'fixed-a653-terminal', fixed653))
for p in sorted((fixed653 / 'ci-originals').glob('39383332057-*.zip')):
    inputs.append((p, 'fixed-a653-terminal', fixed653))
for verify_only in [True, False]:
    for p, group, folder in inputs:
        archive_file(p, group, folder, verify_only)
write(evidence / 'archive-map.json', {'records': archive, 'allOriginalBytesAndHashesVerified': True,
    'eightPrivateProfileValuesScannedWithoutDisclosure': True, 'authRuntimeInstallSdkDatabaseAndCacheExcluded': True,
    'originalFailuresSourcesTrxFramesAndActualVisibleCapturesRetained': True})

def archived(name, role=None, group='n24'):
    return pin(evidence / group / name, role)

check_pin = archived('only-check-retention-and-disposition-v1.json', 'check')
sql_pin = archived('current-real-sql-combined-original-writer-and-independent-readback-v1.json', 'ordinary-real-sql')
matrix_pin = archived('bounded-five-branch-actual27-case-matrix-v1.json', 'actual-case-matrix')
source_pin = archived('bounded-current-official-source-readback-v1.json', 'bounded-current-primary-sources')
visual_pin = archived('exact-current-visual-and-clause-scope-v1.json', 'actual-card-faces-and-exact-clause-scope')
native_pin = archived('fixed-native-visible-controls-and-normal-score-publication-v1.json', 'preceding-fixed43-native', 'fixed43')
full653_pin = archived('fixed-a653-full-ci-terminal-independent-original-readback-v1.json', 'preceding-fixed-a653-full', 'fixed-a653-terminal')
full43_path = evidence / 'fixed43/fixed43-full-ci-terminal-independent-original-readback-v1.json'
full43_pin = pin(full43_path, 'preceding-fixed43-full') if full43_path.exists() else None
partial43_pin = archived('fixed43-completed-sql-and-network-original-readback-v1.json', 'preceding-fixed43-completed-sql-and-network', 'fixed43')
impl = ['src/Riftbound.Engine/CardBehaviorRegistry.cs', 'src/Riftbound.Engine/CoreRuleEngine.cs', 'src/Riftbound.Engine/CoreRuleEngine.SpellChoiceControl.cs']
verify = ['tests/Riftbound.ConformanceTests/ReversalTargetChoiceTests.cs', 'tests/Riftbound.ConformanceTests/ReversalTargetChoiceOpeningTests.cs',
    'tests/Riftbound.ConformanceTests/Fixtures/reversal-target-openings.json', 'tests/Riftbound.PostgresAcceptance/ReversalTargetChoiceSqlAcceptance.cs',
    'tests/Riftbound.PostgresAcceptance/Program.cs', 'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json',
    'tests/Riftbound.PostgresAcceptance/Riftbound.PostgresAcceptance.csproj', 'scripts/tests/test_sql_ci_gate.py']
source_manifest = {'recordedAtUtc': now(), 'scope': 'CN exact OGN080 optional new-target grant, shared control/remake and explicitly recorded branches only.',
    'region': 'CN', 'language': 'zh-CN', 'observedAt': '2026-10-20', 'adoptedCoreEffectiveDate': '2026-10-16',
    'exactPrinting': 'OGN·080/298', 'exactApiId': 31296, 'singlePrintingPublishedAt': None, 'singlePrintingEffectiveAtIndependentlyVerified': None,
    'baseCommit': base, 'includesUncommittedImplementation': True, 'currentSources': source_pin, 'actualVisualAndClauseScope': visual_pin,
    'implementation': [pin(root / p, 'implementation') for p in impl], 'verificationSources': [pin(root / p, 'verification-source') for p in verify],
    'soleCheck': check_pin, 'postCheckVerificationOnlyCalibration': archived('post-check-tool-manifest-identity-calibration-v2.json', 'post-check-tools-only'),
    'actual27CaseFiveBranchMatrix': matrix_pin, 'actualCurrentReleaseFourBranchSql': sql_pin,
    'actualCurrentReleaseRuleInputs': sql['actualRuleInputs'], 'oldFixtureFiveIntentsElevenEventsAllAssertionsAndSeedRetained': True,
    'originalFullGameMethods': 143, 'originalPairs': 110, 'originalDecks': 11, 'originalSeed': 424242,
    'original46SqlCasesAndOrderPreservedWith47thAppend': True, 'currentNativeFullCiAndPhysicalWindows': 'OPEN_NEW_FIXED_CANDIDATE',
    'precedingFixed43Native': native_pin, 'precedingA653ActualFull': full653_pin, 'precedingFixed43ActualFull': full43_pin,
    'precedingFixed43CompletedSqlAndNetwork': partial43_pin,
    'newGameSourceDelta': False, 'sixOriginalGameSourceDeltasAndAllOriginalGapsRetained': True,
    'onlyLatestUsableNativePairAndOneInstallerPerOs': True, 'noNewSdkWholeCheckoutOrDatabase': True,
    'wholePrintingFamilyAndGlobalSemanticsCertified': False}
write(evidence / 'source-manifest.json', source_manifest)
manifest_pin = pin(evidence / 'source-manifest.json', 'source-manifest')
doc = (work / 'reversal-target-choice-audit-draft-v1.md').read_text()
doc = doc.replace('@CHECK@', '13166 例/7490 方法全过、零失败零跳过，原13139例/7479方法完整保留；新增27例/11方法，3312源码/1401执行载荷检查期间精确不变，无第二次check')
doc = doc.replace('@CI43@', '实际11项success，八份原结果独立核对13288例/7620方法、143完整方法/110配对、46SQL/251输出、网络15拒绝零泄露，与a653全部用例/方法精确相同；不覆盖本批新改动，按同目录收据限定使用' if full43_pin else '最后原始观察仍在运行；已完成子任务的成功不代替整体终态，按原收据继续核对')
doc = doc.replace('@TOOLS@', '最终全部73项验证工具测试实际通过，原72过/1失败记录及完整旧源码保留，补充收据明确绑定check后唯一验证文件变化')
assert '@CHECK@' not in doc and '@CI43@' not in doc and '@TOOLS@' not in doc
document_path = root / 'docs/REVERSAL_TARGET_CHOICE_AUDIT_2026-10-20.md'
assert not document_path.exists()
document_path.write_text(doc)
matrix = load(work / 'bounded-five-branch-actual27-case-matrix-v1.json')
rule_refs = ['CN-d6fd7140f106f9b5-P111-B0' + str(n) for n in range(16, 25)] + ['CN-d6fd7140f106f9b5-P116-B020', 'CN-d6fd7140f106f9b5-P116-B022']
reviews = copy.deepcopy(old_reviews)
reviews['reviews'].append({'id': identity, 'scope': source_manifest['scope'], 'status': 'LIMITED27_FOCUS_CHECK13166_SQL4_PASS_NEW_FIXED_FULL_NATIVE_WINDOWS_OPEN',
    'subjects': ['OGN-080/298', 'VEN-152'], 'ruleRecords': rule_refs, 'pendingRuleRecords': [], 'sourceManifest': manifest_pin,
    'auditDocument': str(document_path.relative_to(root)), 'validation': {'boundedNewCases': 27, 'newMethods': 11, 'adjacentCases': 254,
        'originalFullGamesInAdjacentFocus': 2, 'soleCheckCases': 13166, 'soleCheckMethods': 7490, 'ordinaryRealSqlBranches': 4,
        'allOriginalMethodsTheoriesSeedsVictoryReplayAssertionsRetained': True},
    'exclusions': matrix['explicitRemaining'] + ['WHOLE_PRINTING_FAMILY_AND_ALL_SOURCE_GAPS']})
reviews_path.write_text(json.dumps(reviews, ensure_ascii=False, indent=2) + '\n')
spec = importlib.util.spec_from_file_location('governance', root / 'scripts/audit/check-project-governance.py')
checker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checker)
revision = checker.digest(checker.gameplay_inputs(root))
manifest = copy.deepcopy(prior)
prior_pin = archived('prior-entire-current-manifest.json.gz', 'prior-entire-manifest')
updates = []
for key, context in manifest['reviewContexts'].items():
    changes = []
    for field in ['implementation', 'verificationSources']:
        for ref in context.get(field, []):
            actual = sha(root / ref['path'])
            if actual != ref['sha256']:
                changes.append({'field': field, 'path': ref['path'], 'previousSha256': ref['sha256'], 'currentSha256': actual})
                ref['sha256'] = actual
    previous = {f: context.get(f) for f in ['currentInputRevision', 'currentImplementationCommit', 'currentImplementationIncludesUncommittedChanges', 'ciState']}
    context.setdefault('implementationPinUpdates', []).append({'batch': identity, 'changes': changes,
        'previousCurrentMetadata': previous, 'previousEntireContextPreservedIn': prior_pin,
        'scope': 'Finite shared spell control/optional retarget change and explicit old command-flow additions. No old evidence, source universe or whole-card certification upgraded.'})
    context.update(currentInputRevision=revision, currentImplementationCommit=base, currentImplementationIncludesUncommittedChanges=True,
        ciState='PENDING', revalidationReason='Shared control/remake implementation changed; previous fixed CI/native source identity does not cover this candidate.')
    updates.append({'review': key, 'previousEntireContextSha256': checker.digest(prior['reviewContexts'][key]), 'changedPins': changes})
branches = []
for branch in matrix['branches']:
    branches.append({**branch, 'sourceRefs': ['OGN-080/298', 'VEN-152'] + rule_refs, 'sourceManifest': manifest_pin,
        'state': 'RECORDED', 'decision': {'state': 'OPEN', 'reason': 'Bounded exact source, tests and ordinary SQL only; new fixed full/current visible product/Windows and remaining printing branches stay open.'},
        'implementation': 'FINITE_EXISTING_SERVER_AUTHORITATIVE_CONTROL_AND_RULE_CHOICE_FLOW', 'testExecution': 'ACTUAL27_CASES11_METHODS_AND_CHECK13166_PASS',
        'ordinaryRealSql': sql_pin, 'actualTestMatrix': matrix_pin, 'actualCaseKeys': branch['caseKeys'], 'actualMethodNames': branch['methodNames'],
        'remaining': matrix['explicitRemaining']})
manifest['inputs']['reviews'] = pin(reviews_path, prior['inputs']['reviews'].get('role', 'reviews'))
manifest['reviewContexts'][identity] = {'evidenceCommit': base, 'currentImplementationCommit': base,
    'currentImplementationIncludesUncommittedChanges': True, 'currentInputRevision': revision, 'ciState': 'PENDING', 'ciReceipts': [],
    'evidenceCommitScope': 'Base43 plus declared current uncommitted implementation/tests/fixture/SQL; preceding fixed43 product remains separately bound.',
    'region': 'CN', 'language': 'zh-CN', 'applicableAsOf': '2026-10-20', 'adoptedCoreEffectiveDate': '2026-10-16', 'sourceManifest': manifest_pin,
    'implementation': source_manifest['implementation'], 'verificationSources': source_manifest['verificationSources'],
    'evidence': [source_pin, visual_pin, check_pin, sql_pin, matrix_pin, native_pin, full653_pin, partial43_pin] + ([full43_pin] if full43_pin else []), 'branches': branches}
manifest['acceptanceGates'] += [
    {'id': 'REVERSAL_TARGET_CHOICES_CURRENT_FIXED_FULL_NATIVE_PAIRED_SQL_RECONNECT_NORMAL_SCORE_REPLAY_AND_WINDOWS', 'state': 'OPEN',
     'requirement': 'New fixed full with all original methods/theories143fullmethods110pairs/seeds47SQL, current visible native paired controls/SQL/reconnect/normal score/full original replay and physical Windows; no whole-printing promotion.', 'sourceManifest': manifest_pin},
    {'id': 'REVERSAL_REMAINING_ECHO_BASE_DESTINATION_OTHER_TARGET_CONSUMERS_PRINTINGS_SOURCE_APPLICABILITY', 'state': 'OPEN',
     'requirement': 'Retain exact source/date/format/printing universe; review self-granted Echo capability, relative base destination restrictions, no-legal-new-choice rule753.2, exact native heading issue75 and all other target/consumer branches. Existing rejection/registration is not official semantic certification.', 'sourceManifest': manifest_pin}]
manifest['currentReversalOptionalTargetChoiceInputChange'] = manifest_pin
manifest['precedingFixed43ActualPatchedVisibleNativeReadback'] = native_pin
manifest['precedingFixedA653ActualFullCiReadback'] = full653_pin
manifest['precedingFixed43CompletedSqlAndNetworkReadback'] = partial43_pin
if full43_pin:
    manifest['precedingFixed43ActualFullCiReadback'] = full43_pin
result = checker.current_audit(root, manifest)
assert result['governanceValid'], result['errors']
ids = {row['id'] for row in result['remainingObligations']}
assert original_ids <= ids and len(ids) == 16925
assert reviews['reviews'][:-1] == old_reviews['reviews']
assert manifest['laterSourceDeltas'] == prior['laterSourceDeltas'] and len(prior['laterSourceDeltas']) == 6
assert manifest['acceptanceGates'][:239] == prior['acceptanceGates']
assert len(manifest['reviewContexts']) == 62 and len(manifest['acceptanceGates']) == 241
manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
write(evidence / 'remaining-obligation-ids.json', sorted(ids))
write(evidence / 'current-context-rebindings.json', {'priorEntireManifest': prior_pin, 'allOriginal61ScopesAndEvidenceRetained': True,
    'newInputRevision': revision, 'changedContexts': [u for u in updates if u['changedPins']]})
write(evidence / 'unified-obligation-retention.json', {'priorReviews': 146, 'currentReviews': 147, 'priorContexts': 61, 'currentContexts': 62,
    'priorGates': 239, 'currentGates': 241, 'priorObligations': 16918, 'currentObligations': len(ids), 'allOriginalIdsRetained': True,
    'allOriginal146Reviews239GatesAndSixGameSourceDeltasExact': True, 'allOriginal1740Printings14293RuleBlocksEn8GapCn236DispositionsRetained': True,
    'newFiveBranchesAndTwoExplicitAcceptanceGates': True, 'semanticCoverageCertified': False})
compact = {k: v for k, v in result.items() if k not in ['inputManifest', 'reviewView', 'remainingObligations', 'laterSourceDeltas']}
compact['remainingObligationCount'] = len(ids)
write(evidence / 'governance-validation.json', compact)
status_path = root / 'docs/PROJECT_STATUS.md'
marker = '# 当前项目状态\n\n'
status = status_path.read_text()
assert status.startswith(marker)
lead = (work / 'project-status-lead-draft-v1.md').read_text().replace('@TOOLS@', '最终73项工具测试实际通过，原失败及旧源码完整保留')
assert '@TOOLS@' not in lead
status_path.write_text(marker + lead + '\n' + status[len(marker):])
print(json.dumps({'status': 'PUBLISHED_BOUNDED_REVERSAL_AND_SEPARATE_PRECEDING_FIXED43_ACCEPTANCE',
    'archivedOriginals': len(archive), 'reviews': 147, 'contexts': 62, 'gates': 241, 'obligations': len(ids), 'globalSemanticsCertified': False}), flush=True)
