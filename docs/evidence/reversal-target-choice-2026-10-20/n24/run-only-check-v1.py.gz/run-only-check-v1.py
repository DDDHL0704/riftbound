import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

work = Path(__file__).resolve().parent
root = work.parents[2]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
publication = json.loads((work / 'frozen-sql-publication-inputs-v1.json').read_text())
focus = json.loads((work / 'focus-current-ordinary-and-boundaries-v5/summary.json').read_text())
positive = json.loads((work / 'current-real-sql-combined-original-writer-and-independent-readback-v1.json').read_text())
assert focus['status'] == 'PASSED' and focus['total'] == 27
assert positive['status'] == 'PASS_FOUR_ORIGINAL_ORDINARY_SQL_BRANCHES_AND_SEPARATE_INDEPENDENT_READONLY_FULL_REPLAY'
assert positive['commands'] == 222 and positive['events'] == 1252
assert positive['allOriginal209Audit45NativeAndAfterReadAll213Audit45NativeSevenTablesExact']
assert positive['originalDatabaseRetainedAndNormallyStopped']
assert not (work / 'only-check').exists()
inputs = publication['sourceInputHashes']
assert all(sha(root / p) == h for p, h in inputs.items())
folder = root / 'tests/Riftbound.ConformanceTests/bin/Debug/net10.0'
runtime = {str(p.relative_to(root)): sha(p) for p in sorted(folder.rglob('*')) if p.is_file()
           and (p.suffix in {'.dll', '.pdb'} or p.name.endswith(('.deps.json', '.runtimeconfig.json'))
                or p.is_relative_to(folder / 'data') or p.is_relative_to(folder / 'Fixtures'))}
baseline = root / 'var/qa/native-signalr-runtime-patch-20261020/only-check/check/results.trx'
assert sha(baseline) == '1d37239a3764b84f15f4bd8bd17fad58110b46f509fb8c393c0cff18982167c2'
start = {'atUtc': now(), 'baseCommit': publication['baseCommit'], 'sourceInputHashes': inputs,
         'sourceInputCount': len(inputs), 'actualConformanceRuntimeFileHashes': runtime,
         'actualConformanceRuntimeFileCount': len(runtime), 'unchangedOriginalCaseBaseline': str(baseline.relative_to(root)),
         'unchangedOriginalCaseBaselineSha256': sha(baseline), 'onlyOneCheckForThisReversalBatch': True,
         'currentFocus27FourOrdinaryBranchesAndIndependentRealSqlPassed': True,
         'currentDefaultHostRuntimeList': subprocess.check_output(['/Users/dinghaolin/.dotnet/dotnet', '--list-runtimes'], text=True),
         'currentSdkList': subprocess.check_output(['/Users/dinghaolin/.dotnet/dotnet', '--list-sdks'], text=True),
         'separateFrozenNativeCandidateAndCiDoNotUseThisRootBin': True}
with (work / 'only-check-start-inputs-v1.json').open('x') as stream:
    stream.write(json.dumps(start, indent=2) + '\n')
power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())])
code = None
try:
    environment = dict(os.environ)
    environment.pop('ConnectionStrings__Riftbound', None)
    environment.pop('DOTNET_STARTUP_HOOKS', None)
    with (work / 'only-check-runner-v1.log').open('xb') as log:
        code = subprocess.run(['python3', str(root / 'scripts/test-rules.py'), 'check', '--jobs', '3',
            '--output', str(work / 'only-check')],
            cwd=root, stdout=log, stderr=subprocess.STDOUT, env=environment).returncode
finally:
    if power.poll() is None:
        power.terminate()
        power.wait(timeout=10)
    changed_source = [p for p, h in inputs.items() if not (root / p).is_file() or sha(root / p) != h]
    changed_runtime = [p for p, h in runtime.items() if not (root / p).is_file() or sha(root / p) != h]
    changed_modes = [p for p, m in publication['sourceInputModes'].items() if oct((root / p).stat().st_mode & 0o777) != m]
    terminal = {'finishedAtUtc': now(), 'checkExitCode': code,
        'changedSourceInputs': changed_source, 'changedConformanceRuntimeFiles': changed_runtime,
        'changedSourceModes': changed_modes, 'allDeclaredSourceAndRuntimeInputsStable': not changed_source and not changed_runtime and not changed_modes,
        'boundIdleAssertionEnded': power.poll() is not None, 'noSecondCheck': True,
        'sourceManifestSha256': sha(work / 'only-check-start-inputs-v1.json')}
    with (work / 'only-check-terminal-integrity-v1.json').open('x') as stream:
        stream.write(json.dumps(terminal, indent=2) + '\n')
assert not changed_source and not changed_runtime and not changed_modes
print('SOLE_REVERSAL_BATCH_CHECK_FINISHED_EXIT_' + str(code), flush=True)
sys.exit(code if code is not None else 1)
