import ast
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import plistlib
import subprocess

os.umask(0o077)
work = Path(__file__).resolve().parent
root = work.parents[2]
runtime = work / 'sql-readonly-runtime-v2'
pg = Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin')
cluster = root / 'var/qa/permanent-play-here-base-20261017/postgres'
sock = Path('/tmp/rft-here-family-20261018-55486')
tables = ['matches', 'match_players', 'command_log', 'game_events', 'state_snapshots', 'snapshots', 'action_prompts']
read_env = dict(os.environ, PGOPTIONS='-c default_transaction_read_only=on')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
publication_path = work / 'frozen-readonly-publication-inputs-v2.json'
publication = json.loads(publication_path.read_text())
original = json.loads((work / 'frozen-sql-publication-inputs-v1.json').read_text())
baseline = json.loads((work / 'after-four-writers-before-readonly-baseline-v1.json').read_text())
output = work / 'independent-original-four-sql-readonly-verification-v2.json'
assert not output.exists()
guard_source = work.parent / 'graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes = [n for n in ast.parse(guard_source.read_text()).body if isinstance(n, ast.FunctionDef)
         and n.name in {'query', 'rooms', 'digests', 'observe_lock'}]
assert len(nodes) == 4
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(guard_source), 'exec'), globals())

def write(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)

def frozen():
    assert all(sha(runtime / p) == h for p, h in publication['runtimeFiles'].items())
    assert all(sha(work / 'sql-runtime-v1' / p) == h for p, h in original['runtimeFiles'].items())
    assert all(sha(root / p) == h for p, h in original['sourceInputHashes'].items())
    assert all(oct((root / p).stat().st_mode & 0o777) == m for p, m in original['sourceInputModes'].items())
    assert all(sha(work / p) == h for p, h in publication['readerSourceHashes'].items())
    assert json.loads(subprocess.check_output(publication['readerCommand'] + ['identity-print'], cwd=runtime, text=True)) == original['actualRuleInputs']

frozen()
guard = (root / 'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a')
fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
proof = {'status': 'RUNNING_NOT_ACCEPTANCE', 'startedAtUtc': now(), 'actualRuleInputs': original['actualRuleInputs'],
         'scope': 'Independent read-only verification of the same four original writer rooms; no new game or writer rerun.',
         'originalPublicationSha256': sha(work / 'frozen-sql-publication-inputs-v1.json'),
         'readonlyPublicationSha256': sha(publication_path), 'priorFailedReaderAndAllOriginalHistoryRetained': True,
         'lockAtStart': observe_lock(), 'visibleNativeAndPhysicalWindows': 'OPEN'}
write(output, proof)
started = False
power = process = None
try:
    assert subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), 'status'], capture_output=True).returncode == 3
    power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())])
    proof.update(ownRunnerPid=os.getpid(), boundIdleAssertionPid=power.pid)
    sock.mkdir(exist_ok=True)
    subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-l', str(work / 'own-postgres-readonly-v2.log'),
                    '-o', f'-p 55486 -h 127.0.0.1 -k {sock}', '-w', 'start'], check=True, capture_output=True)
    started = True
    assert rooms('riftbound_acceptance') == baseline['auditRooms'] and len(baseline['auditRooms']) == 213
    assert rooms('riftbound_here_native') == baseline['nativeRooms'] and len(baseline['nativeRooms']) == 45
    assert digests('riftbound_acceptance', baseline['auditRooms']) == baseline['auditSevenTables']
    assert digests('riftbound_here_native', baseline['nativeRooms']) == baseline['nativeSevenTables']
    proof.update(all213Audit45NativeSevenTablesExactBeforeRead=True)
    write(output, proof)
    env = dict(os.environ, ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit')
    log_path = work / 'independent-actual-original-four-sql-reader-v2.log'
    with log_path.open('x') as log:
        process = subprocess.Popen(publication['readerCommand'] + ['independent-readonly',
            str(work / 'actual-sql-partition-v1/reversal-target-choice')], cwd=runtime, env=env, stdout=log, stderr=subprocess.STDOUT)
        proof['ownReadonlyReaderPid'] = process.pid
        write(output, proof)
        code = process.wait(timeout=3600)
    assert code == 0, code
    result = json.loads(log_path.read_text())
    assert result['status'] == 'PASS_INDEPENDENT_READONLY_REAL_POSTGRES_FOUR_REVERSAL_ORIGINALS'
    assert result['actualRuleInputs'] == original['actualRuleInputs'] and len(result['checks']) == 4
    assert {(c['format'], c['remake']) for c in result['checks']} == {
        (f, r) for f in ['CoreRules', 'ChinaStandard20260724'] for r in [False, True]}
    assert sum(c['commands'] for c in result['checks']) == 222 and sum(c['events'] for c in result['checks']) == 1252
    assert sum(c['actualHistoricalPayloads']['state_snapshots'] for c in result['checks']) == 222
    assert sum(c['actualHistoricalPayloads']['snapshots'] for c in result['checks']) == 428
    assert sum(c['actualHistoricalPayloads']['action_prompts'] for c in result['checks']) == 428
    assert all(c['allOriginalFieldsNullsAndPrivateHistoryMatch'] and c['original49IntentPayloadsAndActorsExact']
               and c['fullOriginalReplayMatched'] for c in result['checks'])
    assert rooms('riftbound_acceptance') == baseline['auditRooms'] and rooms('riftbound_here_native') == baseline['nativeRooms']
    assert digests('riftbound_acceptance', baseline['auditRooms']) == baseline['auditSevenTables']
    assert digests('riftbound_here_native', baseline['nativeRooms']) == baseline['nativeSevenTables']
    proof.update(status='PASS_SAME_FOUR_ORIGINAL_SQL_ROOMS_INDEPENDENT_ALL_FIELDS_NULL_HISTORY_AND_FULL_REPLAY',
                 commands=222, events=1252, originalStates=222, originalPrivateSnapshots=428, originalPrompts=428,
                 all213Audit45NativeSevenTablesExactAfterRead=True, originalResultSha256=sha(log_path))
except BaseException as error:
    proof.update(status='FAILED_OR_INTERRUPTED_ORIGINAL_HISTORY_RETAINED', errorType=type(error).__name__, errorMessage=str(error))
    raise
finally:
    if process is not None and process.poll() is None:
        process.terminate()
        process.wait(timeout=30)
    if started:
        proof['all213Audit45NativeSevenTablesExactAtStop'] = (
            digests('riftbound_acceptance', baseline['auditRooms']) == baseline['auditSevenTables']
            and digests('riftbound_here_native', baseline['nativeRooms']) == baseline['nativeSevenTables'])
        proof['ownPostgresSmartStopped'] = subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-m', 'smart', '-w', '-t', '20', 'stop'], capture_output=True).returncode == 0
    if power is not None:
        if power.poll() is None:
            power.terminate()
            power.wait(timeout=10)
        proof['boundIdleAssertionEnded'] = power.poll() is not None
    frozen()
    proof.update(finishedAtUtc=now(), lockAtEnd=observe_lock(), allOriginalSourcesRuntimeAndReaderInputsExact=True,
                 originalDatabaseRetained=cluster.exists())
    write(output, proof)
    fcntl.flock(guard, fcntl.LOCK_UN)
print(proof['status'], flush=True)
