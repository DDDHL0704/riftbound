import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess

work = Path(__file__).resolve().parent
root = work.parents[2]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
retention = load(work / 'only-check-retention-and-disposition-v1.json')
assert retention['passed'] == 13166 and retention['uniqueMethods'] == 7490
assert retention['allSourceAndRuntimeInputsStableThroughTerminal']
start = load(work / 'only-check-start-inputs-v1.json')
assert all(sha(root / p) == h for p, h in start['sourceInputHashes'].items())
assert all(sha(root / p) == h for p, h in start['actualConformanceRuntimeFileHashes'].items())
plan = load(work / 'post-check-tool-count-and-last-identity-calibration-plan-v2.json')
path = root / plan['path']
assert sha(path) == plan['originalSha256']
text = path.read_text()
assert text.count(plan['exactOldBlock']) == 1
original = work / 'original-tool-sql-ci-guard-before47-append-calibration.py.gz'
assert not original.exists() and not (work / 'python-verification-tools-v2.log').exists()
original.write_bytes(gzip.compress(path.read_bytes(), mtime=0))
path.write_text(text.replace(plan['exactOldBlock'], plan['exactNewBlock'], 1))
assert path.read_text() == text.replace(plan['exactOldBlock'], plan['exactNewBlock'], 1)
with (work / 'python-verification-tools-v2.log').open('xb') as log:
    code = subprocess.run(['python3', '-m', 'unittest', 'discover', '-s', 'scripts/tests', '-v'], cwd=root,
        stdout=log, stderr=subprocess.STDOUT).returncode
raw = (work / 'python-verification-tools-v2.log').read_text()
count = int(re.search(r'^Ran (\d+) tests in ', raw, re.MULTILINE).group(1))
result = {'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exitCode': code,
    'actualTestsRun': count, 'originalFailurePreserved': 'python-verification-tools-v1.log',
    'logSha256': sha(work / 'python-verification-tools-v2.log'),
    'scope': 'All verification tooling tests; these synthetic unit fixtures do not constitute real database or gameplay certification.'}
with (work / 'python-verification-tools-v2.json').open('x') as out:
    out.write(json.dumps(result, indent=2) + '\n')
changed = [p for p, h in start['sourceInputHashes'].items() if sha(root / p) != h]
assert changed == [plan['path']], changed
assert all(sha(root / p) == h for p, h in start['actualConformanceRuntimeFileHashes'].items())
receipt = {'status': 'PASS_POST_CHECK_TOOL_ONLY_DEFAULT_SQL47_COUNT_AND_EXACT_LAST_TWO_IDS_CALIBRATION' if code == 0 else 'FAILED_POST_CHECK_TOOL_CALIBRATION_ORIGINAL_RETAINED',
    'atUtc': result['atUtc'], 'changedSourcePath': plan['path'], 'beforeSha256': plan['originalSha256'], 'afterSha256': sha(path),
    'originalSourceGzipSha256': sha(original), 'actualSourceDiff': subprocess.check_output(['git', 'diff', '--', plan['path']], cwd=root, text=True),
    'checkReceiptSha256': sha(work / 'only-check-retention-and-disposition-v1.json'),
    'allOther3311DeclaredSourcesAnd1401RuntimeFilesExactAfterToolTests': True,
    'originalDefault46IdentitiesAndOrderRemainRequiredWith47thAppend': True,
    'oldConditionalCounterIdentityGuardPreservedAtPenultimatePosition': True,
    'newFinalReversalIdentityExplicitlyRequired': True,
    'allOriginalMethodsAndOtherSafetyGuardsRetained': True,
    'toolTestCount': count, 'toolExitCode': code, 'noSecondCheck': True,
    'finalFixedFullMustVerifyFinalSource': True, 'gameplayOrNewNativeCertification': False}
with (work / 'post-check-tool-manifest-identity-calibration-v2.json').open('x') as out:
    out.write(json.dumps(receipt, indent=2) + '\n')
assert code == 0 and count == 73
print(receipt['status'], count, flush=True)
