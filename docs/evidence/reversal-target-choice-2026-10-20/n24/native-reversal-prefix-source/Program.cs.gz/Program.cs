using System.Collections.Concurrent;
using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using Riftbound.Contracts;
using Riftbound.GodotClient;

if (!OperatingSystem.IsMacOS()) throw new Exception("This bounded runner audits the existing Mac production client only.");
if (args.Length != 3) throw new Exception("Exact own API URL, fresh evidence directory and existing latest profile directory required.");
var server = args[0]; var output = Path.GetFullPath(args[1]); var profiles = Path.GetFullPath(args[2]);
if (server != "http://127.0.0.1:15847" || Directory.Exists(output)) throw new Exception("Own loopback API and fresh original evidence required.");
Directory.CreateDirectory(output);
using var deadline = new CancellationTokenSource(TimeSpan.FromMinutes(12)); var ct = deadline.Token;
var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
var room = "N24-RETARGET-" + Guid.NewGuid().ToString("N")[..10].ToUpperInvariant();
var originalProfiles = new[] { "a", "b" }.Select(label => JsonNode.Parse(File.ReadAllText(Path.Combine(profiles, "session-" + label + ".json")))!).ToArray();
using var trace = new WireTrace(Path.Combine(output, "original-private-native-wire-snapshots-prompts.ndjson.gz"));
await using var a = new Side(server, room, originalProfiles[0], trace, ct);
await using var b = new Side(server, room, originalProfiles[1], trace, ct);
var sides = new[] { a, b }; var accepted = new List<object>();
await a.Connect(); await b.Connect();
using var fixture = JsonDocument.Parse(File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "Fixtures/reversal-target-openings.json")));
var decks = fixture.RootElement.GetProperty("openingIntents").EnumerateArray().Take(2).ToArray();
for (var i = 0; i < 2; i++) await Submit(sides[i], JsonNode.Parse(decks[i].GetProperty("rawCommand").GetRawText())!.AsObject());
foreach (var side in sides) await Submit(side, new() { ["cmdType"] = "READY" });
for (var i = 0; i < 2; i++)
{
    await Until(() => sides.Any(s => s.Enabled("MULLIGAN")), "actual server mulligan owner");
    await Submit(sides.Single(s => s.Enabled("MULLIGAN")), new() { ["cmdType"] = "MULLIGAN", ["handObjectIds"] = new JsonArray() });
}
var reached = false;
for (var i = 0; i < 76; i++)
{
    var side = sides.Single(s => s.Enabled("END_TURN"));
    if (Unit(side) is null && Hand(side, "OGN·052/298").FirstOrDefault() is { } source && Runes(side).Length + Mana(side) >= 2)
    {
        foreach (var rune in Runes(side).Take(Math.Max(0, 2 - Mana(side))).ToArray()) await Submit(side, new() { ["cmdType"] = "TAP_RUNE", ["sourceObjectId"] = rune });
        await Submit(side, new() { ["cmdType"] = "PLAY_CARD", ["sourceObjectId"] = source, ["cardNo"] = "OGN·052/298", ["targetObjectIds"] = new JsonArray() });
    }
    if (side == b && Hand(a, "OGN·095/298").Length > 0 && Hand(b, "OGN·080/298").Length > 0
        && Unit(a) is not null && Unit(b) is not null && Runes(b).Length >= 4 && GreenRunes(b).Length >= 3)
    { reached = true; break; }
    await Submit(side, new() { ["cmdType"] = "END_TURN" });
}
Check(reached, "Natural original opening must provide both real units and spells without state or private-seed injection.");
// Retain enough real deck for the later normal-score acceptance; late original
// rooms remain preserved as partial evidence rather than being reset or seeded.
Check(Own(a).GetProperty("zones").GetProperty("mainDeckCount").GetInt32() >= 9
    && Own(b).GetProperty("zones").GetProperty("mainDeckCount").GetInt32() >= 9,
    "Original deck must still permit normal score continuation without deck exhaustion.");
await Submit(b, new() { ["cmdType"] = "END_TURN" });
await Submit(a, new() { ["cmdType"] = "TAP_RUNE", ["sourceObjectId"] = Runes(a).First() });
var targetSource = Hand(a, "OGN·095/298")[0]; var counter = Hand(b, "OGN·080/298")[0];
var oldTarget = Unit(b)!; var newTarget = Unit(a)!;
await Submit(a, new() { ["cmdType"] = "PLAY_CARD", ["sourceObjectId"] = targetSource, ["cardNo"] = "OGN·095/298", ["targetObjectIds"] = new JsonArray(oldTarget) });
await Submit(a, new() { ["cmdType"] = "PASS_PRIORITY" });
Check(Priority() == b.Handle, "Only actual response priority grants the production control spell.");
foreach (var rune in Runes(b).Take(4).ToArray()) await Submit(b, new() { ["cmdType"] = "TAP_RUNE", ["sourceObjectId"] = rune });
foreach (var rune in GreenRunes(b).Take(3).ToArray()) await Submit(b, new() { ["cmdType"] = "RECYCLE_RUNE", ["sourceObjectId"] = rune });
var targetId = a.Snapshot.GetProperty("stack").EnumerateArray().Single().GetProperty("stackItemId").GetString()!;
Check(Mana(b) == 4, "Four current real reaction rune activations provide the exact printed mana.");
await Submit(b, new() { ["cmdType"] = "PLAY_CARD", ["sourceObjectId"] = counter, ["cardNo"] = "OGN·080/298", ["targetObjectIds"] = new JsonArray(targetId) });
await Pass(); await Pass();
var payment = b.Snapshot.GetProperty("timing").GetProperty("pendingPayment");
Check(payment.GetProperty("choiceKind").GetString() == "SPELL_CHOICE_REMAKE"
    && payment.GetProperty("playerId").GetString() == b.Handle && b.Enabled("PAY_COST") && !a.Enabled("PAY_COST"),
    "Only the actual new controller receives the original optional target-selection control.");
foreach (var (side, index) in sides.Select((side, index) => (side, index)))
{
    var original = originalProfiles[index];
    var saved = new JsonObject { ["handle"] = side.Handle, ["roomId"] = room,
        ["playerKey"] = original["playerKey"]!.GetValue<string>(), ["reconnectToken"] = side.ReconnectToken,
        ["lastDeckId"] = "lillia-lowcurve", ["serverUrl"] = server };
    var path = Path.Combine(output, index == 0 ? "session-native-a.json" : "session-native-b.json");
    await File.WriteAllTextAsync(path, saved.ToJsonString(json), ct);
    File.SetUnixFileMode(path, UnixFileMode.UserRead | UnixFileMode.UserWrite);
    await File.WriteAllTextAsync(Path.Combine(output, index == 0 ? "a-original-opponent-wait-prompt.json" : "b-original-target-choice-prompt.json"), side.Prompt.GetRawText(), ct);
    await File.WriteAllTextAsync(Path.Combine(output, index == 0 ? "a-original-opponent-snapshot.json" : "b-original-target-choice-snapshot.json"), side.Snapshot.GetRawText(), ct);
}
await File.WriteAllTextAsync(Path.Combine(output, "original-accepted-native-prefix-intents.json"), JsonSerializer.Serialize(accepted, json), ct);
var receipt = new { status = "ACTUAL_TWO_PRODUCTION_GATEWAYS_ORDINARY_CONTROL_OPTIONAL_TARGET_PENDING_NOT_VISIBLE_CONTROLS_ACCEPTANCE",
    room, server, players = new[] { a.Handle, b.Handle }, acceptedCommands = accepted.Count,
    actualTick = a.Snapshot.GetProperty("tick").GetInt64(), actualTurn = a.Snapshot.GetProperty("turnNumber").GetInt32(),
    sourceObjectId = counter, targetStackItemId = targetId, targetSourceObjectId = targetSource,
    originalTargetObjectId = oldTarget, newTargetObjectId = newTarget, actualChoiceKind = "SPELL_CHOICE_REMAKE",
    snapshotCounts = sides.Select(s => s.SnapshotCount).ToArray(), promptCounts = sides.Select(s => s.PromptCount).ToArray(),
    originalBlankOpeningNoSeedOrStateInjection = true, actualRandomOpeningSeedNotPrinted = true,
    existingNativeProfilesUnchangedByRunner = true, originalAuthValuesOnlyInPrivateSessionFiles = true,
    visibleControlsFixedCommitWindowsAndWholeCardAcceptance = false };
await File.WriteAllTextAsync(Path.Combine(output, "pending-original-native-prefix-receipt.json"), JsonSerializer.Serialize(receipt, json), ct);
Console.WriteLine(JsonSerializer.Serialize(receipt, json));

async Task Submit(Side side, JsonObject command)
{
    var receipt = await side.Submit(command); accepted.Add(new { actor = side.Handle, rawCommand = command, receipt });
    await Until(() => sides.All(s => s.Snapshot.ValueKind == JsonValueKind.Object
        && s.Snapshot.GetProperty("tick").GetInt64() == receipt.ServerTick
        && s.Prompt.TryGetProperty("snapshotTick", out var tick) && tick.GetInt64() == receipt.ServerTick), "both actual wire views and prompt ticks");
}
string Priority() => a.Snapshot.GetProperty("timing").GetProperty("priorityPlayerId").GetString()!;
Task Pass() => Submit(sides.Single(s => s.Handle == Priority()), new() { ["cmdType"] = "PASS_PRIORITY" });
JsonElement Own(Side side) => side.Snapshot.GetProperty("players").GetProperty(side.Handle);
int Mana(Side side) => Own(side).GetProperty("runePool").GetProperty("mana").GetInt32();
string[] Hand(Side side, string card) => Own(side).GetProperty("zones").GetProperty("hand").EnumerateArray().Select(v => v.GetString()!)
    .Where(id => Own(side).GetProperty("objects").GetProperty(id).GetProperty("cardNo").GetString() == card).ToArray();
string? Unit(Side side) => Own(side).GetProperty("zones").GetProperty("base").EnumerateArray().Select(v => v.GetString()!)
    .FirstOrDefault(id => Own(side).GetProperty("objects").GetProperty(id).GetProperty("cardNo").GetString() == "OGN·052/298");
string[] AllRunes(Side side) => Own(side).GetProperty("zones").GetProperty("base").EnumerateArray().Select(v => v.GetString()!)
    .Where(id => Own(side).GetProperty("objects").TryGetProperty(id, out var obj)
        && obj.GetProperty("tags").EnumerateArray().Any(t => t.GetString() == "CARD_TYPE:RUNE")).ToArray();
string[] Runes(Side side) => AllRunes(side).Where(id => !Own(side).GetProperty("objects").GetProperty(id).GetProperty("isExhausted").GetBoolean()).ToArray();
string[] GreenRunes(Side side) => AllRunes(side).Where(id => Own(side).GetProperty("objects").GetProperty(id).GetProperty("tags").EnumerateArray().Any(t => t.GetString() == "COLOR:green")).ToArray();
async Task Until(Func<bool> predicate, string why)
{ while (!predicate()) { foreach (var side in sides) side.CheckErrors(); await Task.Delay(20, ct); } }
static void Check(bool condition, string reason) { if (!condition) throw new Exception(reason); }

sealed class WireTrace : IDisposable
{
    readonly StreamWriter writer; readonly object gate = new();
    public WireTrace(string path) => writer = new StreamWriter(new GZipStream(new FileStream(path, FileMode.CreateNew), CompressionLevel.SmallestSize));
    public void Record(string actor, string kind, JsonElement payload)
    { lock (gate) { writer.WriteLine(JsonSerializer.Serialize(new { actor, kind, payload })); writer.Flush(); } }
    public void Dispose() { lock (gate) writer.Dispose(); }
}
sealed class Side : IAsyncDisposable
{
    readonly string key; readonly string room; readonly CancellationToken ct;
    readonly ConcurrentQueue<string> errors = new(); readonly object gate = new();
    JsonElement snapshot, prompt;
    public string Handle { get; }
    public string? ReconnectToken { get; private set; }
    public int SnapshotCount, PromptCount;
    public RiftboundGameHubClient Hub { get; }
    public JsonElement Snapshot { get { lock (gate) return snapshot; } }
    public JsonElement Prompt { get { lock (gate) return prompt; } }
    public Side(string server, string room, JsonNode profile, WireTrace trace, CancellationToken token)
    {
        this.room = room; ct = token; Handle = profile["handle"]!.GetValue<string>(); key = profile["playerKey"]!.GetValue<string>();
        Hub = new(server);
        Hub.ServerMessageReceived += (kind, message) => {
            if (message.Payload is not JsonElement payload) return;
            lock (gate) {
                if (kind == "Joined") ReconnectToken = payload.GetProperty("reconnectToken").GetString();
                if (kind == "Snapshot") { snapshot = payload.Clone(); SnapshotCount++; trace.Record(Handle, kind, payload); }
                if (kind == "Prompt") { prompt = payload.Clone(); PromptCount++; trace.Record(Handle, kind, payload); }
                if (kind == "Error") errors.Enqueue("Actual server error " + payload.GetProperty("code").GetString());
            }
        };
        Hub.RestoreSession += async () => {
            var auth = await Hub.AuthenticateAsync(Handle, key, ct); if (!auth.Authenticated) throw new Exception("Actual restore authentication failed.");
            await Hub.ReconnectAsync(room, Handle, ReconnectToken!, ct); await Hub.RequestSnapshotAsync(room, Handle, ct);
        };
    }
    public async Task Connect()
    {
        await Hub.StartAsync(ct); var auth = await Hub.AuthenticateAsync(Handle, key, ct);
        if (!auth.Authenticated) throw new Exception("Existing own native identity authentication failed.");
        await Hub.JoinRoomAsync(room, Handle, null, ct); await Hub.RequestSnapshotAsync(room, Handle, ct);
        while (ReconnectToken is null || SnapshotCount == 0 || PromptCount == 0) { CheckErrors(); await Task.Delay(20, ct); }
    }
    public bool Enabled(string action) => Prompt.ValueKind == JsonValueKind.Object && Prompt.GetProperty("actionable").GetBoolean()
        && Prompt.GetProperty("candidates").EnumerateArray().Any(c => c.GetProperty("action").GetString() == action && c.GetProperty("enabled").GetBoolean());
    public async Task<CommandReceiptDto> Submit(JsonObject command)
    {
        command["promptId"] = Prompt.GetProperty("promptId").GetString(); command["snapshotTick"] = Prompt.GetProperty("snapshotTick").GetInt64();
        var receipt = await Hub.SubmitIntentAsync(room, Handle, "native-counter-prefix-" + Guid.NewGuid().ToString("N"), JsonSerializer.SerializeToElement(command), ct);
        if (!receipt.Accepted) throw new Exception("Actual ordinary native prefix rejected: " + receipt.CmdType + " " + receipt.ErrorCode);
        return receipt;
    }
    public void CheckErrors() { if (errors.TryPeek(out var error)) throw new Exception(error); }
    public ValueTask DisposeAsync() => Hub.DisposeAsync();
}
