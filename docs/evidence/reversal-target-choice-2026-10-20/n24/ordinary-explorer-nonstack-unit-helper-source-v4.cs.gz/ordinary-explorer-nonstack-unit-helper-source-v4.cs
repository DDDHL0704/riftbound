using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Nodes;
using Riftbound.CardCatalog;
using Riftbound.Contracts;
using Riftbound.Engine;

if (args.Length != 1 || Directory.Exists(args[0])) throw new Exception("Fresh explorer evidence directory required.");
Directory.CreateDirectory(args[0]);
var folder = args[0];
var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
var catalog = await OfficialCardCatalog.LoadDefaultAsync();
var original = PreconstructedDeckCatalog.Build(catalog, OfficialDeckFormat.ChinaStandard20260724).Single(d => d.Id == "lillia-lowcurve");
var needed = new List<string> { "OGN·080/298", "OGN·095/298" };
if (!original.Decklist.MainDeck.Contains("OGN·052/298")) needed.Add("OGN·052/298");
var replacements = original.Decklist.MainDeck.GroupBy(c => c).Where(g => g.Count() == 3
    && g.Key != original.Decklist.ChampionCardNo && g.Key != "OGN·052/298" && !needed.Contains(g.Key)).Take(needed.Count).Select(g => g.Key).ToArray();
if (replacements.Length != needed.Count) throw new Exception("Explicit distinct filler triples are required.");
var replacementsByCard = replacements.Zip(needed).ToDictionary(p => p.First, p => p.Second);
var deck = original.Decklist with { MainDeck = original.Decklist.MainDeck.Select(c => replacementsByCard.GetValueOrDefault(c, c)).ToArray() };
foreach (var format in new[] { OfficialDeckFormat.CoreRules, OfficialDeckFormat.ChinaStandard20260724 })
{
    var valid = OfficialDeckValidator.Validate(deck, catalog, format);
    if (!valid.IsValid) throw new Exception(format + ": " + string.Join(';', valid.Errors));
}
var journal = new Journal();
var engine = new CoreRuleEngine();
var initial = MatchReplayInitialStateBuilder.FromSeats("ordinary-reversal-discovery-v1",
    new Dictionary<string, string> { ["P1"] = "P1", ["P2"] = "P2" });
if (initial.Tick != 0 || initial.Seed != 0 || initial.CardObjects.Count != 0) throw new Exception("Original blank seed-zero opening required.");
var state = initial;
var session = new MatchSession(initial, engine, journal, NoopMatchPlayerStore.Instance,
    new(AllowLegacyReadyWithoutDeck: false, DeckFormat: OfficialDeckFormat.CoreRules));
var intents = new List<object>();
try
{
    foreach (var player in new[] { "P1", "P2" })
        await Submit(player, new SubmitDeckCommand(deck.LegendCardNo, deck.ChampionCardNo, deck.MainDeck, deck.RuneDeck, deck.Battlefields));
    foreach (var player in new[] { "P1", "P2" }) await Submit(player, new ReadyCommand());
    while (state.Phase == MatchPhases.Mulligan)
        await Submit(ResolutionResult.OpeningMulliganPlayerId(state)!, new MulliganCommand([]));
    for (var n = 0; n < 38; n++)
    {
        if (state.Phase != MatchPhases.Main || state.TimingState != TimingStates.NeutralOpen || state.StackItems.Count > 0)
            throw new Exception("Explorer expects an ordinary neutral main phase; no state injection is allowed.");
        var player = state.TurnPlayerId;
        foreach (var rune in Runes(player).Where(id => !state.CardObjects[id].IsExhausted).ToArray())
            await Submit(player, new TapRuneCommand(rune));
        if (Unit(player) is null && Hand(player, "OGN·052/298") is { } unit && state.RunePools[player].Mana >= 2)
        {
            await Submit(player, new PlayCardCommand(unit, "OGN·052/298", [])); await Top();
        }
        if (player == "P2" && Hand("P2", "OGN·080/298") is not null && Hand("P1", "OGN·095/298") is not null
            && Unit("P1") is not null && Unit("P2") is not null && state.RunePools["P2"].Mana >= 4
            && GreenRunes("P2").Length >= 3 && GreenRunes("P1").Length >= 1)
        {
            foreach (var rune in GreenRunes("P2").Take(3)) await Submit("P2", new RecycleRuneCommand(rune));
            await Submit("P2", new EndTurnCommand());
            foreach (var rune in Runes("P1").Where(id => !state.CardObjects[id].IsExhausted).ToArray())
                await Submit("P1", new TapRuneCommand(rune));
            await Submit("P1", new RecycleRuneCommand(GreenRunes("P1")[0]));
            var targetSource = Hand("P1", "OGN·095/298")!;
            var source = Hand("P2", "OGN·080/298")!;
            var oldTarget = Unit("P2")!; var newTarget = Unit("P1")!;
            await Submit("P1", new PlayCardCommand(targetSource, "OGN·095/298", [oldTarget]));
            await Submit("P1", new PassPriorityCommand());
            var targetId = state.StackItems.Single().StackItemId;
            var recipe = new { schemaVersion = 1, status = "ORDINARY_LEGAL_DERIVED_OPENING_REQUIRES_CURRENT_INDEPENDENT_ACCEPTANCE",
                region = "CN", language = "zh-CN", coreEffectiveDate = "2026-10-16", originalBlankSeed = 0,
                baseDeckId = original.Id, originalBaseDeck = original.Decklist, derivedDeck = deck, exactFillerReplacements = replacementsByCard,
                bothFormatsLegalityPassed = true, openingIntents = intents.ToArray(), sourceObjectId = source,
                targetSourceObjectId = targetSource, targetStackItemId = targetId, originalTargetObjectId = oldTarget,
                newTargetObjectId = newTarget, expectedTurn = state.TurnNumber, expectedPrefixCommands = intents.Count,
                actualRuleInputs = state.RuleInputs, wholeCardOrCompleteGameCertification = false };
            await File.WriteAllTextAsync(Path.Combine(folder, "reversal-ordinary-derived-opening-recipe-v1.json"), JsonSerializer.Serialize(recipe, json));
            await Submit("P2", new PlayCardCommand(source, "OGN·080/298", [targetId])); await Top();
            if (state.PendingRuleChoice is not { Request.PlayerId: "P2", Request.Kind: "SPELL_CHOICE_REMAKE" } choice
                || !choice.Request.Options.Any(o => o.ObjectIds?.Contains(newTarget) == true))
                throw new Exception("Real ordinary opening must offer the actual new controller a legal new target.");
            var frame = Frame();
            var errors = await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame, engine, default);
            if (errors.Count > 0) throw new Exception(string.Join(';', errors));
            Console.WriteLine(JsonSerializer.Serialize(new { status = "PASS_ORDINARY_BLANK_LEGAL_OPENING_REACHES_OPTIONAL_TARGET_CHOICE",
                state.TurnNumber, commands = intents.Count, events = frame.Events.Count, replacementsByCard,
                actualRuleInputs = state.RuleInputs, fullOriginalReplayMatched = true }, json));
            return;
        }
        await Submit(player, new EndTurnCommand());
    }
    throw new Exception("Bounded original opening did not reach all prerequisites; retain trace and inspect rather than inject state.");
}
finally
{
    await using var file = new FileStream(Path.Combine(folder, "original-explorer-frame.json.gz"), FileMode.CreateNew);
    await using var zip = new GZipStream(file, CompressionLevel.SmallestSize);
    await JsonSerializer.SerializeAsync(zip, Frame(), json);
}

IEnumerable<string> Runes(string player) => state.PlayerZones[player].Base.Where(id => state.CardObjects[id].Tags.Contains(CardObjectTags.RuneCard));
string[] GreenRunes(string player) => Runes(player).Where(id => state.CardObjects[id].Tags.Contains("COLOR:green")).ToArray();
string? Unit(string player) => state.PlayerZones[player].Base.FirstOrDefault(id => state.CardObjects[id].CardNo == "OGN·052/298");
string? Hand(string player, string card) => state.PlayerZones[player].Hand.FirstOrDefault(id => state.CardObjects[id].CardNo == card);
async Task Top() { await Submit(state.PriorityPlayerId!, new PassPriorityCommand()); await Submit(state.PriorityPlayerId!, new PassPriorityCommand()); }
async Task Submit(string player, GameCommand command)
{
    var rawNode = JsonSerializer.SerializeToNode(command, command.GetType(), json)!.AsObject();
    var rawIntent = JsonSerializer.SerializeToElement(rawNode, json);
    rawNode["promptId"] = session.PromptFor(player).PromptId; rawNode["snapshotTick"] = state.Tick;
    var raw = JsonSerializer.SerializeToElement(rawNode, json); var id = "reversal-ordinary-original-" + intents.Count;
    var result = command switch {
        SubmitDeckCommand submitted => await session.SubmitDeckAsync(player, id, submitted, raw, default),
        ReadyCommand => await session.ReadyAsync(player, id, raw, default),
        _ => await session.SubmitAsync(player, id, command, raw, default) };
    if (!result.Accepted) throw new Exception(command.CmdType + ": " + result.ErrorMessage);
    state = result.State; intents.Add(new { playerId = player, rawCommand = rawIntent });
    var frame = Frame(); if (frame.ValidationErrors.Count != 0) throw new Exception(string.Join(';', frame.ValidationErrors));
}
MatchRecoveryFrame Frame()
{
    var commands = journal.Entries.Select(e => new RecoveredCommand(e.PlayerId, e.ClientIntentId, e.CommandType, e.RawCommand,
        e.StartedTick, e.CompletedTick, e.StartedEventSequence, e.CompletedEventSequence, e.Accepted, e.ErrorMessage) { RuleInputs = e.RuleInputs }).ToArray();
    var events = journal.Entries.SelectMany(e => e.Events.Select((v, i) => new RecoveredEvent(e.StartedEventSequence + i + 1, e.CompletedTick, i, v))).ToArray();
    var sequence = journal.Entries.LastOrDefault()?.CompletedEventSequence ?? 0;
    var snapshots = ResolutionResult.BuildSnapshots(state); var prompts = ResolutionResult.BuildPrompts(state);
    var views = initial.Seats.Keys.ToDictionary(p => p, p => new RecoveredPlayerView(p, state.Tick, sequence, snapshots[p], state.Tick, sequence, prompts[p]));
    var spectator = MatchReplayRedactor.BuildSpectatorFrame(state.RoomId, state.Tick, sequence, [], state);
    var errors = MatchRecoveryValidator.Validate(state.RoomId, sequence, commands, events, views, state, state.Tick, spectator);
    return new(state.RoomId, state.Tick, sequence, commands, events, views, errors, state, initial, spectator);
}
internal sealed class Journal : IMatchJournal
{
    internal List<MatchJournalEntry> Entries { get; } = [];
    public ValueTask RecordAsync(MatchJournalEntry entry, CancellationToken cancellationToken) { Entries.Add(entry); return ValueTask.CompletedTask; }
}
