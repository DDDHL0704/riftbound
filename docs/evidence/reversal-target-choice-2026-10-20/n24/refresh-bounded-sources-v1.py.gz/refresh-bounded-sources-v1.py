import datetime
import gzip
import hashlib
import json
from pathlib import Path
import urllib.parse
import urllib.request

work = Path(__file__).resolve().parent
root = work.parents[2]
prior = root / 'var/qa/native-signalr-runtime-patch-fixed-43d5b84e-20261020/source-consumer-followup'
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
receipt = {'startedAtUtc': now(), 'region': 'CN', 'language': 'zh-CN',
           'applicabilityDate': '2026-10-20', 'adoptedCoreEffectiveDate': '2026-10-16',
           'singlePrintingPublishedAt': None, 'singlePrintingEffectiveAtIndependentlyVerified': None,
           'exactPrinting': 'OGN·080/298', 'exactApiId': 31296, 'records': [],
           'wholePrintingOrFamilyCertified': False, 'allExistingSourceDeltasPreserved': True}
out = work / 'bounded-current-official-source-readback-v1.json'
assert not out.exists()

def fetch(label, url, payload=None):
    parts = urllib.parse.urlsplit(url)
    encoded = urllib.parse.urlunsplit((parts.scheme, parts.netloc,
        urllib.parse.quote(parts.path, safe='/%'), parts.query, parts.fragment))
    started = now()
    req = urllib.request.Request(encoded, data=None if payload is None else json.dumps(payload, ensure_ascii=False).encode(),
        headers={'User-Agent': 'RiftboundRulesAudit/1.0', **({'Content-Type': 'application/json'} if payload is not None else {})})
    with urllib.request.urlopen(req, timeout=55) as response:
        raw = response.read()
        entry = {'label': label, 'url': url, 'encodedRequestUrl': encoded,
            'requestedAtUtc': started, 'receivedAtUtc': now(), 'httpStatus': response.status,
            'httpDate': response.headers.get('Date'), 'contentType': response.headers.get('Content-Type'),
            'bytes': len(raw), 'sha256': sha(raw)}
    if payload is not None:
        entry['request'] = payload
    receipt['records'].append(entry)
    return raw, entry

try:
    payload = {'pageNum': 1, 'pageSize': 100, 'searchContent': '倒转神通', 'cardCategoryList': [],
               'cardColorList': [], 'rarityList': [], 'productCodeList': []}
    raw, entry = fetch('exact-card-complete-response', 'https://lol-api.playloltcg.com/xcx/card/searchCardCraftWeb', payload)
    (work / 'current-reversal-complete-response-v1.json.gz').write_bytes(gzip.compress(raw, mtime=0))
    parsed = json.loads(raw)
    assert parsed['code'] == 0 and parsed['result']['total'] == len(parsed['result']['list']) == 1
    card = parsed['result']['list'][0]
    old = json.loads(gzip.decompress((prior / 'reversal-current-complete-api-response-v1.json.gz').read_bytes()))['result']['list'][0]
    assert card['id'] == 31296 and card['cardNo'] == 'OGN·080/298'
    entry['wholeRawRowExactToPriorObservedSource'] = card == old
    assert card == old
    raw, entry = fetch('complete-current-rules-directory', 'https://lol-api.playloltcg.com/xcx/gameRule/getGameRuleList', {'pageNum': 1, 'pageSize': 1000})
    (work / 'current-rules-directory-complete-response-v1.json.gz').write_bytes(gzip.compress(raw, mtime=0))
    old = json.loads(gzip.decompress((root / 'var/qa/conditional-counter-payment-audit-20261020/current-rules-directory-complete-response-v1.json.gz').read_bytes()))
    parsed = json.loads(raw)
    entry['entireResultExactToPriorDirectory'] = parsed['result'] == old['result']
    assert parsed['code'] == 0 and entry['entireResultExactToPriorDirectory']
    sources = json.loads((root / 'data/official/rule-input-scope.json').read_text())['adoptedSources']
    for identity in ['DOC-01', 'DOC-06', 'DOC-15', 'DOC-16']:
        source = next(s for s in sources if s['id'] == identity)
        raw, entry = fetch(identity, source['url'])
        existing = root / 'var/qa/cn-effective-20261016/whole-rule-source-readback/CN' / (identity + '.pdf')
        entry.update(versionDate=source['versionDate'], effectiveDate=source.get('effectiveDate'),
            adoptedSha256=source['sha256'], unchanged=sha(raw) == source['sha256'],
            existingOriginal=str(existing.relative_to(root)), existingOriginalSha256=sha(existing.read_bytes()))
        if not entry['unchanged']:
            (work / (identity + '-changed-unadopted.pdf')).write_bytes(raw)
        assert entry['unchanged'] and raw == existing.read_bytes()
        entry['existingOriginalReusedWithoutDuplicatePdf'] = True
    raw, entry = fetch('current-exact-card-face', card['frontImage'])
    old_face = prior / 'current-exact-ogn080-card-face.png'
    assert raw == old_face.read_bytes()
    entry.update(existingOriginal=str(old_face.relative_to(root)), wholeFaceExact=True,
                 priorActualVisualReview=str((prior / 'reversal-current-exact-visual-review-and-pending-code-gap-v1.json').relative_to(root)))
    receipt['status'] = 'PASS_CURRENT_BOUNDED_SOURCE_VERSIONS_UNCHANGED'
except BaseException as error:
    receipt.update(status='FAILED_OR_SOURCE_DELTA_REQUIRES_SEPARATE_INTAKE',
                   errorType=type(error).__name__, errorMessage=str(error))
    raise
finally:
    receipt['finishedAtUtc'] = now()
    out.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(receipt['status'], len(receipt['records']), 'source receipts; no duplicate PDFs or card image retained')
