import collections
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET

work = Path(__file__).resolve().parent
root = work.parents[2]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
terminal = load(work / 'only-check-terminal-integrity-v1.json')
assert terminal['checkExitCode'] == 0 and terminal['allDeclaredSourceAndRuntimeInputsStable']
assert terminal['boundIdleAssertionEnded'] and terminal['noSecondCheck']
start = load(work / 'only-check-start-inputs-v1.json')
assert sha(work / 'only-check-start-inputs-v1.json') == terminal['sourceManifestSha256']
assert all(sha(root / p) == h for p, h in start['sourceInputHashes'].items())
assert all(sha(root / p) == h for p, h in start['actualConformanceRuntimeFileHashes'].items())
baseline = root / start['unchangedOriginalCaseBaseline']
assert sha(baseline) == start['unchangedOriginalCaseBaselineSha256']

def cases(path):
    tree = ET.parse(path)
    definitions = {d.attrib['id']: d.find('t:TestMethod', ns).attrib for d in tree.findall('.//t:UnitTest', ns)}
    rows = tree.findall('.//t:UnitTestResult', ns)
    assert rows and all(r.attrib['outcome'] == 'Passed' for r in rows)
    methods = {definitions[r.attrib['testId']]['className'] + '.' + definitions[r.attrib['testId']]['name'] for r in rows}
    return collections.Counter(r.attrib['testName'] for r in rows), methods

trx = work / 'only-check/check/results.trx'
current, methods = cases(trx)
original, old_methods = cases(baseline)
new_cases, new_methods = cases(work / 'focus-current-ordinary-and-boundaries-v5/focus/results.trx')
assert sum(original.values()) == 13139 and len(old_methods) == 7479
assert not (original - current) and old_methods <= methods
assert current - original == new_cases and methods - old_methods == new_methods
assert sum(current.values()) == 13166 and len(methods) == 7490
plan = load(work / 'only-check/plan.json')
assert len(plan['shards']) == 1 and set(plan['shards'][0]['methods']) == methods
summary = load(work / 'only-check/summary.json')
assert summary['status'] == 'PASSED' and summary['profile'] == 'check' and summary['total'] == 13166
assert all(s['total'] == s['passed'] and s['failed'] == s['notExecuted'] == 0 for s in summary['shards'])
host = load(work / 'sole-check-actual-testhost-runtime-loaded-maps-v1.json')
assert host['hits'] and all('/10.0.13/' in p for h in host['hits'] for p in h['actualLoadedCoreRuntimeFiles'])
before = load(work / 'original-fixed43-source-and-test-inputs-v1.json')
assert len(before['trackedFiles']) == 3308
changed = [r['path'] for r in before['trackedFiles'] if sha(root / r['path']) != r['sha256']]
expected = ['src/Riftbound.Engine/CardBehaviorRegistry.cs', 'src/Riftbound.Engine/CoreRuleEngine.cs',
    'src/Riftbound.Engine/CoreRuleEngine.SpellChoiceControl.cs', 'tests/Riftbound.ConformanceTests/ClairvoyanceTests.cs',
    'tests/Riftbound.ConformanceTests/DeckPlaySequenceTests.cs', 'tests/Riftbound.ConformanceTests/MelNativeTests.cs',
    'tests/Riftbound.ConformanceTests/MelRulesTests.cs', 'tests/Riftbound.ConformanceTests/TargetedInsightRepeatTests.cs',
    'tests/Riftbound.ConformanceTests/Fixtures/p2-preflight-play-reversal-gain-stack-spell-control.fixture.json',
    'tests/Riftbound.PostgresAcceptance/Program.cs', 'tests/Riftbound.PostgresAcceptance/Riftbound.PostgresAcceptance.csproj',
    'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json']
assert sorted(changed) == sorted(expected)
assert all(oct((root / r['path']).stat().st_mode & 0o777) == r['mode'] for r in before['trackedFiles'])
for path in [p for p in expected if p.startswith('tests/Riftbound.ConformanceTests/') and p.endswith('.cs')]:
    old = subprocess.check_output(['git', 'show', start['baseCommit'] + ':' + path], cwd=root).decode().splitlines()
    cursor = iter((root / path).read_text().splitlines())
    assert all(any(line == prior for line in cursor) for prior in old), path
full = [r for r in before['trackedFiles'] if re.fullmatch(r'tests/Riftbound.ConformanceTests/FullGameEndToEndTests[^/]*\.cs', r['path'])]
assert len(full) == 9 and all(sha(root / r['path']) == r['sha256'] for r in full)
names = {n for r in full for n in re.findall(r'\bpublic\s+(?:async\s+)?(?:Task|void)\s+(\w+)\s*\(', (root / r['path']).read_text())}
assert len(names) == 143
old_fixture = json.loads(gzip.decompress((work / 'original-reversal-five-command-fixture-before-explicit-decision.json.gz').read_bytes()))
new_fixture = load(root / expected[8])
restored = json.loads(json.dumps(new_fixture))
assert restored['commands'][-1]['cmd']['paymentChoiceIds'] == ['KEEP_ALL']
restored['commands'].pop()
assert restored['expected']['events'][8]['kind'] == restored['expected']['eventKinds'][8] == 'RULE_CHOICE_REQUESTED'
restored['expected']['events'].pop(8)
restored['expected']['eventKinds'].pop(8)
restored['expected']['finalTick'] -= 1
assert restored == old_fixture
sql = load(root / 'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json')
old_sql = json.loads(subprocess.check_output(['git', 'show', start['baseCommit'] + ':tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'], cwd=root))
assert sql['cases'][:46] == old_sql['cases'] and len(sql['cases']) == 47
result = {'status': 'PASS_SOLE_REVERSAL_BATCH_CHECK_ORIGINAL_MULTISET_METHODS_ASSERTIONS_AND_ALL_INPUTS_STABLE',
    'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'baseCommit': start['baseCommit'],
    'totalCases': sum(current.values()), 'passed': sum(current.values()), 'failed': 0, 'skipped': 0, 'uniqueMethods': len(methods),
    'allOriginal13139CaseMultisetAnd7479MethodsPreserved': True, 'addedCases': 27, 'addedMethods': 11,
    'newMethodNames': sorted(new_methods), 'sourceInputCount': start['sourceInputCount'],
    'actualConformanceRuntimeFileCount': start['actualConformanceRuntimeFileCount'],
    'allSourceAndRuntimeInputsStableThroughTerminal': True, 'exactChangedOriginalSourceFiles': changed,
    'allOther3296OriginalSourcesAndAllModesExact': True, 'originalNineFullGameFilesAnd143MethodsByteExact': True,
    'retainedPairs': 110, 'retainedDecks': 11, 'retainedSeed': 424242, 'allOriginalTestMethodsTheoryRowsVictoryReplayAssertionsRetained': True,
    'original46SqlCasesAndOrderExactWith47thAppend': True, 'originalFixtureFiveIntentsElevenEventsAndAllOtherAssertionsExact': True,
    'baselineTrxSha256': sha(baseline), 'actualTrxSha256': sha(trx), 'actualMappedRuntime': '10.0.13',
    'summary': summary, 'noSecondCheck': True, 'newFixedFullNativeAndPhysicalWindowsSeparatelyOpen': True}
with (work / 'only-check-retention-and-disposition-v1.json').open('x') as out:
    out.write(json.dumps(result, indent=2) + '\n')
print(result['status'], result['totalCases'], result['uniqueMethods'], flush=True)
