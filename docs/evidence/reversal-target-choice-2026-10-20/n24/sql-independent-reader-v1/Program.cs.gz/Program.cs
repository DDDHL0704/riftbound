using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.CardCatalog;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
if (args.SequenceEqual(["identity-print"])) { Console.WriteLine(JsonSerializer.Serialize(RuleInputIdentity.Current, json)); return; }
Check(args.Length == 2 && args[0] == "independent-readonly", "Original four-branch output path required.");
var folder = Path.GetFullPath(args[1]);
var settings = new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
Check(settings.Host == "127.0.0.1" && settings.Port == 55486 && settings.Database == "riftbound_acceptance"
    && settings.Username == "codex_riftbound_audit", "Existing dedicated original database required.");
settings.Options = "-c default_transaction_read_only=on";
await using var source = NpgsqlDataSource.Create(settings.ConnectionString);
var catalog = await OfficialCardCatalog.LoadDefaultAsync();
using var recipe = JsonDocument.Parse(File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "Fixtures/reversal-target-openings.json")));
var opening = recipe.RootElement.GetProperty("openingIntents").EnumerateArray().ToArray();
Check(opening.Length == 49, "Exact retained new-intent recipe required.");
var counter = recipe.RootElement.GetProperty("sourceObjectId").GetString()!;
var spellSource = recipe.RootElement.GetProperty("targetSourceObjectId").GetString()!;
var target = recipe.RootElement.GetProperty("targetStackItemId").GetString()!;
var oldUnit = recipe.RootElement.GetProperty("originalTargetObjectId").GetString()!;
var newUnit = recipe.RootElement.GetProperty("newTargetObjectId").GetString()!;
var checks = new List<object>();
foreach (var format in new[] { "CoreRules", "ChinaStandard20260724" })
foreach (var remake in new[] { false, true })
{
    var path = Path.Combine(folder, $"reversal-{format}-{remake}-final-original-frame.json.gz");
    var bytes = File.ReadAllBytes(path); var hash = Convert.ToHexStringLower(SHA256.HashData(bytes));
    await using var zip = new GZipStream(new MemoryStream(bytes), CompressionMode.Decompress);
    var raw = await JsonNode.ParseAsync(zip) ?? throw new Exception("Original SQL frame required.");
    var original = raw.Deserialize<MatchRecoveryFrame>(json)!;
    Check(JsonNode.DeepEquals(raw, JsonSerializer.SerializeToNode(original, json)), "Every original frame field and null survives typed read exactly.");
    var frame = await new PostgresMatchRecoveryStore(source).LoadAsync(original.RoomId, default) ?? throw new Exception("Actual original database frame required.");
    Check(JsonNode.DeepEquals(raw, JsonSerializer.SerializeToNode(frame, json)), "All original saved fields/nulls/commands/events/private views/prompts equal actual SQL.");
    var expectedCommands = remake ? 56 : 55; var state = frame.AuthoritativeState!;
    Check(frame.IsConsistent && frame.OpeningSeed == 0 && frame.ReplayInitialState is { Tick: 0, Seed: 0 } blank
        && blank.CardObjects.Count == 0 && blank.RuleInputs == RuleInputIdentity.Current && frame.Commands.Count == expectedCommands
        && frame.Commands.All(c => c.Accepted && c.RuleInputs == RuleInputIdentity.Current)
        && state.RuleInputs == RuleInputIdentity.Current, "Actual original blank seed, complete accepted history and current runtime identity.");
    Check(frame.Commands.Count(c => c.CommandType == CommandTypes.SubmitDeck) == 2
        && frame.Commands.Count(c => c.CommandType == CommandTypes.PlayCard) == 4
        && frame.Commands.All(c => c.CommandType != "SURRENDER" && c.CommandType != "DEV_SEED_SCENARIO"), "Two actual deck submissions and four normal plays without state injection or surrender.");
    for (var i = 0; i < opening.Length; i++)
    {
        var command = frame.Commands[i]; var expected = GameCommandJsonMapper.Map(opening[i].GetProperty("rawCommand"));
        var actual = GameCommandJsonMapper.Map(command.RawCommand!.Value);
        Check(command.PlayerId == opening[i].GetProperty("playerId").GetString()
            && JsonNode.DeepEquals(JsonSerializer.SerializeToNode(expected, expected.GetType(), json), JsonSerializer.SerializeToNode(actual, actual.GetType(), json)),
            "All49 original typed intents retain exact actor, order and payload; only fresh transport prompt/tick was bound.");
    }
    foreach (var command in frame.Commands.Where(c => c.CommandType == CommandTypes.SubmitDeck))
    {
        var deck = (SubmitDeckCommand)GameCommandJsonMapper.Map(command.RawCommand!.Value);
        foreach (var f in new[] { OfficialDeckFormat.CoreRules, OfficialDeckFormat.ChinaStandard20260724 })
            Check(OfficialDeckValidator.Validate(new(deck.LegendCardNo, deck.ChampionCardNo, deck.MainDeck, deck.RuneDeck, deck.Battlefields), catalog, f).IsValid,
                "Both original decks independently legal in both explicitly named formats.");
    }
    var declaration = (PlayCardCommand)GameCommandJsonMapper.Map(frame.Commands[49].RawCommand!.Value);
    Check(frame.Commands[49].PlayerId == "P2" && declaration.SourceObjectId == counter && declaration.CardNo == "OGN·080/298"
        && string.IsNullOrEmpty(declaration.Mode) && declaration.TargetObjectIds.SequenceEqual([target])
        && declaration.OptionalCosts is not { Count: > 0 }, "Actual ordinary Reversal declaration retains the exact target spell and no fabricated mode.");
    var payments = frame.Commands.Where(c => c.CommandType == CommandTypes.PayCost).ToArray();
    var choices = payments.Select(p => ((PayCostCommand)GameCommandJsonMapper.Map(p.RawCommand!.Value)).PaymentChoiceIds!.Single()).ToArray();
    Check(payments.All(p => p.PlayerId == "P2") && (remake ? choices.Length == 2
        && choices[0].StartsWith("EDIT:0:", StringComparison.Ordinal) && choices[1] == "CONFIRM"
        : choices.SequenceEqual(["KEEP_ALL"])), "Original controller decisions are explicit, ordered and bound to the server continuation.");
    var controlEvents = frame.Events.Where(e => e.Event.Kind == "STACK_ITEM_CONTROL_GAINED").ToArray();
    Check(controlEvents.Length == 1 && Payload(controlEvents[0]).GetProperty("stackItemId").GetString() == target
        && Payload(controlEvents[0]).GetProperty("previousControllerId").GetString() == "P1"
        && Payload(controlEvents[0]).GetProperty("controllerId").GetString() == "P2"
        && frame.Events.All(e => e.Event.Kind != "STACK_ITEM_COUNTERED"), "The actual original spell changes controller and is never countered.");
    Check(frame.Events.Count(e => e.Event.Kind == "SPELL_CHOICES_REMADE") == (remake ? 1 : 0), "Only explicit remake records a new target selection.");
    var costs = frame.Events.Where(e => e.Event.Kind == "COST_PAID").ToArray();
    Check(costs.Length == 4, "Only the four original plays pay their play costs; target edits do not play again.");
    var controlCost = costs.Single(e => Payload(e).GetProperty("sourceObjectId").GetString() == counter);
    Check(Payload(controlCost).GetProperty("mana").GetInt32() == 4
        && Payload(controlCost).GetProperty("powerByTrait").GetProperty("green").GetInt32() == 3,
        "Exact printed four-mana, three-green-power cost from the actual new controller.");
    Check(state.Status == MatchStatuses.InProgress && state.StackItems.Count == 0 && state.TriggerQueue.Count == 0
        && state.PendingRuleChoice is null && state.PendingCardChoice is null && state.PendingPayment is null && state.PendingEffectPlay is null
        && state.RunePools["P2"].Mana == 0 && state.RunePools["P2"].TotalPower == 0
        && state.PlayerZones["P2"].Graveyard.Contains(counter) && state.PlayerZones["P1"].Graveyard.Contains(spellSource)
        && !state.PlayerZones["P2"].Graveyard.Contains(spellSource)
        && state.CardObjects[oldUnit].Power == (remake ? 2 : 1) && state.CardObjects[newUnit].Power == (remake ? 1 : 2),
        "Only the explicit target is reduced, source ownership is retained, and all pending flows complete.");
    var history = new Dictionary<string, int>(); var originalPendingStates = 0; var originalDraftStates = 0; MatchState? prefixHistoricalState = null;
    await using (var connection = await source.OpenConnectionAsync())
    {
        Check((string)(await new NpgsqlCommand("show transaction_read_only", connection).ExecuteScalarAsync())! == "on", "Actual database enforces independent read-only transactions.");
        foreach (var table in new[] { "state_snapshots", "snapshots", "action_prompts" })
        {
            await using var command = new NpgsqlCommand($"select payload::text from {table} where match_id=@room order by id", connection);
            command.Parameters.AddWithValue("room", frame.RoomId); await using var rows = await command.ExecuteReaderAsync(); var count = 0;
            while (await rows.ReadAsync())
            {
                var payload = rows.GetString(0); var originalPayload = JsonNode.Parse(payload);
                var roundtrip = table switch {
                    "state_snapshots" => JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<MatchState>(payload, json), json),
                    "snapshots" => JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<SnapshotDto>(payload, json), json),
                    _ => JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<ActionPromptDto>(payload, json), json) };
                Check(JsonNode.DeepEquals(originalPayload, roundtrip), "Every historical original state/private view/prompt field and null survives typed read exactly."); count++;
                if (table == "state_snapshots")
                {
                    var historical = JsonSerializer.Deserialize<MatchState>(payload, json)!;
                    Check(historical.RuleInputs == RuleInputIdentity.Current, "Every original historical state binds the current actual rule inputs.");
                    if (historical.Tick == 49) prefixHistoricalState = historical;
                }
                if (table == "state_snapshots" && JsonSerializer.Deserialize<MatchState>(payload, json)!.PendingRuleChoice is { } pending)
                {
                    Check(pending.Request.PlayerId == "P2" && pending.Request.ManaCost == 0 && pending.Request.PowerCost == 0
                        && pending.Request.Kind == "SPELL_CHOICE_REMAKE" && pending.Request.Options.Any(o => o.Id == "KEEP_ALL")
                        && pending.Request.Preview!.StackItems.Single(i => i.StackItemId == target).ControllerId == "P2"
                        && pending.Request.Preview.RunePools["P2"].Mana == 0 && pending.Request.Preview.RunePools["P2"].TotalPower == 0,
                        "Persisted original choice belongs to the new controller, after the actual printed cost, without a second payment.");
                    Check(!pending.Request.Options.Any(o => o.Label.Contains("模式 ") || o.Label.Contains("目的地")),
                        "The exact target-only grant cannot expose a broader mode or destination choice.");
                    originalPendingStates++;
                    if (pending.Answers.Count == 1)
                    {
                        Check(remake && pending.Answers[0].OptionId.StartsWith("EDIT:0:", StringComparison.Ordinal)
                            && pending.Request.Options.Any(o => o.Id == "CONFIRM"), "Only the explicit original draft edit precedes confirmation.");
                        originalDraftStates++;
                    }
                    else Check(pending.Answers.Count == 0 && pending.Request.Options.Any(o => o.ObjectIds?.Contains(newUnit) == true),
                        "The first original choice actually offers the intended legal new target.");
                }
            }
            Check(count > 0, "Actual original historical payload rows required."); history[table] = count;
        }
    }
    Check(history["state_snapshots"] == expectedCommands && history["snapshots"] == 2 * (expectedCommands - 2)
        && history["action_prompts"] == 2 * (expectedCommands - 2) && originalPendingStates == (remake ? 2 : 1)
        && originalDraftStates == (remake ? 1 : 0), "Every original state and both players' complete private history and explicit target checkpoints are retained.");
    Check(prefixHistoricalState is not null
        && state.PlayerZones["P2"].Hand.Count == prefixHistoricalState.PlayerZones["P2"].Hand.Count
        && state.PlayerZones["P1"].Hand.Count == prefixHistoricalState.PlayerZones["P1"].Hand.Count
        && state.PlayerZones["P1"].MainDeck.Count == prefixHistoricalState.PlayerZones["P1"].MainDeck.Count
        && state.PlayerZones["P2"].MainDeck.Count == prefixHistoricalState.PlayerZones["P2"].MainDeck.Count - 1,
        "Independent original prefix proves that only the actual new controller draws from their own deck.");
    var errors = await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame, new CoreRuleEngine(), default);
    Check(errors.Count == 0, "Independent full original SQL action/event/state replay: " + string.Join(';', errors));
    Check(Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(path))) == hash, "Original saved frame remains byte exact.");
    checks.Add(new { room = frame.RoomId, format, remake, commands = frame.Commands.Count, events = frame.Events.Count,
        originalFrameSha256 = hash, actualHistoricalPayloads = history, originalPendingStates, originalDraftStates,
        allOriginalFieldsNullsAndPrivateHistoryMatch = true, original49IntentPayloadsAndActorsExact = true, fullOriginalReplayMatched = true });
}
Console.WriteLine(JsonSerializer.Serialize(new { status = "PASS_INDEPENDENT_READONLY_REAL_POSTGRES_FOUR_REVERSAL_ORIGINALS",
    actualRuleInputs = RuleInputIdentity.Current, checks, noNewGameplayStateSeedOrHistoryRewrite = true,
    completeGameOrWholeCardCertification = false, visibleNativeAndPhysicalWindows = "OPEN" }, json));
static JsonElement Payload(RecoveredEvent e) => JsonSerializer.SerializeToElement(e.Event.Payload);
static void Check(bool condition, string message) { if (!condition) throw new Exception(message); }
