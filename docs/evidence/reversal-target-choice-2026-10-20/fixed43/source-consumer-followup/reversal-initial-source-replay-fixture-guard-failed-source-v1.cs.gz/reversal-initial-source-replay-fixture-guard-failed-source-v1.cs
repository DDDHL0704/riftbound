using System.IO.Compression;
using System.Text.Json;
using Riftbound.Contracts;
using Riftbound.Engine;

if (args.Length != 1 || File.Exists(args[0])) throw new Exception("Fresh controlled-counterexample frame path required.");
var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
var spell = CardBehaviorRegistry.GetAll().First(b => b.TargetScope == CardTargetScopes.AnyUnit
    && b.DamageAmount == 2 && b.RequiredTargetCount == 1 && b.Mode.Length == 0
    && !b.PlaysSourceToBaseAsUnit && !b.PlaysSourceToBaseAsEquipment);
var initial = new MatchState("REVERSAL-FIXED43-CONTROLLED-READONLY", 1, 3, "P1",
    new Dictionary<string, string> { ["P1"] = "P1", ["P2"] = "P2" },
    status: MatchStatuses.InProgress, phase: MatchPhases.Main, timingState: TimingStates.NeutralClosed,
    priorityPlayerId: "P1",
    runePools: new Dictionary<string, RunePool> { ["P1"] = new(20, 20), ["P2"] = new(20, 20) },
    playerZones: new Dictionary<string, PlayerZones> {
        ["P1"] = PlayerZones.Empty with { Hand = ["REVERSAL"], Base = ["FRIEND"] },
        ["P2"] = PlayerZones.Empty with { Base = ["ENEMY"] } },
    cardObjects: new Dictionary<string, CardObjectState> {
        ["REVERSAL"] = new("REVERSAL", cardNo: "OGN·080/298", ownerId: "P1", controllerId: "P1"),
        ["DAMAGE"] = new("DAMAGE", cardNo: spell.CardNo, ownerId: "P2", controllerId: "P2"),
        ["FRIEND"] = new("FRIEND", cardNo: "SFD·125/221", ownerId: "P1", controllerId: "P1", power: 5, tags: [CardObjectTags.UnitCard]),
        ["ENEMY"] = new("ENEMY", cardNo: "SFD·125/221", ownerId: "P2", controllerId: "P2", power: 5, tags: [CardObjectTags.UnitCard]) },
    stackItems: [new("DAMAGE-SPELL", "P2", "DAMAGE", spell.EffectKind, spell.CardNo, ["FRIEND"], 0, 1)]);
var engine = new CoreRuleEngine();
var steps = new List<ResolutionResult>();
var command = new PlayCardCommand("REVERSAL", "OGN·080/298", ["DAMAGE-SPELL"], OptionalCosts: []);
var played = await engine.ResolveAsync(initial, new("reversal-readonly-play", "P1", command.CmdType), command, default);
if (!played.Accepted) throw new Exception("Controlled input is not yet a meaningful counterexample: " + played.ErrorCode + ": " + played.ErrorMessage);
steps.Add(played);
var state = played.State;
for (var i = 0; i < 2; i++)
{
    var pass = new PassPriorityCommand();
    var next = await engine.ResolveAsync(state, new("reversal-readonly-pass-" + i, state.PriorityPlayerId!, pass.CmdType), pass, default);
    if (!next.Accepted) throw new Exception("Original normal priority pass rejected: " + next.ErrorMessage);
    steps.Add(next); state = next.State;
}
var target = state.StackItems.Single(s => s.StackItemId == "DAMAGE-SPELL");
if (target.ControllerId != "P1" || !steps.SelectMany(s => s.Events).Any(e => e.Kind == "STACK_ITEM_CONTROL_GAINED"))
    throw new Exception("Actual original control instruction must complete before testing optional new targets.");
var same = JsonSerializer.Deserialize<MatchState>(JsonSerializer.Serialize(state, json), json)!;
if (MatchStateHasher.Hash(same) != MatchStateHasher.Hash(state)) throw new Exception("Complete typed controlled state must round-trip.");
var recoveryErrors = MatchRecoveryValidator.Validate(state.RoomId, 0, [], [],
    new Dictionary<string, RecoveredPlayerView>(), same, same.Tick);
if (recoveryErrors.Count != 0) throw new Exception("Counterexample must satisfy the independent recovery validator: " + string.Join(';', recoveryErrors));
var optionalNewTargetOffered = state.PendingRuleChoice is { } pending
    && pending.Request.PlayerId == "P1" && pending.Request.Options.Any(o => o.ObjectIds?.Contains("ENEMY") == true)
    || state.PendingCardChoice is { PlayerId: "P1" } cardChoice && cardChoice.LegalObjectIds.Contains("ENEMY");
await using (var file = new FileStream(args[0], FileMode.CreateNew))
await using (var zip = new GZipStream(file, CompressionLevel.SmallestSize))
    await JsonSerializer.SerializeAsync(zip, new { initial, command, steps, final = state }, json);
Console.WriteLine(JsonSerializer.Serialize(new {
    status = optionalNewTargetOffered ? "EXPECTED_OPTIONAL_NEW_TARGET_CHOICE_PRESENT" : "RED_REPRODUCED_REVERSAL_CONTROLS_SPELL_WITHOUT_OPTIONAL_NEW_TARGET_CHOICE",
    actualRuleInputs = RuleInputIdentity.Current,
    sourceCard = "OGN·080/298", sourceApiId = 31296,
    independentExpected = "Current exact official face/API allow the new controller to optionally designate new targets.",
    actualFixtureSpell = new { spell.CardNo, spell.DisplayName, spell.EffectKind },
    actualController = target.ControllerId, actualOriginalTargets = target.TargetObjectIds,
    actualPendingKind = state.PendingRuleChoice?.Request.Kind, optionalNewTargetOffered,
    independentRecoveryErrors = recoveryErrors.Count,
    actualPromptActions = ResolutionResult.BuildPrompts(state)["P1"].Candidates?.Select(c => c.Action).Distinct().ToArray(),
    acceptedCommands = steps.Count, events = steps.Sum(s => s.Events.Count),
    controlledOnlyNotOrdinaryOpening = true, noDatabaseOrProductionSourceOrExistingTestMutation = true,
    wholePrintingNotCertified = true }, json));
Environment.ExitCode = optionalNewTargetOffered ? 0 : 1;
