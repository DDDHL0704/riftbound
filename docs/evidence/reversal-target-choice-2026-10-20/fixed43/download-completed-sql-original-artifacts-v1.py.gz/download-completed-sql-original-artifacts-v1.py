import datetime
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import time
import zipfile

work = Path(__file__).resolve().parent
run = 39397913669
fixed = '43d5b84e867eb09ca0570ed8774832ce70b04d87'
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
raw = subprocess.check_output(['gh','api',f'repos/DDDHL0704/riftbound/actions/runs/{run}/artifacts?per_page=100'])
index = json.loads(raw)
metadata_path = work / 'fixed43-completed-sql-partial-artifacts-original-v1.json'
with metadata_path.open('xb') as out: out.write(raw)
rows = {a['name']:a for a in index['artifacts']}
proof = []
for name in ['postgres-partition-0','postgres-partition-1','postgres-partition-2','postgres-partition-3','postgres-results']:
    meta = rows[name]
    assert not meta['expired'] and meta['workflow_run']['head_sha'] == fixed
    path = work / 'ci-originals' / (str(run) + '-' + name + '.zip')
    assert not path.exists()
    for attempt in range(1, 4):
        temporary = path.with_name(path.name + '.download-' + str(attempt))
        with temporary.open('xb') as out:
            process = subprocess.run(['gh','api',f'repos/DDDHL0704/riftbound/actions/artifacts/{meta["id"]}/zip'],stdout=out,stderr=subprocess.PIPE,timeout=60)
        data = temporary.read_bytes()
        correct = process.returncode == 0 and len(data) == meta['size_in_bytes'] and 'sha256:' + hashlib.sha256(data).hexdigest() == meta['digest']
        if correct:
            with zipfile.ZipFile(temporary) as z: assert z.testzip() is None
            temporary.rename(path)
            break
        failed = work / 'ci-originals' / (str(run) + '-' + name + '-original-failed-download-' + str(attempt) + '.bin.gz')
        failed.write_bytes(gzip.compress(data,mtime=0))
        failure = {'atUtc':now(),'exitCode':process.returncode,'rawBytes':len(data),'rawSha256':hashlib.sha256(data).hexdigest(),
            'originalFailedBytesGzip':str(failed),'stderr':process.stderr.decode(errors='replace'),'notAValidResultArtifact':True}
        failed.with_suffix('.json').write_text(json.dumps(failure,indent=2)+'\n')
        temporary.unlink()
        if attempt == 3: raise RuntimeError('Original download could not be verified for ' + name)
        time.sleep(4)
    proof.append({'name':name,'artifactId':meta['id'],'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'backendSizeDigestAndAllZipCrcVerified':True})
    print(name,'ORIGINAL_SIZE_SHA_CRC_VERIFIED',flush=True)
result={'atUtc':now(),'fixedCommit':fixed,'runId':run,'completedSqlResultArtifacts':proof,'fullRuleSuiteAndOverallTerminalNotInferred':True,'noNativeInstallersDownloadedAgain':True}
with (work/'fixed43-completed-sql-artifacts-download-v1.json').open('x') as out:out.write(json.dumps(result,indent=2)+'\n')
