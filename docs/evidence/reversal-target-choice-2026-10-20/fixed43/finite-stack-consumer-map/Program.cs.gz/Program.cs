using System.Text.Json;
using Riftbound.Engine;

var all = CardBehaviorRegistry.GetAll();
var rows = all.Where(b => b.CountersTargetStackSpell || b.GainsControlOfTargetStackSpell
    || b.MayPayPowerToGainControlAndRemakeSpellChoices)
    .OrderBy(b => b.CardNo, StringComparer.Ordinal).ThenBy(b => b.EffectKind, StringComparer.Ordinal)
    .Select(b => new { b.CardNo, b.DisplayName, b.EffectKind, b.TargetScope,
        b.CountersTargetStackSpell, b.CanCounterAbilities, b.CounterUnlessControllerPaysMana,
        b.GainsControlOfTargetStackSpell, b.MayPayPowerToGainControlAndRemakeSpellChoices,
        b.MaxTargetManaCost, b.MaxTargetPowerCost, b.CounteredStackItemDestination,
        b.PreventsTargetSpellControllerPlayingSpellsThisTurn }).ToArray();
Console.WriteLine(JsonSerializer.Serialize(new {
    status = "FINITE_ACTUAL_FIXED_REGISTRY_CONSUMER_DISCOVERY_NOT_SEMANTIC_CERTIFICATION",
    actualRuleInputs = RuleInputIdentity.Current, registryDefinitionCount = all.Count,
    consumers = rows, lexicalSnapshot17IsNotTheSameAsAllCodeConsumers = true,
    noDatabaseConnectionStateSeedSourceOrTestMutation = true,
    wholePrintingFamilyOrSourceUniverseCertified = false },
    new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true }));
