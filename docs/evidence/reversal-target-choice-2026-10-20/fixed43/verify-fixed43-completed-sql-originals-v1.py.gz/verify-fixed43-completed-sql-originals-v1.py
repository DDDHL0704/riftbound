import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

work = Path(__file__).resolve().parent
root = work.parents[2]
fixed = '43d5b84e867eb09ca0570ed8774832ce70b04d87'
run = 39397913669
sha = lambda b: hashlib.sha256(b).hexdigest()
metadata = {a['name']:a for a in json.loads((work / 'fixed43-completed-sql-partial-artifacts-original-v1.json').read_text())['artifacts']}
verified_artifacts = {}

def original(name):
    path = work / 'ci-originals' / (str(run) + '-' + name + ('-v2.zip' if name == 'native-network-results' else '.zip'))
    data = path.read_bytes()
    assert len(data) == metadata[name]['size_in_bytes'] and 'sha256:' + sha(data) == metadata[name]['digest']
    z = zipfile.ZipFile(path)
    assert z.testzip() is None
    verified_artifacts[name] = {'path': str(path.relative_to(root)), 'sha256': sha(data), 'bytes': len(data)}
    return z

manifest_bytes = subprocess.check_output(['git','show',fixed+':tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'], cwd=root)
ids = [c['id'] for c in json.loads(manifest_bytes)['cases']]
assert len(ids) == len(set(ids)) == 46
parts = []
for i in range(4):
    with original('postgres-partition-' + str(i)) as z:
        receipt_raw = z.read('ci-postgres/partition-receipt.json')
        d = json.loads(receipt_raw)
        assert d['status'] == 'REAL_POSTGRES_PARTITION_COMPLETE' and d['fixedCommit'] == fixed
        assert d['manifestSha256'] == sha(manifest_bytes) and d['orderedDefaultCases'] == ids
        assert d['partitionIndex'] == i and d['partitionCount'] == 4
        assert d['expectedCases'] == d['completedCases'] == [e['id'] for e in d['executions']] == ids[i::4]
        assert [e['ordinal'] for e in d['executions']] == list(range(i, len(ids), 4))
        assert all(e['status'] == 'PASSED' for e in d['executions'])
        for row in d['outputFiles']:
            data = z.read('ci-postgres/' + row['path'])
            assert len(data) == row['bytes'] and sha(data) == row['sha256']
        parts.append({'partitionIndex': i, 'cases': ids[i::4], 'receiptSha256': sha(receipt_raw),
                      'outputs': len(d['outputFiles']), 'actualRuleInputs': d['actualRuleInputs'], 'runtimeAssemblies': d['runtimeAssemblies']})
assert len({json.dumps(p['actualRuleInputs'], sort_keys=True) for p in parts}) == 1
assert len({json.dumps(p['runtimeAssemblies'], sort_keys=True) for p in parts}) == 1
with original('postgres-results') as z:
    gate = json.loads(z.read('result.json'))
    assert gate['status'] == 'FIXED_COMMIT_ALL_SQL_PARTITIONS_AND_NATIVE_NETWORK_PASS' and gate['fixedCommit'] == fixed
    assert gate['manifestSha256'] == sha(manifest_bytes) and gate['caseCount'] == 46 and gate['orderedDefaultCases'] == ids
    assert all(v == 'success' for v in gate['jobs'].values())
    for g, p in zip(gate['partitions'], parts):
        assert all(g[k] == p[k] for k in ['partitionIndex', 'cases', 'receiptSha256', 'actualRuleInputs', 'runtimeAssemblies'])
with original('native-network-results') as z:
    network_logs = {n: sha(z.read(n)) for n in z.namelist()}
    log_name = next(n for n in z.namelist() if n.endswith('native-network.log'))
    network_log = z.read(log_name).decode()
    identity_row = json.loads(next(line.removeprefix('NATIVE_ROOM_IDENTITY_EVIDENCE ') for line in network_log.splitlines() if line.startswith('NATIVE_ROOM_IDENTITY_EVIDENCE ')))
    assert identity_row['rejectedActions'] == 15 and identity_row['leakedPrivateMessages'] == 0 and identity_row['validReconnectTokenWasSupplied'] is True
    assert identity_row['identities'] == ['ANONYMOUS','FAILED_KEY','OTHER_HANDLE']
    commit_files = [n for n in z.namelist() if n.endswith('commit.txt')]
    assert len(commit_files) == 1 and z.read(commit_files[0]).decode().strip() == fixed
    assert '15 rejected actions, three independent connection identities, real-token possession rejected' in network_log
    assert 'socket loss, authenticated room restore, fresh snapshot, rejected-token guard.' in network_log

result = {'status':'PASS_FIXED43_ACTUAL_COMPLETED_FOUR_SQL_PARTITIONS_AND_NETWORK_ORIGINALS_OVERALL_FULL_STILL_SEPARATE',
    'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fixedCommit':fixed,'runId':run,
    'all46DefaultSqlIdentitiesExactOnceInOriginalOrder':True,'orderedDefaultCases':ids,'manifestSha256':sha(manifest_bytes),
    'partitions':parts,'actualSqlOutputFileCount':sum(p['outputs'] for p in parts),'verifiedOriginalArtifacts':verified_artifacts,
    'networkOriginalFileHashes':network_logs,'networkRejectedActions':identity_row['rejectedActions'],
    'networkLeakedPrivateMessages':identity_row['leakedPrivateMessages'],'validReconnectTokenWasSupplied':identity_row['validReconnectTokenWasSupplied'],
    'actualNetworkIdentities':identity_row['identities'],'overallRuleSuiteAndFullTerminalNotInferred':True,
    'currentReversal47thSqlCaseAndMacNativeOrWindowsPhysicalNotCovered':True}
with (work/'fixed43-completed-sql-and-network-original-readback-v1.json').open('x') as out:
    out.write(json.dumps(result,indent=2)+chr(10))
print(result['status'],len(ids),result['actualSqlOutputFileCount'],flush=True)
