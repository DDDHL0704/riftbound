import ast
import datetime
import fcntl
import gzip
import hashlib
import json
import os
from pathlib import Path
import plistlib
import shutil
import socket
import subprocess
import time
import urllib.request

os.umask(0o077)
work = Path(__file__).resolve().parent
root = work.parents[2]
pg = Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin')
cluster = root / 'var/qa/permanent-play-here-base-20261017/postgres'
sock = Path('/tmp/rft-here-family-20261018-55486')
tables = ['matches', 'match_players', 'command_log', 'game_events', 'state_snapshots', 'snapshots', 'action_prompts']
read_env = dict(os.environ, PGOPTIONS='-c default_transaction_read_only=on')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
guard_source = root / 'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes = [n for n in ast.parse(guard_source.read_text()).body if isinstance(n, ast.FunctionDef)
         and n.name in {'query', 'rooms', 'digests', 'observe_lock'}]
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(guard_source), 'exec'), globals())
publication = json.loads((work / 'fixed-api-publication-v1.json').read_text())
prefix_publication = json.loads((work / 'fixed-prefix-and-reader-publication-v1.json').read_text())
reader_publication = json.loads((work / 'fixed-original-frame-export-reader-publication-v1.json').read_text())
security_work = root / 'var/qa/native-signalr-runtime-patch-20261020'
separate_security = json.loads((security_work / 'patched-production-runtime-publication-v1.json').read_text())
previous_fixed = root / 'var/qa/conditional-counter-payment-fixed-a653e547-20261020'
network = {'actualNewRoom': json.loads((previous_fixed / 'fixed-native-control-owner-v1.json').read_text())['room']}
original = json.loads((previous_fixed / 'fixed-native-control-original209-audit43-native-baseline-v1.json').read_text())
apps = json.loads((work / 'native-app-inputs.json').read_text())
assert apps['fixedCommit'] == publication['fixedCommit'] == '43d5b84e867eb09ca0570ed8774832ce70b04d87'
package_proof = json.loads((work / 'actual-both-platform-patched-common-readback-v1.json').read_text())
assert package_proof['bothPlatformsActualCommonSha256'] == '550058f27f5577e20184a0e0d198c90c87079b45dffab170423f6fe030c0687d'
hook = security_work / 'assembly-audit-hook/runtime/probe.dll'
hook_files = {str(p): sha(p) for p in hook.parent.iterdir() if p.is_file()}

runtime = work / 'fixed-api'
prefix = work / 'native-payment-prefix'
reader = work / 'reader-runtime'
output = work / 'fixed-native-control-owner-v1.json'
ready = work / 'fixed-native-control-ready-v1.json'
stop = work / 'fixed-native-control-stop-v1.json'
restart = work / 'fixed-native-control-restart-request-v1.json'
evidence = work / 'actual-native-control-prefix-v1'
assert not any(p.exists() for p in [output, ready, stop, restart, evidence])


def write(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def frozen():
    assert all(sha(Path(p)) == h for p, h in hook_files.items())
    assert all(sha(runtime / p) == h for p, h in publication['apiRuntimeHashes'].items())
    assert all(sha(prefix / p['path']) == p['sha256'] for p in prefix_publication['prefixRuntimeFiles'])
    assert all(sha(reader / p) == h for p, h in reader_publication['readerRuntimeFiles'].items())
    # The immutable security candidate was compiled from clean fixed43.
    # The complete 3308 declared source inputs remain frozen through this owner.
    assert all(sha(root / p) == h for p, h in separate_security['sourceInputHashes'].items())
    for row in apps['apps']:
        assert all(sha(Path(row['app']) / p) == h for p, h in apps['ciManagedAndPckPayloads'].items())


frozen()
guard = (root / 'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a')
fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
proof = {'status': 'STARTING_FIXED_NATIVE_CANDIDATE_ORIGINAL_PREFIX', 'startedAtUtc': now(),
         'fixedCommit': publication['fixedCommit'], 'actualRuleInputs': publication['actualRuleInputs'],
         'nativeClientCommit': apps['fixedCommit'], 'actualSharedFrameworkVersion': '10.0.13',
         'fixedSecurityCandidateApiAndPatchedNativeInputs': True,
         'scope': 'Actual fixed security candidate, patched Common8.0.32/10.0.13 and original real database. Gateway prefix and visible desktop acceptance remain separately stated.',
         'ownedApiProcesses': [], 'lockAtStart': observe_lock()}
write(output, proof)
started = False
api = power = driver = None
baseline = None


def start_api(index):
    global api
    path = work / ('fixed-native-control-api-' + str(index) + '.log')
    with path.open('xb') as log:
        api = subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet', str(runtime / 'Riftbound.Api.dll')], cwd=runtime,
            stdout=log, stderr=subprocess.STDOUT, start_new_session=True,
            env=dict(os.environ, ASPNETCORE_ENVIRONMENT='Production', ASPNETCORE_URLS='http://127.0.0.1:15847',
                     ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit',
                     DOTNET_STARTUP_HOOKS=str(hook), RIFTBOUND_ASSEMBLY_AUDIT=str(work / ('actual-fixed43-api-loaded-assemblies-' + str(index) + '-v1.ndjson'))))
    for attempt in range(150):
        assert api.poll() is None
        try:
            with urllib.request.urlopen('http://127.0.0.1:15847/health', timeout=.5) as response:
                health = json.load(response)
            assert health['persistenceMode'] == 'postgres' and health['environment'] == 'Production'
            break
        except OSError:
            time.sleep(.1)
    else:
        raise AssertionError('Owned fixed API did not become ready.')
    assert set(subprocess.check_output(['/usr/sbin/lsof', '-tiTCP:15847', '-sTCP:LISTEN'], text=True).splitlines()) == {str(api.pid)}
    proof['ownedApiProcesses'].append({'pid': api.pid, 'health': health, 'index': index})
    write(output, proof)


def export(room, filename):
    path = work / filename
    command = ['/Users/dinghaolin/.dotnet/dotnet', 'exec', '--depsfile', str(reader / 'Riftbound.Api.deps.json'),
        '--runtimeconfig', str(reader / 'Riftbound.Api.runtimeconfig.json'), str(reader / 'FixedNativeFrameExport.dll'), room, str(path)]
    raw = subprocess.check_output(command, cwd=reader,
        env=dict(os.environ, ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit'))
    metadata = json.loads(raw)
    write(path.with_suffix('.metadata.json'), metadata)
    return metadata


try:
    assert subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), 'status'], capture_output=True).returncode == 3
    with socket.socket() as port:
        assert port.connect_ex(('127.0.0.1', 15847)) != 0
    power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())])
    proof.update(ownRunnerPid=os.getpid(), boundIdleAssertionPid=power.pid)
    sock.mkdir(exist_ok=True)
    subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-l', str(work / 'fixed-native-control-postgres-v1.log'),
                    '-o', f'-p 55486 -h 127.0.0.1 -k {sock}', '-w', 'start'], capture_output=True, check=True)
    started = True
    audit = rooms('riftbound_acceptance')
    native = rooms('riftbound_here_native')
    assert audit == original['auditRooms'] and len(audit) == 209
    assert native == sorted(original['nativeRooms'] + [network['actualNewRoom']]) and len(native) == 44
    assert digests('riftbound_acceptance', audit) == original['auditSevenTables']
    assert digests('riftbound_here_native', original['nativeRooms']) == original['nativeSevenTables']
    baseline = {'atUtc': now(), 'auditRooms': audit, 'nativeRooms': native,
                'auditSevenTables': digests('riftbound_acceptance', audit), 'nativeSevenTables': digests('riftbound_here_native', native)}
    write(work / 'fixed-native-control-original209-audit44-native-baseline-v1.json', baseline)
    start_api(0)
    with (work / 'fixed-native-control-prefix-writer-v1.log').open('xb') as log:
        driver = subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet', str(prefix / 'Fixed43NativePaymentPrefix.dll'),
            'http://127.0.0.1:15847', str(evidence), str(work)], cwd=prefix, stdout=log, stderr=subprocess.STDOUT,
            env=dict(os.environ, DOTNET_STARTUP_HOOKS=str(hook), RIFTBOUND_ASSEMBLY_AUDIT=str(work / 'actual-fixed43-native-prefix-loaded-assemblies-v1.ndjson')))
        assert driver.wait(timeout=780) == 0
    receipt = json.loads((evidence / 'pending-original-native-prefix-receipt.json').read_text())
    room = receipt['room']
    assert sorted(set(rooms('riftbound_here_native')) - set(native)) == [room]
    assert digests('riftbound_acceptance', audit) == baseline['auditSevenTables']
    assert digests('riftbound_here_native', native) == baseline['nativeSevenTables']
    for label in ['a', 'b']:
        shutil.copy2(evidence / ('session-native-' + label + '.json'), work / ('session-' + label + '.json'))
    proof.update(status='FIXED_CURRENT_NATIVE_PREFIX_READY_PAYMENT_PENDING', room=room,
                 prefixAcceptedCommands=receipt['acceptedCommands'], actualTick=receipt['actualTick'], actualTurn=receipt['actualTurn'],
                 allOriginal209Audit44NativeSevenTablesExact=True)
    write(output, proof)
    write(ready, {'atUtc': now(), 'room': room, 'players': receipt['players'], 'apiPid': api.pid,
                  'fixedCommit': apps['fixedCommit'], 'actualRuleInputs': publication['actualRuleInputs'],
                  'prefixAcceptedCommands': receipt['acceptedCommands'], 'currentNativeControlsAndDesktopStillOpen': True})
    print('FIXED_NATIVE_PAYMENT_PREFIX_READY', room, flush=True)
    deadline = time.monotonic() + 3600
    while not stop.exists():
        assert api.poll() is None and time.monotonic() < deadline
        if restart.exists() and len(proof['ownedApiProcesses']) == 1:
            before = export(room, 'headless-before-api-cold-restart-v1.json.gz')
            assert before['commands'] == receipt['acceptedCommands'] + 1 and before['priorAnswers'] == 1
            api.terminate()
            assert api.wait(timeout=30) == 0
            proof['firstApiGracefulExitCode'] = 0
            frozen()
            start_api(1)
            write(work / 'fixed-native-control-api-restarted-v1.json', {'atUtc': now(), 'newApiPid': api.pid,
                'sameFrozenApiAndRuleInputs': True, 'originalDatabaseRetained': True,
                'originalBeforeFrame': before, 'nativeRestoredControlsNotYetInferred': True})
        time.sleep(.2)
    proof['status'] = 'FIXED_NATIVE_CONTROL_STOP_REQUESTED_ORIGINAL_HISTORY_RETAINED'
except BaseException as error:
    proof.update(status='FAILED_OR_INTERRUPTED_FIXED_NATIVE_CONTROL_ORIGINAL_PREFIX_RETAINED',
                 errorType=type(error).__name__, errorMessage=str(error))
    raise
finally:
    if driver is not None and driver.poll() is None:
        driver.terminate()
        driver.wait(timeout=30)
    if api is not None and api.poll() is None:
        api.terminate()
        proof['ownApiGracefulExitCode'] = api.wait(timeout=30)
    if started:
        if baseline is not None:
            proof['allOriginal209AuditSevenTablesExactAtStop'] = digests('riftbound_acceptance', baseline['auditRooms']) == baseline['auditSevenTables']
            proof['allOriginal44NativeSevenTablesExactAtStop'] = digests('riftbound_here_native', baseline['nativeRooms']) == baseline['nativeSevenTables']
            proof['nativeRoomIdsAtStop'] = rooms('riftbound_here_native')
        proof['ownPostgresSmartStopped'] = subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-m', 'smart', '-w', '-t', '20', 'stop'], capture_output=True).returncode == 0
    if power is not None:
        if power.poll() is None:
            power.terminate()
            power.wait(timeout=10)
        proof['boundIdleAssertionEnded'] = power.poll() is not None
    frozen()
    proof.update(finishedAtUtc=now(), lockAtEnd=observe_lock(), frozenInputsAndRuntimeExact=True, originalDatabaseRetained=True)
    write(output, proof)
    fcntl.flock(guard, fcntl.LOCK_UN)
