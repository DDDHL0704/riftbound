using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
if (args.SequenceEqual(["identity-print"])) { Console.WriteLine(JsonSerializer.Serialize(RuleInputIdentity.Current, json)); return; }
Check(args.Length == 4, "Exact original native prefix folder and fresh full-frame output required.");
var folder = Path.GetFullPath(args[0]); var path = Path.GetFullPath(args[1]); Check(!File.Exists(path), "Do not overwrite original native source-audit frames.");
using var nativeManifest = JsonDocument.Parse(File.ReadAllText(args[2]));
var currentNativeCommit = nativeManifest.RootElement.GetProperty("fixedCommit").GetString();
Check(currentNativeCommit == "43d5b84e867eb09ca0570ed8774832ce70b04d87", "Exact current fixed native manifest required.");
foreach (var app in nativeManifest.RootElement.GetProperty("apps").EnumerateArray())
foreach (var payload in nativeManifest.RootElement.GetProperty("ciManagedAndPckPayloads").EnumerateObject())
    Check(Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(Path.Combine(app.GetProperty("app").GetString()!, payload.Name))))
        == payload.Value.GetString(), "Both actual fixed native original managed/PCK payloads match the declared CI bytes.");
var settings = new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
Check(settings.Host == "127.0.0.1" && settings.Port == 55486 && settings.Database == "riftbound_here_native"
    && settings.Username == "codex_riftbound_audit", "Only the existing dedicated native audit database.");
settings.Options = "-c default_transaction_read_only=on";
await using var source = NpgsqlDataSource.Create(settings.ConnectionString);
using var originalPrefix = JsonDocument.Parse(File.ReadAllText(Path.Combine(folder, "pending-original-native-prefix-receipt.json")));
using var originalCommands = JsonDocument.Parse(File.ReadAllText(Path.Combine(folder, "original-accepted-native-prefix-intents.json")));
var prefix = originalPrefix.RootElement; var room = prefix.GetProperty("room").GetString()!;
var actors = prefix.GetProperty("players").EnumerateArray().Select(v => v.GetString()!).ToArray(); var count = prefix.GetProperty("acceptedCommands").GetInt32();
var frame = await new PostgresMatchRecoveryStore(source).LoadAsync(room, default) ?? throw new Exception("Original actual native room required.");
Check(frame.IsConsistent && frame.Commands.Count == count + 25 && frame.Commands.All(c => c.Accepted && c.RuleInputs == RuleInputIdentity.Current)
    && frame.AuthoritativeState!.RuleInputs == RuleInputIdentity.Current && frame.OpeningSeed != 0
    && frame.ReplayInitialState is { Tick: 0 } initial && initial.CardObjects.Count == 0,
    "Original blank opening, nonzero private seed, accepted commands and exact runtime identities.");
for (var i = 0; i < count; i++)
{
    var row = originalCommands.RootElement[i]; var command = frame.Commands[i];
    Check(command.PlayerId == row.GetProperty("actor").GetString()
        && JsonNode.DeepEquals(JsonNode.Parse(command.RawCommand!.Value.GetRawText()), JsonNode.Parse(row.GetProperty("rawCommand").GetRawText())),
        "Every original production gateway prefix actor and complete raw command remains exact.");
}
var native = frame.Commands.Skip(count).Take(4).ToArray();
Check(native[0].PlayerId == actors[0] && native[1].PlayerId == actors[0]
    && native[0].CommandType == CommandTypes.PayCost && native[1].CommandType == CommandTypes.PayCost
    && native[2].PlayerId == actors[0] && native[3].PlayerId == actors[1]
    && native[2].CommandType == CommandTypes.PassPriority && native[3].CommandType == CommandTypes.PassPriority,
    "The four actual native commands are payer pay, independent payer decline and both original normal passes.");
var pay = (PayCostCommand)GameCommandJsonMapper.Map(native[0].RawCommand!.Value);
var decline = (PayCostCommand)GameCommandJsonMapper.Map(native[1].RawCommand!.Value);
Check(pay.PaymentChoiceIds!.SequenceEqual(["SPEND_MANA:2"]) && decline.PaymentChoiceIds!.SequenceEqual(["DECLINE"])
    && pay.PaymentId != decline.PaymentId && pay.PaymentWindow == "RULE_REPLACEMENT" && decline.PaymentWindow == "RULE_REPLACEMENT",
    "Actual native button decisions use independent current server identities and exact selected choices.");
var targets = prefix.GetProperty("targetStackItemIds").EnumerateArray().Select(v => v.GetString()!).ToArray();
var spellSources = prefix.GetProperty("targetSourceObjectIds").EnumerateArray().Select(v => v.GetString()!).ToArray();
var counter = prefix.GetProperty("sourceObjectId").GetString()!; var state = frame.AuthoritativeState!;
Check(state.Status == "FINISHED" && state.WinnerPlayerId == actors[0] && state.TurnNumber == 48
    && state.PlayerScores[actors[0]] == 8 && state.PlayerScores[actors[1]] == 0 && state.StackItems.Count == 0 && state.TriggerQueue.Count == 0
    && state.PendingRuleChoice is null && state.PendingPayment is null && state.PendingEffectPlay is null
    && state.RunePools[actors[0]].Mana == 0 && state.RunePools[actors[1]].Mana == 0
    && spellSources.All(s => state.PlayerZones[actors[0]].Graveyard.Contains(s)) && state.PlayerZones[actors[1]].Graveyard.Contains(counter),
    "Actual native decisions finish both repeated instructions, spend only first two mana, and preserve physical spell ownership.");
var later = frame.Events.Skip((int)frame.Commands[count - 1].CompletedEventSequence)
    .Take((int)(frame.Commands[count + 3].CompletedEventSequence - frame.Commands[count - 1].CompletedEventSequence)).ToArray();
var counters = later.Where(e => e.Event.Kind == "STACK_ITEM_COUNTERED").ToArray();
Check(counters.Length == 1 && Payload(counters[0]).GetProperty("stackItemId").GetString() == targets[1], "Only the independently refused second target is countered.");
var paid = later.Where(e => e.Event.Kind == "COST_PAID" && Payload(e).TryGetProperty("reason", out var r) && r.GetString() == "COUNTER_TARGET_MANA_PAYMENT").ToArray();
Check(paid.Length == 1 && Payload(paid[0]).GetProperty("playerId").GetString() == actors[0]
    && Payload(paid[0]).GetProperty("mana").GetInt32() == 2 && Payload(paid[0]).GetProperty("power").GetInt32() == 0,
    "One exact actual target-controller mana payment, no power.");
Check(later.Count(e => e.Event.Kind == "CARD_DRAWN") == 1, "Only the surviving original spell draws after both native passes.");
var history = new Dictionary<string, int>(); var pending = 0; var second = 0;
await using (var connection = await source.OpenConnectionAsync())
{
    Check((string)(await new NpgsqlCommand("show transaction_read_only", connection).ExecuteScalarAsync())! == "on", "Actual independent database connection is read-only.");
    foreach (var table in new[] { "state_snapshots", "snapshots", "action_prompts" })
    {
        await using var query = new NpgsqlCommand($"select payload::text from {table} where match_id=@room order by id", connection);
        query.Parameters.AddWithValue("room", room); await using var rows = await query.ExecuteReaderAsync(); var n = 0;
        while (await rows.ReadAsync())
        {
            var raw = rows.GetString(0); var node = JsonNode.Parse(raw);
            var roundtrip = table switch {
                "state_snapshots" => JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<MatchState>(raw, json), json),
                "snapshots" => JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<SnapshotDto>(raw, json), json),
                _ => JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<ActionPromptDto>(raw, json), json) };
            Check(JsonNode.DeepEquals(node, roundtrip), "Every field/null in every original native historical state, private view and prompt survives the independent typed read."); n++;
            if (table == "state_snapshots" && JsonSerializer.Deserialize<MatchState>(raw, json)!.PendingRuleChoice is { } choice)
            {
                Check(choice.Request.PlayerId == actors[0] && choice.Request.Kind == "COUNTER_TARGET_MANA_PAYMENT" && choice.Request.ManaCost == 2,
                    "Both original persisted decisions retain the correct payer, kind and cost."); pending++;
                if (choice.Answers.Count == 1) { Check(choice.Answers[0].OptionId == "SPEND_MANA:2" && choice.Request.Preview!.RunePools[actors[0]].Mana == 2,
                    "Actual second native decision retains first accepted answer and two preview mana."); second++; }
            }
        }
        Check(n > 0, "Actual original history required."); history[table] = n;
    }
}
Check(history["state_snapshots"] == count + 25 && pending == 2 && second == 1, "Every original native accepted state and both payment checkpoints retained.");
using (var checkpointZip = new GZipStream(File.OpenRead(args[3]), CompressionMode.Decompress))
using (var checkpoint = await JsonDocument.ParseAsync(checkpointZip))
{
    var old = checkpoint.RootElement;
    Check(old.GetProperty("commands").GetArrayLength() == count + 4 && old.GetProperty("events").GetArrayLength() == 344,
        "Exact independently verified original 59-command payment checkpoint required.");
    Check(JsonNode.DeepEquals(JsonSerializer.SerializeToNode(frame.Commands.Take(count + 4), json), JsonNode.Parse(old.GetProperty("commands").GetRawText()))
        && JsonNode.DeepEquals(JsonSerializer.SerializeToNode(frame.Events.Take(344), json), JsonNode.Parse(old.GetProperty("events").GetRawText()))
        && JsonNode.DeepEquals(JsonSerializer.SerializeToNode(frame.ReplayInitialState, json), JsonNode.Parse(old.GetProperty("replayInitialState").GetRawText())),
        "Every field/null of all original accepted commands/events and blank initial state remains unchanged before native score continuation.");
}
string[] expectedNativeContinuation = ["TAP_RUNE", "PLAY_CARD", "END_TURN", "END_TURN", "MOVE_UNIT", "PASS_FOCUS", "PASS_FOCUS", "END_TURN", "END_TURN", "END_TURN", "END_TURN", "END_TURN", "END_TURN", "END_TURN", "END_TURN", "END_TURN", "END_TURN", "END_TURN", "END_TURN", "END_TURN", "END_TURN"];
Check(frame.Commands.Skip(count + 4).Select(c => c.CommandType).SequenceEqual(expectedNativeContinuation),
    "Only observed actual native rune activation, unit play, one battlefield move, two focus passes and sixteen normal end turns.");
Check(frame.Events.Count == 533 && frame.Events.Count(e => e.Event.Kind == "MATCH_WON") == 1
    && frame.Events.All(e => e.Event.Kind is not ("PLAYER_SURRENDERED" or "MATCH_SURRENDERED" or "DECK_OUT" or "DECK_EXHAUSTED_LOSS")),
    "Normal score victory retains exact event count and no surrender or exhaustion event.");
Check(state.PlayerZones.Values.All(z => z.MainDeck.Count > 0), "Both decks remain nonempty at ordinary held-field score victory.");
var scores = frame.Events.Where(e => e.Event.Kind == "SCORE_GAINED").Select(Payload).ToArray();
Check(scores.Length == 8 && scores.Select(p => p.GetProperty("score").GetInt32()).SequenceEqual(Enumerable.Range(1, 8))
    && scores.All(p => p.GetProperty("playerId").GetString() == actors[0] && p.GetProperty("amount").GetInt32() == 1)
    && scores.Take(1).All(p => p.GetProperty("reason").GetString() == "BATTLEFIELD_CONQUERED_SCORE")
    && scores.Skip(1).All(p => p.GetProperty("reason").GetString() == "BATTLEFIELD_HELD_SCORE"),
    "One original conquest followed by seven held-field points produce all eight points through ordinary rules.");
var win = Payload(frame.Events.Single(e => e.Event.Kind == "MATCH_WON"));
Check(win.GetProperty("winnerPlayerId").GetString() == actors[0] && win.GetProperty("winningScore").GetInt32() == 8,
    "Persisted winner and winning score agree with both actual native victory/defeat windows.");
var errors = await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame, new CoreRuleEngine(), default);
Check(errors.Count == 0, "Full original actual native action/event/state replay: " + string.Join(';', errors));
await using (var file = new FileStream(path, FileMode.CreateNew))
await using (var zip = new GZipStream(file, CompressionLevel.SmallestSize)) await JsonSerializer.SerializeAsync(zip, frame, json);
await using (var zip = new GZipStream(File.OpenRead(path), CompressionMode.Decompress))
{
    var node = await JsonNode.ParseAsync(zip); Check(JsonNode.DeepEquals(node, JsonSerializer.SerializeToNode(frame, json)), "Saved original full frame fields and nulls exact.");
}
Console.WriteLine(JsonSerializer.Serialize(new { status = "PASS_INDEPENDENT_READONLY_ACTUAL_NATIVE_PAY_DECLINE_NORMAL_SCORE_WIN_AND_ENTIRE_REPLAY",
    room, commands = frame.Commands.Count, events = frame.Events.Count, originalGatewayPrefixCommands = count,
    actualNativeButtonCommands = frame.Commands.Count - count, actualNativePaymentAndPriorityCommands = 4, actualNativeNormalScoreContinuationCommands = 21, actualHistoricalPayloads = history, originalPaymentStates = pending, originalSecondPaymentStates = second,
    actualBackendRuleInputs = RuleInputIdentity.Current, originalNonzeroPrivateSeedRetainedNotPrinted = true,
    originalRawPrefixCommandsExact = true, originalAllFieldsNullsPrivateHistoryAndFullReplayMatched = true,
    originalFrameSha256 = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(path))),
    phaseAndActionVisualAcceptance = "SEPARATE_REAL_CURRENT_WINDOW_CAPTURES", nativeClientCommit = currentNativeCommit,
    actualBothFixedNativePayloadsIndependentlyVerified = true, wholeGameNormalScoreCertified = true, physicalWindowsNotCertified = true, winningScore = state.PlayerScores[actors[0]], finalTurn = state.TurnNumber }, json));
static JsonElement Payload(RecoveredEvent e) => JsonSerializer.SerializeToElement(e.Event.Payload);
static void Check(bool value, string reason) { if (!value) throw new Exception(reason); }
