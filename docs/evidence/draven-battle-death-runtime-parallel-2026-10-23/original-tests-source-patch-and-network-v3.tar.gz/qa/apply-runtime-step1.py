from pathlib import Path
r=Path.cwd()
def edit(name,old,new,count=None):
 p=r/'src/Riftbound.Engine'/name;s=p.read_text();n=s.count(old)
 assert n>0 and(count is None or n==count),(name,n,old[:100]);p.write_text(s.replace(old,new))
edit('CoreRuleEngine.DravenBattleDeathScore.cs','string BattlefieldId, long DeathTick, string DeathId, string Role);','''string BattlefieldId, long DeathTick, string DeathId, string Role)
{
    public string? OpponentId { get; init; }
}''',1)
edit('CoreRuleEngine.DravenBattleDeathScore.cs','{ SourceCardNo = context.CardNo, EnqueuedAtTick = context.DeathTick };','{ SourceCardNo = context.CardNo, EnqueuedAtTick = context.DeathTick, DravenBattleDeathScore = context };',1)
# Immutable public source facts, captured before removal; publish only committed deaths.
edit('CoreRuleEngine.DeathObservers.cs','    public DestructionAttribution? Attribution { get; init; }','    public DravenBattleDeathScoreContext? DravenBattleDeathScore { get; init; }\n    public DestructionAttribution? Attribution { get; init; }',1)
edit('CoreRuleEngine.DeathObservers.cs','''        return new($"death-{frame.Origin.Tick}-{frame.DeathSequence++}",frame.CurrentDestructionBatch ?? frame.DestructionBatchSequence++,state.TurnNumber,fact,observers) {
            LastBreathMights''','''        var deathId = $"death-{frame.Origin.Tick}-{frame.DeathSequence++}";
        return new(deathId,frame.CurrentDestructionBatch ?? frame.DestructionBatchSequence++,state.TurnNumber,fact,observers) {
            DravenBattleDeathScore = CaptureDravenBattleDeathScore(state, zones, cards,
                frame.CurrentDestructionLocations ?? state.ObjectLocations, unit, deathId, state.Tick + 1),
            LastBreathMights''',1)
edit('CoreRuleEngine.DeathObservers.cs','''            QueueGraveyardPlays(state, death, deaths, queue, events);''','''            QueueGraveyardPlays(state, death, deaths, queue, events);
            if (death.DravenBattleDeathScore is { } dravenDeath)
            {
                var trigger = BuildDravenBattleDeathScoreTrigger(dravenDeath);
                queue.Add(trigger);
                events.Add(BuildTriggerQueuedEvent(trigger) with { Payload = new Dictionary<string, object?>(BuildTriggerQueuedEvent(trigger).Payload)
                    { ["dravenBattleDeathScore"] = dravenDeath, ["deathId"] = death.Id, ["deathBatch"] = death.Batch } });
            }''',1)
edit('CoreRuleEngine.RuleChoices.cs','        public LastKnownMightFrame? CurrentDestructionMightFrame { get; set; }','''        public LastKnownMightFrame? CurrentDestructionMightFrame { get; set; }
        public IReadOnlyDictionary<string, ObjectLocationState>? CurrentDestructionLocations { get; set; }''',1)
edit('CoreRuleEngine.DestructionReplacement.cs','        private readonly LastKnownMightFrame? previousMight = frame.CurrentDestructionMightFrame;','''        private readonly LastKnownMightFrame? previousMight = frame.CurrentDestructionMightFrame;
        private readonly IReadOnlyDictionary<string, ObjectLocationState>? previousLocations = frame.CurrentDestructionLocations;''',1)
edit('CoreRuleEngine.DestructionReplacement.cs','            frame.CurrentDestructionMightFrame = previousMight;','''            frame.CurrentDestructionMightFrame = previousMight;
            frame.CurrentDestructionLocations = previousLocations;''',1)
edit('CoreRuleEngine.DestructionReplacement.cs','        frame.CurrentDestructionBatch = frame.DestructionBatchSequence++;','''        frame.CurrentDestructionBatch = frame.DestructionBatchSequence++;
        frame.CurrentDestructionLocations = locations ?? state.ObjectLocations;''',1)
edit('MatchSession.cs','    public DravenBattleWinScoreContext? DravenBattleWinScore { get; init; }','''    public DravenBattleWinScoreContext? DravenBattleWinScore { get; init; }
    [System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull)]
    public DravenBattleDeathScoreContext? DravenBattleDeathScore { get; init; }''',2)
edit('MatchSession.cs','DravenBattleWinScore = item.DravenBattleWinScore,','DravenBattleWinScore = item.DravenBattleWinScore, DravenBattleDeathScore = item.DravenBattleDeathScore,',2)
edit('MatchSession.cs','        if (trigger.DravenBattleWinScore is not null) return','        if (trigger.DravenBattleDeathScore is not null) return "战斗中被摧毁：选择一名对手获得1分；双方响应后结算。";\n        if (trigger.DravenBattleWinScore is not null) return',2)
edit('MatchSession.cs','|| trigger.DravenBattleWinScore is not null)','|| trigger.DravenBattleWinScore is not null || trigger.DravenBattleDeathScore is not null)',1)
edit('MatchSession.cs','|| item.DravenBattleWinScore is not null\n','|| item.DravenBattleWinScore is not null || item.DravenBattleDeathScore is not null\n',1)
edit('CoreRuleEngine.cs','DravenBattleWinScore = trigger.DravenBattleWinScore,','DravenBattleWinScore = trigger.DravenBattleWinScore, DravenBattleDeathScore = trigger.DravenBattleDeathScore,',1)
edit('CoreRuleEngine.cs','        if (stackItem.DravenBattleWinScore is { } dravenScore)','''        if (stackItem.DravenBattleDeathScore is { OpponentId: { } opponent } dravenDeath)
            return ResolveDravenBattleDeathScore(state, stackItem, dravenDeath, opponent);
        if (stackItem.DravenBattleWinScore is { } dravenScore)''',1)
edit('CoreRuleEngine.cs','        if (pendingChoice.ChoiceWindow is AttachmentModeWindow or AttachmentModeTargetWindow)','''        if (pendingChoice.ChoiceWindow == DravenDeathOpponentWindow) return ResolveDravenDeathOpponentChoice(state, pendingChoice, submittedObjectIds);
        if (pendingChoice.ChoiceWindow is AttachmentModeWindow or AttachmentModeTargetWindow)''',1)
edit('CoreRuleEngine.FieldTriggers.cs','''        var item = state.StackItems.FirstOrDefault(i =>
''','''        var item = state.StackItems.FirstOrDefault(i =>
            i.DravenBattleDeathScore is { OpponentId: null } ||
''',1)
edit('CoreRuleEngine.FieldTriggers.cs','''        if (item is null) return result;
''','''        if (item is null) return result;
        if (item.DravenBattleDeathScore is not null) return PrepareDravenDeathOpponent(result, item);
''',1)
# Confirmation uses player IDs, separate from object incarnation targets.
p=r/'src/Riftbound.Engine/CoreRuleEngine.DravenBattleDeathScore.cs';s=p.read_text();pos=s.index('    // Opponent selection belongs')
s=s[:pos]+'''    private const string DravenDeathOpponentWindow = "DRAVEN_BATTLE_DEATH_OPPONENT";

    private static ResolutionResult PrepareDravenDeathOpponent(ResolutionResult result, StackItemState item)
    {
        var state = result.State;
        var legal = SeatPlayerIds(state).Where(id => id != item.ControllerId).ToArray();
        var choice = new PendingCardChoiceState("DRAVEN-DEATH:" + item.StackItemId, DravenDeathOpponentWindow,
            item.ControllerId, 1, 1, legal, legal, "选择一名对手获得1分；确认后双方可响应。",
            item.SourceObjectId, item.EffectKind) { ResolvingStackItemId = item.StackItemId };
        state = state with { PendingCardChoice = choice, PriorityPlayerId = null, ActivePlayerId = item.ControllerId };
        return result with { State = state, Snapshots = ResolutionResult.BuildSnapshots(state), Prompts = BuildCorePrompts(state) };
    }

    private static ResolutionResult ResolveDravenDeathOpponentChoice(MatchState state,
        PendingCardChoiceState choice, IReadOnlyList<string> selected)
    {
        var item = state.StackItems.FirstOrDefault(i => i.StackItemId == choice.ResolvingStackItemId);
        if (item?.DravenBattleDeathScore is not { OpponentId: null } context || selected.Count != 1
            || selected[0] == item.ControllerId || !state.Seats.ContainsKey(selected[0])
            || choice.PlayerId != item.ControllerId || choice.EffectKind != DravenBattleDeathScoreEffect)
            return RejectWithCorePrompts(state, "死亡技能的对手选择与原技能不匹配。", ErrorCodes.InvalidTarget);
        var confirmed = item with { DravenBattleDeathScore = context with { OpponentId = selected[0] } };
        var next = state with { Tick = state.Tick + 1, PendingCardChoice = null,
            StackItems = state.StackItems.Select(i => i.StackItemId == item.StackItemId ? confirmed : i).ToArray(),
            ActivePlayerId = state.StackItems[^1].ControllerId, PriorityPlayerId = state.StackItems[^1].ControllerId,
            PassedPriorityPlayerIds = [] };
        return new(true, null, next, [new("DRAVEN_DEATH_OPPONENT_CONFIRMED", "已确认死亡技能的得分对手",
            new Dictionary<string, object?> { ["stackItemId"] = item.StackItemId, ["controllerId"] = item.ControllerId,
                ["opponentId"] = selected[0], ["sourceObjectId"] = item.SourceObjectId })],
            ResolutionResult.BuildSnapshots(next), BuildCorePrompts(next));
    }

'''+s[pos:];p.write_text(s)
print('step 1 capture, committed death queue, context copy, ordinary opponent confirmation and resolver wired')
