from pathlib import Path
import datetime,hashlib,json,os,subprocess
w=Path(__file__).resolve().parent;pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=w/'own-postgres-v1';output=w/'independent-original-sql-v1';terminal=w/'independent-original-sql-owner-v1.json'
assert not output.exists()and not terminal.exists()
assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
psql=[str(pg/'psql'),'-h','127.0.0.1','-p','55497','-U','codex_draven_death','-d','draven_death_acceptance','-At','-c']
env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55497;Database=draven_death_acceptance;Username=codex_draven_death',PGOPTIONS='-c default_transaction_read_only=on')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts']
def hashes():
 return {t:hashlib.sha256(subprocess.check_output(psql+[f'select to_jsonb(t)::text from {t} t order by to_jsonb(t)::text'],env=env)).hexdigest()for t in tables}
proof={'startedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'RUNNING'};started=False
try:
 subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'postgres-independent-read-v1.log'),'-o','-p 55497 -h 127.0.0.1 -k /tmp/rft-draven-death-55497','-w','start'],capture_output=True,check=True);started=True
 proof['before']=hashes()
 with (w/'independent-original-sql-v1.log').open('xb')as log:
  r=subprocess.run(['/Users/dinghaolin/.dotnet/dotnet',str(w/'independent-sql-reader-v1/bin/Debug/net10.0/DravenDeathIndependentSqlReaderV1.dll'),str(output),str(w/'network-original-v1')],cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 proof['exitCode']=r.returncode;assert r.returncode==0
 proof['after']=hashes();assert proof['after']==proof['before']
 proof['status']='PASS_ORIGINAL_SEVEN_TABLES_UNCHANGED_INDEPENDENT_PREFIX_REPLAY'
except BaseException as e:proof.update(status='FAILED_ORIGINAL_READER_PRESERVED',error=str(e));raise
finally:
 if started:proof['postgresStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 proof['finishedAtUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat();terminal.write_text(json.dumps(proof,indent=2))
print(proof['status'])
