from pathlib import Path
import datetime,gzip,hashlib,json,os,resource,socket,subprocess,time,urllib.request
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
w=Path(__file__).resolve().parent;root=w.parents[2]
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');dotnet='/Users/dinghaolin/.dotnet/dotnet'
cluster=w/'own-postgres-v1';sock=Path('/tmp/rft-draven-death-55497');runtime=w/'fixed-api-runtime-v1';driver=w/'network-driver-v1/bin/Debug/net10.0'
output=w/'network-original-v1';private=w/'private-network-auth-v1';terminal=w/'network-owner-terminal-v1.json'
assert not cluster.exists() and not terminal.exists() and not output.exists() and not private.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def hashes(folder):return {str(p.relative_to(folder)):sha(p) for p in folder.rglob('*') if p.is_file()}
def sources():
 names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z','--','src','data'],cwd=root).split(b'\0')
 return {p.decode():sha(root/p.decode()) for p in names if p and (root/p.decode()).is_file()}
source_hashes=sources();runtime_hashes=hashes(runtime);driver_hashes=hashes(driver)
for name in ['Riftbound.Engine','Riftbound.Contracts','Riftbound.CardCatalog','Riftbound.Persistence']:
 assert runtime_hashes[name+'.dll']==driver_hashes[name+'.dll']
proof=dict(startedAtUtc=now(),status='RUNNING',sourceInputHashes=source_hashes,apiRuntimeHashes=runtime_hashes,driverRuntimeHashes=driver_hashes,apiProcesses=[],dedicatedFreshCluster=str(cluster),apiPort=15857,postgresPort=55497)
def stable():
 assert sources()==source_hashes and hashes(runtime)==runtime_hashes and hashes(driver)==driver_hashes
with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15857))!=0
with socket.socket() as s:assert s.connect_ex(('127.0.0.1',55497))!=0
connection='Host=127.0.0.1;Port=55497;Database=draven_death_acceptance;Username=codex_draven_death'
env=dict(os.environ,ASPNETCORE_ENVIRONMENT='Production',ASPNETCORE_URLS='http://127.0.0.1:15857',Riftbound__AllowDevSeedScenarios='true',ConnectionStrings__Riftbound=connection,DOTNET_DbgEnableMiniDump='0');env.pop('DOTNET_STARTUP_HOOKS',None)
api=None;started=False;power=None
try:
 subprocess.run([str(pg/'initdb'),'-D',str(cluster),'-U','codex_draven_death','-A','trust','--no-locale','--encoding=UTF8'],check=True,stdout=(w/'postgres-init-v1.log').open('xb'),stderr=subprocess.STDOUT)
 sock.mkdir(exist_ok=True)
 subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'postgres-own-v1.log'),'-o',f'-p 55497 -h 127.0.0.1 -k {sock}','-w','start'],check=True,capture_output=True);started=True
 subprocess.run([str(pg/'createdb'),'-h','127.0.0.1','-p','55497','-U','codex_draven_death','draven_death_acceptance'],check=True,capture_output=True)
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())])
 proof['driverLoadedAssemblies']=json.loads(subprocess.check_output([dotnet,str(driver/'DravenDeathOriginalSignalRRestartV1.dll'),'--loaded-inputs'],cwd=driver,env=env))
 for a in proof['driverLoadedAssemblies']['assemblies']:
  assert Path(a['path'])==driver/(a['name']+'.dll') and a['sha256']==driver_hashes[a['name']+'.dll'] and a['mvid']
 for index,phase in enumerate(['prepare','resume']):
  stable()
  with (w/f'api-own-{index}-v1.log').open('xb') as log:
   api=subprocess.Popen([dotnet,str(runtime/'Riftbound.Api.dll')],cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT)
  for _ in range(150):
   assert api.poll() is None,'Owned API failed; retain its original log.'
   try:
    with urllib.request.urlopen('http://127.0.0.1:15857/health',timeout=1) as response:health=json.load(response)
    assert health['environment']=='Production' and health['persistenceMode']=='postgres'
    assert set(subprocess.check_output(['/usr/sbin/lsof','-tiTCP:15857','-sTCP:LISTEN'],text=True).splitlines())=={str(api.pid)}
    break
   except OSError:time.sleep(.1)
  else:raise AssertionError('Owned API readiness timeout')
  proof['apiProcesses'].append(dict(pid=api.pid,phase=phase,health=health,startedAtUtc=now()))
  with (w/f'network-{phase}-v1.log').open('xb') as log:
   result=subprocess.run([dotnet,str(driver/'DravenDeathOriginalSignalRRestartV1.dll'),phase,str(output),str(private)],cwd=driver,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
  proof[phase+'ExitCode']=result.returncode
  assert result.returncode==0,'Keep partial original rooms and failure logs; no silent rerun.'
  proof[phase+'Receipts']=json.loads((output/(phase+'-receipts.json')).read_text())
  api.terminate();proof['apiProcesses'][-1]['exitCode']=api.wait(timeout=30);assert api.returncode==0;api=None
  stable()
 rooms=subprocess.check_output([str(pg/'psql'),'-h','127.0.0.1','-p','55497','-U','codex_draven_death','-d','draven_death_acceptance','-At','-c','select match_id from matches order by match_id'],text=True).splitlines()
 assert set(rooms)=={r['room']for r in proof['prepareReceipts']} and len(rooms)==6
 proof['rooms']=rooms
 sql='select jsonb_build_object('+','.join("'%s',(select count(*) from %s)"%(t,t) for t in ['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'])+')'
 proof['sevenTableCounts']=json.loads(subprocess.check_output([str(pg/'psql'),'-h','127.0.0.1','-p','55497','-U','codex_draven_death','-d','draven_death_acceptance','-At','-c',sql],text=True))
 proof.update(status='PASS_SIX_REAL_SIGNALR_SQL_ROOMS_WITH_ACTUAL_API_RESTART',controlledPositionsNotOrdinaryOpening=True,visibleDesktopAcceptance=False)
except BaseException as error:
 proof.update(status='FAILED_ORIGINAL_PARTIAL_ROOMS_PRESERVED',errorType=type(error).__name__,error=str(error));raise
finally:
 if api is not None and api.poll() is None:api.terminate();proof['failedPhaseApiExitCode']=api.wait(timeout=30)
 if started:proof['ownPostgresStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None and power.poll() is None:power.terminate();power.wait(timeout=10)
 stable();proof.update(finishedAtUtc=now(),allSourceRuntimeInputsStable=True)
 terminal.write_text(json.dumps(proof,ensure_ascii=False,indent=2))
assert proof['ownPostgresStopped'];print(proof['status'])
