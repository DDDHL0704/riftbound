using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

var json = new JsonSerializerOptions(JsonSerializerDefaults.Web);
var folder = Path.GetFullPath(args[0]); Directory.CreateDirectory(folder);
var original = Path.GetFullPath(args[1]);
await using var source = NpgsqlDataSource.Create(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound")! + ";Options=-c default_transaction_read_only=on");
var store = new PostgresMatchRecoveryStore(source); var receipts = new List<object>();
foreach (var receiptFile in Directory.GetFiles(original, "resume-receipt.json", SearchOption.AllDirectories).Order())
{
    using var receipt = JsonDocument.Parse(File.ReadAllText(receiptFile));
    var room = receipt.RootElement.GetProperty("room").GetString()!;
    var branch = receipt.RootElement.GetProperty("branch").GetString()!;
    var frame = (await store.LoadAsync(room, default))!;
    Check(frame.IsConsistent, string.Join("; ", frame.ValidationErrors));
    var originalPath = Path.Combine(Path.GetDirectoryName(receiptFile)!, "post-restart-original-final-frame.json.gz");
    using var file = File.OpenRead(originalPath); using var zip = new GZipStream(file, CompressionMode.Decompress);
    var expected = JsonSerializer.Deserialize<MatchRecoveryFrame>(zip, json)!;
    Check(MatchStateHasher.HashValue(frame) == MatchStateHasher.HashValue(expected), "Independent SQL reader must match every original final field.");
    await using var connection = await source.OpenConnectionAsync();
    var raw = new Dictionary<string, JsonElement>();
    foreach (var table in new[] { "matches", "match_players", "command_log", "game_events", "state_snapshots", "snapshots", "action_prompts" })
    {
        await using var cmd = new NpgsqlCommand($"select coalesce(jsonb_agg(to_jsonb(t) order by to_jsonb(t)::text),'[]'::jsonb)::text from {table} t where match_id=@room", connection);
        cmd.Parameters.AddWithValue("room", room);
        using var document = JsonDocument.Parse((string)(await cmd.ExecuteScalarAsync())!); raw[table] = document.RootElement.Clone();
    }
    var count = 0;
    foreach (var command in frame.Commands)
    {
        await using var cmd = new NpgsqlCommand("select payload::text from state_snapshots where match_id=@room and state_tick=@tick order by last_event_sequence desc limit 1", connection);
        cmd.Parameters.AddWithValue("room", room); cmd.Parameters.AddWithValue("tick", command.CompletedTick);
        var state = JsonSerializer.Deserialize<MatchState>((string)(await cmd.ExecuteScalarAsync())!, json)!;
        var commands = frame.Commands.Take(++count).ToArray();
        var events = frame.Events.Where(e => e.Sequence <= command.CompletedEventSequence).ToArray();
        var replay = await MatchActionLogReplayer.VerifyFinalStateAsync(frame.ReplayInitialState!, commands, state, new CoreRuleEngine(), default, events);
        Check(replay.IsMatch, branch + ": " + string.Join("; ", replay.Errors));
    }
    var path = Path.Combine(folder, branch + "-original-seven-tables.json.gz");
    using (var outFile = File.Open(path, FileMode.CreateNew))
    using (var gz = new GZipStream(outFile, CompressionLevel.SmallestSize)) JsonSerializer.Serialize(gz, raw, json);
    receipts.Add(new { room, branch, originalCommands = frame.Commands.Count, originalEvents = frame.Events.Count,
        independentlyReplayedPrefixes = count, originalSevenTableRows = raw.ToDictionary(p => p.Key, p => p.Value.GetArrayLength()),
        rawSevenTablesSha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path))).ToLowerInvariant() });
}
var result = new { status = "PASS_INDEPENDENT_READ_ONLY_ORIGINAL_SQL_PREFIXES", receipts,
    actualRuleInputs = RuleInputIdentity.Current, baseDirectory = AppContext.BaseDirectory,
    assemblies = new[] { typeof(MatchSession).Assembly, typeof(GameCommand).Assembly, typeof(Riftbound.CardCatalog.OfficialCardCatalogLoader).Assembly, typeof(PostgresMatchRecoveryStore).Assembly }
        .Select(a => new { name = a.GetName().Name, path = a.Location, mvid = a.ManifestModule.ModuleVersionId,
            sha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(a.Location))).ToLowerInvariant() }) };
File.WriteAllText(Path.Combine(folder, "receipt.json"), JsonSerializer.Serialize(result, json));
Console.WriteLine("PASS_INDEPENDENT_READ_ONLY_ORIGINAL_SQL_PREFIXES " + receipts.Count);
static void Check(bool value, string message) { if (!value) throw new Exception(message); }
