from pathlib import Path
p=Path('tests/Riftbound.ConformanceTests/DravenBattleDeathRecoveryTests.cs')
s=p.read_text();Path('var/qa/draven-death-runtime-20261023/recovery-fixture-v1.cs.txt').write_text(s)
a=s.index('        var cards = new Dictionary<string, CardObjectState>();',s.index('private static async Task<Driver> Open'))
b=s.index('        await run.Act("P1", new MoveUnitCommand',a)
fixture=s[a:b]
body=fixture[:fixture.index('        var initial = new MatchState')]
body=body.replace('OfficialGarenConquestBattlefieldCountTests.Printed(id, no, owner)','Printed(id, no, owner)')
body=body.replace('"P1"','seed.P1').replace('"P2"','seed.P2')
header='''using Riftbound.Contracts;

namespace Riftbound.Engine;

public sealed partial class MatchSession
{
    // Finite backend positions. Deaths, ordering, response and terminal outcomes
    // must be produced by subsequent ordinary commands and preserved journals.
    private static MatchState BuildDravenBattleDeathScenario(MatchState current, DevScenarioSeed seed, string branch)
    {
        var alternate = branch.Contains("alt", StringComparison.Ordinal);
        var mutual = branch.Contains("mutual", StringComparison.Ordinal);
        var score = branch.Contains("winning", StringComparison.Ordinal) ? 7 : 0;
        var mixed = branch.StartsWith("mixed", StringComparison.Ordinal);
        var attackingDraven = branch != "mixed-defender";
        static CardObjectState Printed(string id, string no, string owner)
            => PrintedCardFactory.TryCreate(id, owner, no, out var card) ? card
                : throw new InvalidOperationException("Death QA requires official catalog printings.");
'''
footer='''        return BuildScenarioState(current, seed, 424242, 5,
            new Dictionary<string, RunePool> { [seed.P1] = new(20, 20), [seed.P2] = new(20, 20) }, zones, cards) with
        {
            ObjectLocations = locations, CardPlays = new(5, [], []),
            PlayerScores = new Dictionary<string, int> { [seed.P1] = score, [seed.P2] = score }
        };
    }
}
'''
Path('src/Riftbound.Engine/MatchSession.DravenBattleDeathScenario.cs').write_text(header+body+footer)
s=s[:a]+'''        var run = new Driver(MatchState.Create("DRAVEN-DEATH-RECOVERY") with { Seed = 424242 });
        var scenario = "draven-death-" + (mixed ? attackingDraven ? "mixed-attacker" : "mixed-defender"
            : (alternate ? "alt-" : "") + (mutual ? "mutual-" : "") + (score == 7 ? "winning" : "normal"));
        await run.Prepare(scenario);
'''+s[b:]
s=s.replace('''            var frame = Frame();
            Assert.True(frame.IsConsistent,''','''            await Cold();
        }

        internal async Task Prepare(string scenario)
        {
            await session.EnsurePlayerAsync("P1", default); State = journal.Entries[^1].AuthoritativeState; states.Add(State); await Cold();
            await session.EnsurePlayerAsync("P2", default); State = journal.Entries[^1].AuthoritativeState; states.Add(State); await Cold();
            var result = await session.SeedScenarioAsync("P1", "original-death-position", scenario,
                JsonSerializer.SerializeToElement(new { cmdType = "DEV_SEED_SCENARIO", scenarioId = scenario }, Json), default);
            Assert.True(result.Accepted, result.ErrorMessage); State = result.State; states.Add(State); await Cold();
        }

        private async Task Cold()
        {
            var frame = Frame();
            Assert.True(frame.IsConsistent,''')
p.write_text(s)
p=Path('src/Riftbound.Engine/MatchSession.cs');s=p.read_text();at='''                => BuildBattleResultScenario(current, seed, scenarioId["battle-result-".Length..]),''';assert s.count(at)==1
s=s.replace(at,at+'''
            "draven-death-normal" or "draven-death-winning" or "draven-death-alt-normal" or "draven-death-alt-winning"
                or "draven-death-mutual-normal" or "draven-death-mutual-winning"
                or "draven-death-alt-mutual-normal" or "draven-death-alt-mutual-winning"
                or "draven-death-mixed-attacker" or "draven-death-mixed-defender"
                => BuildDravenBattleDeathScenario(current, seed, scenarioId["draven-death-".Length..]),''');p.write_text(s)
