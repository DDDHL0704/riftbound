from pathlib import Path
r=Path('src/Riftbound.Engine')
p=r/'CoreRuleEngine.BattleResultContinuation.cs';s=p.read_text()
s=s.replace('string? DefendingPlayerId, string WinnerPlayerId, long ResultTick,','string? DefendingPlayerId, string? WinnerPlayerId, long ResultTick,')
s=s.replace('''        if (winner is null) return false;
        var role''','''        // Death instructions have already captured their ordinary skills, but
        // their observer collector runs after this battle instruction completes.
        // Do not establish control or close a no-winner battle ahead of them.
        var hasCapturedDeaths = events.Any(e => e.Payload.GetValueOrDefault("capturedUnitDeath")
            is CapturedUnitDeath { DravenBattleDeathScore: not null });
        if (winner is null && !hasCapturedDeaths) return false;
        var role''')
s=s.replace('''        queued.AddRange(CaptureUnitBattleWinDrawObservations''','''        if (winner is not null) queued.AddRange(CaptureUnitBattleWinDrawObservations''')
s=s.replace('''        queued.AddRange(CaptureKhazixBattleWinObservations''','''        if (winner is not null) queued.AddRange(CaptureKhazixBattleWinObservations''')
s=s.replace('''        if (resultState.PlayerZones.TryGetValue(winner, out var winnerZones))''','''        if (winner is not null && resultState.PlayerZones.TryGetValue(winner, out var winnerZones))''')
s=s.replace('''        var scoreObservations = CaptureDravenBattleWinScoreObservations(resultState, battlefield, winner,
            attackers, defenders, resultState.Tick);''','''        var scoreObservations = winner is null ? Array.Empty<CapturedDravenBattleWinScore>()
            : CaptureDravenBattleWinScoreObservations(resultState, battlefield, winner,
                attackers, defenders, resultState.Tick);''')
s=s.replace('''        if (queued.Count == 0) return false;''','''        if (queued.Count == 0 && !hasCapturedDeaths) return false;''')
s=s.replace('''        ApplyBattleCleanup(zones, cards, battlefield, attackers, defenders, events);
        var bindings''','''        ApplyBattleCleanup(zones, cards, battlefield, attackers, defenders, events);
        if (winner is null)
            events.Add(BuildBattleNoResultEvent(zones, cards, battlefield, attackers, defenders, attacker, defender));
        var bindings''')
p.write_text(s)
p=r/'BattleResultRecoveryRules.cs';s=p.read_text();s=s.replace('''            || c.WinnerPlayerId != c.AttackingPlayerId && c.WinnerPlayerId != c.DefendingPlayerId''','''            || c.WinnerPlayerId is not null && c.WinnerPlayerId != c.AttackingPlayerId && c.WinnerPlayerId != c.DefendingPlayerId''')
s=s.replace('''            && (c.WinnerPlayerId == c.AttackingPlayerId
''','''            && (c.WinnerPlayerId is null
                ? c.SurvivingAttackerObjectIds.Count == 0 && c.SurvivingDefenderObjectIds.Count == 0
                    || c.SurvivingAttackerObjectIds.Count > 0 && c.SurvivingDefenderObjectIds.Count > 0
                : c.WinnerPlayerId == c.AttackingPlayerId
''')
p.write_text(s)
print('step 2 battle settlement retains death skills including no-winner continuation')
