using System.Collections.Concurrent;
using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.Json.Serialization;
using Microsoft.AspNetCore.SignalR.Client;
using Microsoft.Extensions.DependencyInjection;
using Npgsql;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

if (args.SequenceEqual(new[] { "--loaded-inputs" }))
{
    Console.WriteLine(JsonSerializer.Serialize(new { baseDirectory = AppContext.BaseDirectory, actualRuleInputs = RuleInputIdentity.Current,
        assemblies = new[] { typeof(MatchSession).Assembly, typeof(GameCommand).Assembly, typeof(Riftbound.CardCatalog.OfficialCardCatalogLoader).Assembly, typeof(PostgresMatchRecoveryStore).Assembly }
            .Select(a => new { name = a.GetName().Name, path = a.Location, mvid = a.ManifestModule.ModuleVersionId,
                sha256 = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(a.Location))).ToLowerInvariant() }) }));
    return;
}

Check(args.Length == 3 && args[0] is "prepare" or "resume", "Explicit phase and fresh output/private paths required.");
var phase = args[0]; var output = Path.GetFullPath(args[1]); var secrets = Path.GetFullPath(args[2]);
Directory.CreateDirectory(output); Directory.CreateDirectory(secrets);
using var limit = new CancellationTokenSource(TimeSpan.FromMinutes(12)); var ct = limit.Token;
var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
await using var source = NpgsqlDataSource.Create(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound")! + ";Options=-c default_transaction_read_only=on");
var store = new PostgresMatchRecoveryStore(source);
using var http = new HttpClient();
var health = JsonNode.Parse(await http.GetStringAsync("http://127.0.0.1:15857/health", ct))!;
Check(health["environment"]!.GetValue<string>() == "Production" && health["persistenceMode"]!.GetValue<string>() == "postgres", "Dedicated real SQL Production API with explicitly enabled finite QA positions.");
var receipts = new List<object>();
foreach (var branch in new[] { "normal", "alt-normal", "mutual-normal", "mutual-winning", "altar", "mixed-defender" })
{
    var folder = Path.Combine(output, branch); Directory.CreateDirectory(folder);
    var privatePath = Path.Combine(secrets, branch + ".json");
    JsonObject config;
    if (phase == "prepare")
    {
        Check(!File.Exists(privatePath), "Never replace original private room identity.");
        var suffix = Guid.NewGuid().ToString("N")[..12];
        config = new JsonObject { ["room"] = "DRAVEN-DEATH-NET-" + suffix, ["a"] = Profile("death_a_" + suffix), ["b"] = Profile("death_b_" + suffix) };
        PrivateSave();
    }
    else config = JsonNode.Parse(File.ReadAllText(privatePath))!.AsObject();
    var room = config["room"]!.GetValue<string>();
    using var trace = new StreamWriter(new GZipStream(new FileStream(Path.Combine(folder, phase + "-original-wire.ndjson.gz"), FileMode.CreateNew), CompressionLevel.SmallestSize));
    await using var a = new Side(config["a"]!.AsObject(), room, trace, source, PrivateSave);
    await using var b = new Side(config["b"]!.AsObject(), room, trace, source, PrivateSave);
    var sides = new[] { a, b }; MatchRecoveryFrame frame = null!; var checkpoints = 0;
    foreach (var s in sides) await s.Connect(phase == "resume", ct);
    await Until(() => sides.All(s => s.Snapshot.GetProperty("players").EnumerateObject().Count() == 2));
    await Checkpoint("connected");
    var winning = branch.Contains("winning"); var alternate = branch.Contains("alt-");
    var recycled = branch is "normal" or "alt-normal";
    if (phase == "prepare")
    {
        Check(frame.Commands.Count == 2 && frame.ReplayInitialState is { Tick: 0, Status: "EMPTY", Seats.Count: 0 }, "Both real seat commands start from EMPTY.");
        var before = frame.CurrentTick;
        await a.Hub.InvokeAsync("SeedScenario", room, a.Actor, "draven-death-" + branch, "original-finite-seed", ct);
        await Until(() => sides.All(s => s.Snapshot.GetProperty("tick").GetInt64() > before));
        await Checkpoint("seed");
        await Act(a.Actor, new MoveUnitCommand("P1-UNIT", "BASE", "BATTLEFIELD:FIELD", []), true);
        await Act(a.Actor, new PassFocusCommand()); await Act(b.Actor, new PassFocusCommand());
        await Act(a.Actor, new DeclareBattleCommand("FIELD", ["P1-UNIT"], ["P2-UNIT"], ["COMBAT_ASSIGNMENT"]));
        if (frame.AuthoritativeState!.TriggerQueue.Count > 0) await Order();
        if (recycled)
        {
            await Confirm();
            var earned = frame.AuthoritativeState!.StackItems.Single().DravenBattleDeathScore!;
            if (frame.AuthoritativeState.PriorityPlayerId == a.Actor) await Act(a.Actor, new PassPriorityCommand());
            await Act(b.Actor, new PlayCardCommand("DISPOSAL", "UNL-103/219", ["P1-UNIT"], "RECYCLE_OPPONENT_GRAVEYARD_UP_TO_3"));
            var top = frame.AuthoritativeState!.StackItems.Last().StackItemId;
            for (var i = 0; frame.AuthoritativeState.StackItems.Any(s => s.StackItemId == top); i++)
            { Check(i < 4, "Bounded original recycle response."); await Act(frame.AuthoritativeState.PriorityPlayerId!, new PassPriorityCommand()); }
            Check(frame.AuthoritativeState.PlayerZones[a.Actor].MainDeck.Contains("P1-UNIT")
                && frame.AuthoritativeState.StackItems.Single().DravenBattleDeathScore == earned
                && frame.AuthoritativeState.CardObjects["P1-UNIT"].ObjectGeneration > earned.Source.Generation,
                "An original death skill survives the source becoming a different private incarnation.");
            CheckHidden();
        }
        else Check(branch == "altar" ? frame.AuthoritativeState!.PendingRuleChoice is not null
            : frame.AuthoritativeState!.PendingCardChoice is not null, "Actual pending selection must survive process restart.");
        await RejectNetworkInputs();
        await Save("pre-restart-original-frame.json.gz", frame);
        await Save("pre-restart-original-network-views.json.gz", sides.ToDictionary(s => s.Actor, s => new { snapshot = s.Snapshot, prompt = s.Prompt }));
    }
    else
    {
        var original = await Read<MatchRecoveryFrame>("pre-restart-original-frame.json.gz");
        Check(MatchStateHasher.HashValue(frame) == MatchStateHasher.HashValue(original), "Actual process restart and both token rotations preserve the original complete recovery frame.");
        var views = await Read<JsonElement>("pre-restart-original-network-views.json.gz");
        foreach (var side in sides)
        {
            Equal(views.GetProperty(side.Actor).GetProperty("snapshot"), side.Snapshot, "Original private snapshot after API restart.");
            Equal(views.GetProperty(side.Actor).GetProperty("prompt"), side.Prompt, "Original prompt after API restart.");
        }
        if (recycled) CheckHidden();
        for (var i = 0; frame.AuthoritativeState!.Status == MatchStatuses.InProgress
            && (frame.AuthoritativeState.StackItems.Count > 0 || frame.AuthoritativeState.TriggerQueue.Count > 0
                || frame.AuthoritativeState.PendingRuleChoice is not null); i++)
        {
            Check(i < 24, "Bounded retained death continuation.");
            if (frame.AuthoritativeState.PendingRuleChoice is { } replacement)
                await Act(replacement.Request.PlayerId, new PayCostCommand(replacement.Request.Id, "RULE_REPLACEMENT", ["DECLINE"]));
            else if (frame.AuthoritativeState.PendingCardChoice is not null) await Confirm();
            else if (frame.AuthoritativeState.TriggerQueue.Count > 0) await Order();
            else await Act(frame.AuthoritativeState.PriorityPlayerId!, new PassPriorityCommand());
        }
        var state = frame.AuthoritativeState!; var events = frame.Events.Select(e => e.Event).ToArray();
        var scores = events.Where(e => e.Kind == "SCORE_GAINED" && e.Payload.GetValueOrDefault("reason")?.ToString() == "CAPTURED_DRAVEN_BATTLE_DEATH_OPPONENT_SCORE").ToArray();
        Check(scores.Length == (branch == "mutual-normal" ? 2 : 1), "Each original resolved death skill grants exactly one point.");
        Check(winning ? state.WinnerPlayerId == a.Actor && state.PlayerScores[a.Actor] == 8 && state.PlayerScores[b.Actor] == 7
            && state.PendingBattleResult is not null && !events.Any(e => e.Kind == "BATTLE_CLOSED")
            : state.WinnerPlayerId is null && state.PendingBattleResult is null && events.Count(e => e.Kind == "BATTLE_CLOSED") == 1,
            "Ordinary victory or no-winner battle close follows the original death skills.");
        if (branch == "mixed-defender")
        {
            var kinds = events.Select(e => e.Kind).ToList();
            Check(kinds.Count(x => x == "CARD_DRAWN") == 1 && kinds.IndexOf("CARD_DRAWN") < Array.IndexOf(events, scores[0]),
                "The later result skill resolves before the earlier death skill.");
        }
        if (branch == "mutual-normal") Check(state.PlayerScores[a.Actor] == 1 && state.PlayerScores[b.Actor] == 1
            && state.CardObjects["FIELD"].ControllerId is null, "Both deaths score, then the empty battlefield becomes neutral.");
        Check(frame.OpeningSeed == original.OpeningSeed && frame.Commands.Take(original.Commands.Count).Select(MatchStateHasher.HashValue).SequenceEqual(original.Commands.Select(MatchStateHasher.HashValue))
            && frame.Events.Take(original.Events.Count).Select(MatchStateHasher.HashValue).SequenceEqual(original.Events.Select(MatchStateHasher.HashValue)), "No original action, event or private opening seed rewritten.");
        await Save("post-restart-original-final-frame.json.gz", frame);
    }
    async Task RejectNetworkInputs()
    {
        var seen = new ConcurrentQueue<string>();
        await using var probe = new HubConnectionBuilder().WithUrl("http://127.0.0.1:15857/hubs/game")
            .AddJsonProtocol(o => o.PayloadSerializerOptions.Converters.Add(new JsonStringEnumConverter())).Build();
        foreach (var kind in new[] { "Snapshot", "Prompt", "Events" }) probe.On<WsServerMessage>(kind, _ => seen.Enqueue(kind));
        await probe.StartAsync(ct);
        await Reject(a.Actor, "unauthenticated", null);
        var auth = await probe.InvokeAsync<AuthResultDto>("Authenticate", a.Actor, config["a"]!["playerKey"]!.GetValue<string>(), ct);
        Check(auth.Authenticated, "Own isolated probe authenticates as the first player.");
        await Reject(b.Actor, "impersonation", null);
        await Reject(a.Actor, "stale-tick", frame.CurrentTick - 1);
        async Task Reject(string actor, string kind, long? tick)
        {
            var before = (await store.LoadAsync(room, ct))!;
            var raw = JsonSerializer.SerializeToNode(new PassPriorityCommand(), json)!.AsObject();
            raw["promptId"] = a.Prompt.GetProperty("promptId").GetString(); raw["snapshotTick"] = tick ?? frame.CurrentTick;
            var receipt = await probe.InvokeAsync<CommandReceiptDto>("SubmitIntent", room, actor, "reject-" + kind, JsonSerializer.SerializeToElement(raw, json), ct);
            Check(!receipt.Accepted && receipt.ErrorCode is not null, "The real network must reject " + kind);
            var after = (await store.LoadAsync(room, ct))!;
            Check(MatchStateHasher.Hash(before.AuthoritativeState!) == MatchStateHasher.Hash(after.AuthoritativeState!)
                && MatchStateHasher.HashValue(before.Events) == MatchStateHasher.HashValue(after.Events)
                && MatchStateHasher.HashValue(before.PlayerViews) == MatchStateHasher.HashValue(after.PlayerViews)
                && seen.IsEmpty, "Rejected network intent preserves both private views and all original events, with no private reply.");
            lock (trace) { trace.WriteLine(JsonSerializer.Serialize(new { kind, actor, receipt, invariant = true })); trace.Flush(); }
            await Checkpoint("reject-" + kind);
        }
    }
    async Task Confirm()
    {
        var choice = frame.AuthoritativeState!.PendingCardChoice!;
        await Act(choice.PlayerId, new ChooseCardsCommand(choice.ChoiceId, choice.ChoiceWindow,
            [choice.PlayerId == a.Actor ? b.Actor : a.Actor]), true);
    }
    async Task Order()
    {
        var side = sides.Single(s => s.Prompt.GetProperty("candidates").EnumerateArray().Any(c => c.GetProperty("action").GetString() == CommandTypes.OrderTriggers && c.GetProperty("enabled").GetBoolean()));
        var candidate = side.Prompt.GetProperty("candidates").EnumerateArray().Single(c => c.GetProperty("action").GetString() == CommandTypes.OrderTriggers && c.GetProperty("enabled").GetBoolean());
        var ids = candidate.GetProperty("metadata").GetProperty("orderedTriggerIds").EnumerateArray().Select(x => x.GetString()!).ToArray();
        await Act(side.Actor, new OrderTriggersCommand(OrderedTriggerIds: ids));
    }
    foreach (var s in sides) await s.Drain();
    var receipt = new { status = "PASS_SCOPED_REAL_SIGNALR_" + phase.ToUpperInvariant(), room, branch, phase, originalCommands = frame.Commands.Count,
        originalEvents = frame.Events.Count, checkpoints, persistedBeforeObservedWireMessages = sides.Sum(s => s.PersistedMessages),
        actualRuleInputs = RuleInputIdentity.Current, controlledPositionNotOrdinaryOpening = true, realProcessRestart = phase == "resume", originalPrivateSeed = frame.OpeningSeed,
        wholeCardCertification = false, visibleDesktopOrHardwareAcceptance = false };
    await File.WriteAllTextAsync(Path.Combine(folder, phase + "-receipt.json"), JsonSerializer.Serialize(receipt, json), ct); receipts.Add(receipt);
    Console.WriteLine(JsonSerializer.Serialize(receipt));

    void PrivateSave()
    {
        File.WriteAllText(privatePath, config.ToJsonString(json));
        if (!OperatingSystem.IsWindows()) File.SetUnixFileMode(privatePath, UnixFileMode.UserRead | UnixFileMode.UserWrite);
    }
    async Task Until(Func<bool> condition)
    { while (!condition()) { foreach (var s in sides) s.CheckErrors(); await Task.Delay(20, ct); } foreach (var s in sides) s.CheckErrors(); }
    async Task Checkpoint(string label)
    {
        frame = (await store.LoadAsync(room, ct))!;
        Check(frame.IsConsistent && frame.AuthoritativeState!.RuleInputs == RuleInputIdentity.Current, "Actual network SQL loaded inputs: " + string.Join(";", frame.ValidationErrors));
        await Until(() => sides.All(s => s.Snapshot.GetProperty("tick").GetInt64() == frame.CurrentTick && s.Prompt.GetProperty("snapshotTick").GetInt64() == frame.CurrentTick));
        Check((await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame, new CoreRuleEngine(), ct)).Count == 0, "Entire original real SQL prefix replays.");
        foreach (var s in sides)
        {
            Equal(JsonSerializer.SerializeToElement(frame.PlayerViews[s.Actor].Snapshot, json), s.Snapshot, "Observed snapshot equals stored original private view.");
            Equal(JsonSerializer.SerializeToElement(frame.PlayerViews[s.Actor].Prompt, json), s.Prompt, "Observed prompt equals stored original private view.");
            await s.Drain();
        }
        await Save(phase + "-checkpoint-" + (++checkpoints).ToString("D2") + "-" + label + ".json.gz", frame);
    }
    async Task Act(string actor, GameCommand command, bool duplicate = false)
    {
        var side = sides.Single(s => s.Actor == actor);
        var raw = JsonSerializer.SerializeToNode(command, command.GetType(), json)!.AsObject(); raw["promptId"] = side.Prompt.GetProperty("promptId").GetString(); raw["snapshotTick"] = frame.CurrentTick;
        var intent = phase + "-original-" + frame.Commands.Count; var element = JsonSerializer.SerializeToElement(raw, json);
        var receipt = await side.Hub.InvokeAsync<CommandReceiptDto>("SubmitIntent", room, actor, intent, element, ct);
        lock (trace) { trace.WriteLine(JsonSerializer.Serialize(new { actor, kind = "OriginalIntent", intent, command = element, receipt })); trace.Flush(); }
        Check(receipt.Accepted, "Real original intent refused: " + receipt.ErrorCode + " " + receipt.Message);
        await Checkpoint(command.CmdType);
        if (duplicate)
        {
            var original = MatchStateHasher.HashValue(frame);
            var again = await side.Hub.InvokeAsync<CommandReceiptDto>("SubmitIntent", room, actor, intent, element, ct);
            Check(again.Accepted && again.ServerTick == receipt.ServerTick && MatchStateHasher.HashValue((await store.LoadAsync(room, ct))!) == original, "Actual duplicate network intent writes no second input/state/event.");
        }
    }
    void CheckHidden()
    {
        var stack = b.Snapshot.GetProperty("stack").EnumerateArray().Single();
        Check(stack.GetProperty("sourceObjectId").GetString() == "HIDDEN" && stack.GetProperty("cardNo").GetString() == (alternate ? "SFD·148a/221" : "SFD·148/221"), "Opponent sees original public skill printing but never new private source identity.");
    }
    async Task Save(string name, object value)
    { await using var f = new FileStream(Path.Combine(folder, name), FileMode.CreateNew); await using var z = new GZipStream(f, CompressionLevel.SmallestSize); await JsonSerializer.SerializeAsync(z, value, value.GetType(), json, ct); }
    async Task<T> Read<T>(string name)
    { await using var f = File.OpenRead(Path.Combine(folder, name)); await using var z = new GZipStream(f, CompressionMode.Decompress); return (await JsonSerializer.DeserializeAsync<T>(z, json, ct))!; }
}
await File.WriteAllTextAsync(Path.Combine(output, phase + "-receipts.json"), JsonSerializer.Serialize(receipts, json), ct);
static JsonObject Profile(string actor) => new() { ["handle"] = actor, ["playerKey"] = Guid.NewGuid().ToString("N") + Guid.NewGuid().ToString("N") };
static void Check(bool ok, string why) { if (!ok) throw new Exception(why); }
static void Equal(JsonElement a, JsonElement b, string why) => Check(JsonNode.DeepEquals(JsonNode.Parse(a.GetRawText()), JsonNode.Parse(b.GetRawText())), why);

sealed class Side : IAsyncDisposable
{
    readonly ConcurrentQueue<string> errors = new(); readonly ConcurrentQueue<Task> checks = new(); readonly object gate = new();
    readonly JsonObject profile; readonly string room; readonly StreamWriter trace; readonly NpgsqlDataSource source; readonly Action save;
    JsonElement snapshot, prompt; bool joined; int persisted;
    public string Actor => profile["handle"]!.GetValue<string>();
    public HubConnection Hub { get; }
    public JsonElement Snapshot { get { lock (gate) return snapshot; } }
    public JsonElement Prompt { get { lock (gate) return prompt; } }
    public int PersistedMessages => persisted;
    public Side(JsonObject profile, string room, StreamWriter trace, NpgsqlDataSource source, Action save)
    {
        this.profile = profile; this.room = room; this.trace = trace; this.source = source; this.save = save;
        Hub = new HubConnectionBuilder().WithUrl("http://127.0.0.1:15857/hubs/game").AddJsonProtocol(o => { o.PayloadSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase; o.PayloadSerializerOptions.Converters.Add(new JsonStringEnumConverter()); }).Build();
        foreach (var kind in new[] { "Joined", "Snapshot", "Prompt", "Events", "Error" }) Hub.On<WsServerMessage>(kind, m => Receive(kind, m));
    }
    void Receive(string kind, WsServerMessage message)
    {
        if (message.Payload is not JsonElement payload) return;
        lock (gate)
        {
            if (kind == "Joined") { profile["reconnectToken"] = payload.GetProperty("reconnectToken").GetString(); save(); joined = true; return; }
            if (kind == "Snapshot") snapshot = payload.Clone();
            if (kind == "Prompt") prompt = payload.Clone();
            if (kind == "Error") errors.Enqueue(payload.GetRawText());
            lock (trace) { trace.WriteLine(JsonSerializer.Serialize(new { actor = Actor, kind, payload })); trace.Flush(); }
            if (kind is "Snapshot" or "Prompt") checks.Enqueue(Persisted(kind, payload.Clone()));
        }
    }
    async Task Persisted(string kind, JsonElement payload)
    {
        var snapshot = kind == "Snapshot"; var table = snapshot ? "snapshots" : "action_prompts"; var column = snapshot ? "snapshot_tick" : "prompt_tick";
        await using var connection = await source.OpenConnectionAsync();
        await using var command = new NpgsqlCommand($"select payload::text from {table} where match_id=@room and player_id=@actor and {column}=@tick", connection);
        command.Parameters.AddWithValue("room", room); command.Parameters.AddWithValue("actor", Actor);
        command.Parameters.AddWithValue("tick", payload.GetProperty(snapshot ? "tick" : "snapshotTick").GetInt64());
        var stored = await command.ExecuteScalarAsync() as string;
        if (stored is null || !JsonNode.DeepEquals(JsonNode.Parse(stored), JsonNode.Parse(payload.GetRawText()))) throw new Exception("Observed original private wire message must already exist exactly in SQL.");
        Interlocked.Increment(ref persisted);
    }
    public async Task Connect(bool reconnect, CancellationToken ct)
    {
        using var connectedLimit = CancellationTokenSource.CreateLinkedTokenSource(ct); connectedLimit.CancelAfter(TimeSpan.FromSeconds(25)); ct = connectedLimit.Token;
        await Hub.StartAsync(ct);
        var auth = await Hub.InvokeAsync<AuthResultDto>("Authenticate", Actor, profile["playerKey"]!.GetValue<string>(), ct);
        if (!auth.Authenticated) throw new Exception("Own authenticated identity rejected: " + auth.Status);
        var previous = profile["reconnectToken"]?.GetValue<string>();
        if (reconnect) await Hub.InvokeAsync("Reconnect", room, Actor, previous!, ct);
        else await Hub.InvokeAsync("JoinRoom", room, Actor, (string?)null, ct);
        while (!joined || Snapshot.ValueKind != JsonValueKind.Object || Prompt.ValueKind != JsonValueKind.Object) { CheckErrors(); await Task.Delay(20, ct); }
        if (reconnect && previous == profile["reconnectToken"]?.GetValue<string>()) throw new Exception("Original reconnect token must rotate.");
    }
    public void CheckErrors() { if (errors.TryPeek(out var error)) throw new Exception("Actual original network error: " + error); }
    public async Task Drain() { await Task.WhenAll(checks.ToArray()); CheckErrors(); }
    public ValueTask DisposeAsync() => Hub.DisposeAsync();
}
