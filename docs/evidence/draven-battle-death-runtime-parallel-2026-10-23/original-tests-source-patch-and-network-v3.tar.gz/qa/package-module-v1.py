from pathlib import Path
import datetime,difflib,gzip,hashlib,io,json,subprocess,tarfile,tempfile,xml.etree.ElementTree as ET
root=Path.cwd();q=root/'var/qa/draven-death-runtime-20261023';dest=root/'docs/evidence/draven-battle-death-runtime-parallel-2026-10-23';dest.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
old={}
with tarfile.open(q/'before-death-module-v1.tar.gz')as t:
 for m in t.getmembers():
  if m.isfile():old[m.name]=t.extractfile(m).read()
extra='tests/Riftbound.ConformanceTests/OfficialDravenBattleWinScoreTests.cs';old[extra]=(q/'OfficialDravenBattleWinScoreTests.before.cs.txt').read_bytes()
paths=list(old)+['src/Riftbound.Engine/DravenBattleDeathRecoveryRules.cs','src/Riftbound.Engine/MatchSession.DravenBattleDeathScenario.cs','tests/Riftbound.ConformanceTests/DravenBattleDeathRecoveryTests.cs']
changes={p:(root/p).read_bytes()for p in paths if p not in old or old[p]!=(root/p).read_bytes()}
patch=[]
for p,b in changes.items():
 patch.append(f'diff --git a/{p} b/{p}\n')
 if p not in old:patch.append('new file mode 100644\n')
 patch.extend(difflib.unified_diff(old.get(p,b'').decode().splitlines(True),b.decode().splitlines(True),fromfile='a/'+p if p in old else '/dev/null',tofile='b/'+p))
patch=''.join(patch).encode();(dest/'complete-module-only.patch').write_bytes(patch)
with tempfile.TemporaryDirectory(prefix='draven-death-patch-proof-')as d:
 d=Path(d)
 for p in changes:
  if p in old:(d/p).parent.mkdir(parents=True,exist_ok=True);(d/p).write_bytes(old[p])
 subprocess.run(['git','apply','--check',str(dest/'complete-module-only.patch')],cwd=d,check=True,capture_output=True)
 subprocess.run(['git','apply',str(dest/'complete-module-only.patch')],cwd=d,check=True,capture_output=True)
 assert all((d/p).read_bytes()==b for p,b in changes.items())
# Keep failed runs, their diagnostics and all final originals. Exclude only runtime
# caches, PostgreSQL storage and generated authentication credentials.
members={}
def add(name,data):
 assert name not in members;members[name]=data
for p in q.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(q)
 if any(x in {'bin','obj','__pycache__','fixed-api-runtime-v1','private-network-auth-v1','own-postgres-v1'}for x in rel.parts):continue
 if p.name=='network-owner-terminal-v1.json':pass
 add('qa/'+str(rel),p.read_bytes())
for p,b in changes.items():add('after/'+p,b)
for p in changes:
 if p in old:add('before/'+p,old[p])
# The existing original case identities are unchanged and preserved explicitly.
for f in ['OfficialDravenBattleDeathScoreTests.cs','DravenMutualDeathScoreTests.cs','DravenBattleWinScoreRecoveryTests.cs']:
 p='tests/Riftbound.ConformanceTests/'+f;add('unchanged-tests/'+p,(root/p).read_bytes())
add('complete-module-only.patch',patch)
# Source rows retain exact fields and original acquisition provenance from the
# same-day complete official response; no regenerated metadata is called original.
source=Path('/Users/dinghaolin/MyProjects/riftbound/var/qa/current-cn-source-readback-20261023/current-complete-cn-original-pages-v1.jsonl.gz')
wanted={'SFD·148/221','SFD·148a/221','UNL-206/219','UNL-103/219','SFD·185/221','OGN·077/298'};rows=[]
for line in gzip.open(source,'rt'):
 outer=json.loads(line)
 for c in json.loads(outer['originalUtf8'])['result']['list']:
  if c['cardNo']in wanted:rows.append(c)
sourceRows=dict(originalResponsePath=str(source),originalCompressedSha256=sha(source.read_bytes()),apiUrl='https://lol-api.playloltcg.com/xcx/card/searchCardCraftWeb',rows=rows)
add('sources/same-day-complete-api-exact-rows.json',json.dumps(sourceRows,ensure_ascii=False,indent=2).encode())
for p in ['docs/evidence/draven-battle-death-score-parallel-2026-10-23/source-and-red-test-manifest.json','docs/evidence/draven-battle-death-response-parallel-2026-10-23/source-and-red-test-manifest.json','docs/evidence/draven-mutual-death-parallel-2026-10-23/source-and-red-test-manifest.json']:
 add('prior-source-manifests/'+p,(root/p).read_bytes())
archive=dest/'original-tests-source-patch-and-network-v1.tar.gz'
with archive.open('wb')as out:
 with gzip.GzipFile(fileobj=out,mode='wb',mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as tar:
   for name,b in sorted(members.items()):
    info=tarfile.TarInfo(name);info.size=len(b);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(b))
with tarfile.open(archive)as t:
 actual={m.name:sha(t.extractfile(m).read())for m in t.getmembers()if m.isfile()}
assert actual=={n:sha(b)for n,b in members.items()}
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
runs={}
for name in ['first-wiring-focus-v1','recovery-focus-v1','recovery-focus-v2','recovery-focus-v3','altar-focus-v1','altar-focus-v2','altar-focus-v3','recovery-focus-v4','adjacent-focus-v1','win-calibration-focus-v1']:
 p=next((q/name).rglob('*.trx'));r=ET.parse(p).getroot()
 runs[name]=dict(counters=r.find('.//t:Counters',ns).attrib,trxPath=str(p.relative_to(root)),trxSha256=sha(p.read_bytes()))
histories={}
for name in ['recovery-original-v4','complete-death-v4','complete-mutual-v4','win-calibrated-original-v1']:
 files=list((q/name).glob('*.gz'));n=a=e=0
 for p in files:
  x=json.load(gzip.open(p,'rt'));n+=len(x['entries']);a+=sum(z['accepted']for z in x['entries']);e+=sum(len(z['events'])for z in x['entries'])
 histories[name]=dict(histories=len(files),inputs=n,accepted=a,rejected=n-a,events=e,originalPrefixReplayCount=n)
net=json.loads((q/'network-owner-terminal-v1.json').read_text());ind=json.loads((q/'independent-original-sql-v1/receipt.json').read_text())
manifest=dict(status='SCOPED_RUNTIME_IMPLEMENTED_TESTED_PATCH_DELIVERY',region='CN',language='zh-CN',reviewDate='2026-10-23',
 baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),baselineOverlay=json.loads((q/'before-death-module-v1.json').read_text()),
 delivery='Apply complete-module-only.patch to the received N52/N53 plus six-source N54 v1 base; this evidence commit is not a replacement for applying the runtime patch.',
 changedFiles=[dict(path=p,beforeSha256=sha(old[p])if p in old else None,afterSha256=sha(b),bytes=len(b))for p,b in changes.items()],
 patch=dict(path=str((dest/'complete-module-only.patch').relative_to(root)),sha256=sha(patch),bytes=len(patch),exactBeforeApplyAndAfterBytesVerified=True),
 officialSources=sourceRows,testRuns=runs,originalHistories=histories,
 adjacentDisposition=dict(original314Passed=309,original314Failed=5,dravenOriginal18RecheckedPassed=18,originalThreeFullGamesPassed=True,
 remainingMainOwnedN54Fixture='LocalDestructionRecallTests.LethalSpellDamageUsesTheSameRecall: expected 1 actual 2 from current Void Gate +1. This module does not edit that N54 fixture.'),
 network=dict(status=net['status'],rooms=net['rooms'],finalCommands=sum(r['originalCommands']for r in net['resumeReceipts']),finalEvents=sum(r['originalEvents']for r in net['resumeReceipts']),
 sevenTableCounts=net['sevenTableCounts'],negativeNetworkIntents=18,actualProcessRestart=True,ownPostgresStopped=net['ownPostgresStopped'],
 allSourceRuntimeInputsStable=net['allSourceRuntimeInputsStable'],actualLoadedInputs=net['driverLoadedAssemblies'],independentOriginalPrefixReplays=sum(r['independentlyReplayedPrefixes']for r in ind['receipts']),
 allOriginalSevenTableRowsUnchanged=json.loads((q/'independent-original-sql-owner-v1.json').read_text())['before']==json.loads((q/'independent-original-sql-owner-v1.json').read_text())['after']),
 noExtraCheckOrFull=True,wholeCardCertified=False,fullBackendComplete=False,goalStatus='ACTIVE',
 archive=dict(path=str(archive.relative_to(root)),bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),members=[dict(path=n,bytes=len(b),sha256=sha(b))for n,b in sorted(members.items())]))
(dest/'source-runtime-tests-and-delivery-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
print(json.dumps({k:manifest[k]for k in ['status','patch']},ensure_ascii=False));print('changed',len(changes),'archive',len(members),archive.stat().st_size)
