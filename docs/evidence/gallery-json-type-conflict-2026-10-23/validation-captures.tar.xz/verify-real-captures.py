from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import importlib.util
import json
import re
import subprocess
import tarfile
import types

WT = Path('/Users/dinghaolin/MyProjects/.worktrees/riftbound-parallel-official-audit-20261023')
Q = Path(__file__).resolve().parent
BASE = WT/'docs/evidence/en-gallery-gap-parallel-2026-10-23'
sha = lambda b: hashlib.sha256(b).hexdigest()
canonical = lambda value: json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode()
spec=importlib.util.spec_from_file_location('fixed_gallery',WT/'scripts/audit/gallery_coverage.py')
fixed=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixed)
old=types.ModuleType('old_gallery')
old_source=subprocess.check_output(['git','show','f0f4efc5:scripts/audit/gallery_coverage.py'],cwd=WT)
exec(compile(old_source,'f0f4efc5:scripts/audit/gallery_coverage.py','exec'),old.__dict__)
manifest=json.loads((BASE/'source-manifest.json').read_text())
archive=BASE/'original-captures.tar.xz'
pin=next(x for x in manifest['files'] if x['path'].endswith('/original-captures.tar.xz'))
assert sha(archive.read_bytes())==pin['sha256']
index=json.loads((BASE/'archive-index.json').read_text())
member_index={m['archiveMember']:m for m in index['members']}
inputs=[]
with tarfile.open(archive)as t:
    def raw(name):
        b=t.extractfile(name).read();entry=member_index[name]
        assert sha(b)==entry['sha256'] and len(b)==entry['bytes']
        inputs.append(dict(path=name,sha256=sha(b),bytes=len(b)))
        return gzip.decompress(b)
    whole=json.loads(raw('whole-list.gz'))
    pages=[json.loads(raw(f'window-{start:04}-0200.json.gz')) for start in range(0,whole['metadata']['totalItems'],200)]
    html=raw('gallery-page.gz').decode()
    next_data=json.loads(re.search(r'<script id="__NEXT_DATA__"[^>]*>(.*?)</script>',html).group(1))
    gallery=next(b for b in next_data['props']['pageProps']['page']['blades']if b['type']=='riftboundCardGallery')
    assert all(p['metadata']['totalItems']==whole['metadata']['totalItems']for p in pages)
    views=[dict(name='pagination',reportedTotal=whole['metadata']['totalItems'],records=[r for p in pages for r in p['data']]),
           dict(name='wholeList',reportedTotal=whole['metadata']['totalItems'],records=whole['data']),
           dict(name='pageSsr',reportedTotal=gallery['cards']['async']['metadata']['totalItems'],records=gallery['cards']['items'])]
old_rows,old_receipt=old.merge_gallery_views(views)
rows,receipt=fixed.merge_gallery_views(views)
assert canonical(rows)==canonical(old_rows) and canonical(receipt)==canonical(old_receipt)
assert receipt['reportedTotal']==1416 and receipt['returnedEntries']==1408 and receipt['reportedMinusReturned']==8
baseline_path=Path('/Users/dinghaolin/MyProjects/riftbound/docs/evidence/source-round-2026-10-21/originals/en-after-full-rows-checker-adapter-v1.json')
baseline=json.loads(baseline_path.read_text())['data']
assert canonical(rows)==canonical(sorted(baseline,key=lambda x:x['id']))

cases=[]
for before,after in [(True,1),(False,0),(1,1.0)]:
    for shape in ('same-view','two-views'):
        a=dict(id='SYNTHETIC-A',details=[dict(value=before)])
        b=dict(id='SYNTHETIC-A',details=[dict(value=after)])
        values=[dict(name='synthetic',reportedTotal=1,records=[a,b])] if shape=='same-view' else [
            dict(name='synthetic-before',reportedTotal=1,records=[a]),dict(name='synthetic-after',reportedTotal=1,records=[b])]
        old_result=old.merge_gallery_views(values)
        try:fixed.merge_gallery_views(values)
        except ValueError as error:rejected=str(error)
        else:raise AssertionError('Type conflict accepted')
        cases.append(dict(inputs=values,oldOutput=old_result,newRejection=rejected))

protected=['scripts/audit/gallery_gap_diagnostics.py','scripts/tests/test_gallery_gap_diagnostics.py']
unchanged=[]
for name in protected:
    original=subprocess.check_output(['git','show','f0f4efc5:'+name],cwd=WT)
    current=(WT/name).read_bytes();assert current==original
    unchanged.append(dict(path=name,sha256=sha(current)))
report=dict(schemaVersion=1,recordedAtUtc=datetime.now(timezone.utc).isoformat(),
    classification='TOOL_BOUNDARY_REGRESSION_NOT_A_NEW_OFFICIAL_SOURCE_DELTA',
    priorCommit=subprocess.check_output(['git','rev-parse','f0f4efc5'],cwd=WT,text=True).strip(),
    tool=dict(path='scripts/audit/gallery_coverage.py',beforeSha256=sha(old_source),afterSha256=sha((WT/'scripts/audit/gallery_coverage.py').read_bytes())),
    syntheticCounterexamples=cases,originalGalleryArchive=pin,verifiedOriginalMembers=inputs,
    actualCaptureReplay=dict(result=receipt,oldAndNewEntireRowsAndReceiptsCanonicalExact=True,
        all1408RowsEqualBaseline=True,baselinePath=str(baseline_path),baselineSha256=sha(baseline_path.read_bytes()),
        rowsSha256=sha(canonical(rows)),currentNetworkRefetch=False),
    preservedTenDiagnosticTestsAndImplementation=unchanged,
    seventeenDrawingsGatesUnchanged=True,englishEightSourceGapClosed=False,
    semanticCoverageCertified=False,runtimeAdoption=False,gameCheckOrFullRun=False)
(Q/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('PASS: 6 synthetic conflicts rejected; 3 actual capture views,1408 full rows and prior receipt unchanged;1416 reported,8 gap retained;original10 diagnostic tests unchanged')
