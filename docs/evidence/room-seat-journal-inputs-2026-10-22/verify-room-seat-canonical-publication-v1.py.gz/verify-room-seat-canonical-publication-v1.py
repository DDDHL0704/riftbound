from pathlib import Path
import copy, datetime, gzip, hashlib, json, tarfile

root = Path('/Users/dinghaolin/MyProjects/riftbound'); w = Path(__file__).resolve().parent
ev = root / 'docs/evidence/room-seat-journal-inputs-2026-10-22'
load = lambda p: json.loads(p.read_text()); sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
old = json.loads(gzip.decompress((w / 'prior-room-seat-publication-v1/current-manifest.json.gz').read_bytes()))
old_reviews = json.loads(gzip.decompress((w / 'prior-room-seat-publication-v1/review-decisions.json.gz').read_bytes()))
m = load(root / 'docs/audit/current-manifest.json'); reviews = load(root / m['inputs']['reviews']['path'])
assert (len(reviews['reviews']), len(m['reviewContexts']), len(m['acceptanceGates']), len(m['laterSourceDeltas'])) == (162, 77, 250, 7)
assert reviews['reviews'][:161] == old_reviews['reviews']
assert {k: v for k, v in reviews.items() if k != 'reviews'} == {k: v for k, v in old_reviews.items() if k != 'reviews'}
for key, value in old.items():
    if key not in {'inputs', 'reviewContexts', 'acceptanceGates'}: assert m[key] == value, key
expected_inputs = copy.deepcopy(old['inputs']); expected_inputs['reviews']['sha256'] = sha(root / m['inputs']['reviews']['path'])
assert m['inputs'] == expected_inputs and m['acceptanceGates'][:245] == old['acceptanceGates']
assert m['certificationScope'] == old['certificationScope'] and m['officialNewsObligations'] == old['officialNewsObligations']
refresh = json.loads(gzip.decompress((ev / 'complete-prior-contexts-current-input-refresh.json.gz').read_bytes()))
assert len(refresh) == len({r['id'] for r in refresh}) == 48
refresh_map = {r['id']: r for r in refresh}; unchanged = 0
for identity, context in old['reviewContexts'].items():
    actual = m['reviewContexts'][identity]
    if identity not in refresh_map:
        assert actual == context; unchanged += 1; continue
    row = refresh_map[identity]; assert row['oldCompleteContext'] == context
    expected = copy.deepcopy(context); differences = []
    for ref in expected['implementation']:
        current = sha(root / ref['path'])
        if current != ref['sha256']:
            differences.append({'path': ref['path'], 'before': ref['sha256'], 'after': current}); ref['sha256'] = current
    assert differences == row['changes']
    expected.update(currentImplementationCommit='be0e7a88d86e191d87404488a8ecc4777411dfb7', currentImplementationIncludesUncommittedChanges=True,
                    currentRoomSeatInputRefresh=actual['currentRoomSeatInputRefresh'])
    if identity == 'native-late-seat-historical-replay-finding-2026-10-22':
        followup = actual['currentRoomSeatBoundedRepairFollowup']
        assert followup['old7aCounterexampleAndAcceptedGameRemainUnmodified'] and followup['newFixedFullAndCurrentProducts'] == 'OPEN' and not followup['wholeFindingOrGoalClosed']
        expected['currentRoomSeatBoundedRepairFollowup'] = followup
    assert expected == actual, identity
assert unchanged == 28
identity = 'room-seat-journal-inputs-2026-10-22'; context = m['reviewContexts'][identity]
assert context['ciState'] == 'PENDING' and context['ciReceipts'] == [] and context['currentImplementationIncludesUncommittedChanges']
for ref in context['implementation'] + context['verificationSources'] + context['evidence']:
    assert sha(root / ref['path']) == ref['sha256']
branches = context['branches']; assert len(branches) == 21
retention = load(ev / 'final-original-test-and-input-retention.json')
assert {b['boundedCase']['actualExecutedCase'] for b in branches} == set(retention['newCaseIdentities'])
assert all(b['sourceRefs'] == ['DOC-01-P101-B004'] and b['decision']['state'] == 'OPEN' and not b['wholePrintingCertified'] for b in branches)
gates = m['acceptanceGates'][245:]; assert len(gates) == 5 and len({g['id'] for g in gates}) == 5
assert {g['announcedName'] for g in gates} == {'Agony’s Embrace', 'Nine-Tailed Fox', 'Rogue Assassin', 'Daughter of the Void', 'Packed Amphitheater'}
assert all(g['state'] == 'OPEN' and g['region'] == 'GLOBAL' and g['language'] == 'en-US' and not g['wholePrintingCertified'] for g in gates)
for gate in gates:
    assert sha(root / gate['sourceManifest']['path']) == gate['sourceManifest']['sha256']
source = load(ev / 'source-manifest.json'); global_source = load(ev / 'global-kda-couture-source-supplement.json')
assert source['actualRuleInputs'] == retention['actualRuleInputs'] and source['fullScopeRetained']['printings'] == 1740 and source['fullScopeRetained']['cnNews'] == 139
assert global_source['declaredPublicationUtc'] == '2026-10-21T16:00:00.000Z' and global_source['precisePrintingIdsGameEffectiveDatesRegionalLegalityAndRulesIdentity'] == 'OPEN'
assert global_source['notAssumedToExplainEightMissingEnglishGalleryRows'] and global_source['old1740PrintingUniverseAnd139ChineseNewsScopeUnchanged']

mapping = load(ev / 'archive-map.json'); archive = root / mapping['archive']['path']
assert sha(archive) == mapping['archive']['sha256']
with tarfile.open(archive, 'r:gz') as tar:
    assert set(tar.getnames()) == {r['path'] for r in mapping['members']}
    for row in mapping['members']:
        raw = tar.extractfile(row['path']).read()
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
for row in mapping['existingIdenticalOlderArchiveMembersNotDuplicated']:
    previous_map_path = root / row['existingArchiveMap']['path']; assert sha(previous_map_path) == row['existingArchiveMap']['sha256']
    previous_map = load(previous_map_path)
    with tarfile.open(root / previous_map['archive']['path'], 'r:gz') as tar:
        raw = tar.extractfile(row['existingArchiveMember']).read(); assert hashlib.sha256(raw).hexdigest() == row['sha256']
bits = load(w / 'executed-own-probe-and-reader-bits-retention-v1.json')['bits']; assert len(bits) == 10
for bit in bits:
    retained = root / bit['retained']['path']; assert sha(retained) == bit['retained']['sha256'] == bit['original']['sha256']
    name = Path(bit['original']['path']).name
    assert any((folder / name).is_file() and sha(folder / name) == sha(retained)
               for folder in w.iterdir() if folder.is_dir() and 'runtime' in folder.name.lower()), name
govpath = w / 'postpublication-current-governance-v1.json'; gov = load(govpath)
assert gov['governanceValid'] and gov['errors'] == [] and not gov['semanticCoverageCertified'] and gov['currentReviewCount'] == 162
baseline = json.loads(gzip.decompress((root / 'docs/evidence/special-trigger-damage-current-cn16-2026-10-22/final-governance.json.gz').read_bytes()))
oldids = {r['id'] for r in baseline['remainingObligations']}; newids = {r['id'] for r in gov['remainingObligations']}
expected_added = {'GATE:' + g['id'] for g in gates} | {'BRANCH:' + identity + ':' + b['id'] for b in branches}
assert len(oldids) == 17088 and len(newids) == 17114 and oldids <= newids and newids - oldids == expected_added
for name, value in source['fullScopeRetained'].items():
    if name == 'printings': assert value == 1740
raw = govpath.read_bytes(); canonical = ev / 'final-governance.json.gz'; assert not canonical.exists()
canonical.write_bytes(gzip.compress(raw, mtime=0)); assert gzip.decompress(canonical.read_bytes()) == raw
frozen = load(w / 'current-room-seat-frozen-runtime-inputs-v2.json')
assert all(sha(root / p) == h for p, h in frozen['sourceInputHashes'].items())
proof = {'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'CANONICAL_ROOM_SEAT_PUBLICATION_ARCHIVE_BYTES_ORIGINAL_REVIEW_CONTEXT_GATE_DELTA_AND_ALL17088_OBLIGATION_IDS_RETAINED',
    'oldReviewsCompleteAndExact': 161, 'oldGatesCompleteAndExact': 245, 'oldSourceDeltasCompleteAndExact': 7,
    'oldContextsCompleteAndExact': 28, 'oldContextsOnlyDeclaredCurrentImplementationPinsRefreshedWithCompleteOriginalsRetained': 48,
    'currentReviews': 162, 'currentContexts': 77, 'currentGates': 250, 'originalRemainingObligationIds': 17088,
    'remainingObligationIds': 17114, 'onlyAddedExactEngineeringBranches': 21, 'onlyAddedSeparateGlobalPrintingIdentitySourceGaps': 5,
    'allArchiveMembersBytesHashesClosedSetAndOnePriorReuseVerified': True, 'actualRetainedArchiveMembers': len(mapping['members']),
    'allTenExecutedOwnProbeReaderPayloadsMatchFrozenRuntimeBytes': True,
    'all3336ExecutionSourceInputsStableAfterPublication': True, 'originalSixCheckFailuresAndAllCounterexamplesRemainRecorded': True,
    'allOldSourceDatesScopeAndNewsUniverseUnchanged': True, 'semanticCoverageCertified': False,
    'currentFixedFullNativeProductsVisiblePairedAndPhysicalWindows': 'OPEN', 'wholePrintingOrGoalCertified': False}
with (ev / 'independent-publication-and-retention-verification.json').open('x') as f: json.dump(proof, f, ensure_ascii=False, indent=2)
print('PASS canonical publication:162 reviews77 contexts250 gates7 deltas;17088 original obligation IDs +21 branches+5 source gaps=17114;615 archive members exact; semanticfalse')
