from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import datetime,gzip,hashlib,json,re,subprocess,sys
sys.dont_write_bytecode=True
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;rawdir=w/'en-curl-originals-v1';rawdir.mkdir();sys.path.insert(0,str(root/'scripts/audit'));from gallery_coverage import merge_gallery_views
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda b:hashlib.sha256(b).hexdigest();receipts=[]
def get(url,name):
 temporary=rawdir/(name+'.temporary');headers=rawdir/(name+'.headers.temporary');start=now();result=subprocess.run(['curl','--location','--max-time','30','--silent','--show-error','--output',str(temporary),'--dump-header',str(headers),'--write-out','%{http_code}\n%{url_effective}\n',url],capture_output=True,text=True);received=now();raw=temporary.read_bytes() if temporary.exists() else b'';lines=result.stdout.splitlines();status=int(lines[0]) if lines and lines[0].isdigit() else None;resolved=lines[1] if len(lines)>1 else None
 raw_headers=headers.read_text(errors='replace') if headers.exists() else '';kept={}
 for line in raw_headers.splitlines():
  if ':' in line:
   k,v=line.split(':',1)
   if k.lower() in {'date','etag','age','cache-control','last-modified','content-type'}:kept[k.lower()]=v.strip()
 path=rawdir/(name+'.gz');assert not path.exists();path.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(path.read_bytes())==raw
 r={'url':url,'startedAtUtc':start,'receivedAtUtc':received,'curlExitCode':result.returncode,'httpStatus':status,'resolvedUrl':resolved,'selectedResponseHeaders':kept,'originalRawSha256':sha(raw),'originalRawBytes':len(raw),'losslessCompressedOriginal':str(path.relative_to(root)),'compressedSha256':sha(path.read_bytes())};receipts.append(r);(rawdir/(name+'.receipt.json')).write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');temporary.unlink(missing_ok=True);headers.unlink(missing_ok=True)
 if result.returncode!=0 or status is None or not 200<=status<300:raise RuntimeError(str({'status':status,'curlExit':result.returncode,'stderr':result.stderr[:300],'receipt':str(path)}))
 return json.loads(raw) if name.endswith('.json') else raw

def diff(old,new):
 a={x['id']:x for x in old};b={x['id']:x for x in new};assert len(a)==len(old) and len(b)==len(new)
 changes=[{'id':id,'fields':sorted(k for k in set(a[id])|set(b[id]) if a[id].get(k)!=b[id].get(k) or (k in a[id])!=(k in b[id]))} for id in sorted(a.keys()&b.keys()) if a[id]!=b[id]]
 return {'previousRows':len(a),'currentRows':len(b),'addedIds':sorted(b.keys()-a.keys()),'unreturnedPreviousIds':sorted(a.keys()-b.keys()),'changedCompleteRows':changes,'allCompleteRowsKeysValuesAndNullsExact':a==b,'canonicalCurrentRowsSha256':sha(json.dumps(sorted(new,key=lambda x:x['id']),ensure_ascii=False,sort_keys=True).encode())}
proof={'status':'RUNNING_FRESH_CURRENT_EN_THREE_VIEWS_SOURCE_READ','startedAtUtc':now(),'noCertificateValidationDisabled':True,'noRootTrackedSourcesOrManifestsChanged':True,'region':'GLOBAL','language':'en-US','publicationEffectiveDatesNotInferredFromFetchTime':True}
try:
 base='https://content.publishing.riotgames.com/publishing-content/v2.0/public/channel/riftbound_website/list/riftbound_gallery_cards?locale=en_US&limit=200&from=';first=get(base+'0','en-page-0000.json');total=first['metadata']['totalItems']
 with ThreadPoolExecutor(max_workers=3) as pool:pages=[first]+list(pool.map(lambda i:get(base+str(i),f'en-page-{i:04}.json'),range(200,total,200)))
 assert all(p['metadata']['totalItems']==total for p in pages)
 whole=get(base.replace('limit=200','limit=2000')+'0','en-whole.json');html=get('https://playriftbound.com/en-us/card-gallery/','en-gallery.html').decode();n=json.loads(re.search(r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>',html,re.S).group(1));gallery=next(b for b in n['props']['pageProps']['page']['blades'] if b['type']=='riftboundCardGallery')
 rows,views=merge_gallery_views([{'name':'currentPagination','reportedTotal':total,'records':[c for p in pages for c in p['data']]},{'name':'currentWholeList','reportedTotal':whole['metadata']['totalItems'],'records':whole['data']},{'name':'currentSsr','reportedTotal':gallery['cards']['async']['metadata']['totalItems'],'records':gallery['cards']['items']}]);manifest=json.loads((root/'docs/audit/current-manifest.json').read_text());delta=next(d for d in reversed(manifest['laterSourceDeltas']) if d['kind']=='cards');latest=json.loads((root/delta['after']['path']).read_text());assert isinstance(latest['data'],list)
 proof.update(region='GLOBAL',language='en-US',reportedTotal=total,returnedUnique=len(rows),reportedButUnreturned=total-len(rows),currentViewComparison=views,latestAlreadyRegisteredSourceVersion=delta['after'],diffAgainstLatestRegisteredVersion=diff(latest['data'],rows));print('EN current',total,'reported',len(rows),'unique; vs latest',proof['diffAgainstLatestRegisteredVersion'],flush=True)
 try:
  default=get(base.replace('locale=en_US&','').replace('limit=200','limit=2000')+'0','default-locale-whole.json');current={c['id'] for c in rows};actual={c['id'] for c in default['data']};proof['boundedDefaultLocaleGapHypothesis']={'actualMetadata':default['metadata'],'returnedRows':len(default['data']),'distinctIds':len(actual),'idsNotInCurrentExplicitEnglishViews':sorted(actual-current),'explicitEnglishIdsMissing':sorted(current-actual),'noMergeWithoutLocaleEvidence':True,'backendCauseNotInferred':True}
 except Exception as error:proof['boundedDefaultLocaleGapHypothesis']={'errorType':type(error).__name__,'error':str(error),'sourceGapNotClosed':True}
 proof['status']='COMPLETE_CURRENT_EXPLICIT_EN_VIEWS_READ_AND_LATEST_REGISTERED_DIFF_DEFAULT_LOCALE_HYPOTHESIS_SEPARATE'
except BaseException as error:
 proof.update(status='CURRENT_EN_SOURCE_READ_STILL_INCOMPLETE_OR_NONATOMIC',errorType=type(error).__name__,error=str(error));raise
finally:
 proof.update(finishedAtUtc=now(),originalResponseReceipts=sorted(receipts,key=lambda r:r['losslessCompressedOriginal']));(w/'current-en-complete-view-source-diff-v1.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print(proof['status'],flush=True)
