from pathlib import Path
import datetime, gzip, hashlib, json

root = Path('/Users/dinghaolin/MyProjects/riftbound')
w = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
pin = lambda p: {'path': str(p.relative_to(root)), 'sha256': sha(p)}
original = w / 'en-curl-originals-v1/en-whole.json.gz'
receipt = json.loads((w / 'en-curl-originals-v1/en-whole.json.receipt.json').read_text())
raw = gzip.decompress(original.read_bytes())
assert hashlib.sha256(raw).hexdigest() == receipt['originalRawSha256']
assert sha(original) == receipt['compressedSha256'] and receipt['httpStatus'] == 200
source = json.loads(raw)
assert source['metadata']['totalItems'] == 1416 and len(source['data']) == 1408
normalize = lambda s: s.replace('\u2019', "'")
subjects = [
    ('Evelynn', "Agony's Embrace", 'legend'),
    ('Ahri', 'Nine-Tailed Fox', 'legend'),
    ('Akali', 'Rogue Assassin', 'legend'),
    ("Kai'Sa", 'Daughter of the Void', 'legend'),
    (None, 'Packed Amphitheater', 'battlefield'),
]
results = []
for character, name, kind in subjects:
    rows = [r for r in source['data'] if normalize(r['name']) == name
            and kind in [t['id'] for t in r['cardType']['type']]]
    assert rows
    results.append({
        'announcedCharacter': character, 'announcedName': name, 'announcedType': kind,
        'nameComparison': 'Exact official English name, only typographic apostrophe normalized; no translation or printing identity merge',
        'currentReturnedSameNameAndTypeRows': rows,
        'currentReturnedExactIds': [r['id'] for r in rows],
        'currentReturnedPublicCodes': [r['publicCode'] for r in rows],
        'announcedCouturePrintingAssignedToExistingId': False,
        'preciseAnnouncedPrintingIdentity': 'OPEN',
        'rulesIdentityLegalityAndEffectiveDate': 'OPEN_NOT_INFERRED_FROM_BASE_NAME_OR_SHOPPING_DATE',
    })
assert sum(len(r['currentReturnedSameNameAndTypeRows']) for r in results) == 13
artists = [r for r in source['data'] if any('fortiche' in (v.get('id', '') + ' ' + v.get('label', '')).lower()
           for v in r.get('illustrator', {}).get('values', []))]
proof = {
    'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'FIVE_ANNOUNCED_NAMES_RECONCILED_WITH_THIRTEEN_EXISTING_NAMED_GALLERY_ROWS_PRECISE_COUTURE_PRINTINGS_STILL_OPEN',
    'region': 'GLOBAL', 'language': 'en-US',
    'freshWholeGalleryOriginal': pin(original), 'originalReceipt': pin(w / 'en-curl-originals-v1/en-whole.json.receipt.json'),
    'actualAcquisitionStartedAtUtc': receipt['startedAtUtc'], 'actualAcquisitionReceivedAtUtc': receipt['receivedAtUtc'],
    'announcementIntake': pin(w / 'current-kda-product-faq-five-announced-card-source-intake-v1.json'),
    'actualPrimaryPixelsObservation': pin(w / 'kda-primary-header-actual-pixel-observation-v1.json'),
    'reportedGalleryCount': 1416, 'returnedGalleryCount': 1408, 'originalEightRowGapStillOpen': True,
    'subjects': results,
    'allReturnedRowsWithForticheIllustratorMetadata': [r['id'] for r in artists],
    'noForticheMetadataIsNotProofThatACollectiblePrintingIsUnavailableOrAbsent': True,
    'fiveAnnouncedSubjectsNotAssumedToExplainTheEightGalleryGap': True,
    'allExisting1740PrintingsAnd139ChineseNewsScopeRetained': True,
    'noGameplayCatalogInputsSourceDatesOrExistingCertificationClaimsChanged': True,
    'wholePrintingOrGoalCertified': False,
}
target = w / 'kda-five-announced-names-current-gallery-candidate-reconciliation-v1.json'
with target.open('x') as f:
    json.dump(proof, f, ensure_ascii=False, indent=2)
print('PASS bounded name reconciliation: five subjects, thirteen existing named rows; precise collectible identity remains OPEN')
