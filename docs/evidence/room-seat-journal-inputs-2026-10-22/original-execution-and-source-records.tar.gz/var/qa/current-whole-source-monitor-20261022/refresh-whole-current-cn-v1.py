from pathlib import Path
from urllib.request import Request,urlopen
from concurrent.futures import ThreadPoolExecutor
import datetime,gzip,hashlib,json,math,re,sys
sys.dont_write_bytecode=True
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;rawdir=w/'card-originals-v1';rawdir.mkdir();baseline=root/'data/official/upstream/2026-10-16/source-refresh-20261015T160523Z'
sys.path.insert(0,str(root/'scripts/audit'));from gallery_coverage import merge_gallery_views
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda b:hashlib.sha256(b).hexdigest();receipts=[]
def get(url,name,body=None):
 start=now();req=Request(url,json.dumps(body).encode() if body is not None else None,{'Content-Type':'application/json','User-Agent':'Mozilla/5.0','Cache-Control':'no-cache'})
 with urlopen(req,timeout=35) as r:raw=r.read();headers={k:r.headers[k] for k in ['Date','ETag','Age','Cache-Control','Last-Modified','Content-Type'] if k in r.headers};status=r.status;resolved=r.url
 path=rawdir/(name+'.gz');assert not path.exists();path.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(path.read_bytes())==raw
 receipt={'url':url,'request':body,'startedAtUtc':start,'receivedAtUtc':now(),'httpStatus':status,'resolvedUrl':resolved,'responseHeaders':headers,'originalRawBytes':len(raw),'originalRawSha256':sha(raw),'losslessCompressedOriginal':str(path.relative_to(root)),'compressedSha256':sha(path.read_bytes())};receipts.append(receipt);(rawdir/(name+'.receipt.json')).write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');return json.loads(raw) if name.endswith('.json') else raw

def diff(old,new):
 previous={x['id']:x for x in old};current={x['id']:x for x in new};assert len(current)==len(new)
 changed=[{'id':id,'changedFields':sorted(k for k in set(previous[id])|set(current[id]) if previous[id].get(k)!=current[id].get(k) or (k in previous[id])!=(k in current[id])),'oldCanonicalRowSha256':sha(json.dumps(previous[id],ensure_ascii=False,sort_keys=True).encode()),'currentCanonicalRowSha256':sha(json.dumps(current[id],ensure_ascii=False,sort_keys=True).encode())} for id in sorted(previous.keys()&current.keys()) if previous[id]!=current[id]]
 return {'previous':len(previous),'current':len(current),'addedIds':sorted(current.keys()-previous.keys()),'unreturnedPreviousIds':sorted(previous.keys()-current.keys()),'changedCompleteRows':changed,'allPreviousKeysValuesAndNullsExact':not(changed or previous.keys()-current.keys()),'currentCanonicalRowsSha256':sha(json.dumps(sorted(new,key=lambda x:x['id']),ensure_ascii=False,sort_keys=True).encode())}
proof={'status':'RUNNING_WHOLE_CURRENT_CARD_SOURCE_READ_NOT_ADOPTED','startedAtUtc':now(),'primarySourcesOnly':True,'activeInputsAndExistingScopeDatesAndManifestsUnchanged':True,'firstPublicationAndEffectiveDatesNotInferredFromFetchTime':True}
try:
 url='https://lol-api.playloltcg.com/xcx/card/searchCardCraftWeb';body={'pageNum':1,'pageSize':100,'searchContent':'','cardCategoryList':[],'cardColorList':[],'rarityList':[],'productCodeList':[]};first=get(url,'cn-page-01.json',body)['result'];total=first['total']
 with ThreadPoolExecutor(max_workers=4) as pool:pages=[first]+list(pool.map(lambda i:get(url,f'cn-page-{i:02}.json',{**body,'pageNum':i})['result'],range(2,math.ceil(total/100)+1)))
 cards=[c for page in pages for c in page['list']];assert all(page['total']==total for page in pages) and len(cards)==len({c['id'] for c in cards})==total
 old=json.loads((baseline/'card-catalog.zh-CN.json').read_text());proof['CN']={'language':'zh-CN','region':'CN','reportedTotal':total,'returnedUnique':len(cards),'pages':len(pages),'diff':diff(old['cards'],cards),'nonnullApiQaRows':sum(bool(c.get('cardQaList')) for c in cards)};print('CN',total,'rows;',len(proof['CN']['diff']['changedCompleteRows']),'changed;',len(proof['CN']['diff']['addedIds']),'new',flush=True)
 manifest=json.loads((root/'docs/audit/current-manifest.json').read_text());latest=next(d['after'] for d in reversed(manifest['laterSourceDeltas']) if d['kind']=='cn_cards');registered=json.loads((root/latest['path']).read_text());assert isinstance(registered['data'],list)
 proof['comparedToLatestRegisteredCnVersion']=latest;proof['CN']['diffAgainstLatestRegisteredVersion']=diff(registered['data'],cards);proof['status']='COMPLETE_CURRENT_WHOLE_CN_FIELDS_AND_QA_DIFF_ONLY_NOT_ADOPTED'
except BaseException as error:
 proof.update(status='CURRENT_CN_SOURCE_READ_INCOMPLETE_ALL_ORIGINALS_RETAINED',errorType=type(error).__name__,error=str(error));raise
finally:
 proof.update(finishedAtUtc=now(),originalResponseReceipts=sorted(receipts,key=lambda r:r['losslessCompressedOriginal']));(w/'whole-current-cn-card-source-diff-v1.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print(proof['status'],flush=True)
