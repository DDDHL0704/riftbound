using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using Npgsql;
using Riftbound.Engine;
using Riftbound.Persistence;

var writer = Assembly.LoadFrom(Path.Combine(AppContext.BaseDirectory, "Riftbound.PostgresAcceptance.dll"));
var target = writer.GetType("OpeningRandomnessSqlAcceptance")!.GetMethod("RunAsync", BindingFlags.Static | BindingFlags.Public)!;
if (args.SequenceEqual(new[] { "--identity" }))
{
    Console.WriteLine(JsonSerializer.Serialize(new {
        baseDirectory = AppContext.BaseDirectory, actualRuleInputs = RuleInputIdentity.Current,
        originalTargetClass = target.DeclaringType!.FullName, originalTargetMethod = target.Name,
        actualWriterAssemblyPath = writer.Location, writerSha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(writer.Location))).ToLowerInvariant(),
        writerMvid = writer.ManifestModule.ModuleVersionId,
        assemblies = new[] { typeof(MatchSession).Assembly, typeof(Riftbound.Contracts.GameCommand).Assembly,
            typeof(Riftbound.CardCatalog.OfficialCardCatalog).Assembly, typeof(PostgresMatchJournal).Assembly }
            .Select(a => new { name = a.GetName().Name, path = a.Location,
                sha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(a.Location))).ToLowerInvariant(), mvid = a.ManifestModule.ModuleVersionId })
    }, new JsonSerializerOptions(JsonSerializerDefaults.Web))); return;
}
var settings = new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
if (settings.Host != "127.0.0.1" || settings.Port != 55486 || settings.Database != "riftbound_acceptance" || settings.Username != "codex_riftbound_audit")
    throw new InvalidOperationException("Only the existing dedicated audit database is allowed.");
var output = args.Single(); if (Directory.Exists(output)) throw new InvalidOperationException("Fresh original private-opening output required.");
await using var source = NpgsqlDataSource.Create(settings.ConnectionString);
await (Task)target.Invoke(null, [source, output])!;
Console.WriteLine("ACTUAL_ORIGINAL_PRIVATE_OPENING_CLASS_EXECUTED_ONLY; the unrelated fixed-room causal fixture and the full SQL suite were not reissued.");
