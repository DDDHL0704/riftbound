using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using Npgsql;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
if (args.SequenceEqual(new[] { "--identity" }))
{
    Console.WriteLine(JsonSerializer.Serialize(new {
        baseDirectory = AppContext.BaseDirectory, actualRuleInputs = RuleInputIdentity.Current,
        assemblies = new[] { typeof(MatchSession).Assembly, typeof(SubmitDeckCommand).Assembly,
            typeof(Riftbound.CardCatalog.OfficialCardCatalog).Assembly, typeof(PostgresMatchJournal).Assembly }
            .Select(a => new { name = a.GetName().Name, path = a.Location,
                sha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(a.Location))).ToLowerInvariant(),
                mvid = a.ManifestModule.ModuleVersionId.ToString() })
    }, json)); return;
}
var output = args.Single(); Directory.CreateDirectory(output);
var room = "room-seat-journal-fault-" + Guid.NewGuid().ToString("N");
var connection = Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound")!;
await using var source = NpgsqlDataSource.Create(connection);
var playerStore = new PostgresMatchPlayerStore(source);
var recoveryStore = new PostgresMatchRecoveryStore(source);
var journal = new PostgresMatchJournal(source);
var fault = new FailFirstSeatJournal(journal);
var session = new MatchSession(room, new CoreRuleEngine(), fault, playerStore);
await File.WriteAllTextAsync(Path.Combine(output, "original-first-join-input.json"), JsonSerializer.Serialize(new { room, actor = "alice", operation = "EnsurePlayerAsync", originalFault = "before first seat journal write, after actual player-store commit" }, json));
var failedAtInjectedJournal = false;
try { await session.EnsurePlayerAsync("alice", default); }
catch (InvalidOperationException e) when (e.Message == "controlled first ROOM_SEAT journal failure") { failedAtInjectedJournal = true; }
if (!failedAtInjectedJournal) throw new InvalidOperationException("Controlled actual journal fault was not reached.");
var first = await recoveryStore.LoadAsync(room, default) ?? throw new InvalidOperationException("No metadata left by failed join.");
await File.WriteAllTextAsync(Path.Combine(output, "original-after-failed-first-seat-frame.json"), JsonSerializer.Serialize(first, json));
var loaded = await new InMemoryMatchSessionRegistry(new CoreRuleEngine(), journal, recoveryStore, playerStore).GetOrCreateAsync(room, default);
var aliceError = "";
try { await loaded.EnsurePlayerAsync("alice", default); }
catch (MatchSessionException e) { aliceError = e.Code; }
await File.WriteAllTextAsync(Path.Combine(output, "original-second-join-input.json"), JsonSerializer.Serialize(new { room, actor = "bob", operation = "EnsurePlayerAsync", freshRegistry = true }, json));
await loaded.EnsurePlayerAsync("bob", default);
var final = await recoveryStore.LoadAsync(room, default) ?? throw new InvalidOperationException("No original frame after second join.");
await File.WriteAllTextAsync(Path.Combine(output, "original-after-second-seat-frame.json"), JsonSerializer.Serialize(final, json));
var replayErrors = await MatchActionLogReplayer.ValidateRecoveryFrameAsync(final, new CoreRuleEngine(), default);
var coldError = "";
try { await new InMemoryMatchSessionRegistry(new CoreRuleEngine(), journal, recoveryStore, playerStore).GetOrCreateAsync(room, default); }
catch (MatchSessionException e) { coldError = e.Code; }
var confirmed = first.Commands.Count == 0 && first.AuthoritativeState!.Seats.TryGetValue("alice", out var slot) && slot == "P1"
    && aliceError == ErrorCodes.InvalidReconnectToken && final.Commands.Count == 1
    && final.Commands[0].Accepted && final.Commands[0].CommandType == "ROOM_SEAT"
    && final.Commands[0].PlayerId == "bob" && !final.IsConsistent
    && coldError == ErrorCodes.RecoveryInconsistent && replayErrors.Count > 0;
var proof = new {
    status = confirmed ? "CONFIRMED_CURRENT_WIP_NONATOMIC_FIRST_SEAT_GHOST_AND_UNREPLAYABLE_SECOND_JOIN" : "UNEXPECTED_OBSERVATION_REQUIRES_INSPECTION",
    room, actualRuleInputs = RuleInputIdentity.Current, injectedJournalFaultReached = failedAtInjectedJournal,
    failedJoinMetadataCommands = first.Commands.Count, failedJoinLoadedSeats = first.AuthoritativeState?.Seats,
    failedJoinFrameWasConsistent = first.IsConsistent, firstActorRetryErrorCode = aliceError,
    secondJoinCommands = final.Commands.Count, secondJoinEvents = final.Events.Count,
    secondJoinFrameErrors = final.ValidationErrors, replayErrors, coldError,
    releasedParentBe0eHasThisNewRoomSeatImplementation = false,
    oldMatchesSeedsOrHistoriesRewritten = false, allOriginalFramesAndInputsRetained = true
};
await File.WriteAllTextAsync(Path.Combine(output, "receipt.json"), JsonSerializer.Serialize(proof, json));
Console.WriteLine(JsonSerializer.Serialize(proof, json));
if (!confirmed) throw new InvalidOperationException("The candidate boundary observation differs from the predicted counterexample.");

sealed class FailFirstSeatJournal(IMatchJournal actual) : IMatchJournal
{
    private bool first = true;
    public ValueTask RecordAsync(MatchJournalEntry entry, CancellationToken token)
    {
        if (first && entry.CommandType == "ROOM_SEAT") { first = false; throw new InvalidOperationException("controlled first ROOM_SEAT journal failure"); }
        return actual.RecordAsync(entry, token);
    }
}
