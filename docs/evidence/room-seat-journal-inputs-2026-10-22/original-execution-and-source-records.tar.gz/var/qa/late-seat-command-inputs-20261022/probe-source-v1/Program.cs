using System.IO.Compression;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using Npgsql;
using Riftbound.CardCatalog;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

if (args.Length != 1 || Directory.Exists(args[0])) throw new Exception("Fresh retained late-seat probe output required.");
Directory.CreateDirectory(args[0]);
var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
if (RuleInputIdentity.Current.IdentitySha256 != "b8817f46b4abfd81dccbf54892260694ae7341145c4b315f5a11c363beeadf8d") throw new Exception("Only measured N38/be0e inputs.");
await using var data = NpgsqlDataSource.Create(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound")!);
var engine = new CoreRuleEngine(); var journal = new PostgresMatchJournal(data); var players = new PostgresMatchPlayerStore(data); var store = new PostgresMatchRecoveryStore(data);
var room = "late-seat-input-" + Guid.NewGuid().ToString("N");
var session = new MatchSession(room, engine, journal, players);
var catalog = await OfficialCardCatalog.LoadDefaultAsync(); var deck = PreconstructedDeckCatalog.Build(catalog).Single(d => d.Id == "lillia-lowcurve").Decklist;
var command = new SubmitDeckCommand(deck.LegendCardNo, deck.ChampionCardNo, deck.MainDeck, deck.RuneDeck, deck.Battlefields);
var raw = JsonSerializer.SerializeToElement(command, command.GetType(), json);
var a = await session.EnsurePlayerAsync("late-seat-a", default);
var first = await session.SubmitDeckAsync(a.PlayerId, "first-deck-a", command, raw, default);
if (!first.Accepted || first.State.Seats.Count != 1) throw new Exception(first.ErrorMessage ?? "First actual input must have only A.");
var firstFrame = await store.LoadAsync(room, default) ?? throw new Exception("Original first frame missing.");
await Save("original-after-first-a-deck-frame.json.gz", firstFrame);
var b = await session.EnsurePlayerAsync("late-seat-b", default);
var afterJoin = await store.LoadAsync(room, default) ?? throw new Exception("Frame after original B join missing.");
await Save("original-after-b-join-before-next-command-frame.json.gz", afterJoin);
var afterJoinErrors = await MatchActionLogReplayer.ValidateRecoveryFrameAsync(afterJoin, engine, default);
var second = await session.SubmitDeckAsync(b.PlayerId, "second-deck-b", command, raw, default);
if (!second.Accepted) throw new Exception(second.ErrorMessage ?? "Second actual input rejected.");
var final = await store.LoadAsync(room, default) ?? throw new Exception("Final original frame missing.");
await Save("original-after-second-b-deck-frame.json.gz", final);
var finalErrors = await MatchActionLogReplayer.ValidateRecoveryFrameAsync(final, engine, default);
var prefix = await MatchActionLogReplayer.VerifyFinalStateAsync(final.ReplayInitialState!, final.Commands.Take(1).ToArray(), first.State, engine, default, firstFrame.Events);
var confirmed = firstFrame.Commands.Count == 1 && final.Commands.Count == 2 && firstFrame.AuthoritativeState!.Seats.Count == 1
    && final.ReplayInitialState!.Seats.Count == 2 && !prefix.IsMatch && afterJoinErrors.Count > 0 && finalErrors.Count == 0;
var result = new {
    atUtc = DateTimeOffset.UtcNow, status = confirmed ? "CONFIRMED_CURRENT_BE0E_FIRST_DECK_HISTORY_AND_TRAILING_JOIN_COLD_REPLAY_GAPS" : "OBSERVATION_ONLY_SCOPE_NOT_CONFIRMED",
    room, actualRuleInputs = RuleInputIdentity.Current, actualBaseDirectory = AppContext.BaseDirectory,
    actualAssemblies = new[] { typeof(CoreRuleEngine).Assembly, typeof(SubmitDeckCommand).Assembly, typeof(OfficialCardCatalog).Assembly, typeof(PostgresMatchJournal).Assembly }
        .Select(x => new { name = x.GetName().Name, path = x.Location, sha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(x.Location))).ToLowerInvariant(), mvid = x.ManifestModule.ModuleVersionId }).ToArray(),
    firstOriginalSeats = first.State.Seats, replayInitialSeatsAfterLaterJoin = final.ReplayInitialState!.Seats,
    originalCommands = final.Commands.Count, originalEvents = final.Events.Count,
    afterJoinBeforeAnyNewCommand = new { originalLatestAuthoritySeats = afterJoin.AuthoritativeState!.Seats, originalReplayInitialSeats = afterJoin.ReplayInitialState!.Seats, errors = afterJoinErrors },
    firstHistoricalPrefixReplay = prefix, finalOnlyRecoveryErrors = finalErrors,
    allOriginalInputIntentsFramesEventsAndSeedRetained = true, oldGamesChangedOrMigrated = false, commandsReissuedToLiveRoom = false,
    apiOrNativeUiExercised = false, wholeProductOrFixedCiAcceptance = false
};
await File.WriteAllTextAsync(Path.Combine(args[0], "result.json"), JsonSerializer.Serialize(result, json));
Console.WriteLine(JsonSerializer.Serialize(new { result.status, room, result.originalCommands, result.originalEvents, afterJoinErrors, prefix.IsMatch, finalErrors }, json));
if (!confirmed) throw new Exception("Bounded current source counterexample did not confirm all declared observations.");

async Task Save(string name, MatchRecoveryFrame frame)
{
    await using var output = new FileStream(Path.Combine(args[0], name), FileMode.CreateNew);
    await using var gz = new GZipStream(output, CompressionLevel.SmallestSize);
    await JsonSerializer.SerializeAsync(gz, frame, json);
}
