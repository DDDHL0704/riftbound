from pathlib import Path
import collections, datetime, hashlib, json, re, subprocess, xml.etree.ElementTree as ET

root = Path('/Users/dinghaolin/MyProjects/riftbound'); w = Path(__file__).resolve().parent
load = lambda p: json.loads(p.read_text()); sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
pin = lambda p: {'path': str(p.relative_to(root)), 'sha256': sha(p)}
ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
first = load(w / 'first-only-check-original-case-method-and-input-retention-v1.json')
assert first['actualCases'] == 13369 and first['actualMethods'] == 7530 and first['outcomes'] == {'Passed': 13363, 'Failed': 6}
focus = w / 'post-check-atomic-room-seat-focus-v1/focus/results.trx'; tree = ET.parse(focus)
rows = tree.findall('.//t:UnitTestResult', ns)
defs = {e.get('id'): e.find('t:TestMethod', ns).attrib for e in tree.findall('.//t:UnitTest', ns)}
methods = {defs[e.get('testId')]['className'] + '.' + defs[e.get('testId')]['name'] for e in rows}
assert len(rows) == 358 and len(methods) == 279 and all(e.get('outcome') == 'Passed' for e in rows)
assert set(first['actualFailedOrNonPassed']) <= {e.get('testName') for e in rows}

def discovered(path):
    names = [line.strip() for line in path.read_text().splitlines() if line.strip().startswith('Riftbound.ConformanceTests.')]
    return collections.Counter(names), {re.match(r'Riftbound\.ConformanceTests\.\w+\.\w+', n).group() for n in names}

before, before_methods = discovered(w / 'only-check-v1/discovery.log')
after, after_methods = discovered(w / 'post-check-atomic-room-seat-focus-v1/discovery.log')
parent, parent_methods = discovered(root / 'var/qa/special-trigger-damage-current-cn16-20261021/only-check-v1/discovery.log')
assert before == after and before_methods == after_methods
assert sum(after.values()) == 13412 and len(after_methods) == 7671
assert sum(parent.values()) == 13391 and len(parent_methods) == 7662
assert not parent - after and parent_methods <= after_methods
assert sum((after - parent).values()) == 21 and len(after_methods - parent_methods) == 9
assert set(after - parent) == set(first['actualNewCaseIdentities'])

f = load(w / 'current-room-seat-frozen-runtime-inputs-v2.json')
old_runtime = load(w / 'current-room-seat-frozen-runtime-inputs-v1.json')
assert len(f['sourceInputHashes']) == 3336 and f['actualRuleInputs']['identitySha256'] == '47e17f3592b33de6c9398fdbb31fa08c6d647b6e77abb93f0f913ab8b37d284e'
assert f['actualRuleInputs']['authoritySha256'] == old_runtime['actualRuleInputs']['authoritySha256']
assert f['actualRuleInputs']['catalogSha256'] == old_runtime['actualRuleInputs']['catalogSha256']
assert f['actualRuleInputs']['identitySha256'] != old_runtime['actualRuleInputs']['identitySha256']
assert all(sha(root / p) == h and oct((root / p).stat().st_mode & 0o777) == f['sourceInputModes'][p] for p, h in f['sourceInputHashes'].items())
runtime = Path(f['runtimeRoot']); assert all(sha(runtime / p) == h for p, h in f['runtimeFiles'].items())
plan = load(w / 'post-check-atomic-room-seat-focus-v1/plan.json')
assert plan['testAssemblySha256'] == sha(runtime / 'Riftbound.ConformanceTests.dll')
assert plan['testAssemblySha256'] == sha(root / 'tests/Riftbound.ConformanceTests/bin/Debug/net10.0/Riftbound.ConformanceTests.dll')
old = load(w / 'pre-change-current-be0e-room-input-source-retention-v1.json')
changed = [p for p, h in old['allOriginalConformanceInputs'].items() if sha(root / p) != h]
assert set(changed) == {'tests/Riftbound.ConformanceTests/OpeningRandomizationTests.cs',
                       'tests/Riftbound.ConformanceTests/GameHubJoinTests.cs', 'tests/Riftbound.ConformanceTests/MatchRecoveryTests.cs'}
for p in changed:
    original = subprocess.check_output(['git', 'show', f['parentCommit'] + ':' + p], cwd=root).decode()
    current = (root / p).read_text()
    attrs = lambda s: [line.strip() for line in s.splitlines() if re.match(r'\s*\[(?:Fact|Theory|InlineData|MemberData|ClassData)\b', line)]
    assert attrs(original) == attrs(current), 'Original Fact/Theory/data rows changed: ' + p
correction = load(w / 'finite-room-seat-atomicity-and-original-fixture-plan-v3.json')
assert all(sha(root / p) == h for p, h in correction['sourceHashesProposed'].items())
assert len(f['allNineFullGameSourcesByteExact']) == 9
for p, h in f['allNineFullGameSourcesByteExact'].items():
    assert sha(root / p) == h and (root / p).read_bytes() == subprocess.check_output(['git', 'show', f['parentCommit'] + ':' + p], cwd=root)
sqlpath = 'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'
sql = load(root / sqlpath); previous_sql = json.loads(subprocess.check_output(['git', 'show', f['parentCommit'] + ':' + sqlpath], cwd=root))
assert len(sql['cases']) == 57 and len(previous_sql['cases']) == 56 and sql['cases'][:56] == previous_sql['cases'] and sql['cases'][-1]['id'] == 'room-seat-journal'
old_sql_sources = set(r['sourceType'] for r in previous_sql['cases']) - {'PROGRAM_CORE_OPENING', 'OpeningRandomnessSqlAcceptance'}
for name in old_sql_sources:
    p = 'tests/Riftbound.PostgresAcceptance/' + name + '.cs'
    assert (root / p).read_bytes() == subprocess.check_output(['git', 'show', f['parentCommit'] + ':' + p], cwd=root), p
start = load(w / 'only-check-start-inputs-v1.json')
assert all(sha(root / p) == h for p, h in start['actualNativeRuntimeFileHashes'].items())

real = load(w / 'actual-current-room-seat-sql-owner-terminal-v2.json')
independent = load(w / 'independent-current-room-seat-all-live-input-history-v2.json')
private = load(w / 'corrected-original-private-opening-real-sql-owner-terminal-v2.json')
assert real['writerCases'] == 6 and real['commands'] == 40 and real['events'] == 84 and real['coldRecoveries'] == 41
assert real['allOriginal323AuditSevenTablesExactAtStop'] and real['allOriginal66NativeSevenTablesExactAtStop'] and real['ownPostgresStopped']
assert independent['cases'] == 6 and independent['commands'] == 40 and independent['events'] == 84 and independent['authoritativeHistoricalStates'] == 36
assert independent['privateSnapshots'] == independent['privatePrompts'] == 48 and independent['independentStructuralRejections'] == 24
assert independent['actualReadOnlyConnection'] and independent['originalLivePrePersistenceInputsUsedAsExpected']
assert private['actualJournalCommands'] == 9 and private['actualClientCommands'] == 7 and private['actualServerRegistrations'] == 2 and private['actualEvents'] == 29
assert private['allOriginal330AuditSevenTablesExactAtStop'] and private['allOriginal66NativeSevenTablesExactAtStop'] and private['ownPostgresStopped']
pairs = load(w / 'original-all110-pairs-owner-terminal-v2.json'); result = load(w / 'original-all110-pairs-result-v2.json')
assert pairs['exitCode'] == 0 and pairs['actualOriginalDirections'] == 110 and pairs['allFrozenRuntimeAndSourceHashesStable']
assert pairs['actualRuleInputs'] == f['actualRuleInputs'] and pairs['resultSha256'] == sha(w / 'original-all110-pairs-result-v2.json')
prior_result = load(w / 'original-all110-pairs-result-v1.json')
assert result['seed'] == prior_result['seed'] == 424242 and result['originalDeckCount'] == prior_result['originalDeckCount'] == 11
assert result['selectedPairs'] == prior_result['selectedPairs'] and len(result['completed']) == result['originalFullMatrixPairCount'] == 110
comparison = {k: {'before': prior_result['completed'][k], 'after': result['completed'][k], 'equal': prior_result['completed'][k] == result['completed'][k]} for k in result['completed']}
comparison_path = w / 'post-check-atomic-vs-original-b624-all110-terminal-hash-comparison-v1.json'
with comparison_path.open('x') as stream: json.dump({'pairs': comparison, 'differences': sum(not p['equal'] for p in comparison.values()), 'originalPairIdentitiesSeedAndAssertionsRetained': True}, stream, indent=2)
proof = {
    'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'SOLE_CHECK_FAILURES_PRESERVED_EXACT_FIXTURE_CORRECTIONS_FINAL_FOCUS_ALL_ORIGINAL_DISCOVERY_SQL_ATOMICITY_AND_ALL110_PASS_NEW_FIXED_FULL_PENDING',
    'originalSoleCheck': pin(w / 'first-only-check-original-case-method-and-input-retention-v1.json'),
    'soleCheckActualCases': 13369, 'soleCheckMethods': 7530, 'soleCheckPassed': 13363, 'soleCheckFailed': 6, 'soleCheckSkipped': 0,
    'finalFocusCases': 358, 'finalFocusMethods': 279, 'finalFocusPassed': 358, 'allSixOriginalFailuresPassWithTheirOriginalAssertionsAndExplicitServerEntryGuards': True,
    'finalFocusTrx': pin(focus), 'allCurrentlyListed13412ExactCaseNamesAnd7671MethodsRetainedFromFirstCheck': True,
    'originalParentFullDiscovery13391ListedNames7662MethodsRetainedOnly21Cases9MethodsAdded': True,
    'discoveryListAndExecutedTheoryExpansionAreSeparate': True,
    'expectedNewFixedFullCases': 13518, 'expectedNewFixedFullMethods': 7671,
    'expectedFullCountBasis': 'Independently verified fixed7a13453 runtime cases plus44 N38 and21 N39; new fixed actual full TRX still pending.',
    'newMethodNames': first['newMethodNames'], 'newCaseIdentities': first['actualNewCaseIdentities'],
    'allOldFactTheoryAndDataAttributeLinesExact': True, 'threeOriginalConformanceFixtureOrPrivateStoreAdapters': changed,
    'all3336SourcesModesAndFrozenRuntimeStable': True, 'native23DebugPayloadUnchangedNotCurrentNativeExecution': True,
    'allNineFullGameSources143PublicMethods110Pairs11DecksSeed424242VictoryAndReplayAssertionsRetained': True,
    'allOriginal56SqlIdentitiesObjectsAndOrderRetainedOnly57Appended': True,
    'allOriginalSqlClassesExactExceptOneOpeningInputCountAndReceiptCalibration': True,
    'realSixRoomSeatCases': pin(w / 'actual-current-room-seat-sql-owner-terminal-v2.json'),
    'independentAllOriginalLiveInputs': pin(w / 'independent-current-room-seat-all-live-input-history-v2.json'),
    'correctedOriginalPrivateOpeningClass': pin(w / 'corrected-original-private-opening-real-sql-owner-terminal-v2.json'),
    'all110CurrentOriginalPairDirections': pin(w / 'original-all110-pairs-owner-terminal-v2.json'),
    'actualRuleInputs': f['actualRuleInputs'], 'allOldWipCounterexamplesAndCheckFailuresRetainedNotRelabelled': True,
    'noSecondCheck': True, 'newFixedFullNativeVisiblePairedAndPhysicalWindows': 'OPEN', 'wholePrintingOrGoalCertified': False,
}
with (w / 'final-current-atomic-room-seat-original-retention-v1.json').open('x') as stream: json.dump(proof, stream, ensure_ascii=False, indent=2)
print('PASS final focus358/279; all original listed discovery13412/7671; solecheck13363pass/6fail kept; sixSQL40/84, private9/29, all110 current; full/products still pending')
