from pathlib import Path
import ast, datetime, fcntl, hashlib, json, os, plistlib, resource, socket, subprocess

resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts']
read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
definition=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes=[n for n in ast.parse(definition.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}]
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(definition),'exec'),globals())
frozen=load(w/'current-room-seat-frozen-runtime-inputs-v1.json');runtime=Path(frozen['runtimeRoot'])
old=load(w/'actual-current-be0e-late-seat-probe-owner-terminal-v1.json');assert old['ownPostgresStopped']
old_audit=old['actualAuditRoomsAtStop'];old_native=old['actualNativeRoomsAtStop'];assert len(old_audit)==317 and len(old_native)==66
stable=lambda:all(sha(runtime/p)==h for p,h in frozen['runtimeFiles'].items()) and all(sha(root/p)==h and oct((root/p).stat().st_mode&0o777)==frozen['sourceInputModes'][p] for p,h in frozen['sourceInputHashes'].items())
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
terminal=w/'actual-current-room-seat-sql-owner-terminal-v1.json';assert not terminal.exists()
proof={'status':'RUNNING_CURRENT_FOUR_ROOM_SEAT_SQL_CASES','startedAtUtc':now(),'parentCommit':frozen['parentCommit'],'actualRuleInputs':frozen['actualRuleInputs'],'declaredUncommittedRoomSeatBatch':True,'lockAtStart':observe_lock(),'allOriginalRoomSeedsInputsAndHistoriesRetained':True,'original56SqlIdentitiesAndOrderRetainedOnly57Appended':True}
started=False;power=writer=reader=None;before_audit=before_native=None
try:
    assert stable();assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
    with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
    power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);sock.mkdir(exist_ok=True)
    subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'current-room-seat-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
    assert rooms('riftbound_acceptance')==old_audit and rooms('riftbound_here_native')==old_native
    before_audit=digests('riftbound_acceptance',old_audit);before_native=digests('riftbound_here_native',old_native)
    (w/'original317-audit66-native-seven-table-baseline-v1.json').write_text(json.dumps({'atUtc':now(),'auditRooms':old_audit,'nativeRooms':old_native,'auditSevenTables':before_audit,'nativeSevenTables':before_native},indent=2))
    output=w/'actual-current-room-seat-sql-v1';assert not output.exists()
    env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit',RIFTBOUND_POSTGRES_EVIDENCE=str(output),DOTNET_DbgEnableMiniDump='0')
    command=['/Users/dinghaolin/.dotnet/dotnet',str(runtime/'Riftbound.PostgresAcceptance.dll'),'--room-seat-journal-only'];proof['actualWriterCommand']=command
    with (w/'actual-current-room-seat-writer-v1.log').open('xb') as log:
        writer=subprocess.Popen(command,cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT);proof['writerExitCode']=writer.wait(timeout=900)
    assert proof['writerExitCode']==0
    receipts=[load(p) for p in (output/'room-seat-journal').rglob('receipt.json')]
    assert len(receipts)==4 and {(r['reverse'],r['late']) for r in receipts}=={(False,False),(False,True),(True,False),(True,True)}
    assert all(r['commands']==r['coldRecoveries']==r['noOpKnownPlayerJoins']==9 and r['preGameDirectAtomicRejections']==1 and r['independentStructuralRejections']==36 and r['actualRuleInputs']==frozen['actualRuleInputs'] for r in receipts)
    added={r['room'] for r in receipts};assert len(added)==4 and set(rooms('riftbound_acceptance'))==set(old_audit)|added and rooms('riftbound_here_native')==old_native
    proof.update(writerCases=4,receipts=receipts,commands=36,events=sum(r['events'] for r in receipts),coldRecoveries=36,noOpKnownPlayerJoins=36,preGameDirectAtomicRejections=4,writerIndependentStructuralRejections=144,newRooms=sorted(added));print('WRITER_PASS_four_cases36commands36cold144structural',flush=True)
    result=w/'independent-current-room-seat-all-live-input-history-v1.json'
    command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(runtime/'Riftbound.PostgresAcceptance.deps.json'),'--runtimeconfig',str(runtime/'Riftbound.PostgresAcceptance.runtimeconfig.json'),str(runtime/'CurrentRoomSeatIndependentReaderV1.dll'),str(output/'room-seat-journal'),str(result)];proof['actualReadOnlyIndependentCommand']=command
    with (w/'independent-current-room-seat-all-live-input-history-v1.log').open('xb') as log:
        reader=subprocess.Popen(command,cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT);proof['independentExitCode']=reader.wait(timeout=900)
    assert proof['independentExitCode']==0
    actual=load(result);assert actual['cases']==4 and actual['commands']==36 and actual['events']==proof['events'] and actual['actualReadOnlyConnection'] and actual['originalLivePrePersistenceInputsUsedAsExpected'] and actual['actualRuleInputs']==frozen['actualRuleInputs'] and set(actual['rooms'])==added
    proof.update(independentReadback=actual,status='PASS_CURRENT_FOUR_ROOM_SEAT_SQL_CASES_ORIGINAL_LIVE_INPUTS_ALL_HISTORY_COLD_REPLAY_AND_INDEPENDENT_REJECTIONS');print(proof['status'],flush=True)
except BaseException as error:
    proof.update(status='FAILED_CURRENT_ROOM_SEAT_SQL_OR_INDEPENDENT_READBACK_ALL_ORIGINALS_RETAINED',errorType=type(error).__name__,error=str(error));raise
finally:
    for process in [writer,reader]:
        if process and process.poll() is None:process.terminate();process.wait(timeout=20)
    if started:
        try:
            if before_audit is not None:proof['allOriginal317AuditSevenTablesExactAtStop']=digests('riftbound_acceptance',old_audit)==before_audit
            if before_native is not None:proof['allOriginal66NativeSevenTablesExactAtStop']=digests('riftbound_here_native',old_native)==before_native
            proof['actualAuditRoomsAtStop']=rooms('riftbound_acceptance');proof['actualNativeRoomsAtStop']=rooms('riftbound_here_native')
        finally:
            stop=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','fast','-w','stop'],capture_output=True);proof['ownPostgresNormalStopExitCode']=stop.returncode;proof['ownPostgresStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
    if power:
        if power.poll() is None:power.terminate()
        power.wait(timeout=10)
    proof.update(finishedAtUtc=now(),lockAtStop=observe_lock(),allFrozenSourceAndRuntimeInputsStable=stable());terminal.write_text(json.dumps(proof,ensure_ascii=False,indent=2))
