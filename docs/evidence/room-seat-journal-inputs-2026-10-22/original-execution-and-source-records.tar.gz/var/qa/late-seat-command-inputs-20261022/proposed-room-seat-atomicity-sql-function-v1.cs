        async Task RunAtomicity(bool atomicFirst)
        {
            var folder = Path.Combine(output, $"atomic-first-{atomicFirst}"); Directory.CreateDirectory(folder);
            var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
            var room = "room-seat-atomic-" + Guid.NewGuid().ToString("N");
            var constraint = "qa_room_seat_" + Guid.NewGuid().ToString("N");
            var engine = new CoreRuleEngine(); var journal = new CapturingJournal(new PostgresMatchJournal(source), folder);
            var players = new PostgresMatchPlayerStore(source); var store = new PostgresMatchRecoveryStore(source);
            IMatchSession session = new MatchSession(room, engine, journal, players);
            var tokens = new Dictionary<string, string>(StringComparer.Ordinal); var cold = 0;
            if (!atomicFirst) await Join("seat-a");
            var before = await Rows();
            await File.WriteAllTextAsync(Path.Combine(folder, "original-seven-tables-before-controlled-failure.json"), JsonSerializer.Serialize(before, json));
            var actor = atomicFirst ? "seat-a" : "seat-b";
            await File.WriteAllTextAsync(Path.Combine(folder, "original-failing-join-input.json"), JsonSerializer.Serialize(new { room, actor, operation = "EnsurePlayerAsync", atomicFirst, constraint }, json));
            var rejected = false;
            await Execute($"alter table command_log add constraint {constraint} check (match_id <> '{room}') not valid");
            try
            {
                try { await session.EnsurePlayerAsync(actor, default); }
                catch (PostgresException error) when (error.SqlState == PostgresErrorCodes.CheckViolation) { rejected = true; }
            }
            finally { await Execute($"alter table command_log drop constraint {constraint}"); }
            Check(rejected, "The actual journal SQL insert must fail inside the shared player/journal transaction.");
            var after = await Rows();
            await File.WriteAllTextAsync(Path.Combine(folder, "original-seven-tables-after-transaction-rollback.json"), JsonSerializer.Serialize(after, json));
            Check(JsonSerializer.Serialize(before, json) == JsonSerializer.Serialize(after, json), "Failed first/second seat changed original metadata or any accepted history.");
            var absent = false;
            try { session.SnapshotFor(actor); }
            catch (MatchSessionException) { absent = true; }
            Check(absent, "Failed durable registration published an in-memory seat.");
            var failedInput = Path.Combine(folder, $"entry-{journal.Entries.Count + 1:D2}-original-input-before-persist.json.gz");
            File.Move(failedInput, Path.Combine(folder, "original-failed-seat-input-before-transaction-rollback.json.gz"));
            var rollbackFrame = await store.LoadAsync(room, default);
            if (atomicFirst)
                Check(rollbackFrame is null && after.Values.All(rows => rows.Length == 0), "First-seat failure left a ghost room, credential, or implicit recovered seat.");
            else
            {
                Check(rollbackFrame is not null && rollbackFrame.IsConsistent && rollbackFrame.Commands.Count == 1
                    && rollbackFrame.AuthoritativeState!.Seats.Count == 1 && rollbackFrame.AuthoritativeState.Seats["seat-a"] == "P1",
                    "Second-seat failure must retain the exact first registered player and original journal.");
                await Save("original-after-rollback-frame.json.gz", rollbackFrame!);
                await Cold();
            }
            await Join(actor);
            if (atomicFirst) await Join("seat-b");
            var final = await store.LoadAsync(room, default) ?? throw new Exception("No retried original room.");
            Check(journal.Entries.Count == 2 && journal.Attempts.Count == 3 && journal.Attempts.Select(e => e.OpeningSeed).Distinct().Count() == 1
                && final.Commands.Count == 2 && final.Commands.All(c => c.Accepted && c.CommandType == "ROOM_SEAT")
                && final.AuthoritativeState!.Seats["seat-a"] == "P1" && final.AuthoritativeState.Seats["seat-b"] == "P2",
                "Original failed input, seed, accepted first seat and same next slot must survive retry without rewriting a command.");
            await Save("original-final-frame.json.gz", final);
            await File.WriteAllTextAsync(Path.Combine(folder, "receipt.json"), JsonSerializer.Serialize(new {
                status = "PASS_ACTUAL_FIRST_OR_SECOND_SEAT_JOURNAL_SQL_FAILURE_ATOMIC_ROLLBACK_COLD_RETRY_AND_ALL_ORIGINAL_PREFIX_REPLAYS",
                room, atomicFirst, commands = 2, events = final.Events.Count, coldRecoveries = cold,
                originalSeed = final.OpeningSeed, actualRuleInputs = RuleInputIdentity.Current,
                actualSqlCheckViolation = true, originalSevenTableRowsExactAfterRollback = true,
                firstFailureLeavesNoGhostRoomOrSeat = atomicFirst, originalUnacceptedAttemptRetained = true,
                temporarySqlConstraintRemoved = true, allOriginalAcceptedInputsAndSeedsRetained = true,
                oldGamesMigratedOrRewritten = false, currentNativeVisibleWindowsOrWholeProductAcceptance = false }, json));

            async Task Join(string player)
            {
                await File.WriteAllTextAsync(Path.Combine(folder, $"input-{journal.Entries.Count + 1:D2}-join.json"), JsonSerializer.Serialize(new { actor = player, operation = "EnsurePlayerAsync" }, json));
                tokens[player] = (await session.EnsurePlayerAsync(player, default)).ReconnectToken;
                var frame = await store.LoadAsync(room, default) ?? throw new Exception("Original accepted seat frame missing.");
                Check(frame.IsConsistent && frame.Commands.Count == journal.Entries.Count, string.Join("; ", frame.ValidationErrors));
                Check((await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame, engine, default)).Count == 0, "Retried original prefix replay differs.");
                await Save($"history-{journal.Entries.Count:D2}-original-frame.json.gz", frame);
                await Cold();
            }
            async Task Cold()
            {
                var frame = await store.LoadAsync(room, default) ?? throw new Exception("Missing original cold input.");
                session = await new InMemoryMatchSessionRegistry(engine, journal, store, players).GetOrCreateAsync(room, default);
                foreach (var player in tokens.Keys.ToArray())
                {
                    tokens[player] = (await session.ReconnectPlayerAsync(player, tokens[player], default)).ReconnectToken;
                    Check(MatchStateHasher.HashValue(session.SnapshotFor(player)) == MatchStateHasher.HashValue(frame.PlayerViews[player].Snapshot)
                        && MatchStateHasher.HashValue(session.PromptFor(player)) == MatchStateHasher.HashValue(frame.PlayerViews[player].Prompt),
                        "Original private view changed on actual cold authentication.");
                }
                cold++;
            }
            async Task Save(string name, MatchRecoveryFrame frame)
            {
                await using var file = new FileStream(Path.Combine(folder, name), FileMode.CreateNew);
                await using var gzip = new GZipStream(file, CompressionLevel.SmallestSize);
                await JsonSerializer.SerializeAsync(gzip, frame, json);
            }
            async Task Execute(string sql)
            {
                await using var connection = await source.OpenConnectionAsync();
                await new NpgsqlCommand(sql, connection).ExecuteNonQueryAsync();
            }
            async Task<Dictionary<string, string[]>> Rows()
            {
                var value = new Dictionary<string, string[]>();
                await using var connection = await source.OpenConnectionAsync();
                await using var transaction = await connection.BeginTransactionAsync();
                await new NpgsqlCommand("set transaction read only", connection, transaction).ExecuteNonQueryAsync();
                Check((string)(await new NpgsqlCommand("show transaction_read_only", connection, transaction).ExecuteScalarAsync())! == "on", "Actual rollback readback must be read only.");
                foreach (var table in new[] { "matches", "match_players", "command_log", "game_events", "state_snapshots", "snapshots", "action_prompts" })
                {
                    var rows = new List<string>();
                    await using var q = new NpgsqlCommand($"select row_to_json(t)::text from {table} t where match_id=@room order by row_to_json(t)::text", connection, transaction);
                    q.Parameters.AddWithValue("room", room);
                    await using var reader = await q.ExecuteReaderAsync();
                    while (await reader.ReadAsync()) rows.Add(reader.GetString(0));
                    value[table] = rows.ToArray();
                }
                await transaction.CommitAsync(); return value;
            }
        }

        async Task RejectNonAtomicDurableJournal()
        {
            var room = "room-seat-nonatomic-rejected-" + Guid.NewGuid().ToString("N");
            var journal = new NonAtomicJournalMustNotRun();
            var session = new MatchSession(room, new CoreRuleEngine(), journal, new PostgresMatchPlayerStore(source));
            var rejected = false;
            try { await session.EnsurePlayerAsync("seat-a", default); }
            catch (MatchSessionException error) when (error.Code == ErrorCodes.RecoveryInconsistent) { rejected = true; }
            Check(rejected && !journal.Called && await new PostgresMatchRecoveryStore(source).LoadAsync(room, default) is null,
                "Unsupported durable journal composition must fail before writing a player or room.");
            await using var connection = await source.OpenConnectionAsync();
            var counts = new Dictionary<string, long>();
            foreach (var table in new[] { "matches", "match_players", "command_log", "game_events", "state_snapshots", "snapshots", "action_prompts" })
            {
                await using var q = new NpgsqlCommand($"select count(*) from {table} where match_id=@room", connection);
                q.Parameters.AddWithValue("room", room); counts[table] = (long)(await q.ExecuteScalarAsync())!;
            }
            Check(counts.Values.All(n => n == 0), "Rejected non-atomic composition left durable room rows.");
            await File.WriteAllTextAsync(Path.Combine(output, "unsupported-nonatomic-journal-rejection.json"), JsonSerializer.Serialize(new {
                room, status = "PASS_NONATOMIC_DURABLE_JOURNAL_REJECTED_BEFORE_ANY_WRITE", journalCalled = journal.Called,
                errorCode = ErrorCodes.RecoveryInconsistent, actualSevenTableCounts = counts, actualRuleInputs = RuleInputIdentity.Current }));
        }
