from pathlib import Path
import ast, datetime, fcntl, gzip, hashlib, json, os, plistlib, resource, subprocess

resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
os.umask(0o077)
root = Path('/Users/dinghaolin/MyProjects/riftbound'); w = Path(__file__).resolve().parent
pg = Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin')
cluster = root / 'var/qa/permanent-play-here-base-20261017/postgres'
sock = Path('/tmp/rft-here-family-20261018-55486')
tables = ['matches', 'match_players', 'command_log', 'game_events', 'state_snapshots', 'snapshots', 'action_prompts']
read_env = dict(os.environ, PGOPTIONS='-c default_transaction_read_only=on')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
definition = root / 'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes = [n for n in ast.parse(definition.read_text()).body if isinstance(n, ast.FunctionDef) and n.name in {'query', 'rooms', 'digests', 'observe_lock'}]
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(definition), 'exec'), globals())
f = load(w / 'current-room-seat-frozen-runtime-inputs-v1.json'); runtime = Path(f['runtimeRoot'])
prior = load(w / 'actual-current-room-seat-sql-owner-terminal-v1.json')
old_audit, old_native = prior['actualAuditRoomsAtStop'], prior['actualNativeRoomsAtStop']
assert len(old_audit) == 321 and len(old_native) == 66 and prior['ownPostgresStopped']
stable = lambda: all(sha(runtime / p) == h for p, h in f['runtimeFiles'].items()) and all(sha(root / p) == h for p, h in f['sourceInputHashes'].items())
guard = (root / 'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a')
fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
terminal = w / 'original-opening-sql-two-server-input-counterexample-owner-terminal-v1.json'
assert not terminal.exists()
proof = {'startedAtUtc': now(), 'status': 'RUNNING_ORIGINAL_PRIVATE_OPENING_SQL_FIXTURE_EXPECTATION_COUNTEREXAMPLE',
         'actualRuleInputs': f['actualRuleInputs'], 'frozenParentCommit': f['parentCommit'],
         'currentDeclaredUncommittedInputs': True, 'lockAtStart': observe_lock(),
         'rootCheckSourceAndBinNotModified': True}
started = False; writer = power = None; before_audit = before_native = None
try:
    assert stable() and subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), 'status'], capture_output=True).returncode == 3
    power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())])
    sock.mkdir(exist_ok=True)
    subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-l', str(w / 'original-opening-sql-counterexample-postgres-v1.log'),
                    '-o', f'-p 55486 -h 127.0.0.1 -k {sock}', '-w', 'start'], capture_output=True, check=True)
    started = True
    assert rooms('riftbound_acceptance') == old_audit and rooms('riftbound_here_native') == old_native
    before_audit = digests('riftbound_acceptance', old_audit); before_native = digests('riftbound_here_native', old_native)
    output = w / 'original-opening-sql-before-fixture-calibration-v1'; assert not output.exists()
    env = dict(os.environ, ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit',
               RIFTBOUND_POSTGRES_EVIDENCE=str(output), DOTNET_DbgEnableMiniDump='0')
    command = ['/Users/dinghaolin/.dotnet/dotnet', str(runtime / 'Riftbound.PostgresAcceptance.dll'), '--opening-randomness-only']
    proof['actualCommand'] = command
    logpath = w / 'original-opening-sql-before-fixture-calibration-v1.log'
    with logpath.open('xb') as log:
        writer = subprocess.Popen(command, cwd=runtime, env=env, stdout=log, stderr=subprocess.STDOUT)
        proof['originalWriterExitCode'] = writer.wait(timeout=120)
    expected = 'Fresh production room must persist before its first command.'
    assert proof['originalWriterExitCode'] != 0 and expected in logpath.read_text()
    new = set(rooms('riftbound_acceptance')) - set(old_audit)
    assert len(new) == 1
    room = next(iter(new)); assert room.startswith('postgres-private-opening-')
    rows = {t: [json.loads(line) for line in query('riftbound_acceptance',
            'select row_to_json(t)::text from ' + t + " t where match_id='" + room.replace("'", "''") + "' order by row_to_json(t)::text").splitlines()] for t in tables}
    commands = sorted(rows['command_log'], key=lambda c: c['completed_tick'])
    assert len(commands) == 2 and [c['command_type'] for c in commands] == ['ROOM_SEAT', 'ROOM_SEAT']
    assert [c['completed_tick'] for c in commands] == [1, 2] and all(c['accepted'] for c in commands)
    assert [c['player_id'] for c in commands] == ['alice', 'bob']
    original_rows = output / 'all-seven-new-room-original-sql-rows-v1.json.gz'
    raw = json.dumps(rows, ensure_ascii=False, indent=2).encode(); original_rows.write_bytes(gzip.compress(raw, mtime=0))
    proof.update(status='CONFIRMED_ORIGINAL_PRIVATE_OPENING_FIXTURE_EXPECTED_ZERO_ROWS_BUT_TWO_REAL_DURABLE_ROOM_SEAT_INPUTS',
                 originalFailureMessage=expected, newRoom=room, actualCommands=2, actualEvents=len(rows['game_events']),
                 actualFirstTwoCompletedTicks=[1, 2], actualRawTableCounts={t: len(rs) for t, rs in rows.items()},
                 originalSqlRows={'path': str(original_rows.relative_to(root)), 'sha256': sha(original_rows)},
                 originalFailureLog={'path': str(logpath.relative_to(root)), 'sha256': sha(logpath)},
                 noSeedCommandHistoryOrExistingRoomRewritten=True,
                 completeSqlPrivateOpeningAcceptance='FAILED_ORIGINAL_FIXTURE_NOT_RELABELLED_PASS')
finally:
    if writer and writer.poll() is None: writer.terminate(); writer.wait(timeout=20)
    if started:
        try:
            if before_audit is not None: proof['allOriginal321AuditSevenTablesExact'] = digests('riftbound_acceptance', old_audit) == before_audit
            if before_native is not None: proof['allOriginal66NativeSevenTablesExact'] = digests('riftbound_here_native', old_native) == before_native
            proof['actualAuditRoomsAtStop'] = rooms('riftbound_acceptance'); proof['actualNativeRoomsAtStop'] = rooms('riftbound_here_native')
        finally:
            proof['ownPostgresNormalStopExitCode'] = subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-m', 'fast', '-w', 'stop'], capture_output=True).returncode
            proof['ownPostgresStopped'] = subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), 'status'], capture_output=True).returncode == 3
    if power:
        if power.poll() is None: power.terminate()
        power.wait(timeout=10)
    proof.update(finishedAtUtc=now(), lockAtStop=observe_lock(), allFrozenSourceAndRuntimeInputsStable=stable())
    terminal.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
print(proof['status'], flush=True)
