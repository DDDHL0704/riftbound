from pathlib import Path
import datetime, hashlib, json, os, subprocess

root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=load(root/'var/qa/special-trigger-damage-current-cn16-20261021/current-special-trigger-frozen-runtime-inputs-v1.json');previous=Path(old['runtimeRoot'])
assert all(sha(previous/p)==h for p,h in old['runtimeFiles'].items())
paths=set(old['sourceInputHashes'])|{'src/Riftbound.Engine/MatchSession.RoomSeats.cs','src/Riftbound.Engine/RoomSeatRecoveryValidator.cs','tests/Riftbound.ConformanceTests/RoomSeatJournalTests.cs','tests/Riftbound.PostgresAcceptance/RoomSeatJournalSqlAcceptance.cs'}
inputs={p:sha(root/p) for p in sorted(paths)};modes={p:oct((root/p).stat().st_mode&0o777) for p in sorted(paths)}
pre=load(w/'pre-change-current-be0e-room-input-source-retention-v1.json');changed=[p for p,h in pre['allOriginalConformanceInputs'].items() if sha(root/p)!=h]
assert changed==['tests/Riftbound.ConformanceTests/OpeningRandomizationTests.cs']
full={p:h for p,h in pre['allOriginalConformanceInputs'].items() if Path(p).name.startswith('FullGameEndToEndTests')};assert len(full)==9 and all(sha(root/p)==h for p,h in full.items())
sqlroot=root/'tests/Riftbound.PostgresAcceptance/bin/Debug/net10.0';testroot=root/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0'
runtime=w/'current-room-seat-runtime-v1';runtime.mkdir(exist_ok=False);links=[];physical=[]
for name,oldhash in old['runtimeFiles'].items():
    if name.startswith('CurrentSpecialTriggerIndependentReaderV1.'):continue
    source=sqlroot/name if (sqlroot/name).is_file() else testroot/name if (testroot/name).is_file() else previous/name
    target=runtime/name;target.parent.mkdir(parents=True,exist_ok=True)
    if target.name.endswith(('.deps.json','.runtimeconfig.json')) or sha(source)!=oldhash:
        subprocess.run(['/bin/cp','-c',str(source),str(target)],check=True);physical.append(name);assert not target.is_symlink()
    else:
        assert sha(previous/name)==sha(source);target.symlink_to(previous/name);links.append(name)
    assert sha(target)==sha(source)
source=w/'independent-reader-source-v1';assembly='CurrentRoomSeatIndependentReaderV1'
refs=['Riftbound.Contracts','Riftbound.Engine','Riftbound.CardCatalog','Riftbound.Persistence','Npgsql']
project='<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFramework>net10.0</TargetFramework><OutputType>Exe</OutputType><AssemblyName>'+assembly+'</AssemblyName><ImplicitUsings>enable</ImplicitUsings><Nullable>enable</Nullable><UseAppHost>false</UseAppHost></PropertyGroup><ItemGroup>'+''.join('<Reference Include="'+r+'"><HintPath>'+str(runtime/(r+'.dll'))+'</HintPath><Private>false</Private></Reference>' for r in refs)+'</ItemGroup></Project>'
(source/'probe.csproj').write_text(project)
with (w/'build-current-room-seat-independent-reader-v1.log').open('xb') as log:
    result=subprocess.run(['/Users/dinghaolin/.dotnet/dotnet','build',str(source/'probe.csproj'),'-c','Release','--nologo'],cwd=source,stdout=log,stderr=subprocess.STDOUT)
assert result.returncode==0,'Independent reader compile failed before any new SQL run; original log and sources retained.'
for suffix in ['.dll','.pdb']:
    a=source/'bin/Release/net10.0'/(assembly+suffix);b=runtime/a.name;subprocess.run(['/bin/cp','-c',str(a),str(b)],check=True);physical.append(a.name)
files={str(p.relative_to(runtime)):sha(p) for p in runtime.rglob('*') if p.is_file()}
command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(runtime/'Riftbound.PostgresAcceptance.deps.json'),'--runtimeconfig',str(runtime/'Riftbound.PostgresAcceptance.runtimeconfig.json'),str(runtime/(assembly+'.dll')),'--identity']
actual=json.loads(subprocess.check_output(command,cwd=runtime,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0')))
assert Path(actual['baseDirectory']).resolve()==runtime.resolve() and actual['hasRoomSeatReplay'] and actual['hasIndependentSeatGuard'] and actual['hasNewSqlCase']
assert actual['actualRuleInputs']['authoritySha256']=='70ccda5893a1b8b56cdceadee35e084b1e3f5b297ef64e1ce7d0cbeb141ce2d4'
assert actual['actualRuleInputs']['catalogSha256']=='e7455edc32d43f8253a9d0c6fedb83c347bebafbef064f9b8dffaaabc4b4d266'
assert actual['actualRuleInputs']['identitySha256']!=old['actualRuleInputs']['identitySha256']
for a in actual['assemblies']:
    assert Path(a['path']).resolve()==(runtime/(a['name']+'.dll')).resolve() and a['sha256']==files[a['name']+'.dll']
assert all(sha(root/p)==h for p,h in inputs.items())
manifest={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parentCommit':'be0e7a88d86e191d87404488a8ecc4777411dfb7','uncommittedBoundedRoomSeatBatch':True,'runtimeRoot':str(runtime),'runtimeFiles':files,'sourceInputHashes':inputs,'sourceInputModes':modes,'actualRuleInputs':actual['actualRuleInputs'],'actualBaseLoadedAssemblyShaAndMvid':actual,'allControlMetadataPhysicalIndependent':True,'unchangedImmutableLinks':links,'independentApfsCopies':physical,'allOriginalConformanceSourcesUnchangedExceptOneExactSeedFixtureInputCalibration':changed,'allNineFullGameSourcesByteExact':full,'all143PublicFullMethods110Pairs11Decks424242AndAssertionsRetained':True,'allOriginal56SqlIdentitiesOrderAndClassSourcesRetainedOnly57Appended':True}
with (w/'current-room-seat-frozen-runtime-inputs-v1.json').open('x') as stream:json.dump(manifest,stream,indent=2)
print('FROZEN current room seats',len(files),'runtime files',len(inputs),'source inputs; actual base/SHA/MVID and physical metadata PASS',actual['actualRuleInputs']['identitySha256'],flush=True)
