from pathlib import Path
import datetime, difflib, gzip, hashlib, json, sys

root = Path('/Users/dinghaolin/MyProjects/riftbound'); w = Path(__file__).resolve().parent
frozen = json.loads((w / 'current-room-seat-frozen-runtime-inputs-v1.json').read_text())
sha = lambda b: hashlib.sha256(b).hexdigest()
original, changed = {}, {}
def edit(path, before, after, count=1):
    if path not in changed:
        original[path] = (root / path).read_text(); changed[path] = original[path]
        assert sha((root / path).read_bytes()) == frozen['sourceInputHashes'][path], path
    assert changed[path].count(before) == count, (path, before[:100], changed[path].count(before))
    changed[path] = changed[path].replace(before, after)

p = 'src/Riftbound.Engine/MatchPlayers.cs'
edit(p, '    ValueTask<bool> HasReconnectTokenHashAsync(', '''    ValueTask CommitRoomSeatAsync(MatchJournalEntry entry, string reconnectTokenHash,
        IMatchJournal journal, CancellationToken cancellationToken);

    ValueTask<bool> HasReconnectTokenHashAsync(''')
edit(p, '    public ValueTask SavePlayerSessionAsync(', '''    public ValueTask CommitRoomSeatAsync(MatchJournalEntry entry, string reconnectTokenHash,
        IMatchJournal journal, CancellationToken cancellationToken)
        => journal.RecordAsync(entry, cancellationToken);

    public ValueTask SavePlayerSessionAsync(''')
p = 'src/Riftbound.Engine/MatchJournal.cs'
edit(p, 'public sealed class NoopMatchJournal : IMatchJournal', '''// Durable player credentials and the original room input must commit together.
public interface IMatchRoomSeatJournal : IMatchJournal
{
    ValueTask RecordRoomSeatAsync(MatchJournalEntry entry, string reconnectTokenHash,
        CancellationToken cancellationToken);
}

public sealed class NoopMatchJournal : IMatchJournal''')
p = 'src/Riftbound.Engine/MatchSession.RoomSeats.cs'
edit(p, '''            await PersistPlayerSessionAsync(player, cancellationToken).ConfigureAwait(false);
            if (nextState is null) return (player, null);''', '''            if (nextState is null)
            {
                await PersistPlayerSessionAsync(player, cancellationToken).ConfigureAwait(false);
                return (player, null);
            }''')
edit(p, '''            await journal.RecordAsync(new MatchJournalEntry(RoomId, player.PlayerId, intentId, RoomSeatCommandType, raw,
                state.Tick, nextState.Tick, lastEventSequence, lastEventSequence + 1, true, null,
                nextState, events, result.Snapshots, result.Prompts, DateTimeOffset.UtcNow) { OpeningSeed = openingSeed }, cancellationToken).ConfigureAwait(false);''', '''            var entry = new MatchJournalEntry(RoomId, player.PlayerId, intentId, RoomSeatCommandType, raw,
                state.Tick, nextState.Tick, lastEventSequence, lastEventSequence + 1, true, null,
                nextState, events, result.Snapshots, result.Prompts, DateTimeOffset.UtcNow) { OpeningSeed = openingSeed };
            await playerStore.CommitRoomSeatAsync(entry, ReconnectTokenHasher.Hash(player.ReconnectToken),
                journal, cancellationToken).ConfigureAwait(false);''')
p = 'src/Riftbound.Persistence/PostgresMatchPlayerStore.cs'
text = (root / p).read_text()
begin = text.index('        await AcquireMatchPlayerSeatLockAsync(')
end = text.index('        await transaction.CommitAsync(cancellationToken).ConfigureAwait(false);', begin)
body = text[begin:end].rstrip()
edit(p, text[begin:end], '''        await SavePlayerSessionInTransactionAsync(connection, transaction, roomId, playerId, seat,
            reconnectTokenHash, cancellationToken, openingSeed).ConfigureAwait(false);

''')
edit(p, '    public async ValueTask<bool> HasReconnectTokenHashAsync(', '''    public ValueTask CommitRoomSeatAsync(MatchJournalEntry entry, string reconnectTokenHash,
        IMatchJournal journal, CancellationToken cancellationToken)
    {
        if (journal is not IMatchRoomSeatJournal atomic)
            throw new MatchSessionException(ErrorCodes.RecoveryInconsistent,
                "durable room seats require an atomic player-session and journal commit");
        return atomic.RecordRoomSeatAsync(entry, reconnectTokenHash, cancellationToken);
    }

    internal static async Task SavePlayerSessionInTransactionAsync(NpgsqlConnection connection,
        NpgsqlTransaction transaction, string roomId, string playerId, string seat,
        string reconnectTokenHash, CancellationToken cancellationToken, long openingSeed)
    {
''' + body + '''
    }

    public async ValueTask<bool> HasReconnectTokenHashAsync(''')
p = 'src/Riftbound.Persistence/PostgresMatchJournal.cs'
edit(p, ': IMatchJournal\n', ': IMatchRoomSeatJournal\n')
text = changed[p]
begin = text.index('        await UpsertMatchAsync(connection, transaction, entry, cancellationToken)')
end = text.index('        await transaction.CommitAsync(cancellationToken).ConfigureAwait(false);', begin)
body = text[begin:end].rstrip()
edit(p, text[begin:end], '''        await RecordInTransactionAsync(connection, transaction, entry, cancellationToken).ConfigureAwait(false);

''')
edit(p, '    private static async Task UpsertMatchAsync(', '''    public async ValueTask RecordRoomSeatAsync(MatchJournalEntry entry, string reconnectTokenHash,
        CancellationToken cancellationToken)
    {
        entry.ValidateRuleInputs();
        if (entry.CommandType != MatchSession.RoomSeatCommandType || !entry.Accepted || entry.ErrorMessage is not null
            || !entry.AuthoritativeState.Seats.TryGetValue(entry.PlayerId, out var seat) || seat is not ("P1" or "P2"))
            throw new MatchSessionException(ErrorCodes.RecoveryInconsistent, "invalid original room seat commit");
        await using var connection = await dataSource.OpenConnectionAsync(cancellationToken).ConfigureAwait(false);
        await using var transaction = await connection.BeginTransactionAsync(cancellationToken).ConfigureAwait(false);
        await PostgresMatchPlayerStore.SavePlayerSessionInTransactionAsync(connection, transaction,
            entry.RoomId, entry.PlayerId, seat, reconnectTokenHash, cancellationToken, entry.OpeningSeed).ConfigureAwait(false);
        await RecordInTransactionAsync(connection, transaction, entry, cancellationToken).ConfigureAwait(false);
        await transaction.CommitAsync(cancellationToken).ConfigureAwait(false);
    }

    private static async Task RecordInTransactionAsync(NpgsqlConnection connection, NpgsqlTransaction transaction,
        MatchJournalEntry entry, CancellationToken cancellationToken)
    {
''' + body + '''
    }

    private static async Task UpsertMatchAsync(''')

# These are the only three test player-store implementations. Their original
# save/read behavior and every original test method/assertion stay intact.
for p in ['tests/Riftbound.ConformanceTests/GameHubJoinTests.cs',
          'tests/Riftbound.ConformanceTests/OpeningRandomizationTests.cs',
          'tests/Riftbound.ConformanceTests/MatchRecoveryTests.cs']:
    edit(p, '        public ValueTask<bool> HasReconnectTokenHashAsync(', '''        public async ValueTask CommitRoomSeatAsync(MatchJournalEntry entry, string reconnectTokenHash,
            IMatchJournal journal, CancellationToken cancellationToken)
        {
            await SavePlayerSessionAsync(entry.RoomId, entry.PlayerId, entry.AuthoritativeState.Seats[entry.PlayerId],
                reconnectTokenHash, cancellationToken, entry.OpeningSeed);
            await journal.RecordAsync(entry, cancellationToken);
        }

        public ValueTask<bool> HasReconnectTokenHashAsync(''')

p = 'tests/Riftbound.ConformanceTests/GameHubJoinTests.cs'
edit(p, 'Assert.Single(journal.Entries);', 'SingleClientEntryAfterRoomSeats(journal);', count=5)
edit(p, '        Assert.Equal(1, acceptedJournalCount);', '        Assert.Equal(3, acceptedJournalCount);')
edit(p, '''        var replayInitialState = MatchReplayInitialStateBuilder.FromSeats(
            roomId,
            new Dictionary<string, string>(StringComparer.Ordinal)
            {
                ["P1"] = "P1",
                ["P2"] = "P2"
            });''', '''        var replayInitialState = MatchState.Create(roomId);''')
edit(p, '    private sealed record OfficialOpeningState(', '''    private static MatchJournalEntry SingleClientEntryAfterRoomSeats(RecordingMatchJournal journal)
    {
        Assert.Equal(3, journal.Entries.Count);
        for (var index = 0; index < 2; index++)
        {
            var seat = index == 0 ? "P1" : "P2";
            var entry = journal.Entries[index];
            Assert.Equal("ROOM_SEAT", entry.CommandType);
            Assert.Equal("room-seat:" + seat, entry.ClientIntentId);
            Assert.True(entry.Accepted); Assert.Null(entry.ErrorMessage);
            Assert.Equal(index + 1, entry.CompletedTick);
            Assert.Equal(index + 1, entry.CompletedEventSequence);
            Assert.Equal(index + 1, entry.AuthoritativeState.Seats.Count);
            Assert.Equal(seat, entry.AuthoritativeState.Seats[entry.PlayerId]);
            var raw = Assert.IsType<JsonElement>(entry.RawCommand);
            Assert.Equal(3, raw.EnumerateObject().Count());
            Assert.Equal("ROOM_SEAT", raw.GetProperty("cmdType").GetString());
            Assert.Equal(entry.PlayerId, raw.GetProperty("playerId").GetString());
            Assert.Equal(seat, raw.GetProperty("seat").GetString());
            var seated = Assert.Single(entry.Events);
            Assert.Equal("PLAYER_SEATED", seated.Kind); Assert.Equal(2, seated.Payload.Count);
            Assert.Equal(entry.PlayerId, Assert.IsType<string>(seated.Payload["playerId"]));
            Assert.Equal(seat, Assert.IsType<string>(seated.Payload["seat"]));
        }
        return Assert.Single(journal.Entries.Skip(2));
    }

    private sealed record OfficialOpeningState(''')

p = 'tests/Riftbound.PostgresAcceptance/OpeningRandomnessSqlAcceptance.cs'
edit(p, '''        Check(waiting.IsConsistent && waiting.Commands.Count == 0 && waiting.CurrentTick == 0,
            "Fresh production room must persist before its first command.");''', '''        Check(waiting.IsConsistent && waiting.Commands.Count == 2 && waiting.CurrentTick == 2
            && waiting.Commands.All(c => c.Accepted && c.CommandType == "ROOM_SEAT")
            && waiting.Commands.Select(c => c.PlayerId).SequenceEqual(new[] { "alice", "bob" })
            && waiting.Commands.Select(c => c.CompletedTick).SequenceEqual(new long[] { 1, 2 }),
            "Fresh production room must persist both original server registrations before client commands.");
        const int originalServerRegistrations = 2;
        Check(waiting.ReplayInitialState is { Status: MatchStatuses.Empty, Seats.Count: 0, CardObjects.Count: 0 },
            "Both original room inputs must replay from the actual empty room.");''')
edit(p, 'frame.Commands.Count == submitted && MatchStateHasher.Hash', 'frame.Commands.Count == originalServerRegistrations + submitted && MatchStateHasher.Hash')
edit(p, '''            if (submitted > 0)
            {''', '''            if (originalServerRegistrations + submitted > 0)
            {''')
edit(p, '            room, submitted, events = final.Events.Count, originalTick = initial.Tick,',
        '            room, submitted, originalServerRegistrations, allJournalCommands = final.Commands.Count, events = final.Events.Count, originalTick = initial.Tick,')

p = 'tests/Riftbound.PostgresAcceptance/RoomSeatJournalSqlAcceptance.cs'
edit(p, 'private sealed class CapturingJournal(IMatchJournal inner, string folder) : IMatchJournal',
        'private sealed class CapturingJournal(IMatchJournal inner, string folder) : IMatchRoomSeatJournal')
edit(p, '''            var name = Path.Combine(folder, $"entry-{Entries.Count + 1:D2}-original-input-before-persist.json.gz");''', '''            await CaptureOriginal(entry, cancellationToken);
            await inner.RecordAsync(entry, cancellationToken);
            Entries.Add(entry);
        }
        public async ValueTask RecordRoomSeatAsync(MatchJournalEntry entry, string reconnectTokenHash,
            CancellationToken cancellationToken)
        {
            await CaptureOriginal(entry, cancellationToken);
            await ((IMatchRoomSeatJournal)inner).RecordRoomSeatAsync(entry, reconnectTokenHash, cancellationToken);
            Entries.Add(entry);
        }
        private async Task CaptureOriginal(MatchJournalEntry entry, CancellationToken cancellationToken)
        {
            var name = Path.Combine(folder, $"entry-{Entries.Count + 1:D2}-original-input-before-persist.json.gz");''')
edit(p, '''            await inner.RecordAsync(entry, cancellationToken);
            Entries.Add(entry);
        }
    }
}''', '''        }
    }
}''')

mode = sys.argv[1:] or ['--plan']
assert mode in [['--plan'], ['--apply']]
if mode == ['--plan']:
    target = w / 'finite-room-seat-atomicity-and-original-fixture-plan-v1.diff'; assert not target.exists()
    target.write_text(''.join(''.join(difflib.unified_diff(original[p].splitlines(True), changed[p].splitlines(True),
        fromfile='a/' + p, tofile='b/' + p)) for p in changed))
    proof = {'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': 'PROPOSED_ONLY_ROOT_CHECK_INPUTS_UNCHANGED',
             'actualWipCounterexample': 'failed-first-seat-real-sql-counterexample-owner-terminal-v1.json',
             'sourceHashesBefore': {p: sha(original[p].encode()) for p in changed},
             'sourceHashesProposed': {p: sha(changed[p].encode()) for p in changed},
             'onlyFiniteRoomSeatStoreAndJournalOperation': True, 'allOriginalPublicTestsAndAssertionsRetained': True,
             'oneOriginalWholeJournalCountChanges1To3AndNewTwoServerInputGuardsAdded': True,
             'actualSqlFaultInjectionAndFinalFocusStillRequired': True, 'rootSourceOrBinMutated': False}
    (w / 'finite-room-seat-atomicity-and-original-fixture-plan-v1.json').write_text(json.dumps(proof, indent=2))
    print('Plan only:', len(changed), 'source files; no root input changed. Actual SQL atomic rollback tests still required.')
else:
    terminal = json.loads((w / 'only-check-owner-terminal-v1.json').read_text())
    retention = json.loads((w / 'first-only-check-original-case-method-and-input-retention-v1.json').read_text())
    assert terminal['all3336SourceHashesAndModesStable'] and retention['actualCases'] == 13369
    assert retention['outcomes'].get('Failed') == 6 and len(retention['actualFailedOrNonPassed']) == 6
    plan = json.loads((w / 'finite-room-seat-atomicity-and-original-fixture-plan-v1.json').read_text())
    assert plan['sourceHashesProposed'] == {p: sha(changed[p].encode()) for p in changed}
    originals = w / 'original-only-check-inputs-before-atomicity-v1'; originals.mkdir(exist_ok=False)
    for p in changed:
        target = originals / (p.replace('/', '__') + '.gz')
        target.write_bytes(gzip.compress(original[p].encode(), mtime=0))
        (root / p).write_text(changed[p])
    (w / 'finite-room-seat-atomicity-applied-after-sole-check-v1.json').write_text(json.dumps({
        'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'originalOnlyCheckRetainedAndNotRelabelled': True,
        'sourceHashesBefore': plan['sourceHashesBefore'], 'sourceHashesAfter': plan['sourceHashesProposed'],
        'noSecondCheck': True, 'newFixedFullAndTargetedAndRealSqlValidationStillRequired': True}, indent=2))
    print('Applied finite atomic room-seat operation and exact original fixture calibrations after sole check terminal.')
