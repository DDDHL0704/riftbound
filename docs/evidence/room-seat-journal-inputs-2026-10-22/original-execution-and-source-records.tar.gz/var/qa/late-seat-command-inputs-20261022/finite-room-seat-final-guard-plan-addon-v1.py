p = 'src/Riftbound.Persistence/PostgresMatchRecoveryStore.cs'
old = '''        // Seats can be saved before a new waiting room's first command. Use
        // its explicitly recorded identity, never invent inputs for old games
        // or replace a damaged authoritative payload.
        if (authoritativeState is null && !invalidStatePayload && commands.Count == 0
            && metadata.CurrentTick == 0 && metadata.LastEventSequence == 0
            && RuleInputIdentity.IsCurrent(metadata.RuleInputs) && openingSeed is not null)
            authoritativeState = (await LoadReplayInitialStateAsync(connection, roomId, openingSeed.Value, cancellationToken).ConfigureAwait(false))
                with { RuleInputs = metadata.RuleInputs };
'''
edit(p, old, '''        // Every production seat is now an original atomic journal input.
        // Metadata alone cannot manufacture a seat or migrate a development room.
''')
edit(p, '        var invalidStatePayload = false;\n', '')
edit(p, '            invalidStatePayload = true;\n', '')
p = 'tests/Riftbound.PostgresAcceptance/OpeningRandomnessSqlAcceptance.cs'
edit(p, 'privateSeedRecordedBeforeFirstCommand = true,',
        'privateSeedRecordedWithFirstServerRegistration = true, privateSeedRecordedBeforeFirstClientCommand = true,')
p = 'tests/Riftbound.PostgresAcceptance/RoomSeatJournalSqlAcceptance.cs'
edit(p, '        await RejectNonAtomicDurableJournal();', '        await RejectNonAtomicDurableJournal();\n        await RejectMetadataOnlyCurrentRoom();')
snippet = (w / 'proposed-metadata-only-seat-refusal-v1.cs').read_text()
edit(p, '        async Task Run(bool reverse, bool late)', snippet + '\n        async Task Run(bool reverse, bool late)')
