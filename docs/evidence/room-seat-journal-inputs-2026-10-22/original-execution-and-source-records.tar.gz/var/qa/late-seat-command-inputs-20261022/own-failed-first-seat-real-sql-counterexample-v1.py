from pathlib import Path
import ast, datetime, fcntl, hashlib, json, os, plistlib, resource, subprocess

resource.setrlimit(resource.RLIMIT_CORE, (0, 0)); os.umask(0o077)
root = Path('/Users/dinghaolin/MyProjects/riftbound'); w = Path(__file__).resolve().parent
pg = Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin')
cluster = root / 'var/qa/permanent-play-here-base-20261017/postgres'; sock = Path('/tmp/rft-here-family-20261018-55486')
tables = ['matches', 'match_players', 'command_log', 'game_events', 'state_snapshots', 'snapshots', 'action_prompts']
read_env = dict(os.environ, PGOPTIONS='-c default_transaction_read_only=on')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
definition = root / 'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes = [n for n in ast.parse(definition.read_text()).body if isinstance(n, ast.FunctionDef) and n.name in {'query', 'rooms', 'digests', 'observe_lock'}]
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(definition), 'exec'), globals())
f = load(w / 'room-seat-failed-journal-probe-frozen-inputs-v1.json'); runtime = Path(f['runtimeRoot'])
root_inputs = load(w / 'current-room-seat-frozen-runtime-inputs-v1.json')
prior = load(w / 'original-opening-sql-two-server-input-counterexample-owner-terminal-v1.json')
old_audit, old_native = prior['actualAuditRoomsAtStop'], prior['actualNativeRoomsAtStop']
assert len(old_audit) == 322 and len(old_native) == 66 and prior['ownPostgresStopped']
stable = lambda: all(sha(runtime / p) == h for p, h in f['runtimeFiles'].items()) and all(sha(root / p) == h for p, h in root_inputs['sourceInputHashes'].items())
guard = (root / 'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a'); fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
terminal = w / 'failed-first-seat-real-sql-counterexample-owner-terminal-v1.json'; assert not terminal.exists()
proof = {'startedAtUtc': now(), 'status': 'RUNNING_CONTROLLED_FIRST_ROOM_SEAT_JOURNAL_FAILURE_REAL_PLAYER_STORE_COLD_REPLAY_PROBE',
         'actualRuleInputs': f['actualIdentityAndLoadedAssemblies']['actualRuleInputs'], 'lockAtStart': observe_lock(),
         'unreleasedRoomSeatWipNotParentBe0e': True, 'noRootSourceOrBinMutation': True}
started = False; power = writer = None; before_audit = before_native = None
try:
    assert stable() and subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), 'status'], capture_output=True).returncode == 3
    power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())]); sock.mkdir(exist_ok=True)
    subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-l', str(w / 'failed-first-seat-real-sql-counterexample-postgres-v1.log'),
                    '-o', f'-p 55486 -h 127.0.0.1 -k {sock}', '-w', 'start'], capture_output=True, check=True); started = True
    assert rooms('riftbound_acceptance') == old_audit and rooms('riftbound_here_native') == old_native
    before_audit = digests('riftbound_acceptance', old_audit); before_native = digests('riftbound_here_native', old_native)
    output = w / 'failed-first-seat-real-sql-counterexample-v1'; assert not output.exists()
    env = dict(os.environ, ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit', DOTNET_DbgEnableMiniDump='0')
    command = ['/Users/dinghaolin/.dotnet/dotnet', 'exec', '--depsfile', str(runtime / 'Riftbound.PostgresAcceptance.deps.json'),
               '--runtimeconfig', str(runtime / 'Riftbound.PostgresAcceptance.runtimeconfig.json'), str(runtime / f['executable']), str(output)]
    proof['actualCommand'] = command
    with (w / 'failed-first-seat-real-sql-counterexample-v1.log').open('xb') as log:
        writer = subprocess.Popen(command, cwd=runtime, env=env, stdout=log, stderr=subprocess.STDOUT); proof['probeExitCode'] = writer.wait(timeout=120)
    receipt = load(output / 'receipt.json'); proof['actualOriginalReceipt'] = receipt
    assert proof['probeExitCode'] == 0 and receipt['status'] == 'CONFIRMED_CURRENT_WIP_NONATOMIC_FIRST_SEAT_GHOST_AND_UNREPLAYABLE_SECOND_JOIN'
    assert receipt['actualRuleInputs'] == proof['actualRuleInputs']
    assert set(rooms('riftbound_acceptance')) == set(old_audit) | {receipt['room']} and rooms('riftbound_here_native') == old_native
    proof['status'] = receipt['status']; proof['newRoom'] = receipt['room']
except BaseException as e:
    proof.update(status='FAILED_OR_UNEXPECTED_ORIGINAL_PROBE_OUTPUT_RETAINED', errorType=type(e).__name__, error=str(e)); raise
finally:
    if writer and writer.poll() is None: writer.terminate(); writer.wait(timeout=20)
    if started:
        try:
            if before_audit is not None: proof['allOriginal322AuditSevenTablesExact'] = digests('riftbound_acceptance', old_audit) == before_audit
            if before_native is not None: proof['allOriginal66NativeSevenTablesExact'] = digests('riftbound_here_native', old_native) == before_native
            proof['actualAuditRoomsAtStop'] = rooms('riftbound_acceptance'); proof['actualNativeRoomsAtStop'] = rooms('riftbound_here_native')
        finally:
            proof['ownPostgresNormalStopExitCode'] = subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-m', 'fast', '-w', 'stop'], capture_output=True).returncode
            proof['ownPostgresStopped'] = subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), 'status'], capture_output=True).returncode == 3
    if power:
        if power.poll() is None: power.terminate()
        power.wait(timeout=10)
    proof.update(finishedAtUtc=now(), lockAtStop=observe_lock(), allFrozenSourceAndRuntimeInputsStable=stable())
    terminal.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
print(proof['status'], flush=True)
