from pathlib import Path
import ast, datetime, fcntl, hashlib, json, os, plistlib, resource, socket, subprocess

resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts']
read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
definition=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes=[n for n in ast.parse(definition.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}]
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(definition),'exec'),globals())
frozen=load(w/'current-be0e-late-seat-probe-frozen-v1.json');runtime=Path(frozen['runtimeRoot'])
source=load(w/'pre-change-current-be0e-room-input-source-retention-v1.json')
old=load(root/'var/qa/fixed7a-early-native-20261021/visible-current-api-owner-terminal-v1.json')
old_audit=old['actualAuditRoomsAtStop'];old_native=old['actualNativeRoomsAtStop'];assert len(old_audit)==316 and len(old_native)==66
stable=lambda:all(sha(runtime/p)==h for p,h in frozen['runtimeFiles'].items()) and all(sha(root/p)==h for p,h in source['currentAll3332GameplaySourceHashes'].items())
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
terminal=w/'actual-current-be0e-late-seat-probe-owner-terminal-v1.json';assert not terminal.exists()
proof={'startedAtUtc':now(),'status':'RUNNING_CURRENT_BE0E_LATE_SEAT_REAL_SQL_SOURCE_PROBE','fixedSourceCommit':frozen['fixedSourceCommit'],'lockAtStart':observe_lock(),'expectedRuleInputs':frozen['expectedRuleInputs'],'allOriginalGamesAndSeedsRetained':True}
started=False;power=child=None;before_audit=before_native=None
try:
    assert stable();assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
    with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
    power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);sock.mkdir(exist_ok=True)
    subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'current-be0e-probe-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
    assert rooms('riftbound_acceptance')==old_audit and rooms('riftbound_here_native')==old_native
    before_audit=digests('riftbound_acceptance',old_audit);before_native=digests('riftbound_here_native',old_native)
    (w/'original316-audit66-native-seven-table-baseline-v1.json').write_text(json.dumps({'atUtc':now(),'auditRooms':old_audit,'nativeRooms':old_native,'auditSevenTables':before_audit,'nativeSevenTables':before_native},indent=2))
    output=w/'actual-current-be0e-late-seat-probe-v1';assert not output.exists()
    command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(runtime/'Riftbound.PostgresAcceptance.deps.json'),'--runtimeconfig',str(runtime/'Riftbound.PostgresAcceptance.runtimeconfig.json'),str(runtime/'CurrentBe0eLateSeatProbeV1.dll'),str(output)]
    proof['actualCommand']=command
    env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit',DOTNET_DbgEnableMiniDump='0')
    with (w/'current-be0e-late-seat-probe-v1.log').open('xb') as log:
        child=subprocess.Popen(command,cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT);proof['probeExitCode']=child.wait(timeout=150)
    assert proof['probeExitCode']==0
    result=load(output/'result.json');assert result['status']=='CONFIRMED_CURRENT_BE0E_FIRST_DECK_HISTORY_AND_TRAILING_JOIN_COLD_REPLAY_GAPS'
    assert result['actualRuleInputs']==frozen['expectedRuleInputs'] and Path(result['actualBaseDirectory']).resolve()==runtime.resolve()
    for a in result['actualAssemblies']:
        assert Path(a['path']).resolve()==(runtime/(a['name']+'.dll')).resolve() and a['sha256']==frozen['runtimeFiles'][a['name']+'.dll']
    assert result['originalCommands']==2 and result['originalEvents']==2 and result['finalOnlyRecoveryErrors']==[]
    assert set(rooms('riftbound_acceptance'))==set(old_audit)|{result['room']} and rooms('riftbound_here_native')==old_native
    proof.update(status='CONFIRMED_CURRENT_BE0E_TWO_ORIGINAL_COMMANDS_FIRST_HISTORY_AND_TRAILING_JOIN_RECOVERY_GAPS',actualProbeResult=result,newRoom=result['room'])
    print(proof['status'],flush=True)
except BaseException as error:
    proof.update(status='FAILED_CURRENT_BE0E_PROBE_OR_READBACK_ALL_ORIGINAL_ACTIONS_RETAINED',errorType=type(error).__name__,error=str(error));raise
finally:
    if child and child.poll() is None:child.terminate();child.wait(timeout=20)
    if started:
        try:
            if before_audit is not None:proof['allOriginal316AuditSevenTablesExactAtStop']=digests('riftbound_acceptance',old_audit)==before_audit
            if before_native is not None:proof['allOriginal66NativeSevenTablesExactAtStop']=digests('riftbound_here_native',old_native)==before_native
            proof['actualAuditRoomsAtStop']=rooms('riftbound_acceptance');proof['actualNativeRoomsAtStop']=rooms('riftbound_here_native')
        finally:
            stop=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','fast','-w','stop'],capture_output=True);proof['ownPostgresNormalStopExitCode']=stop.returncode;proof['ownPostgresStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
    if power:
        if power.poll() is None:power.terminate()
        power.wait(timeout=10)
    proof.update(finishedAtUtc=now(),lockAtStop=observe_lock(),allFrozenAndRootSourceInputsStable=stable());terminal.write_text(json.dumps(proof,ensure_ascii=False,indent=2))
