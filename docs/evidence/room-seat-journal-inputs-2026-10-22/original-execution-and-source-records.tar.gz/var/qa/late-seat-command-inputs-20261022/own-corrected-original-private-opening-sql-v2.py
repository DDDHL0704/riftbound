from pathlib import Path
import ast, datetime, fcntl, gzip, hashlib, json, os, plistlib, resource, subprocess

resource.setrlimit(resource.RLIMIT_CORE, (0, 0)); os.umask(0o077)
root = Path('/Users/dinghaolin/MyProjects/riftbound'); w = Path(__file__).resolve().parent
pg = Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin'); cluster = root / 'var/qa/permanent-play-here-base-20261017/postgres'; sock = Path('/tmp/rft-here-family-20261018-55486')
tables = ['matches', 'match_players', 'command_log', 'game_events', 'state_snapshots', 'snapshots', 'action_prompts']
read_env = dict(os.environ, PGOPTIONS='-c default_transaction_read_only=on')
load = lambda p: json.loads(p.read_text()); sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest(); now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
definition = root / 'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes = [n for n in ast.parse(definition.read_text()).body if isinstance(n, ast.FunctionDef) and n.name in {'query', 'rooms', 'digests', 'observe_lock'}]
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(definition), 'exec'), globals())
f = load(w / 'current-private-opening-only-runner-frozen-inputs-v1.json'); runtime = Path(f['runtimeRoot'])
inputs = load(w / 'current-room-seat-frozen-runtime-inputs-v2.json')
prior = load(w / 'actual-current-room-seat-sql-owner-terminal-v2.json'); old_audit, old_native = prior['actualAuditRoomsAtStop'], prior['actualNativeRoomsAtStop']
assert len(old_audit) == 330 and len(old_native) == 66 and prior['ownPostgresStopped']
stable = lambda: all(sha(runtime / p) == h for p, h in f['runtimeFiles'].items()) and all(sha(root / p) == h for p, h in inputs['sourceInputHashes'].items())
guard = (root / 'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a'); fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
terminal = w / 'corrected-original-private-opening-real-sql-owner-terminal-v2.json'; assert not terminal.exists()
proof = {'status': 'RUNNING_ACTUAL_CORRECTED_ORIGINAL_PRIVATE_OPENING_CLASS_ONLY', 'startedAtUtc': now(),
         'actualRuleInputs': inputs['actualRuleInputs'], 'actualFrozenOriginalClassTarget': f['actualIdentityAndLoadedAssembliesAndTargetClass'],
         'lockAtStart': observe_lock(), 'scopeReason': f['scopeReason'],
         'allOriginalSevenClientActionsSevenColdCheckpointsFourSeedTamperCasesAndPrivacyAssertionsRetained': True,
         'notTheSeparateOriginalCausalFixtureOrEntire57CaseSqlSuite': True}
started = False; power = writer = None; before_audit = before_native = None
try:
    assert stable() and subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), 'status'], capture_output=True).returncode == 3
    power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())]); sock.mkdir(exist_ok=True)
    subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-l', str(w / 'corrected-original-private-opening-postgres-v2.log'), '-o', f'-p 55486 -h 127.0.0.1 -k {sock}', '-w', 'start'], capture_output=True, check=True); started = True
    assert rooms('riftbound_acceptance') == old_audit and rooms('riftbound_here_native') == old_native
    before_audit = digests('riftbound_acceptance', old_audit); before_native = digests('riftbound_here_native', old_native)
    (w / 'original330-audit66-native-seven-table-baseline-v2.json').write_text(json.dumps({'atUtc': now(), 'auditRooms': old_audit, 'nativeRooms': old_native, 'auditSevenTables': before_audit, 'nativeSevenTables': before_native}, indent=2))
    output = w / 'corrected-original-private-opening-real-sql-v2'; assert not output.exists()
    env = dict(os.environ, ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit', DOTNET_DbgEnableMiniDump='0')
    command = ['/Users/dinghaolin/.dotnet/dotnet', 'exec', '--depsfile', str(runtime / 'Riftbound.PostgresAcceptance.deps.json'), '--runtimeconfig', str(runtime / 'Riftbound.PostgresAcceptance.runtimeconfig.json'), str(runtime / f['executable']), str(output)]; proof['actualCommand'] = command
    with (w / 'corrected-original-private-opening-real-sql-v2.log').open('xb') as log:
        writer = subprocess.Popen(command, cwd=runtime, env=env, stdout=log, stderr=subprocess.STDOUT); proof['writerExitCode'] = writer.wait(timeout=180)
    assert proof['writerExitCode'] == 0
    receipt = load(output / 'receipt.json')
    assert receipt['status'] == 'REAL_POSTGRES_PRIVATE_OPENING_SEED_COLD_FULL_ORIGINAL_REPLAY_TAMPER_AND_PROJECTION_PASS'
    assert receipt['submitted'] == 7 and receipt['originalServerRegistrations'] == 2 and receipt['allJournalCommands'] == 9 and receipt['originalTick'] == 2 and receipt['originalCards'] == 0
    assert receipt['privateSeedRecordedWithFirstServerRegistration'] and receipt['privateSeedRecordedBeforeFirstClientCommand'] and receipt['allFourOpeningConsumers'] and receipt['ruleInputs'] == inputs['actualRuleInputs']
    assert receipt['tamperRejections'] == ['missing', 'malformed', 'noncanonical', 'wrong-value'] and len(receipt['coldCheckpoints']) == 7 and receipt['originalSeedAndAcceptedHistoryNeverRewritten']
    room = receipt['room']; assert set(rooms('riftbound_acceptance')) == set(old_audit) | {room} and rooms('riftbound_here_native') == old_native
    rows = {t: [json.loads(line) for line in query('riftbound_acceptance', 'select row_to_json(t)::text from ' + t + " t where match_id='" + room.replace("'", "''") + "' order by row_to_json(t)::text").splitlines()] for t in tables}
    commands = sorted(rows['command_log'], key=lambda c: c['id'])
    assert len(commands) == 9 and [c['command_type'] for c in commands[:2]] == ['ROOM_SEAT', 'ROOM_SEAT'] and all(c['accepted'] for c in commands)
    assert sum(c['command_type'] == 'ROOM_SEAT' for c in commands) == 2
    raw = json.dumps(rows, ensure_ascii=False, indent=2).encode(); payload = output / 'all-seven-actual-new-room-original-sql-rows.json.gz'; payload.write_bytes(gzip.compress(raw, mtime=0))
    proof.update(status='PASS_ACTUAL_ORIGINAL_PRIVATE_OPENING_SEVEN_CLIENT_TWO_SERVER_INPUTS_SEVEN_COLD_FOUR_TAMPER_AND_PRIVACY_GUARDS',
                 originalClassReceipt=receipt, newRoom=room, actualJournalCommands=9, actualServerRegistrations=2, actualClientCommands=7,
                 actualEvents=len(rows['game_events']), actualRawTableCounts={t: len(v) for t, v in rows.items()},
                 independentReadOnlyRawSevenTableRows={'path': str(payload.relative_to(root)), 'sha256': sha(payload)},
                 notAClaimOfLivePrePersistenceIndependentExpectedValuesForThisSeparateOriginalPrivateOpeningClass=True)
except BaseException as e:
    proof.update(status='FAILED_ORIGINAL_PRIVATE_OPENING_CLASS_OR_SCOPE_CHECK_ORIGINALS_RETAINED', errorType=type(e).__name__, error=str(e)); raise
finally:
    if writer and writer.poll() is None: writer.terminate(); writer.wait(timeout=20)
    if started:
        try:
            if before_audit is not None: proof['allOriginal330AuditSevenTablesExactAtStop'] = digests('riftbound_acceptance', old_audit) == before_audit
            if before_native is not None: proof['allOriginal66NativeSevenTablesExactAtStop'] = digests('riftbound_here_native', old_native) == before_native
            proof['actualAuditRoomsAtStop'] = rooms('riftbound_acceptance'); proof['actualNativeRoomsAtStop'] = rooms('riftbound_here_native')
        finally:
            proof['ownPostgresNormalStopExitCode'] = subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-m', 'fast', '-w', 'stop'], capture_output=True).returncode
            proof['ownPostgresStopped'] = subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), 'status'], capture_output=True).returncode == 3
    if power:
        if power.poll() is None: power.terminate()
        power.wait(timeout=10)
    proof.update(finishedAtUtc=now(), lockAtStop=observe_lock(), allFrozenSourceAndRuntimeInputsStable=stable()); terminal.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
print(proof['status'], flush=True)
