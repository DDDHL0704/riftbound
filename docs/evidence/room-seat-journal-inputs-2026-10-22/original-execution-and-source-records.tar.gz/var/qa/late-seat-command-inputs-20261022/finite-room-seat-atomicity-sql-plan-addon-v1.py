p = 'tests/Riftbound.PostgresAcceptance/RoomSeatJournalSqlAcceptance.cs'
edit(p, '        foreach (var late in new[] { false, true }) await Run(reverse, late);', '''        foreach (var late in new[] { false, true }) await Run(reverse, late);
        foreach (var atomicFirst in new[] { true, false }) await RunAtomicity(atomicFirst);
        await RejectNonAtomicDurableJournal();''')
snippet = (w / 'proposed-room-seat-atomicity-sql-function-v1.cs').read_text()
edit(p, '        async Task Run(bool reverse, bool late)', snippet + '\n        async Task Run(bool reverse, bool late)')
edit(p, '    private sealed class CapturingJournal(IMatchJournal inner, string folder) : IMatchRoomSeatJournal', '''    private sealed class NonAtomicJournalMustNotRun : IMatchJournal
    {
        public bool Called { get; private set; }
        public ValueTask RecordAsync(MatchJournalEntry entry, CancellationToken cancellationToken)
        {
            Called = true;
            throw new InvalidOperationException("Non-atomic durable journal must be rejected before reaching a write.");
        }
    }

    private sealed class CapturingJournal(IMatchJournal inner, string folder) : IMatchRoomSeatJournal''')
edit(p, '        public List<MatchJournalEntry> Entries { get; } = [];', '''        public List<MatchJournalEntry> Entries { get; } = [];
        public List<MatchJournalEntry> Attempts { get; } = [];''')
line = '                await JsonSerializer.SerializeAsync(gzip, entry, new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true }, cancellationToken);'
edit(p, line, line + '\n            Attempts.Add(entry);')
