        async Task RejectMetadataOnlyCurrentRoom()
        {
            var room = "room-seat-metadata-only-rejected-" + Guid.NewGuid().ToString("N");
            const long seed = 424242;
            var players = new PostgresMatchPlayerStore(source);
            await players.SavePlayerSessionAsync(room, "seat-a", "P1",
                ReconnectTokenHasher.Hash(Guid.NewGuid().ToString("N")), default, seed);
            var before = await Rows();
            var store = new PostgresMatchRecoveryStore(source);
            var frame = await store.LoadAsync(room, default) ?? throw new Exception("Controlled metadata-only room missing.");
            Check(!frame.IsConsistent && frame.AuthoritativeState is null && frame.Commands.Count == 0
                && frame.OpeningSeed == seed && frame.ValidationErrors.Any(e => e.Contains("requires authoritative state", StringComparison.Ordinal)),
                "Matching current identity/seed and player metadata must not invent an unrecorded seat.");
            var rejected = false;
            try { await new InMemoryMatchSessionRegistry(new CoreRuleEngine(), new PostgresMatchJournal(source), store, players).GetOrCreateAsync(room, default); }
            catch (MatchSessionException error) when (error.Code == ErrorCodes.RecoveryInconsistent) { rejected = true; }
            var after = await Rows();
            Check(rejected && before.SequenceEqual(after), "Cold rejection must preserve every original metadata row and must not synthesize accepted history.");
            await File.WriteAllTextAsync(Path.Combine(output, "metadata-only-current-room-rejection.json"), JsonSerializer.Serialize(new {
                room, status = "PASS_CURRENT_IDENTITY_METADATA_WITHOUT_ORIGINAL_ROOM_JOURNAL_REJECTED_NOT_MIGRATED",
                originalSeed = seed, actualRuleInputs = RuleInputIdentity.Current, validationErrors = frame.ValidationErrors,
                coldErrorCode = ErrorCodes.RecoveryInconsistent, originalSqlRowsBefore = before, originalSqlRowsAfter = after,
                originalMetadataRowsRetained = true, acceptedHistoryOrOldGameRewritten = false }));

            async Task<string[]> Rows()
            {
                var rows = new List<string>();
                await using var connection = await source.OpenConnectionAsync();
                await using var transaction = await connection.BeginTransactionAsync();
                await new NpgsqlCommand("set transaction read only", connection, transaction).ExecuteNonQueryAsync();
                foreach (var table in new[] { "matches", "match_players", "command_log", "game_events", "state_snapshots", "snapshots", "action_prompts" })
                {
                    await using var q = new NpgsqlCommand($"select row_to_json(t)::text from {table} t where match_id=@room order by row_to_json(t)::text", connection, transaction);
                    q.Parameters.AddWithValue("room", room);
                    await using var reader = await q.ExecuteReaderAsync();
                    while (await reader.ReadAsync()) rows.Add(table + ":" + reader.GetString(0));
                }
                await transaction.CommitAsync(); return rows.ToArray();
            }
        }
