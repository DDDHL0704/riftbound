from pathlib import Path
import collections, datetime, gzip, hashlib, json, re, subprocess, types, xml.etree.ElementTree as ET, zipfile

w = Path(__file__).resolve().parent
root = Path('/Users/dinghaolin/MyProjects/riftbound')
fixed = '7a334e7c1cab701d9506b6cf94f3f3a86d316ef8'
run_id = 39615500598
load = lambda p: json.loads(p.read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
downloads = load(w / 'ci7a-all-nine-original-artifacts-receipt-v1.json')
assert downloads['fixedCommit'] == fixed and downloads['runId'] == run_id
assert len(downloads['jobs']) == 11 and all(s == 'success' for s in downloads['jobs'].values())
artifacts = {a['name']: a for a in downloads['artifacts']}
assert len(artifacts) == 9
for a in artifacts.values():
    data = Path(a['path']).read_bytes()
    assert sha(data) == a['sha256'] and len(data) == a['bytes'] and 'sha256:' + sha(data) == a['backendDigest']
collector = root / 'var/qa/fixed708-early-native-20261021/verify-completed-fixed2b83-full-originals-v1.py'
text = collector.read_text()
start = text.index("ns={'t':")
end = text.index('current=collect(', start)
segment = text[start:end]
assert segment.count('==13380') == 2 and segment.count('==7646') == 1
segment = segment.replace('==13380', '==13453').replace('==7646', '==7657')
exec(compile(segment, '<original-independent-trx-collector-current7a-counts>', 'exec'), globals())
current = collect(Path(artifacts['conformance-results']['path']), True)
prior = load(root / 'var/qa/special-trigger-damage-current-cn16-20261021/ci99e-entire-full-independent-verification-v1.json')
prior_artifact = next(a for a in prior['artifacts'] if a['name'] == 'conformance-results')
assert sha(Path(prior_artifact['path']).read_bytes()) == prior_artifact['sha256']
before = collect(Path(prior_artifact['path']))
assert not (before[0] - current[0]) and before[1] <= current[1]
added_cases=current[0]-before[0]; added_methods=current[1]-before[1]
assert sum(added_cases.values())==50 and len(added_methods)==6
assert all('CurrentControllerDamageBonusTests.' in name for name in added_cases)
assert added_methods==set(['Riftbound.ConformanceTests.CurrentControllerDamageBonusTests.ActivatedXerathSkillAddsCurrentControllerAndTargetLocalBonuses', 'Riftbound.ConformanceTests.CurrentControllerDamageBonusTests.ActualResponseSacrificeRemovesBonusBeforeTheOriginalSpellResolves', 'Riftbound.ConformanceTests.CurrentControllerDamageBonusTests.CountedDefendAddsControllerAndLocalBonusesOnceAndPreservesNoActionAtZero', 'Riftbound.ConformanceTests.CurrentControllerDamageBonusTests.CountedSkillUsesItsControllersCurrentFieldSources', 'Riftbound.ConformanceTests.CurrentControllerDamageBonusTests.OfficialStarfallExampleAddsControllerBonusPerTargetAndLocalBonusOnlyAtItsTarget', 'Riftbound.ConformanceTests.CurrentControllerDamageBonusTests.SelectedBattlefieldDoesNotDoubleTheSharedControllerOrLocalBonus'])
assert sum(current[0].values()) == 13453 and len(current[1]) == 7657
assert len(current[2]) == 1
matrix = current[2][0]
assert matrix['seed'] == 424242 and matrix['deckCount'] == 11 and matrix['pairCount'] == 110
assert set(matrix['completed']) == set(prior['matrix']['completed']) and all(re.fullmatch('[0-9a-f]{64}', h) for h in matrix['completed'].values())
full = {m for m in current[1] if m.startswith('Riftbound.ConformanceTests.FullGameEndToEndTests.')}
assert len(full) == 143 and full == {m for m in before[1] if m.startswith('Riftbound.ConformanceTests.FullGameEndToEndTests.')}
stage = w / 'ci7a-independent-sql-members-v1'
stage.mkdir(exist_ok=False)
members = []
for index in range(4):
    target = stage / str(index)
    target.mkdir(exist_ok=False)
    with zipfile.ZipFile(artifacts['postgres-partition-' + str(index)]['path']) as z:
        for name in z.namelist():
            assert not Path(name).is_absolute() and '..' not in Path(name).parts
            if name.endswith('/'): continue
            p = target / name
            p.parent.mkdir(parents=True, exist_ok=True)
            raw = z.read(name)
            with p.open('xb') as stream: stream.write(raw)
            members.append({'partition': index, 'originalZipMember': name, 'path': str(p.relative_to(root)), 'bytes': len(raw), 'sha256': sha(raw)})
manifest = w / 'exact-fixed7a-sql-manifest-original-v1.json'
manifest.write_bytes(subprocess.check_output(['git', 'show', fixed + ':tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'], cwd=root))
assert len(load(manifest)['cases']) == 55
assert load(manifest)['cases'][-1]['id'] == 'controller-damage-bonus'
assert load(manifest)['cases'][:54] == json.loads(subprocess.check_output(['git', 'show', prior['commit'] + ':tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'], cwd=root))['cases']
gate_source = subprocess.check_output(['git', 'show', fixed + ':scripts/sql-ci-gate.py'], cwd=root)
(w / 'exact-fixed7a-sql-ci-gate-original-v1.py').write_bytes(gate_source)
module = types.ModuleType('exact_fixed7a_sql_gate')
exec(compile(gate_source, '<exact-fixed7a-sql-gate>', 'exec'), module.__dict__)
sql = module.verify(fixed, manifest, stage, dict.fromkeys(['scope', 'postgres_partitions', 'native_network'], 'success'))
assert sql['caseCount'] == 55
with zipfile.ZipFile(artifacts['postgres-results']['path']) as z: assert json.loads(z.read('result.json')) == sql
with zipfile.ZipFile(artifacts['full-verification-gate']['path']) as z:
    gate = json.loads(z.read('result.json'))
    assert gate['commit'] == fixed and gate['status'] == 'FIXED_COMMIT_FULL_CHILD_JOBS_ALL_SUCCEEDED' and all(s == 'success' for s in gate['jobs'].values())
with zipfile.ZipFile(artifacts['verification-scope']['path']) as z:
    decision = json.loads(z.read('decision.json'))
    governance = json.loads(z.read('governance.json'))
    assert decision['headSha'] == fixed and decision['full'] is True
    assert governance['governanceValid'] and not governance['semanticCoverageCertified'] and governance['errors'] == []
with zipfile.ZipFile(artifacts['native-network-results']['path']) as z:
    network = {n: z.read(n).decode() for n in z.namelist()}
    assert not any('error' in n.lower() for n in network) and network['commit.txt'].strip() == fixed
    log = network['native-network.log']
    wire = next(json.loads(line[len('NATIVE_ROOM_IDENTITY_EVIDENCE '):]) for line in log.splitlines() if line.startswith('NATIVE_ROOM_IDENTITY_EVIDENCE '))
    assert wire['rejectedActions'] == 15 and wire['leakedPrivateMessages'] == 0 and wire['validReconnectTokenWasSupplied']
    assert 'Native canonical room identity passed:' in log and 'Native network recovery passed: socket loss, authenticated room restore, fresh snapshot, rejected-token guard.' in log
comparison = {'atUtc': now(), 'previousFixed': prior['commit'], 'currentFixed': fixed, 'pairs': {k: {'previous': prior['matrix']['completed'][k], 'current': matrix['completed'][k], 'equal': prior['matrix']['completed'][k] == matrix['completed'][k]} for k in sorted(matrix['completed'])}, 'originalPairIdsAndSeedUnchanged': True}
comparison['differentTerminalHashes'] = sum(not row['equal'] for row in comparison['pairs'].values())
(w / 'ci7a-vs-99e-original-terminal-hash-comparison-v1.json').write_text(json.dumps(comparison, indent=2))
(w / 'ci7a-original-sql-zip-member-extraction-manifest-v1.json.gz').write_bytes(gzip.compress(json.dumps(members, indent=2).encode(), mtime=0))
result = {'status': 'FIXED7A_FULL_ORIGINALS_ALL11_JOBS_AND_INDEPENDENT55_SQL_NETWORK_GATE_VERIFIED', 'atUtc': now(), 'commit': fixed, 'runId': run_id, 'jobs': downloads['jobs'], 'actualCases': 13453, 'actualMethods': 7657, 'original99eAll13403CaseMultiset7651MethodsRetained': True, 'addedCases': dict(added_cases), 'addedMethods': sorted(added_methods), 'fullGameMethods': 143, 'matrix': matrix, 'allOriginal110PairIds11DecksAnd424242SeedRetained': True, 'trxSha256': current[3], 'sql': sql, 'originalNetwork': wire, 'artifacts': downloads['artifacts'], 'originalCollectorSourceSha256': sha(collector.read_bytes()), 'exactTargetSqlGateSourceSha256': sha(gate_source), 'scopeDecision': decision, 'governanceSemanticCertificationRemainsFalse': True, 'newBe0eSpecialTrigger56AndRoomSeat57NotCoveredByThis55SqlRun': True, 'wholePrintingVisiblePhysicalWindowsAndGoalComplete': False}
(w / 'ci7a-entire-full-independent-verification-v1.json').write_text(json.dumps(result, indent=2))
print('PASS fixed7a actual13453/7657; original99e13403/7651 retained; only50/6 added;143full/110pairs/11decks/424242;all55SQL;network15/0;terminal hash differences', comparison['differentTerminalHashes'], flush=True)
