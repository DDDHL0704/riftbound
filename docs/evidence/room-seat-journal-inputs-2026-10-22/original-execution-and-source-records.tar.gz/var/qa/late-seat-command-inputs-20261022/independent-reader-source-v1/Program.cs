using System.IO.Compression;
using System.Reflection;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

if (args.SequenceEqual(new[] { "--identity" }))
{
    var assemblies = new[] { typeof(CoreRuleEngine).Assembly, typeof(GameCommand).Assembly,
        typeof(Riftbound.CardCatalog.OfficialCardCatalog).Assembly, typeof(PostgresMatchJournal).Assembly };
    var writer = Assembly.LoadFrom(Path.Combine(AppContext.BaseDirectory, "Riftbound.PostgresAcceptance.dll"));
    Console.WriteLine(JsonSerializer.Serialize(new { actualRuleInputs = RuleInputIdentity.Current, baseDirectory = AppContext.BaseDirectory,
        hasRoomSeatReplay = typeof(MatchSession).GetMethod("ReplayRoomSeatAsync", BindingFlags.Instance | BindingFlags.NonPublic) is not null,
        hasIndependentSeatGuard = typeof(CoreRuleEngine).Assembly.GetType("Riftbound.Engine.RoomSeatRecoveryValidator") is not null,
        hasNewSqlCase = writer.GetType("RoomSeatJournalSqlAcceptance") is not null,
        assemblies = assemblies.Select(a => new { name = a.GetName().Name, path = a.Location,
            sha256 = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(a.Location))).ToLowerInvariant(), mvid = a.ManifestModule.ModuleVersionId }) },
        new JsonSerializerOptions(JsonSerializerDefaults.Web)));
    return;
}

Check(args.Length == 2 && !File.Exists(args[1]), "Original SQL evidence and unused independent result required.");
var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
var settings = new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
Check(settings.Host == "127.0.0.1" && settings.Port == 55486 && settings.Database == "riftbound_acceptance" && settings.Username == "codex_riftbound_audit", "Only own retained audit database.");
settings.Options = "-c default_transaction_read_only=on";
await using var source = NpgsqlDataSource.Create(settings.ConnectionString);
var cases = new HashSet<(bool, bool)>(); var rooms = new List<string>(); var results = new List<object>();
var commands = 0; var events = 0; var histories = 0; var snapshots = 0; var prompts = 0; var structural = 0;
var replayMethod = typeof(MatchActionLogReplayer).GetMethod("ReplayCommandAsync", BindingFlags.Static | BindingFlags.NonPublic)!;
foreach (var receiptPath in Directory.GetFiles(args[0], "receipt.json", SearchOption.AllDirectories).Order(StringComparer.Ordinal))
{
    var folder = Path.GetDirectoryName(receiptPath)!; using var receipt = JsonDocument.Parse(File.ReadAllText(receiptPath)); var r = receipt.RootElement;
    var reverse = r.GetProperty("reverse").GetBoolean(); var late = r.GetProperty("late").GetBoolean();
    Check(cases.Add((reverse, late)), "Duplicate finite room seating case.");
    var first = reverse ? "seat-b" : "seat-a"; var second = reverse ? "seat-a" : "seat-b";
    var room = r.GetProperty("room").GetString()!; rooms.Add(room);
    var original = new List<MatchJournalEntry>();
    for (var i = 1; i <= 9; i++)
    {
        using var input = Read(Path.Combine(folder, $"entry-{i:D2}-original-input-before-persist.json.gz"));
        var e = input.RootElement.Deserialize<MatchJournalEntry>(json)!;
        Check(Same(input.RootElement, JsonSerializer.SerializeToElement(e, json)), "Every pre-persistence input field, null and omission retained.");
        Check(e.RoomId == room && e.RuleInputs == RuleInputIdentity.Current && e.OpeningSeed != 0, "Original room/seed/version exact.");
        original.Add(e);
    }
    Check(original.Select(e => e.OpeningSeed).Distinct().Count() == 1 && original.Count(e => e.Accepted && e.CommandType == "ROOM_SEAT") == 2
        && original.Count(e => !e.Accepted && e.CommandType == "ROOM_SEAT") == 1, "Two independent server inputs and the original rejected client raw input.");
    var expectedOrder = late ? new[] { "ROOM_SEAT", "SUBMIT_DECK", "ROOM_SEAT", "SUBMIT_DECK", "READY", "READY", "MULLIGAN", "MULLIGAN", "ROOM_SEAT" }
        : new[] { "ROOM_SEAT", "ROOM_SEAT", "SUBMIT_DECK", "SUBMIT_DECK", "READY", "READY", "MULLIGAN", "MULLIGAN", "ROOM_SEAT" };
    Check(original.Select(e => e.CommandType).SequenceEqual(expectedOrder), "Exact original interleaving is not normalized away.");
    var stateRows = new Dictionary<(long, long), MatchState>();
    var expectedPrivate = new Dictionary<(string, long), (long Sequence, SnapshotDto Snapshot, ActionPromptDto Prompt)>();
    var joined = 0;
    foreach (var e in original)
    {
        if (e.Accepted && e.CommandType == "ROOM_SEAT")
        {
            var actor = joined == 0 ? first : second; var slot = joined == 0 ? "P1" : "P2"; joined++;
            Check(e.PlayerId == actor && e.ClientIntentId == "room-seat:" + slot && e.CompletedTick == e.StartedTick + 1
                && e.CompletedEventSequence == e.StartedEventSequence + 1 && e.RawCommand!.Value.GetProperty("playerId").GetString() == actor
                && e.RawCommand.Value.GetProperty("seat").GetString() == slot && e.RawCommand.Value.EnumerateObject().Count() == 3
                && e.Events.Count == 1 && e.Events[0].Kind == "PLAYER_SEATED", "Independent literal assignment/order and event span, no production seat derivation.");
        }
        Check(e.AuthoritativeState.Seats.Count == joined && e.AuthoritativeState.Seats[first] == "P1"
            && (joined == 1 || e.AuthoritativeState.Seats[second] == "P2"), "Every original state has its actual historical membership.");
        var key = (e.CompletedTick, e.CompletedEventSequence);
        if (stateRows.TryGetValue(key, out var previous)) Check(Same(JsonSerializer.SerializeToElement(previous, json), JsonSerializer.SerializeToElement(e.AuthoritativeState, json)), "Same-key rejected command must not overwrite different accepted history.");
        stateRows[key] = e.AuthoritativeState;
        foreach (var actor in e.Snapshots.Keys) expectedPrivate[(actor, e.CompletedTick)] = (e.CompletedEventSequence, e.Snapshots[actor], e.Prompts[actor]);
    }
    var frame = await new PostgresMatchRecoveryStore(source).LoadAsync(room, default) ?? throw new Exception("Original final SQL frame missing.");
    using (var saved = Read(Path.Combine(folder, "original-final-frame.json.gz"))) Check(Same(saved.RootElement, JsonSerializer.SerializeToElement(frame, json)), "Every original final recovery field/null/omission exact.");
    Check(frame.ValidationErrors.Count == 0 && frame.Commands.Count == 9 && frame.ReplayInitialState is { Status: "EMPTY", Seats.Count: 0 }
        && frame.OpeningSeed == original[0].OpeningSeed, "Actual empty-room origin and original private seed, no old-game rewrite.");
    await using (var connection = await source.OpenConnectionAsync())
    {
        Check((string)(await new NpgsqlCommand("show transaction_read_only", connection).ExecuteScalarAsync())! == "on", "Actual read-only session.");
        await using (var q = Query(connection, "select player_id,client_intent_id,command_type,started_tick,completed_tick,started_event_sequence,completed_event_sequence,accepted,error_message,payload::text,rule_inputs::text from command_log where match_id=@room order by id", room))
        await using (var rows = await q.ExecuteReaderAsync())
        {
            var i = 0;
            while (await rows.ReadAsync())
            {
                Check(i < original.Count, "No extra SQL command."); var e = original[i++];
                Check(rows.GetString(0) == e.PlayerId && rows.GetString(1) == e.ClientIntentId && rows.GetString(2) == e.CommandType
                    && rows.GetInt64(3) == e.StartedTick && rows.GetInt64(4) == e.CompletedTick && rows.GetInt64(5) == e.StartedEventSequence
                    && rows.GetInt64(6) == e.CompletedEventSequence && rows.GetBoolean(7) == e.Accepted && (rows.IsDBNull(8) ? null : rows.GetString(8)) == e.ErrorMessage, "Every original command column matches the live pre-persist input.");
                var expected = JsonSerializer.SerializeToElement(new { e.RoomId, e.PlayerId, e.ClientIntentId, e.CommandType, e.RawCommand, e.StartedTick, e.CompletedTick,
                    e.StartedEventSequence, e.CompletedEventSequence, e.Accepted, e.ErrorMessage, e.RulesetVersion, e.FaqVersion, e.RuleInputs, e.RulesAuditStatus }, json);
                using var payload = JsonDocument.Parse(rows.GetString(9)); using var inputs = JsonDocument.Parse(rows.GetString(10));
                Check(Same(payload.RootElement, expected) && Same(inputs.RootElement, JsonSerializer.SerializeToElement(e.RuleInputs, json)), "Entire original SQL command payload and typed input identity.");
            }
            Check(i == original.Count, "Every original command retained.");
        }
        await using (var q = Query(connection, "select event_sequence,event_tick,event_order,payload::text from game_events where match_id=@room order by event_sequence", room))
        await using (var rows = await q.ExecuteReaderAsync())
        {
            var expected = original.SelectMany(e => e.Events.Select((item, i) => new RecoveredEvent(e.StartedEventSequence + i + 1, e.CompletedTick, i, item))).ToArray(); var i = 0;
            while (await rows.ReadAsync()) { Check(i < expected.Length, "No extra event."); var e = expected[i++]; using var raw = JsonDocument.Parse(rows.GetString(3));
                Check(rows.GetInt64(0) == e.Sequence && rows.GetInt64(1) == e.Tick && rows.GetInt32(2) == e.Order && Same(raw.RootElement, JsonSerializer.SerializeToElement(e.Event, json)), "Every original live event field and column."); }
            Check(i == expected.Length, "All original events present."); events += i;
        }
        await using (var q = Query(connection, "select state_tick,last_event_sequence,payload::text from state_snapshots where match_id=@room order by id", room))
        await using (var rows = await q.ExecuteReaderAsync())
        {
            var seen = new HashSet<(long,long)>();
            while (await rows.ReadAsync()) { var key = (rows.GetInt64(0), rows.GetInt64(1)); using var raw = JsonDocument.Parse(rows.GetString(2));
                Check(seen.Add(key) && stateRows.TryGetValue(key, out var expected) && Same(raw.RootElement, JsonSerializer.SerializeToElement(expected, json)), "Each complete original live authority state survives JSONB, including early one-seat histories."); }
            Check(seen.SetEquals(stateRows.Keys), "No missing authority histories."); histories += seen.Count;
        }
        foreach (var table in new[] { "snapshots", "action_prompts" })
        {
            var tickColumn = table == "snapshots" ? "snapshot_tick" : "prompt_tick";
            await using var q = Query(connection, $"select player_id,{tickColumn},last_event_sequence,payload::text from {table} where match_id=@room order by id", room);
            await using var rows = await q.ExecuteReaderAsync(); var seen = new HashSet<(string,long)>();
            while (await rows.ReadAsync())
            {
                var actor = rows.GetString(0); var key = (actor, rows.GetInt64(1)); using var raw = JsonDocument.Parse(rows.GetString(3));
                Check(expectedPrivate.TryGetValue(key, out var expected) && seen.Add(key) && rows.GetInt64(2) == expected.Sequence, "Actual original private storage key and latest sequence.");
                var literal = table == "snapshots" ? JsonSerializer.SerializeToElement(expected.Snapshot, json) : JsonSerializer.SerializeToElement(expected.Prompt, json);
                Check(Same(raw.RootElement, literal), "Every private field equals the original live pre-persistence value; expected values do not come from production projection.");
                var state = stateRows[(key.Item2, expected.Sequence)]; var text = raw.RootElement.GetRawText();
                foreach (var other in state.Seats.Keys.Where(p => p != actor)) foreach (var id in state.PlayerZones[other].Hand.Concat(state.PlayerZones[other].MainDeck))
                    Check(!text.Contains("\"" + id + "\"", StringComparison.Ordinal), "Opponent hidden card identity leaked.");
                Check(!raw.RootElement.TryGetProperty("openingSeed", out _) && !raw.RootElement.TryGetProperty("reconnectToken", out _), "Private authority/authentication metadata leaked.");
            }
            Check(seen.SetEquals(expectedPrivate.Keys), "All historical private views retained under the existing tick key.");
            if (table == "snapshots") snapshots += seen.Count; else prompts += seen.Count;
        }
    }
    var replay = new MatchSession(frame.ReplayInitialState!, new CoreRuleEngine(), NoopMatchJournal.Instance);
    for (var i = 0; i < original.Count; i++)
    {
        var result = await (ValueTask<ResolutionResult>)replayMethod.Invoke(null, [replay, frame.Commands[i], CancellationToken.None])!;
        Check(result.Accepted == original[i].Accepted && result.ErrorMessage == original[i].ErrorMessage
            && Same(JsonSerializer.SerializeToElement(result.State, json), JsonSerializer.SerializeToElement(original[i].AuthoritativeState, json))
            && Same(JsonSerializer.SerializeToElement(result.Events, json), JsonSerializer.SerializeToElement(original[i].Events, json)), "Every original command prefix replays to its exact complete live state and event batch.");
        using var saved = Read(Path.Combine(folder, $"history-{i + 1:D2}-original-frame.json.gz")); var prefix = saved.RootElement.Deserialize<MatchRecoveryFrame>(json)!;
        Check((await MatchActionLogReplayer.ValidateRecoveryFrameAsync(prefix, new CoreRuleEngine(), default)).Count == 0, "Every original saved cold frame validates independently.");
    }
    var firstCommand = frame.Commands[0];
    foreach (var branch in new[] { "actor", "slot", "extra", "missing" })
    {
        var raw = branch == "actor" ? JsonSerializer.SerializeToElement(new { cmdType = "ROOM_SEAT", playerId = "intruder", seat = "P1" }, json)
            : branch == "slot" ? JsonSerializer.SerializeToElement(new { cmdType = "ROOM_SEAT", playerId = first, seat = "P2" }, json)
            : JsonSerializer.SerializeToElement(new { cmdType = "ROOM_SEAT", playerId = first, seat = "P1", extra = true }, json);
        var forged = frame with { Commands = branch == "missing" ? frame.Commands.Skip(1).ToArray()
            : frame.Commands.Select(c => ReferenceEquals(c, firstCommand) ? c with { RawCommand = raw } : c).ToArray() };
        Check(MatchRecoveryValidator.Validate(room, forged.LastEventSequence, forged.Commands, forged.Events, forged.PlayerViews, forged.AuthoritativeState, forged.CurrentTick).Any(e => e.Contains("room seat", StringComparison.Ordinal)), "Independent final structural refusal."); structural++;
    }
    commands += original.Count; results.Add(new { room, reverse, late, originalCommands = original.Count, uniqueAuthorityHistories = stateRows.Count, historicalPrivateKeys = expectedPrivate.Count });
}
Check(cases.SetEquals(new[] { (false,false),(false,true),(true,false),(true,true) }), "All four exact order/interleaving cases required.");
var proof = new { status = "PASS_INDEPENDENT_FOUR_ROOM_SEAT_SQL_CASES_ALL_ORIGINAL_LIVE_INPUTS_HISTORIES_PRIVATE_VIEWS_AND_PREFIX_REPLAYS", cases = cases.Count,
    commands, events, authoritativeHistoricalStates = histories, privateSnapshots = snapshots, privatePrompts = prompts, independentStructuralRejections = structural,
    actualRuleInputs = RuleInputIdentity.Current, rooms, results, actualReadOnlyConnection = true, originalLivePrePersistenceInputsUsedAsExpected = true,
    oldGameSeedCommandsOrHistoriesRewritten = false, nativeVisibleWindowsOrWholeProductAcceptance = false };
await File.WriteAllTextAsync(args[1], JsonSerializer.Serialize(proof, json)); Console.WriteLine(JsonSerializer.Serialize(proof, json));

static void Check(bool value, string message) { if (!value) throw new Exception(message); }
static JsonDocument Read(string path) { using var file = File.OpenRead(path); using var gzip = new GZipStream(file, CompressionMode.Decompress); return JsonDocument.Parse(gzip); }
static bool Same(JsonElement a, JsonElement b) => JsonNode.DeepEquals(JsonNode.Parse(a.GetRawText()), JsonNode.Parse(b.GetRawText()));
static NpgsqlCommand Query(NpgsqlConnection connection, string text, string room) { var q = new NpgsqlCommand(text, connection); q.Parameters.AddWithValue("room", room); return q; }
