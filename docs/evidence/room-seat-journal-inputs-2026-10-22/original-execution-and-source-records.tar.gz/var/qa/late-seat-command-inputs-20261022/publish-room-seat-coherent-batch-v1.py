from pathlib import Path
import copy, datetime, gzip, hashlib, io, json, re, subprocess, tarfile

root = Path('/Users/dinghaolin/MyProjects/riftbound'); w = Path(__file__).resolve().parent
monitor = root / 'var/qa/current-whole-source-monitor-20261022'
load = lambda p: json.loads(p.read_text()); sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(path, value):
    with path.open('x') as f: json.dump(value, f, ensure_ascii=False, indent=2)
def pin(path, role=None):
    value = {'path': str(path.relative_to(root)), 'sha256': sha(path)}
    if role: value['role'] = role
    return value

final = load(w / 'final-current-atomic-room-seat-original-retention-v1.json')
assert (final['finalFocusCases'], final['finalFocusMethods'], final['soleCheckFailed']) == (358, 279, 6)
frozen = load(w / 'current-room-seat-frozen-runtime-inputs-v2.json')
assert all(sha(root / p) == h for p, h in frozen['sourceInputHashes'].items())
assert load(w / 'original-all110-pairs-owner-terminal-v2.json')['actualOriginalDirections'] == 110
real = load(w / 'actual-current-room-seat-sql-owner-terminal-v2.json')
assert real['commands'] == 40 and real['events'] == 84 and real['coldRecoveries'] == 41 and real['ownPostgresStopped']
private = load(w / 'corrected-original-private-opening-real-sql-owner-terminal-v2.json')
assert private['actualJournalCommands'] == 9 and private['actualEvents'] == 29 and private['ownPostgresStopped']
mp = root / 'docs/audit/current-manifest.json'; m = load(mp)
rp = root / m['inputs']['reviews']['path']; reviews = load(rp)
oldm, oldreviews = copy.deepcopy(m), copy.deepcopy(reviews)
assert (len(reviews['reviews']), len(m['reviewContexts']), len(m['acceptanceGates']), len(m['laterSourceDeltas'])) == (161, 76, 245, 7)
prior = w / 'prior-room-seat-publication-v1'
for path in [mp, rp, root / 'docs/PROJECT_STATUS.md']:
    assert gzip.decompress((prior / (path.name + '.gz')).read_bytes()) == path.read_bytes()
baseline_path = root / 'docs/evidence/special-trigger-damage-current-cn16-2026-10-22/final-governance.json.gz'
baseline = json.loads(gzip.decompress(baseline_path.read_bytes()))
assert baseline['governanceValid'] and not baseline['errors'] and len(baseline['remainingObligations']) == 17088

ev = root / 'docs/evidence/room-seat-journal-inputs-2026-10-22'; ev.mkdir(exist_ok=True); assert not any(ev.iterdir())
identity = 'room-seat-journal-inputs-2026-10-22'
doc = 'docs/ROOM_SEAT_JOURNAL_INPUTS_AUDIT_2026-10-22.md'
corpus = load(root / m['inputs']['corpus']['path']); record = next(r for r in corpus['records'] if r['id'] == 'DOC-01-P101-B004')
source_review = {
    'atUtc': now(), 'status': 'BOUNDED_TWO_PLAYER_ROOM_INPUT_ENGINEERING_INVARIANT_NOT_NEW_OFFICIAL_GAME_RULE',
    'region': 'CN', 'language': 'zh-CN', 'applicableAsOf': '2026-10-22', 'adoptedCoreEffectiveDate': '2026-10-16',
    'ruleRecords': [{'id': record['id'], 'textSha256': hashlib.sha256(record['text'].encode()).hexdigest(), 'role': 'TWO_PLAYER_FORMAT_CONTEXT_ONLY_NOT_OFFICIAL_SQL_JOURNAL_REQUIREMENT'}],
    'invariant': 'Original server seat registration, actor and assigned seat must be durably recorded before publication and replay from the actual EMPTY room and original private seed. Credential metadata and the complete journal transition commit in one database transaction.',
    'implementationBoundary': 'One finite room-seat store/journal operation, serial command gate, reserved intent namespace and independent seat/event schema guard; no card parser, gameplay DSL, catalog adoption or old-development-game migration.',
    'failureBoundary': 'First/second actual SQL journal failure rolls back every original row. Unsupported durable composition fails before any write. Matching current metadata without original journal/state is rejected rather than turned into an implicit seat.',
    'sourceScope': 'CN1504, EN1408/1416, all16 known CN documents and GLOBAL hub body compared with latest separately registered versions; existing source dates and gaps retained. New GLOBAL K/DA announcement handled in a distinct supplement.',
    'actualCurrentRuleInputs': frozen['actualRuleInputs'], 'soleCheckRetainedAsFailed': True,
    'wholePrintingOrGoalCertified': False,
}
write(w / 'current-room-seat-engineering-source-scope-review-v1.json', source_review)

copies = {
    'current-exact-source-review.json': w / 'current-room-seat-engineering-source-scope-review-v1.json',
    'final-original-test-and-input-retention.json': w / 'final-current-atomic-room-seat-original-retention-v1.json',
    'only-check-original-failure-retention.json': w / 'first-only-check-original-case-method-and-input-retention-v1.json',
    'current-runtime-inputs.json': w / 'current-room-seat-frozen-runtime-inputs-v2.json',
    'real-six-sql-terminal.json': w / 'actual-current-room-seat-sql-owner-terminal-v2.json',
    'independent-all-live-inputs-history-and-replay.json': w / 'independent-current-room-seat-all-live-input-history-v2.json',
    'corrected-original-private-opening-sql.json': w / 'corrected-original-private-opening-real-sql-owner-terminal-v2.json',
    'original-all110-owner-terminal.json': w / 'original-all110-pairs-owner-terminal-v2.json',
    'preceding-fixed7a-complete-full.json': w / 'ci7a-entire-full-independent-verification-v1.json',
    'unreleased-nonatomic-first-seat-counterexample.json': w / 'failed-first-seat-real-sql-counterexample-owner-terminal-v1.json',
    'original-private-opening-count-counterexample.json': w / 'original-opening-sql-two-server-input-counterexample-owner-terminal-v1.json',
    'current-whole-cn-source-diff.json': monitor / 'whole-current-cn-card-source-diff-v1.json',
    'current-whole-en-three-views-source-diff.json': monitor / 'current-en-complete-view-source-diff-v1.json',
    'current-all-sixteen-cn-document-versions.json': monitor / 'current-cn-rule-directory-and-known-source-versions-v1.json',
    'current-global-rules-hub-body-version.json': monitor / 'current-global-rules-hub-body-versus-recorded-version-v1.json',
    'kda-announcement-primary-intake.json': monitor / 'current-kda-product-faq-five-announced-card-source-intake-v1.json',
    'kda-primary-header-pixels-observation.json': monitor / 'kda-primary-header-actual-pixel-observation-v1.json',
    'kda-five-names-thirteen-current-gallery-rows.json': monitor / 'kda-five-announced-names-current-gallery-candidate-reconciliation-v1.json',
}
for name, path in copies.items(): (ev / name).write_bytes(path.read_bytes())

# Retain each executed probe/reader's own payload once. Shared SDKs, runtime
# dependencies, installers and applications are not copied into the audit.
bits = w / 'executed-own-probe-and-reader-bits-v1'; bits.mkdir(exist_ok=False); retained_bits = []
for folder in ['probe-source-v1', 'independent-reader-source-v1', 'room-seat-failed-journal-sql-probe-source-v1', 'independent-reader-source-v3', 'current-private-opening-only-runner-source-v1']:
    source = w / folder; project = next(source.glob('*.csproj')); match = re.search(r'<AssemblyName>([^<]+)</AssemblyName>', project.read_text()); assert match
    for extension in ['.dll', '.pdb']:
        original = source / 'bin/Release/net10.0' / (match.group(1) + extension); assert original.is_file()
        target = bits / (folder + '-' + original.name); target.write_bytes(original.read_bytes())
        assert sha(target) == sha(original); retained_bits.append({'original': pin(original), 'retained': pin(target)})
write(w / 'executed-own-probe-and-reader-bits-retention-v1.json', {'atUtc': now(), 'bits': retained_bits, 'sharedMeasuredDependenciesRetainedInImmutableLocalRuntimes': True})

oldmap_path = root / 'docs/evidence/special-trigger-damage-current-cn16-2026-10-22/archive-map.json'
oldmap = load(oldmap_path); old_by_sha = {}
for row in oldmap['members']: old_by_sha.setdefault(row['sha256'], row)
members, reuse, excluded = {}, [], []
runtime_names = {p.name for p in w.iterdir() if p.is_dir() and 'runtime' in p.name.lower()}
secret = re.compile(rb'(?i)(?:playerKey|reconnectToken)[\"\s]*[:=][\s\"]*([a-z0-9_+/-]{16,})')
for folder in [w, monitor]:
    for path in sorted(folder.rglob('*')):
        parts = set(path.relative_to(folder).parts)
        if runtime_names & parts or {'bin', 'obj', '__pycache__'} & parts or not path.is_file(): continue
        if path.name.startswith('publish-room-seat-owner') or path.name.startswith('postpublication-'):
            excluded.append({'path': str(path.relative_to(root)), 'sha256': sha(path), 'reason': 'OPERATIONAL_OUTPUT_RETAINED_LOCALLY'}); continue
        raw = path.read_bytes()
        if path.suffix in {'.json', '.log', '.ndjson'}: assert not secret.search(raw), path
        name = str(path.relative_to(root)); digest = hashlib.sha256(raw).hexdigest()
        if digest in old_by_sha:
            reuse.append({'path': name, 'sha256': digest, 'existingArchiveMember': old_by_sha[digest]['path'], 'existingArchiveMap': pin(oldmap_path)})
        else: members[name] = path
archive = ev / 'original-execution-and-source-records.tar.gz'; member_rows = []
with tarfile.open(archive, 'w:gz', compresslevel=9) as tar:
    for name, path in sorted(members.items()):
        raw = path.read_bytes(); info = tarfile.TarInfo(name); info.size = len(raw); info.mode = path.stat().st_mode & 0o777; info.mtime = 0
        tar.addfile(info, io.BytesIO(raw)); member_rows.append({'path': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
with tarfile.open(archive, 'r:gz') as tar:
    assert set(tar.getnames()) == {row['path'] for row in member_rows}
    for row in member_rows:
        raw = tar.extractfile(row['path']).read(); assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
write(ev / 'archive-map.json', {'atUtc': now(), 'archive': pin(archive), 'members': member_rows,
    'existingIdenticalOlderArchiveMembersNotDuplicated': reuse, 'operationalExclusionsRetainedLocally': excluded,
    'allMemberBytesHashesAndClosedSetVerified': True, 'applicationsInstallersSdksAndFrozenRuntimeDependenciesNotDuplicated': True})

source_manifest = {'schemaVersion': 1, 'id': identity, 'atUtc': now(), 'region': 'CN', 'language': 'zh-CN',
    'applicableAsOf': '2026-10-22', 'adoptedCoreEffectiveDate': '2026-10-16', 'parentCommit': frozen['parentCommit'],
    'declaredUncommittedBatch': True, 'actualRuleInputs': frozen['actualRuleInputs'],
    'currentSourceReview': pin(ev / 'current-exact-source-review.json'), 'archive': pin(archive), 'archiveMap': pin(ev / 'archive-map.json'),
    'scope': 'Two-player original room-seat inputs, reserved-intent safety, actual EMPTY origin, atomic durable credentials/journal and independent orphan/tamper rejection.21 new conformance cases; current358 focus,110 original helper directions, six SQL branches40/84 and separate original private-opening9/29.',
    'allOriginalPublicationEffectiveAndAcquisitionDatesAndSevenDeltasRetained': True,
    'fullScopeRetained': {'printings': 1740, 'ruleBlocks': 14293, 'cnRows': 1504, 'enRows': 1408, 'enReported': 1416, 'enGap': 8, 'active': 1035, 'outsideActive': 705, 'cnDispositions': 236, 'cnNews': 139, 'sourceDeltas': 7},
    'originalSoleCheck': {'cases': 13369, 'methods': 7530, 'passed': 13363, 'failed': 6, 'skipped': 0, 'noSecondCheck': True},
    'newFixedFullAndCurrentCandidateNativeVisiblePhysicalWindows': 'PENDING_SEPARATELY', 'semanticCoverageCertified': False}
write(ev / 'source-manifest.json', source_manifest); sp = pin(ev / 'source-manifest.json', 'source-manifest')
kda = load(ev / 'kda-announcement-primary-intake.json')
global_manifest = {'schemaVersion': 1, 'id': 'global-kda-couture-source-supplement-20261022', 'atUtc': now(),
    'region': 'GLOBAL', 'language': 'en-US', 'sourceUrl': kda['sourceUrl'], 'contentId': kda['contentId'], 'revision': kda['revision'],
    'declaredPublicationUtc': kda['declaredPublication'], 'browserDisplayedLocalDate': '10/22/2026',
    'intake': pin(ev / 'kda-announcement-primary-intake.json'), 'actualHeaderPixels': pin(ev / 'kda-primary-header-pixels-observation.json'),
    'existingNamedGalleryCandidateRows': pin(ev / 'kda-five-names-thirteen-current-gallery-rows.json'),
    'archiveMap': pin(ev / 'archive-map.json'), 'announcedSubjectCount': 5,
    'precisePrintingIdsGameEffectiveDatesRegionalLegalityAndRulesIdentity': 'OPEN',
    'shoppingRegistrationAndShippingDatesAreNotGameEffectiveDates': True,
    'notAssumedToExplainEightMissingEnglishGalleryRows': True, 'old1740PrintingUniverseAnd139ChineseNewsScopeUnchanged': True,
    'newAnnouncementSeparateFromUnchangedGlobalRulesHubBody': True, 'issue': 'https://github.com/DDDHL0704/riftbound/issues/86',
    'semanticCoverageCertified': False}
write(ev / 'global-kda-couture-source-supplement.json', global_manifest); gp = pin(ev / 'global-kda-couture-source-supplement.json', 'source-manifest')

branches = []
for case in final['newCaseIdentities']:
    branches.append({'id': 'room-seat-' + hashlib.sha256(case.encode()).hexdigest()[:20], 'sourceRefs': ['DOC-01-P101-B004'],
        'state': 'RECORDED', 'sourceManifest': sp, 'boundedCase': {'actualExecutedCase': case, 'formatClauseIsContextOnly': True,
            'sqlAtomicFirstAndSecondRollbackAndOrphanBackstopAdditionalEvidence': 'FailedJournal' in case},
        'semanticReview': {'state': 'BOUNDED_ENGINEERING_INVARIANT_REVIEW_NOT_WHOLE_CARD_OR_OFFICIAL_DATABASE_RULE'},
        'implementation': {'state': 'ORIGINAL_SERVER_INPUT_ATOMIC_CREDENTIAL_JOURNAL_SERIALIZED_PUBLICATION_RESERVED_NAMESPACE_AND_INDEPENDENT_GUARDS'},
        'testExecution': {'state': 'FINAL_FOCUS358_ALL110_SIX_SQL40_84_INDEPENDENT_HISTORY_AND_ORIGINAL_PRIVATE_OPENING9_29_PASS', 'soleCheckSixFailuresPreservedWithExactCorrections': True},
        'fixedCommitCi': {'state': 'PENDING_NEW_FIXED_FULL'}, 'productAcceptance': {'state': 'OPEN_NEW_FIXED_CANDIDATE_VISIBLE_AND_PHYSICAL_WINDOWS'},
        'decision': {'state': 'OPEN', 'reason': 'Bounded engineering repair and executed local evidence do not close new fixed full or current candidate product acceptance.'},
        'wholePrintingCertified': False, 'existingAcceptanceGateDependencies': ['FIXED_CURRENT_CANDIDATE_FULL', 'VISIBLE_PAIRED_SQL_NETWORK_SCORE_REPLAY', 'USER_WINDOWS_RUNTIME']})
assert len(branches) == 21
write(ev / 'twenty-one-exact-room-input-behavior-branches.json', {'branches': branches})

refresh = []
for review_id, context in m['reviewContexts'].items():
    differences = []
    for ref in context['implementation']:
        current = sha(root / ref['path'])
        if current != ref['sha256']:
            differences.append({'path': ref['path'], 'before': ref['sha256'], 'after': current}); ref['sha256'] = current
    if differences:
        refresh.append({'id': review_id, 'changes': differences, 'oldCompleteContext': oldm['reviewContexts'][review_id]})
        context.update(currentImplementationCommit=frozen['parentCommit'], currentImplementationIncludesUncommittedChanges=True,
            currentRoomSeatInputRefresh={'sourceManifest': sp, 'onlyCurrentImplementationRefsRefreshed': True,
                'oldSourceEvidenceVerificationPinsBranchesAndCiClaimsRetained': True, 'newFixedFullAndProducts': 'OPEN',
                'notAnAdditionalSemanticReviewOfPriorFindingsOrPrintings': True})
assert len(refresh) == 48
m['reviewContexts']['native-late-seat-historical-replay-finding-2026-10-22']['currentRoomSeatBoundedRepairFollowup'] = {
    'newReview': identity, 'sourceManifest': sp, 'old7aCounterexampleAndAcceptedGameRemainUnmodified': True,
    'currentBoundedImplementationFocusSqlAndAll110': 'PASS', 'newFixedFullAndCurrentProducts': 'OPEN', 'wholeFindingOrGoalClosed': False}
refresh_path = ev / 'complete-prior-contexts-current-input-refresh.json.gz'
refresh_path.write_bytes(gzip.compress(json.dumps(refresh, ensure_ascii=False, indent=2).encode(), mtime=0))

implementation = ['src/Riftbound.Engine/MatchSession.cs', 'src/Riftbound.Engine/MatchSession.RoomSeats.cs',
    'src/Riftbound.Engine/RoomSeatRecoveryValidator.cs', 'src/Riftbound.Engine/MatchRecovery.cs', 'src/Riftbound.Engine/MatchPlayers.cs',
    'src/Riftbound.Engine/MatchJournal.cs', 'src/Riftbound.Persistence/PostgresMatchJournal.cs',
    'src/Riftbound.Persistence/PostgresMatchPlayerStore.cs', 'src/Riftbound.Persistence/PostgresMatchRecoveryStore.cs']
verification = ['tests/Riftbound.ConformanceTests/RoomSeatJournalTests.cs', 'tests/Riftbound.ConformanceTests/OpeningRandomizationTests.cs',
    'tests/Riftbound.ConformanceTests/GameHubJoinTests.cs', 'tests/Riftbound.ConformanceTests/MatchRecoveryTests.cs',
    'tests/Riftbound.PostgresAcceptance/RoomSeatJournalSqlAcceptance.cs', 'tests/Riftbound.PostgresAcceptance/OpeningRandomnessSqlAcceptance.cs',
    'tests/Riftbound.PostgresAcceptance/Program.cs', 'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json', 'scripts/tests/test_sql_ci_gate.py']
m['reviewContexts'][identity] = {'evidenceCommit': frozen['parentCommit'], 'currentImplementationCommit': frozen['parentCommit'],
    'currentImplementationIncludesUncommittedChanges': True, 'ciState': 'PENDING', 'ciReceipts': [], 'region': 'CN', 'language': 'zh-CN',
    'applicableAsOf': '2026-10-22', 'adoptedCoreEffectiveDate': '2026-10-16', 'sourceManifest': sp,
    'implementation': [pin(root / p, 'implementation') for p in implementation],
    'verificationSources': [pin(root / p, 'verification-source') for p in verification], 'branches': branches,
    'evidence': [pin(ev / name, role) for name, role in [('final-original-test-and-input-retention.json', 'focus-and-retention'),
        ('only-check-original-failure-retention.json', 'sole-check-failures'), ('real-six-sql-terminal.json', 'sql'),
        ('independent-all-live-inputs-history-and-replay.json', 'independent-sql'), ('corrected-original-private-opening-sql.json', 'original-private-opening'),
        ('original-all110-owner-terminal.json', 'original-pair-helpers')]]}
reviews['reviews'].append({'id': identity, 'scope': source_manifest['scope'], 'subjects': [], 'ruleRecords': ['DOC-01-P101-B004'],
    'status': 'BOUNDED_ORIGINAL_ROOM_INPUT_ATOMICITY_FINAL_FOCUS_SQL_AND_ALL110_PASS_ORIGINAL_CHECK_FAILURES_RETAINED_FIXED_FULL_AND_PRODUCTS_OPEN',
    'sourceManifest': sp, 'auditDocument': doc, 'validation': {'newCases': 21, 'newMethods': 9, 'finalFocusCases': 358, 'finalFocusMethods': 279,
        'originalOnlyCheckPassed': 13363, 'originalOnlyCheckFailed': 6, 'sqlCases': 6, 'sqlCommands': 40, 'sqlEvents': 84, 'sqlColdRecoveries': 41,
        'originalPrivateOpeningCommands': 9, 'originalPrivateOpeningEvents': 29, 'wholePrintingCertified': False},
    'exclusions': ['New fixed full and new native/visible/Windows evidence remain open.', 'Old native41 history and every old seed/command are retained, not migrated.',
        'Frost battlefield controller issue84 remains unrepaired.', 'All source gaps, dates,1740 printings,14293 blocks,139 Chinese news and seven source deltas remain.']})

gate_ids = []
for key, character, name in [('EVELYNN', 'Evelynn', 'Agony’s Embrace'), ('AHRI', 'Ahri', 'Nine-Tailed Fox'),
                             ('AKALI', 'Akali', 'Rogue Assassin'), ('KAISA', 'Kai’Sa', 'Daughter of the Void'),
                             ('PACKED_AMPHITHEATER', None, 'Packed Amphitheater')]:
    gate_id = 'GLOBAL_KDA_COUTURE_' + key + '_EXACT_PRINTING_APPLICABILITY_20261022'; gate_ids.append(gate_id)
    m['acceptanceGates'].append({'id': gate_id, 'state': 'OPEN', 'sourceDocument': kda['contentId'], 'sourceManifest': gp,
        'region': 'GLOBAL', 'language': 'en-US', 'announcedCharacter': character, 'announcedName': name,
        'requirement': 'Obtain exact official Couture printing identity, rules text, regional/date legality and relation to current returned gallery entries; named base-card candidates and purchase dates do not close this gap.',
        'semanticReview': 'ANNOUNCEMENT_TEXT_AND_HEADER_PIXELS_BOUNDED_ONLY', 'implementation': 'NO_RUNTIME_ADOPTION_WITHOUT_IDENTITY_AND_APPLICABILITY',
        'testExecution': 'NOT_A_GAMEPLAY_PASS', 'fixedCommitCi': 'SEPARATE', 'productAcceptance': 'SEPARATE',
        'notAssumedToBeOneOfEightUnreturnedEnglishRows': True, 'wholePrintingCertified': False})
assert reviews['reviews'][:161] == oldreviews['reviews'] and m['acceptanceGates'][:245] == oldm['acceptanceGates'] and m['laterSourceDeltas'] == oldm['laterSourceDeltas']
assert (len(reviews['reviews']), len(m['reviewContexts']), len(m['acceptanceGates'])) == (162, 77, 250)
rp.write_text(json.dumps(reviews, ensure_ascii=False, indent=2) + '\n'); m['inputs']['reviews']['sha256'] = sha(rp)
m['currentRoomSeatJournalInputChange'] = {'sourceManifest': sp, 'auditDocument': doc, 'newBoundedBranches': 21,
    'original17088ObligationIdsMustRemain': True, 'expectedCurrentTotalAfterFiveGlobalSourceGaps': 17114,
    'all161OldReviews245OldGatesAndSevenDeltasExact': True, 'oldContexts': 76, 'completeUnchangedOldContexts': 28,
    'currentImplementationRefRefreshOnlyContexts': 48, 'completeOldContexts': pin(refresh_path), 'noSecondCheck': True,
    'originalSixCheckFailuresAndUnreleasedNonatomicCounterexampleRetained': True, 'newFixedFullAndProducts': 'OPEN', 'wholePrintingOrGoalComplete': False}
m['currentGlobalKdaCoutureSupplement'] = {'sourceManifest': gp, 'newSourceGapGateIds': gate_ids, 'old139ChineseNewsScopeUnchanged': True,
    'fiveSubjectsNotMergedInto1740PrintingUniverseOrExistingEightRowGap': True}
m['precedingFixed7aActualCompleteFullCiReadback'] = pin(ev / 'preceding-fixed7a-complete-full.json')
mp.write_text(json.dumps(m, ensure_ascii=False, indent=2) + '\n')
write(ev / 'publication-original-governance-object-retention.json', {'atUtc': now(), 'oldReviews': 161, 'oldContexts': 76, 'oldGates': 245, 'oldDeltas': 7,
    'allCompleteOldReviewGateAndDeltaObjectsExact': True, 'oldContextsExact': 28, 'oldContextsOnlyCurrentImplementationRefreshWithCompleteOriginalsRetained': 48,
    'originalObligationCount': 17088, 'newBehaviorBranches': 21, 'newGlobalAnnouncementSourceGates': 5, 'expectedRemainingObligations': 17114,
    'originalCompleteManifestAndReviewsInArchive': True, 'baselineGovernance': pin(baseline_path), 'semanticCoverageCertified': False})

document = '''# 原始入座日志与原子持久化限定审查

本批地区CN、语言zh-CN、适用日期2026-10-22，核心规则仍为10-16生效版本。来源、发布、生效与取得日期各自保留。[来源manifest](evidence/room-seat-journal-inputs-2026-10-22/source-manifest.json)限定工程行为；DOC-01-P101-B004只提供双人产品格式背景，没有把数据库日志要求虚构成官方游戏条款。Goal active / NOT READY。

真实异步入房现在是既有日志中的服务端ROOM_SEAT输入：记录原玩家、服务端分配席位、固定内部intent、tick/事件序列、完整权威和私有视图。与普通指令共用serialGate，持久化成功后才发布内存；已知玩家和重连不重复入座。完整回放从真实EMPTY房间和原私有种子开始，不从最终双人座位倒推，不跳过早期SEATING。客户端同名未知指令仍按原拒绝路径回放，内部intent命名空间在暖/冷缓存访问前拒绝；无新GameCommand、目录、解析器或DSL扩张。

原固定7a可见局41命令263事件正常8:0，但首条仅A状态无法从最终A+B初态回放，#85原失败与旧局均保留。本批先在干净be0输入复现两条真实客户端命令的相同缺陷。首个方案在锁屏下的独立SQL中断测试又发现未提交b624候选的缺陷：玩家元数据已提交、首条入座日志失败，冷恢复会读出幽灵P1；首人不能重试，第二人首条P2日志无法回放。它不是已发布be0的新缺陷，原完整帧/失败/种子与原库保留。

修复仅增加有限的入座存储/日志操作。PostgreSQL在同一事务保存玩家、令牌哈希、命令、事件、权威历史、私有快照和提示；复用原席位锁、原SQL与规则身份校验。未知非原子持久化组合在任何写入前拒绝；仅有匹配当前身份/种子的玩家元数据也不能合成座位。原显式受控初态路径保留，旧开发局不迁移或重写。

新21例/9方法覆盖原始晚入座、重复已知玩家、12种字段/事件/序列篡改、JSONB成员换序、客户端伪造、保留拒绝日志、预游戏拒绝、并发、失败不发布及暖/冷保留intent攻击。原两次缓存反例、空房间首修失败、旧种子夹具输入校准、首次SQL编译错误都按原结果保留，未改写为通过。

唯一check实际13369例/7530方法：13363通过、六个原Hub夹具失败、零跳过；3336源/模式、1419Conformance与23原生Debug载荷全过程稳定，起止实测锁屏。五例仍把两条新服务端输入后的日志当成一条，另一个回放助手仍用最终双座位初态。只校准这些输入/计数，新增精确两条服务端字段/事件守卫，保留原幂等、拒绝不变性、隐私、胜利和回放断言。三个原测试源仅此夹具或私有存储适配，所有Fact/Theory/data行及公开测试方法保留；最终focus358例/279方法全过，六个原失败全部通过。无第二check，新固定full必须覆盖收尾后的原子实现。

原九份完整源码/143公共方法/110配对/十一牌组/424242与全部胜利及回放断言字节保留。47e实际身份下110原助手方向完整通过，原b624运行也按原输入留存；终态哈希按各身份记录，不要求跨实现相等。发现列表13412行/7671方法全同原检查输入，原be0列表13391行/7662方法只增21/9；发现列表与运行期Theory展开分别记录。新固定full预计13518/7671，尚非已执行结果。

第57项SQL保留原56身份、对象和顺序。四原顺序分支各9日志，另两真实首人/第二人日志插入CHECK失败分支：七表精确回滚、原种子与下一席位保留，撤销临时约束后同局正常重试。合计六分支40命令84事件、41冷恢复、36已知玩家无操作、四预游戏拒绝及144写入端结构拒绝。非原子组合无写入、当前身份孤立元数据拒绝各一项独立保留。只读读者逐条核对原写入前完整输入，验证36权威历史/双方合计48快照48提示、所有原始前缀回放及24结构拒绝；原323审计/66原生七表不变，留至330审计，库正常停止。

原private-opening SQL类另按实际编译类执行：保留七条原客户端动作、七个冷恢复点、四种种子篡改拒绝、四开局随机消费者及全部私有种子/对手隐藏信息守卫；另计两条服务端注册，共9日志29事件。原首轮零日志期望失败留存，收据明确种子与首个服务端注册同时落库、早于首个客户端动作。独立原始七表读取另存，但不冒称这一独立原类具有六分支相同的写入前期望值读者。原330审计/66原生七表不变，新局留至331；不重提无关固定房间因果夹具或整套57项，本库未新建。

原固定7a CI39615500598实际11项success，九原产物独立13453例/7657方法、143/110/11/424242、55SQL及网络15拒绝零泄露通过；原99e13403/7651全留，只增50/6。be0 CI39639479119继续按真实终态另核，本批新固定full仍待推送。旧7a有界可见失败及后台通过都只按其原范围引用，新候选原生/可见双端/正常得分/网络重连/完整回放和Windows实机仍分别OPEN。

本轮完整CN1504字段/QA、EN报告1416实际1408的分页/整表/SSR与默认语言额外探测，均与最近已登记版本一致；英文八缺口继续OPEN。中文当前目录14项与全部16已知来源版本未换版，七HTTP304，其他原字节同哈希不存重复PDF。GLOBAL Rules Hub正文和修订与已登记版本一致，新相关文章轮播不是核心换版。

新GLOBAL/en-US公告Riftbound x K/DA: Couture Collection Drawing FAQ为独立补充：声明UTC10-21 16:00，浏览器本地显示10/22；两正文加八折叠问答实际读取，官方头图实际查看可见四传奇及一战场，小字不足以确认精确印次。五公告名称在当前图库找到13条同名同类型候选，不等于已确认Couture印次；购买登记和发货日期不充当游戏生效或合法日期。为Evelynn、Ahri、Akali、Kai’Sa与Packed Amphitheater各登记一项精确身份/适用性OPEN门禁，#86保留；不将五者等同旧八缺口，不凭名字合并目录，不把139中文新闻改成全球140条。[独立补充manifest](evidence/room-seat-journal-inputs-2026-10-22/global-kda-couture-source-supplement.json)保留原页面、修订、取得时间和哈希。

原161审查、245门禁与七增量对象完整；28旧上下文原样、48仅更新当前实现绑定并留完整旧对象，原来源、证据、验证源、分支与CI历史声明不覆盖。旧#85原反例另外挂当前限定修复阶段，未升整卡或产品完成；冰霜要塞控制者#84仍未修。新增21行为和五全球公告来源缺口至17114义务，162审查/77上下文/250门禁/七增量，semanticCoverageCertified=false。只保留最新可用7a双端及每平台一包，未下载已被本批功能替代的be0安装包；本批档案不复制SDK、安装器或共享运行依赖。
'''
(root / doc).write_text(document)
status = root / 'docs/PROJECT_STATUS.md'; original_status = status.read_text()
prefix = '''2026-10-22 本批：[原始入座日志与原子持久化](ROOM_SEAT_JOURNAL_INPUTS_AUDIT_2026-10-22.md)。真实异步入房记录服务端ROOM_SEAT并从原EMPTY/私有种子回放，保留客户端拒绝原文与独立篡改验证；暖/冷保留intent保护。新未提交候选的元数据先落库幽灵座位反例完整保留，最终玩家/令牌哈希/日志同事务，非原子组合写前拒绝，孤立当前元数据不合成座位；旧局不迁移。

新21/9；唯一check13369/7530实际13363过六旧Hub夹具失败，零跳过、3336/1419/23稳定，原结果留存；精确校准输入/计数并保留全部断言后focus358/279全过，无第二check。实际47e身份下110原配对完整通过，原九源码/143方法/十一牌组/424242完整。六真实SQL40命令84事件41冷恢复，含首人/第二人实际SQL失败七表回滚；独立36历史/48快照48提示及全原前缀、24结构拒绝通过。原开局类另9/29、七冷恢复四种子篡改通过；原331审计/66原生均保留，库正常停止。

固定7a整次11项success，九原产物独立13453/7657、55SQL、网络15/0；be0及本批新固定full仍按实际终态分开。新GLOBAL K/DA公告五身份与13同名候选分开，五精确印次/适用性门禁OPEN；CN1504/EN1408和16文档、GLOBAL hub未换版，旧英文八缺口/139中文新闻范围保留。原161审查/245门禁/七增量完整，28上下文原样/48仅刷新当前实现绑定留完整旧对象；原17088义务全留加21行为和五来源缺口至17114，162审查77上下文250门禁，语义false。当前固定产品/可见双端/Windows与冰霜要塞#84仍OPEN，#85只挂限定修复阶段。仅最新可用双端及每平台一包，无新SDK/工作树/数据库。Goal active / NOT READY。

以下原批按原范围与当时终态保留。

'''
assert original_status.startswith('# 当前项目状态\n\n')
status.write_text('# 当前项目状态\n\n' + prefix + original_status[len('# 当前项目状态\n\n'):])
print('Published bounded room-seat engineering review and five separate global source gaps; expected17114; original failures and all old obligations retained; fixed full/products remain pending.')
