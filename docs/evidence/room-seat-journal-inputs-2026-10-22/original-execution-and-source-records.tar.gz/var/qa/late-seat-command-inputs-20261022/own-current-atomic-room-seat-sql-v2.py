from pathlib import Path
import ast, datetime, fcntl, hashlib, json, os, plistlib, resource, socket, subprocess

resource.setrlimit(resource.RLIMIT_CORE, (0, 0)); os.umask(0o077)
root = Path('/Users/dinghaolin/MyProjects/riftbound'); w = Path(__file__).resolve().parent
pg = Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin'); cluster = root / 'var/qa/permanent-play-here-base-20261017/postgres'
sock = Path('/tmp/rft-here-family-20261018-55486')
tables = ['matches', 'match_players', 'command_log', 'game_events', 'state_snapshots', 'snapshots', 'action_prompts']
read_env = dict(os.environ, PGOPTIONS='-c default_transaction_read_only=on')
load = lambda p: json.loads(p.read_text()); sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
definition = root / 'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes = [n for n in ast.parse(definition.read_text()).body if isinstance(n, ast.FunctionDef) and n.name in {'query', 'rooms', 'digests', 'observe_lock'}]
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(definition), 'exec'), globals())
frozen = load(w / 'current-room-seat-frozen-runtime-inputs-v2.json'); runtime = Path(frozen['runtimeRoot'])
prior = load(w / 'failed-first-seat-real-sql-counterexample-owner-terminal-v1.json')
old_audit, old_native = prior['actualAuditRoomsAtStop'], prior['actualNativeRoomsAtStop']
assert len(old_audit) == 323 and len(old_native) == 66 and prior['ownPostgresStopped']
stable = lambda: all(sha(runtime / p) == h for p, h in frozen['runtimeFiles'].items()) and all(sha(root / p) == h and oct((root / p).stat().st_mode & 0o777) == frozen['sourceInputModes'][p] for p, h in frozen['sourceInputHashes'].items())
guard = (root / 'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a'); fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
terminal = w / 'actual-current-room-seat-sql-owner-terminal-v2.json'; assert not terminal.exists()
proof = {'status': 'RUNNING_CURRENT_SIX_ROOM_SEAT_SQL_CASES_WITH_ATOMIC_ROLLBACK_AND_ORPHAN_REFUSAL', 'startedAtUtc': now(),
         'parentCommit': frozen['parentCommit'], 'actualRuleInputs': frozen['actualRuleInputs'],
         'declaredUncommittedAtomicRoomSeatBatch': True, 'lockAtStart': observe_lock(),
         'allOriginalRoomsSeedsInputsAndAcceptedHistoriesRetained': True,
         'original56SqlIdentitiesAndOrderRetainedOnly57Appended': True}
started = False; power = writer = reader = None; before_audit = before_native = None
try:
    assert stable() and subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), 'status'], capture_output=True).returncode == 3
    with socket.socket() as s: assert s.connect_ex(('127.0.0.1', 15847)) != 0
    power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())]); sock.mkdir(exist_ok=True)
    subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-l', str(w / 'current-room-seat-postgres-v2.log'), '-o', f'-p 55486 -h 127.0.0.1 -k {sock}', '-w', 'start'], capture_output=True, check=True); started = True
    assert rooms('riftbound_acceptance') == old_audit and rooms('riftbound_here_native') == old_native
    before_audit = digests('riftbound_acceptance', old_audit); before_native = digests('riftbound_here_native', old_native)
    (w / 'original323-audit66-native-seven-table-baseline-v2.json').write_text(json.dumps({'atUtc': now(), 'auditRooms': old_audit, 'nativeRooms': old_native, 'auditSevenTables': before_audit, 'nativeSevenTables': before_native}, indent=2))
    output = w / 'actual-current-room-seat-sql-v2'; assert not output.exists()
    env = dict(os.environ, ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit', RIFTBOUND_POSTGRES_EVIDENCE=str(output), DOTNET_DbgEnableMiniDump='0')
    command = ['/Users/dinghaolin/.dotnet/dotnet', str(runtime / 'Riftbound.PostgresAcceptance.dll'), '--room-seat-journal-only']; proof['actualWriterCommand'] = command
    with (w / 'actual-current-room-seat-writer-v2.log').open('xb') as log:
        writer = subprocess.Popen(command, cwd=runtime, env=env, stdout=log, stderr=subprocess.STDOUT); proof['writerExitCode'] = writer.wait(timeout=900)
    assert proof['writerExitCode'] == 0
    receipts = [load(p) for p in (output / 'room-seat-journal').rglob('receipt.json')]
    ordinary = [r for r in receipts if 'reverse' in r]; atomic = [r for r in receipts if 'atomicFirst' in r]
    assert len(receipts) == 6 and len(ordinary) == 4 and {(r['reverse'], r['late']) for r in ordinary} == {(False,False),(False,True),(True,False),(True,True)}
    assert len(atomic) == 2 and {r['atomicFirst'] for r in atomic} == {False, True}
    assert all(r['commands'] == r['coldRecoveries'] == r['noOpKnownPlayerJoins'] == 9 and r['preGameDirectAtomicRejections'] == 1 and r['independentStructuralRejections'] == 36 for r in ordinary)
    assert all(r['commands'] == 2 and r['events'] == 2 and r['actualSqlCheckViolation'] and r['originalSevenTableRowsExactAfterRollback'] and r['temporarySqlConstraintRemoved'] and r['originalUnacceptedAttemptRetained'] for r in atomic)
    assert all(r['actualRuleInputs'] == frozen['actualRuleInputs'] for r in receipts)
    unsupported = load(output / 'room-seat-journal/unsupported-nonatomic-journal-rejection.json')
    metadata = load(output / 'room-seat-journal/metadata-only-current-room-rejection.json')
    assert unsupported['status'] == 'PASS_NONATOMIC_DURABLE_JOURNAL_REJECTED_BEFORE_ANY_WRITE' and not unsupported['journalCalled'] and all(v == 0 for v in unsupported['actualSevenTableCounts'].values())
    assert metadata['status'] == 'PASS_CURRENT_IDENTITY_METADATA_WITHOUT_ORIGINAL_ROOM_JOURNAL_REJECTED_NOT_MIGRATED' and metadata['originalSqlRowsBefore'] == metadata['originalSqlRowsAfter']
    for receipt in [unsupported, metadata]:
        actual = receipt['actualRuleInputs']
        if set(actual) == {k[0].upper() + k[1:] for k in frozen['actualRuleInputs']}:
            actual = {k[0].lower() + k[1:]: v for k, v in actual.items()}
        assert actual == frozen['actualRuleInputs'], 'All seven original identity fields exact; receipt default/Web property casing only.'
    added = {r['room'] for r in receipts} | {metadata['room']}
    assert len(added) == 7 and set(rooms('riftbound_acceptance')) == set(old_audit) | added and rooms('riftbound_here_native') == old_native
    proof.update(writerCases=6, originalInterleavingCases=4, atomicRollbackCases=2, unsupportedDurableJournalRejectionsBeforeAnyWrite=1,
                 currentIdentityMetadataOnlyRefusals=1, receipts=receipts, commands=sum(r['commands'] for r in receipts), events=sum(r['events'] for r in receipts),
                 coldRecoveries=sum(r['coldRecoveries'] for r in receipts), noOpKnownPlayerJoins=36, preGameDirectAtomicRejections=4,
                 writerIndependentStructuralRejections=144, newRooms=sorted(added), unsupportedOriginalReceipt=unsupported, metadataOnlyOriginalReceipt=metadata)
    result = w / 'independent-current-room-seat-all-live-input-history-v2.json'
    command = ['/Users/dinghaolin/.dotnet/dotnet', 'exec', '--depsfile', str(runtime / 'Riftbound.PostgresAcceptance.deps.json'), '--runtimeconfig', str(runtime / 'Riftbound.PostgresAcceptance.runtimeconfig.json'), str(runtime / 'CurrentRoomSeatIndependentReaderV3.dll'), str(output / 'room-seat-journal'), str(result)]; proof['actualReadOnlyIndependentCommand'] = command
    with (w / 'independent-current-room-seat-all-live-input-history-v2.log').open('xb') as log:
        reader = subprocess.Popen(command, cwd=runtime, env=env, stdout=log, stderr=subprocess.STDOUT); proof['independentExitCode'] = reader.wait(timeout=900)
    assert proof['independentExitCode'] == 0
    actual = load(result)
    assert actual['cases'] == 6 and actual['commands'] == proof['commands'] == 40 and actual['events'] == proof['events'] == 84
    assert actual['authoritativeHistoricalStates'] == 36 and actual['privateSnapshots'] == actual['privatePrompts'] == 48 and actual['independentStructuralRejections'] == 24
    assert actual['unsupportedNonAtomicJournalRefusals'] == actual['currentIdentityOrphanMetadataRefusals'] == 1
    assert actual['actualReadOnlyConnection'] and actual['originalLivePrePersistenceInputsUsedAsExpected'] and actual['actualRuleInputs'] == frozen['actualRuleInputs']
    assert set(actual['rooms']) == {r['room'] for r in receipts}
    proof.update(independentReadback=actual, status='PASS_CURRENT_SIX_ROOM_SEAT_SQL_CASES_ATOMIC_ROLLBACKS_TWO_NO_WRITE_OR_NO_MIGRATION_GUARDS_ALL_ORIGINAL_LIVE_INPUTS_AND_REPLAYS')
except BaseException as e:
    proof.update(status='FAILED_CURRENT_ATOMIC_ROOM_SEAT_SQL_OR_INDEPENDENT_READBACK_ALL_ORIGINALS_RETAINED', errorType=type(e).__name__, error=str(e)); raise
finally:
    for process in [writer, reader]:
        if process and process.poll() is None: process.terminate(); process.wait(timeout=20)
    if started:
        try:
            if before_audit is not None: proof['allOriginal323AuditSevenTablesExactAtStop'] = digests('riftbound_acceptance', old_audit) == before_audit
            if before_native is not None: proof['allOriginal66NativeSevenTablesExactAtStop'] = digests('riftbound_here_native', old_native) == before_native
            proof['actualAuditRoomsAtStop'] = rooms('riftbound_acceptance'); proof['actualNativeRoomsAtStop'] = rooms('riftbound_here_native')
        finally:
            proof['ownPostgresNormalStopExitCode'] = subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-m', 'fast', '-w', 'stop'], capture_output=True).returncode
            proof['ownPostgresStopped'] = subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), 'status'], capture_output=True).returncode == 3
    if power:
        if power.poll() is None: power.terminate()
        power.wait(timeout=10)
    proof.update(finishedAtUtc=now(), lockAtStop=observe_lock(), allFrozenSourceAndRuntimeInputsStable=stable()); terminal.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
print(proof['status'], flush=True)
