from pathlib import Path
import datetime, hashlib, json, os, resource, subprocess

resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
w = Path(__file__).resolve().parent
root = Path('/Users/dinghaolin/MyProjects/riftbound')
load = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
f = load(w / 'current-room-seat-frozen-runtime-inputs-v2.json')
r = Path(f['runtimeRoot'])
stable = lambda: all(sha(r / p) == h for p, h in f['runtimeFiles'].items()) and all(sha(root / p) == h for p, h in f['sourceInputHashes'].items())
terminal = w / 'original-all110-pairs-owner-terminal-v2.json'
result = w / 'original-all110-pairs-result-v2.json'
assert not terminal.exists() and not result.exists() and stable()
assert not (r / 'Riftbound.PostgresAcceptance.deps.json').is_symlink()
command = ['/Users/dinghaolin/.dotnet/dotnet', 'exec', '--depsfile', str(r / 'Riftbound.PostgresAcceptance.deps.json'), '--runtimeconfig', str(r / 'Riftbound.PostgresAcceptance.runtimeconfig.json'), str(r / 'CurrentControllerOriginalAll110PairRunnerV1.dll'), str(result)]
proof = {'status': 'RUNNING_CURRENT_ROOM_SEAT_ALL110_ORIGINAL_HELPER_DIRECTIONS', 'startedAtUtc': now(), 'parentCommit': f['parentCommit'], 'actualRuleInputs': f['actualRuleInputs'], 'command': command, 'sameOriginal143PublicMethodsNineSources110Pairs11DecksSeed424242AndAssertionsRetained': True, 'notFullCiOrVisiblePhysicalWindowsCertification': True}
power = process = None
try:
    power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())])
    with (w / 'original-all110-pairs-v2.log').open('xb') as log:
        process = subprocess.Popen(command, cwd=r, env=dict(os.environ, DOTNET_DbgEnableMiniDump='0'), stdout=log, stderr=subprocess.STDOUT)
        proof['exitCode'] = process.wait(timeout=10800)
    assert proof['exitCode'] == 0
    d = load(result)
    assert d['status'] == 'PASS_CURRENT_CONTROLLER_ALL110_ORIGINAL_PAIR_HELPERS_NOT_ALL143_PUBLIC_METHODS_OR_FULL_CI'
    assert d['seed'] == 424242 and d['originalDeckCount'] == 11 and d['originalFullMatrixPairCount'] == 110
    assert len(d['completed']) == len(d['selectedPairs']) == 110
    expected_pascal={k[0].upper()+k[1:]:v for k,v in f['actualRuleInputs'].items()}
    assert d['actualRuleInputs'] == expected_pascal, 'Original helper uses the exact PascalCase identity schema; all seven fields must match the independently measured actual current inputs.'
    assert stable()
    proof.update(status='PASS_CURRENT_ROOM_SEAT_ALL110_ORIGINAL_PAIR_HELPERS_NOT_ALL143_PUBLIC_METHODS_OR_FULL_CI', unchangedOriginalHelperResultStatus=d['status'], resultSha256=sha(result), actualOriginalDirections=110, allFrozenRuntimeAndSourceHashesStable=True)
except BaseException as error:
    proof.update(status='FAILED_CURRENT_ORIGINAL_PAIR_RUN_ORIGINALS_RETAINED_NO_FALSE_FULL_CI_PASS', errorType=type(error).__name__, error=str(error))
    raise
finally:
    if process and process.poll() is None:
        process.terminate()
        process.wait(timeout=20)
    if power:
        if power.poll() is None: power.terminate()
        power.wait(timeout=10)
    proof.update(finishedAtUtc=now(), allFrozenRuntimeAndSourceHashesStable=stable())
    terminal.write_text(json.dumps(proof, ensure_ascii=False, indent=2))
print(proof['status'], flush=True)
