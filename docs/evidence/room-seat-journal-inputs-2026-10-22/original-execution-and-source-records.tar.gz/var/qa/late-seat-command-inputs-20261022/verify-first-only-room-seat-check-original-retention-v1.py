from pathlib import Path
import collections, datetime, hashlib, json, subprocess, xml.etree.ElementTree as ET

root = Path('/Users/dinghaolin/MyProjects/riftbound')
w = Path(__file__).resolve().parent
load = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
pin = lambda p: {'path': str(p.relative_to(root)), 'sha256': sha(p)}
ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}

def read(path):
    tree = ET.parse(path)
    defs = {r.get('id'): r.find('t:TestMethod', ns).attrib for r in tree.findall('.//t:UnitTest', ns)}
    rows = tree.findall('.//t:UnitTestResult', ns)
    return rows, collections.Counter(r.get('testName') for r in rows), {
        defs[r.get('testId')]['className'] + '.' + defs[r.get('testId')]['name'] for r in rows}

start = load(w / 'only-check-start-inputs-v1.json')
end = load(w / 'only-check-owner-terminal-v1.json')
assert all(end[k] for k in ['all3336SourceHashesAndModesStable',
                           'all1419ConformanceRuntimeInputsStable', 'all23NativeDebugRuntimeInputsStable'])
baseline = root / start['originalBaselineTrx']
assert sha(baseline) == start['originalBaselineTrxSha256']
trx = w / 'only-check-v1/check/results.trx'
rows, counts, methods = read(trx)
oldrows, oldcounts, oldmethods = read(baseline)
assert (len(rows), len(methods), len(oldrows), len(oldmethods)) == (13369, 7530, 13348, 7521)
assert not oldcounts - counts and oldmethods <= methods
added = counts - oldcounts
assert sum(added.values()) == 21 and len(methods - oldmethods) == 9
assert all('RoomSeatJournalTests.' in name for name in added)
focusrows, _, _ = read(w / 'room-seat-focus-v5/focus/results.trx')
assert len(focusrows) == 95 and all(r.get('outcome') == 'Passed' for r in focusrows)
assert set(added) == {r.get('testName') for r in focusrows if 'RoomSeatJournalTests.' in r.get('testName')}
frozen = load(w / 'current-room-seat-frozen-runtime-inputs-v1.json')
assert frozen['sourceInputHashes'] == start['sourceInputHashes']
assert len(frozen['sourceInputHashes']) == 3336
assert all(sha(root / p) == h and oct((root / p).stat().st_mode & 0o777) == frozen['sourceInputModes'][p]
           for p, h in frozen['sourceInputHashes'].items())
original = load(w / 'pre-change-current-be0e-room-input-source-retention-v1.json')
changed = [p for p, h in original['allOriginalConformanceInputs'].items() if sha(root / p) != h]
calibration = 'tests/Riftbound.ConformanceTests/OpeningRandomizationTests.cs'
assert changed == [calibration]
old = subprocess.check_output(['git', 'show', frozen['parentCommit'] + ':' + calibration], cwd=root).decode()
before = '        var initial = MatchReplayInitialStateBuilder.FromSeats(session.RoomId,\n            new Dictionary<string, string> { ["alice"] = "P1", ["bob"] = "P2" }) with { Seed = seed };'
after = '        // Durable room entries now precede both original deck submissions.\n        var initial = MatchState.Create(session.RoomId) with { Seed = seed };'
assert old.count(before) == 1
expected = old.replace(before, after).replace('        foreach (var player in initial.Seats.Keys)', '        foreach (var player in new[] { "alice", "bob" })')
assert (root / calibration).read_text() == expected
full = {p: h for p, h in original['allOriginalConformanceInputs'].items() if '/FullGameEndToEndTests' in p}
assert len(full) == 9
for p, h in full.items():
    assert sha(root / p) == h and (root / p).read_bytes() == subprocess.check_output(['git', 'show', frozen['parentCommit'] + ':' + p], cwd=root)
pairs = load(w / 'original-all110-pairs-owner-terminal-v1.json')
assert pairs['actualOriginalDirections'] == 110 and pairs['exitCode'] == 0 and pairs['allFrozenRuntimeAndSourceHashesStable']
failed = [r for r in rows if r.get('outcome') != 'Passed']
outcomes = dict(collections.Counter(r.get('outcome') for r in rows))
proof = {
    'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'ONLY_CHECK_COMPLETE_ORIGINAL_CASES_METHODS_AND_INPUTS_RETAINED_FAILURES_NOT_RELABELED' if failed else 'ONLY_CHECK_AND_EXACT_ORIGINAL_RETENTION_PASS',
    'exitCode': end['exitCode'], 'actualCases': len(rows), 'actualMethods': len(methods),
    'outcomes': outcomes, 'actualFailedOrNonPassed': [r.get('testName') for r in failed],
    'oldCases': len(oldrows), 'oldMethods': len(oldmethods),
    'oldExactCaseMultisetAndMethodsRetained': True,
    'newCases': 21, 'newMethods': 9, 'newMethodNames': sorted(methods - oldmethods),
    'actualNewCaseIdentities': sorted(added.elements()),
    'onlyCheckTrx': pin(trx), 'originalBaselineTrx': pin(baseline),
    'all3336SourcesAndModes1419Conformance23NativeDebugInputsStable': True,
    'soleOriginalSeedFixtureCalibrationBeforeCheck': {'path': calibration, 'oldSha256': original['allOriginalConformanceInputs'][calibration], 'newSha256': sha(root / calibration), 'allOriginalMethodsAndAssertionsRetained': True},
    'allNineOriginalFullGameSourcesExact': full,
    'all143OriginalPublicFullMethods110Pairs11Decks424242VictoryAndReplayAssertionsRetained': True,
    'all110OriginalPairHelperDirectionsExecutedSeparately': pin(w / 'original-all110-pairs-owner-terminal-v1.json'),
    'failureCorrectionsAndTheirTargetedRetestPending': bool(failed),
    'noSecondCheck': True, 'newFixedFullNativeProductAndPhysicalWindows': 'OPEN',
}
target = w / 'first-only-check-original-case-method-and-input-retention-v1.json'
with target.open('x') as stream:
    json.dump(proof, stream, ensure_ascii=False, indent=2)
print(json.dumps({k: proof[k] for k in ['status', 'actualCases', 'actualMethods', 'outcomes', 'newCases', 'newMethods']}, ensure_ascii=False))
