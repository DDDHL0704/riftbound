from pathlib import Path
import datetime, gzip, hashlib, json, shutil

root = Path('/Users/dinghaolin/MyProjects/riftbound'); w = Path(__file__).resolve().parent
ev = root / 'docs/evidence/room-seat-journal-inputs-2026-10-22'
load = lambda p: json.loads(p.read_text()); sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert load(ev / 'independent-publication-and-retention-verification.json')['remainingObligationIds'] == 17114
folders = ['probe-source-v1', 'independent-reader-source-v1', 'room-seat-failed-journal-sql-probe-source-v1',
           'independent-reader-source-v3', 'current-private-opening-only-runner-source-v1']
targets = [w / folder / name for folder in folders for name in ['bin', 'obj']]
assert all(p.is_dir() and p.resolve().is_relative_to(w) for p in targets)
runtimes = [p for p in w.iterdir() if p.is_dir() and 'runtime' in p.name.lower()]
runtime_files = {str(p): sha(p) for folder in runtimes for p in folder.rglob('*') if p.is_file()}
for name in runtime_files:
    resolved = Path(name).resolve()
    assert not any(resolved.is_relative_to(target.resolve()) for target in targets), name
retained = load(w / 'executed-own-probe-and-reader-bits-retention-v1.json')['bits']
for row in retained:
    assert sha(root / row['retained']['path']) == row['retained']['sha256'] == row['original']['sha256']
raw_gov = w / 'postpublication-current-governance-v1.json'
assert gzip.decompress((ev / 'final-governance.json.gz').read_bytes()) == raw_gov.read_bytes()
rows = []
for folder in targets:
    for path in sorted(folder.rglob('*')):
        if path.is_file():
            rows.append({'path': str(path.relative_to(root)), 'bytes': path.stat().st_size, 'sha256': sha(path),
                         'purpose': 'UNUSED_REGENERABLE_OWN_HELPER_BUILD_OUTPUT_ACTUAL_EXECUTED_BITS_AND_CONTROL_METADATA_ALREADY_RETAINED'})
rows.append({'path': str(raw_gov.relative_to(root)), 'bytes': raw_gov.stat().st_size, 'sha256': sha(raw_gov),
             'purpose': 'EXACT_DUPLICATE_OF_VERIFIED_CANONICAL_LOSSLESS_GOVERNANCE_GZIP'})
for folder in targets: shutil.rmtree(folder)
raw_gov.unlink()
assert all(sha(Path(name)) == h for name, h in runtime_files.items())
source = load(w / 'current-room-seat-frozen-runtime-inputs-v2.json')
assert all(sha(root / p) == h for p, h in source['sourceInputHashes'].items())
proof = {'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'RETIRED_ONLY_UNUSED_OWN_HELPER_BIN_OBJ_AND_EXACT_CANONICAL_GOVERNANCE_DUPLICATE',
    'retiredDirectories': [str(p.relative_to(root)) for p in targets], 'files': rows,
    'fileCount': len(rows), 'logicalBytes': sum(r['bytes'] for r in rows),
    'allMeasuredFrozenRuntimeFilesUnchanged': True, 'all3336CurrentSourceInputsUnchanged': True,
    'allExecutedOwnPayloadsRetainedInCanonicalArchiveAndMeasuredRuntimes': True,
    'allSourcesTestsTheoryRowsSeedsOriginalFailuresLogsCiOriginalsAndDatabasesRetained': True,
    'noSdkWorktreeApplicationOrInstallerCreatedOrRemoved': True, 'physicalApfsReclamationNotInferred': True}
with (ev / 'obsolete-owned-build-cache-and-duplicate-governance-retirement.json').open('x') as f:
    json.dump(proof, f, ensure_ascii=False, indent=2)
print('Retired', len(rows), 'unused/duplicate files,', proof['logicalBytes'], 'logical bytes; all runtime/source evidence stable.')
