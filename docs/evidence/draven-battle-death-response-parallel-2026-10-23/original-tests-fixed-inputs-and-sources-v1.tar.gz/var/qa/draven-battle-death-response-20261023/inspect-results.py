from pathlib import Path
import gzip,json,xml.etree.ElementTree as E
Q=Path(__file__).parent;ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
p=Q/'focus-v3/focus/results.trx'
if not p.exists():print('RUNNING');raise SystemExit
r=E.parse(p);print('COUNTERS',r.find('.//t:Counters',ns).attrib)
def gameplay(x):
 if isinstance(x,dict):return {k:gameplay(v)for k,v in x.items()if k not in ('implementationSha256','identitySha256','recordedAt','rulesetVersion')}
 if isinstance(x,list):return [gameplay(v)for v in x]
 return x
proof=[]
for p in sorted((Q/'original-v3').glob('*.gz')):
 x=json.load(gzip.open(p,'rt'));es=[e['event']for e in x['events']];proof.append({'caseId':x['caseId'],'scenario':x['scenario'],'commands':len(x['commands']),'events':len(es),'prefixes':x['originalPrefixReplayCount'],'failure':x['failure']})
 assert x['originalPrefixReplayCount']==len(x['commands'])==len(x['entries'])==len(x['states']) and all(c['accepted']for c in x['commands'])
 if x['scenario'].startswith('response-'):
  print('NEW',proof[-1]);print('DAMAGE',[e['payload']for e in es if e['kind']=='DAMAGE_APPLIED'])
 else:
  prior=json.load(gzip.open(Q.parent/'draven-battle-death-score-20261023/original-v2'/p.name,'rt'))
  for k in ['initial','states','entries','commands','events','originalPrefixReplayCount','failure']:
   assert gameplay(prior[k])==gameplay(x[k]),(p.name,k)
print('TOTALS',{k:sum(x[k]for x in proof)for k in ('commands','events','prefixes')})
with(Q/'inspected-final-v3.json').open('x')as f:json.dump(proof,f,ensure_ascii=False,indent=2)
