from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,tarfile,io,subprocess,xml.etree.ElementTree as E
R=Path.cwd();Q=R/'var/qa/draven-battle-death-response-20261023';D=R/'docs/evidence/draven-battle-death-response-parallel-2026-10-23';D.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def trx(p):
 r=E.parse(p);return {'sha256':sha(p.read_bytes()),'counters':r.find('.//t:Counters',ns).attrib,'cases':[{'name':x.get('testName'),'outcome':x.get('outcome'),'failure':x.find('.//t:Message',ns).text if x.find('.//t:Message',ns)is not None else None}for x in r.findall('.//t:UnitTestResult',ns)]}
runs={k:trx(Q/k/'focus/results.trx')for k in ['focus-v1','focus-v2','focus-v3','damage-adjacent-v3']}
for k,total,passed,failed in [('focus-v1',18,4,14),('focus-v2',18,4,14),('focus-v3',20,4,16)]:
 c=runs[k]['counters'];assert c['total']==str(total)and c['passed']==str(passed)and c['failed']==str(failed)and c['notExecuted']=='0'
adj=runs['damage-adjacent-v3']['counters'];assert adj['total']==adj['passed']and adj['failed']=='0'and adj['notExecuted']=='0'
receiptPath=R/'var/qa/battle-win-combined-20261023/applied-peer-fixed-n52-first45-v1.json';receipt=json.load(receiptPath.open());peer=Path(receipt['overlaySource']);assert sha(peer.read_bytes())==receipt['overlaySha256']
for f in receipt['files']:assert sha((R/f['path']).read_bytes())==f['afterSha256']
proof=json.load((Q/'inspected-final-v3.json').open());assert len(proof)==20 and sum(x['commands']for x in proof)==100 and sum(x['events']for x in proof)==318
ruleInputs=[]
for p in sorted((Q/'original-v3').glob('*.json.gz')):
 a=json.loads(gzip.decompress(p.read_bytes()));assert a['originalPrefixReplayCount']==len(a['commands'])==len(a['entries'])==len(a['states']);assert a['initial']['seed']==424242 and all(c['accepted']for c in a['commands'])
 events=[e for entry in a['entries']for e in entry['events']];assert events==[e['event']for e in a['events']]
 s=a['states'][-1];sc=a['scenario'];deaths=[e for e in events if e['kind']=='UNIT_DESTROYED'and e['payload'].get('targetObjectId')=='SOURCE']
 if sc=='response-void-gate-damage':
  assert not deaths and 'SOURCE'in s['playerZones']['P1']['battlefields']and s['cardObjects']['SOURCE']['damage']==2 and 'Expected: 3\nActual:   2'in a['failure']
 elif sc=='response-damage-death':
  ds=[e['payload']['damage']for e in events if e['kind']=='DAMAGE_APPLIED'and e['payload'].get('targetObjectId')=='SOURCE'];assert ds==[2,2,2]and len(deaths)==1 and 'SOURCE'in s['playerZones']['P1']['graveyard']
  assert all(c['commandType']!='DECLARE_BATTLE'for c in a['commands'])and 'Expected: 1\nActual:   0'in a['failure']
 elif sc=='response-pass-death':assert len(deaths)==1 and 'Expected: 1\nActual:   0'in a['failure']
 for c in a['commands']:
  if c['ruleInputs']not in ruleInputs:ruleInputs.append(c['ruleInputs'])
assert len(ruleInputs)==1
assembly=R/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0/Riftbound.ConformanceTests.dll'
for k in ['focus-v3','damage-adjacent-v3']:assert json.load((Q/k/'plan.json').open())['testAssemblySha256']==sha(assembly.read_bytes())
source='tests/Riftbound.ConformanceTests/OfficialDravenBattleDeathScoreTests.cs';consumer='src/Riftbound.Engine/CoreRuleEngine.DravenBattleDeathScore.cs';assert(Q/'focus-v3/test-source.cs').read_bytes()==(R/source).read_bytes()
assert subprocess.check_output(['git','show','dd084dfd:'+consumer])==(R/consumer).read_bytes()
previous='docs/evidence/draven-battle-death-score-parallel-2026-10-23/source-and-red-test-manifest.json'
extra=[source,consumer,'docs/DRAVEN_BATTLE_DEATH_RESPONSE_PARALLEL_2026-10-23.md',previous,
 'var/qa/draven-battle-death-score-20261023/captured-death-core-and-judge-clauses-v1.json',
 'var/qa/draven-battle-death-score-20261023/sources-v1/current-虚空之门-original-v1.json.gz',
 'var/qa/draven-battle-death-score-20261023/current-sfd-judge-faq-http-v1.json',
 'var/qa/draven-battle-win-score-20261023/current-core304-http-original-v1.json']
paths=[(str(p.relative_to(R)),p)for p in Q.rglob('*')if p.is_file()]+[(x,R/x)for x in extra]+[('inputs/peer-fixed-n52-first45-v1.tar.gz',peer),('inputs/applied-peer-fixed-n52-first45-v1.json',receiptPath)]
for name,p in paths:
 if 'current-'in p.name and p.name.endswith('-original-v1.json.gz'):
  a=json.loads(gzip.decompress(p.read_bytes()));assert sha(a['originalUtf8'].encode())==a['rawSha256']
archive=D/'original-tests-fixed-inputs-and-sources-v1.tar.gz';members=[]
with archive.open('xb')as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as tar:
   for name,p in sorted(paths):
    data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data));members.append({'path':name,'bytes':len(data),'sha256':sha(data)})
with tarfile.open(archive,'r:gz')as tar:
 for m in members:
  data=tar.extractfile(m['path']).read();assert len(data)==m['bytes']and sha(data)==m['sha256']
manifest={'status':'SOURCE_RED_DEATH_SCORE_14_AND_INDEPENDENT_VOID_GATE_DAMAGE_2','atUtc':datetime.now(timezone.utc).isoformat(),'baseCommit':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'region':'CN','language':'zh-CN','coreEffectiveDate':'2026-10-16','peerOverlay':receipt,'all19SharedInputsUnchanged':True,'actualRuleInputs':ruleInputs[0],'testAssemblySha256':sha(assembly.read_bytes()),'source':{'path':source,'sha256':sha((R/source).read_bytes())},'consumer':{'path':consumer,'sha256':sha((R/consumer).read_bytes()),'unchangedFromCommit':'dd084dfd','sharedCallSites':0},'originalRuns':runs,'finalOriginalHistories':proof,'cases':20,'methods':3,'passed':4,'deathScoreCases':18,'deathScoreSourceFailures':14,'deathScoreCommands':88,'deathScoreEvents':288,'independentDamageCases':2,'independentDamageSourceFailures':2,'independentDamageCommands':12,'independentDamageEvents':30,'originalCommands':100,'accepted':100,'originalPrefixReplays':100,'originalEvents':318,'damageAdjacentPassed':int(adj['passed']),'seed':424242,'prior14GameplayEqualExcludingOnly':['implementationSha256','identitySha256','recordedAt','rulesetVersion'],'originalIdentityValuesRetained':True,'originalV1FourWrongWindowPremiseFailuresAreNotEngineBugs':True,'originalV2TwoDamageFailuresDidNotReachDeath':True,'freshCompleteSourceRows':json.load((Q/'sources-v1/extra-rows.json').open())+json.load((Q/'sources-v3/extra-rows.json').open()),'currentVoidGateErratum':json.load((Q/'void-gate-current-erratum-binding-v1.json').open()),'deathHotFeprIntegrationStillOpen':True,'noExtraCheckOrFull':True,'noDatabaseExecution':True,'fullGameAcceptanceDeferredUntilIntegration':True,'backendGoalComplete':False,'sharedIntegrationOwner':'01a16770-8c1b-7da2-872b-a8ec5ae77413','archive':{'path':str(archive.relative_to(R)),'sha256':sha(archive.read_bytes()),'members':members}}
with(D/'source-and-red-test-manifest.json').open('x')as f:json.dump(manifest,f,ensure_ascii=False,indent=2)
print(manifest['status'],len(members),'members',archive.stat().st_size,'bytes;adjacent',adj['passed'])
