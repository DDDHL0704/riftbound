# coding: utf-8
"""Retire exactly superseded native package copies after new fixed native boot/payload proof."""
import datetime,hashlib,json,os,shutil,subprocess,zipfile
from pathlib import Path
os.umask(0o077)
r=Path.cwd();n=Path(__file__).resolve().parent;old=r/'var/qa/empty-reveal-followup-20261019'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
current=load(n/'native-app-inputs.json');prior=load(old/'native-app-inputs.json')
assert current['fixedCommit']=='08fd25c0dc643f9120b529f039feed69beffc251'
assert prior['fixedCommit']=='797f813c03a739141ba4a8fbe1bb9921337bd351'
assert load(n/'current-native-headless-boot-verification.json')['status']=='CURRENT_FIXED_DEFAULT_MAIN_HEADLESS_BOOT_PASS'
out=n/'prior-native-pair-retirement.json';assert not out.exists()
for root,proof,metadata_name in [(n,current,'fixed-native-artifact-index-v1.json'),(old,prior,'fixed-native-artifact-index-v1.json')]:
 for row in proof['apps']:
  app=Path(row['app']);assert app.parent==root and not app.is_symlink()
  assert all(sha(app/p)==value for p,value in proof['ciManagedAndPckPayloads'].items())
  subprocess.run(['codesign','--verify','--deep','--strict',str(app)],capture_output=True,check=True)
 metadata_doc=load(root/metadata_name);metadata=metadata_doc.get('index',metadata_doc)['artifacts']
 for row in proof['platformArchiveAndLogProof']:
  label=row['platform'];file=root/'native-current'/(label+'-ci-artifact.zip')
  item=next(x for x in metadata if x['name']=={'mac':'native-macos-latest','windows':'native-windows-latest'}[label])
  assert sha(file)==row['outerSha256'] and item['digest']=='sha256:'+sha(file) and file.stat().st_size==item['size_in_bytes']
  with zipfile.ZipFile(file) as archive:
   assert archive.testzip() is None
   for name,key in [('exported-boot.log','bootLogSha256'),('rune-table-lifecycle.log','lifecycleLogSha256')]:
    assert hashlib.sha256(archive.read('ci-logs/'+name)).hexdigest()==sha(root/'native-current/ci-logs'/label/name)==row[key]
processes=subprocess.check_output(['ps','-ax','-o','command='],text=True)
assert all(str(Path(row['app'])/'Contents/MacOS') not in processes for row in prior['apps'])
expected_apps={str(Path(row['app']).relative_to(r)) for proof in [current,prior] for row in proof['apps']}
assert {str(p.relative_to(r)) for p in (r/'var/qa').glob('*/*.app')}==expected_apps
expected_archives={str((root/'native-current'/(label+'-ci-artifact.zip')).relative_to(r)) for root in [n,old] for label in ['mac','windows']}
assert {str(p.relative_to(r)) for p in (r/'var/qa').glob('*/native-current/*-ci-artifact.zip')}==expected_archives
retained={str(p.relative_to(old)):sha(p) for p in old.rglob('*') if p.is_file() and not any(part.endswith('.app') for part in p.relative_to(old).parts) and p.name not in ['mac-ci-artifact.zip','windows-ci-artifact.zip']}
paths=[Path(row['app']) for row in prior['apps']]+[old/'native-current/mac-ci-artifact.zip',old/'native-current/windows-ci-artifact.zip']
targets=[]
for path in paths:
 assert path.exists() and path.is_relative_to(old) and not path.is_symlink()
 files=sorted(p for p in path.rglob('*') if p.is_file()) if path.is_dir() else [path]
 manifest={str(p.relative_to(path)) if path.is_dir() else p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in files}
 targets.append({'path':str(path.relative_to(r)),'logicalBytes':sum(p.stat().st_size for p in files),'allRemovedFileManifest':manifest,'originalBundleReceipt':str((old/'native-app-inputs.json').relative_to(r)),'originalBundleReceiptSha256':sha(old/'native-app-inputs.json')})
current_required={str(p.relative_to(n)):sha(p) for directory in ['fixed-api'] for p in (n/directory).rglob('*') if p.is_file()}
cluster=r/'var/qa/permanent-play-here-base-20261017/postgres';assert cluster.exists()
proof={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PREPARED_EXACT_FOUR_OBSOLETE_PACKAGE_TARGETS','newFixedCommit':current['fixedCommit'],'newRunId':39305210166,'oldFixedCommit':prior['fixedCommit'],'oldRunId':39248538363,'userInstruction':'Only latest usable native A/B and one Mac/Windows canonical archive; retain sources tests evidence original database and required runtimes.','newBothDefaultMainAndBundledCatalogHeadlessBootsPassed':True,'bothCandidatesAll373PayloadHashesAndDeepStrictSignaturesAndBothCanonicalArchiveShaCrcVerified':True,'oldAppProcessesAbsent':True,'retiredExactTargets':targets,'removedLogicalBytes':sum(row['logicalBytes'] for row in targets),'allOldNonPackageFilesRetainedExact':retained,'currentPublishedFunctionalInputsToRemainExact':current_required,'fullCiAndNewNetworkPairStillPendingAtRetirement':True,'newFixedReleaseTwoSqlBranchesAndIndependentReadOnlyAlreadyPassed':load(n/'real-sql-verification-v1.json')['status']=='PASS_REAL_SQL_FOUR_HWEI_ORIGINALS_AND_INDEPENDENT_READONLY_FULL_REPLAY','visibleControlsAndPairedNormalScoreAndPhysicalWindows':'OPEN','noDatabaseOrTestOrSourceRetirement':True}
out.write_text(json.dumps(proof,indent=2)+'\n')
before=shutil.disk_usage(r).free
for path in paths:
 if path.is_dir():shutil.rmtree(path)
 else:path.unlink()
after=shutil.disk_usage(r).free
assert all(not p.exists() for p in paths)
assert all(sha(old/p)==h for p,h in retained.items())
assert all(sha(n/p)==h for p,h in current_required.items()) and cluster.exists()
apps=sorted(str(p.relative_to(r)) for p in (r/'var/qa').glob('*/*.app'))
archives=sorted(str(p.relative_to(r)) for p in (r/'var/qa').glob('*/native-current/*-ci-artifact.zip'))
assert apps==sorted(str(Path(row['app']).relative_to(r)) for row in current['apps'])
assert len(archives)==2 and all(p.startswith(str(n.relative_to(r))) for p in archives)
proof.update(status='ONLY_LATEST_08FD_NATIVE_PAIR_AND_TWO_CANONICAL_ARCHIVES_RETAINED',observedFreeDeltaBytes=after-before,freeDeltaMayIncludeConcurrentActivity=True,allOldNonPackageEvidenceAndRequiredRuntimesStillExact=True,currentFunctionalPublishedInputsStillExact=True,onlyLatestNativeApps=apps,onlyLatestCanonicalArchives=archives,originalDatabaseRetained=True)
out.write_text(json.dumps(proof,indent=2)+'\n')
print({k:proof[k] for k in ['status','removedLogicalBytes','observedFreeDeltaBytes','onlyLatestNativeApps','onlyLatestCanonicalArchives']})
