"""Exercise both current exported Godot Main applications while desktop tools are locked."""
import ast, fcntl, hashlib, json, os, runpy, socket, subprocess, time, urllib.request, uuid
from pathlib import Path
os.umask(0o077)
n=Path(__file__).resolve().parent;c=runpy.run_path(str(n/'fixed_08fd_native_common.py'))
sha,load,write,now=[c[k] for k in ['sha','load','write','now']]
out=n/'exported-stale-retry-v2-verification-v1.json';assert not out.exists()
apps=load(n/'native-app-inputs.json');identity=c['identity']
for app in apps['apps']:
    assert all(sha(Path(app['app'])/p)==h for p,h in apps['ciManagedAndPckPayloads'].items())
    subprocess.run(['codesign','--verify','--deep','--strict',app['app']],capture_output=True,check=True)
digests=c['digests'];pg,cluster,sock,dotnet,api,reader=[c[k] for k in ['pg','cluster','sock','dotnet','api','reader']]
for _ in range(1800):
    candidate=n/'real-sql-verification-v1.json'
    if candidate.exists():
        independent=load(candidate)
        if independent['status']!='RUNNING_NOT_ACCEPTANCE':break
    time.sleep(2)
else:raise AssertionError('Independent original SQL verification still pending.')
assert independent['status'].startswith('PASS') and independent['ownPostgresSmartStopped']
room='STALE2-08FD-NATIVE-'+uuid.uuid4().hex[:12]
guard=(n.parent/'ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof={'startedAtUtc':now(),'fixedCommit':c['publication']['fixedCommit'],'actualRuleInputs':identity,
       'fixedSqlIndependentReceiptSha256':sha(n/'real-sql-verification-v1.json'),'nativeInputsSha256':sha(n/'native-app-inputs.json'),'runnerSourceSha256':sha(Path(__file__)),
       'room':room,'lockAtStart':c['lock_observation'](),'status':'RUNNING_NOT_ACCEPTANCE',
       'currentDefaultHeadlessBootReceiptSha256':sha(n/'current-native-headless-boot-verification.json'),
       'scope':'Actual exported default Main pair under one bounded unmodified-payload localhost ordering fault. Hold original A mulligan until first B surrender is in flight; only forward that surrender after real A acceptance advances the authoritative tick. Require real stale rejection, actual native retry with a new prompt, both result views, normal exit and original SQL full replay. Visible, scoring and physical Windows remain separate.',
       'visibleControls':'OPEN','normalVisiblePairedScoring':'OPEN','physicalWindows':'OPEN'}
write(out,proof)
started=False;api_process=None;clients=[];power=None;proxy_process=None
proxy_root=n.parent/'public-reveal-wording-20261019'
proxy_inputs=load(proxy_root/'retry-fault-proxy-inputs-v2.json')
assert all(sha(proxy_root/p)==h for p,h in proxy_inputs['files'].items())
proof['faultProxyReusedFrozenIndependentTransportToolPath']=str(proxy_root/'retry-fault-proxy-inputs-v2.json')
proof['faultProxyInputsSha256']=sha(proxy_root/'retry-fault-proxy-inputs-v2.json')
try:
    power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    proof['boundIdleSleepAssertionPid']=power.pid
    assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
    subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(n/'exported-stale-retry-v2-postgres.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
    old_native=c['rooms']('riftbound_here_native');assert len(old_native)==32 and len(c['rooms']('riftbound_acceptance'))==172
    native_before=digests('riftbound_here_native');audit_before=digests('riftbound_acceptance')
    proof.update(priorNativeRooms=old_native,priorNativeSevenTables=native_before,priorAuditSevenTables=audit_before)
    with socket.socket() as port_guard:
        port_guard.settimeout(.5);assert port_guard.connect_ex(('127.0.0.1',15839))!=0
    with (n/'exported-stale-retry-v2-api.log').open('x') as log:
        api_process=subprocess.Popen([dotnet,str(api/'Riftbound.Api.dll')],cwd=api,
            env=dict(c['environment']('riftbound_here_native'),ASPNETCORE_ENVIRONMENT='Production',ASPNETCORE_URLS='http://127.0.0.1:15839'),stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    proof['ownApiPid']=api_process.pid
    for _ in range(100):
        assert api_process.poll() is None
        try:
            with urllib.request.urlopen('http://127.0.0.1:15839/health',timeout=1) as response:health=json.load(response)
            assert health['persistenceMode']=='postgres'
            assert set(subprocess.check_output(['/usr/sbin/lsof','-tiTCP:15839','-sTCP:LISTEN'],text=True).splitlines())=={str(api_process.pid)}
            break
        except OSError:time.sleep(.1)
    else:raise AssertionError('Own exact published API not ready.')
    with socket.socket() as proxy_guard:
        proxy_guard.settimeout(.5);assert proxy_guard.connect_ex(('127.0.0.1',15840))!=0
    with (n/'exported-stale-retry-v2-fault-proxy-v1.log').open('x') as log:
        proxy_process=subprocess.Popen([dotnet,str(proxy_root/'retry-fault-proxy-v2/bin/Release/net10.0/proxy.dll')],cwd=proxy_root/'retry-fault-proxy-v2/bin/Release/net10.0',stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    proof['ownLocalFaultProxyPid']=proxy_process.pid
    for _ in range(100):
        assert proxy_process.poll() is None
        try:
            with urllib.request.urlopen('http://127.0.0.1:15840/fault-evidence',timeout=1) as response:initial_fault=json.load(response)
            assert not initial_fault['heldAFirstMulligan'] and not initial_fault['heldBFirstSurrender']
            assert set(subprocess.check_output(['/usr/sbin/lsof','-tiTCP:15840','-sTCP:LISTEN'],text=True).splitlines())=={str(proxy_process.pid)}
            break
        except OSError:time.sleep(.1)
    else:raise AssertionError('Own bounded proxy not ready.')
    suffix=room.rsplit('-',1)[1];proof['nativeClients']=[]
    for row in apps['apps']:
        label=row['label'];executable=Path(row['app'])/'Contents/MacOS/符文战场'
        log=n/('exported-stale-retry-v2-'+label+'.log');profile=n/('never-written-exported-stale-retry-v2-'+label+'.json');assert not profile.exists()
        args=[str(executable),'--headless','--quit-after','3600','--','--riftbound-ephemeral-session','--riftbound-server=http://127.0.0.1:15840',
              '--riftbound-room='+room,'--riftbound-handle=retry'+label+suffix,'--riftbound-session-file='+str(profile),
              '--riftbound-smoke-auto-ready','--riftbound-smoke-auto-mulligan']
        if label=='b':args.append('--riftbound-smoke-auto-surrender')
        with log.open('x') as stream:
            client=subprocess.Popen(args,cwd='/tmp',stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
        clients.append(client);proof['nativeClients'].append({'label':label,'ownNativePid':client.pid,'log':log.name,'profile':profile.name,'app':row['app'],'defaultMain':True,'headless':True})
    write(out,proof)
    # The exported release buffers stdout when redirected. Wait for normal engine
    # frame-limit exit before reading the same original logs, without SIGTERM.
    for client in clients:
        assert client.wait(timeout=100)==0,'Original exported Godot did not quit normally.'
    texts=[(n/row['log']).read_text(errors='replace') for row in proof['nativeClients']]
    assert all('Match result rendered:' in text and 'MATCH_WON' in text for text in texts)
    assert api_process.poll() is None
    proof['bothNativeNormalExitCodes']=[client.returncode for client in clients]
    proof['actualStaleSurrenderRejectionThenNewPromptRetryObserved']=any('投降 receipt accepted=False' in text and '行动窗口已过期' in text and '投降 receipt accepted=True' in text and text.count('Auto smoke: submitting SURRENDER')>=2 for text in texts)
    assert proof['actualStaleSurrenderRejectionThenNewPromptRetryObserved'],'Actual new default Main must itself retry after the actual rejected original prompt.'
    with urllib.request.urlopen('http://127.0.0.1:15840/fault-evidence',timeout=2) as response:fault=json.load(response)
    assert fault['payloadsNeverRewritten'] and fault['heldAFirstMulligan'] and fault['heldBFirstSurrender']
    assert fault['acceptedMulliganTick']>fault['heldSurrenderTick']>=0
    stages=[row['stage'] for row in fault['trace']]
    for stage in ['HOLD_ORIGINAL_A_MULLIGAN','HOLD_ORIGINAL_B_SURRENDER','FORWARD_ORIGINAL_A_MULLIGAN_UNMODIFIED','REAL_SERVER_ACCEPTED_A_MULLIGAN','FORWARD_ORIGINAL_STALE_B_SURRENDER_UNMODIFIED','ACTUAL_NATIVE_B_RETRY_UNMODIFIED']:assert stages.count(stage)==1,(stage,stages)
    proof['actualTransportOrderingFault']=fault
    proxy_process.terminate();proxy_process.wait(timeout=20);proof['ownProxyNormalStop']=True
    proof['noSigtermNeededForEitherSuccessfulNativeProcess']=True
    api_process.terminate();api_process.wait(timeout=20)
    proof['ownApiGracefulStop']=True
    frame=n/'exported-stale-retry-v2-original-frame.json.gz';assert not frame.exists()
    replay=json.loads(subprocess.check_output(c['reader_command']+['native-frame',room,str(frame)],cwd=reader,env=c['environment']('riftbound_here_native'),text=True))
    frame.chmod(0o600)
    assert replay['actualRuleInputs']==identity and replay['originalNonZeroPrivateSeedPreserved']
    assert digests('riftbound_here_native',old_native)==native_before and digests('riftbound_acceptance')==audit_before
    assert set(c['rooms']('riftbound_here_native'))-set(old_native)=={room}
    for row in proof['nativeClients']:
        text=(n/row['log']).read_text(errors='replace')
        row.update(logSha256=sha(n/row['log']),bootMarker='Client booted. Waiting for server authority.' in text,
                   catalogMarker='Official catalog loaded: 1035 cards.' in text,resultMessageAndViewConstructed='Match result rendered:' in text,
                   matchWonReceived='MATCH_WON' in text,ephemeralNoProfileWritten=not (n/row['profile']).exists(),
                   noGodotErrorOrUnhandledException=not any(x in text for x in ['ERROR:','Unhandled exception','SCRIPT ERROR:']))
        assert all(row[k] for k in ['bootMarker','catalogMarker','resultMessageAndViewConstructed','matchWonReceived','ephemeralNoProfileWritten','noGodotErrorOrUnhandledException'])
    proof.update(status='PASS_ACTUAL_EXPORTED_NATIVE_STALE_REJECTION_NEW_PROMPT_RETRY_RESULT_AND_FULL_REPLAY',originalReplay=replay,originalFrameSha256=sha(frame),
        all172AuditAnd32PriorNativeRoomsSevenTablesExact=True,newOriginalRoomSevenTables=digests('riftbound_here_native',[room]),
        nativeRoomCount=33,auditRoomCount=172,successfulPreviousFunctionalStepsNotRerun=True)
except BaseException as e:
    proof.update(status='FAILED_OR_INTERRUPTED_ORIGINAL_PREFIX_RETAINED',errorType=type(e).__name__)
    raise
finally:
    for client in clients:
        if client.poll() is None:client.terminate();client.wait(timeout=15)
    if proxy_process is not None and proxy_process.poll() is None:proxy_process.terminate();proxy_process.wait(timeout=20)
    if api_process is not None and api_process.poll() is None:api_process.terminate();api_process.wait(timeout=20)
    if started:proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
    if power is not None:
        if power.poll() is None:power.terminate();power.wait(timeout=10)
        proof['boundIdleSleepAssertionEnded']=power.poll() is not None
    assert all(sha(proxy_root/p)==h for p,h in proxy_inputs['files'].items())
    c['verify_fixed']();proof.update(finishedAtUtc=now(),lockAtEnd=c['lock_observation'](),allFrozenFixedPublicationsAndAcceptanceRuntimesStillExact=True,
        originalDatabaseRetained=cluster.exists(),allNativeCiPayloadsStillExact=all(sha(Path(app['app'])/p)==h for app in apps['apps'] for p,h in apps['ciManagedAndPckPayloads'].items()))
    write(out,proof);fcntl.flock(guard,fcntl.LOCK_UN)
print(proof['status'],flush=True)
