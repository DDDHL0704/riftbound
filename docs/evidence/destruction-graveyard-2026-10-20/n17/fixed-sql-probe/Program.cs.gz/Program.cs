using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
if (args.SequenceEqual(new[] { "identity-print" }))
{ Console.WriteLine(JsonSerializer.Serialize(RuleInputIdentity.Current, json)); return; }
if (!args.SequenceEqual(new[] { "independent-readonly" }) && !args.SequenceEqual(new[] { "run-sql" })) throw new Exception("Explicit read-only mode required.");
var settings = new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
if (settings.Host != "127.0.0.1" || settings.Port != 55486 || settings.Database != "riftbound_acceptance"
    || settings.Username != "codex_riftbound_audit") throw new Exception("Existing dedicated audit SQL database required.");
if (args[0] == "independent-readonly") settings.Options = "-c default_transaction_read_only=on";
await using var source = NpgsqlDataSource.Create(settings.ConnectionString);
var work = Path.GetFullPath(Environment.GetEnvironmentVariable("RIFTBOUND_HWEI_SQL_WORK") ?? throw new Exception("Evidence directory required."));
if (args[0] == "run-sql")
{
    await HweiMoveDiscardTypesSqlAcceptance.RunAsync(source, Path.Combine(work, "actual-fixed-sql-v1/hwei-move-discard-types"));
    Console.WriteLine("FIXED_08FD_REAL_HWEI_SQL_COMPLETE"); return;
}
var checks = new List<object>();
using var recipe = JsonDocument.Parse(File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "Fixtures/hwei-move-discard-openings.json")));
var host = recipe.RootElement.GetProperty("host").GetString()!;
var top = recipe.RootElement.GetProperty("top").GetString()!;
foreach (var format in new[] { "CoreRules", "ChinaStandard20260724" })
foreach (var reverse in new[] { false, true })
{
    var path = Path.Combine(work, $"actual-fixed-sql-v1/hwei-move-discard-types/hwei-{format}-{reverse}-original-frame.json.gz");
    using var zip = new GZipStream(File.OpenRead(path), CompressionMode.Decompress);
    var original = await JsonSerializer.DeserializeAsync<MatchRecoveryFrame>(zip, json) ?? throw new Exception("Original SQL frame required.");
    var actual = await new PostgresMatchRecoveryStore(source).LoadAsync(original.RoomId, default) ?? throw new Exception("Actual persisted original room required.");
    Check(JsonNode.DeepEquals(JsonSerializer.SerializeToNode(original, json), JsonSerializer.SerializeToNode(actual, json)),
        "Every original stored field, null, command, event and both private views must match.");
    Check(actual.IsConsistent && actual.OpeningSeed == 0 && actual.ReplayInitialState is { Tick: 0, Seed: 0 } blank
        && blank.CardObjects.Count == 0 && actual.AuthoritativeState is { } current && current.RuleInputs == RuleInputIdentity.Current
        && actual.Commands.All(c => c.Accepted && c.RuleInputs == RuleInputIdentity.Current), "Original blank seed0 and exact current identities required.");
    var state = actual.AuthoritativeState!;
    Check(state.CardObjects[host].CardNo == "UNL-080/219" && state.CardObjects[top].CardNo == "VEN·058"
        && state.CardObjects[top].Tags.Contains(CardObjectTags.UnitCard) && state.CardObjects[top].Tags.Contains(CardObjectTags.EquipmentCard)
        && state.PlayerZones["P1"].Graveyard.Contains(top) && state.CardObjects[host].UntilEndOfTurnPowerModifiers.Count == 0,
        "Original physical printings, both types, actual discard and expired temporary Might required.");
    var move = actual.Commands.Single(c => c.CommandType == CommandTypes.MoveUnit);
    var discard = actual.Commands.Single(c => c.CommandType == CommandTypes.ChooseHandCards);
    var order = actual.Commands.Single(c => c.CommandType == CommandTypes.OrderTriggers && c.CompletedTick > discard.CompletedTick);
    var end = actual.Commands.Single(c => c.CommandType == CommandTypes.EndTurn && c.CompletedTick > move.CompletedTick);
    var events = actual.Events.Where(e => e.Sequence > move.StartedEventSequence && e.Sequence <= end.StartedEventSequence).Select(e => e.Event).ToArray();
    Check(events.Count(e => e.Kind == "CARD_DRAWN") == 1 && events.Count(e => e.Kind == "CARD_DISCARDED") == 1
        && events.Count(e => e.Kind == "RUNE_READIED") == 2
        && !events.Any(e => e.Kind is "CARDS_REVEALED" or "BURNOUT_APPLIED" or "UNIT_PLAYED_TO_BASE"), "Independent expected draw/discard/ready counts without reveal, burnout or play.");
    Check(Array.FindIndex(events, e => e.Kind == "CARD_DRAWN") < Array.FindIndex(events, e => e.Kind == "CARD_DISCARDED"), "Draw precedes discard.");
    using var ordered = await Read("state_snapshots", "state_tick", order.CompletedTick, null);
    var byStack = ordered.RootElement.GetProperty("stackItems").EnumerateArray().ToDictionary(
        item => item.GetProperty("stackItemId").GetString()!, item => item.GetProperty("movementObserver").GetProperty("discardInline").GetProperty("branchType").GetInt32());
    Check(byStack.Count == 2 && byStack.Values.Order().SequenceEqual(new[] { 1, 2 }), "Independent physical unit/gear yields both inline branches.");
    Check(events.Where(e => e.Kind == "TRIGGER_RESOLVED" && JsonSerializer.SerializeToElement(e.Payload).GetProperty("effectKind").GetString() == "MOVEMENT_DISCARD_TYPE_INLINE")
        .Select(e => byStack[JsonSerializer.SerializeToElement(e.Payload).GetProperty("triggerId").GetString()!])
        .SequenceEqual(reverse ? new[] { 2, 1 } : new[] { 1, 2 }), "Both actual controller-selected resolution orders retained.");
    foreach (var player in state.Seats.Keys)
    {
        using var preEnd = await Read("snapshots", "snapshot_tick", end.StartedTick, player);
        Check(preEnd.RootElement.GetProperty("players").GetProperty("P1").GetProperty("objects").GetProperty(host).GetProperty("effectivePower").GetInt32() == 8,
            "Both actual stored pre-end views have source Might8.");
        var final = JsonSerializer.SerializeToElement(actual.PlayerViews[player].Snapshot, json);
        Check(final.GetProperty("players").GetProperty("P1").GetProperty("objects").GetProperty(host).GetProperty("effectivePower").GetInt32() == 5,
            "Both actual stored next-turn views have source Might5.");
    }
    using var pendingOpponent = await Read("snapshots", "snapshot_tick", discard.StartedTick, "P2");
    Check(!pendingOpponent.RootElement.GetRawText().Contains('"' + top + '"', StringComparison.Ordinal), "Original pending discard does not disclose the new hand identity to opponent.");
    var errors = await MatchActionLogReplayer.ValidateRecoveryFrameAsync(actual, new CoreRuleEngine(), default);
    Check(errors.Count == 0, "Full original command/event/state replay: " + string.Join(';', errors));
    checks.Add(new { room = actual.RoomId, format, reverse, commands = actual.Commands.Count, events = actual.Events.Count,
        allStoredFieldsAndNullsAndPrivateViewsExact = true, originalSeed = 0, independentDraws = 1, independentDiscards = 1,
        bothInlineBranchesAndOrder = true, readiedRunes = 2, preEndMight = 8, nextTurnMight = 5, fullOriginalReplayMatched = true });

    async Task<JsonDocument> Read(string table, string tickColumn, long tick, string? player)
    {
        await using var connection = await source.OpenConnectionAsync();
        await using var command = new NpgsqlCommand($"select payload::text from {table} where match_id=@room and {tickColumn}=@tick"
            + (player is null ? " order by last_event_sequence desc limit 1" : " and player_id=@player"), connection);
        command.Parameters.AddWithValue("room", actual.RoomId); command.Parameters.AddWithValue("tick", tick);
        if (player is not null) command.Parameters.AddWithValue("player", player);
        return JsonDocument.Parse((string)(await command.ExecuteScalarAsync() ?? throw new Exception("Original stored history row required.")));
    }
}
Console.WriteLine(JsonSerializer.Serialize(new { status = "PASS_ACTUAL_INDEPENDENT_READONLY_HWEI_ORIGINAL_FRAMES", checks,
    actualRuleInputs = RuleInputIdentity.Current, noNewRoomStateSeedOrHistoryRewrite = true, visibleAndPhysicalWindows = "OPEN" }, json));
static void Check(bool condition, string message) { if (!condition) throw new Exception(message); }
