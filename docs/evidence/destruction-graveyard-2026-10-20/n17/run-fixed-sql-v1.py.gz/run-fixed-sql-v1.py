import fcntl
import json
import os
import pathlib
import subprocess
import sys

os.umask(0o077)
work = pathlib.Path(__file__).resolve().parent
root = work.parents[2]
sys.path.insert(0, str(root / 'var/qa/empty-reveal-followup-20261019'))
import fixed_n13_common as c

publication = c.load(work / 'fixed-api-publication-v2.json')
runtime = work / 'fixed-api'
output = work / 'real-sql-verification-v1.json'
assert not output.exists()

def frozen():
    c.verify_frozen()
    assert all(c.sha(runtime / p) == h for p, h in publication['runtimeFiles'].items())
    assert all(c.sha(root / p) == h for p, h in publication['sourceInputHashes'].items())

frozen()
guard = (root / 'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a')
fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
proof = {'status': 'RUNNING_NOT_ACCEPTANCE', 'startedAtUtc': c.now(),
         'fixedCommit': publication['fixedCommit'], 'allCommittedSourcesExact': True,
         'actualRuleInputs': publication['actualRuleInputs'],
         'frozenPublicationSha256': c.sha(work / 'fixed-api-publication-v2.json'),
         'runnerSourceSha256': c.sha(pathlib.Path(__file__)), 'lockAtStart': c.locked(),
         'visibleNativeAndPhysicalWindows': 'OPEN',
         'scope': 'Fixed08fd actual Release b95c: four new blank seed0 Hwei ordinary matches, two named engine formats and both real unit/gear inline orders, existing original SQL database only. Frozen Release core; old histories and source universe retained.'}
c.write(output, proof)
started = False
power = process = None
try:
    assert subprocess.run([str(c.pg / 'pg_ctl'), '-D', str(c.cluster), 'status'], capture_output=True).returncode == 3
    power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    proof.update(ownRunnerPid=os.getpid(), boundIdleSleepAssertionPid=power.pid)
    subprocess.run([str(c.pg / 'pg_ctl'), '-D', str(c.cluster), '-l', str(work / 'own-postgres-v1.log'), '-o',
                    f'-p 55486 -h 127.0.0.1 -k {c.sock}', '-w', 'start'], check=True, capture_output=True)
    started = True
    audit = c.rooms('riftbound_acceptance'); native = c.rooms('riftbound_here_native')
    assert len(audit) == 168 and len(native) == 31
    before_audit = c.digests('riftbound_acceptance', audit)
    before_native = c.digests('riftbound_here_native', native)
    proof.update(priorAuditRooms=audit, priorNativeRooms=native, priorAuditSevenTables=before_audit,
                 priorNativeSevenTables=before_native, actualPostgresVersion=c.query('riftbound_acceptance', 'select version()').decode().strip())
    c.write(output, proof)
    env = dict(os.environ, ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit',
               RIFTBOUND_POSTGRES_EVIDENCE=str(work / 'actual-fixed-sql-v1'), RIFTBOUND_HWEI_SQL_WORK=str(work))

    def run(arguments, filename):
        global process
        with (work / filename).open('x') as log:
            process = subprocess.Popen(arguments, cwd=runtime, env=env, stdout=log, stderr=subprocess.STDOUT)
            proof['ownAcceptancePid'] = process.pid; c.write(output, proof)
            code = process.wait(timeout=900)
        assert code == 0, (code, filename)

    run([c.dotnet, 'exec', '--depsfile', str(runtime / 'Riftbound.Api.deps.json'), '--runtimeconfig', str(runtime / 'Riftbound.Api.runtimeconfig.json'), str(runtime / 'fixedprobe.dll'), 'run-sql'], 'real-sql-writer-v1.log')
    receipt_path = work / 'actual-fixed-sql-v1/hwei-move-discard-types/receipt.json'
    receipt = c.load(receipt_path)
    assert receipt['status'] == 'REAL_POSTGRES_ORIGINAL_HWEI_DRAW_DISCARD_TYPES_FOUR_BRANCHES_COLD_REPLAY_PASS'
    rows = receipt['results']; assert len(rows) == 4
    assert {(x['format'], x['reverse']) for x in rows} == {(f, b) for f in ['CoreRules', 'ChinaStandard20260724'] for b in [False, True]}
    assert all(x['originalOpeningCommands'] == 18 and x['originalBlankSeed'] == 0
               and x['expectedDraws'] == 1 and x['expectedDiscards'] == 1 and x['inlineCount'] == 2
               and x['readiedRunes'] == 2 and x['expectedMight'] == 8 and x['nextTurnMight'] == 5
               and x['originalFullReplayMatched'] and x['originalPrivateViewsAndPromptsExact']
               and x['noStateSeedOrHistoryInjection'] and x['ruleInputs'] == publication['actualRuleInputs']
               and x['coldRestores'] >= 8 and x['originalNextCommandsMatched'] >= 7 and x['atomicRejections'] == 5 for x in rows)
    added = sorted(set(c.rooms('riftbound_acceptance')) - set(audit))
    assert added == sorted(x['room'] for x in rows) and len(c.rooms('riftbound_acceptance')) == 172
    assert c.rooms('riftbound_here_native') == native
    assert c.digests('riftbound_acceptance', audit) == before_audit
    assert c.digests('riftbound_here_native', native) == before_native
    current_audit = c.rooms('riftbound_acceptance'); before_read = c.digests('riftbound_acceptance', current_audit)
    run([c.dotnet, 'exec', '--depsfile', str(runtime / 'Riftbound.Api.deps.json'),
         '--runtimeconfig', str(runtime / 'Riftbound.Api.runtimeconfig.json'),
         str(runtime / 'fixedprobe.dll'), 'independent-readonly'], 'independent-actual-sql-reader-v1.log')
    reader = json.loads((work / 'independent-actual-sql-reader-v1.log').read_text())
    assert reader['status'] == 'PASS_ACTUAL_INDEPENDENT_READONLY_HWEI_ORIGINAL_FRAMES' and len(reader['checks']) == 4
    assert reader['actualRuleInputs'] == publication['actualRuleInputs']
    assert c.rooms('riftbound_acceptance') == current_audit and c.rooms('riftbound_here_native') == native
    assert c.digests('riftbound_acceptance', current_audit) == before_read
    assert c.digests('riftbound_here_native', native) == before_native
    c.write(work / 'independent-actual-sql-reader-result-v1.json', reader)
    proof.update(status='PASS_REAL_SQL_FOUR_HWEI_ORIGINALS_AND_INDEPENDENT_READONLY_FULL_REPLAY',
                 branches=4, commands=sum(x['commands'] for x in rows), events=sum(x['events'] for x in rows),
                 coldRestores=sum(x['coldRestores'] for x in rows), originalNextCommandsMatched=sum(x['originalNextCommandsMatched'] for x in rows),
                 atomicRejections=sum(x['atomicRejections'] for x in rows), originalReceiptSha256=c.sha(receipt_path),
                 newOriginalRooms=added, all168PriorAuditAnd31NativeRoomsSevenTablesExact=True,
                 independentAll172AuditAnd31NativeRoomsSevenTablesUnchanged=True,
                 newRoomSevenTables=c.digests('riftbound_acceptance', added), observedAuditRooms=172, observedNativeRooms=31,
                 originalFrameHashes={p.name: c.sha(p) for p in receipt_path.parent.glob('*.json.gz')})
except BaseException as error:
    proof.update(status='FAILED_OR_INTERRUPTED_ORIGINAL_PREFIX_RETAINED', errorType=type(error).__name__, errorMessage=str(error))
    raise
finally:
    if process is not None and process.poll() is None:
        process.terminate(); process.wait(timeout=30)
    if started:
        proof['ownPostgresSmartStopped'] = subprocess.run([str(c.pg / 'pg_ctl'), '-D', str(c.cluster), '-m', 'smart', '-w', '-t', '20', 'stop'], capture_output=True).returncode == 0
    if power is not None:
        if power.poll() is None: power.terminate(); power.wait(timeout=10)
        proof['boundIdleSleepAssertionEnded'] = power.poll() is not None
    frozen()
    proof.update(finishedAtUtc=c.now(), lockAtEnd=c.locked(), allFrozenRuntimeAndHarnessInputsStillExact=True,
                 olderFixed797fRuntimeUnchanged=True, originalDatabaseRetained=c.cluster.exists())
    c.write(output, proof)
    fcntl.flock(guard, fcntl.LOCK_UN)
print(proof['status'], flush=True)
