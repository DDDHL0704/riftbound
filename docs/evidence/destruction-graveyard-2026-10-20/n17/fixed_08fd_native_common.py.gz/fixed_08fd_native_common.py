import datetime,hashlib,json,os,pathlib,subprocess,sys
n=pathlib.Path(__file__).resolve().parent;r=n.parents[2]
sys.path.insert(0,str(r/'var/qa/empty-reveal-followup-20261019'))
import fixed_n13_common as prior
pg,cluster,sock,dotnet=prior.pg,prior.cluster,prior.sock,prior.dotnet
sha,load,write,now,rooms,lock_observation=prior.sha,prior.load,prior.write,prior.now,prior.rooms,prior.locked
publication=load(n/'fixed-api-publication-v3.json');fixed=publication['fixedCommit'];identity=publication['actualRuleInputs'];api=n/'fixed-api';reader=api;reader_command=publication['readerCommand']
def environment(db):return dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database='+db+';Username=codex_riftbound_audit',RIFTBOUND_FIXED_ACCEPTANCE_ROOT=str(n))
def digests(db,ids=None):return prior.digests(db,rooms(db) if ids is None else ids)
def verify_fixed():
 prior.verify_frozen()
 assert all(sha(api/p)==h for p,h in publication['runtimeFiles'].items())
 assert all(sha(r/p)==h for p,h in publication['sourceInputHashes'].items())
 assert json.loads(subprocess.check_output(reader_command+['identity-print'],env=environment('riftbound_here_native'),cwd=api,text=True))==identity
verify_fixed()
