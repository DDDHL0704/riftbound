import datetime
import hashlib
import json
import os
import pathlib
import subprocess
import xml.etree.ElementTree as ET

os.umask(0o077)
n = pathlib.Path(__file__).resolve().parent
r = n.parents[2]
prior = n.parent / 'empty-reveal-followup-20261019'
fixed = '08fd25c0dc643f9120b529f039feed69beffc251'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
write = lambda p, d: p.write_text(json.dumps(d, indent=2) + '\n')
proof = {'status': 'PREPARING_ACTUAL_CURRENT_CI_GATEWAY_INPUTS', 'fixedCommit': fixed, 'startedAtUtc': now()}
out = n / 'fixed-background-native-build-v1.json'
assert not out.exists()
apps = load(n / 'native-app-inputs.json')
assert apps['fixedCommit'] == fixed
app = pathlib.Path(next(x['app'] for x in apps['apps'] if x['label'] == 'a'))
assert all(sha(app / p) == h for p, h in apps['ciManagedAndPckPayloads'].items())
network = n / 'native-network'
score = n / 'score-network'
network.mkdir(exist_ok=False)
score.mkdir(exist_ok=False)
production = {}
for path, name in [('tests/Riftbound.NativeNetworkSmoke/Program.cs', 'Program.cs'),
                   ('clients/godot/scripts/RiftboundGameHubClient.cs', 'RiftboundGameHubClient.cs'),
                   ('clients/godot/scripts/SnapshotCardRef.cs', 'SnapshotCardRef.cs')]:
    raw = subprocess.check_output(['git', 'show', fixed + ':' + path], cwd=r)
    (network / name).write_bytes(raw)
    production[path] = sha(network / name)
old_app = prior / 'RiftboundEmpty-A.app'
project = (prior / 'native-network/network.csproj').read_text().replace(str(old_app), str(app))
(network / 'network.csproj').write_text(project)
(score / 'Fixtures').mkdir()
fixture = subprocess.check_output(['git','show',fixed+':tests/Riftbound.ConformanceTests/Fixtures/copied-duel-insight-openings.json'],cwd=r)
(score/'Fixtures/copied-duel-insight-openings.json').write_bytes(fixture)
(score / 'score.csproj').write_text((prior / 'score-network/score.csproj').read_text().replace('../fixed-sql-publish/Fixtures/copied-duel-insight-openings.json','Fixtures/copied-duel-insight-openings.json'))
body = (prior / 'score-network/Program.cs').read_text().replace('fixed797f-paired-score-restart', 'fixed08fd-paired-score-restart').replace('LOCKED-797F-SCORE-', 'LOCKED-08FD-SCORE-').replace('fixed-release-publication-inputs-v1.json','fixed-api-publication-v3.json')
(score / 'Program.cs').write_text(body)
references = {}
for ref in ET.fromstring(project).findall('.//HintPath'):
    p = pathlib.Path(ref.text)
    assert p.is_relative_to(app) and sha(p) == apps['ciManagedAndPckPayloads'][str(p.relative_to(app))]
    references[str(p.relative_to(n))] = sha(p)
source_files = {str(p.relative_to(n)): sha(p) for folder in [network, score] for p in folder.iterdir() if p.is_file()}
inputs = {'atUtc': now(), 'fixedCommit': fixed, 'productionNativeGatewaySourcesExtractedDirectlyFromFixedGitCommit': production,
    'actualCurrentCiNet8References': references, 'sourceFiles': source_files,
    'priorScoringHelperOriginalSha256': sha(prior / 'score-network/Program.cs'),
    'scoringHelperChangeOnlyGateAndRoomLabels': True, 'noGodotSdkProjectOrUserProcessBuild': True}
write(n / 'fixed-background-native-source-inputs-v1.json', inputs)
process = None
power = None
try:
    proof['builds'] = []
    for folder, project_name in [(network, 'network.csproj'), (score, 'score.csproj')]:
        with (n / (folder.name + '-build-v1.log')).open('x') as log:
            process = subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet', 'build', str(folder / project_name), '-c', 'Release', '-v:q', '--nologo'],
                cwd=r, stdout=log, stderr=subprocess.STDOUT)
            power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(process.pid)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            code = process.wait(timeout=300)
            power.wait(timeout=10)
        proof['builds'].append({'project': str((folder / project_name).relative_to(n)), 'exitCode': code})
        assert code == 0
    assert all(sha(n / p) == h for p, h in source_files.items())
    assert all(sha(n / p) == h for p, h in references.items())
    contract = app / next(p for p in apps['ciManagedAndPckPayloads'] if p.endswith('/Riftbound.Contracts.dll'))
    for folder in [network, score]:
        assert sha(folder / 'bin/Release/net8.0/Riftbound.Contracts.dll') == sha(contract)
    proof.update(status='FIXED_NATIVE_GATEWAY_AND_ACTUAL_NET8_CURRENT_CI_CONTRACTS_BUILT_NO_GODOT_SDK',
        sourceInputsSha256=sha(n / 'fixed-background-native-source-inputs-v1.json'),
        files={str(p.relative_to(n)): sha(p) for folder in [network, score] for p in (folder / 'bin/Release/net8.0').rglob('*') if p.is_file()},
        sourceFiles=source_files, nativeContractsSha256=sha(contract),
        actualServerReleaseRuleInputs=load(n / 'fixed-api-publication-v3.json')['actualRuleInputs'], visibleAcceptance='OPEN', physicalWindows='OPEN')
except BaseException as error:
    proof.update(status='FAILED_OR_INTERRUPTED_PREFIX_RETAINED', errorType=type(error).__name__)
    raise
finally:
    if process is not None and process.poll() is None:
        process.terminate()
        process.wait(timeout=30)
    if power is not None and power.poll() is None:
        power.terminate()
        power.wait(timeout=10)
    proof['finishedAtUtc'] = now()
    write(out, proof)
print(proof['status'], len(proof['files']), flush=True)
