"""Run exported default Main without a desktop or a checkout build."""
import datetime, hashlib, json, os, plistlib, subprocess
from pathlib import Path
os.umask(0o077)
n=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def lock():
    x=plistlib.loads(subprocess.check_output(['/usr/sbin/ioreg','-n','Root','-d','1','-a']))
    return {'rootLocked':x.get('IOConsoleLocked'),'sessions':[
        {'screenLocked':u['CGSSessionScreenIsLocked']} for u in x.get('IOConsoleUsers',[]) if 'CGSSessionScreenIsLocked' in u]}
proof=json.loads((n/'native-app-inputs.json').read_text())
assert proof['fixedCommit']=='08fd25c0dc643f9120b529f039feed69beffc251'
out=n/'current-native-headless-boot-verification.json'; assert not out.exists()
result={'atUtc':now(),'fixedCommit':proof['fixedCommit'],'fixedCiRun':39305210166,
        'lockAtStart':lock(),'records':[],'notVisibleControlsOrPairedGameAcceptance':True,'physicalWindows':'OPEN'}
try:
    for row in proof['apps']:
        app=Path(row['app']); label=row['label'];log=n/('current-native-default-headless-'+label+'.log')
        profile=n/('never-written-default-headless-'+label+'-session.json');assert not profile.exists()
        assert all(sha(app/k)==v for k,v in proof['ciManagedAndPckPayloads'].items())
        executable=app/'Contents/MacOS/符文战场'
        args=[str(executable),'--headless','--quit-after','600','--','--riftbound-ephemeral-session',
              '--riftbound-server=http://127.0.0.1:15847','--riftbound-session-file='+str(profile)]
        with log.open('x') as stream:
            process=subprocess.Popen(args,cwd='/tmp',stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
            try:code=process.wait(timeout=45)
            finally:
                if process.poll() is None:process.terminate();process.wait(timeout=10)
        raw=log.read_text()
        record={'label':label,'ownNativePid':process.pid,'returnCode':code,
                'defaultMainBootMarker':'[Riftbound] Client booted. Waiting for server authority.' in raw,
                'officialCatalogBootMarker':'[Riftbound] Official catalog loaded: 1035 cards.' in raw,
                'noGodotErrorOrUnhandledException':not any(x in raw for x in ['ERROR:','Unhandled exception','SCRIPT ERROR:']),
                'log':log.name,'logSha256':sha(log),'outsideCheckoutCwd':'/tmp',
                'exactArguments':args,'ephemeralNoProfileWritten':not profile.exists(),
                'all373OriginalCiManagedAndPckFilesStillExact':all(sha(app/k)==v for k,v in proof['ciManagedAndPckPayloads'].items())}
        subprocess.run(['codesign','--verify','--deep','--strict',str(app)],capture_output=True,check=True)
        record['deepStrictSignaturePass']=True;result['records'].append(record)
        assert code==0 and all(record[k] for k in ['defaultMainBootMarker','officialCatalogBootMarker',
            'noGodotErrorOrUnhandledException','ephemeralNoProfileWritten','all373OriginalCiManagedAndPckFilesStillExact'])
    result['status']='CURRENT_FIXED_DEFAULT_MAIN_HEADLESS_BOOT_PASS'
except BaseException as e:
    result.update(status='FAILED_OR_INTERRUPTED_PREFIX_RETAINED',errorType=type(e).__name__)
    raise
finally:
    result.update(finishedAtUtc=now(),lockAtEnd=lock());out.write_text(json.dumps(result,indent=2)+'\n')
print(result['status'],flush=True)
