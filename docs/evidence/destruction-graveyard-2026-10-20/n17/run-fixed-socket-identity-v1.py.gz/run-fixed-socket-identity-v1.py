import fcntl,os,socket,subprocess,time,urllib.request
from fixed_08fd_gateway_common import *
os.umask(0o077);out=n/'fixed-socket-identity-verification-v1.json';assert not out.exists()
dependency=load(n/'score-without-desktop-verification.json');assert dependency['status']=='PASS' and dependency['ownPostgresSmartStopped']
guard=(r/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
record={'startedAtUtc':now(),'fixedCommit':fixed,'actualServerReleaseRuleInputs':identity,'status':'RUNNING_NOT_ACCEPTANCE','lockAtStart':lock_observation(),
 'nativeGatewayBuildInputsSha256':sha(n/'fixed-background-native-build-v1.json'),'scope':'Actual production native gateway socket drop/recovery and15 independent identity rejections against own real PG API. No visible/native full-game or physical Windows claim.'}
started=False;server=None;power=None;process=None
try:
 verify_fixed();assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket() as probe:probe.settimeout(.5);assert probe.connect_ex(('127.0.0.1',15839))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 record.update(ownRunnerPid=os.getpid(),boundIdleSleepAssertionPid=power.pid);write(out,record)
 subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(n/'fixed-socket-identity-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 native=rooms('riftbound_here_native');audit=rooms('riftbound_acceptance');assert len(native)==34 and len(audit)==172
 native_before=digests('riftbound_here_native',native);audit_before=digests('riftbound_acceptance',audit)
 record.update(priorNativeRooms=native,priorAuditRooms=audit,priorNativeSevenTables=native_before,priorAuditSevenTables=audit_before);write(out,record)
 with (n/'fixed-socket-identity-api-v1.log').open('x') as log:
  server=subprocess.Popen([dotnet,str(api/'Riftbound.Api.dll')],cwd=api,env=dict(environment('riftbound_here_native'),ASPNETCORE_ENVIRONMENT='Production',ASPNETCORE_URLS='http://127.0.0.1:15839'),stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 record['ownApiPid']=server.pid
 for _ in range(100):
  assert server.poll() is None
  try:
   with urllib.request.urlopen('http://127.0.0.1:15839/health',timeout=1) as response:health=json.load(response)
   assert health['persistenceMode']=='postgres' and health['environment']=='Production'
   assert set(subprocess.check_output(['/usr/sbin/lsof','-tiTCP:15839','-sTCP:LISTEN'],text=True).splitlines())=={str(server.pid)};break
  except OSError:time.sleep(.1)
 else:raise AssertionError('Own exact fixed API did not become ready.')
 with (n/'fixed-socket-identity-native-v1.log').open('x') as log:
  process=subprocess.Popen([dotnet,str(n/'native-network/bin/Release/net8.0/Riftbound.NativeNetworkSmoke.dll')],cwd=n/'native-network/bin/Release/net8.0',env=dict(environment('riftbound_here_native'),RIFTBOUND_SERVER_URL='http://127.0.0.1:15839'),stdout=log,stderr=subprocess.STDOUT)
  record['ownNativeGatewayPid']=process.pid;write(out,record);code=process.wait(timeout=90)
 record['nativeExitCode']=code;assert code==0
 text=(n/'fixed-socket-identity-native-v1.log').read_text();assert 'Native network recovery passed:' in text and 'Native snapshot projection passed:' in text
 evidence=json.loads(next(line.split('NATIVE_ROOM_IDENTITY_EVIDENCE ',1)[1] for line in text.splitlines() if line.startswith('NATIVE_ROOM_IDENTITY_EVIDENCE ')))
 assert evidence['rejectedActions']==15 and evidence['leakedPrivateMessages']==0 and evidence['validReconnectTokenWasSupplied']
 server.terminate();server.wait(timeout=20);record['ownApiNormalStop']=True
 assert set(rooms('riftbound_here_native'))-set(native)=={evidence['room']}
 assert native_before==digests('riftbound_here_native',native) and audit_before==digests('riftbound_acceptance',audit)
 record.update(status='PASS_ACTUAL_NATIVE_SOCKET_RESTORE_REJECTED_TOKEN_AND15_IDENTITY_REJECTIONS_REAL_PG',wireIdentityEvidence=evidence,
  logSha256=sha(n/'fixed-socket-identity-native-v1.log'),all34PriorNativeAnd172AuditRoomsSevenTablesExact=True,
  newOwnOriginalRoomSevenTables=digests('riftbound_here_native',[evidence['room']]),socketDropAuthenticatedRestoreFreshSnapshotAndRejectedReceiptPassed=True,
  observedNativeRooms=35,observedAuditRooms=172)
except BaseException as error:
 record.update(status='FAILED_OR_INTERRUPTED_ORIGINALS_RETAINED',errorType=type(error).__name__,errorMessage=str(error));raise
finally:
 if process is not None and process.poll() is None:process.terminate();process.wait(timeout=20)
 if server is not None and server.poll() is None:server.terminate();server.wait(timeout=20)
 if started:record['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None:
  if power.poll() is None:power.terminate();power.wait(timeout=10)
  record['boundIdleSleepAssertionEnded']=power.poll() is not None
 verify_fixed();record.update(finishedAtUtc=now(),lockAtEnd=lock_observation(),allFixedFrozenRuntimeFilesStillExact=True,originalDatabaseRetained=cluster.exists());write(out,record);fcntl.flock(guard,fcntl.LOCK_UN)
print(record['status'],flush=True)
