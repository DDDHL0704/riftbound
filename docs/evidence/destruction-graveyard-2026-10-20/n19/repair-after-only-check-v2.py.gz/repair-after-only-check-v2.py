import datetime
import hashlib
import json
import pathlib
import subprocess
import time

work = pathlib.Path(__file__).resolve().parent; root = work.parents[2]
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
output = work / 'postcheck-source-repairs-v2.json'; assert not output.exists()
terminal_path = work / 'only-check-terminal-integrity-v1.json'; deadline = time.monotonic() + 7200
while not terminal_path.exists():
    assert time.monotonic() < deadline, 'Do not mutate source before actual check termination.'
    time.sleep(3)
terminal = json.loads(terminal_path.read_text())
assert terminal['allDeclaredInputsAndRuntimeFilesStable'] and terminal['boundIdleSleepAssertionEnded']
receipt_path = work / 'only-check-retention-and-disposition-v1.json'
assert not receipt_path.exists()
subprocess.run(['python3', str(work / 'verify-only-check-v1.py')], cwd=root, check=True)
check = json.loads(receipt_path.read_text())
names = {
    'Riftbound.ConformanceTests.CardCatalogBaselineTests.P6LifecycleTriggerReplacementFamiliesReportSpecAndExecutionBoundaryCoverage',
    'Riftbound.ConformanceTests.MatchRecoveryTests.RecoveryValidatorRejectsAuthoritativeStateUntilEndOfTurnEffectValueDrift',
    'Riftbound.ConformanceTests.OfficialInformationPermissionTests.FullGamePrivacyGuardAllowsOnlyCurrentRevealedGenerationsAndNeverDeckIdentities'}
assert check['failed'] == 3 and check['skipped'] == 0 and check['all73NewDestructionCasesPassed']
assert {row['name'] for row in check['failures']} == names
inputs = json.loads((work / 'only-check-start-inputs-v1.json').read_text())['inputHashes']
paths = ['src/Riftbound.Engine/CoreRuleEngine.DamageDestruction.cs',
         'tests/Riftbound.ConformanceTests/DestructionFamilyPrivacyAssertions.cs',
         'tests/Riftbound.ConformanceTests/CardCatalogBaselineTests.cs']
before = {path: (root / path).read_text() for path in paths}
assert all(sha(root / path) == inputs[path] for path in paths)
damage = before[paths[0]]
old = '    internal static bool ValidDamageDestructionState(MatchState state)\n    {\n'
new = old + '        if (state.UntilEndOfTurnEffects is null || state.UntilEndOfTurnEffects.Any(effect => effect is null)) return false;\n'
assert damage.count(old) == 1
privacy = before[paths[1]]
assert privacy.count('state.StackItems.Single(i =>') == 1 and privacy.count('state.TriggerQueue.Single(i =>') == 1
privacy = privacy.replace('state.StackItems.Single(i =>', 'Assert.Single(state.StackItems, i =>').replace('state.TriggerQueue.Single(i =>', 'Assert.Single(state.TriggerQueue, i =>')
catalog = before[paths[2]]
old_counter = '''            TimingSurfaceNames.Trigger,
            entries: 551,
            specImplementedEntries: 551,
            manualRuleRequiredEntries: 0,
            unimplementedEntries: 0,
            functionalUnits: 441,
            specImplementedFunctionalUnits: 441,
            pendingFunctionalUnits: 0);'''
new_counter = old_counter.replace('551', '552').replace('441', '442')
assert catalog.count(old_counter) == 1
inventory = json.loads((work / 'catalog-boundary-independent-old-current-comparison-v1.json').read_text())
assert set(inventory['newTriggerPrintingRows']) == {'OGN·254/298'} and not inventory['removedOldTriggerPrintingRows']
assert inventory['after']['entries'] == 552 and inventory['after']['functionalUnits'] == 442
after = {paths[0]: damage.replace(old, new, 1), paths[1]: privacy, paths[2]: catalog.replace(old_counter, new_counter, 1)}
for path, text in after.items():
    (root / path).write_text(text)
record = {'status': 'THREE_BOUNDED_SOURCE_REPAIRS_APPLIED_AFTER_STABLE_SOLE_CHECK_VALIDATION_PENDING',
    'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'originalCheckReceiptSha256': sha(receipt_path),
    'originalFailedNames': sorted(names), 'sourceChanges': [{'path': path, 'beforeSha256': hashlib.sha256(before[path].encode()).hexdigest(),
        'afterSha256': sha(root / path)} for path in paths],
    'productionChange': 'Fail closed for null collection or member before damage marker scan; original base validator errors retained.',
    'privacyHelperChange': 'Exact unique binding still required, now through independent Assert.Single instead of a generic LINQ exception.',
    'counterChange': {'exactPrinting': 'OGN·254/298', 'functionalUnit': 'FU-842e15ada7', 'before': [551, 441], 'after': [552, 442]},
    'allOriginalAssertionsRetained': True, 'originalFailedCheckNotRewritten': True, 'noSecondCheck': True,
    'newRuntimeAndFocusedAndRealSqlEvidenceRequired': True}
output.write_text(json.dumps(record, indent=2) + '\n')
print('THREE_EXACT_REPAIRS_APPLIED_CURRENT_FOCUSED_AND_SQL_VERIFICATION_REQUIRED', flush=True)
