import os,subprocess,hashlib,json,datetime,plistlib
from pathlib import Path
r=Path(__file__).resolve().parent;root=r.parents[2]
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def locked():
 a=plistlib.loads(subprocess.check_output(['/usr/sbin/ioreg','-n','Root','-d1','-a']))
 if isinstance(a,list):a=a[0]
 return {'IOConsoleLocked':a.get('IOConsoleLocked'),'sessionLocks':[u.get('CGSSessionScreenIsLocked') for u in a.get('IOConsoleUsers',[])]}
names=set(subprocess.check_output(['git','ls-files','src','tests/Riftbound.ConformanceTests','data/official'],cwd=root,text=True).splitlines())
names|={str(p.relative_to(root)) for p in (root/'src/Riftbound.Engine').glob('*Destruction*.cs')}
names|={str(p.relative_to(root)) for p in (root/'src/Riftbound.Engine').glob('*GraveyardPlay.cs')}
names|={str(p.relative_to(root)) for p in (root/'tests/Riftbound.ConformanceTests').glob('Destruction*.cs')}
names.add('tests/Riftbound.ConformanceTests/Fixtures/destruction-graveyard-openings.json')
inputs={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in sorted(names) if (root/n).is_file()}
args=['python3','scripts/test-rules.py','focus','--include-games','--match','DestructionGraveyardOrdinaryTests','--match','OfficialDeckMidgameResolvesVoidGateTargetSpellSkillDamageBonusAndScoreVictoryActionLogReplaysToFinalStateHash','--match','OfficialDecksResolveMultiDefenderBattleDamageAssignmentScoreVictoryActionLogReplaysToFinalStateHash','--output',str(r/'focus-v22-ordinary-and-originals')]
receipt={'status':'RUNNING_NOT_ACCEPTANCE','startedAtUtc':now(),'sourceInputs':inputs,'lockAtStart':locked(),'arguments':args,'scope':'Both original full games and new ordinary blank seed0 destruction family; no native SDK/project build; separate not-yet-built SQL acceptance source excluded from this Conformance input set.'}
p=r/'focus-v22-frozen-inputs-v1.json';assert not p.exists()
env=dict(os.environ,RIFTBOUND_DESTRUCTION_FAMILY_EVIDENCE=str(r/'ordinary-v22'))
runner=subprocess.Popen(args,cwd=root,env=env);power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(runner.pid)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
receipt.update(runnerPid=runner.pid,caffeinatePid=power.pid);p.write_text(json.dumps(receipt,indent=2)+'\n');print('Own frozen-input focus runner',runner.pid,'idle-sleep assertion',power.pid,flush=True)
code=runner.wait();power.wait(timeout=15)
receipt.update(status='EXECUTED_EXIT_'+str(code),exitCode=code,finishedAtUtc=now(),lockAtEnd=locked(),allSourceInputsUnchanged=all(hashlib.sha256((root/n).read_bytes()).hexdigest()==h for n,h in inputs.items()),boundPowerAssertionEnded=power.poll() is not None)
p.write_text(json.dumps(receipt,indent=2)+'\n');raise SystemExit(code)
