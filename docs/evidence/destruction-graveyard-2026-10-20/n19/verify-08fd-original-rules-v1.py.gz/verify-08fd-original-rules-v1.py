import ast, collections, datetime, hashlib, json, re, subprocess, xml.etree.ElementTree as ET, zipfile
from pathlib import Path
R=Path(__file__).resolve().parent
P=R.parent/'hwei-move-discard-types-20261020'
NS={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def sha(data): return hashlib.sha256(data).hexdigest()
source=(P/'verify-b294-original-rule-artifact-v1.py').read_text()
exec("def read_original" + source.split("def read_original",1)[1].split("\npath = ROOT /",1)[0])
archive=R/'08fd-original-rule-results.zip'
assert not archive.exists()
with archive.open('xb') as f:
    subprocess.run(['gh','api','repos/DDDHL0704/riftbound/actions/artifacts/12217643571/zip'],stdout=f,check=True)
assert archive.stat().st_size==3844880
old=read_original(P/'b294-original-rule-results.zip'); cur=read_original(archive)
oc,om,of,_,ox,_,_=old
c,m,f,trxs,x,summary,sql=cur
assert not (oc-c) and om<=m and f==of and len(f)==143
assert x['seed']==424242 and x['deckCount']==11 and x['pairCount']==110
assert set(x['completed'])==set(ox['completed']) and all(re.fullmatch('[a-f0-9]{64}',h) for h in x['completed'].values())
run=json.loads(subprocess.check_output(['gh','api','repos/DDDHL0704/riftbound/actions/runs/39305210166']))
jobs=json.loads(subprocess.check_output(['gh','api','repos/DDDHL0704/riftbound/actions/runs/39305210166/jobs']))
(R/'08fd-actual-run-and-jobs-v1.json').write_text(json.dumps({'observedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'run':run,'jobs':jobs},indent=2)+'\n')
assert run['head_sha']=='08fd25c0dc643f9120b529f039feed69beffc251'
assert next(j for j in jobs['jobs'] if j['name']=='rule_suite')['conclusion']=='success'
receipt={'status':'FIXED_08FD_ALL_ORIGINAL_RULES_PASS_SQL_NETWORK_PENDING','runId':run['id'],'fixedCommit':run['head_sha'],
'archiveBytes':archive.stat().st_size,'archiveSha256':sha(archive.read_bytes()),'cases':sum(c.values()),'methods':len(m),
'all13124PreviousCasesRetained':True,'all7568PreviousMethodsRetained':True,'originalFullGameMethods':len(f),
'110Pairs11DecksSeed424242Retained':True,'newCases':sorted((c-oc).elements()),'rawTrxSha256':trxs,'summary':summary,
'jobs':{j['name']:j['conclusion'] or j['status'] for j in jobs['jobs']},'fullAcceptancePassed':False,
'currentUncommittedDestructionFamilyCovered':False,'visibleNativeAndWindowsPhysical':'OPEN'}
(R/'08fd-original-rule-verification-v1.json').write_text(json.dumps(receipt,indent=2)+'\n')
(R/'08fd-original-matrix-v1.json').write_text(json.dumps(x,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ['status','cases','methods','originalFullGameMethods','archiveSha256']}))
