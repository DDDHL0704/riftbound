import collections
import gzip
import hashlib
import json
import pathlib
import xml.etree.ElementTree as ET

work = pathlib.Path(__file__).resolve().parent
root = work.parents[2]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def read(path):
    tree = ET.fromstring(gzip.decompress(path.read_bytes()) if path.suffix == '.gz' else path.read_bytes())
    rows = tree.findall('.//t:UnitTestResult', ns)
    methods = {m.attrib['className'].split(',')[0] + '.' + m.attrib['name'] for m in tree.findall('.//t:UnitTest/t:TestMethod', ns)}
    return rows, collections.Counter(r.attrib['testName'] for r in rows), methods

terminal = json.loads((work / 'only-check-terminal-integrity-v1.json').read_text())
assert terminal['allDeclaredInputsAndRuntimeFilesStable'] and terminal['boundIdleSleepAssertionEnded']
baseline = root / 'var/qa/hwei-move-discard-types-20261020/only-check/check/results.trx'
old_rows, old, old_methods = read(baseline)
path = work / 'only-check/check/results.trx'
rows, cases, methods = read(path)
assert len(old_rows) == 13027 and len(old_methods) == 7440
assert not old - cases and old_methods <= methods
new_cases = cases - old
assert sum(new_cases.values()) == 73 and len(methods - old_methods) == 24
assert all('DestructionGraveyard' in name for name in new_cases)
failed = [r for r in rows if r.attrib['outcome'] == 'Failed']
skipped = [r for r in rows if r.attrib['outcome'] not in {'Failed', 'Passed'}]
details = []
for row in failed + skipped:
    message = row.find('.//t:Message', ns); trace = row.find('.//t:StackTrace', ns)
    details.append({'name': row.attrib['testName'], 'outcome': row.attrib['outcome'],
                    'message': message.text if message is not None else None, 'stackTrace': trace.text if trace is not None else None})
frames = list((work / 'only-check-ordinary-frames').glob('*-final.json.gz'))
assert len(frames) == 6
identities = []
for frame in frames:
    raw = json.loads(gzip.decompress(frame.read_bytes()))
    identities.append(raw['authoritativeState']['ruleInputs'])
assert all(identity == identities[0] for identity in identities)
start = json.loads((work / 'only-check-start-inputs-v1.json').read_text())
passed = len(rows) - len(failed) - len(skipped)
proof = {'status': 'SOLE_CHECK_ALL_CASES_PASS' if not failed and not skipped and terminal['checkExitCode'] == 0 else 'SOLE_CHECK_FAILED_ORIGINAL_TRX_RETAINED',
         'profile': 'check', 'cases': len(rows), 'methods': len(methods), 'passed': passed, 'failed': len(failed), 'skipped': len(skipped),
         'all13027OriginalCaseMultisetRetained': True, 'all7440OriginalMethodsRetained': True,
         'newCases': sorted(new_cases.elements()), 'newMethodNames': sorted(methods - old_methods),
         'all73NewDestructionCasesPassed': all(row.attrib['outcome'] == 'Passed' for row in rows if row.attrib['testName'] in new_cases),
         'failures': details, 'unresolvedFailureCount': len(failed) + len(skipped), 'allFrozenInputsAndRuntimeStable': True,
         'declaredSourceInputCount': start['sourceInputCount'], 'runtimeFileCount': start['actualConformanceRuntimeFileCount'],
         'actualConformanceDebugRuleInputs': identities[0], 'rawTrxSha256': sha(path), 'baselineTrxSha256': sha(baseline),
         'onlyOneCheck': True, 'noSecondCheck': True, 'fixedFullRequired': True, 'visibleAndPhysicalWindows': 'OPEN'}
output = work / 'only-check-retention-and-disposition-v1.json'
assert not output.exists()
output.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
print({k: proof[k] for k in ['status', 'cases', 'methods', 'passed', 'failed', 'skipped', 'all73NewDestructionCasesPassed']})
for detail in details:
    print(detail['name'], (detail['message'] or '')[:900])
