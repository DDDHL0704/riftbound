import datetime
import hashlib
import json
import os
import pathlib
import plistlib
import subprocess

work = pathlib.Path(__file__).resolve().parent; root = work.parents[2]
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
output = work / 'postcheck-current-focus-v27-integrity.json'
assert not output.exists() and (work / 'postcheck-source-repairs-v2.json').exists()
publication = json.loads((work / 'frozen-sql-publication-inputs-v2.json').read_text())
assert all(sha(root / p) == h for p, h in publication['sourceInputHashes'].items())
def locked():
    raw = plistlib.loads(subprocess.check_output(['/usr/sbin/ioreg', '-n', 'Root', '-d', '1', '-a']))
    return [{'rootLocked': x.get('IOConsoleLocked'), 'sessionLocked': [v.get('CGSSessionScreenIsLocked') for v in x.get('IOConsoleUsers', [])]}
        for x in (raw if isinstance(raw, list) else [raw])]
with (work / 'postcheck-conformance-build-v1.log').open('x') as log:
    subprocess.run(['/Users/dinghaolin/.dotnet/dotnet', 'build', 'tests/Riftbound.ConformanceTests/Riftbound.ConformanceTests.csproj',
                    '-m:1', '-v:q', '--nologo'], cwd=root, stdout=log, stderr=subprocess.STDOUT, check=True)
runtime = root / 'tests/Riftbound.ConformanceTests/bin/Debug/net10.0'
modules = {str(p.relative_to(root)): sha(p) for p in runtime.rglob('*') if p.is_file()
    and (p.suffix in {'.dll', '.pdb'} or p.name.endswith(('.deps.json', '.runtimeconfig.json')) or p.is_relative_to(runtime / 'data') or p.is_relative_to(runtime / 'Fixtures'))}
probe = work / 'identity-probe/bin/Debug/net10.0/probe.dll'
identity = json.loads(subprocess.check_output(['/Users/dinghaolin/.dotnet/dotnet', str(probe), str(runtime)], cwd=root, text=True))
record = {'status': 'RUNNING_CURRENT_POSTCHECK_FOCUS_NOT_ACCEPTANCE', 'startedAtUtc': now(), 'lockAtStart': locked(),
    'actualConformanceDebugIdentity': identity, 'sourceInputHashes': publication['sourceInputHashes'], 'actualRuntimeFiles': modules,
    'originalSoleCheckRetainedNoSecondCheck': True, 'sourceAndRuntimeMustStayFrozen': True}
output.write_text(json.dumps(record, indent=2) + '\n')
names = ['DestructionGraveyardFamilyTests', 'DestructionGraveyardLifecycleTests', 'DestructionGraveyardRecoveryTests',
    'DestructionGraveyardPublicViewTests', 'CoreRuleEnginePlaysNoxianGuillotineAndNextDamageDestroysUnit',
    'CoreRuleEnginePlaysImperialDecreeAndDamageDestroysUnit', 'RecoveryValidatorRejectsSnapshotTimingTriggerQueueTriggeredEventKindDrift',
    'RecoveryValidatorRejectsAuthoritativeStateTriggerQueueTriggeredEventKindDrift',
    'RecoveryValidatorRejectsSpectatorReplayTimingTriggerQueueKeyedKnownValueCanonicalityWithCountMismatch',
    'RecoveryValidatorRejectsSpectatorReplayTimingTriggerQueueKeyedVisibleSourceTriggeredEventKindInvalidValueWithoutCountMismatch',
    'RecoveryValidatorRejectsAuthoritativeStateUntilEndOfTurnEffectValueDrift',
    'FullGamePrivacyGuardAllowsOnlyCurrentRevealedGenerationsAndNeverDeckIdentities',
    'P6LifecycleTriggerReplacementFamiliesReportSpecAndExecutionBoundaryCoverage',
    'OfficialDeckMidgameResolvesVoidGateTargetSpellSkillDamageBonusAndScoreVictoryActionLogReplaysToFinalStateHash',
    'OfficialDecksResolveMultiDefenderBattleDamageAssignmentScoreVictoryActionLogReplaysToFinalStateHash',
    'CoordinatedEarlierDelayedCreationTickPassesShapeButOriginalJournalRejectsIt']
args = ['python3', str(root / 'scripts/test-rules.py'), 'focus', '--include-games']
for name in names:
    args += ['--match', name]
args += ['--output', str(work / 'focus-v27-postcheck-current-family-and-originals')]
power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
code = None
try:
    env = dict(os.environ); env.pop('ConnectionStrings__Riftbound', None)
    with (work / 'focus-v27-postcheck-current-family-and-originals-runner.log').open('x') as log:
        code = subprocess.run(args, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT).returncode
finally:
    if power.poll() is None:
        power.terminate(); power.wait(timeout=10)
    changed_source = [p for p, h in publication['sourceInputHashes'].items() if sha(root / p) != h]
    changed_runtime = [p for p, h in modules.items() if sha(root / p) != h]
    record.update(status='PASS_CURRENT_POSTCHECK_FOCUS' if code == 0 and not changed_source and not changed_runtime else 'FAILED_CURRENT_POSTCHECK_FOCUS',
        focusedExitCode=code, changedSourceInputs=changed_source, changedRuntimeFiles=changed_runtime,
        finishedAtUtc=now(), lockAtEnd=locked(), boundIdleSleepAssertionEnded=power.poll() is not None)
    output.write_text(json.dumps(record, indent=2) + '\n')
assert code == 0 and not changed_source and not changed_runtime
summary = json.loads((work / 'focus-v27-postcheck-current-family-and-originals/summary.json').read_text())
assert summary['total'] == 78
record.update(actualCases=78, actualMethods=34, soleCheckNotRepeated=True)
output.write_text(json.dumps(record, indent=2) + '\n')
print('CURRENT_POSTCHECK78_CASES_WITH_TWO_ORIGINAL_FULL_GAMES_AND_COORDINATED_REJECTION_PASS', flush=True)
