import copy
import datetime
import gzip
import hashlib
import importlib.util
import json
import os
import pathlib
import subprocess

root = pathlib.Path.cwd()
work = pathlib.Path(__file__).resolve().parent
evidence = root / 'docs/evidence/destruction-graveyard-2026-10-20'
identity = 'destruction-attribution-delayed-skill-graveyard-play-2026-10-20'
base = '08fd25c0dc643f9120b529f039feed69beffc251'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
def pin(path, role=None):
    return {'path': str(path.relative_to(root)), 'sha256': sha(path), 'role': role or path.stem}

assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == base
assert not evidence.exists()
sql = load(work / 'real-sql-verification-v2.json')
check = load(work / 'only-check-retention-and-disposition-v1.json')
diagnostic = load(work / 'precheck-existing-diagnostic-closure-v1.json')
tools = load(work / 'final-tool-and-yaml-validation-v1.json')
assert sql['status'] == 'PASS_REAL_SQL_SIX_ORIGINALS_PARTITION_DISPATCH_AND_INDEPENDENT_READONLY_FULL_REPLAY'
assert sql['ownPostgresSmartStopped'] and sql['allFrozenRuntimeAndHarnessInputsStillExact']
assert check['noSecondCheck'] and check['skipped'] == 0 and check['all73NewDestructionCasesPassed']
postcheck_path = work / 'postcheck-three-failures-current-closure-v2.json'
postcheck = load(postcheck_path)
assert check['failed'] == 3
assert postcheck['status'] == 'PASS_THREE_ORIGINAL_FAILURES_CURRENT_FOCUS78_SQL6_TWO_ORIGINAL_FULL_GAMES_NO_SECOND_CHECK'
assert postcheck['actualCurrentFocusedCases'] == 78 and postcheck['allOriginalNegativeAssertionsAndWinReplayAssertionsRetained']
assert set(postcheck['closedOriginalFailureNames']) == {row['name'] for row in check['failures']}
assert sql['actualRuleInputs'] == postcheck['currentFrozenReleaseSqlRuleInputs']
check_text = (f"{check['cases']}例/{check['methods']}方法，{check['passed']}通过、3失败、零跳过；"
    "修复空列表恢复校验异常、独立隐私断言的异常契约，并仅校准有精确来源支撑的四处目录统计常量后，"
    "当前78例/34方法、两条原完整对局和六场新SQL原局通过。原失败保留，不改写为check全绿，没有第二次check")
assert diagnostic['productionModulesByteExact'] and diagnostic['focusedExitCode'] == 0
assert tools['pythonTests'] == 73 and tools['exitCode'] == 0 and tools['actualYamlParsed']

manifest_path = root / 'docs/audit/current-manifest.json'
reviews_path = root / 'docs/evidence/rules-reaudit-2026-10-11/review-decisions.json'
prior = load(manifest_path); original_reviews = load(reviews_path)
assert len(prior['reviewContexts']) == 56 and len(prior['acceptanceGates']) == 232 and len(original_reviews['reviews']) == 141
old_ids = set(json.loads(gzip.decompress((root / 'docs/evidence/hwei-move-discard-types-2026-10-20/remaining-obligation-ids.json.gz').read_bytes())))
assert len(old_ids) == 16892
(work / 'pre-destruction-original-current-manifest.json.gz').write_bytes(gzip.compress(manifest_path.read_bytes(), mtime=0))
(work / 'pre-destruction-original-review-decisions.json.gz').write_bytes(gzip.compress(reviews_path.read_bytes(), mtime=0))
evidence.mkdir(parents=True)
archives = []
exclude = {'bin', 'obj', '__pycache__', 'frozen-sql-v1', 'frozen-sql-v2', 'fixed-api', 'native-current'}
published_probe_roots = {'fixed-sql-probe', 'native-network', 'score-network'}
raw_suffixes = {'.json', '.jsonl', '.gz', '.zip', '.png', '.jpg', '.jpeg', '.webp'}
text_suffixes = {'.py', '.cs', '.csproj', '.trx', '.log', '.js', '.html', '.txt', '.md', '.c', '.yml', '.yaml'}
for folder, prefix in [
        (root / 'var/qa/hwei-fixed-08fd-20261020', 'n17'),
        (root / 'var/qa/phoenix-destroy-source-20261020', 'n18'),
        (work, 'n19'), (root / 'var/qa/sql-ci-partition-20261020', 'ci'),
        (root / 'var/qa/global-gallery-gap-20261020', 'global-source-followup')]:
    for path in sorted(folder.rglob('*')):
        relative = path.relative_to(folder)
        if not path.is_file() or exclude & set(relative.parts) or any(p.endswith('.app') for p in relative.parts):
            continue
        if relative.parts[0] in published_probe_roots and path.suffix not in {'.cs', '.csproj'}:
            continue
        if path.suffix not in raw_suffixes | text_suffixes:
            continue
        compressed = path.suffix in text_suffixes
        target = evidence / prefix / relative
        if compressed:
            target = target.with_name(target.name + '.gz')
        target.parent.mkdir(parents=True, exist_ok=True)
        assert not target.exists()
        if compressed:
            target.write_bytes(gzip.compress(path.read_bytes(), mtime=0))
        else:
            os.link(path, target)
        archives.append({'originalPath': str(path.relative_to(root)), 'originalBytes': path.stat().st_size,
                         'originalSha256': sha(path), 'canonical': pin(target),
                         'gzipOriginalBytes': compressed, 'samePhysicalFileHardlinked': not compressed})

parents = load(work / 'coherent-batch-progress-and-obligation-checkpoint-v1.json')['existing22ParentObligationIds']
assert len(parents) == 22
source_refs = [value.removeprefix('CARD:').removeprefix('RULE:') for value in parents]
source_manifest = {
    'recordedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'region': 'CN', 'language': 'zh-CN', 'applicableAsOf': '2026-10-16', 'observedAtAsiaShanghai': '2026-10-20',
    'rulesEffectiveBaseline': '2026-10-16', 'baseCommit': base, 'includesExplicitUncommittedImplementation': True,
    'scope': 'Actual destruction source/responsibility, Decree and Guillotine independent finite delayed skills, Phoenix graveyard self/simultaneous observation, leading cost and original-incarnation normal effect play only.',
    'freshOfficialSources': pin(evidence / 'n18/fresh-source-intake-v1.json'),
    'additionalExactNoxianAndUnitDamageSources': pin(evidence / 'n18/additional-attribution-consumer-source-intake-v1.json'),
    'currentCoreFaqBranchReadback': pin(evidence / 'n18/current-core-faq-branch-readback-v1.json'),
    'faqTitleExplicitCorrection': pin(evidence / 'n18/faq-title-explicit-correction-v1.json'),
    'leadingCostClauseExplicitCorrection': pin(evidence / 'n18/leading-trigger-cost-clause-correction-v1.json'),
    'originalFullGameFileCountExplicitCorrection': pin(evidence / 'n19/original-fullgame-retention-before-security-v1.json'),
    'exactPrintings': ['OGN·037/298', 'OGN·221/298', 'OGN·254/298', 'OGN·009/298', 'UNL-118/219', 'UNL-118a/219'],
    'existingParentObligationIds': parents,
    'currentClauses': ['204.1.c', '383.2.c.1', '391.2', '412.5', '418.6.b.3-4', '429.5.b-d'],
    'faqExactRecords': ['CN-59bd828207564540-P021-B002', 'CN-59bd828207564540-P021-B003', 'CN-59bd828207564540-P021-B004'],
    'faqOfficialTitle': '《符文战场》化神争锋系列 官方FAQ',
    'sourceBytesUnchangedNotNewTemporalDelta': True, 'unknownSinglePrintingPublicationAndEffectiveDatesRemainNull': True,
    'faqIllustratedVariantFooterIdentity': 'FIVE_EXACT_PRINTED_CODES_READ_PHYSICAL_FINISH_JOIN_OPEN',
    'nativeFaqPage21FooterReadback': pin(evidence / 'n19/faq-page21-exact-footer-readback-v1.json'),
    'original08fdCounterexamplesAndFullReadOnlyReplay': pin(evidence / 'n18/ordinary-counterexamples-and-finite-family-checkpoint-v2.json'),
    'prior08fdFixedNativeSqlNetworkProofOnly': pin(evidence / 'n17/locked-fixed-candidate-continuation-checkpoint-v1.json'),
    'currentConformanceDebugRuleInputs': postcheck['currentConformanceDebugRuleInputs'],
    'earlierSoleCheckDebugRuleInputs': check['actualConformanceDebugRuleInputs'],
    'actualFrozenReleaseSqlRuleInputs': sql['actualRuleInputs'],
    'actualLocalPartialReceiptRejectedAsFull': pin(evidence / 'n19/actual-partial-rejects-full-sql-gate-v1.json'),
    'releaseAndDebugAndOldNativeAndFutureFixedModulesNotInterchanged': True,
    'soleCheck': pin(evidence / 'n19/only-check-retention-and-disposition-v1.json'),
    'soleCheckOriginalFailureNotRelabeledGreen': bool(check['failed']),
    'postCheckFocusedClosure': pin(evidence / 'n19/postcheck-three-failures-current-closure-v2.json'),
    'boundedBranchToExactTestIdentityMatrix': pin(evidence / 'n19/bounded-behavior-evidence-matrix-v2.json'),
    'realSql': pin(evidence / 'n19/real-sql-verification-v2.json'),
    'earlierPreRepairReleaseSqlOriginalIdentityAndHistoryRetained': pin(evidence / 'n19/real-sql-verification-v1.json'),
    'actualPriorB294FullTimeout': pin(evidence / 'ci/actual-b294-sql-timeout-disposition-v1.json'),
    'actual08fdRulesOnly': pin(evidence / 'n19/08fd-original-rule-verification-v1.json'),
    'all1740Printings36HistoricalDocuments14293BlocksOriginalDatesEn8GapCn236DispositionsAndFiveSourceDeltasRetained': True,
    'newFixedFull': 'PENDING', 'visibleCurrentNativeAndPhysicalWindows': 'OPEN',
    'regionalTournamentEligibilityCertified': False, 'wholePrintingCertified': False, 'semanticCoverageCertified': False,
    'latestEffectiveChangesMustBeRecheckedBeforeFinalAcceptance': True}
source_manifest['separateGlobalEnReadOnlyFollowupNotCnCertification'] = {
    'freshViews': pin(evidence / 'global-source-followup/current-source-views-v1.json'),
    'actualSsrAndEightPages': pin(evidence / 'global-source-followup/ssr-and-pagination-readback-v1.json'),
    'boundedUnstableLocalization': pin(evidence / 'global-source-followup/source-window-instability-readback-v1.json'),
    'allEightOriginalSourceGapObligationsRemainOpen': True,
    'all1408ExistingWholeRowsExactNoSemanticTemporalDeltaOrRuntimeInputChange': True}
write(evidence / 'source-manifest.json', source_manifest)
source_pin = pin(evidence / 'source-manifest.json')
scopes = [
    ('ACTUAL_SPELL_DESTRUCTION_SOURCE_RESPONSIBILITY', 'Actual current-command spell damage cleanup and explicit destruction retain source printing, controller and responsible player; no arbitrary old damage attribution.'),
    ('UNIT_COMBAT_AND_NAMED_DUEL_DAMAGE_NOT_SPELL', 'Actual combat and named unit damage in both reviewed duel instructions do not earn the spell-destruction trigger; opponent responsibility remains distinct.'),
    ('PHOENIX_SELF_AND_SIMULTANEOUS_GRAVEYARD_OBSERVERS', 'Existing graveyard sources, self destruction and actual same simultaneous batch capture distinct earned triggers.'),
    ('PHOENIX_LEADING_ONE_MANA_ONE_RED_PAY_OR_DECLINE', 'Leading cost must be confirmed before response; actual pay/decline, typed resources, stale/wrong actor/window and duplicate payloads are independently checked.'),
    ('PHOENIX_CAPTURED_GRAVEYARD_GENERATION_SHARED_PLAY', 'Earned ability survives source departure; shared effect play uses only the captured original graveyard incarnation and ordinary legality/extra costs.'),
    ('DECREE_INDEPENDENT_DELAYED_DAMAGE_DESTRUCTION', 'Positive actual damage queues an independent original-source skill; zero prevention, later entrants, multiple copies, response return and expiry are bounded tested branches.'),
    ('GUILLOTINE_ORIGINAL_INSPIRE_OR_NEXT_DAMAGE', 'Original cast determines immediate inspired destruction versus original-target next-positive-damage skill; later responses cannot retrospectively upgrade it.'),
    ('DESTRUCTION_CONTEXT_STATE_PRIVATE_SPECTATOR_AND_JOURNAL', 'Exact source/controller/printing/generation/window contexts validated independently in state and public views; coordinated earlier historical creation tick rejected by original journal.'),
    ('DESTRUCTION_ORIGINAL_ORDINARY_SQL_COLD_NEXT_AND_REPLAY', 'Six actual legal blank seed0 ordinary branches in two named engine formats retain all original history, exact cold restore, next command, private views and full replay.')]
branches = []
matrix = {row['id']: row for row in load(work / 'bounded-behavior-evidence-matrix-v2.json')['branches']}
for branch, detail in scopes:
    branches.append({'id': branch, 'sourceRefs': source_refs, 'sourceManifest': source_pin, 'state': 'RECORDED',
        'branchScope': detail, 'decision': {'state': 'OPEN', 'reason': 'Bounded source, implementation, test and real SQL evidence only. New fixed full, current visible product and physical Windows gates remain open.'},
        'semanticReview': 'LIMITED_CURRENT_CN_SOURCE_AND_EXACT_REVIEWED_BEHAVIOR_BRANCHES',
        'implementation': 'FINITE_SHARED_DESTRUCTION_GRAVEYARD_FLOW_WITHOUT_MIGRATION_OR_DSL',
        'testExecution': 'ORIGINAL_SOLECHECK3_FAILURES_CURRENT_FOCUS78_SQL6_TWO_ORIGINAL_FULL_GAMES_CLOSED',
        'actualTestEvidence': {'matrix': pin(evidence / 'n19/bounded-behavior-evidence-matrix-v2.json'),
            'caseKeys': matrix[branch]['actualCaseKeys'], 'methodNames': matrix[branch]['actualMethodNames'],
            'reviewedClausesOrPrinting': matrix[branch]['preciseReviewedClausesOrPrinting'],
            'additionalOpenExecution': matrix[branch]['additionalOpenExecution']},
        'fixedCommitCi': 'PENDING_NEW_FIXED_FULL_FOUR_SQL_PARTITIONS', 'productAcceptance': 'OPEN',
        'wholePrintingCertified': False,
        'remaining': ['NEW_FIXED_FULL_ALL_ORIGINAL_METHODS_THEORIES143_FULL_METHODS110_PAIRS_SEEDS_AND45_SQL_IDENTITIES',
            'VISIBLE_CURRENT_NATIVE_CONTROLS_PAIRED_SQL_NETWORK_NORMAL_SCORE_FULL_REPLAY', 'PHYSICAL_WINDOWS',
            'WHOLE_PRINTING_OTHER_COPY_CONTROL_REPLACEMENT_SIMULTANEOUS_AND_OTHER_CONSUMERS', 'FAQ_ILLUSTRATED_PRINTING_IDENTITY_AND_ALL_ORIGINAL_SOURCE_GAPS']})
retention_name = 'all-original-test-and-theory-source-retention-v3.json' if (work / 'all-original-test-and-theory-source-retention-v3.json').exists() else 'all-original-test-and-theory-source-retention-v2.json'
evidence_files = [evidence / 'n19/only-check-retention-and-disposition-v1.json',
    evidence / 'n19/postcheck-current-focus-v27-integrity.json', evidence / 'n19/real-sql-verification-v2.json',
    evidence / 'n19/independent-actual-sql-reader-result-v2.json', evidence / 'n19' / retention_name,
    evidence / 'n19/precheck-existing-diagnostic-closure-v1.json', evidence / 'n19/final-tool-and-yaml-validation-v1.json',
    evidence / 'ci/compiled-plan-and-original-workflow-core-retention-v2.json', evidence / 'ci/retention-v1-failure-reason-explicit-correction-v3.json',
    evidence / 'n19/bounded-behavior-evidence-matrix-v2.json', evidence / 'n19/actual-partial-rejects-full-sql-gate-v1.json',
    evidence / 'n19/faq-page21-exact-footer-readback-v1.json', evidence / 'n19/catalog-boundary-independent-old-current-comparison-v1.json']
evidence_files.append(evidence / 'n19/postcheck-three-failures-current-closure-v2.json')
reviews = copy.deepcopy(original_reviews)
reviews['reviews'].append({'id': identity, 'scope': 'CN/zh-CN effective core baseline2026-10-16; current20Oct exact destruction attribution, delayed damage destroy and Phoenix graveyard instruction branches only.',
    'status': 'LIMITED_IMPLEMENTATION_CURRENT_FOCUS78_SQL6_SOLECHECK3_FAILURES_CLOSED_FIXEDFULL_PRODUCT_OPEN',
    'subjects': source_manifest['exactPrintings'], 'ruleRecords': source_manifest['faqExactRecords'], 'pendingRuleRecords': [],
    'sourceManifest': source_pin, 'auditDocument': 'docs/DESTRUCTION_GRAVEYARD_AUDIT_2026-10-20.md',
    'validation': {'soleCheck': pin(evidence_files[0]), 'realSql': pin(evidence_files[2]),
        'newFixedFull': 'PENDING', 'visibleCurrentNativeProduct': 'OPEN', 'physicalWindows': 'OPEN'},
    'exclusions': ['WHOLE_PRINTING_AND_ALL_OTHER_CONSUMERS_COPY_CONTROL_REPLACEMENT_AND_LIFECYCLE_BRANCHES',
        'FAQ_ILLUSTRATED_PRINTING_IDENTITY', 'GLOBAL_SOURCE_GAPS', 'NEW_FIXED_FULL', 'VISIBLE_NATIVE_PRODUCT', 'PHYSICAL_WINDOWS'],
    'evidence': [str(p.relative_to(root)) for p in evidence_files]})
assert reviews['reviews'][:-1] == original_reviews['reviews']
write(reviews_path, reviews)

spec = importlib.util.spec_from_file_location('governance', root / 'scripts/audit/check-project-governance.py')
checker = importlib.util.module_from_spec(spec); spec.loader.exec_module(checker)
revision = checker.digest(checker.gameplay_inputs(root))
manifest = copy.deepcopy(prior); rebindings = []
for key, context in manifest['reviewContexts'].items():
    changes = []
    for field in ['implementation', 'verificationSources']:
        for ref in context.get(field, []):
            current = sha(root / ref['path'])
            if current == ref['sha256']:
                continue
            changes.append({'field': field, 'path': ref['path'], 'previousSha256': ref['sha256'], 'currentSha256': current})
            ref['sha256'] = current
    context.setdefault('implementationPinUpdates', []).append({'batch': identity, 'changes': changes,
        'previousCurrentMetadata': {f: context.get(f) for f in ['currentInputRevision', 'currentImplementationCommit', 'currentImplementationIncludesUncommittedChanges']},
        'previousEntireContextPreservedIn': 'docs/evidence/destruction-graveyard-2026-10-20/n19/pre-destruction-original-current-manifest.json.gz',
        'scope': 'Explicit current input rebind only. Original evidence commits, CI receipts, semantic branches, dates and exclusions retained. New fixed full required.'})
    context.update(currentInputRevision=revision, currentImplementationCommit=base, currentImplementationIncludesUncommittedChanges=True,
        ciState='PENDING', revalidationReason='Shared destruction source, delayed skills, graveyard effect play and recovery validation changed; prior full evidence does not certify current inputs.')
    rebindings.append({'review': key, 'previousContextSha256': checker.digest(prior['reviewContexts'][key]), 'pinChanges': changes})
manifest['inputs']['reviews'] = pin(reviews_path, prior['inputs']['reviews'].get('role', 'reviews'))
implementation_paths = sorted(set(subprocess.check_output(['git', 'diff', '--name-only', 'HEAD', '--', 'src'], text=True).splitlines()
    + ['src/Riftbound.Engine/CoreRuleEngine.DamageDestruction.cs', 'src/Riftbound.Engine/CoreRuleEngine.DestructionAttribution.cs',
       'src/Riftbound.Engine/CoreRuleEngine.GraveyardPlay.cs', 'src/Riftbound.Engine/MatchRecovery.DestructionFamily.cs']))
verification_paths = sorted(set(subprocess.check_output(['git', 'diff', '--name-only', 'HEAD', '--', 'tests', 'scripts', '.github'], text=True).splitlines()
    + [str(p.relative_to(root)) for p in (root / 'tests/Riftbound.ConformanceTests').glob('Destruction*.cs')]
    + ['tests/Riftbound.ConformanceTests/Fixtures/destruction-graveyard-openings.json',
       'tests/Riftbound.PostgresAcceptance/DestructionGraveyardSqlAcceptance.cs', 'tests/Riftbound.PostgresAcceptance/SqlAcceptancePartition.cs',
       'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json', 'scripts/sql-ci-gate.py', 'scripts/tests/test_sql_ci_gate.py']))
manifest['reviewContexts'][identity] = {'evidenceCommit': base, 'currentImplementationCommit': base,
    'currentImplementationIncludesUncommittedChanges': True, 'evidenceCommitScope': 'Base08fd plus declared uncommitted source/test/SQL/CI inputs. Actual precommit Debug and Release evidence distinct from old08fd native and future fixed modules.',
    'currentInputRevision': revision, 'ciState': 'PENDING', 'ciReceipts': [], 'region': 'CN', 'language': 'zh-CN', 'applicableAsOf': '2026-10-16',
    'sourceManifest': source_pin, 'implementation': [pin(root / p, 'implementation') for p in implementation_paths],
    'verificationSources': [pin(root / p, 'verification') for p in verification_paths],
    'evidence': [pin(p) for p in evidence_files], 'branches': branches}
for gate, requirement in [
    ('DESTRUCTION_GRAVEYARD_NEW_FIXED_FULL_VISIBLE_AND_WINDOWS', 'New fixed full with every original method/Theory,143 full methods,110 directed pairs,original seeds and45 SQL execution identities; separately current visible paired real SQL/network/normal-score/full-replay and physical Windows.'),
    ('ALL_SQL_PARTITIONS_REAL_EXECUTION_AND_NETWORK_AFTER_TIMEOUT', 'Actual fixed full terminal success of all four checked SQL partitions plus independent native network; all45 ordered execution identities and raw artifacts required. Local plan, synthetic gate tests and one-case44of45 execution cannot close it.')]:
    manifest['acceptanceGates'].append({'id': gate, 'state': 'OPEN', 'region': 'CN', 'language': 'zh-CN', 'sourceManifest': source_pin,
        'requirement': requirement, 'semanticReview': 'LIMITED_SOURCE_AND_BRANCHES_ONLY', 'implementation': 'FINITE_SHARED_FLOW_AND_CHECKED_CI_DISPATCH',
        'testExecution': 'CURRENT_FOCUS78_SQL6_ORIGINAL_SOLECHECK3_FAILURES_CLOSED_AND73_TOOL_GUARDS', 'fixedCommitCi': 'PENDING', 'productAcceptance': 'OPEN', 'wholePrintingCertified': False})
assert manifest['acceptanceGates'][:-2] == prior['acceptanceGates'] and manifest['laterSourceDeltas'] == prior['laterSourceDeltas']
manifest['currentDestructionGraveyardInputChange'] = source_pin
manifest['currentSqlPartitionTimeoutConvergence'] = pin(evidence / 'ci/actual-b294-sql-timeout-disposition-v1.json')
manifest['currentGlobalGalleryReadOnlyFollowup'] = pin(evidence / 'global-source-followup/source-window-instability-readback-v1.json')
write(manifest_path, manifest)
result = checker.current_audit(root, manifest)
assert result['governanceValid'], result['errors']
new_ids = {row['id'] for row in result['remainingObligations']}
assert old_ids <= new_ids and len(new_ids - old_ids) == 11
assert reviews['reviews'][:-1] == original_reviews['reviews'] and manifest['laterSourceDeltas'] == prior['laterSourceDeltas']
write(evidence / 'current-context-rebindings.json', {'previousEntireContextSnapshot': pin(evidence / 'n19/pre-destruction-original-current-manifest.json.gz'),
    'all56OriginalContextsPreservedBeforeExplicitCurrentRebind': True, 'allOriginalEvidenceCommitsCiReceiptsSemanticBranchesDatesAndExclusionsRetained': True,
    'currentInputRevision': revision, 'explicitRebindings': rebindings, 'newReview': identity})
write(evidence / 'unified-obligation-retention.json', {'previousManifestCommit': base, 'priorRemainingObligations': len(old_ids),
    'currentRemainingObligations': len(new_ids), 'all16892OriginalIdsRetained': True, 'all22ParentIdsRetained': set(parents) <= new_ids,
    'newObligationIds': sorted(new_ids - old_ids), 'all141OriginalSemanticReviewDictionariesExact': True,
    'all56OriginalContextsPreservedBeforeExplicitRebind': True, 'all232OriginalGateDictionariesExact': True,
    'allFiveTemporalDeltaDictionariesExact': True, 'currentReviews': 142, 'currentContexts': 57, 'currentGates': 234,
    'allOriginalSourceUniversesDatesAndGapsRetained': True, 'semanticCoverageCertified': False})
assert set(parents) <= new_ids
(evidence / 'remaining-obligation-ids.json.gz').write_bytes(gzip.compress(json.dumps(sorted(new_ids), ensure_ascii=False, indent=2).encode() + b'\n', mtime=0))
write(evidence / 'governance-validation.json', {'governanceValid': result['governanceValid'], 'errors': result['errors'],
    'remainingObligationCount': len(new_ids), 'allRemainingIds': pin(evidence / 'remaining-obligation-ids.json.gz'),
    'semanticCoverageCertified': False, 'currentInputRevision': revision})
write(evidence / 'archive-map.json', {'records': archives, 'noNativePackagesRuntimeAssembliesWholeCheckoutDatabaseOrDuplicatePdfCopied': True})
doc = (work / 'DESTRUCTION_GRAVEYARD_AUDIT_2026-10-20.md').read_text()
doc = doc.replace('@SQL_RESULT@', f"六场不同原局共{sql['commands']}命令{sql['events']}事件、{sql['coldRestores']}冷恢复、{sql['originalNextCommandsMatched']}原下一命令和{sql['atomicRejections']}独立原子拒绝通过；实际分片调度44/45只执行本族一个助手，不是四片完整SQL通过")
doc = doc.replace('@CHECK_RESULT@', check_text + f"；原13027例多重集合和7440方法完整保留，新增73例/24方法全部通过。四条旧诊断预检查失败已仅补独立DAMAGE_APPLIED预期后定向通过；check前后{check['declaredSourceInputCount']}源码输入及{check['runtimeFileCount']}载荷文件稳定")
doc = doc.replace('@GOVERNANCE_RESULT@', f"统一清单现142审查、57上下文、234门禁、{len(new_ids)}剩余义务；原141审查、56上下文快照、232门禁和五来源增量完整保留，治理0错误，全量语义未认证")
assert '@SQL_' not in doc and '@CHECK_' not in doc and '@GOVERNANCE_' not in doc
(root / 'docs/DESTRUCTION_GRAVEYARD_AUDIT_2026-10-20.md').write_text(doc)
status_path = root / 'docs/PROJECT_STATUS.md'; old = status_path.read_text(); assert old.startswith('# 当前项目状态\n')
intro = f'''
2026-10-20 当前批次：[销毁归因、独立延迟销毁及废牌堆打出](DESTRUCTION_GRAVEYARD_AUDIT_2026-10-20.md)。CN/zh-CN、适用基线10-16，当前官方来源重新取得、精确印次/条款和未知日期分别保留。修复不朽凤凰自毁/同批入废牌堆观察、开头一费一红能确认及原实例共享效果打出；帝国谕令和断头台保留原法术来源/责任、独立延迟响应及鼓舞确定时机。单位战斗/法术指示单位伤害不误归法术，无旧局迁移或DSL扩张。

修复后当前focus78例/34方法含全部原失败、四条旧因果负例、有限规则族、协调日志篡改拒绝及两条原完整得分/回放对局通过。真实SQL另六个新空白seed0局{sql['commands']}命令/{sql['events']}事件、{sql['coldRestores']}冷恢复、{sql['originalNextCommandsMatched']}原下一命令、{sql['atomicRejections']}原子拒绝及独立只读全部原字段/null/历史私有视图和完整回放通过；原178审计/35原生及只读后全部184/35七表不变。此前第一版172→178及其运行身份、原历史保留；当前前缀仍非完整得分局。原库保留、专用库正常停止，实际Release与Debug/旧08fd原生包分别绑定。

唯一check：{check_text}。原13027例多重集合/7440方法及全部旧方法/Theory保留，新增73例在原check全过；四旧诊断预检查失败仅补独立合法事件常量后先行闭合，该阶段生产模块未变。后续空列表修复改变的实际身份另以当前focus/SQL重新验证。九份原完整源码、143方法、110配对、原种子/胜利/回放断言保留；原43默认SQL助手与核心开局保留，加本族一个共45执行身份。73工具检查通过。

b294完整CI39275773327已实际因官方六小时上限cancelled，规则独立通过，SQL未完/网络skipped，不能算整轮通过。08fd规则原产物13176例/7581方法及143原完整方法、110配对、11牌组/424242原种子独立核实；其完整SQL/网络另按实际终态，不覆盖本批。当前将45 SQL身份按精确清单分四片、网络独立首波，稳定postgres/rules门禁要求全部真实固定输入/产物/子任务通过；新的固定full终态仍PENDING，当前不宣称超时已闭合。

当前142审查/57上下文/234门禁/{len(new_ids)}原加新增义务；22原父义务和全部16892原ID、原1740印次/36文档14293块、EN8缺口/CN236处置/五来源增量均保留。FAQ旧本地名称明确纠正为《化神争锋系列 官方FAQ》，FullGame旧总文件数明确纠正为八部分加主文件共九份；不改写旧证据。整卡、插图印次、其他消费者/控制/复制/替代等仍OPEN。

锁屏下持续运行，新固定full、当前可见控件/双端真实库重连/正常得分完整回放和Windows实机分别OPEN。仅最新可用08fd A/B及两平台各一规范包，无新Godot SDK/项目构建、整份工作树或数据库，用户Godot34426未触碰。Goal active / NOT READY。

以下保留此前批次的原始限定记录；当前范围以上述精确收据为准。
'''
status_path.write_text('# 当前项目状态\n' + intro + old[len('# 当前项目状态\n'):])
write(work / 'canonical-publication-v1.json', {'status': 'CANONICAL_BOUNDED_DESTRUCTION_REVIEW_AND_SQL_TIMEOUT_GATES_WRITTEN',
    'reviews': 142, 'contexts': 57, 'gates': 234, 'remainingObligations': len(new_ids), 'newFixedFull': 'PENDING',
    'visibleAndPhysicalWindows': 'OPEN'})
print('CANONICAL_DESTRUCTION_REVIEW_WRITTEN_142_57_234_' + str(len(new_ids)), flush=True)
