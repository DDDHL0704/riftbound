import datetime
import hashlib
import json
import pathlib
import shutil
import subprocess

root = pathlib.Path.cwd(); work = pathlib.Path(__file__).resolve().parent
runtime = work / 'frozen-sql-v2'; output = work / 'frozen-sql-publication-inputs-v2.json'
dotnet = '/Users/dinghaolin/.dotnet/dotnet'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert not output.exists() and not runtime.exists()
terminal = json.loads((work / 'only-check-terminal-integrity-v1.json').read_text())
assert terminal['allDeclaredInputsAndRuntimeFilesStable'] and terminal['checkExitCode'] == 1
assert 'state.UntilEndOfTurnEffects is null' in (root / 'src/Riftbound.Engine/CoreRuleEngine.DamageDestruction.cs').read_text()
with (work / 'frozen-sql-publish-v2.log').open('x') as log:
    subprocess.run([dotnet, 'publish', 'tests/Riftbound.PostgresAcceptance/Riftbound.PostgresAcceptance.csproj',
                    '-c', 'Release', '-o', str(runtime), '-m:1', '-v:q', '--nologo'], cwd=root, stdout=log, stderr=subprocess.STDOUT, check=True)
with (work / 'independent-reader-build-v2.log').open('x') as log:
    subprocess.run([dotnet, 'build', str(work / 'independent-reader-v2/reader.csproj'), '-m:1', '-v:q', '--nologo'],
                   cwd=root, stdout=log, stderr=subprocess.STDOUT, check=True)
for name in ['reader.dll', 'reader.pdb']:
    shutil.copy2(work / 'independent-reader-v2/bin/Debug/net10.0' / name, runtime / name)
args = [dotnet, 'exec', '--depsfile', str(runtime / 'Riftbound.PostgresAcceptance.deps.json'),
        '--runtimeconfig', str(runtime / 'Riftbound.PostgresAcceptance.runtimeconfig.json'), str(runtime / 'reader.dll'), 'identity-print']
identity = json.loads(subprocess.check_output(args, cwd=runtime, text=True))
raw = subprocess.check_output(['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard', '--',
    'src', 'tests', 'data/official', 'scripts', '.github', 'Directory.Build.props', 'Directory.Build.targets', 'global.json', 'Riftbound.slnx'])
paths = sorted(set(value.decode() for value in raw.split(b'\0') if value))
inputs = {path: sha(root / path) for path in paths if (root / path).is_file()}
publication = {'status': 'FROZEN_POSTCHECK_NULL_VALIDATOR_CORRECTION_RELEASE_NOT_FIXED_COMMIT_ACCEPTANCE',
    'frozenAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'baseCommit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'includesUncommittedImplementation': True, 'sourceInputHashes': inputs,
    'runtimeFiles': {str(path.relative_to(runtime)): sha(path) for path in sorted(runtime.rglob('*')) if path.is_file()},
    'actualRuleInputs': identity, 'readerInputs': {str(path.relative_to(work)): sha(path) for path in
        [work / 'independent-reader-v2/Program.cs', work / 'independent-reader-v2/reader.csproj', work / 'run-frozen-sql-v2.py']},
    'workingDiffSha256': hashlib.sha256(subprocess.check_output(['git', 'diff', '--binary', 'HEAD'])).hexdigest(),
    'originalSoleCheckReceiptSha256': sha(work / 'only-check-retention-and-disposition-v1.json'),
    'scope': 'Fresh actual Release after malformed null-list validator repair. Original V1 runtime/SQL results retained under its old identity; V2 creates six new rooms, no migration/history replacement.'}
assert identity != json.loads((work / 'frozen-sql-publication-inputs-v1.json').read_text())['actualRuleInputs']
output.write_text(json.dumps(publication, indent=2) + '\n')
print('FROZEN_POSTCHECK_RELEASE_V2_READY', identity['identitySha256'], flush=True)
