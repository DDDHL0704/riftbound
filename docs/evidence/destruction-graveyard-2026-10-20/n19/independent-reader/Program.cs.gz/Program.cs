using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.CardCatalog;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
if (args.SequenceEqual(new[] { "identity-print" }))
{ Console.WriteLine(JsonSerializer.Serialize(RuleInputIdentity.Current, json)); return; }
Check(args.SequenceEqual(new[] { "independent-readonly" }), "Explicit independent read-only mode required.");
var settings = new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
Check(settings.Host == "127.0.0.1" && settings.Port == 55486 && settings.Database == "riftbound_acceptance"
    && settings.Username == "codex_riftbound_audit", "Existing dedicated audit database required.");
settings.Options = "-c default_transaction_read_only=on";
await using var source = NpgsqlDataSource.Create(settings.ConnectionString);
var work = Path.GetFullPath(Environment.GetEnvironmentVariable("RIFTBOUND_DESTRUCTION_SQL_WORK") ?? throw new Exception("Evidence directory required."));
using var recipe = JsonDocument.Parse(File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "Fixtures/destruction-graveyard-openings.json")));
var phoenix = recipe.RootElement.GetProperty("phoenixObjectId").GetString()!;
var elder = recipe.RootElement.GetProperty("elderObjectId").GetString()!;
var catalog = await OfficialCardCatalog.LoadDefaultAsync();
var checks = new List<object>();
foreach (var format in new[] { "CoreRules", "ChinaStandard20260724" })
foreach (var profile in new[] { "SELF_PAY", "DECREE_PAY", "DECREE_DECLINE" })
{
    var path = Path.Combine(work, $"actual-sql-partition-v1/destruction-graveyard/destruction-{format}-{profile}-original-frame.json.gz");
    using var zip = new GZipStream(File.OpenRead(path), CompressionMode.Decompress);
    var original = await JsonSerializer.DeserializeAsync<MatchRecoveryFrame>(zip, json) ?? throw new Exception("Original SQL frame required.");
    var frame = await new PostgresMatchRecoveryStore(source).LoadAsync(original.RoomId, default) ?? throw new Exception("Persisted original room required.");
    Check(JsonNode.DeepEquals(JsonSerializer.SerializeToNode(original, json), JsonSerializer.SerializeToNode(frame, json)),
        "Every original field, null, command, event, private view and prompt must match the actual database.");
    Check(frame.IsConsistent && frame.OpeningSeed == 0 && frame.ReplayInitialState is { Tick: 0, Seed: 0 } blank
        && blank.CardObjects.Count == 0 && frame.AuthoritativeState!.RuleInputs == RuleInputIdentity.Current
        && frame.Commands.All(c => c.Accepted && c.RuleInputs == RuleInputIdentity.Current), "Blank seed0 and exact runtime identities required.");
    var state = frame.AuthoritativeState!;
    Check(state.Status == MatchStatuses.InProgress && state.CardObjects[phoenix].CardNo == "OGN·037/298"
        && state.CardObjects[elder].CardNo == "UNL-118/219", "Exact physical cards and unfinished game required.");
    Check(frame.Commands.Count(c => c.CommandType == CommandTypes.SubmitDeck) == 2
        && frame.Commands.All(c => c.CommandType != "SURRENDER" && c.CommandType != "DEV_SEED_SCENARIO"), "Original ordinary decks without surrender or injected state.");
    foreach (var command in frame.Commands.Where(c => c.CommandType == CommandTypes.SubmitDeck))
    {
        var deck = (SubmitDeckCommand)GameCommandJsonMapper.Map(command.RawCommand!.Value);
        foreach (var f in new[] { OfficialDeckFormat.CoreRules, OfficialDeckFormat.ChinaStandard20260724 })
            Check(OfficialDeckValidator.Validate(new(deck.LegendCardNo, deck.ChampionCardNo, deck.MainDeck, deck.RuneDeck, deck.Battlefields), catalog, f).IsValid,
                "Independent current catalog legality for each original deck and both declared formats.");
    }
    var paid = profile != "DECREE_DECLINE";
    Check((paid ? state.PlayerZones["P1"].Base : state.PlayerZones["P1"].Graveyard).Contains(phoenix)
        && state.CardObjects[phoenix].ObjectGeneration == (paid ? 4 : 3), "Captured physical Phoenix uses the correct new incarnation or remains in its original graveyard generation.");
    var deaths = frame.Events.Where(e => e.Event.Kind == "UNIT_DESTROYED").ToArray();
    var self = deaths.Single(e => Payload(e).GetProperty("targetObjectId").GetString() == phoenix);
    var selfCause = Payload(self).GetProperty("destructionAttribution");
    Check(selfCause.GetProperty("cardNo").GetString() == "OGN·009/298" && selfCause.GetProperty("fromSpell").GetBoolean()
        && selfCause.GetProperty("responsiblePlayerId").GetString() == "P1", "Self-destruction is attributed to the actual friendly Ray spell.");
    var confirmations = frame.Events.Count(e => e.Event.Kind == "TRIGGER_CONFIRMED" && Payload(e).GetProperty("sourceObjectId").GetString() == phoenix);
    var declines = frame.Events.Count(e => e.Event.Kind == "TRIGGER_PAYMENT_DECLINED" && Payload(e).GetProperty("sourceObjectId").GetString() == phoenix);
    Check(confirmations == (paid ? 1 : 0) && declines == (profile == "SELF_PAY" ? 0 : profile == "DECREE_PAY" ? 1 : 2),
        "Every original leading payment or decline is explicit and independently counted.");
    if (profile != "SELF_PAY")
    {
        var delayed = deaths.Single(e => Payload(e).GetProperty("targetObjectId").GetString() == elder);
        var cause = Payload(delayed).GetProperty("destructionAttribution");
        var decreeSource = cause.GetProperty("source").GetProperty("objectId").GetString()!;
        Check(cause.GetProperty("cardNo").GetString() == "OGN·221/298" && cause.GetProperty("controllerId").GetString() == "P1"
            && cause.GetProperty("responsiblePlayerId").GetString() == "P1" && cause.GetProperty("fromSpell").GetBoolean()
            && state.CardObjects[decreeSource].CardNo == "OGN·221/298", "Independent delayed skill preserves the original Decree spell and its responsible player.");
        var damage = frame.Events.Single(e => e.Event.Kind == "DAMAGE_APPLIED" && Payload(e).GetProperty("targetObjectId").GetString() == elder
            && Payload(e).GetProperty("sourceObjectId").GetString() == recipe.RootElement.GetProperty("decreeRayIntent").GetProperty("rawCommand").GetProperty("sourceObjectId").GetString());
        Check(Payload(damage).GetProperty("damage").GetInt32() == 3 && damage.Tick < delayed.Tick
            && !deaths.Any(e => e.Tick == damage.Tick && Payload(e).GetProperty("targetObjectId").GetString() == elder),
            "The actual nonlethal Ray damage and later independent destruction occur in different resolution commands.");
        Check(state.PlayerZones["P2"].Graveyard.Contains(elder), "The original opponent Elder is actually in its graveyard.");
    }
    var counts = new Dictionary<string, int>();
    await using (var connection = await source.OpenConnectionAsync())
    {
        Check((string)(await new NpgsqlCommand("show transaction_read_only", connection).ExecuteScalarAsync())! == "on", "Database enforces independent read-only transactions.");
        foreach (var table in new[] { "state_snapshots", "snapshots", "action_prompts" })
        {
            await using var command = new NpgsqlCommand($"select payload::text from {table} where match_id=@room order by id", connection);
            command.Parameters.AddWithValue("room", frame.RoomId);
            await using var rows = await command.ExecuteReaderAsync(); var count = 0;
            while (await rows.ReadAsync())
            {
                var raw = rows.GetString(0); var node = JsonNode.Parse(raw);
                var roundtrip = table switch {
                    "state_snapshots" => JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<MatchState>(raw, json), json),
                    "snapshots" => JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<SnapshotDto>(raw, json), json),
                    _ => JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<ActionPromptDto>(raw, json), json) };
                Check(JsonNode.DeepEquals(node, roundtrip), "Every field and null in every original historical state, private snapshot and prompt survives the typed read exactly."); count++;
            }
            Check(count > 0, "Original historical SQL payload rows required."); counts[table] = count;
        }
    }
    var errors = await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame, new CoreRuleEngine(), default);
    Check(errors.Count == 0, "Independent full original action/event/state replay: " + string.Join(';', errors));
    checks.Add(new { room = frame.RoomId, format, profile, commands = frame.Commands.Count, events = frame.Events.Count,
        allStoredFieldsAndNullsAndPrivateViewsExact = true, originalSeed = 0, originalPhysicalGeneration = paid ? 4 : 3,
        originalHistoricalPayloadsRoundtripped = counts, confirmations, declines,
        independentSourceResponsibilityAndDelayedTick = true, fullOriginalReplayMatched = true });
}
Console.WriteLine(JsonSerializer.Serialize(new { status = "PASS_ACTUAL_INDEPENDENT_READONLY_DESTRUCTION_ORIGINAL_FRAMES", checks,
    actualRuleInputs = RuleInputIdentity.Current, noNewRoomStateSeedOrHistoryRewrite = true,
    completeGameOrWholeCardCertification = false, visibleAndPhysicalWindows = "OPEN" }, json));
static JsonElement Payload(RecoveredEvent e) => JsonSerializer.SerializeToElement(e.Event.Payload);
static void Check(bool condition, string message) { if (!condition) throw new Exception(message); }
