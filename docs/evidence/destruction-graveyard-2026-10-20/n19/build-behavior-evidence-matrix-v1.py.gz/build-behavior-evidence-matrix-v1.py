import hashlib
import json
import pathlib
import xml.etree.ElementTree as ET

root = pathlib.Path.cwd()
work = pathlib.Path(__file__).resolve().parent
ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
observations = []
for folder in ['focus-v21-controlled-all', 'focus-v22-ordinary-and-originals']:
    path = next((work / folder).rglob('*.trx')); tree = ET.parse(path)
    definitions = {x.get('id'): x.find('t:TestMethod', ns) for x in tree.findall('.//t:UnitTest', ns)}
    plan = json.loads((work / folder / 'plan.json').read_text())
    for result in tree.findall('.//t:UnitTestResult', ns):
        method = definitions[result.get('testId')]
        assert result.get('outcome') == 'Passed'
        full = method.get('className').split(',')[0] + '.' + method.get('name')
        observations.append({'key': hashlib.sha256((full + '\n' + result.get('testName')).encode()).hexdigest(),
            'method': method.get('name'), 'fullyQualifiedMethod': full, 'actualCaseName': result.get('testName'),
            'actualOutcome': result.get('outcome'), 'testId': result.get('testId'),
            'originalTrx': str(path.relative_to(root)), 'originalTrxSha256': sha(path),
            'actualTestAssemblySha256': plan['testAssemblySha256']})
assert len(observations) == 77 and len({row['key'] for row in observations}) == 77
groups = {
    'ACTUAL_SPELL_DESTRUCTION_SOURCE_RESPONSIBILITY': [
        'ActualLethalSpellAndSelfDestructionOfferLeadingCostThenPlayOriginalPhoenix',
        'DecreeDamageQueuesIndependentDestroyBeforePhoenixWithOriginalSpellSource',
        'OpponentsDamageTriggersOriginalDecreeControllerAndOnlyThatPlayersPhoenix'],
    'UNIT_COMBAT_AND_NAMED_DUEL_DAMAGE_NOT_SPELL': [
        'ActualCombatUnitDamageDoesNotBecomeSpellDestructionForGraveyardPhoenix',
        'ActualNamedUnitDuelDamageRetainsUnitResponsibilityAndCannotTriggerPhoenix',
        'OpponentsActualLethalSpellDoesNotOfferYourGraveyardPhoenix'],
    'PHOENIX_SELF_AND_SIMULTANEOUS_GRAVEYARD_OBSERVERS': [
        'ActualLethalSpellAndSelfDestructionOfferLeadingCostThenPlayOriginalPhoenix',
        'ActualSimultaneousGraveyardEntrantsObserveOwnAndOtherSpellDestructions'],
    'PHOENIX_LEADING_ONE_MANA_ONE_RED_PAY_OR_DECLINE': [
        'LeadingPaymentCannotBeForgedToWaiveManaRedPowerOrConfirmation',
        'InsufficientRedAndWrongOrStaleChoiceCannotMutateOriginalPendingPayment',
        'ActualLethalSpellAndSelfDestructionOfferLeadingCostThenPlayOriginalPhoenix',
        'OriginalBlankLegalDecksExerciseSelfDestructionAndIndependentDecreeThenPaidOrDeclinedPhoenix'],
    'PHOENIX_CAPTURED_GRAVEYARD_GENERATION_SHARED_PLAY': [
        'PhoenixContextRejectsForgedAttributionVictimSourceAndRole',
        'ActualLethalSpellAndSelfDestructionOfferLeadingCostThenPlayOriginalPhoenix',
        'OriginalBlankLegalDecksExerciseSelfDestructionAndIndependentDecreeThenPaidOrDeclinedPhoenix'],
    'DECREE_INDEPENDENT_DELAYED_DAMAGE_DESTRUCTION': [
        'DecreeDamageQueuesIndependentDestroyBeforePhoenixWithOriginalSpellSource',
        'GlobalDecreeIncludesARealUnitPlayedAfterTheSpellResolved',
        'TwoDecreesRetainBothOriginalSpellInstancesAndOnlyFirstAbilityCanDestroy',
        'ActualDamagePreventionProducesNoDelayedTriggerAndNextRealDamageStillDoes',
        'ReturningDamagedTargetDuringActualResponseMakesEarnedDecreeAbilityNoop',
        'BothInstructionsExpireAtTheActualEndOfTurn',
        'OpponentsDamageTriggersOriginalDecreeControllerAndOnlyThatPlayersPhoenix',
        'CoreRuleEnginePlaysImperialDecreeAndDamageDestroysUnit'],
    'GUILLOTINE_ORIGINAL_INSPIRE_OR_NEXT_DAMAGE': [
        'GuillotineCapturesInspireAtConfirmationOrNextDamageCreatesIndependentAbility',
        'GuillotineConfirmedWithoutInspireCannotUpgradeOrTriggerRetroactivelyAfterAResponseSpell',
        'ReturnedAndActuallyReplayedUnitCannotReuseGuillotinesOldTargetInTheSameTurn',
        'BothInstructionsExpireAtTheActualEndOfTurn',
        'CoreRuleEnginePlaysNoxianGuillotineAndNextDamageDestroysUnit'],
    'DESTRUCTION_CONTEXT_STATE_PRIVATE_SPECTATOR_AND_JOURNAL': [
        'DelayedStackRejectsForgedSourceRolePrintingTimeTargetAndMissingContext',
        'PhoenixContextRejectsForgedAttributionVictimSourceAndRole',
        'PrivateProjectionCannotDropForgeOrExtendCapturedDelayedInstruction',
        'LeadingPaymentCannotBeForgedToWaiveManaRedPowerOrConfirmation',
        'DelayedInstructionMarkerRejectsDuplicatesUnknownSchemaAndForgedGlobalTarget',
        'InsufficientRedAndWrongOrStaleChoiceCannotMutateOriginalPendingPayment',
        'CoordinatedEarlierDelayedCreationTickPassesShapeButOriginalJournalRejectsIt'],
    'DESTRUCTION_ORIGINAL_ORDINARY_SQL_COLD_NEXT_AND_REPLAY': [
        'OriginalBlankLegalDecksExerciseSelfDestructionAndIndependentDecreeThenPaidOrDeclinedPhoenix']}
clauses = {
    'ACTUAL_SPELL_DESTRUCTION_SOURCE_RESPONSIBILITY': ['412.5', '429.5.b-d', 'DOC06-P021-B002..004'],
    'UNIT_COMBAT_AND_NAMED_DUEL_DAMAGE_NOT_SPELL': ['418.6.b.3-4', '429.5.c.2'],
    'PHOENIX_SELF_AND_SIMULTANEOUS_GRAVEYARD_OBSERVERS': ['383.2.c.1'],
    'PHOENIX_LEADING_ONE_MANA_ONE_RED_PAY_OR_DECLINE': ['204.1.c'],
    'PHOENIX_CAPTURED_GRAVEYARD_GENERATION_SHARED_PLAY': ['OGN·037/298 exact printed graveyard instruction'],
    'DECREE_INDEPENDENT_DELAYED_DAMAGE_DESTRUCTION': ['391.2', 'DOC06-P021-B002..004'],
    'GUILLOTINE_ORIGINAL_INSPIRE_OR_NEXT_DAMAGE': ['391.2', 'OGN·254/298 exact printed Inspire instruction']}
rows = []
for branch, methods in groups.items():
    selected = [row for row in observations if row['method'] in methods]
    assert set(methods) == {row['method'] for row in selected}
    rows.append({'id': branch, 'preciseReviewedClausesOrPrinting': clauses.get(branch, ['All exact typed source/version and original history obligations linked in source manifest']),
        'actualCaseKeys': [row['key'] for row in selected], 'actualCaseCount': len(selected), 'actualMethodNames': methods,
        'semanticReview': 'LIMITED_CURRENT_CN_SOURCE_REVIEW', 'testExecution': 'ONLY_LISTED_ORIGINAL_TRX_CASES_PASS',
        'fixedCommitCi': 'PENDING', 'productAcceptance': 'OPEN', 'wholePrintingCertified': False,
        'additionalOpenExecution': ['Legitimate Phoenix graveyard source departure/return through current commands, other extra-cost consumers and copy/control-transfer/replacement branches are not certified by source-forgery negatives.']
            if branch == 'PHOENIX_CAPTURED_GRAVEYARD_GENERATION_SHARED_PLAY' else []})
result = {'status': 'BOUNDED_BRANCH_TO_ACTUAL_TEST_IDENTITY_MATRIX_NOT_WHOLE_CARD_CERTIFICATION',
    'region': 'CN', 'language': 'zh-CN', 'applicableRulesBaseline': '2026-10-16',
    'actualObservations': observations, 'actualUniqueCases': 77, 'actualUniqueMethods': 28,
    'branches': rows, 'countsAcrossBranchesMustNotBeSummed': True,
    'adjacentOriginalFullGameCases': [row['key'] for row in observations if '.FullGameEndToEndTests.' in row['fullyQualifiedMethod']],
    'sql': 'Real six-branch writer and independent read-only receipt are separately required; not inferred from these TRX cases.',
    'fixedFullAndVisibleProductAndPhysicalWindows': 'OPEN'}
assert len(result['adjacentOriginalFullGameCases']) == 2
path = work / 'bounded-behavior-evidence-matrix-v1.json'; assert not path.exists()
path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print('Nine bounded branches linked to77 actual cases28 methods; exact open branches retained.')
