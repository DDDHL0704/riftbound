import datetime
import hashlib
import json
import pathlib
import subprocess
import time
import xml.etree.ElementTree as ET

work = pathlib.Path(__file__).resolve().parent; root = work.parents[2]
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
output = work / 'postcheck-catalog-boundary-closure-v1.json'
assert not output.exists()
deadline = time.monotonic() + 7200
terminal_path = work / 'only-check-terminal-integrity-v1.json'
while not terminal_path.exists():
    assert time.monotonic() < deadline, 'No source mutation without the actual sole-check terminal receipt.'
    time.sleep(3)
terminal = json.loads(terminal_path.read_text())
assert terminal['allDeclaredInputsAndRuntimeFilesStable'] and terminal['boundIdleSleepAssertionEnded']
subprocess.run(['python3', str(work / 'verify-only-check-v1.py')], cwd=root, check=True)
check_path = work / 'only-check-retention-and-disposition-v1.json'
check = json.loads(check_path.read_text())
name = 'Riftbound.ConformanceTests.CardCatalogBaselineTests.P6LifecycleTriggerReplacementFamiliesReportSpecAndExecutionBoundaryCoverage'
assert check['failed'] == 1 and check['skipped'] == 0 and check['all73NewDestructionCasesPassed']
assert {r['name'] for r in check['failures']} == {name}
inventory_path = work / 'catalog-boundary-independent-old-current-comparison-v1.json'
inventory = json.loads(inventory_path.read_text())
assert inventory['before'] == {'entries': 551, 'implementedEntries': 551, 'manualEntries': 0,
    'unimplementedEntries': 0, 'functionalUnits': 441, 'implementedFunctionalUnits': 441}
assert inventory['after'] == {'entries': 552, 'implementedEntries': 552, 'manualEntries': 0,
    'unimplementedEntries': 0, 'functionalUnits': 442, 'implementedFunctionalUnits': 442}
assert set(inventory['newTriggerPrintingRows']) == {'OGN·254/298'} and not inventory['removedOldTriggerPrintingRows']
assert set(inventory['changedOldTriggerPrintingRows']) == {'OGN·037/298', 'OGN·221/298'}
assert inventory['allActualOriginalModuleHashesStable']
source = root / 'tests/Riftbound.ConformanceTests/CardCatalogBaselineTests.cs'
before = source.read_text()
assert before == subprocess.check_output(['git', 'show', 'HEAD:tests/Riftbound.ConformanceTests/CardCatalogBaselineTests.cs'], cwd=root, text=True)
old = '''            TimingSurfaceNames.Trigger,
            entries: 551,
            specImplementedEntries: 551,
            manualRuleRequiredEntries: 0,
            unimplementedEntries: 0,
            functionalUnits: 441,
            specImplementedFunctionalUnits: 441,
            pendingFunctionalUnits: 0);'''
new = old.replace('551', '552').replace('441', '442')
assert before.count(old) == 1
runtime = root / 'tests/Riftbound.ConformanceTests/bin/Debug/net10.0'
production = {p.name: sha(p) for p in runtime.glob('*.dll') if p.name != 'Riftbound.ConformanceTests.dll'}
source.write_text(before.replace(old, new, 1))
record = {'status': 'CATALOG_LITERAL_CORRECTION_AWAITING_FOCUS', 'startedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'originalCheckReceiptSha256': sha(check_path), 'actualFrozenInventorySha256': sha(inventory_path),
    'changedSource': str(source.relative_to(root)), 'previousSourceSha256': hashlib.sha256(before.encode()).hexdigest(), 'currentSourceSha256': sha(source),
    'exactPreviousSnippet': old, 'exactCurrentSnippet': new, 'allOriginalAssertionsRetained': True,
    'closedOriginalFailureNames': [name], 'sourceCorrectedOnlyAfterSoleCheckEnded': True,
    'sourceCountChangeExactPrinting': 'OGN·254/298', 'sourceCountChangeExactFunctionalUnit': 'FU-842e15ada7',
    'registryCountsNotSemanticCertification': True, 'productionModuleHashesBefore': production,
    'noSecondCheck': True, 'originalFailedCheckNotRelabeledGreen': True}
output.write_text(json.dumps(record, indent=2) + '\n')
with (work / 'focus-v25-postcheck-catalog-and-finite-family-runner.log').open('x') as log:
    result = subprocess.run(['python3', str(root / 'scripts/test-rules.py'), 'focus', '--match', 'P6LifecycleTriggerReplacementFamiliesReportSpecAndExecutionBoundaryCoverage',
        '--match', 'DestructionGraveyardFamilyTests', '--output', str(work / 'focus-v25-postcheck-catalog-and-finite-family')], cwd=root, stdout=log, stderr=subprocess.STDOUT)
after = {p.name: sha(p) for p in runtime.glob('*.dll') if p.name != 'Riftbound.ConformanceTests.dll'}
record.update(status='PASS_ORIGINAL_CATALOG_BOUNDARY_AFTER_EXPECTED_COUNTS_ONLY' if result.returncode == 0 else 'FOCUSED_CATALOG_CLOSURE_FAILED',
    focusedExitCode=result.returncode, productionModuleHashesAfter=after, productionModulesByteExact=after == production,
    finishedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(), currentTestAssemblySha256=sha(runtime / 'Riftbound.ConformanceTests.dll'))
output.write_text(json.dumps(record, indent=2) + '\n')
assert result.returncode == 0 and after == production
ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
trx_path = next((work / 'focus-v25-postcheck-catalog-and-finite-family').rglob('*.trx'))
trx = ET.parse(trx_path); rows = trx.findall('.//t:UnitTestResult', ns)
assert len(rows) == 9 and all(row.get('outcome') == 'Passed' for row in rows)
record.update(actualFocusedCases=9, actualFocusedMethods=5, actualFocusedTrxSha256=sha(trx_path))
output.write_text(json.dumps(record, indent=2) + '\n')
prior_path = work / 'all-original-test-and-theory-source-retention-v2.json'
retention = json.loads(prior_path.read_text())
retention.update(status='FINAL_ORIGINAL_TEST_THEORY_IDENTITIES_RETAINED_WITH_TWO_EXPLICIT_TEST_EXPECTATION_CORRECTIONS',
    previousRetentionV2Sha256=sha(prior_path), changedOriginalCsFiles=sorted(retention['changedOriginalCsFiles'] + [str(source.relative_to(root))]),
    onlyAdditionalSourceChangeAfterV2={'path': str(source.relative_to(root)), 'exactPreviousSnippet': old, 'exactCurrentSnippet': new,
        'allOtherBytesAgainstOriginalHeadExact': source.read_text() == before.replace(old, new, 1),
        'sha256': sha(source), 'allOriginalAssertionsRetained': True},
    focusedPostCheckClosureSha256=sha(output), productionModulesNotChangedAfterOriginalCheck=True,
    oldSoleCheckOriginalFailureRetained=True, noSecondCheck=True)
final_path = work / 'all-original-test-and-theory-source-retention-v3.json'; assert not final_path.exists()
final_path.write_text(json.dumps(retention, indent=2) + '\n')
print('ORIGINAL_CATALOG_FAILURE_CLOSED_WITH9_FOCUS_CASES_PRODUCTION_MODULES_EXACT_NO_SECOND_CHECK', flush=True)
