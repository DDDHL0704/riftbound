using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.Text.Json;
using Riftbound.CardCatalog;
using Riftbound.Contracts;
using Riftbound.Engine;

var folder = Path.GetFullPath(args.Single());
AssemblyLoadContext.Default.Resolving += (context, name) => File.Exists(Path.Combine(folder, name.Name + ".dll"))
    ? context.LoadFromAssemblyPath(Path.Combine(folder, name.Name + ".dll")) : null;
await Read(folder);

[MethodImpl(MethodImplOptions.NoInlining)]
static async Task Read(string folder)
{
    var assemblies = new[] { typeof(CoreRuleEngine).Assembly, typeof(OfficialCardCatalog).Assembly, typeof(GameCommand).Assembly };
    if (assemblies.Any(a => Path.GetDirectoryName(a.Location) != folder)) throw new Exception("Every actual runtime module must come from the explicitly selected frozen directory.");
    var catalog = await OfficialCardCatalog.LoadDefaultAsync();
    var units = FunctionalUnitBuilder.Build(catalog.Cards);
    var played = CardBehaviorRegistry.GetAll().Select(definition => new ImplementedCardBehavior(
        definition.CardNo, definition.EffectKind, definition.DisplayName, CardBehaviorRegistry.TriggerEffectKinds(definition))).ToArray();
    var specs = BehaviorSpecCatalogBuilder.Build(catalog.Cards, units, OfficialRuleDomainBehaviorCatalog.MergeWithNonPlayCardDomains(catalog.Cards, played));
    var rows = specs.Where(s => s.Triggers.Count > 0).OrderBy(s => s.CardNo, StringComparer.Ordinal).ToArray();
    var groups = rows.GroupBy(s => s.FunctionalUnitId).ToArray();
    var currentKinds = new[] { "UNIT_SPELL_DESTROY_PLAY_FROM_GRAVEYARD", "SPELL_TURN_UNIT_DAMAGED_DESTROY", "SPELL_NEXT_DAMAGE_OR_INSPIRED_DESTROY" };
    Console.WriteLine(JsonSerializer.Serialize(new { status = "ACTUAL_FROZEN_REGISTRY_STATISTICS_NOT_SEMANTIC_CERTIFICATION",
        actualRuleInputs = RuleInputIdentity.Current,
        actualAssemblies = assemblies.Select(a => new { path = a.Location, sha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(a.Location))).ToLowerInvariant(), mvid = a.ManifestModule.ModuleVersionId }),
        entries = rows.Length, implementedEntries = rows.Count(s => s.Status == BehaviorImplementationStatuses.Implemented),
        manualEntries = rows.Count(s => s.Status == BehaviorImplementationStatuses.ManualRuleRequired),
        unimplementedEntries = rows.Count(s => s.Status == BehaviorImplementationStatuses.Unimplemented),
        functionalUnits = groups.Length, implementedFunctionalUnits = groups.Count(g => g.Any(s => s.Status == BehaviorImplementationStatuses.Implemented)),
        triggerRows = rows.Select(s => new { s.CardNo, s.FunctionalUnitId, s.Status, triggerKinds = s.Triggers.Select(t => t.Kind) }),
        currentFiniteFamilyConsumers = specs.Where(s => s.Triggers.Any(t => currentKinds.Contains(t.Kind))).Select(s => new { s.CardNo, s.FunctionalUnitId, triggerKinds = s.Triggers.Select(t => t.Kind) })
    }, new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true }));
}
