using System.Reflection;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.Text.Json;

var folder = Path.GetFullPath(args.Single());
AssemblyLoadContext.Default.Resolving += (context, name) => File.Exists(Path.Combine(folder, name.Name + ".dll"))
    ? context.LoadFromAssemblyPath(Path.Combine(folder, name.Name + ".dll")) : null;
var engine = AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.Combine(folder, "Riftbound.Engine.dll"));
var type = engine.GetType("Riftbound.Engine.RuleInputIdentity", throwOnError: true)!;
var identity = type.GetProperty("Current", BindingFlags.Public | BindingFlags.Static)!.GetValue(null)!;
var modules = AppDomain.CurrentDomain.GetAssemblies().Where(a =>
    new[] { "Riftbound.Contracts", "Riftbound.CardCatalog", "Riftbound.Engine" }.Contains(a.GetName().Name)).OrderBy(a => a.GetName().Name).ToArray();
if (modules.Length != 3 || modules.Any(a => Path.GetDirectoryName(a.Location) != folder)) throw new Exception("All three actual executing input modules must come from the selected directory.");
Console.WriteLine(JsonSerializer.Serialize(new {
    status = "ACTUAL_LOADED_RULE_INPUT_IDENTITY_NOT_SEMANTIC_CERTIFICATION",
    runtimeDirectory = folder, actualRuleInputs = JsonSerializer.SerializeToElement(identity, identity.GetType(), new JsonSerializerOptions(JsonSerializerDefaults.Web)),
    modules = modules.Select(a => new { file = Path.GetFileName(a.Location), sha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(a.Location))).ToLowerInvariant(),
        mvid = a.ManifestModule.ModuleVersionId }),
    probeSha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(Assembly.GetExecutingAssembly().Location))).ToLowerInvariant()
}, new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true }));
