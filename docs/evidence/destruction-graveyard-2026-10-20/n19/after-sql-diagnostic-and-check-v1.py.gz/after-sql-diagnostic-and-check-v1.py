import datetime
import hashlib
import json
import pathlib
import subprocess
import time

work = pathlib.Path(__file__).resolve().parent
root = work.parents[2]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
record_path = work / 'precheck-existing-diagnostic-closure-v1.json'
assert not record_path.exists() and not (work / 'only-check').exists()
deadline = time.monotonic() + 7200
while True:
    sql = json.loads((work / 'real-sql-verification-v1.json').read_text())
    if sql['status'] != 'RUNNING_NOT_ACCEPTANCE':
        break
    assert time.monotonic() < deadline, 'No dependent source mutation before an actual SQL terminal receipt.'
    time.sleep(3)
assert sql['status'] == 'PASS_REAL_SQL_SIX_ORIGINALS_PARTITION_DISPATCH_AND_INDEPENDENT_READONLY_FULL_REPLAY'
assert sql['ownPostgresSmartStopped'] and sql['allFrozenRuntimeAndHarnessInputsStillExact']
path = root / 'tests/Riftbound.ConformanceTests/MatchRecoveryTests.cs'
before = path.read_text()
assert before == subprocess.check_output(['git', 'show', 'HEAD:tests/Riftbound.ConformanceTests/MatchRecoveryTests.cs'], cwd=root, text=True)
old = '"[CARD_DISCARDED, CARDS_RECYCLED,'
new = '"[DAMAGE_APPLIED, CARD_DISCARDED, CARDS_RECYCLED,'
assert before.count(old) == 1
runtime = root / 'tests/Riftbound.ConformanceTests/bin/Debug/net10.0'
production = {p.name: sha(p) for p in runtime.glob('*.dll') if p.name != 'Riftbound.ConformanceTests.dll'}
path.write_text(before.replace(old, new, 1))
record = {'status': 'TEST_LITERAL_CORRECTION_AWAITING_FOCUSED_EXECUTION', 'recordedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'previousSourceSha256': hashlib.sha256(before.encode()).hexdigest(), 'currentSourceSha256': sha(path),
          'previousDiagnosticPrefix': old, 'currentDiagnosticPrefix': new,
          'allOriginalAssertionsAndForgedEventRejectionsRetained': True,
          'sqlFinishedBeforeThisTestOnlyMutation': True, 'realSqlTerminalReceiptSha256': sha(work / 'real-sql-verification-v1.json'),
          'frozenSqlRuntimeNotMutated': True, 'soleCheckNotRunYet': True, 'productionModuleHashesBefore': production}
record_path.write_text(json.dumps(record, indent=2) + '\n')
names = [
    'RecoveryValidatorRejectsSnapshotTimingTriggerQueueTriggeredEventKindDrift',
    'RecoveryValidatorRejectsAuthoritativeStateTriggerQueueTriggeredEventKindDrift',
    'RecoveryValidatorRejectsSpectatorReplayTimingTriggerQueueKeyedKnownValueCanonicalityWithCountMismatch',
    'RecoveryValidatorRejectsSpectatorReplayTimingTriggerQueueKeyedVisibleSourceTriggeredEventKindInvalidValueWithoutCountMismatch']
arguments = ['python3', str(root / 'scripts/test-rules.py'), 'focus']
for name in names:
    arguments += ['--match', name]
arguments += ['--output', str(work / 'focus-v24-existing-diagnostic-closure')]
with (work / 'focus-v24-existing-diagnostic-closure-runner.log').open('x') as log:
    code = subprocess.run(arguments, cwd=root, stdout=log, stderr=subprocess.STDOUT).returncode
after = {p.name: sha(p) for p in runtime.glob('*.dll') if p.name != 'Riftbound.ConformanceTests.dll'}
record.update(status='FOUR_ORIGINAL_FORGED_EVENT_NEGATIVES_PASS_AFTER_INDEPENDENT_LITERAL_CORRECTION' if code == 0 else 'FOCUSED_CLOSURE_FAILED',
              focusedExitCode=code, productionModuleHashesAfter=after, productionModulesByteExact=after == production,
              finishedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat())
record_path.write_text(json.dumps(record, indent=2) + '\n')
assert code == 0 and after == production
print(record['status'], flush=True)
subprocess.run(['python3', str(work / 'run-only-check-v1.py')], cwd=root, check=True)
