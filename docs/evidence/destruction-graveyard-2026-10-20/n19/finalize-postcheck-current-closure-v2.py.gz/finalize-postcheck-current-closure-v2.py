import copy
import hashlib
import json
import pathlib
import subprocess
import xml.etree.ElementTree as ET

root = pathlib.Path.cwd(); work = pathlib.Path(__file__).resolve().parent
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
load = lambda path: json.loads(path.read_text())
focus = load(work / 'postcheck-current-focus-v27-integrity.json')
sql = load(work / 'real-sql-verification-v2.json')
check = load(work / 'only-check-retention-and-disposition-v1.json')
assert focus['status'] == 'PASS_CURRENT_POSTCHECK_FOCUS' and focus['actualCases'] == 78 and focus['actualMethods'] == 34
assert not focus['changedSourceInputs'] and not focus['changedRuntimeFiles']
assert sql['status'] == 'PASS_REAL_SQL_SIX_ORIGINALS_PARTITION_DISPATCH_AND_INDEPENDENT_READONLY_FULL_REPLAY'
assert sql['ownPostgresSmartStopped'] and sql['allFrozenRuntimeAndHarnessInputsStillExact']
assert sql['all178PriorAuditAnd35NativeRoomsSevenTablesExact'] and sql['independentAll184AuditAnd35NativeRoomsSevenTablesUnchanged']
assert check['failed'] == 3 and check['skipped'] == 0 and check['all73NewDestructionCasesPassed']
repairs = load(work / 'postcheck-source-repairs-v2.json')
assert set(repairs['originalFailedNames']) == {row['name'] for row in check['failures']}
assert all(sha(root / row['path']) == row['afterSha256'] for row in repairs['sourceChanges'])
ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
folder = work / 'focus-v27-postcheck-current-family-and-originals'; trx_path = next(folder.rglob('*.trx'))
tree = ET.parse(trx_path); definitions = {row.get('id'): row.find('t:TestMethod', ns) for row in tree.findall('.//t:UnitTest', ns)}
cases = tree.findall('.//t:UnitTestResult', ns)
assert len(cases) == 78 and all(row.get('outcome') == 'Passed' for row in cases)
methods = {m.get('className').split(',')[0] + '.' + m.get('name') for m in definitions.values()}
assert len(methods) == 34 and set(repairs['originalFailedNames']) <= methods
observations = []
plan = load(folder / 'plan.json')
for row in cases:
    m = definitions[row.get('testId')]; full = m.get('className').split(',')[0] + '.' + m.get('name')
    observations.append({'key': hashlib.sha256((full + '\n' + row.get('testName')).encode()).hexdigest(),
        'method': m.get('name'), 'fullyQualifiedMethod': full, 'actualCaseName': row.get('testName'),
        'actualOutcome': row.get('outcome'), 'testId': row.get('testId'), 'originalTrx': str(trx_path.relative_to(root)),
        'originalTrxSha256': sha(trx_path), 'actualTestAssemblySha256': plan['testAssemblySha256']})
previous_matrix = load(work / 'bounded-behavior-evidence-matrix-v1.json')
matrix = {key: copy.deepcopy(value) for key, value in previous_matrix.items() if key not in ['actualObservations', 'branches', 'adjacentOriginalFullGameCases']}
matrix.update(status='CURRENT_POSTCHECK_BRANCH_CASE_AND_REAL_SQL_IDENTITY_MATRIX_NOT_WHOLE_CARD_CERTIFICATION',
    actualObservations=observations, actualUniqueCases=78, actualUniqueMethods=34,
    currentDebugRuleInputs=focus['actualConformanceDebugIdentity']['actualRuleInputs'],
    currentReleaseSqlRuleInputs=sql['actualRuleInputs'], earlierPreRepairMatrixSha256=sha(work / 'bounded-behavior-evidence-matrix-v1.json'),
    adjacentOriginalFullGameCases=[row['key'] for row in observations if '.FullGameEndToEndTests.' in row['fullyQualifiedMethod']], branches=[])
sql_checks = load(work / 'independent-actual-sql-reader-result-v2.json')['checks']
assert len(sql_checks) == 6
for old in previous_matrix['branches']:
    branch = copy.deepcopy(old)
    selected = [row for row in observations if row['method'] in old['actualMethodNames']]
    branch.update(actualCaseKeys=[row['key'] for row in selected], actualCaseCount=len(selected),
        actualMethodNames=sorted({row['method'] for row in selected}), testExecution='CURRENT_LISTED_TRX_CASES_AND_SEPARATE_REAL_SQL_ONLY')
    if branch['id'] == 'DESTRUCTION_ORIGINAL_ORDINARY_SQL_COLD_NEXT_AND_REPLAY':
        branch['actualSqlCases'] = sql_checks
        branch['actualSqlReceipt'] = {'path': str((work / 'real-sql-verification-v2.json').relative_to(root)), 'sha256': sha(work / 'real-sql-verification-v2.json')}
        branch['currentOrdinaryTrxNotRerunAfterNullGuard'] = True
        branch['currentOrdinaryEvidenceInsteadIsSixFreshRealSqlOriginalsFullReplay'] = True
    if branch['id'] == 'GUILLOTINE_ORIGINAL_INSPIRE_OR_NEXT_DAMAGE':
        branch['additionalOpenExecution'].append('Guillotine controlled branches are not a new ordinary legal blank-opening or visible client certification.')
    matrix['branches'].append(branch)
matrix_path = work / 'bounded-behavior-evidence-matrix-v2.json'; assert not matrix_path.exists()
matrix_path.write_text(json.dumps(matrix, ensure_ascii=False, indent=2) + '\n')
output = work / 'postcheck-three-failures-current-closure-v2.json'; assert not output.exists()
proof = {'status': 'PASS_THREE_ORIGINAL_FAILURES_CURRENT_FOCUS78_SQL6_TWO_ORIGINAL_FULL_GAMES_NO_SECOND_CHECK',
    'originalSoleCheck': {'cases': check['cases'], 'methods': check['methods'], 'passed': check['passed'], 'failed': 3,
        'rawTrxSha256': check['rawTrxSha256'], 'originalFailedCheckNotRelabeledGreen': True},
    'closedOriginalFailureNames': sorted(repairs['originalFailedNames']), 'actualCurrentFocusedCases': 78, 'actualCurrentFocusedMethods': 34,
    'actualCurrentFocusedTrxSha256': sha(trx_path), 'sourceChanges': repairs['sourceChanges'],
    'productionNullGuardChangedRuntimeIdentity': True,
    'currentConformanceDebugRuleInputs': focus['actualConformanceDebugIdentity']['actualRuleInputs'],
    'currentConformanceDebugModules': focus['actualConformanceDebugIdentity']['modules'],
    'currentFrozenReleaseSqlRuleInputs': sql['actualRuleInputs'],
    'currentFrozenReleaseSqlReceiptSha256': sha(work / 'real-sql-verification-v2.json'),
    'earlierPreRepairReleaseSqlRuleInputs': load(work / 'real-sql-verification-v1.json')['actualRuleInputs'],
    'earlierPreRepairResultsRetainedUnderTheirOriginalVersionOnly': True,
    'currentActualSixSqlCommands': sql['commands'], 'currentActualSixSqlEvents': sql['events'],
    'currentSixSqlFullOriginalReplayAndAllFieldsAndPrivateViewsExact': True,
    'allOriginalNegativeAssertionsAndWinReplayAssertionsRetained': True,
    'allInputsStableDuringEachCurrentRun': True, 'onlyOneCheck': True, 'noSecondCheck': True,
    'newFixedFull': 'PENDING', 'visibleCurrentNativeAndPhysicalWindows': 'OPEN', 'wholePrintingCertified': False}
output.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
prior_path = work / 'all-original-test-and-theory-source-retention-v2.json'; retention = load(prior_path)
catalog_path = 'tests/Riftbound.ConformanceTests/CardCatalogBaselineTests.cs'
before = subprocess.check_output(['git', 'show', 'HEAD:' + catalog_path], text=True)
current = (root / catalog_path).read_text()
start = before.index('    public async Task P6LifecycleTriggerReplacementFamiliesReportSpecAndExecutionBoundaryCoverage()')
end = before.index('\n    [', start)
section = before[start:end]; corrected = section.replace('entries: 551,', 'entries: 552,').replace('specImplementedEntries: 551,', 'specImplementedEntries: 552,').replace('functionalUnits: 441,', 'functionalUnits: 442,').replace('specImplementedFunctionalUnits: 441,', 'specImplementedFunctionalUnits: 442,')
assert current == before[:start] + corrected + before[end:]
retention.update(status='FINAL_ORIGINAL_TEST_THEORY_IDENTITIES_RETAINED_AFTER_THREE_BOUNDED_REPAIRS',
    previousRetentionV2Sha256=sha(prior_path), changedOriginalCsFiles=sorted(retention['changedOriginalCsFiles'] + [catalog_path]),
    onlyAdditionalOriginalTestSourceChangeAfterV2={'path': catalog_path, 'fourExpectedCounterConstantsOnly': True, 'allOtherOriginalBytesExact': True, 'sha256': sha(root / catalog_path)},
    allOriginalIndependentNegativeAssertionsRetained=True, oldPrivacyNegativeTestNotModified=True,
    currentFocusedAndSqlClosureSha256=sha(output), currentProductionChangeExplicitlyRevalidatedInsteadOfReusingOldModuleEvidence=True,
    onlyOneCheck=True, noSecondCheck=True)
retention_path = work / 'all-original-test-and-theory-source-retention-v3.json'; assert not retention_path.exists()
retention_path.write_text(json.dumps(retention, indent=2) + '\n')
print('THREE_FAILURES_CLOSED_CURRENT_FOCUS78_SQL6_TWO_ORIGINAL_FULL_GAMES_SOURCE_RETENTION_VERIFIED', flush=True)
