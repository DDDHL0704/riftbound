import concurrent.futures
import datetime
import gzip
import hashlib
import json
import pathlib
import urllib.request

root = pathlib.Path.cwd()
work = pathlib.Path(__file__).resolve().parent
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
sha = lambda value: hashlib.sha256(value).hexdigest()
endpoint = 'https://content.publishing.riotgames.com/publishing-content/v2.0/public/channel/riftbound_website/list/riftbound_gallery_cards'
views = [
    ('whole-en-us', endpoint + '?locale=en_US&limit=2000&from=0', 'en-US'),
    ('whole-api-default-locale', endpoint + '?limit=2000&from=0', 'UNSPECIFIED_REQUEST_USE_RESPONSE_METADATA'),
    ('official-gallery-ssr', 'https://playriftbound.com/en-us/card-gallery/', 'en-US')]
output = work / 'current-source-views-v1.json'
assert not output.exists()
baseline_path = root / 'docs/evidence/source-reconfirmation-2026-10-17/gallery-api-full.json'
baseline = json.loads(baseline_path.read_text()); previous = {row['id']: row for row in baseline['data']}

def acquire(item):
    name, url, language = item
    record = {'view': name, 'url': url, 'requestedLanguage': language, 'region': 'GLOBAL', 'startedAtUtc': now(),
              'publicationDate': None, 'effectiveDate': None, 'sourceAnalysisOnly': True}
    try:
        request = urllib.request.Request(url, headers={'User-Agent': 'RiftboundOfficialAudit/1.0', 'Cache-Control': 'no-cache'})
        with urllib.request.urlopen(request, timeout=45) as response:
            raw = response.read(8 * 1024 * 1024 + 1)
            assert len(raw) <= 8 * 1024 * 1024
            record.update(httpStatus=response.status, resolvedUrl=response.url,
                          responseHeaders={k: response.headers.get(k) for k in ['Date', 'Age', 'Cache-Control', 'ETag', 'Last-Modified', 'Content-Type']})
        path = work / (name + '-original-v1.' + ('html' if name.endswith('ssr') else 'json') + '.gz')
        assert not path.exists(); path.write_bytes(gzip.compress(raw, mtime=0))
        record.update(status='ACQUIRED_NOT_SEMANTIC_CERTIFICATION', receivedAtUtc=now(), rawBytes=len(raw), rawSha256=sha(raw),
                      storedPath=str(path.relative_to(root)), storedSha256=sha(path.read_bytes()))
        if not name.endswith('ssr'):
            body = json.loads(raw); rows = body['data']; current = {row['id']: row for row in rows}
            record.update(metadata=body['metadata'], returnedRows=len(rows), distinctIds=len(current),
                          exactUnchangedBaselineRows=sum(current.get(k) == v for k, v in previous.items()),
                          addedIds=sorted(current.keys() - previous.keys()), missingPriorIds=sorted(previous.keys() - current.keys()),
                          changedPriorIds=sorted(k for k in current.keys() & previous.keys() if current[k] != previous[k]),
                          duplicateIds=sorted({row['id'] for row in rows if sum(r['id'] == row['id'] for r in rows) > 1}))
    except Exception as error:
        record.update(status='SOURCE_VIEW_FAILED_PREFIX_RETAINED', errorType=type(error).__name__, errorMessage=str(error), finishedAtUtc=now())
    return record

with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    records = list(pool.map(acquire, views))
proof = {'status': 'FRESH_OFFICIAL_SOURCE_VIEWS_ONLY_CURRENT_RUNTIME_INPUTS_NOT_CHANGED', 'recordedAtUtc': now(),
         'baselinePath': str(baseline_path.relative_to(root)), 'baselineSha256': sha(baseline_path.read_bytes()),
         'records': records, 'currentCheckSourcesAndCatalogNotMutated': True,
         'defaultLocaleNotAssumedToHaveEnglishOrRegionApplicability': True,
         'reportedEightGapNotEquatedWithEightArticlePrintingCandidates': True,
         'sourceChangesRequireSeparateVersionImpactDisposition': True, 'semanticCoverageCertified': False}
output.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
for row in records:
    print({key: row.get(key) for key in ['view', 'status', 'returnedRows', 'distinctIds', 'addedIds', 'missingPriorIds', 'changedPriorIds']})
