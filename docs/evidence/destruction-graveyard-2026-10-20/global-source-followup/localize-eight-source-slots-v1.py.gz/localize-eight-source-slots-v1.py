import collections
import concurrent.futures
import datetime
import gzip
import hashlib
import json
import pathlib
import urllib.request

root = pathlib.Path.cwd(); work = pathlib.Path(__file__).resolve().parent
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
sha = lambda value: hashlib.sha256(value).hexdigest()
whole = json.loads(gzip.decompress((work / 'whole-en-us-original-v1.json.gz').read_bytes()))
expected_total = whole['metadata']['totalItems']; full = {row['id']: row for row in whole['data']}
assert expected_total == 1416 and len(full) == 1408
with gzip.open(work / 'eight-pagination-original-responses-v1.jsonl.gz', 'rt') as source:
    initial = [json.loads(line) for line in source]
cache = {(row['from'], row['limit']): row for row in initial}
endpoint = 'https://content.publishing.riotgames.com/publishing-content/v2.0/public/channel/riftbound_website/list/riftbound_gallery_cards'
output = work / 'eight-slot-localization-v1.json'; archive = work / 'slot-localization-original-responses-v1.jsonl.gz'
assert not output.exists() and not archive.exists()
manifest_path = root / 'docs/audit/current-manifest.json'; manifest_before = sha(manifest_path.read_bytes())

def mapping(record):
    assert record['status'].startswith('ACQUIRED')
    body = json.loads(record['originalUtf8']); metadata = body['metadata']; rows = body['data']
    assert metadata['from'] == record['from'] and metadata['limit'] == record['limit']
    assert metadata['totalItems'] == expected_total and metadata['locale'] == 'en-us'
    assert all(full.get(row['id']) == row for row in rows), 'Source content drift or unknown original identity.'
    result = {row['id']: row for row in rows}
    assert len(result) == len(rows), 'Unexpected duplicate within one raw response.'
    return result

def deficit(key):
    start, size = key
    return min(size, expected_total - start) - len(mapping(cache[key]))

assert set().union(*(mapping(row).keys() for row in initial)) == full.keys()
assert sum(deficit(key) for key in cache) == 8
queue = [key for key in cache if deficit(key) > 0]
forks = []; empty = []; conservation = []; failures = []; request_count = 0

def acquire(key):
    start, size = key; url = endpoint + f'?locale=en_US&limit={size}&from={start}'
    record = {'url': url, 'from': start, 'limit': size, 'startedAtUtc': now()}
    try:
        request = urllib.request.Request(url, headers={'User-Agent': 'RiftboundOfficialAudit/1.0', 'Cache-Control': 'no-cache'})
        with urllib.request.urlopen(request, timeout=45) as response:
            raw = response.read(2 * 1024 * 1024 + 1); assert len(raw) <= 2 * 1024 * 1024
            record.update(httpStatus=response.status, resolvedUrl=response.url, httpDate=response.headers.get('Date'))
        record.update(status='ACQUIRED_ORIGINAL_SOURCE_WINDOW_NOT_CARD_CERTIFICATION', originalUtf8=raw.decode(),
                      rawBytes=len(raw), rawSha256=sha(raw), receivedAtUtc=now())
    except Exception as error:
        record.update(status='FAILED_ORIGINAL_WINDOW_PREFIX_RETAINED', errorType=type(error).__name__, errorMessage=str(error))
    return record

try:
    with gzip.GzipFile(filename=str(archive), mode='wb', mtime=0) as stream:
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            while queue:
                parents = queue; queue = []; pending = set()
                for start, size in parents:
                    if size == 1:
                        assert not mapping(cache[start, size])
                        empty.append({'from': start, 'limit': size, 'url': cache[start, size]['url'], 'originalSha256': cache[start, size]['rawSha256']})
                        continue
                    half = size // 2
                    pending.update([(start, half), (start + half, size - half)])
                needed = sorted(key for key in pending if key not in cache)
                assert request_count + len(needed) <= 128, 'Bounded128-request localization budget exceeded.'
                for key, record in zip(needed, pool.map(acquire, needed)):
                    cache[key] = record; request_count += 1
                    stream.write((json.dumps(record, ensure_ascii=False) + '\n').encode()); stream.flush()
                    mapping(record)
                for key in parents:
                    start, size = key
                    if size == 1:
                        continue
                    half = size // 2; left = (start, half); right = (start + half, size - half)
                    a, b, parent = mapping(cache[left]), mapping(cache[right]), mapping(cache[key])
                    union = a | b
                    assert union == parent, 'Parent/child source identity instability; cannot infer a missing-slot classification.'
                    shared = sorted(a.keys() & b.keys())
                    assert deficit(key) == deficit(left) + deficit(right) + len(shared)
                    conservation.append({'parent': key, 'left': left, 'right': right, 'parentDeficit': deficit(key),
                                         'leftDeficit': deficit(left), 'rightDeficit': deficit(right), 'identicalCrossWindowIds': shared})
                    for value in shared:
                        forks.append({'officialId': value, 'publicCode': full[value]['publicCode'], 'name': full[value]['name'],
                                      'leftWindow': left, 'rightWindow': right, 'leftUrl': cache[left]['url'], 'rightUrl': cache[right]['url'],
                                      'leftOriginalSha256': cache[left]['rawSha256'], 'rightOriginalSha256': cache[right]['rawSha256'],
                                      'sameEntireOfficialRowNotNameOnly': True})
                    queue.extend(child for child in [left, right] if deficit(child) > 0)
    assert len(forks) + len(empty) == 8
except Exception as error:
    failures.append({'type': type(error).__name__, 'message': str(error)})
assert sha(manifest_path.read_bytes()) == manifest_before
proof = {'status': 'ALL_EIGHT_SOURCE_COUNT_VARIANCES_LOCALIZED' if not failures else 'LOCALIZATION_UNSTABLE_OR_INCOMPLETE_PREFIX_RETAINED',
    'finishedAtUtc': now(), 'region': 'GLOBAL', 'language': 'en-US', 'sourceReportedTotal': expected_total, 'sourceUniqueWholeRows': len(full),
    'additionalRequests': request_count, 'maximumAdditionalRequests': 128, 'exactCrossWindowDuplicateIdentityCount': len(forks),
    'zeroRowExactOffsetCount': len(empty), 'duplicateIdentities': forks, 'zeroRowOffsets': empty,
    'conservationChecks': conservation, 'failures': failures,
    'originalAdditionalResponses': {'path': str(archive.relative_to(root)), 'sha256': sha(archive.read_bytes())},
    'allEightObservedVarianceExplainedByIdenticalApiIds': not failures and len(forks) == 8 and not empty,
    'backendCauseOrPhysicalPrintingCompletenessNotInferred': True, 'eightArticleCandidatesNotAssumedToEqualReportedVariance': True,
    'currentSourceUniverseAndDatesAndRuntimeInputsNotMutated': True, 'currentManifestSha256': manifest_before,
    'formalExistingGapDispositionNotChangedByThisReadOnlyResearch': True, 'semanticCoverageCertified': False}
output.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
print({key: proof[key] for key in ['status', 'additionalRequests', 'exactCrossWindowDuplicateIdentityCount', 'zeroRowExactOffsetCount', 'failures']})
print('duplicates', [(row['officialId'], row['publicCode']) for row in forks])
print('zero-row offsets', [row['from'] for row in empty])
