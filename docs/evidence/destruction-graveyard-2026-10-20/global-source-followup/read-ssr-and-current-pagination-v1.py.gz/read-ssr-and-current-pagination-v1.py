import collections
import concurrent.futures
import datetime
import gzip
import hashlib
from html.parser import HTMLParser
import json
import pathlib
import urllib.request

root = pathlib.Path.cwd(); work = pathlib.Path(__file__).resolve().parent
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
sha = lambda value: hashlib.sha256(value).hexdigest()
whole_path = work / 'whole-en-us-original-v1.json.gz'
whole = json.loads(gzip.decompress(whole_path.read_bytes())); all_rows = {row['id']: row for row in whole['data']}
class Script(HTMLParser):
    def __init__(self): super().__init__(); self.active = False; self.parts = []
    def handle_starttag(self, tag, attrs):
        if tag == 'script': self.active = dict(attrs).get('id') == '__NEXT_DATA__'
    def handle_data(self, value):
        if self.active: self.parts.append(value)
    def handle_endtag(self, tag):
        if tag == 'script': self.active = False
parser = Script(); html_path = work / 'official-gallery-ssr-original-v1.html.gz'
parser.feed(gzip.decompress(html_path.read_bytes()).decode())
ssr = json.loads(''.join(parser.parts))
blade = next(row for row in ssr['props']['pageProps']['page']['blades'] if isinstance(row, dict) and isinstance(row.get('cards'), dict) and 'items' in row['cards'])
ssr_rows = blade['cards']['items']; ssr_map = {row['id']: row for row in ssr_rows}
endpoint = 'https://content.publishing.riotgames.com/publishing-content/v2.0/public/channel/riftbound_website/list/riftbound_gallery_cards'
def acquire(offset):
    url = endpoint + f'?locale=en_US&limit=200&from={offset}'
    record = {'url': url, 'from': offset, 'limit': 200, 'startedAtUtc': now()}
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'RiftboundOfficialAudit/1.0', 'Cache-Control': 'no-cache'}), timeout=45) as response:
            raw = response.read(2 * 1024 * 1024 + 1); assert len(raw) <= 2 * 1024 * 1024
            record.update(httpStatus=response.status, resolvedUrl=response.url, httpDate=response.headers.get('Date'))
        body = json.loads(raw)
        record.update(status='ACQUIRED_NOT_COVERAGE_CERTIFICATION', receivedAtUtc=now(), rawBytes=len(raw), rawSha256=sha(raw), originalUtf8=raw.decode(),
                      metadata=body['metadata'], returnedRows=len(body['data']), ids=[r['id'] for r in body['data']],
                      allRowsExactlyMatchObservedWholeList=all(all_rows.get(r['id']) == r for r in body['data']))
    except Exception as error:
        record.update(status='FAILED_SOURCE_PAGE_PREFIX_RETAINED', errorType=type(error).__name__, errorMessage=str(error))
    return record
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    pages = list(pool.map(acquire, range(0, 1600, 200)))
archive = work / 'eight-pagination-original-responses-v1.jsonl.gz'; assert not archive.exists()
with gzip.GzipFile(filename=str(archive), mode='wb', mtime=0) as stream:
    for row in pages:
        stream.write((json.dumps(row, ensure_ascii=False) + '\n').encode())
counter = collections.Counter(value for row in pages for value in row.get('ids', []))
derivative = work / 'ssr-next-data-v1.json.gz'
retired = {'path': str(derivative.relative_to(root)), 'bytes': derivative.stat().st_size, 'sha256': sha(derivative.read_bytes()),
           'reason': 'Redundant extracted JSON exactly recoverable from the retained original HTML script; original official HTML remains.'}
derivative.unlink()
proof = {'status': 'CURRENT_SSR_AND_EIGHT_PAGINATION_PAGES_READBACK_NOT_CARD_CERTIFICATION', 'atUtc': now(),
    'region': 'GLOBAL', 'language': 'en-US', 'sourcePage': 'https://playriftbound.com/en-us/card-gallery/',
    'originalHtmlSha256': sha(html_path.read_bytes()), 'wholeListOriginalSha256': sha(whole_path.read_bytes()),
    'actualSsrCardArrayPath': '/props/pageProps/page/blades/2/cards/items', 'ssrRows': len(ssr_rows), 'ssrDistinctIds': len(ssr_map),
    'ssrExactlyMatchesWholeListDictionary': ssr_map == all_rows, 'actualSsrMetadata': blade['cards']['async']['metadata'],
    'paginationOriginalArchive': {'path': str(archive.relative_to(root)), 'sha256': sha(archive.read_bytes())},
    'pages': [{k: v for k, v in row.items() if k not in ['originalUtf8', 'ids']} for row in pages],
    'actualPaginationRows': sum(counter.values()), 'actualPaginationDistinctIds': len(counter),
    'duplicateIdsWithCounts': {k: v for k, v in counter.items() if v > 1},
    'wholeListIdsNotSeenInPagination': sorted(all_rows.keys() - counter.keys()),
    'paginationIdsNotSeenInWholeList': sorted(counter.keys() - all_rows.keys()),
    'allOriginalGapDispositionsStillOpen': True, 'reportedEightNotAssumedToBeArticleEightOrDuplicateRecords': True,
    'noSourceUniverseDatesRuntimeInputsOrCurrentCheckFilesMutated': True, 'retiredDuplicateDerivative': retired}
output = work / 'ssr-and-pagination-readback-v1.json'; assert not output.exists(); output.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
print({k: proof[k] for k in ['ssrRows', 'ssrDistinctIds', 'ssrExactlyMatchesWholeListDictionary', 'actualPaginationRows', 'actualPaginationDistinctIds', 'duplicateIdsWithCounts', 'wholeListIdsNotSeenInPagination']})
print('page lengths', [(row['from'], row.get('returnedRows')) for row in pages])
