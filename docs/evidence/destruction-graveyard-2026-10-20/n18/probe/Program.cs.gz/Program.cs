using System.IO.Compression;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using Riftbound.Contracts;
using Riftbound.Engine;

if (args.Length != 1 || Directory.Exists(args[0])) throw new Exception("A new original evidence directory is required.");
var output = Path.GetFullPath(args[0]); Directory.CreateDirectory(output);
var summaries = new List<object>();
var factory = typeof(CoreRuleEngine).Assembly.GetType("Riftbound.Engine.PrintedCardFactory")!
    .GetMethod("TryCreate", BindingFlags.NonPublic | BindingFlags.Static)!;
foreach (var kind in new[] { "direct-spell", "self-destroyed-phoenix", "decree-nonlethal-spell" })
{
    var self = kind == "self-destroyed-phoenix";
    var decree = kind == "decree-nonlethal-spell";
    var victim = self ? "PHOENIX" : "VICTIM";
    var owner = self ? "P1" : "P2";
    var cards = new Dictionary<string, CardObjectState> {
        ["F"] = Card("F", "OGN·278/298", "P1") with { ControllerId = "P1" },
        ["OTHER"] = Card("OTHER", "OGN·294/298", "P2") with { ControllerId = "P2" },
        ["PHOENIX"] = Card("PHOENIX", "OGN·037/298", "P1"),
        ["RAY"] = Card("RAY", "OGN·009/298", "P1"), ["DECREE"] = Card("DECREE", "OGN·221/298", "P1"),
        ["D0"] = Card("D0", "OGN·096/298", "P1"), ["D1"] = Card("D1", "OGN·096/298", "P1") };
    if (!self) cards[victim] = Card(victim, decree ? "UNL-118/219" : "OGN·096/298", owner);
    var positions = new Dictionary<string, ObjectLocationState> {
        ["F"] = new("P1", "BATTLEFIELD", "F"), ["OTHER"] = new("P2", "BATTLEFIELD", "OTHER"),
        ["PHOENIX"] = new("P1", self ? "BATTLEFIELD" : "GRAVEYARD", self ? "F" : null),
        ["RAY"] = new("P1", "HAND"), ["DECREE"] = new("P1", "HAND"),
        ["D0"] = new("P1", "MAIN_DECK"), ["D1"] = new("P1", "MAIN_DECK") };
    if (!self) positions[victim] = new(owner, "BATTLEFIELD", "OTHER");
    var initial = new MatchState("CONTROLLED-PHOENIX-" + kind, 0, 5, "P1",
        new Dictionary<string, string> { ["P1"] = "P1", ["P2"] = "P2" },
        status: MatchStatuses.InProgress, phase: MatchPhases.Main, timingState: TimingStates.NeutralOpen,
        cardObjects: cards, objectLocations: positions,
        runePools: new Dictionary<string, RunePool> { ["P1"] = new(20, 20), ["P2"] = new(20, 20) },
        playerZones: new Dictionary<string, PlayerZones> {
            ["P1"] = PlayerZones.Empty with { Hand = ["RAY", "DECREE"], MainDeck = ["D0", "D1"],
                Graveyard = self ? [] : ["PHOENIX"], Battlefields = self ? ["F", "PHOENIX"] : ["F"] },
            ["P2"] = PlayerZones.Empty with { Battlefields = self ? ["OTHER"] : ["OTHER", victim] } })
        { CardPlays = new(5, [], []) };
    var journal = new Journal(); var state = initial;
    var session = new MatchSession(initial, new CoreRuleEngine(), journal);
    Require(Validate(state, journal).Count == 0, "Controlled initial state fails recovery invariants.");
    if (decree) await Spell("DECREE", "OGN·221/298", []);
    await Spell("RAY", "OGN·009/298", [victim]);
    var commands = journal.Commands(); var events = journal.Events();
    var replay = await MatchActionLogReplayer.VerifyFinalStateAsync(initial, commands, state, new CoreRuleEngine(), default, events);
    var phoenixTriggers = events.Count(e => e.Event.Kind == "TRIGGER_QUEUED"
        && Equals(e.Event.Payload.GetValueOrDefault("sourceObjectId"), "PHOENIX"));
    var framePath = Path.Combine(output, kind + "-original-frame.json.gz");
    await using (var file = new FileStream(framePath, FileMode.CreateNew, FileAccess.Write, FileShare.None))
    await using (var zip = new GZipStream(file, CompressionLevel.SmallestSize))
        await JsonSerializer.SerializeAsync(zip, new { controlledFixture = true, ordinaryBlankOpening = false,
            initial, finalState = state, commands, events, replay, actualRuleInputs = RuleInputIdentity.Current }, Journal.Options);
    Require(replay.IsMatch, string.Join(";", replay.Errors));
    Require(Validate(state, journal).Count == 0, string.Join(";", Validate(state, journal)));
    Require(state.PlayerZones[owner].Graveyard.Contains(victim), "The printed unit was not actually destroyed.");
    Require(events.Any(e => e.Event.Kind == "UNIT_DESTROYED"), "No actual destruction event.");
    Require(phoenixTriggers == 0 && state.StackItems.All(s => s.SourceObjectId != "PHOENIX")
        && state.TriggerQueue.All(t => t.SourceObjectId != "PHOENIX"), "Diagnosed missing trigger is no longer reproduced; inspect original evidence.");
    summaries.Add(new { kind, controlledFixture = true, ordinaryBlankOpening = false,
        expectedPhoenixTrigger = true, actualPhoenixQueuedEvents = phoenixTriggers,
        commands = commands.Count, events = events.Count, victim, victimCardNo = cards[victim].CardNo,
        victimOriginalPower = cards[victim].Power, allOriginalReplayMatched = replay.IsMatch,
        independentRecoveryInvariantsPassed = true, originalFrame = framePath, originalFrameSha256 = Sha(framePath) });

    async Task Spell(string id, string cardNo, IReadOnlyList<string> targets)
    {
        await Act("P1", new PlayCardCommand(id, cardNo, targets));
        for (var i = 0; i < 12 && state.StackItems.Any(s => s.SourceObjectId == id); i++)
        {
            Require(state.PriorityPlayerId is not null, "Unexpected pending window; preserve original prefix.");
            await Act(state.PriorityPlayerId!, new PassPriorityCommand());
        }
        Require(state.StackItems.All(s => s.SourceObjectId != id), "Original spell did not resolve.");
    }
    async Task Act(string player, GameCommand command)
    {
        var prompt = session.PromptFor(player);
        var fields = JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(JsonSerializer.Serialize(command, command.GetType(), Journal.Options), Journal.Options)!;
        fields["promptId"] = JsonSerializer.SerializeToElement(prompt.PromptId);
        fields["snapshotTick"] = JsonSerializer.SerializeToElement(state.Tick);
        var result = await session.SubmitAsync(player, "original-" + journal.Entries.Count, command, JsonSerializer.SerializeToElement(fields), default);
        state = result.State;
        if (!result.Accepted)
            File.WriteAllText(Path.Combine(output, kind + "-rejected-prefix.json"), JsonSerializer.Serialize(new { initial, state, journal.Entries }, Journal.Options));
        Require(result.Accepted, result.ErrorMessage ?? "Authoritative engine rejected the original controlled command.");
    }
}
Console.WriteLine(JsonSerializer.Serialize(new { status = "THREE_CONTROLLED_PHOENIX_MISSING_TRIGGER_COUNTEREXAMPLES_NOT_ORDINARY_MATCH_OR_PRODUCT_ACCEPTANCE",
    atUtc = DateTimeOffset.UtcNow, actualRuleInputs = RuleInputIdentity.Current,
    loadedCoreHashes = new[] { typeof(CoreRuleEngine).Assembly, typeof(GameCommand).Assembly, typeof(Riftbound.CardCatalog.OfficialCardCatalog).Assembly }
        .ToDictionary(a => Path.GetFileName(a.Location), a => Sha(a.Location)),
    noMainProjectOrGodotBuild = true, originalDatabaseNotAccessed = true, cases = summaries }, Journal.Options));

CardObjectState Card(string id, string cardNo, string owner)
{
    object?[] arguments = [id, owner, cardNo, null];
    Require((bool)factory.Invoke(null, arguments)!, "Actual fixed printed-card factory rejected " + cardNo);
    return (CardObjectState)arguments[3]!;
}
static IReadOnlyList<string> Validate(MatchState state, Journal journal)
{
    var snapshots = ResolutionResult.BuildSnapshots(state); var prompts = ResolutionResult.BuildPrompts(state);
    var sequence = journal.Entries.LastOrDefault()?.CompletedEventSequence ?? 0;
    var views = state.Seats.Keys.ToDictionary(id => id, id => new RecoveredPlayerView(id, state.Tick, sequence, snapshots[id], state.Tick, sequence, prompts[id]));
    var spectator = MatchReplayRedactor.BuildSpectatorFrame(state.RoomId, state.Tick, sequence, [], state);
    return MatchRecoveryValidator.Validate(state.RoomId, sequence, journal.Commands(), journal.Events(), views, state, state.Tick, spectator);
}
static void Require(bool condition, string message) { if (!condition) throw new Exception(message); }
static string Sha(string path) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path))).ToLowerInvariant();
sealed class Journal : IMatchJournal
{
    public static readonly JsonSerializerOptions Options = new(JsonSerializerDefaults.Web) { WriteIndented = true };
    public List<MatchJournalEntry> Entries { get; } = [];
    public ValueTask RecordAsync(MatchJournalEntry entry, CancellationToken token) { Entries.Add(entry); return ValueTask.CompletedTask; }
    public IReadOnlyList<RecoveredCommand> Commands() => Entries.Select(e => new RecoveredCommand(e.PlayerId, e.ClientIntentId, e.CommandType, e.RawCommand,
        e.StartedTick, e.CompletedTick, e.StartedEventSequence, e.CompletedEventSequence, e.Accepted, e.ErrorMessage) { RuleInputs = e.RuleInputs }).ToArray();
    public IReadOnlyList<RecoveredEvent> Events() => Entries.SelectMany(e => e.Events.Select((ev, i) => new RecoveredEvent(e.StartedEventSequence + i + 1, e.CompletedTick, i, ev))).ToArray();
}
