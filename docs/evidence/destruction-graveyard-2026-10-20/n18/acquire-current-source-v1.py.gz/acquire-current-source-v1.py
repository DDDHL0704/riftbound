import concurrent.futures
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import tempfile
import urllib.request

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
NOW = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
SHA = lambda b: hashlib.sha256(b).hexdigest()
BASELINE = ROOT / 'data/official/upstream/2026-10-16/source-refresh-20261015T160523Z/card-catalog.zh-CN.json'
CATALOG = json.loads(BASELINE.read_text())['cards']
API = 'https://lol-api.playloltcg.com'


def fetch(label, url, payload=None, canonical=None):
    record = {'label': label, 'url': url, 'request': payload, 'startedAtUtc': NOW(),
              'region': 'CN', 'language': 'zh-CN', 'publicationDate': None, 'effectiveDate': None}
    data = None if payload is None else json.dumps(payload, ensure_ascii=False).encode()
    request = urllib.request.Request(url, data=data, headers={
        'Content-Type': 'application/json', 'User-Agent': 'Riftbound official source audit'})
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            record.update(httpStatus=response.status, resolvedUrl=response.url,
                          httpDate=response.headers.get('Date'), lastModified=response.headers.get('Last-Modified'),
                          contentType=response.headers.get('Content-Type'))
            if canonical is not None:
                digest = hashlib.sha256()
                count = 0
                with tempfile.NamedTemporaryFile(dir=HERE, delete=False) as temporary:
                    temporary_path = Path(temporary.name)
                    while chunk := response.read(1024 * 1024):
                        digest.update(chunk)
                        temporary.write(chunk)
                        count += len(chunk)
                canonical = ROOT / canonical
                record.update(rawBytes=count, rawSha256=digest.hexdigest(), canonicalSource=str(canonical.relative_to(ROOT)))
                record['matchesRetainedCanonical'] = digest.hexdigest() == SHA(canonical.read_bytes())
                if record['matchesRetainedCanonical']:
                    temporary_path.unlink()
                    record['noDuplicatePdfRetained'] = True
                else:
                    changed = HERE / (label + '-changed-' + digest.hexdigest()[:16] + '.pdf')
                    temporary_path.rename(changed)
                    record['newBytesRetainedForSeparateDeltaReview'] = str(changed.relative_to(ROOT))
                return record, None
            raw = response.read()
        path = HERE / (label + ('.json.gz' if payload is not None else Path(url).suffix))
        assert not path.exists(), path
        path.write_bytes(gzip.compress(raw, mtime=0) if payload is not None else raw)
        record.update(rawBytes=len(raw), rawSha256=SHA(raw), path=str(path.relative_to(ROOT)), storedSha256=SHA(path.read_bytes()))
        return record, json.loads(raw) if payload is not None else None
    except Exception as error:
        record.update(status='ACQUISITION_FAILED_NOT_SOURCE_ABSENCE', error=repr(error))
        return record, None
    finally:
        record['receivedAtUtc'] = NOW()


assert not (HERE / 'fresh-source-intake-v1.json').exists()
jobs = [('rules-directory', API + '/xcx/gameRule/getGameRuleList', {'pageNum': 1, 'pageSize': 1000}, None)]
for name, label in [('不朽凤凰', 'phoenix'), ('帝国谕令', 'decree'), ('海克斯射线', 'ray'), ('远古巨龙', 'elder')]:
    payload = {'pageNum': 1, 'pageSize': 100, 'searchContent': name, 'cardCategoryList': [],
               'cardColorList': [], 'rarityList': [], 'productCodeList': []}
    jobs.append((label, API + '/xcx/card/searchCardCraftWeb', payload, None))
jobs += [
    ('current-core', 'https://cdn.playloltcg.com/lol/2026/10/2026-10-10/a21ead876c6b44d6abe386b6ae54ea28.pdf', None,
     'var/qa/colorless-token-haste-20261016/DOC-01-current.pdf'),
    ('current-vanquish-faq', 'https://cdn.playloltcg.com/lol/2026/08/2026-08-13/612b1cd53f9f41baaf3c8734c1881a3b.pdf', None,
     'var/qa/porobot-20261015/resume-DOC-06.pdf')]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
    results = list(executor.map(lambda args: fetch(*args), jobs))
records = [r for r, _ in results]
comparisons = []
for record, body in results:
    if body is None or record['label'] == 'rules-directory':
        continue
    assert body['code'] == 0
    rows = body['result']['list']
    for row in rows:
        previous = next((c for c in CATALOG if c['id'] == row['id']), None)
        comparisons.append({'apiId': row['id'], 'cardNo': row['cardNo'], 'name': row['cardName'],
                            'entireCurrentRowMatchesCn16': previous == row,
                            'changedFields': None if previous is None else sorted(k for k in set(previous) | set(row) if previous.get(k) != row.get(k)),
                            'frontImage': row['frontImage'], 'isPreview': row.get('isPreview'),
                            'individualPublicationDate': None, 'individualEffectiveDate': None})
receipt = {'recordedAtUtc': NOW(), 'baseCommit': '08fd25c0dc643f9120b529f039feed69beffc251',
           'region': 'CN', 'language': 'zh-CN', 'applicableRulesBaseline': '2026-10-16',
           'scope': 'Source intake only: graveyard Phoenix optional play and actual spell/delayed destruction responsibility; no semantic implementation certification.',
           'records': records, 'exactRowComparisons': comparisons,
           'prior1740PrintingAndAllRuleObligationsRetained': True,
           'wholeCardSemanticCertification': False, 'fixedCiAndProductAcceptance': 'OPEN'}
(HERE / 'fresh-source-intake-v1.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'sources': len(records), 'failed': [r['label'] for r in records if r.get('status')],
                  'rows': len(comparisons), 'changedRows': [r for r in comparisons if not r['entireCurrentRowMatchesCn16']],
                  'pdfHashesMatch': {r['label']: r.get('matchesRetainedCanonical') for r in records if r['label'].startswith('current-')}}, ensure_ascii=False))
