using System.IO.Compression;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using Riftbound.Contracts;
using Riftbound.Engine;

if (args.Length != 1 || Directory.Exists(args[0])) throw new Exception("New original evidence directory required.");
var output = Path.GetFullPath(args[0]); Directory.CreateDirectory(output);
var factory = typeof(CoreRuleEngine).Assembly.GetType("Riftbound.Engine.PrintedCardFactory")!.GetMethod("TryCreate", BindingFlags.NonPublic | BindingFlags.Static)!;
var results = new List<object>();
foreach (var inspire in new[] { false, true })
{
    var cards = new Dictionary<string, CardObjectState> {
        ["F"] = Card("F", "OGN·278/298", "P1") with { ControllerId = "P1" },
        ["OTHER"] = Card("OTHER", "OGN·297/298", "P2") with { ControllerId = "P2" },
        ["VICTIM"] = Card("VICTIM", "UNL-118/219", "P2"),
        ["NOXIAN"] = Card("NOXIAN", "OGN·254/298", "P1"), ["RAY"] = Card("RAY", "OGN·009/298", "P1"),
        ["CHEAP"] = Card("CHEAP", "OGN·096/298", "P1"), ["D0"] = Card("D0", "OGN·096/298", "P1") };
    var locations = new Dictionary<string, ObjectLocationState> {
        ["F"] = new("P1", "BATTLEFIELD", "F"), ["OTHER"] = new("P2", "BATTLEFIELD", "OTHER"),
        ["VICTIM"] = new("P2", "BATTLEFIELD", "OTHER"), ["NOXIAN"] = new("P1", "HAND"),
        ["RAY"] = new("P1", "HAND"), ["CHEAP"] = new("P1", "HAND"), ["D0"] = new("P1", "MAIN_DECK") };
    var initial = new MatchState("CONTROLLED-NOXIAN-" + inspire, 0, 5, "P1", new Dictionary<string, string> { ["P1"] = "P1", ["P2"] = "P2" },
        status: MatchStatuses.InProgress, phase: MatchPhases.Main, timingState: TimingStates.NeutralOpen,
        cardObjects: cards, objectLocations: locations, runePools: new Dictionary<string, RunePool> { ["P1"] = new(20, 20), ["P2"] = new(20, 20) },
        playerZones: new Dictionary<string, PlayerZones> {
            ["P1"] = PlayerZones.Empty with { Hand = ["NOXIAN", "RAY", "CHEAP"], MainDeck = ["D0"], Battlefields = ["F"] },
            ["P2"] = PlayerZones.Empty with { Battlefields = ["OTHER", "VICTIM"] } }) { CardPlays = new(5, [], []) };
    var journal = new Journal(); var session = new MatchSession(initial, new CoreRuleEngine(), journal); var state = initial;
    Require(Validate(state, journal).Count == 0, "Initial controlled state violates recovery invariants.");
    if (inspire) { await Act("P1", new PlayCardCommand("CHEAP", "OGN·096/298", [])); await Drain(); }
    await Act("P1", new PlayCardCommand("NOXIAN", "OGN·254/298", ["VICTIM"]));
    Require(state.StackItems.Single(s => s.SourceObjectId == "NOXIAN").PlayedAfterAnotherCardThisTurn == inspire,
        "The actual confirmation-time Inspire flag differs from its original command prefix.");
    await Drain(); var afterNoxian = state;
    if (!inspire) { await Act("P1", new PlayCardCommand("RAY", "OGN·009/298", ["VICTIM"])); await Drain(); }
    var commands = journal.Commands(); var events = journal.Events();
    var replay = await MatchActionLogReplayer.VerifyFinalStateAsync(initial, commands, state, new CoreRuleEngine(), default, events);
    var path = Path.Combine(output, (inspire ? "inspire" : "next-damage") + "-original-frame.json.gz");
    await using (var file = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None))
    await using (var zip = new GZipStream(file, CompressionLevel.SmallestSize))
        await JsonSerializer.SerializeAsync(zip, new { controlledFixture = true, ordinaryBlankOpening = false, initial,
            afterNoxian, finalState = state, commands, events, replay, actualRuleInputs = RuleInputIdentity.Current }, Journal.Options);
    Require(replay.IsMatch && Validate(state, journal).Count == 0, "Original full replay or recovery invariants failed.");
    Require(afterNoxian.PlayerZones["P2"].Battlefields.Contains("VICTIM"), "Expected fixed candidate marker-only branch is no longer reproduced.");
    if (!inspire)
        Require(state.PlayerZones["P2"].Graveyard.Contains("VICTIM")
            && events.Last(e => e.Event.Kind == "UNIT_DESTROYED").Event.Payload["sourceObjectId"]?.ToString() == "RAY"
            && !events.Any(e => e.Event.Kind == "TRIGGER_QUEUED" && e.Event.Payload.GetValueOrDefault("sourceObjectId")?.ToString() == "NOXIAN"),
            "Original damage/deferred destruction attribution differs from diagnosed fixed candidate behavior.");
    results.Add(new { inspireAtConfirmation = inspire, commands = commands.Count, events = events.Count,
        actualTargetSurvivedNoxianResolution = true, expectedImmediateDestroy = inspire,
        classification = inspire ? "CONFIRMED_CONTROLLED_INSPIRE_IMMEDIATE_DESTRUCTION_MISSING"
            : "CONFIRMED_CONTROLLED_NEXT_DAMAGE_DESTROYS_INSIDE_DAMAGE_WITHOUT_INDEPENDENT_DELAYED_TRIGGER",
        actualOriginalFullReplayPassed = true, independentRecoveryInvariantsPassed = true, originalFrameSha256 = Sha(path) });
    async Task Act(string actor, GameCommand command)
    {
        var raw = JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(JsonSerializer.Serialize(command, command.GetType(), Journal.Options), Journal.Options)!;
        raw["promptId"] = JsonSerializer.SerializeToElement(session.PromptFor(actor).PromptId); raw["snapshotTick"] = JsonSerializer.SerializeToElement(state.Tick);
        var result = await session.SubmitAsync(actor, "original-" + journal.Entries.Count, command, JsonSerializer.SerializeToElement(raw), default);
        Require(result.Accepted, result.ErrorMessage ?? "Original controlled command rejected."); state = result.State;
    }
    async Task Drain()
    {
        for (var i = 0; i < 24 && (state.StackItems.Count > 0 || state.TriggerQueue.Count > 0); i++)
            if (state.TriggerQueue.Count > 0) await Act(state.TriggerQueue[0].ControllerId, new OrderTriggersCommand(OrderedTriggerIds: state.TriggerQueue.Select(t => t.TriggerId).ToArray()));
            else if (state.PriorityPlayerId is { } actor) await Act(actor, new PassPriorityCommand());
            else throw new Exception("Unexpected pending original window.");
        Require(state.StackItems.Count == 0 && state.TriggerQueue.Count == 0, "Original stack did not close.");
    }
}
Console.WriteLine(JsonSerializer.Serialize(new { status = "TWO_CONTROLLED_CURRENT_NOXIAN_DEFERRED_FAMILY_COUNTEREXAMPLES_ONLY",
    actualRuleInputs = RuleInputIdentity.Current, sourceApiId = 31496, exactPrinting = "OGN·254/298", cases = results,
    noMainOrGodotBuildOrDatabaseAccess = true, ordinaryOpeningAndProductAcceptance = "OPEN" }, Journal.Options));
CardObjectState Card(string id, string no, string owner) { object?[] args = [id, owner, no, null]; Require((bool)factory.Invoke(null, args)!, "Exact printed factory card absent."); return (CardObjectState)args[3]!; }

static IReadOnlyList<string> Validate(MatchState state, Journal journal)
{
    var snapshots = ResolutionResult.BuildSnapshots(state); var prompts = ResolutionResult.BuildPrompts(state);
    var sequence = journal.Entries.LastOrDefault()?.CompletedEventSequence ?? 0;
    var views = state.Seats.Keys.ToDictionary(id => id, id => new RecoveredPlayerView(id, state.Tick, sequence, snapshots[id], state.Tick, sequence, prompts[id]));
    var spectator = MatchReplayRedactor.BuildSpectatorFrame(state.RoomId, state.Tick, sequence, [], state);
    return MatchRecoveryValidator.Validate(state.RoomId, sequence, journal.Commands(), journal.Events(), views, state, state.Tick, spectator);
}
static void Require(bool condition, string message) { if (!condition) throw new Exception(message); }
static string Sha(string path) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path))).ToLowerInvariant();
sealed class Journal : IMatchJournal
{
    public static readonly JsonSerializerOptions Options = new(JsonSerializerDefaults.Web) { WriteIndented = true };
    public List<MatchJournalEntry> Entries { get; } = [];
    public ValueTask RecordAsync(MatchJournalEntry entry, CancellationToken token) { Entries.Add(entry); return ValueTask.CompletedTask; }
    public IReadOnlyList<RecoveredCommand> Commands() => Entries.Select(e => new RecoveredCommand(e.PlayerId, e.ClientIntentId, e.CommandType, e.RawCommand,
        e.StartedTick, e.CompletedTick, e.StartedEventSequence, e.CompletedEventSequence, e.Accepted, e.ErrorMessage) { RuleInputs = e.RuleInputs }).ToArray();
    public IReadOnlyList<RecoveredEvent> Events() => Entries.SelectMany(e => e.Events.Select((ev, i) => new RecoveredEvent(e.StartedEventSequence + i + 1, e.CompletedTick, i, ev))).ToArray();
}
