using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using Riftbound.CardCatalog;
using Riftbound.Contracts;
using Riftbound.Engine;

if (args.Length != 1 || Directory.Exists(args[0])) throw new Exception("New original evidence directory required.");
var output = Path.GetFullPath(args[0]); Directory.CreateDirectory(output);
var catalog = await OfficialCardCatalog.LoadDefaultAsync();
var summaries = new List<object>();
foreach (var format in new[] { OfficialDeckFormat.CoreRules, OfficialDeckFormat.ChinaStandard20260724 })
{
    var main = new List<string> { "OGN·027/298" };
    foreach (var card in new[] { "OGN·037/298", "OGN·009/298", "OGN·221/298" }) main.AddRange(Enumerable.Repeat(card, 3));
    foreach (var card in catalog.Cards.Where(c => c.CardCategoryName == "单位" && c.Energy <= 2
        && c.CardColorList.All(t => t is "red" or "yellow") && ChinaStandardBanList.IsAllowed(c, format)
        && CardBehaviorRegistry.TryGetByCardNo(c.CardNo, out var behavior) && behavior.PlaysSourceToBaseAsUnit)
        .OrderBy(c => c.Energy).ThenBy(c => c.CardNo, StringComparer.Ordinal).GroupBy(c => (c.CardName, c.SubTitle)).Select(g => g.First()))
    {
        main.AddRange(Enumerable.Repeat(card.CardNo, Math.Min(3, 40 - main.Count)));
        if (main.Count == 40) break;
    }
    var fields = new[] { "OGN·278/298", "OGN·293/298", "OGN·297/298" };
    var deck1 = new OfficialDecklist("OGN·253/298", "OGN·027/298", main,
        Enumerable.Repeat("OGN·007/298", 6).Concat(Enumerable.Repeat("OGN·214/298", 6)).ToArray(), fields);
    var baseDeck = PreconstructedDeckCatalog.Build(catalog, format).Single(d => d.Id == "poppy-demacia").Decklist;
    var secondMain = baseDeck.MainDeck.ToList();
    for (var i = 0; i < 3; i++) secondMain.RemoveAt(secondMain.FindIndex(no => no != baseDeck.ChampionCardNo));
    secondMain.AddRange(Enumerable.Repeat("UNL-118/219", 3));
    var deck2 = baseDeck with { MainDeck = secondMain,
        RuneDeck = Enumerable.Repeat("OGN·126/298", 8).Concat(Enumerable.Repeat("OGN·214/298", 4)).ToArray(), Battlefields = fields };
    foreach (var deck in new[] { deck1, deck2 })
    {
        var validation = OfficialDeckValidator.Validate(deck, catalog, format);
        Require(validation.IsValid, string.Join(";", validation.Errors));
    }
    var initial = MatchReplayInitialStateBuilder.FromSeats("ordinary-phoenix-negative-" + format,
        new Dictionary<string, string> { ["P1"] = "P1", ["P2"] = "P2" });
    Require(initial.Seed == 0 && initial.CardObjects.Count == 0 && initial.Tick == 0, "Blank original seed0 match required.");
    var journal = new Journal(); var engine = new CoreRuleEngine(); var state = initial;
    var options = new MatchSessionOptions(AllowLegacyReadyWithoutDeck: false, DeckFormat: format);
    IMatchSession session = new MatchSession(initial, engine, journal, NoopMatchPlayerStore.Instance, options);
    var cold = 0; var nextChecks = 0; var afterCold = false;
    try
    {
        await Act("P1", new SubmitDeckCommand(deck1.LegendCardNo, deck1.ChampionCardNo, deck1.MainDeck, deck1.RuneDeck, deck1.Battlefields));
        await Act("P2", new SubmitDeckCommand(deck2.LegendCardNo, deck2.ChampionCardNo, deck2.MainDeck, deck2.RuneDeck, deck2.Battlefields));
        await Act("P1", new ReadyCommand()); await Act("P2", new ReadyCommand());
        while (state.Phase == MatchPhases.Mulligan) await Act(state.ActivePlayerId, new MulliganCommand([]));
        await Drain();
        for (var i = 0; i < 64 && !(Have("P1", "OGN·037/298") && Have("P1", "OGN·009/298", 2)
            && Have("P1", "OGN·221/298") && Have("P2", "UNL-118/219")
            && Runes("P1").Length == 12 && Runes("P2").Length == 12); i++) await End();
        Require(Have("P1", "OGN·037/298") && Have("P1", "OGN·009/298", 2)
            && Have("P1", "OGN·221/298") && Have("P2", "UNL-118/219"), "Original draws did not reach required cards; preserve prefix without changing seed/deck history.");
        await Turn("P2"); await Resources("P2", "orange", 4);
        var elder = Hand("P2", "UNL-118/219"); await Act("P2", new PlayCardCommand(elder, "UNL-118/219", [])); await Drain();
        Require(state.PlayerZones["P2"].Base.Contains(elder), "Actual printed Elder did not enter its owner's base.");
        await Turn("P1"); await Resources("P1", "red", 1);
        var phoenix = Hand("P1", "OGN·037/298"); await Act("P1", new PlayCardCommand(phoenix, "OGN·037/298", [])); await Drain();
        Require(state.PlayerZones["P1"].Base.Contains(phoenix), "Actual printed Phoenix did not enter its owner's base.");
        await End(); await Turn("P1"); await Resources("P1", "red", 1);
        await Act("P1", new MoveUnitCommand(phoenix, "BASE", "BATTLEFIELD:" + Field("P1"))); await Drain(); await Cold();
        var beforeSelf = journal.Events().Length;
        await Act("P1", new PlayCardCommand(Hand("P1", "OGN·009/298"), "OGN·009/298", [phoenix])); await Drain();
        Require(state.PlayerZones["P1"].Graveyard.Contains(phoenix), "Phoenix was not actually destroyed by its owner's spell.");
        await Cold();
        var selfReplay = await MatchActionLogReplayer.VerifyFinalStateAsync(initial, journal.Commands(), state, engine, default, journal.Events());
        Require(selfReplay.IsMatch, string.Join(";", selfReplay.Errors));
        await Save(Path.Combine(output, format + "-self-destroy-original-frame.json.gz"), Frame());
        var selfEvents = journal.Events().Skip(beforeSelf).ToArray();
        Require(selfEvents.Any(e => e.Event.Kind == "UNIT_DESTROYED") && !QueuedPhoenix(selfEvents, phoenix), "Inspect actual original self-destruction trigger behavior.");
        var selfCommands = journal.Commands().Length; var selfCount = journal.Events().Length;
        await Turn("P2"); await Act("P2", new MoveUnitCommand(elder, "BASE", "BATTLEFIELD:" + Field("P2"))); await Drain();
        await Turn("P1"); await Resources("P1", "yellow", 2); await Resources("P1", "red", 1);
        await Act("P1", new PlayCardCommand(Hand("P1", "OGN·221/298"), "OGN·221/298", [])); await Drain(); await Cold();
        Require(state.CardObjects[elder].Power == 10 && state.PlayerZones["P1"].Graveyard.Contains(phoenix), "Exact original FAQ premise differs.");
        var beforeDecreeKill = journal.Events().Length;
        await Act("P1", new PlayCardCommand(Hand("P1", "OGN·009/298"), "OGN·009/298", [elder])); await Drain(); await Cold();
        Require(state.PlayerZones["P2"].Graveyard.Contains(elder), "Nonlethal damage did not actually cause Elder destruction under Decree.");
        var finalEvents = journal.Events().Skip(beforeDecreeKill).ToArray();
        Require(finalEvents.Any(e => e.Event.Kind == "UNIT_DESTROYED") && !QueuedPhoenix(finalEvents, phoenix), "Inspect actual original delayed-source trigger behavior.");
        var replay = await MatchActionLogReplayer.VerifyFinalStateAsync(initial, journal.Commands(), state, engine, default, journal.Events());
        Require(replay.IsMatch, string.Join(";", replay.Errors));
        await Save(Path.Combine(output, format + "-decree-original-frame.json.gz"), Frame());
        summaries.Add(new { format = format.ToString(), originalBlankInitialSeed = initial.Seed,
            newBothDecksValidatedBeforeSubmit = true, selfCommands, selfEvents = selfCount,
            totalOriginalCommands = journal.Commands().Length, totalOriginalEvents = journal.Events().Length,
            coldRecoveries = cold, originalNextComparisons = nextChecks, selfPhoenixTriggerMissing = true,
            decreePhoenixTriggerMissing = true, originalSelfAndFinalReplayPassed = true,
            finalScores = state.PlayerScores, turnNumber = state.TurnNumber, phoenix, elder });
    }
    catch (Exception error)
    {
        await Save(Path.Combine(output, format + "-failed-original-prefix.json.gz"), new { initial, state, journal.Entries, error = error.ToString() });
        throw;
    }
    string[] Runes(string actor) => state.PlayerZones[actor].Base.Where(id => state.CardObjects[id].Tags.Contains(CardObjectTags.RuneCard)).ToArray();
    bool Have(string actor, string no, int count = 1) => state.PlayerZones[actor].Hand.Count(id => state.CardObjects[id].CardNo == no) >= count;
    string Hand(string actor, string no) => state.PlayerZones[actor].Hand.First(id => state.CardObjects[id].CardNo == no);
    string Field(string actor) => state.PlayerZones[actor].Battlefields.First(id => state.BattlefieldStates.ContainsKey(id));
    async Task End() { await Drain(); await Act(state.TurnPlayerId, new EndTurnCommand()); await Drain(); Require(state.Status == MatchStatuses.InProgress, "Original prefix unexpectedly finished; do not alter history."); }
    async Task Turn(string actor) { for (var i = 0; i < 3 && state.TurnPlayerId != actor; i++) await End(); Require(state.TurnPlayerId == actor, "Turn did not transfer."); }
    async Task Resources(string actor, string trait, int power)
    {
        foreach (var id in Runes(actor).Where(id => !state.CardObjects[id].IsExhausted).ToArray()) await Act(actor, new TapRuneCommand(id));
        for (var i = 0; i < power; i++)
        {
            var id = Runes(actor).First(id => state.CardObjects[id].Tags.Contains("COLOR:" + trait));
            await Act(actor, new RecycleRuneCommand(id));
        }
    }
    async Task Drain()
    {
        for (var i = 0; i < 48; i++)
        {
            if (state.PendingCardChoice is { } choice) await Act(choice.PlayerId, new ChooseCardsCommand(choice.ChoiceId, choice.ChoiceWindow, choice.LegalObjectIds.Take(choice.RequiredCount).ToArray()));
            else if (state.PendingPayment is { } payment && payment.LegalPaymentChoiceIds.Contains("DECLINE")) await Act(payment.PlayerId, new PayCostCommand(payment.PaymentId, payment.PaymentWindow, ["DECLINE"]));
            else if (state.TriggerQueue.Count > 0) await Act(state.TriggerQueue[0].ControllerId, new OrderTriggersCommand(OrderedTriggerIds: state.TriggerQueue.Select(t => t.TriggerId).ToArray()));
            else if (state.PriorityPlayerId is { } priority) await Act(priority, new PassPriorityCommand());
            else if (state.FocusPlayerId is { } focus) await Act(focus, new PassFocusCommand());
            else return;
        }
        throw new Exception("Unexpected unclosed original pending window.");
    }
    async Task Act(string actor, GameCommand command)
    {
        var raw = JsonSerializer.SerializeToNode(command, command.GetType(), Journal.Options)!.AsObject();
        raw["promptId"] = session.PromptFor(actor).PromptId; raw["snapshotTick"] = state.Tick;
        var intent = "ordinary-original-" + journal.Entries.Count;
        var expected = afterCold ? await engine.ResolveAsync(state, new(intent, actor, command.CmdType), command, default) : null;
        var encoded = JsonSerializer.SerializeToElement(raw);
        var result = command switch { SubmitDeckCommand deck => await session.SubmitDeckAsync(actor, intent, deck, encoded, default),
            ReadyCommand => await session.ReadyAsync(actor, intent, encoded, default), _ => await session.SubmitAsync(actor, intent, command, encoded, default) };
        Require(result.Accepted, result.ErrorMessage ?? "Original command rejected.");
        if (afterCold) { Require(expected!.Accepted && MatchStateHasher.Hash(expected.State) == MatchStateHasher.Hash(result.State)
            && JsonNode.DeepEquals(JsonSerializer.SerializeToNode(expected.Events), JsonSerializer.SerializeToNode(result.Events)), "Original next command mismatch."); nextChecks++; }
        state = result.State; afterCold = false;
    }
    MatchRecoveryFrame Frame()
    {
        var commands = journal.Commands(); var events = journal.Events(); var seq = journal.Entries.Last().CompletedEventSequence;
        var snapshots = ResolutionResult.BuildSnapshots(state); var prompts = ResolutionResult.BuildPrompts(state);
        var views = initial.Seats.Keys.ToDictionary(id => id, id => new RecoveredPlayerView(id, state.Tick, seq, snapshots[id], state.Tick, seq, prompts[id]));
        var spectator = MatchReplayRedactor.BuildSpectatorFrame(initial.RoomId, state.Tick, seq, [], state);
        var errors = MatchRecoveryValidator.Validate(initial.RoomId, seq, commands, events, views, state, state.Tick, spectator);
        Require(errors.Count == 0, string.Join(";", errors));
        return new(initial.RoomId, state.Tick, seq, commands, events, views, errors, state, initial, spectator);
    }
    async Task Cold()
    {
        var frame = JsonSerializer.Deserialize<MatchRecoveryFrame>(JsonSerializer.Serialize(Frame(), Journal.Options), Journal.Options)!;
        var errors = await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame, engine, default); Require(errors.Count == 0, string.Join(";", errors));
        var previous = session; session = MatchSession.Restore(frame, engine, journal, NoopMatchPlayerStore.Instance, options);
        foreach (var actor in initial.Seats.Keys)
        {
            Require(JsonNode.DeepEquals(JsonSerializer.SerializeToNode(previous.SnapshotFor(actor)), JsonSerializer.SerializeToNode(session.SnapshotFor(actor))), "Private snapshot mismatch.");
            Require(JsonNode.DeepEquals(JsonSerializer.SerializeToNode(previous.PromptFor(actor)), JsonSerializer.SerializeToNode(session.PromptFor(actor))), "Private prompt mismatch.");
        }
        cold++; afterCold = true;
    }
}
Console.WriteLine(JsonSerializer.Serialize(new { status = "ORDINARY_NEW_BLANK_SEED0_LEGAL_DECK_PHOENIX_COUNTEREXAMPLES_ONLY",
    actualRuleInputs = RuleInputIdentity.Current, noOriginalAcceptedHistoryOrSeedChanged = true,
    noGodotMainProjectBuildOrDatabaseAccess = true, cases = summaries }, Journal.Options));
static void Require(bool condition, string message) { if (!condition) throw new Exception(message); }
static async Task Save(string path, object value) { await using var file = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None); await using var zip = new GZipStream(file, CompressionLevel.SmallestSize); await JsonSerializer.SerializeAsync(zip, value, Journal.Options); }
sealed class Journal : IMatchJournal
{
    public static readonly JsonSerializerOptions Options = new(JsonSerializerDefaults.Web) { WriteIndented = true };
    public List<MatchJournalEntry> Entries { get; } = [];
    public ValueTask RecordAsync(MatchJournalEntry entry, CancellationToken token) { Entries.Add(entry); return ValueTask.CompletedTask; }
    public RecoveredCommand[] Commands() => Entries.Select(e => new RecoveredCommand(e.PlayerId, e.ClientIntentId, e.CommandType, e.RawCommand,
        e.StartedTick, e.CompletedTick, e.StartedEventSequence, e.CompletedEventSequence, e.Accepted, e.ErrorMessage) { RuleInputs = e.RuleInputs }).ToArray();
    public RecoveredEvent[] Events() => Entries.SelectMany(e => e.Events.Select((ev, i) => new RecoveredEvent(e.StartedEventSequence + i + 1, e.CompletedTick, i, ev))).ToArray();
}
