using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using Riftbound.CardCatalog;
using Riftbound.Contracts;
using Riftbound.Engine;

if (args.Length != 1) throw new Exception("Original intake root required.");
var root = Path.GetFullPath(args[0]);
var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
var checks = new List<object>();
var catalog = await OfficialCardCatalog.LoadDefaultAsync();
foreach (var format in new[] { OfficialDeckFormat.CoreRules, OfficialDeckFormat.ChinaStandard20260724 })
foreach (var branch in new[] { "self-destroy", "decree" })
{
    var path = Path.Combine(root, "ordinary-originals-v3", format + "-" + branch + "-original-frame.json.gz");
    var hashBefore = Sha(path);
    var original = await Read(path);
    var frame = original.Deserialize<MatchRecoveryFrame>(json)!;
    Require(JsonNode.DeepEquals(original, JsonSerializer.SerializeToNode(frame, json)), "A declared field, null or original collection changed in typed roundtrip.");
    Require(frame.ValidationErrors.Count == 0 && frame.ReplayInitialState is { Seed: 0, Tick: 0 } initial
        && initial.CardObjects.Count == 0 && initial.RuleInputs == RuleInputIdentity.Current,
        "Actual original blank match or input identity differs.");
    var state = frame.AuthoritativeState!;
    Require(state.RuleInputs == RuleInputIdentity.Current && frame.Commands.All(c => c.Accepted), "Unexpected accepted-history or implementation identity.");
    Require(frame.Commands.Count == (branch == "self-destroy" ? 85 : 111) && frame.Events.Count == (branch == "self-destroy" ? 393 : 471), "Actual original prefix counts differ.");
    foreach (var actor in new[] { "P1", "P2" })
    {
        var submitted = frame.Commands.Single(c => c.PlayerId == actor && c.CommandType == "SUBMIT_DECK");
        var deck = (SubmitDeckCommand)GameCommandJsonMapper.Map(submitted.RawCommand!.Value);
        Require(OfficialDeckValidator.Validate(new(deck.LegendCardNo, deck.ChampionCardNo, deck.MainDeck, deck.RuneDeck, deck.Battlefields), catalog, format).IsValid,
            "Original submitted deck was not legal in its named engine format.");
        var other = actor == "P1" ? "P2" : "P1";
        var visible = JsonSerializer.Serialize(frame.PlayerViews[actor].Snapshot, json);
        foreach (var hidden in state.PlayerZones[other].Hand.Concat(state.PlayerZones[other].MainDeck))
            Require(!visible.Contains(JsonSerializer.Serialize(hidden)), "Opponent private current hand/deck identity leaked.");
    }
    var phoenix = state.PlayerZones["P1"].Graveyard.Single(id => state.CardObjects[id].CardNo == "OGN·037/298");
    Require(state.CardObjects[phoenix].ObjectGeneration > 0, "Phoenix was injected directly into graveyard.");
    var phoenixPlayed = frame.Commands.Single(c => c.CommandType == "PLAY_CARD" && c.RawCommand!.Value.GetProperty("sourceObjectId").GetString() == phoenix);
    Require(phoenixPlayed.PlayerId == "P1", "Actual Phoenix owner did not ordinarily play it.");
    Require(frame.Events.Any(e => e.Event.Kind == "UNIT_DESTROYED" && Text(e.Event, "targetObjectId") == phoenix), "Original self-destruction event absent.");
    Require(!frame.Events.Any(e => e.Event.Kind == "TRIGGER_QUEUED" && Text(e.Event, "sourceObjectId") == phoenix), "Original missing-trigger counterexample no longer matches.");
    Require(state.StackItems.All(s => s.SourceObjectId != phoenix) && state.TriggerQueue.All(t => t.SourceObjectId != phoenix), "Phoenix trigger already exists in original final state.");
    if (branch == "decree")
    {
        var elder = state.PlayerZones["P2"].Graveyard.Single(id => state.CardObjects[id].CardNo == "UNL-118/219");
        var ray = frame.Commands.Last(c => c.CommandType == "PLAY_CARD");
        Require(ray.PlayerId == "P1" && ray.RawCommand!.Value.GetProperty("cardNo").GetString() == "OGN·009/298"
            && ray.RawCommand.Value.GetProperty("targetObjectIds").EnumerateArray().Single().GetString() == elder,
            "Original final action is not Ray on actual Elder.");
        var damages = frame.Events.Where(e => e.Sequence > ray.StartedEventSequence && e.Event.Kind == "DAMAGE_APPLIED").ToArray();
        Require(damages.Length == 1 && Text(damages[0].Event, "targetObjectId") == elder
            && Text(damages[0].Event, "damage") == "3", "Actual original nonlethal3 damage differs.");
        Require(state.PlayerScores["P1"] == 1 && state.PlayerScores["P2"] == 1 && state.Status == MatchStatuses.InProgress,
            "A prefix was incorrectly promoted to complete game or score acceptance.");
    }
    var replay = await MatchActionLogReplayer.VerifyFinalStateAsync(frame.ReplayInitialState!, frame.Commands, state, new CoreRuleEngine(), default, frame.Events);
    Require(replay.IsMatch, string.Join(";", replay.Errors));
    var errors = await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame, new CoreRuleEngine(), default);
    Require(errors.Count == 0, string.Join(";", errors));
    Require(Sha(path) == hashBefore, "Original frame was rewritten.");
    checks.Add(new { format = format.ToString(), branch, commands = frame.Commands.Count, events = frame.Events.Count,
        allDeclaredFieldsAndNullsExact = true, actualBothSubmittedDecksRevalidated = true,
        currentOpponentPrivateHandAndDeckIdsProtected = true, originalFullReplayAndRecoveryPassed = true,
        semanticMissingTriggerNotPromotedToPassingBehavior = true, originalFrameSha256 = hashBefore });
}
var failedPath = Path.Combine(root, "ordinary-originals-v2", "CoreRules-failed-original-prefix.json.gz");
var failed = await Read(failedPath);
var failedInitial = failed["initial"]!.Deserialize<MatchState>(json)!;
var failedState = failed["state"]!.Deserialize<MatchState>(json)!;
var entries = failed["entries"]!.Deserialize<List<MatchJournalEntry>>(json)!;
Require(entries.Count == 6 && entries.Count(e => e.Accepted) == 5 && !entries[^1].Accepted
    && entries[^1].CompletedTick == entries[^1].StartedTick && entries[^1].StartedEventSequence == entries[^1].CompletedEventSequence,
    "Original rejected second-mulligan prefix is not atomic.");
var commands = entries.Select(e => new RecoveredCommand(e.PlayerId, e.ClientIntentId, e.CommandType, e.RawCommand,
    e.StartedTick, e.CompletedTick, e.StartedEventSequence, e.CompletedEventSequence, e.Accepted, e.ErrorMessage) { RuleInputs = e.RuleInputs }).ToArray();
var events = entries.SelectMany(e => e.Events.Select((ev, i) => new RecoveredEvent(e.StartedEventSequence + i + 1, e.CompletedTick, i, ev))).ToArray();
var failedReplay = await MatchActionLogReplayer.VerifyFinalStateAsync(failedInitial, commands, failedState, new CoreRuleEngine(), default, events);
Require(failedReplay.IsMatch, string.Join(";", failedReplay.Errors));
Console.WriteLine(JsonSerializer.Serialize(new { status = "PASS_INDEPENDENT_FOUR_ORIGINAL_PHOENIX_PREFIXES_AND_ORIGINAL_REJECTED_MULLIGAN",
    actualRuleInputs = RuleInputIdentity.Current, checks, failedPrefix = new { commands = commands.Length, accepted = 5,
        rejected = 1, originalReplayPassed = true, rejectedAtomic = true, originalSha256 = Sha(failedPath) },
    actualOrdinaryDistinctGames = 2, distinctOriginalCommands = 222, distinctOriginalEvents = 942,
    noOriginalHistoryOrSeedOrPrivateViewRewrite = true, productAndWholeCardCertification = "OPEN" }, json));
static string Text(GameEvent ev, string key) => ev.Payload.TryGetValue(key, out var value) ? value?.ToString() ?? "" : "";
static void Require(bool condition, string message) { if (!condition) throw new Exception(message); }
static string Sha(string path) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path))).ToLowerInvariant();
static async Task<JsonNode> Read(string path) { await using var file = File.OpenRead(path); await using var zip = new GZipStream(file, CompressionMode.Decompress); return (await JsonNode.ParseAsync(zip))!; }
