import datetime
import gzip
import hashlib
import importlib.util
import json
import pathlib
import subprocess

root = pathlib.Path.cwd()
work = root / 'var/qa/destruction-graveyard-implementation-20261020'
evidence = root / 'docs/evidence/destruction-graveyard-2026-10-20'
identity = 'destruction-attribution-delayed-skill-graveyard-play-2026-10-20'
base = '08fd25c0dc643f9120b529f039feed69beffc251'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())

def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def pin(path, role=None):
    return {'path': str(path.relative_to(root)), 'sha256': sha(path), 'role': role or path.stem}

assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == base
assert evidence.exists() and not (work / 'canonical-publication-v1.json').exists()
publisher = work / 'publish-audit-v1.py'
archived_publisher = evidence / 'n19/publish-audit-v1.py.gz'
assert gzip.decompress(archived_publisher.read_bytes()) == publisher.read_bytes()
source = publisher.read_text()
sql = load(work / 'real-sql-verification-v2.json')
check = load(work / 'only-check-retention-and-disposition-v1.json')
assert sql['status'] == 'PASS_REAL_SQL_SIX_ORIGINALS_PARTITION_DISPATCH_AND_INDEPENDENT_READONLY_FULL_REPLAY'
assert sql['ownPostgresSmartStopped'] and sql['allFrozenRuntimeAndHarnessInputsStillExact']
assert check['failed'] == 3 and check['noSecondCheck']
prior = json.loads(gzip.decompress((work / 'pre-destruction-original-current-manifest.json.gz').read_bytes()))
original_reviews = json.loads(gzip.decompress((work / 'pre-destruction-original-review-decisions.json.gz').read_bytes()))
manifest = load(root / 'docs/audit/current-manifest.json')
reviews = load(root / 'docs/evidence/rules-reaudit-2026-10-11/review-decisions.json')
assert len(prior['reviewContexts']) == 56 and len(manifest['reviewContexts']) == 57
assert reviews['reviews'][:-1] == original_reviews['reviews']
assert manifest['acceptanceGates'][:-2] == prior['acceptanceGates']
assert manifest['laterSourceDeltas'] == prior['laterSourceDeltas']
old_ids = set(json.loads(gzip.decompress((root / 'docs/evidence/hwei-move-discard-types-2026-10-20/remaining-obligation-ids.json.gz').read_bytes())))
parents = load(work / 'coherent-batch-progress-and-obligation-checkpoint-v1.json')['existing22ParentObligationIds']
spec = importlib.util.spec_from_file_location('governance', root / 'scripts/audit/check-project-governance.py')
checker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checker)
revision = checker.digest(checker.gameplay_inputs(root))
assert manifest['reviewContexts'][identity]['currentInputRevision'] == revision
rebindings = []
for key, old in prior['reviewContexts'].items():
    current = manifest['reviewContexts'][key]
    update = current['implementationPinUpdates'][-1]
    assert update['batch'] == identity
    rebindings.append({'review': key, 'previousContextSha256': checker.digest(old), 'pinChanges': update['changes']})
archives = []
for folder, prefix in [(root / 'var/qa/hwei-fixed-08fd-20261020', 'n17'),
                       (root / 'var/qa/phoenix-destroy-source-20261020', 'n18'),
                       (work, 'n19'), (root / 'var/qa/sql-ci-partition-20261020', 'ci'),
                       (root / 'var/qa/global-gallery-gap-20261020', 'global-source-followup')]:
    for target in sorted((evidence / prefix).rglob('*')):
        if not target.is_file():
            continue
        relative = target.relative_to(evidence / prefix)
        original = folder / relative
        compressed = not original.is_file()
        if compressed:
            assert original.suffix == '.gz'
            original = original.with_name(original.name[:-3])
        assert original.is_file()
        assert (gzip.decompress(target.read_bytes()) if compressed else target.read_bytes()) == original.read_bytes()
        archives.append({'originalPath': str(original.relative_to(root)), 'originalBytes': original.stat().st_size,
                         'originalSha256': sha(original), 'canonical': pin(target), 'gzipOriginalBytes': compressed,
                         'samePhysicalFileHardlinked': not compressed and original.stat().st_ino == target.stat().st_ino})
assert len(archives) + 1 == sum(p.is_file() for p in evidence.rglob('*'))
check_text = (f"{check['cases']}例/{check['methods']}方法，{check['passed']}通过、3失败、零跳过；"
    "修复空列表恢复校验异常、独立隐私断言的异常契约，并仅校准有精确来源支撑的四处目录统计常量后，"
    "当前78例/34方法、两条原完整对局和六场新SQL原局通过。原失败保留，不改写为check全绿，没有第二次check")
# First attempt checked a referenced audit document before writing that document.
# Complete the exact already-reviewed rendering first, without reappending records.
before = checker.current_audit(root, manifest)
assert before['errors'] == ['Missing or escaped review evidence: docs/DESTRUCTION_GRAVEYARD_AUDIT_2026-10-20.md']
new_ids = old_ids | {row['id'] for row in before['remainingObligations']}
doc_start = source.index("doc = (work / 'DESTRUCTION_GRAVEYARD_AUDIT_2026-10-20.md').read_text()")
doc_end = source.index("status_path = root / 'docs/PROJECT_STATUS.md'")
exec(compile(source[doc_start:doc_end], str(publisher) + ':exact-document-render', 'exec'), globals())
tail = source.index('result = checker.current_audit(root, manifest)')
exec(compile(source[tail:], str(publisher) + ':resume-after-preserved-first-failure', 'exec'), globals())
assert result['governanceValid'] and len(new_ids) == 16903
receipt = {'status': 'PUBLICATION_ORDER_FAILURE_CLOSED_WITHOUT_REAPPENDING_OR_REWRITING_EVIDENCE',
           'originalPublisherSha256': sha(publisher), 'originalFailedPhase': 'Audit-document reference checked before document rendering',
           'originalError': before['errors'], 'all549OriginalArchiveFilesReverified': len(archives) == 549,
           'archiveFileCount': len(archives), 'allOriginalReviewAndGateAndDeltaDictionariesRetained': True,
           'noGameplayOrTestSourceMutation': True, 'noSecondCheck': True, 'governanceValid': True,
           'remainingObligations': len(new_ids), 'finishedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
write(pathlib.Path(__file__).parent / 'publication-order-failure-closure-v2.json', receipt)
recovery_dir = evidence / 'publication-recovery'
recovery_dir.mkdir()
for original in [pathlib.Path(__file__), pathlib.Path(__file__).parent / 'publication-order-failure-closure-v2.json']:
    target = recovery_dir / (original.name + '.gz')
    target.write_bytes(gzip.compress(original.read_bytes(), mtime=0))
print(json.dumps(receipt, ensure_ascii=False), flush=True)
