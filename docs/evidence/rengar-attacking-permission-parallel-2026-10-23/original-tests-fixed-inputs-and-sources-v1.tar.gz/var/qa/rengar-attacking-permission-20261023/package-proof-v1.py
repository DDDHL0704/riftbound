from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,tarfile,io,subprocess,xml.etree.ElementTree as E
R=Path.cwd();Q=R/'var/qa/rengar-attacking-permission-20261023';D=R/'docs/evidence/rengar-attacking-permission-parallel-2026-10-23';D.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def trx(path):
 r=E.parse(path);defs={d.get('id'):d.find('t:TestMethod',ns).attrib for d in r.findall('.//t:UnitTest',ns)}
 return {'sha256':sha(path.read_bytes()),'counters':r.find('.//t:Counters',ns).attrib,'cases':[{'name':x.get('testName'),'method':defs[x.get('testId')]['className']+'.'+defs[x.get('testId')]['name'],'outcome':x.get('outcome'),'failure':x.find('.//t:Message',ns).text if x.find('.//t:Message',ns)is not None else None}for x in r.findall('.//t:UnitTestResult',ns)]}
runs={k:trx(Q/k/'focus/results.trx')for k in ['focus-v1','adjacent-v1']}
for k,total,passed,failed in [('focus-v1',11,4,7),('adjacent-v1',70,70,0)]:
 c=runs[k]['counters'];assert c['total']==str(total)and c['passed']==str(passed)and c['failed']==str(failed)and c['notExecuted']=='0'
receiptPath=R/'var/qa/battle-win-combined-20261023/applied-peer-fixed-n52-first45-v1.json';receipt=json.load(receiptPath.open());peer=Path(receipt['overlaySource']);assert sha(peer.read_bytes())==receipt['overlaySha256']
for f in receipt['files']:assert sha((R/f['path']).read_bytes())==f['afterSha256']
proof=[];ruleInputs=[]
for folder in ['original-v1','original-late-v1']:
 for p in sorted((Q/folder).glob('*.json.gz')):
  a=json.loads(gzip.decompress(p.read_bytes()));assert a['originalPrefixReplayCount']==len(a['commands'])==len(a['entries'])==len(a['states']);assert a['initial']['seed']==424242
  events=[e for entry in a['entries']for e in entry['events']];assert events==[e['event']for e in a['events']]
  for i,c in enumerate(a['commands']):
   if c['ruleInputs']not in ruleInputs:ruleInputs.append(c['ruleInputs'])
   if not c['accepted']:assert a['states'][i]==a['states'][i-1]
  if a.get('scenario')=='result-source-returned':assert 'SOURCE'in a['states'][-1]['playerZones']['P1']['hand'] and not any(c['controllerId']=='P1'and c['isAttacking']for c in a['states'][-1]['cardObjects'].values())and a['states'][-1]['pendingBattleResult']['attackingPlayerId']=='P1'
  proof.append({'caseId':a['caseId'],'scenario':a.get('scenario','original-late-attacker'),'commands':len(a['commands']),'accepted':sum(c['accepted']for c in a['commands']),'events':len(events),'originalPrefixReplays':a['originalPrefixReplayCount'],'sha256':sha(p.read_bytes()),'failure':a['failure']})
assert len(proof)==11 and sum(x['commands']for x in proof)==57 and sum(x['accepted']for x in proof)==48 and sum(x['events']for x in proof)==171 and len(ruleInputs)==1
assembly=R/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0/Riftbound.ConformanceTests.dll'
for run in runs:assert json.load((Q/run/'plan.json').open())['testAssemblySha256']==sha(assembly.read_bytes())
for p in Q.rglob('current-*-original-v1.json.gz'):
 a=json.loads(gzip.decompress(p.read_bytes()));assert sha(a['originalUtf8'].encode())==a['rawSha256']
source='tests/Riftbound.ConformanceTests/RengarAttackingBattlefieldPermissionTests.cs';consumer='src/Riftbound.Engine/CoreRuleEngine.RengarAttackingPermission.cs'
assert (Q/'focus-v1/test-source.cs').read_bytes()==(R/source).read_bytes()and(Q/'focus-v1/consumer-source.cs').read_bytes()==(R/consumer).read_bytes()
extra=[source,consumer,'tests/Riftbound.ConformanceTests/BattleWinLateParticipantTests.cs','docs/RENGAR_ATTACKING_PERMISSION_PARALLEL_2026-10-23.md','var/qa/draven-battle-win-score-20261023/current-core304-http-original-v1.json']
paths=[(str(p.relative_to(R)),p)for p in Q.rglob('*')if p.is_file()]+[(x,R/x)for x in extra]+[('inputs/peer-fixed-n52-first45-v1.tar.gz',peer),('inputs/applied-peer-fixed-n52-first45-v1.json',receiptPath)]
archive=D/'original-tests-fixed-inputs-and-sources-v1.tar.gz';members=[]
with archive.open('xb')as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as tar:
   for name,p in sorted(paths):
    data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data));members.append({'path':name,'bytes':len(data),'sha256':sha(data)})
with tarfile.open(archive,'r:gz')as tar:
 for m in members:
  data=tar.extractfile(m['path']).read();assert len(data)==m['bytes']and sha(data)==m['sha256']
manifest={'status':'SOURCE_RED_SFD_RENGAR_ATTACKING_DESTINATION_PERMISSION_UNWIRED','atUtc':datetime.now(timezone.utc).isoformat(),'baseCommit':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'region':'CN','language':'zh-CN','coreEffectiveDate':'2026-10-16','peerOverlay':receipt,'all19SharedInputsUnchanged':True,'actualRuleInputs':ruleInputs[0],'testAssemblySha256':sha(assembly.read_bytes()),'source':{'path':source,'sha256':sha((R/source).read_bytes())},'consumer':{'path':consumer,'sha256':sha((R/consumer).read_bytes()),'sharedCallSites':0},'originalRuns':runs,'finalOriginalHistories':proof,'cases':11,'methods':2,'passed':4,'sourceFailures':7,'originalCommands':57,'accepted':48,'rejected':9,'originalPrefixReplays':57,'originalEvents':171,'adjacentPassed':70,'adjacentMethods':21,'seed':424242,'freshCompleteSourceRows':json.load((Q/'sources-v1/extra-rows.json').open()),'priorLateAttackerFailurePreserved':'docs/evidence/battle-win-late-participant-parallel-2026-10-23/source-and-red-test-manifest.json','testHelperDependencyCommit':'1fe687a1070fe4fd42f18bd4a0f8f000566dd0b6','scope':'Hand-play location permissions only; no effect-play certification or post-entry role cleanup pass claimed.','noExtraCheckOrFull':True,'noDatabaseExecution':True,'fullGameAcceptanceDeferredUntilIntegration':True,'allEarlierSourcesTestsSeedsAndFailuresPreserved':True,'backendGoalComplete':False,'sharedIntegrationOwner':'01a16770-8c1b-7da2-872b-a8ec5ae77413','parallelThread':'01a16771-220b-7e83-91c6-44acf6dfe4b0','archive':{'path':str(archive.relative_to(R)),'sha256':sha(archive.read_bytes()),'members':members}}
with(D/'source-and-red-test-manifest.json').open('x')as f:json.dump(manifest,f,ensure_ascii=False,indent=2)
print(manifest['status'],len(members),'members',archive.stat().st_size,'bytes;11 cases4pass7fail;57prefixes;70 adjacentpass')
