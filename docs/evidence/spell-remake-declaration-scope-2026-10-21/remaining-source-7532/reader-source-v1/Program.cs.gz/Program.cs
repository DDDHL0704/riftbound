using System.Text.Json;
using System.Text.Json.Nodes;
using Riftbound.Contracts;
using Riftbound.Engine;

if (args.Length!=2 || File.Exists(args[1])) throw new Exception("Exact original diagnostic directory and unused output required.");
var json=new JsonSerializerOptions(JsonSerializerDefaults.Web){WriteIndented=true};
var records=new List<object>();var commands=0;var events=0;var frames=0;
foreach (var label in new[]{"reversal","mirror"})
{
    var folder=Path.Combine(args[0],label);
    var initial=Read("explicit-derived-initial");
    Check(initial.RoomId=="no-complete-remake-"+label && initial.RuleInputs==RuleInputIdentity.Current,"Exact new diagnostic initial/current runtime identity required.");
    Check(initial.PlayerZones["P2"].Base.Count==0 && !initial.CardObjects.Values.Any(c=>c.ControllerId=="P2" && c.Tags.Contains(CardObjectTags.UnitCard)),"No friendly unit for the new controller.");
    var candidates=CardBehaviorRegistry.GetAll().Where(c=>c.CardNo=="OGN·046/298").ToArray();
    Check(candidates.Length==1 && candidates[0].RequiredTargetCount==1 && !candidates[0].AnyNumberOfTargets && candidates[0].TargetScope==CardTargetScopes.FriendlyUnit,"Single mandatory friendly unit; no alternative mode or zero-target permission.");
    var before=Read("before-original-unfinishable-choice");var draft=Read("after-original-partial-edit");
    Check(before.PendingRuleChoice?.Request is {Kind:"SPELL_CHOICE_REMAKE",PlayerId:"P2"},"Original newly controlled choice exists.");
    Check(!before.PendingRuleChoice!.Request.Options.Any(o=>o.Id=="CONFIRM") && before.PendingRuleChoice.Request.Options.Count==2,"Exactly KEEP and an invalid partial removal, not a legal complete selection.");
    Check(draft.PendingRuleChoice?.Request.Options is {Count:1} options && options.Single().Id=="KEEP_ALL","Partial edit leaves no legal completion.");
    var checkpoints=new[]{initial,before,draft,Read("after-original-keep"),Read("final-original-state")}.ToDictionary(s=>s.Tick);
    var log=JsonNode.Parse(await File.ReadAllTextAsync(Path.Combine(folder,"accepted-original-command-event-and-state-hashes.json")))!.AsArray();
    var engine=new CoreRuleEngine();var state=initial;var seen=new HashSet<long>{initial.Tick};
    foreach(var row in log)
    {
        Check(MatchStateHasher.Hash(state)==row!["beforeStateHash"]!.GetValue<string>(),"Original pre-command state hash.");
        var raw=row["command"]!.ToJsonString();
        GameCommand command=row["commandType"]!.GetValue<string>() switch {
            "PLAY_CARD"=>JsonSerializer.Deserialize<PlayCardCommand>(raw,json)!,
            "PASS_PRIORITY"=>JsonSerializer.Deserialize<PassPriorityCommand>(raw,json)!,
            "PAY_COST"=>JsonSerializer.Deserialize<PayCostCommand>(raw,json)!,
            _=>throw new Exception("Unknown original command kind")};
        var result=await engine.ResolveAsync(state,new(row["intent"]!.GetValue<string>(),row["actor"]!.GetValue<string>(),command.CmdType),command,default);
        Check(result.Accepted && MatchStateHasher.Hash(result.State)==row["afterStateHash"]!.GetValue<string>(),"Original accepted post-command state hash.");
        Check(JsonNode.DeepEquals(row["events"],JsonSerializer.SerializeToNode(result.Events,json)),"Every complete original event payload and null field.");
        state=result.State;commands++;events+=result.Events.Count;
        if(checkpoints.TryGetValue(state.Tick,out var expected))
        {Check(JsonNode.DeepEquals(JsonSerializer.SerializeToNode(expected,json),JsonSerializer.SerializeToNode(state,json)),"Every full original checkpoint field/null.");seen.Add(state.Tick);}
    }
    Check(seen.Count==5 && state.StackItems.Count==0 && state.CardObjects["UNIT-1"].Power==9 && state.PlayerZones["P1"].Graveyard.Contains("SPELL"),"All original phases/final physical owner and unaffected invalid target.");
    records.Add(new{control=label,commands=log.Count,originalCheckpoints=seen.Count,originalEventsAndCompleteStateFieldsExact=true,proofNoLegalFriendlyUnitCompleteRemake=true});
    MatchState Read(string name)
    {
        var raw=File.ReadAllText(Path.Combine(folder,name+".json"));var value=JsonSerializer.Deserialize<MatchState>(raw,json)!;
        Check(JsonNode.DeepEquals(JsonNode.Parse(raw),JsonSerializer.SerializeToNode(value,json)),"Original checkpoint raw key/null roundtrip.");frames++;return value;
    }
}
await File.WriteAllTextAsync(args[1],JsonSerializer.Serialize(new{
    status="PASS_INDEPENDENT_ORIGINAL19_COMMAND_EVENT_STATE_REPLAY_AND_BOUNDED_SOURCE_DEFECT_READBACK_NOT_CORRECT_GAMEPLAY_PASS",
    commands,events,originalCheckpointFiles=frames,records,
    whole753_2OtherCasesRealSqlVisibleProductAndWindows="OPEN",originalDiagnosticOrRootSourceMutated=false
},json));
Console.WriteLine($"INDEPENDENT_ORIGINAL_DIAGNOSTIC_READBACK {commands} commands {events} events {frames} full checkpoints");
static void Check(bool condition,string message){if(!condition)throw new InvalidOperationException(message);}
