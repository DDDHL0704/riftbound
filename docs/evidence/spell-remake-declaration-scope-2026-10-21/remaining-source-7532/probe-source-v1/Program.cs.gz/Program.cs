using System.Text.Json;
using Riftbound.Contracts;
using Riftbound.Engine;

if (args.Length != 2 || Directory.Exists(args[1])) throw new Exception("Exact prior fixture root and unused output directory required.");
var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
Directory.CreateDirectory(args[1]);
var records = new List<object>();
foreach (var mirror in new[] { false, true })
{
    var label = mirror ? "mirror" : "reversal";
    var original = Path.Combine(args[0], "spell-remake-declaration", label + "-zero", "explicit-fixture-initial.json");
    var initial = JsonSerializer.Deserialize<MatchState>(await File.ReadAllTextAsync(original), json)!;
    var cards = initial.CardObjects.ToDictionary(p => p.Key, p => p.Value);
    cards.Remove("UNIT-2");
    cards["SPELL"] = cards["SPELL"] with { CardNo = "OGN·046/298", ManaCost = 1 };
    var locations = initial.ObjectLocations.ToDictionary(p => p.Key, p => p.Value); locations.Remove("UNIT-2");
    initial = initial with { RoomId = "no-complete-remake-" + label,
        CardObjects = cards, ObjectLocations = locations,
        PlayerZones = new Dictionary<string, PlayerZones>(initial.PlayerZones) {
            ["P2"] = initial.PlayerZones["P2"] with { Base = [] } } };
    var folder = Path.Combine(args[1], label); Directory.CreateDirectory(folder);
    await Save("explicit-derived-initial", initial);
    var engine = new CoreRuleEngine(); var state = initial;
    var journal = new List<object>();
    await Act("P1", new PlayCardCommand("SPELL", "OGN·046/298", ["UNIT-1"]));
    var originalTarget = state.StackItems.Single().StackItemId;
    await Act("P1", new PassPriorityCommand());
    await Act("P2", new PlayCardCommand("CONTROL", mirror ? "VEN·152" : "OGN·080/298", [originalTarget]));
    await Top();
    if (mirror)
    {
        Check(state.PendingRuleChoice?.Request.Kind == "OPTIONAL_SPELL_CONTROL_PAYMENT", "Original optional control payment required.");
        await Choose("PAY:ANY");
    }
    var request = state.PendingRuleChoice?.Request ?? throw new Exception("Current source issue no longer reproduced; inspect independently.");
    Check(request.Kind == "SPELL_CHOICE_REMAKE" && request.PlayerId == "P2", "Current actual empty completion window required for diagnostic.");
    Check(!cards.Values.Any(c => c.Tags.Contains(CardObjectTags.UnitCard) && c.ControllerId == "P2"), "Fixture has no unit controlled by the new controller.");
    Check(!request.Options.Any(o => o.Id == "CONFIRM"), "Originally declared friendly target is illegal under the new controller.");
    Check(CardBehaviorRegistry.GetAll().Count(b => b.CardNo == "OGN·046/298") == 1, "No alternative mode can make a legal no-target declaration.");
    await Save("before-original-unfinishable-choice", state);
    var remove = request.Options.Single(o => o.Label.Contains("移除目标 1", StringComparison.Ordinal));
    await Choose(remove.Id);
    var draft = state.PendingRuleChoice!.Request;
    Check(draft.Kind == "SPELL_CHOICE_REMAKE" && !draft.Options.Any(o => o.Id == "CONFIRM"), "Partial removal cannot complete a spell requiring one friendly target.");
    Check(draft.Options.Count == 1 && draft.Options.Single().Id == "KEEP_ALL", "After partial edit the actual window offers only KEEP_ALL, despite no legal complete remake.");
    await Save("after-original-partial-edit", state);
    await Choose("KEEP_ALL");
    Check(state.StackItems.Single().ControllerId == "P2" && state.StackItems.Single().TargetObjectIds.SequenceEqual(new[] { "UNIT-1" }), "KEEP retains the whole original target list, not the partial draft.");
    await Save("after-original-keep", state);
    await Top();
    Check(state.StackItems.Count == 0 && state.PlayerZones["P1"].Graveyard.Contains("SPELL") && state.CardObjects["UNIT-1"].Power == 9, "The retained now-illegal original target is not affected and the physical source completes.");
    await Save("final-original-state", state);
    await File.WriteAllTextAsync(Path.Combine(folder,"accepted-original-command-event-and-state-hashes.json"),JsonSerializer.Serialize(journal,json));
    records.Add(new { control = label, commands = journal.Count, originalFriendlyUnitCountForNewController = 0,
        actualBeforeChoiceOptions = request.Options, actualAfterPartialEditOptions = draft.Options,
        core753_2RequiresNoNewChoiceWindow = true, actualCurrentWindowDespiteNoLegalCompletion = true,
        independentReason = "Only one mandatory friendly unit target, no new-controller unit, no alternative mode or location; deletion is a partial invalid choice.",
        existingKeepOriginalAndFinalizerBehaviorRetained = true, actualRuleInputs = initial.RuleInputs });
    async Task Act(string actor, GameCommand command)
    {
        var intent = label + "-no-complete-" + journal.Count;
        var before = MatchStateHasher.Hash(state);
        var result = await engine.ResolveAsync(state,new(intent,actor,command.CmdType),command,default);
        Check(result.Accepted, result.ErrorMessage ?? "Original diagnostic command rejected.");
        state=result.State;
        journal.Add(new { intent, actor, commandType = command.CmdType,
            command = JsonSerializer.SerializeToElement(command,command.GetType(),json), events = result.Events,
            beforeStateHash = before, afterStateHash = MatchStateHasher.Hash(state) });
    }
    async Task Top() { await Act(state.PriorityPlayerId!,new PassPriorityCommand()); await Act(state.PriorityPlayerId!,new PassPriorityCommand()); }
    async Task Choose(string option) { var r=state.PendingRuleChoice!.Request;await Act(r.PlayerId,new PayCostCommand(r.Id,"RULE_REPLACEMENT",[option])); }
    async Task Save(string name, MatchState value) { await File.WriteAllTextAsync(Path.Combine(folder,name+".json"),JsonSerializer.Serialize(value,json)); }
}
await File.WriteAllTextAsync(Path.Combine(args[1],"diagnostic-result.json"),JsonSerializer.Serialize(new {
    status = "REPRODUCED_CURRENT_TWO_CONTROL_CONSUMERS_PARTIAL_EDIT_WITH_NO_LEGAL_COMPLETE_REMAKE_NOT_RULE_PASS",
    records, currentN27IntrinsicNoDeclarationScopeDoesNotCoverThisBranch = true,
    sourceRootTestsOrAcceptedDatabaseHistoryModified = false, realSqlVisibleOrWholePrintingCertification = false
},json));
Console.WriteLine("REPRODUCED_TWO_CURRENT_CONTROL_CONSUMERS_NO_COMPLETE_LEGAL_REMAKE");
static void Check(bool condition,string message) { if (!condition) throw new InvalidOperationException(message); }
