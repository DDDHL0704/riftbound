import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

root=Path('/Users/dinghaolin/MyProjects/riftbound');work=Path(__file__).resolve().parent;runtime=work/'sql-runtime-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prior=json.loads((root/'var/qa/fixed-reversal-native-locked-20261020/clean-fixed564e433-source-baseline-v1.json').read_text())
paths=set(prior['sourceInputHashes'])|{'tests/Riftbound.ConformanceTests/SpellRemakeDeclarationScopeTests.cs','tests/Riftbound.PostgresAcceptance/SpellRemakeDeclarationSqlAcceptance.cs'}
inputs={p:sha(root/p) for p in sorted(paths)};modes={p:oct((root/p).stat().st_mode&0o777) for p in sorted(paths)}
mutable={(p.stat().st_dev,p.stat().st_ino) for p in [root/p for p in paths]}
for folder in ('src','tests','clients/godot/.godot/mono/temp/bin'):
    for p in (root/folder).rglob('*'):
        if p.is_file() and ('bin' in p.parts or 'obj' in p.parts):mutable.add((p.stat().st_dev,p.stat().st_ino))
known={}
for folder in ('var/qa/fixed-reversal-native-locked-20261020/fixed-api-v1','var/qa/native-spell-choice-presentation-20261020/sql-runtime-v1'):
    for p in (root/folder).rglob('*'):
        if p.is_file() and (p.stat().st_dev,p.stat().st_ino) not in mutable:known.setdefault((p.stat().st_size,sha(p)),p)
shared=[]
for p in runtime.rglob('*'):
    if not p.is_file():continue
    digest=sha(p);candidate=known.get((p.stat().st_size,digest))
    if candidate:
        tmp=p.with_name(p.name+'.immutable-link');os.link(candidate,tmp);os.replace(tmp,p)
        assert sha(p)==digest;shared.append({'path':str(p.relative_to(runtime)),'immutableExistingSource':str(candidate.relative_to(root)),'sha256':digest})
    elif (p.stat().st_dev,p.stat().st_ino) in mutable:
        tmp=p.with_name(p.name+'.independent-copy');tmp.write_bytes(p.read_bytes());os.replace(tmp,p);assert sha(p)==digest
reader=runtime/'ClairvoyanceIndependentFrameReaderV2.dll'
os.link(root/'var/qa/fixed-reversal-native-locked-20261020/read-only-runtime-v1/ClairvoyanceIndependentFrameReaderV2.dll',reader)
files={str(p.relative_to(runtime)):sha(p) for p in sorted(runtime.rglob('*')) if p.is_file()}
assert all((p.stat().st_dev,p.stat().st_ino) not in mutable for p in runtime.rglob('*') if p.is_file())
command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(runtime/'Riftbound.PostgresAcceptance.deps.json'),'--runtimeconfig',str(runtime/'Riftbound.PostgresAcceptance.runtimeconfig.json'),str(reader)]
identity=json.loads(subprocess.check_output(command+['identity-print'],cwd=runtime,text=True))
old_manifest=json.loads((work/'original-before-any-edit/tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json').read_text())
new_manifest=json.loads((root/'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json').read_text())
assert len(old_manifest['cases'])==47 and new_manifest['cases'][:-1]==old_manifest['cases'] and new_manifest['cases'][-1]['id']=='spell-remake-declaration'
result={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'CURRENT_N27_RELEASE_SQL_RUNTIME_AND_SOURCE_FROZEN_NOT_TEST_PASS',
    'baseCommit':prior['fixedCommit'],'includesDeclaredUncommittedChanges':True,'sourceInputHashes':inputs,'sourceInputModes':modes,
    'sourceInputCount':len(inputs),'runtimeFiles':files,'runtimeFileCount':len(files),'actualRuleInputs':identity,
    'identityReaderCommand':command,'immutableSharedIdenticalPayloads':shared,'noFrozenFileSharesMutableRootSourceOrBuildInode':True,
    'old47SqlIdentitiesAndOrderExactPrefixOf48':True,'newSdkCheckoutDatabaseOrNativeInstallersCreated':False}
p=work/'current-release-sql-frozen-publication-v1.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n')
print(result['status'],len(inputs),len(files),'shared',len(shared),json.dumps(identity),flush=True)
