import collections
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

root=Path('/Users/dinghaolin/MyProjects/riftbound');work=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def read_trx(path):
    tree=ET.fromstring(path.read_bytes());ns={'t':tree.tag.split('}')[0][1:]}
    cases=collections.Counter();methods=set();outcomes=collections.Counter()
    for row in tree.findall('.//t:UnitTestResult',ns):cases[row.attrib['testName']]+=1;outcomes[row.attrib['outcome']]+=1
    for row in tree.findall('.//t:UnitTest',ns):
        m=row.find('t:TestMethod',ns);methods.add(m.attrib['className']+'.'+m.attrib['name'])
    return cases,methods,outcomes
owner=load(work/'only-check-owner-terminal-v1.json');start=load(work/'only-check-start-inputs-v1.json')
assert owner['exitCode']==0 and owner['status']=='CHECK_PROCESS_EXIT_ZERO_INDEPENDENT_PARITY_STILL_REQUIRED'
for key in ('all3316SourceHashesUnchanged','allSourceModesUnchanged','allConformanceInputPayloadsUnchanged','all23NativePayloadsUnchanged','boundIdleAssertionEnded'):assert owner[key],key
for field in ('sourceInputHashes','actualConformanceRuntimeFileHashes','actualNativeRuntimeFileHashes'):
    assert all(sha(root/p)==h for p,h in start[field].items()),field
assert all(oct((root/p).stat().st_mode&0o777)==m for p,m in start['sourceInputModes'].items())
summary=load(work/'only-check-v1/summary.json');plan=load(work/'only-check-v1/plan.json')
assert summary['status']=='PASSED' and summary['profile']=='check'
baseline=root/start['originalBaselineTrx'];assert sha(baseline)==start['originalBaselineTrxSha256']
old_cases,old_methods,old_outcomes=read_trx(baseline)
trx=work/'only-check-v1/check/results.trx';cases,methods,outcomes=read_trx(trx)
assert sum(old_cases.values())==13166 and len(old_methods)==7490 and set(old_outcomes)=={'Passed'}
assert all(cases[k]>=n for k,n in old_cases.items()) and old_methods<methods
added=cases-old_cases;added_methods=methods-old_methods
assert sum(cases.values())==summary['total']==13176 and len(methods)==7494 and outcomes=={'Passed':13176}
prefix='Riftbound.ConformanceTests.SpellRemakeDeclarationScopeTests.'
assert sum(added.values())==10 and len(added_methods)==4 and all(n.startswith(prefix) for n in added) and all(m.startswith(prefix) for m in added_methods)
assert all(s['failed']==s['notExecuted']==0 and s['total']==s['passed'] for s in summary['shards'])
baseline_inputs=json.loads(gzip.decompress((work/'prior-fixed564-source-baseline.json.gz').read_bytes()))
assert baseline_inputs['sourceInputCount']==3314 and set(baseline_inputs['sourceInputHashes'])<set(start['sourceInputHashes'])
changed={p for p,h in baseline_inputs['sourceInputHashes'].items() if start['sourceInputHashes'][p]!=h}
expected_changed={'src/Riftbound.Engine/CoreRuleEngine.SpellChoiceControl.cs','src/Riftbound.Engine/CardBehaviorRegistry.cs',
    'tests/Riftbound.ConformanceTests/ReversalTargetChoiceTests.cs','tests/Riftbound.ConformanceTests/ClairvoyanceTests.cs',
    'tests/Riftbound.PostgresAcceptance/ClairvoyanceSqlAcceptance.cs','tests/Riftbound.PostgresAcceptance/Program.cs','tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json','scripts/tests/test_sql_ci_gate.py'}
new=set(start['sourceInputHashes'])-set(baseline_inputs['sourceInputHashes'])
assert changed==expected_changed and new=={'tests/Riftbound.ConformanceTests/SpellRemakeDeclarationScopeTests.cs','tests/Riftbound.PostgresAcceptance/SpellRemakeDeclarationSqlAcceptance.cs'}
assert start['sourceInputModes']=={**baseline_inputs['sourceInputModes'],**{p:start['sourceInputModes'][p] for p in new}}
full_sources={p:h for p,h in baseline_inputs['sourceInputHashes'].items() if Path(p).name.startswith('FullGameEndToEndTests') and p.endswith('.cs')}
assert len(full_sources)==9 and all(sha(root/p)==h for p,h in full_sources.items())
old_sql=json.loads(subprocess.check_output(['git','show',start['baseCommit']+':tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'],cwd=root))
new_sql=load(root/'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json')
assert len(old_sql['cases'])==47 and len(new_sql['cases'])==48 and new_sql['cases'][:47]==old_sql['cases']
for path in ('tests/Riftbound.ConformanceTests/ReversalTargetChoiceTests.cs','tests/Riftbound.ConformanceTests/ClairvoyanceTests.cs'):
    old=subprocess.check_output(['git','show',start['baseCommit']+':'+path],cwd=root).decode()
    current=(root/path).read_text()
    import re
    for pattern in (r'\[InlineData\([^\n]*',r'\[MemberData\([^\n]*',r'\[ClassData\([^\n]*'):
        assert collections.Counter(re.findall(pattern,old))==collections.Counter(re.findall(pattern,current))
result={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'CHECK_AND_EXACT_CASE_METHOD_PARITY_PASS',
    'cases':13176,'methods':7494,'passed':13176,'failed':0,'skipped':0,'seconds':summary['seconds'],
    'oldCasesPreserved':True,'oldMethodsPreserved':True,'originalCases':13166,'originalMethods':7490,
    'addedCaseMultiset':dict(added),'addedMethodNames':sorted(added_methods),'frozenInputsUnchanged':True,
    'all3316SourceHashesAndOctalModesExact':True,'all1419NonOutputConformanceAnd23NativePayloadsExact':True,
    'allOriginal1401InputPathsAnd18AdditionalResourcesFrozen':True,'allNineOriginalFullGameSourcesByteExact':full_sources,
    'all143FullMethods110Pairs11Decks424242AndVictoryReplayAssertionsRetainedNotAllExecutedByCheck':True,
    'allOriginal47SqlRecordsAndOrderExactPrefixOf48':True,'twoPreRunWrapperFailuresDidNotStartOrRepeatCheck':True,
    'exactOneActualCheckRun':True,'trx':str(trx.relative_to(root)),'trxSha256':sha(trx),'actualTestAssemblySha256':plan['testAssemblySha256'],
    'currentNewFixedFullVisiblePairedProductAndPhysicalWindows':'OPEN','wholePrintingOrGlobalCertification':False}
dest=work/'only-check-retention-and-disposition-v1.json';assert not dest.exists();dest.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(result['status'],result['cases'],result['methods'],result['seconds'],flush=True)
