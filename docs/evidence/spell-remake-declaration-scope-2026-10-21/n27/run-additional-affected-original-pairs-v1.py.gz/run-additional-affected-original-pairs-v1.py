import ast
import datetime
import hashlib
import json
import os
from pathlib import Path
import plistlib
import resource
import subprocess

resource.setrlimit(resource.RLIMIT_CORE,(0,0));root=Path('/Users/dinghaolin/MyProjects/riftbound');work=Path(__file__).resolve().parent;runtime=work/'affected-pair-runtime-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
publication=json.loads((work/'affected-pair-frozen-runtime-publication-v1.json').read_text());sql=json.loads((work/'current-release-sql-frozen-publication-v1.json').read_text())
assert all(sha(runtime/p)==h for p,h in publication['runtimeFiles'].items())
files={str(p.relative_to(runtime)):sha(p) for p in runtime.rglob('*') if p.is_file()}
source=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py';definition=next(n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='observe_lock');exec(compile(ast.Module(body=[definition],type_ignores=[]),str(source),'exec'),globals())
record={'status':'RUNNING_ADDITIONAL_AFFECTED20_NOT_FULL110_OR_FULL_CI','startedAtUtc':now(),'runtimeFiles':files,
    'sourceInputHashes':sql['sourceInputHashes'],'originalConformanceAssemblySha256':publication['testAssemblySha256'],
    'baseCommit':sql['baseCommit'],'includesDeclaredUncommittedChanges':True,'expectedReleaseRuleInputs':sql['actualRuleInputs'],
    'lockAtStart':observe_lock(),'purpose':'Earlier affected preconstructed pair helpers; original full110/publicmethod and143methods remain separately required.'}
output=work/'affected-original-pairs-owner-v1.json';assert not output.exists()
def write():
    tmp=output.with_suffix('.tmp');tmp.write_text(json.dumps(record,indent=2)+'\n');tmp.replace(output)
args=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(runtime/'Riftbound.PostgresAcceptance.deps.json'),'--runtimeconfig',str(runtime/'Riftbound.PostgresAcceptance.runtimeconfig.json'),str(runtime/'AffectedOriginalPairHelper.dll'),str(work/'affected-original20-current-release-result-v1.json')]
env=dict(os.environ,DOTNET_DbgEnableMiniDump='0')
for name in list(env):
    if name.startswith('ConnectionStrings__') or name.startswith('RIFTBOUND_') and 'EVIDENCE' in name:env.pop(name)
power=process=None;write()
try:
    power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);record['boundIdleAssertionPid']=power.pid
    with (work/'affected-original20-current-release-v1.log').open('xb') as log:
        process=subprocess.Popen(args,cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT);record['ownedHelperPid']=process.pid;write();code=process.wait(timeout=7200)
    record['exitCode']=code;assert code==0,'Additional original pair helper failure; original output retained'
    result=json.loads((work/'affected-original20-current-release-result-v1.json').read_text());assert result['status']=='PASS_ADDITIONAL20_ORIGINAL_AFFECTED_PAIR_HELPERS_CURRENT_RELEASE_NOT_ALL110_PUBLIC_METHOD_OR_FULL_CI'
    assert len(result['completed'])==20 and result['seed']==424242 and result['originalDeckCount']==11 and result['originalFullMatrixPairCount']==110
    assert result['actualRuleInputs']==sql['actualRuleInputs'];record.update(status=result['status'],completedPairs=20,actualRuleInputs=result['actualRuleInputs'])
except BaseException as e:
    record.update(status='FAILED_OR_INTERRUPTED_ADDITIONAL_AFFECTED_PAIR_HELPERS_NOT_FULL_PASS',errorType=type(e).__name__,error=str(e));raise
finally:
    if process is not None and process.poll() is None:process.terminate();process.wait(timeout=20)
    if power is not None:
        if power.poll() is None:power.terminate();power.wait(timeout=10)
        record['boundIdleAssertionEnded']=power.poll() is not None
    assert files=={str(p.relative_to(runtime)):sha(p) for p in runtime.rglob('*') if p.is_file()}
    assert all(sha(root/p)==h for p,h in sql['sourceInputHashes'].items())
    record.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),allRuntimeAndDeclaredSourceHashesUnchanged=True);write()
print(record['status'],flush=True)
