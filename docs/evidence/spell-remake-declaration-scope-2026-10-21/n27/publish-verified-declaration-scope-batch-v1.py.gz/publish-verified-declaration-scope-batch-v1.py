import copy
import datetime
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import zipfile

root=Path('/Users/dinghaolin/MyProjects/riftbound');work=Path(__file__).resolve().parent
out=root/'docs/evidence/spell-remake-declaration-scope-2026-10-21'
followup=root/'var/qa/spell-remake-no-complete-choice-20261021'
base='564e433d54d47f98b405787eed97cbdd48b7c394'
identity='spell-remake-no-intrinsic-declarations-and-sfd080-zero-targets-2026-10-21'
load=lambda p:json.loads(p.read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
def pin(path,role):return {'path':str(path.relative_to(root)),'sha256':sha(path),'role':role}
assert not out.exists() and subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==base
check=load(work/'only-check-retention-and-disposition-v1.json');start=load(work/'only-check-start-inputs-v1.json')
assert check['status']=='CHECK_AND_EXACT_CASE_METHOD_PARITY_PASS' and check['cases']==13176 and check['methods']==7494
assert check['oldCasesPreserved'] and check['oldMethodsPreserved'] and check['frozenInputsUnchanged'] and check['failed']==check['skipped']==0
assert all(sha(root/p)==h for p,h in start['sourceInputHashes'].items())
assert all(sha(root/p)==h for p,h in start['actualConformanceRuntimeFileHashes'].items())
assert all(sha(root/p)==h for p,h in start['actualNativeRuntimeFileHashes'].items())
manifest_path=root/'docs/audit/current-manifest.json';reviews_path=root/'docs/evidence/rules-reaudit-2026-10-11/review-decisions.json'
assert manifest_path.read_bytes()==gzip.decompress((work/'prior-entire-current-manifest.json.gz').read_bytes())
assert reviews_path.read_bytes()==gzip.decompress((work/'prior-entire-review-decisions.json.gz').read_bytes())
prior=load(manifest_path);prior_reviews=load(reviews_path)
plan=load(work/'publication-plan-governance-and-prior-universe-retention-v2.json');assert plan['governanceValid'] and plan['currentObligations']==16936
assert load(followup/'independent-original-diagnostic-readback-v1.json')['commands']==19

secrets=[]
for folder in (root/'var/qa/fixed-reversal-native-locked-20261020',root/'var/qa/native-signalr-runtime-patch-fixed-43d5b84e-20261020'):
    for p in folder.rglob('session*.json'):
        if any(part in {'bin','obj'} or part.endswith('.app') for part in p.parts):continue
        d=load(p)
        for k in ('playerKey','reconnectToken'):
            if isinstance(d,dict) and isinstance(d.get(k),str) and len(d[k])>=8:secrets.append(d[k].encode())
assert len(secrets)>=4
excluded_dirs={'sql-runtime-v1','affected-pair-runtime-v1','independent-sql-reader-runtime-v1','independent-sql-reader-runtime-v2','probe-runtime-v1','bin','obj','__pycache__'}
exact_prose_drafts={'n27-audit-draft-v1.md','project-status-lead-draft-v1.md'}
text={'.py','.cs','.csproj','.md','.log','.txt','.trx'};raw_types={'.json','.gz','.png','.zip'}
files=[]
for folder,prefix in ((work,'n27'),(followup,'remaining-source-7532')):
    for p in sorted(folder.rglob('*')):
        if not p.is_file():continue
        rel=p.relative_to(folder)
        if p.name in exact_prose_drafts or p.name.startswith('session') or p.name.endswith(('.deps.json','.runtimeconfig.json')):continue
        if any(part in excluded_dirs or part.endswith('.app') for part in rel.parts):continue
        if p.suffix not in text|raw_types:continue
        raw=p.read_bytes()
        if p.suffix=='.gz':blocks=[gzip.decompress(raw)]
        elif p.suffix=='.zip':
            with zipfile.ZipFile(p) as z:assert z.testzip() is None;blocks=[z.read(n) for n in z.namelist() if not n.endswith('/')]
        else:blocks=[raw]
        assert not any(secret in block for secret in secrets for block in blocks),str(p.relative_to(root))
        assert p.suffix in text or len(raw)<10*2**20,str(p.relative_to(root))
        files.append((p,Path(prefix)/rel,raw))
records=[]
for p,rel,raw in files:
    compressed=p.suffix in text;dest=out/rel
    if compressed:dest=dest.with_name(dest.name+'.gz')
    dest.parent.mkdir(parents=True,exist_ok=True)
    if compressed:dest.write_bytes(gzip.compress(raw,mtime=0))
    else:os.link(p,dest)
    assert dest.stat().st_size<10*2**20,str(dest.relative_to(root))
    assert (gzip.decompress(dest.read_bytes()) if compressed else dest.read_bytes())==raw
    records.append({'originalPath':str(p.relative_to(root)),'originalSha256':hashlib.sha256(raw).hexdigest(),'originalBytes':len(raw),
        'canonical':pin(dest,'original-declaration-scope-evidence'),'gzipOriginalBytes':compressed,'samePhysicalFileHardlinked':not compressed})
mapping={r['originalPath']:r['canonical'] for r in records}
write(out/'archive-map.json',{'recordedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':records,
    'allOriginalBytesAndHashesVerified':True,'privateActualAuthValuesScannedWithoutDisclosure':True,'runtimeAppsSdkAndDatabaseNotCopiedOrDeleted':True,
    'draftExclusionIsExactProseListOnly':sorted(exact_prose_drafts),'allRealSqlDraftFramesRetained':True,
    'following7532ControlledOriginal19CommandsAreDiagnosticNotCurrentCorrectGameplayPass':True})
def rebind(value):
    if isinstance(value,list):return [rebind(v) for v in value]
    if not isinstance(value,dict):return value
    if 'path' in value and 'sha256' in value and value['path'] in mapping:
        target=mapping[value['path']];assert sha(root/value['path'])==value['sha256']
        assert not next(r for r in records if r['originalPath']==value['path'])['gzipOriginalBytes']
        return {**{k:rebind(v) for k,v in value.items() if k not in {'path','sha256'}},'path':target['path'],'sha256':target['sha256']}
    return {k:rebind(v) for k,v in value.items()}
def archived(name,role,folder=work):return {**mapping[str((folder/name).relative_to(root))],'role':role}
check_ref=archived('only-check-retention-and-disposition-v1.json','check')
source=rebind(load(work/'planned-source-manifest-v2.json'))
source['recordedAtUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
source['soleCheck']=check_ref
source['actualSoleCheck']={'cases':13176,'methods':7494,'allOriginal13166CaseMultisetAnd7490MethodsRetained':True,'failed':0,'skipped':0,'sourceInputs':3316,'nonOutputConformancePayloads':1419,'nativePayloads':23,'allInputsAndModesStable':True,'exactOneActualRun':True}
source['preciseRemaining7532ActualControlledDiagnostic']=archived('independent-original-diagnostic-readback-v1.json','remaining-source-only-not-rule-pass',followup)
source['actualCurrentZeroTargetPublicPromptAndLockedHeadlessComposer']=archived('zero-target-public-prompt-and-locked-composer-finite-readback-v1.json','native-zero-composer-and-synthetic-quote-freshness-only')
source['actualControlFaceFootersAndApiShortIdentityNotMerged']=archived('current-card-faces/two-control-actual-visual-footer-and-permission-readback-v1.json','exact-control-footer-source-differences')
source['originalTracePathsInsideReceiptsResolveThroughCanonicalArchiveMap']=True
source['archiveMap']=pin(out/'archive-map.json','original-byte-map')
write(out/'source-manifest.json',source);source_ref=pin(out/'source-manifest.json','source-manifest')
check_text='实际13176例/7494方法全部通过，零失败零跳过；原13166例完整多重集合/7490方法保留，新增10例/4方法。3316源码及执行位、1419非输出Conformance输入、23原生载荷全程精确不变；只有一次真实check'
governance_text='149审查/64上下文/245门禁/7来源增量/16936义务；原148审查、63上下文范围与证据、241门禁原值、六增量和16927义务身份全部保留，仅新增三行为分支、四来源门禁、一NEWS身份及一增量'
draft=(work/'n27-audit-draft-v1.md').read_text();document=draft.replace('@CHECK@',check_text).replace('@GOV@',governance_text)
assert '@CHECK@' not in document and '@GOV@' not in document
audit_path=root/'docs/SPELL_REMAKE_DECLARATION_SCOPE_AUDIT_2026-10-21.md';assert not audit_path.exists();audit_path.write_text(document)
reviews=rebind(load(work/'planned-entire-review-decisions-v2.json'))
new=reviews['reviews'][-1];assert new['id']==identity
new.update(sourceManifest=source_ref,auditDocument=str(audit_path.relative_to(root)),status='BOUNDED_CURRENT_SOURCE_FOCUS85_ADJACENT2982_ORIGINAL20_HELPERS_SQL8_OLD_CLAIR5_CHECK13176_NEW_FIXED_FULL_AND_PRODUCT_OPEN')
new.pop('plannedCanonicalAuditDocument',None)
new['validation'].update(soleCheck='ACTUAL_PASS_EXACT_ORIGINAL_RETENTION',checkCases=13176,checkMethods=7494)
new['validation']['actualLockedHeadlessZeroTargetComposerAndOriginalSyntheticQuoteFreshnessOnly']=True
manifest=rebind(load(work/'planned-entire-current-manifest-v2.json'))
context=manifest['reviewContexts'][identity];context['sourceManifest']=source_ref
context['evidence'].append(check_ref)
context['evidence'].append(source['actualCurrentZeroTargetPublicPromptAndLockedHeadlessComposer'])
for branch in context['branches']:
    branch['sourceManifest']=source_ref;branch['testExecution']='ACTUAL_FOCUS85_ADJACENT2982_ORIGINAL20_HELPERS_SQL8_OLD_CLAIR5_CHECK13176'
    branch['decision']['reason']='Bounded current source, execution and sole-check evidence; new fixed complete CI, current product and remaining semantics stay open.'
manifest['currentSpellRemakeDeclarationScopeInputChange']=source_ref
temporary=work/'canonical-reviews-before-root-write-v1.json';write(temporary,reviews)
manifest['inputs']['reviews']=pin(temporary,prior['inputs']['reviews'].get('role','reviews'))
spec=importlib.util.spec_from_file_location('gov',root/'scripts/audit/check-project-governance.py');checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
result=checker.current_audit(root,manifest);assert result['governanceValid'],result['errors']
ids={r['id'] for r in result['remainingObligations']};assert ids==set(load(work/'planned-remaining-obligation-ids-v2.json')) and len(ids)==16936
assert reviews['reviews'][:148]==prior_reviews['reviews'] and manifest['certificationScope']==prior['certificationScope']
assert manifest['acceptanceGates'][:241]==prior['acceptanceGates'] and manifest['laterSourceDeltas'][:6]==prior['laterSourceDeltas']
reviews_path.write_bytes(temporary.read_bytes());manifest['inputs']['reviews']=pin(reviews_path,prior['inputs']['reviews'].get('role','reviews'))
manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
actual=checker.current_audit(root,load(manifest_path));assert actual['governanceValid'] and ids=={r['id'] for r in actual['remainingObligations']}
write(out/'remaining-obligation-ids.json',sorted(ids))
write(out/'unified-obligation-retention.json',{**plan,'status':'ACTUAL_CANONICAL_PUBLICATION_PRIOR_SCOPE_AND_IDENTITY_RETENTION_PASS','allCurrentCheckAndImplementationInputsStillExact':True,'actualSoleCheck':check_ref,'newFixedFullAndVisibleProductAndPhysicalWindows':'OPEN'})
compact={k:v for k,v in actual.items() if k not in {'inputManifest','reviewView','remainingObligations','laterSourceDeltas'}};compact['remainingObligationCount']=len(ids);write(out/'governance-validation.json',compact)
status=root/'docs/PROJECT_STATUS.md';old=status.read_text();marker='# 当前项目状态\n\n';assert old.startswith(marker)
lead=(work/'project-status-lead-draft-v1.md').read_text().replace('@CHECK@',check_text).replace('@GOV@',governance_text)
status.write_text(marker+lead+'\n'+old[len(marker):])
assert all(sha(root/p)==h for p,h in start['sourceInputHashes'].items())
print('PUBLISHED_BOUNDED_DECLARATION_SCOPE_AND_ZERO_TARGETS_PRIOR_ALL_SCOPE_RETAINED',len(records),149,64,245,16936,flush=True)
