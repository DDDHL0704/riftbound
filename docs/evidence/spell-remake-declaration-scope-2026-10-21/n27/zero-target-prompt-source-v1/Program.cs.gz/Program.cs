using System.Text.Json;
using System.Text.Json.Nodes;
using Riftbound.Contracts;
using Riftbound.Engine;

if(args.Length!=2||Directory.Exists(args[1]))throw new Exception("Exact original controlled initial and unused output required.");
var json=new JsonSerializerOptions(JsonSerializerDefaults.Web){WriteIndented=true};
var initial=JsonSerializer.Deserialize<MatchState>(await File.ReadAllTextAsync(args[0]),json)!;
if(initial.RuleInputs!=RuleInputIdentity.Current||initial.CardObjects["SPELL"].CardNo!="SFD·080/221")throw new Exception("Exact current SFD080 zero-target controlled initial required.");
var session=new MatchSession(initial,new CoreRuleEngine(),NoopMatchJournal.Instance);
var prompt=session.PromptFor("P1");var snapshot=session.SnapshotFor("P1");
var raw=JsonSerializer.SerializeToNode(prompt,json)!;
var candidate=raw["candidates"]!.AsArray().Single(c=>c!["action"]!.GetValue<string>()=="PLAY_CARD")!;
var requirements=candidate["metadata"]!["sourceRequirements"]!.AsArray();
var requirement=requirements.Single(r=>r!["sourceObjectId"]!.GetValue<string>()=="SPELL")!;
if(requirement["minTargetCount"]!.GetValue<int>()!=0||requirement["maxTargetCount"]!.GetValue<int>()!=3)throw new Exception("Current server prompt must expose exact zero-to-three.");
Directory.CreateDirectory(args[1]);
await File.WriteAllTextAsync(Path.Combine(args[1],"prompt.json"),JsonSerializer.Serialize(prompt,json));
await File.WriteAllTextAsync(Path.Combine(args[1],"snapshot.json"),JsonSerializer.Serialize(snapshot,json));
await File.WriteAllTextAsync(Path.Combine(args[1],"candidate.json"),candidate.ToJsonString(json));
await File.WriteAllTextAsync(Path.Combine(args[1],"receipt.json"),JsonSerializer.Serialize(new{
 status="ACTUAL_CURRENT_FROZEN_RELEASE_ZERO_TO_THREE_PUBLIC_PROMPT_GENERATED_NO_SQL_OR_NATIVE_EXECUTION_CLAIM",actualRuleInputs=initial.RuleInputs,
 source="SPELL",cardNo="SFD·080/221",minimum=0,maximum=3,
 legalTargetSelections=requirement["legalTargetSelections"],
 exactOriginalControlledInitialRetained=true,realSqlNativeVisibleWindowsOrWholePrintingCertification=false
},json));
Console.WriteLine("ACTUAL_CURRENT_PUBLIC_PROMPT_MIN0_MAX3");
