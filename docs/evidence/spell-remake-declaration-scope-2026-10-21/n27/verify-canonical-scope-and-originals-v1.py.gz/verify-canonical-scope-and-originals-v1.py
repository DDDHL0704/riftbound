import datetime
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path

root=Path('/Users/dinghaolin/MyProjects/riftbound');work=Path(__file__).resolve().parent
out=root/'docs/evidence/spell-remake-declaration-scope-2026-10-21'
load=lambda p:json.loads(p.read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
archive=load(out/'archive-map.json')
assert archive['draftExclusionIsExactProseListOnly']==['n27-audit-draft-v1.md','project-status-lead-draft-v1.md']
for row in archive['records']:
    original=root/row['originalPath'];canonical=root/row['canonical']['path'];data=canonical.read_bytes()
    raw=gzip.decompress(data) if row['gzipOriginalBytes'] else data
    assert original.read_bytes()==raw and len(raw)==row['originalBytes'] and hashlib.sha256(raw).hexdigest()==row['originalSha256'] and sha(canonical)==row['canonical']['sha256']
    if row['samePhysicalFileHardlinked']:assert (original.stat().st_dev,original.stat().st_ino)==(canonical.stat().st_dev,canonical.stat().st_ino)
old=json.loads(gzip.decompress((work/'prior-entire-current-manifest.json.gz').read_bytes()))
old_reviews=json.loads(gzip.decompress((work/'prior-entire-review-decisions.json.gz').read_bytes()))
manifest=load(root/'docs/audit/current-manifest.json');reviews=load(root/'docs/evidence/rules-reaudit-2026-10-11/review-decisions.json')
assert len(reviews['reviews'])==149 and reviews['reviews'][:148]==old_reviews['reviews']
assert len(manifest['reviewContexts'])==64 and len(manifest['acceptanceGates'])==245 and manifest['acceptanceGates'][:241]==old['acceptanceGates']
assert len(manifest['laterSourceDeltas'])==7 and manifest['laterSourceDeltas'][:6]==old['laterSourceDeltas'] and manifest['certificationScope']==old['certificationScope']
identity='spell-remake-no-intrinsic-declarations-and-sfd080-zero-targets-2026-10-21'
allowed={'currentInputRevision','currentImplementationCommit','currentImplementationIncludesUncommittedChanges','ciState','revalidationReason','implementationPinUpdates','implementation','verificationSources'}
for name,previous in old['reviewContexts'].items():
    current=manifest['reviewContexts'][name]
    assert {k:v for k,v in current.items() if k not in allowed}=={k:v for k,v in previous.items() if k not in allowed}
    updates=current['implementationPinUpdates'];assert updates[:-1]==previous.get('implementationPinUpdates',[]) and updates[-1]['batch']==identity
    assert updates[-1]['previousCurrentMetadata']=={f:previous.get(f) for f in ['currentInputRevision','currentImplementationCommit','currentImplementationIncludesUncommittedChanges','ciState']}
    for field in ('implementation','verificationSources'):
        assert len(current.get(field,[]))==len(previous.get(field,[]))
        for a,b in zip(previous.get(field,[]),current.get(field,[])):
            assert {k:v for k,v in a.items() if k!='sha256'}=={k:v for k,v in b.items() if k!='sha256'} and sha(root/b['path'])==b['sha256']
new=manifest['reviewContexts'][identity];assert new['ciState']=='PENDING' and new['ciReceipts']==[] and len(new['branches'])==3 and all(b['decision']['state']=='OPEN' for b in new['branches'])
start=load(work/'only-check-start-inputs-v1.json')
for field in ('sourceInputHashes','actualConformanceRuntimeFileHashes','actualNativeRuntimeFileHashes'):assert all(sha(root/p)==h for p,h in start[field].items())
assert all(oct((root/p).stat().st_mode&0o777)==mode for p,mode in start['sourceInputModes'].items())
source=load(out/'source-manifest.json');assert source['actualSoleCheck']['cases']==13176 and source['actualSoleCheck']['methods']==7494
assert source['expectedFullNotResult']=={'cases':13325,'methods':7635,'sqlExecutionIdentities':48,'fullGameMethods':143,'pairs':110,'decks':11,'seed':424242}
assert source['newFixedCompleteCiAndCurrentVisiblePairedPhysicalWindows']=='OPEN' and source['wholePrintingAndGlobalSemanticCertification'] is False
for ref in source['implementation']+source['verificationSources']:assert sha(root/ref['path'])==ref['sha256']
old_ids=set(load(root/'docs/evidence/native-spell-choice-presentation-2026-10-20/remaining-obligation-ids.json'))
new_ids=set(load(out/'remaining-obligation-ids.json'));assert len(old_ids)==16927 and len(new_ids)==16936 and old_ids<new_ids
assert 'NEWS:CN-NEWS-d7e10972978590af' in new_ids
spec=importlib.util.spec_from_file_location('gov',root/'scripts/audit/check-project-governance.py');checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
result=checker.current_audit(root,manifest);assert result['governanceValid'] and new_ids=={r['id'] for r in result['remainingObligations']}
news=load(root/manifest['officialNewsObligations']['path']);old_news=load(root/old['officialNewsObligations']['path'])
assert news['documents']==old_news['documents'] and news['candidateInventory']==old_news['candidateInventory'] and news['cardSource']==old_news['cardSource']
for path in ('docs/SPELL_REMAKE_DECLARATION_SCOPE_AUDIT_2026-10-21.md','docs/PROJECT_STATUS.md'):
    text=(root/path).read_text();assert '@CHECK@' not in text and '@GOV@' not in text
receipt={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_CANONICAL_ORIGINAL_BYTES_HASHES_INODES_ALL_PRIOR_SCOPE_AND16927_IDS_RETAINED',
    'originals':len(archive['records']),'reviews':149,'contexts':64,'gates':245,'sourceDeltas':7,'obligations':16936,
    'all148OriginalReviews63ContextScopes241Gates6DeltasAnd20NewsDocumentsPreserved':True,'allOriginalObligationIdsRetained':True,
    'soleCheck13176Cases7494MethodsFrozenAll3316Sources1419Conformance23NativeStillExact':True,
    'sourceRound21AndOriginalCertificationScope16Distinct':True,'newFixedFullVisiblePairedAndWindowsStillOpen':True,'wholePrintingAndGlobalCertification':False}
p=out/'final-original-retention-and-publication-verification.json';assert not p.exists();p.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(receipt['status'],len(archive['records']),len(new_ids),flush=True)
