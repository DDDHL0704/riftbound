import ast
import datetime
import fcntl
import gzip
import hashlib
import json
import os
from pathlib import Path
import plistlib
import resource
import subprocess
import time

os.umask(0o077);resource.setrlimit(resource.RLIMIT_CORE,(0,0))
root=Path('/Users/dinghaolin/MyProjects/riftbound');work=Path(__file__).resolve().parent;runtime=work/'sql-runtime-v1'
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts']
read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
source=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py';defs=[n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}]
exec(compile(ast.Module(body=defs,type_ignores=[]),str(source),'exec'),globals())
publication=json.loads((work/'current-release-sql-frozen-publication-v1.json').read_text())
prior=json.loads((root/'var/qa/fixed-reversal-native-locked-20261020/actual-safe-native-main-v1/original213-audit46-native-including67-room-seven-table-baseline-v1.json').read_text())
old_final=json.loads(gzip.decompress((root/'var/qa/fixed-reversal-native-locked-20261020/actual-safe-normal-score-v1/after-safe-normal-score-final-original-frame-v1.json.gz').read_bytes()))
output=work/'actual-eight-and-clairvoyance-owner-v1.json';assert not output.exists()
def write(p,d):
    tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(d,indent=2)+'\n');tmp.replace(p)
def frozen():
    assert all(sha(root/p)==h for p,h in publication['sourceInputHashes'].items())
    assert all(oct((root/p).stat().st_mode&0o777)==m for p,m in publication['sourceInputModes'].items())
    assert all(sha(runtime/p)==h for p,h in publication['runtimeFiles'].items())
    assert json.loads(subprocess.check_output(publication['identityReaderCommand']+['identity-print'],cwd=runtime,text=True))==publication['actualRuleInputs']
frozen();guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof={'status':'RUNNING_NOT_ACCEPTANCE','startedAtUtc':now(),'baseCommit':publication['baseCommit'],
    'includesDeclaredCurrentUncommittedSources':True,'actualRuleInputs':publication['actualRuleInputs'],
    'lockAtStart':observe_lock(),'sourceInputCount':publication['sourceInputCount'],'runtimeFileCount':publication['runtimeFileCount'],
    'scope':'Eight new explicit controlled declaration fixtures plus five retained Clairvoyance branches; no all48/fixedCI/ordinary-opening/native/whole-printing certification.'}
write(output,proof);started=False;power=process=None;audit=native=None
try:
    assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
    power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof.update(ownPid=os.getpid(),boundIdleAssertionPid=power.pid)
    sock.mkdir(exist_ok=True)
    subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(work/'actual-eight-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],check=True,capture_output=True);started=True
    audit=rooms('riftbound_acceptance');native=rooms('riftbound_here_native')
    assert audit==prior['auditRooms'] and len(audit)==213
    assert set(native)==set(prior['nativeRooms'])|{old_final['roomId']} and len(native)==47
    before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',native)
    assert before_audit==prior['auditSevenTables'] and digests('riftbound_here_native',prior['nativeRooms'])==prior['nativeSevenTables']
    write(work/'original213-audit47-native-seven-table-baseline-v1.json',{'atUtc':now(),'auditRooms':audit,'nativeRooms':native,'auditSevenTables':before_audit,'nativeSevenTables':before_native})
    evidence=work/'actual-sql-v1';assert not evidence.exists()
    env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit',
        RIFTBOUND_POSTGRES_EVIDENCE=str(evidence),DOTNET_DbgEnableMiniDump='0');env.pop('GITHUB_SHA',None);env.pop('DOTNET_STARTUP_HOOKS',None)
    for name,selector in [('eight',['--spell-remake-declaration-only']),('clairvoyance',['--ci-partition','17','48'])]:
        args=['/Users/dinghaolin/.dotnet/dotnet',str(runtime/'Riftbound.PostgresAcceptance.dll')]+selector
        with (work/('actual-'+name+'-writer-v1.log')).open('xb') as log:
            process=subprocess.Popen(args,cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT);proof[name+'WriterPid']=process.pid;write(output,proof);code=process.wait(timeout=300)
        proof[name+'WriterExitCode']=code;write(output,proof);assert code==0,name+' actual SQL writer failed; preserve partial database and outputs'
        frozen()
    case_dirs=sorted((evidence/'spell-remake-declaration').iterdir());assert len(case_dirs)==8
    receipts=[json.loads((p/'receipt.json').read_text()) for p in case_dirs]
    assert all(r['status']=='REAL_POSTGRES_DECLARATION_SCOPE_COLD_DEDUP_REPLAY_AND_ATOMIC_REJECTION_PASS' and r['actualRuleInputs']==publication['actualRuleInputs'] for r in receipts)
    added=sorted(set(rooms('riftbound_acceptance'))-set(audit));assert len(added)==8 and set(added)=={r['room'] for r in receipts}
    assert all(r['coldRecoveries']==r['commands'] for r in receipts)
    part=json.loads((evidence/'partition-receipt.json').read_text());assert part['status']=='REAL_POSTGRES_PARTITION_COMPLETE' and part['fixedCommit'] is None
    assert part['expectedCases']==part['completedCases']==['clairvoyance'] and part['partitionIndex']==17 and part['partitionCount']==48 and len(part['orderedDefaultCases'])==48
    assert part['actualRuleInputs']==publication['actualRuleInputs']
    for r in part['outputFiles']:
        p=evidence/r['path'];assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256']
    clair=[json.loads((evidence/'clairvoyance'/b/'receipt.json').read_text()) for b in ['keep','some','all','burnout','control']]
    assert all(r['coldRecoveries']==r['submitted'] for r in clair) and sum(r['structuralTamperRejections'] for r in clair)==15
    assert digests('riftbound_acceptance',audit)==before_audit and rooms('riftbound_here_native')==native and digests('riftbound_here_native',native)==before_native
    ready={'status':'EIGHT_AND_RETAINED_FIVE_WRITERS_PASSED_INDEPENDENT_SQL_HISTORY_READBACK_STILL_REQUIRED','atUtc':now(),
        'originalAuditRoomCount':len(audit),'originalNativeRoomCount':len(native),'addedAuditRooms':added,'currentAuditRoomCount':len(audit)+len(added),
        'newEightCommands':sum(r['commands'] for r in receipts),'newEightEvents':sum(r['events'] for r in receipts),
        'newEightAtomicRejections':sum(r['atomicRejections'] for r in receipts),
        'clairvoyanceCommands':sum(r['submitted'] for r in clair),'clairvoyanceEvents':sum(r['events'] for r in clair),
        'originalClairvoyanceTamperRejections':15,'actualRuleInputs':publication['actualRuleInputs'],'allOriginal213Audit47NativeSevenTablesExact':True}
    proof.update(ready);proof['status']='WAITING_INDEPENDENT_CURRENT_SQL_HISTORY_READER_NOT_FINAL_ACCEPTANCE';write(output,proof);write(work/'actual-sql-writers-ready-v1.json',ready)
    print(ready['status'],ready['newEightCommands'],ready['newEightEvents'],flush=True)
    while not (work/'independent-readback-complete-stop-v1.json').exists():
        time.sleep(2)
    stop=json.loads((work/'independent-readback-complete-stop-v1.json').read_text());assert stop['independentReadbackPassed'] is True
    assert digests('riftbound_acceptance',audit)==before_audit and digests('riftbound_here_native',native)==before_native
    assert set(rooms('riftbound_acceptance'))==set(audit)|set(added) and rooms('riftbound_here_native')==native
    proof.update(status='PASS_CURRENT_EIGHT_AND_FIVE_REAL_SQL_PLUS_INDEPENDENT_HISTORY_REPLAY',independentReadback=stop,
        allOriginal213Audit47NativeSevenTablesExact=True,allEightNewOwnFixtureRoomsRetained=True)
except BaseException as e:
    proof.update(status='FAILED_OR_INTERRUPTED_CURRENT_SQL_OWNER_ORIGINALS_RETAINED',errorType=type(e).__name__,error=str(e));raise
finally:
    if process is not None and process.poll() is None:process.terminate();process.wait(timeout=20)
    if started:
        if audit is not None and 'before_audit' in globals():
            proof['allOriginal213AuditSevenTablesExactAtStop']=digests('riftbound_acceptance',audit)==before_audit
            proof['allOriginal47NativeSevenTablesExactAtStop']=digests('riftbound_here_native',native)==before_native
            proof['currentAuditRoomsAtStop']=rooms('riftbound_acceptance')
        proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
    if power is not None:
        if power.poll() is None:power.terminate();power.wait(timeout=10)
        proof['boundIdleAssertionEnded']=power.poll() is not None
    frozen();proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),allSourceModesAndRuntimeHashesFrozen=True,originalDatabaseRetained=True)
    write(output,proof);fcntl.flock(guard,fcntl.LOCK_UN)
print(proof['status'],flush=True)
