import collections
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

root=Path('/Users/dinghaolin/MyProjects/riftbound');work=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(path,value):
    with path.open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
def read_trx(path):
    tree=ET.fromstring(path.read_bytes());ns={'t':tree.tag.split('}')[0][1:]}
    cases=collections.Counter();methods=set();outcomes=collections.Counter();failed=[];passed=set()
    for row in tree.findall('.//t:UnitTestResult',ns):
        name=row.attrib['testName'];cases[name]+=1;outcomes[row.attrib['outcome']]+=1
        if row.attrib['outcome']=='Passed':passed.add(name)
        else:failed.append(name)
    for row in tree.findall('.//t:UnitTest',ns):
        m=row.find('t:TestMethod',ns);methods.add(m.attrib['className']+'.'+m.attrib['name'])
    return cases,methods,outcomes,failed,passed
owner=load(work/'only-check-owner-terminal-v1.json');start=load(work/'only-check-start-inputs-v1.json')
assert owner['exitCode']==1 and owner['status']=='CHECK_FAILED_OR_INTERRUPTED_ORIGINAL_OUTPUT_RETAINED'
for key in ('all3316SourceHashesUnchanged','allSourceModesUnchanged','allConformanceInputPayloadsUnchanged','all23NativePayloadsUnchanged','boundIdleAssertionEnded'):assert owner[key],key
baseline=root/start['originalBaselineTrx'];assert sha(baseline)==start['originalBaselineTrxSha256']
old_cases,old_methods,old_outcomes,_,_=read_trx(baseline)
trx=work/'only-check-v1/check/results.trx';cases,methods,outcomes,failures,passed=read_trx(trx)
failure='Riftbound.ConformanceTests.DeckPlaySequenceTests.RealControlChangeKeepsTheTurnPlayersChoiceOrderAndFinishesTheSourceBeforeConfirmation'
assert sum(old_cases.values())==13166 and len(old_methods)==7490 and set(old_outcomes)=={'Passed'}
assert all(cases[k]>=n for k,n in old_cases.items()) and old_methods<methods
added=cases-old_cases;added_methods=methods-old_methods
assert sum(cases.values())==13176 and len(methods)==7494 and outcomes=={'Passed':13175,'Failed':1} and failures==[failure]
prefix='Riftbound.ConformanceTests.SpellRemakeDeclarationScopeTests.'
assert sum(added.values())==10 and len(added_methods)==4 and all(n.startswith(prefix) and n in passed for n in added) and all(m.startswith(prefix) for m in added_methods)
focus=work/'post-check-original-deck-driver-focus-v1';summary=load(focus/'summary.json');assert summary['status']=='PASSED'
fc,fm,fo,ff,fp=read_trx(focus/'focus/results.trx');assert failure in fp and not ff and set(fo)=={'Passed'} and sum(fc.values())==summary['total'] and len(fm)==72
path='tests/Riftbound.ConformanceTests/DeckPlaySequenceTests.cs'
original=work/'original-before-post-check-expectation-correction'/path
assert sha(original)==start['sourceInputHashes'][path]
expected=original.read_text().replace('        await driver.Act("P1", new PayCostCommand(driver.State.PendingRuleChoice!.Request.Id, "RULE_REPLACEMENT", ["KEEP_ALL"]));',
    '        Assert.Null(driver.State.PendingRuleChoice);\n        Assert.Null(driver.State.PendingCardChoice);')
assert (root/path).read_text()==expected
source_diff={p for p,h in start['sourceInputHashes'].items() if sha(root/p)!=h};assert source_diff=={path}
runtime_diff={p for p,h in start['actualConformanceRuntimeFileHashes'].items() if sha(root/p)!=h}
assert runtime_diff=={'tests/Riftbound.ConformanceTests/bin/Debug/net10.0/Riftbound.ConformanceTests.dll','tests/Riftbound.ConformanceTests/bin/Debug/net10.0/Riftbound.ConformanceTests.pdb'}
assert all(sha(root/p)==h for p,h in start['actualNativeRuntimeFileHashes'].items())
assert all(oct((root/p).stat().st_mode&0o777)==m for p,m in start['sourceInputModes'].items())
baseline_inputs=json.loads(gzip.decompress((work/'prior-fixed564-source-baseline.json.gz').read_bytes()))
full_sources={p:h for p,h in baseline_inputs['sourceInputHashes'].items() if Path(p).name.startswith('FullGameEndToEndTests') and p.endswith('.cs')}
assert len(full_sources)==9 and all(sha(root/p)==h for p,h in full_sources.items())
current_sources={p:sha(root/p) for p in start['sourceInputHashes']};current_conformance={p:sha(root/p) for p in start['actualConformanceRuntimeFileHashes']}
changed={p for p,h in baseline_inputs['sourceInputHashes'].items() if current_sources[p]!=h}
assert len(changed)==9 and path in changed
new=set(current_sources)-set(baseline_inputs['sourceInputHashes']);assert new=={'tests/Riftbound.ConformanceTests/SpellRemakeDeclarationScopeTests.cs','tests/Riftbound.PostgresAcceptance/SpellRemakeDeclarationSqlAcceptance.cs'}
old_sql=json.loads(subprocess.check_output(['git','show',start['baseCommit']+':tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'],cwd=root))
new_sql=load(root/'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json');assert len(new_sql['cases'])==48 and new_sql['cases'][:47]==old_sql['cases']
final={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseCommit':start['baseCommit'],
    'sourceInputHashes':current_sources,'sourceInputModes':start['sourceInputModes'],'sourceInputCount':3316,
    'actualConformanceRuntimeFileHashes':current_conformance,'actualConformanceRuntimeFileCount':1419,
    'actualNativeRuntimeFileHashes':start['actualNativeRuntimeFileHashes'],'actualNativeRuntimeFileCount':23,
    'onlyChangeAfterSoleCheck':path,'onlyTwoConformanceBinaryPayloadsRebuilt':sorted(runtime_diff),'gameplayRulesCatalogApiNativeAndSqlSourceInputsUnchangedSinceSoleCheck':True,
    'actualFocusedTestAssemblySha256':load(focus/'plan.json')['testAssemblySha256'],'newFixedFullRequired':True}
write(work/'post-check-final-focused-source-and-payload-inputs-v1.json',final)
result={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ACTUAL_SOLE_CHECK_ONE_OLD_DRIVER_FAILURE_RETAINED_POST_CHECK_FOCUSED_CORRECTION_PASS_NEW_FIXED_FULL_OPEN',
    'cases':13176,'methods':7494,'passed':13175,'failed':1,'skipped':0,'seconds':owner['seconds'],
    'oldCaseMultisetAndMethodIdentitiesPreserved':True,'originalCases':13166,'originalMethods':7490,'addedCaseMultiset':dict(added),'addedMethodNames':sorted(added_methods),'all10NewCasesPassedInSoleCheck':True,
    'originalFailureMethod':failure,'originalTrxSha256':sha(trx),'all3316SourcesModes1419Conformance23NativeStableDuringOnlyCheck':True,
    'onlyPostCheckChangeIsExactOldVerificationDriverCorrectionAndTwoNewNullAssertions':path,'noOriginalAssertionMethodTheoryOrReplayRemoval':True,
    'postCheckFocusCases':sum(fc.values()),'postCheckFocusMethods':len(fm),'originalFailedMethodAndWholeDeckPlaySequenceClassExecutedAndPassed':True,
    'postCheckFocusTrxSha256':sha(focus/'focus/results.trx'),'allNineOriginalFullGameSourcesByteExact':full_sources,
    'all143FullMethods110Pairs11Decks424242AndVictoryReplayAssertionsPreserved':True,'allOriginal47SqlRecordsAndOrderExactPrefixOf48':True,
    'exactOneActualCheckNoCheckRerun':True,'gameplayRulesNativeCatalogAndSqlInputsUnchangedByCorrection':True,
    'newFixedFullForFinalVerificationInputAndCurrentVisibleProductPhysicalWindows':'OPEN','wholePrintingOrGlobalCertification':False}
write(work/'only-check-failure-retention-and-focused-correction-disposition-v2.json',result)
print(result['status'],result['cases'],result['failed'],result['postCheckFocusCases'],result['postCheckFocusMethods'],flush=True)
