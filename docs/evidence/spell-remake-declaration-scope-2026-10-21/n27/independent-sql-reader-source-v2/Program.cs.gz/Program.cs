using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

Check(args.Length == 2, "Exact evidence directory and unused receipt path required.");
var work = Path.GetFullPath(args[0]); var output = Path.GetFullPath(args[1]);
Check(!File.Exists(output), "Never overwrite an original independent result.");
var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
var settings = new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
Check(settings.Host == "127.0.0.1" && settings.Port == 55486 && settings.Database == "riftbound_acceptance"
    && settings.Username == "codex_riftbound_audit", "Only the existing own audit database is allowed.");
settings.Options = "-c default_transaction_read_only=on";
await using var source = NpgsqlDataSource.Create(settings.ConnectionString);
var store = new PostgresMatchRecoveryStore(source);
var results = new List<object>(); var totalStates = 0; var totalSnapshots = 0; var totalPrompts = 0;
var eight = Directory.GetDirectories(Path.Combine(work, "actual-sql-v1/spell-remake-declaration")).Order().ToArray();
Check(eight.Length == 8, "All original eight fixture identities required.");
foreach (var folder in eight)
{
    using var receipt = JsonDocument.Parse(File.ReadAllText(Path.Combine(folder, "receipt.json")));
    var room = receipt.RootElement.GetProperty("room").GetString()!;
    var mirror = receipt.RootElement.GetProperty("mirror").GetBoolean();
    var branch = receipt.RootElement.GetProperty("branch").GetString()!;
    using var exported = Read(Path.Combine(folder, "final-original-frame.json.gz"));
    var original = exported.RootElement.Deserialize<MatchRecoveryFrame>(json)!;
    var frame = await store.LoadAsync(room, default) ?? throw new Exception("Actual retained SQL fixture is required.");
    Check(Same(exported.RootElement, JsonSerializer.SerializeToElement(original, json))
        && Same(exported.RootElement, JsonSerializer.SerializeToElement(frame, json)), "All original frame fields, nulls and omissions equal the independent typed SQL read.");
    var expectedCommands = branch is "zero" or "echo" ? (mirror ? 10 : 9) : branch == "mode" && mirror ? 9 : mirror ? 8 : 7;
    Check(frame.IsConsistent && frame.Commands.Count == expectedCommands && frame.Commands.All(c => c.Accepted && c.RuleInputs == RuleInputIdentity.Current)
        && frame.AuthoritativeState!.RuleInputs == RuleInputIdentity.Current, "Literal command counts and every current input identity.");
    var initialRaw = File.ReadAllBytes(Path.Combine(folder, "explicit-fixture-initial.json"));
    var initial = JsonSerializer.Deserialize<MatchState>(initialRaw, json)!;
    Check(Same(JsonSerializer.SerializeToElement(initial, json), JsonSerializer.Deserialize<JsonElement>(initialRaw)), "Every original explicit initial field and null retained.");
    var state = frame.AuthoritativeState!; var targets = branch is "zero" or "echo";
    var draws = branch == "draw" ? 2 : branch == "mode" ? 1 : 0;
    Check(state.Status == MatchStatuses.InProgress && state.StackItems.Count == 0 && state.PendingRuleChoice is null
        && state.PendingCardChoice is null, "No artificial choice, pending spell or burnout at completion.");
    Check(state.CardObjects["UNIT-1"].Damage == (targets ? 1 : 0) && state.CardObjects["UNIT-2"].Damage == 0
        && state.CardObjects["UNIT-1"].Power == 9 && state.CardObjects["UNIT-2"].Power == 9, "Independent literal damage versus stored Might checks.");
    Check(state.PlayerZones["P2"].Hand.SequenceEqual(initial.PlayerZones["P2"].MainDeck.Take(draws))
        && state.PlayerZones["P1"].MainDeck.SequenceEqual(initial.PlayerZones["P1"].MainDeck), "Literal new-controller draws and original opponent deck.");
    Check(state.RunePools["P2"].Mana == (mirror ? 29 : 26) && state.RunePools["P2"].TotalPower == (mirror ? 28 : 27), "Literal original control costs only.");
    Check(state.PlayerZones["P1"].Graveyard.Contains("SPELL") && !state.PlayerZones["P2"].Graveyard.Contains("SPELL")
        && state.CardPlays.Finalized.Single(p => p.Source.ObjectId == "SPELL").PlayerId == "P1"
        && state.CardPlays.Resolved.Single(p => p.Source.ObjectId == "SPELL").PlayerId == "P2", "Physical owner, finalizer and resolver are independent literal actors.");
    Check(frame.Events.Count(e => e.Event.Kind == "SPELL_CHOICES_REMADE") == (targets ? 1 : 0), "No fabricated remake event.");
    using var control = Read(Path.Combine(folder, "after-control-original-frame.json.gz"));
    var controlled = control.RootElement.GetProperty("authoritativeState").Deserialize<MatchState>(json)!;
    var spell = controlled.StackItems.Single();
    Check(spell.ControllerId == "P2" && Same(JsonSerializer.SerializeToElement(controlled.RunePools, json), JsonSerializer.SerializeToElement(state.RunePools, json)), "No resources are charged during the controlled resolution.");
    if (branch == "echo")
        Check(spell.RepeatExecutions is { Count: 2 } executions && executions[0].TargetObjectIds.Count == 0
            && executions[1].TargetObjectIds.SequenceEqual(new[] { "UNIT-1" }), "Literal zero first execution and one target in the second execution.");
    var states = new Dictionary<(long Tick, long Sequence), MatchState>(); var pendingRemakes = 0; var drafts = 0;
    await using (var connection = await source.OpenConnectionAsync())
    {
        Check((string)(await new NpgsqlCommand("show transaction_read_only", connection).ExecuteScalarAsync())! == "on", "Actual read-only connection required.");
        await using (var query = new NpgsqlCommand("select last_event_sequence,payload::text from state_snapshots where match_id=@room order by id", connection))
        {
            query.Parameters.AddWithValue("room", room); await using var rows = await query.ExecuteReaderAsync();
            while (await rows.ReadAsync())
            {
                var text = rows.GetString(1); var historical = JsonSerializer.Deserialize<MatchState>(text, json)!;
                Check(JsonNode.DeepEquals(JsonNode.Parse(text), JsonSerializer.SerializeToNode(historical, json))
                    && historical.RuleInputs == RuleInputIdentity.Current, "Every authoritative historical field, null and conditional omission.");
                Check(states.TryAdd((historical.Tick, rows.GetInt64(0)), historical), "Unique tick plus journal sequence; no state row discarded.");
                if (historical.PendingRuleChoice?.Request.Kind == "SPELL_CHOICE_REMAKE")
                {
                    pendingRemakes++; var pending = historical.PendingRuleChoice;
                    Check(pending.Request.PlayerId == "P2" && (targets || mirror && branch == "mode"), "Only a permitted literal declaration has a remake window.");
                    Check(pending.Request.Preview!.StackItems.Single(i => i.SourceObjectId == "SPELL").ControllerId == "P2", "Actual resolving preview controller.");
                    var edits = pending.Answers.Count(a => a.OptionId.StartsWith("EDIT:", StringComparison.Ordinal));
                    Check(edits <= 1 && pending.Answers.Count == (mirror ? 1 : 0) + edits
                        && (!mirror || pending.Answers[0].OptionId == "PAY:ANY"), "Prior optional control payment and a later declaration edit are separate transcript entries.");
                    if (edits == 1) drafts++;
                }
            }
        }
        Check(states.Count == expectedCommands && pendingRemakes == (targets ? 2 : mirror && branch == "mode" ? 1 : 0)
            && drafts == (targets ? 1 : 0), "All original states and exact literal choice/draft checkpoints.");
        foreach (var table in new[] { "snapshots", "action_prompts" })
        {
            await using var query = new NpgsqlCommand($"select player_id,last_event_sequence,payload::text from {table} where match_id=@room order by id", connection);
            query.Parameters.AddWithValue("room", room); await using var rows = await query.ExecuteReaderAsync();
            var keys = new HashSet<(long Tick, long Sequence, string Player)>();
            while (await rows.ReadAsync())
            {
                var actor = rows.GetString(0); var sequence = rows.GetInt64(1); var text = rows.GetString(2);
                using var document = JsonDocument.Parse(text); var tick = document.RootElement.GetProperty(table == "snapshots" ? "tick" : "snapshotTick").GetInt64();
                Check(states.TryGetValue((tick, sequence), out var historical), "Every private row binds its exact authoritative tick and journal sequence.");
                Check(keys.Add((tick, sequence, actor)), "No duplicate private row hidden by dictionary replacement.");
                var typed = table == "snapshots" ? JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<SnapshotDto>(text, json), json)
                    : JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<ActionPromptDto>(text, json), json);
                Check(JsonNode.DeepEquals(JsonNode.Parse(text), typed), "All original private fields, nulls and conditional omissions survive typed read.");
                var expected = table == "snapshots" ? JsonSerializer.SerializeToNode(ResolutionResult.BuildSnapshots(historical!)[actor], json)
                    : JsonSerializer.SerializeToNode(ResolutionResult.BuildPrompts(historical!)[actor], json);
                Check(JsonNode.DeepEquals(JsonNode.Parse(text), expected), "Complete projection matches the exact persisted historical state.");
                var other = actor == "P1" ? "P2" : "P1";
                foreach (var id in historical!.PlayerZones[other].MainDeck.Concat(historical.PlayerZones[other].Hand))
                    Check(!text.Contains("\"" + id + "\"", StringComparison.Ordinal), "Literal opponent hidden identities remain absent from the stored private row.");
            }
            Check(keys.Count == states.Count * 2 && states.Keys.All(key => initial.Seats.Keys.All(actor => keys.Contains((key.Tick, key.Sequence, actor)))), "Both original private rows exist for every authoritative state.");
            if (table == "snapshots") totalSnapshots += keys.Count; else totalPrompts += keys.Count;
        }
    }
    var replay = await MatchActionLogReplayer.VerifyFinalStateAsync(initial, frame.Commands, state, new CoreRuleEngine(), default, frame.Events);
    Check(replay.IsMatch, "All original commands, events and final state replay from the separate original explicit fixture: " + string.Join(';', replay.Errors));
    totalStates += states.Count;
    results.Add(new { room, mirror, branch, commands = frame.Commands.Count, events = frame.Events.Count, historicalStates = states.Count,
        historicalPrivateSnapshots = states.Count * 2, historicalPrivatePrompts = states.Count * 2, pendingRemakes, drafts,
        originalExplicitInitialSha256 = Convert.ToHexString(SHA256.HashData(initialRaw)).ToLowerInvariant() });
}
var clairResults = new List<object>();
foreach (var branch in new[] { "keep", "some", "all", "burnout", "control" })
{
    var folder = Path.Combine(work, "actual-sql-v1/clairvoyance", branch);
    using var original = Read(Path.Combine(folder, "complete-original-frame.json.gz"));
    var frame = original.RootElement.Deserialize<MatchRecoveryFrame>(json)!;
    Check(Same(original.RootElement, JsonSerializer.SerializeToElement(frame, json)) && frame.IsConsistent, "Every original Clairvoyance frame field and null is preserved.");
    var initial = JsonSerializer.Deserialize<MatchState>(File.ReadAllBytes(Path.Combine(folder, "explicit-fixture-initial.json")), json)!;
    var state = frame.AuthoritativeState!; var actor = branch == "control" ? "P2" : "P1";
    var expected = branch switch { "keep" => new[] { "D5", "D4" }, "some" => ["D5", "D3"], "all" => ["D6", "D7"], "control" => ["E2", "E1"], _ => ["D1"] };
    Check(state.RuleInputs == RuleInputIdentity.Current && state.PlayerZones[actor].Hand.SequenceEqual(expected)
        && state.PendingCardChoice is null && state.PendingRuleChoice is null && state.StackItems.Count == 0, "All five original literal draw orders and completion.");
    if (branch == "control")
        Check(frame.Commands.Count == 9 && frame.Commands.All(c => c.CommandType != "PAY_COST")
            && state.CardPlays.Finalized.Single(c => c.Source.ObjectId == "SPELL").PlayerId == "P1"
            && state.CardPlays.Resolved.Single(c => c.Source.ObjectId == "SPELL").PlayerId == "P2"
            && state.PlayerZones["P1"].MainDeck.SequenceEqual(initial.PlayerZones["P1"].MainDeck), "Control completes with no empty choice while original owner and private decks remain distinct.");
    Check(state.Status == (branch == "burnout" ? MatchStatuses.Finished : MatchStatuses.InProgress), "Original winning burnout branch retained separately from normal games.");
    foreach (var player in initial.Seats.Keys)
        Check(Same(JsonSerializer.SerializeToElement(frame.PlayerViews[player].Snapshot, json), JsonSerializer.SerializeToElement(ResolutionResult.BuildSnapshots(state)[player], json))
            && Same(JsonSerializer.SerializeToElement(frame.PlayerViews[player].Prompt, json), JsonSerializer.SerializeToElement(ResolutionResult.BuildPrompts(state)[player], json)), "All ten original final private snapshots and ten prompts are exact.");
    var replay = await MatchActionLogReplayer.VerifyFinalStateAsync(initial, frame.Commands, state, new CoreRuleEngine(), default, frame.Events);
    Check(replay.IsMatch, "Entire original explicit controlled Clairvoyance replay: " + string.Join(';', replay.Errors));
    clairResults.Add(new { branch, commands = frame.Commands.Count, events = frame.Events.Count,
        sourceScope = "Original exported frames; original fixture cleanup retained, no claim that deleted intermediate SQL rows remain present" });
}
Check(totalStates == 69 && totalSnapshots == 138 && totalPrompts == 138, "All 69 retained SQL states and both players combined 138 snapshots and 138 prompts.");
var result = new { status = "PASS_INDEPENDENT_CURRENT_EIGHT_ACTUAL_SQL_HISTORY_AND_FIVE_ORIGINAL_CLAIRVOYANCE_FULL_REPLAYS",
    retainedActualSqlFixtures = 8, originalExportedClairvoyanceFixtures = 5, totalAuthoritativeHistoricalSqlStates = totalStates,
    bothPlayersCombinedHistoricalSqlSnapshots = totalSnapshots, bothPlayersCombinedHistoricalSqlPrompts = totalPrompts,
    actualSqlResults = results, clairvoyanceOriginalFileResults = clairResults, actualRuleInputs = RuleInputIdentity.Current,
    everyOriginalFieldNullAndConditionalOmissionPreserved = true, actualReadOnlyConnection = true,
    noOriginalBlankMetadataAcceptedHistoryOrDatabaseWrites = true, ordinaryOpeningNativeAndWholePrintingCertification = false };
await File.WriteAllTextAsync(output, JsonSerializer.Serialize(result, json)); Console.WriteLine(JsonSerializer.Serialize(result, json));
bool Same(JsonElement x, JsonElement y) => JsonNode.DeepEquals(JsonNode.Parse(x.GetRawText()), JsonNode.Parse(y.GetRawText()));
static JsonDocument Read(string path) { using var zip = new GZipStream(File.OpenRead(path), CompressionMode.Decompress); return JsonDocument.Parse(zip); }
static void Check(bool condition, string message) { if (!condition) throw new Exception(message); }
