import copy
import datetime
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

root=Path('/Users/dinghaolin/MyProjects/riftbound');work=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(path,value):
    with path.open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
def pin(path,role):return {'path':str(path.relative_to(root)),'sha256':sha(path),'role':role}
base='564e433d54d47f98b405787eed97cbdd48b7c394'
identity='spell-remake-no-intrinsic-declarations-and-sfd080-zero-targets-2026-10-21'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==base
manifest_path=root/'docs/audit/current-manifest.json';reviews_path=root/'docs/evidence/rules-reaudit-2026-10-11/review-decisions.json'
prior=load(manifest_path);old_reviews=load(reviews_path)
assert len(prior['reviewContexts'])==63 and len(prior['acceptanceGates'])==241 and len(prior['laterSourceDeltas'])==6 and len(old_reviews['reviews'])==148
for path,name in [(manifest_path,'prior-entire-current-manifest.json.gz'),(reviews_path,'prior-entire-review-decisions.json.gz')]:
    target=work/name
    if target.exists():assert gzip.decompress(target.read_bytes())==path.read_bytes()
    else:target.write_bytes(gzip.compress(path.read_bytes(),mtime=0))
baseline_ids=set(load(root/'docs/evidence/native-spell-choice-presentation-2026-10-20/remaining-obligation-ids.json'));assert len(baseline_ids)==16927
frozen=load(work/'only-check-start-inputs-v1.json');assert frozen['sourceInputCount']==3316 and all(sha(root/p)==h for p,h in frozen['sourceInputHashes'].items())
source_root=root/'docs/evidence/source-round-2026-10-21';source=load(source_root/'source-manifest.json')
prior_fixed_root=root/'docs/evidence/fixed-564-native-and-full-2026-10-21';fixed=load(prior_fixed_root/'source-manifest.json')
assert load(root/fixed['actualCompleteFixedCi']['path'])['status']=='FIXED_COMMIT_FULL_CI_AND_PARITY_VERIFIED'
assert load(work/'adjacent-original-games-actual-terminal-and-method-retention-v1.json')['cases']==2982
sql=load(work/'actual-eight-and-clairvoyance-owner-v1.json');independent=load(work/'independent-current-eight-and-clair-originals-result-v2.json')
assert sql['status']=='PASS_CURRENT_EIGHT_AND_FIVE_REAL_SQL_PLUS_INDEPENDENT_HISTORY_REPLAY'
assert independent['totalAuthoritativeHistoricalSqlStates']==69 and independent['bothPlayersCombinedHistoricalSqlSnapshots']==independent['bothPlayersCombinedHistoricalSqlPrompts']==138
impl=['src/Riftbound.Engine/CoreRuleEngine.SpellChoiceControl.cs','src/Riftbound.Engine/CardBehaviorRegistry.cs']
verification=['tests/Riftbound.ConformanceTests/SpellRemakeDeclarationScopeTests.cs','tests/Riftbound.ConformanceTests/ReversalTargetChoiceTests.cs','tests/Riftbound.ConformanceTests/ClairvoyanceTests.cs',
    'tests/Riftbound.PostgresAcceptance/SpellRemakeDeclarationSqlAcceptance.cs','tests/Riftbound.PostgresAcceptance/ClairvoyanceSqlAcceptance.cs','tests/Riftbound.PostgresAcceptance/Program.cs',
    'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json','scripts/tests/test_sql_ci_gate.py']
source_manifest={'recordedAtUtc':now(),'region':'CN','language':'zh-CN','applicableAsOf':'2026-10-21','adoptedCoreEffectiveDate':'2026-10-16',
    'baseCommit':base,'includesDeclaredUncommittedChanges':True,
    'scope':'Intrinsic absence of a declaration in the controlling permission scope; exact SFD080 up-to-zero cast and retarget including separately retained Echo executions. No general rule753.2 completion reachability claim.',
    'currentEntireSourceRound':pin(source_root/'source-manifest.json','current21-source-round'),
    'exactFiveCurrentFullApiRowsAndFaces':pin(work/'current-card-faces/all-five-exact-face-and-full-row-readbacks-v1.json','current-exact-five-faces'),
    'sixthExactUnl182Face':pin(work/'current-card-faces/additional-perfect-finale-mode-control-face-v1.json','current-exact-unl182'),
    'coreExactClauseBindings':pin(work/'current-exact-core-clause-block-bindings-v1.json','exact-current-core-records'),
    'allOriginalPrintingAndClauseRecordsSourceDatesAndGapsPreserved':True,
    'implementation':[pin(root/p,'implementation') for p in impl],'verificationSources':[pin(root/p,'verification-source') for p in verification],
    'focus85Cases39Methods':'ACTUAL_PASS','adjacent2982Cases2105MethodsAndTwoOriginalGames':pin(work/'adjacent-original-games-actual-terminal-and-method-retention-v1.json','adjacent-focus'),
    'additional20AffectedOriginalHelpers':pin(work/'affected20-independent-seven-field-identity-and-original-output-readback-v1.json','actual-original-affected-pairs'),
    'actualNewControlledSql8':{'commands':69,'events':145,'coldRecoveries':69,'directAtomicRejects':18,'wholeGameOrOrdinaryOpening':False},
    'actualOriginalClairvoyance5':{'commands':27,'events':64,'coldRecoveries':27,'structuralTamperRejects':15,'originalIntermediateSqlRowsCleanedByUnchangedOldHelper':True,'allOriginalExportedFullFramesAndFinalPrivateRowsReadBack':True},
    'independentSqlHistoricalReadback':pin(work/'independent-current-eight-and-clair-originals-result-v2.json','independent-sql-actual-history-and-original-clair-full-replay'),
    'actualSqlOwner':pin(work/'actual-eight-and-clairvoyance-owner-v1.json','actual-sql-owner-normal-stop-and-original-database-retention'),
    'actualCurrentReleaseRuleInputs':load(work/'current-release-sql-frozen-publication-v1.json')['actualRuleInputs'],
    'soleCheck':'RUNNING_EXACT_ONE_ATTEMPT_AFTER_TWO_PRE_RUN_WRAPPER_PREFLIGHT_ERRORS',
    'frozenCheckInputs':pin(work/'only-check-start-inputs-v1.json','check-running-frozen-inputs'),
    'expectedCheckNotResult':{'cases':13176,'methods':7494},'expectedFullNotResult':{'cases':13325,'methods':7635,'sqlExecutionIdentities':48,'fullGameMethods':143,'pairs':110,'decks':11,'seed':424242},
    'old47DefaultSqlCasesExactPrefixOf48':True,'oldAllMethodsTheoryRows110PairsOriginalSeedsAndVictoryReplayAssertionsRetained':True,
    'precedingFixed564CompleteFullAndBoundedLockedNative':pin(prior_fixed_root/'source-manifest.json','preceding-fixed564-separate-complete-ci-and-bounded-native'),
    'newFixedCompleteCiAndCurrentVisiblePairedPhysicalWindows':'OPEN',
    'existingAcceptanceGateDependencies':['REVERSAL_TARGET_CHOICES_CURRENT_FIXED_FULL_NATIVE_PAIRED_SQL_RECONNECT_NORMAL_SCORE_REPLAY_AND_WINDOWS','REVERSAL_REMAINING_ECHO_BASE_DESTINATION_OTHER_TARGET_CONSUMERS_PRINTINGS_SOURCE_APPLICABILITY'],
    'currentCandidateRequirementAll48DefaultSqlAndAll143FullMethods110Pairs':'ADDITIVE_TO_EXISTING_RETAINED47_SQL_GATE_NOT_A_REDUCTION',
    'remaining':['NO_LEGAL_COMPLETE_REMAKE_DESPITE_PARTIAL_EDITS','ORIGINAL_BASE_AND_NEW_CONTROLLER_SOURCE_RESTRICTIONS','EXTERNALLY_GRANTED_ECHO','STANDBY_OTHER_CONSUMERS_AND_ALL_PRINTINGS_DATES_REGIONS_SOURCE_GAPS','CURRENT_FIXED_VISIBLE_PAIRED_REAL_SQL_RECONNECT_NORMAL_SCORE_FULL_REPLAY','PHYSICAL_WINDOWS'],
    'wholePrintingAndGlobalSemanticCertification':False}
source_path=work/'planned-source-manifest-v2.json';write(source_path,source_manifest);source_ref=pin(source_path,'planned-source-manifest')
subjects=['OGN-080/298','VEN-152','VEN-152/166','OGN-083/298','SFD-087/221','SFD-080/221','UNL-182/219','VEN-056','VEN-056/166']
bindings=load(work/'current-exact-core-clause-block-bindings-v1.json')['exactSourceRecords']
rules=['CN-d6fd7140f106f9b5-'+r['id'].removeprefix('DOC-01-') for r in bindings]
reviews=copy.deepcopy(old_reviews)
reviews['reviews'].append({'id':identity,'scope':source_manifest['scope'],'subjects':subjects,'ruleRecords':rules,'pendingRuleRecords':[],
    'status':'BOUNDED_CURRENT_FOCUS_SQL_AND_ORIGINAL20_PAIR_HELPERS_CHECK_RUNNING_NEW_FIXED_FULL_AND_PRODUCT_OPEN',
    'sourceManifest':source_ref,'auditDocument':'var/qa/spell-remake-no-declaration-20261021/n27-audit-draft-v1.md','plannedCanonicalAuditDocument':'docs/SPELL_REMAKE_DECLARATION_SCOPE_AUDIT_2026-10-21.md',
    'validation':{'newCases':10,'newMethods':4,'focusedCases':85,'focusedMethods':39,'adjacentCases':2982,'adjacentMethods':2105,'originalFullGames':2,'additionalOriginalAffectedPairHelpers':20,
        'newControlledSqlScenarios':8,'newSqlCommands':69,'newSqlEvents':145,'newSqlCold':69,'newDirectRejects':18,'retainedClairvoyanceBranches':5,'retainedClairCommands':27,'retainedClairEvents':64,'retainedStructuralRejects':15,
        'allOriginalMethodsTheoryRowsFullGamesMatrixSeedsAndAssertionsPreserved':True,'soleCheck':'RUNNING'},
    'exclusions':source_manifest['remaining']})
reviews_plan=work/'planned-entire-review-decisions-v2.json';write(reviews_plan,reviews)
spec=importlib.util.spec_from_file_location('gov',root/'scripts/audit/check-project-governance.py');checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
revision=checker.digest(checker.gameplay_inputs(root));manifest=copy.deepcopy(prior);prior_ref=pin(work/'prior-entire-current-manifest.json.gz','prior-entire-manifest-raw-gzip');updates=[]
for key,context in manifest['reviewContexts'].items():
    changes=[]
    for field in ('implementation','verificationSources'):
        for ref in context.get(field,[]):
            current=sha(root/ref['path'])
            if current!=ref['sha256']:
                changes.append({'field':field,'path':ref['path'],'previousSha256':ref['sha256'],'currentSha256':current});ref['sha256']=current
    old_metadata={f:context.get(f) for f in ('currentInputRevision','currentImplementationCommit','currentImplementationIncludesUncommittedChanges','ciState')}
    context.setdefault('implementationPinUpdates',[]).append({'batch':identity,'changes':changes,'previousCurrentMetadata':old_metadata,'previousEntireContextPreservedIn':prior_ref,
        'scope':'Only current declared shared guard/SFD080 lower bound and eight verification inputs. All old scopes/source dates/semantic decisions remain; predecessor564 complete CI is separate from current inputs.'})
    context.update(currentInputRevision=revision,currentImplementationCommit=base,currentImplementationIncludesUncommittedChanges=True,ciState='PENDING',revalidationReason='New finite declaration and exact SFD080 source correction; preceding564 full does not cover current uncommitted code, current fixed full and product remain required.')
    if changes:updates.append({'review':key,'changes':changes})
branch_specs=[('INTRINSIC_NO_GRANTED_DECLARATIONS_SKIP_EMPTY_REMAKE','No intrinsic target/mode/destination in granted scope, including target-only DRAW1 vs wider-mode control.'),
    ('SFD080_UP_TO_ZERO_CAST_AND_LATER_NEW_TARGETS','Original zero-target SFD080 casting and new legal target under either control consumer.'),
    ('SFD080_ECHO_FIRST_ZERO_AND_SECOND_NEW_TARGET_ONLY','Both original executions declare zero; only the second is retargeted, original costs/owner/resolver retained.')]
branches=[{'id':key,'scope':scope,'sourceRefs':subjects+rules,'state':'RECORDED','sourceManifest':source_ref,
    'decision':{'state':'OPEN','reason':'Bounded current source/focus/SQL/replay/helper evidence; sole check running, new fixed full and product/remaining semantics still required.'},
    'semanticReview':'BOUNDED_CURRENT_SOURCE_BRANCH_ONLY','implementation':'CURRENT_SHARED_GUARD_AND_EXACT_REGISTERED_MINIMUM','testExecution':'ACTUAL_FOCUS85_ADJACENT2982_SQL8_OLD_CLAIR5_ORIGINAL20_HELPERS_CHECK_RUNNING',
    'fixedCommitCi':'PENDING','productAcceptance':'OPEN','wholePrintingCertified':False,'existingAcceptanceGateDependencies':source_manifest['existingAcceptanceGateDependencies']} for key,scope in branch_specs]
manifest['inputs']['reviews']=pin(reviews_plan,prior['inputs']['reviews'].get('role','reviews'))
manifest['reviewContexts'][identity]={'evidenceCommit':base,'currentImplementationCommit':base,'currentImplementationIncludesUncommittedChanges':True,'currentInputRevision':revision,'ciState':'PENDING','ciReceipts':[],
    'region':'CN','language':'zh-CN','applicableAsOf':'2026-10-21','adoptedCoreEffectiveDate':'2026-10-16','sourceManifest':source_ref,
    'implementation':source_manifest['implementation'],'verificationSources':source_manifest['verificationSources'],
    'evidence':[source_manifest['frozenCheckInputs'],source_manifest['adjacent2982Cases2105MethodsAndTwoOriginalGames'],source_manifest['additional20AffectedOriginalHelpers'],source_manifest['independentSqlHistoricalReadback'],source_manifest['actualSqlOwner']],
    'branches':branches,'existingAcceptanceGateDependencies':source_manifest['existingAcceptanceGateDependencies'],'currentDefaultSqlExecutionIdentities':48,'semanticWholePrintingCertified':False}
manifest['laterSourceDeltas'].append({'kind':'cards','before':source['cards']['beforeAdapter'],'after':source['cards']['afterAdapter'],
    'impact':pin(source_root/'source-manifest.json','current21-precise-badge-key-presence-impact'),
    'disposition':'Only RAD-044/167 flags key removed, absent rather than null; all1408 identities and other fields/presence exact, EN1416/1408 gap8 and issue35 Unit/Gear discrepancy retained. No publication/effective inference or runtime adoption.'})
requirements={
    'CN21_ACTIVITY_20261020_PERIOD_AND_NON_GAMEPLAY_SURFACE':'Retain original image and bounded future10/23–11/30 event interpretation; recheck applicable changes before final certification, not blanket card legality or whole source completion.',
    'CN21_ACTIVITY_20261020_PRECISE_PROMO_PRINTING_IDENTITY':'Bind exact promotional collector identity independently. Same-name RAD133 and133a API40214/40215 remain distinct and are not merged into the displayed P-card voucher.',
    'CN21_ACTIVITY_20261020_OFFICIAL_MINIAPP_FULL_ELIGIBILITY':'Obtain full current official miniapp eligibility and region/date conditions; public poster alone does not close the dynamic source surface.',
    'CN21_ACTIVITY_20261020_REDEMPTION_AND_DEADLINE_SCOPE':'Obtain redemption miniapp conditions and independently specified timezone; printed12/3 23:59:59 is retained as displayed.'}
for item in source['news']['fourNewFiniteIntakeObligations']:
    manifest['acceptanceGates'].append({'id':item['id'],'state':'OPEN','sourceDocument':'CN-NEWS-d7e10972978590af','sourceManifest':source['news']['newActivityPreciseVisualAndDateIdentityDisposition'],
        'region':'CN','language':'zh-CN','applicableAsOf':'2026-10-21','requirement':requirements[item['id']],'boundedObservedDisposition':item,
        'semanticReview':'BOUNDED_PRIMARY_IMAGE_SURFACE_ONLY','implementation':'NO_NEW_GAMEPLAY_INSTRUCTION_FROM_THIS_SURFACE','testExecution':'NOT_A_GAMEPLAY_PASS','fixedCommitCi':'SEPARATE','productAcceptance':'SEPARATE','wholePrintingCertified':False})
manifest['officialNewsObligations']=pin(source_root/'current139-news-index-original20-scope-preserving-ledger.json','current139-listing-and-old20-exact-obligations')
manifest['currentSourceRound20261021']=pin(source_root/'source-manifest.json','source-round21')
manifest['precedingFixed564ActualFullAndBoundedLockedNative']=pin(prior_fixed_root/'source-manifest.json','preceding-fixed564-full-and-bounded-native')
manifest['currentSpellRemakeDeclarationScopeInputChange']=source_ref
assert manifest['certificationScope']==prior['certificationScope'] and manifest['acceptanceGates'][:241]==prior['acceptanceGates'] and manifest['laterSourceDeltas'][:6]==prior['laterSourceDeltas']
assert reviews['reviews'][:148]==old_reviews['reviews'] and len(manifest['reviewContexts'])==64
result=checker.current_audit(root,manifest);assert result['governanceValid'],result['errors']
ids={r['id'] for r in result['remainingObligations']};assert baseline_ids<ids and len(ids)==16936 and 'NEWS:CN-NEWS-d7e10972978590af' in ids
write(work/'planned-entire-current-manifest-v2.json',manifest)
write(work/'planned-remaining-obligation-ids-v2.json',sorted(ids))
write(work/'planned-context-current-pin-rebindings-v2.json',{'originalEntireManifest':prior_ref,'allOld63ScopesDatesAndEvidencePreserved':True,'currentInputRevision':revision,'changedContexts':updates})
write(work/'publication-plan-governance-and-prior-universe-retention-v2.json',{'atUtc':now(),'status':'PASS_PLANNED_INDEX_ONLY_CURRENT_CHECK_RUNNING_NOT_ROOT_PUBLISHED_OR_RULE_CERTIFIED',
    'oldReviews':148,'currentReviews':149,'oldContexts':63,'currentContexts':64,'oldGates':241,'currentGates':245,'allOldGateRecordsExact':True,
    'oldSourceDeltas':6,'currentSourceDeltas':7,'allOldSixDeltasExact':True,'oldObligations':16927,'currentObligations':16936,'allOldIdsRetained':True,
    'addedObligationIds':sorted(ids-baseline_ids),'allOriginal1740Printings14293BlocksEn8GapCn236DispositionsAnd20NewsDocumentsRetained':True,
    'newSourceOnlyObservationScope21OriginalCertificationScope16Exact':True,'newRuntimeOrWholeCardSemanticCertification':False,'governanceValid':True,'errors':result['errors']})
print('PLANNED_CANONICAL_INDEX_RETENTION_VALID_NOT_YET_ROOT_PUBLISHED',len(ids),len(manifest['reviewContexts']),flush=True)
