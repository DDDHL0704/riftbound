from pathlib import Path
import datetime, gzip, hashlib, json, re, shutil, subprocess

root=Path('/Users/dinghaolin/MyProjects/riftbound')
w=Path(__file__).resolve().parent
w37=root/'var/qa/reksai-exhausted-confirmation-current-cn16-20261021'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def pin(p):return {'path':str(p.relative_to(root)),'sha256':sha(p)}
def write(p,value):
    with p.open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')

projects=[
 (w,'independent-reader-source-v1','independent-reader-frozen-inputs-v1.json'),
 (w,'independent-reader-source-v2','independent-reader-frozen-inputs-v2.json'),
 (w,'diagnose-structural-source-v1','diagnose-structural-frozen-inputs-v1.json'),
 (w,'diagnose-structural-source-v2','diagnose-structural-frozen-inputs-v2.json'),
 (w,'diagnose-structural-source-v3','diagnose-structural-frozen-inputs-v3.json'),
 (w,'affected-pair-source-v1','affected-pair-frozen-inputs-v1.json'),
 (w,'fixed2b83-native-history-reader-source-v1','fixed2b83-native-history-reader-frozen-v1.json'),
 (w37,'current-four-exhausted-legend-prototype-source-v1','current-four-exhausted-legend-prototype-frozen-inputs-v1.json'),
 (w37,'current-four-exhausted-legend-reader-source-v1','current-four-exhausted-legend-reader-frozen-inputs-v1.json')
]
finished=[
 w/'actual-current-four-field-damage-sql-owner-terminal-v2.json',
 w/'affected-original20-owner-terminal-v1.json',
 w/'original-current-sql-structural-and-full-replay-rejection-diagnosis-v3.json',
 w/'current-fixed2b83-ci-native-combined-subscope-readback-v1.json',
 w37/'current-four-exhausted-legend-combined-writer-and-resumed-reader-v2.json'
]
assert all(p.is_file() for p in finished)
processes=subprocess.check_output(['ps','-axo','pid=,command='],text=True)
pending=[];rows=[];verification=[]
for base,name,receipt_name in projects:
    source=base/name;receipt=base/receipt_name;r=load(receipt)
    runtime=Path(r['runtimeRoot'])
    assert not any(str(source) in line and ('dotnet' in line or 'testhost' in line) for line in processes.splitlines())
    sources=r.get('sourceHashes',r.get('prototypeSources',{}))
    own_sources={p:h for p,h in sources.items() if (base/p).parent==source}
    assert own_sources
    for p,h in own_sources.items():assert sha(base/p)==h,p
    runtime_files=r.get('runtimeFiles',r.get('files'))
    assert isinstance(runtime_files,dict)
    for p,h in runtime_files.items():assert sha(runtime/p)==h,p
    project=list(source.glob('*.csproj'));assert len(project)==1
    assembly=r.get('assembly') or re.search(r'<AssemblyName>([^<]+)</AssemblyName>',project[0].read_text()).group(1)
    for suffix in ['.dll','.pdb']:
        name_in_runtime=assembly+suffix
        assert name_in_runtime in runtime_files
        matches=list((source/'bin').rglob(name_in_runtime))
        assert matches and all(sha(p)==runtime_files[name_in_runtime] for p in matches)
    kept=[pin(p) for p in source.iterdir() if p.is_file()]
    verification.append({'sourceProject':str(source.relative_to(root)),'frozenReceipt':pin(receipt),'allActualFrozenRuntimeFileHashesExact':True,'compiledAssemblyAndPdbMatchFrozenExecutedPayload':True,'allHandwrittenSourceHashesExactAndRetained':kept})
    for folder in ['bin','obj']:
        d=source/folder;assert d.is_dir() and not d.is_symlink()
        pending.append(d)
        for p in sorted(d.rglob('*')):
            if p.is_file():
                assert not p.is_symlink()
                rows.append({'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':sha(p)})
assert len(pending)==18
listing=w/'completed-helper-generated-staging-original-file-manifest-v1.json.gz'
listing.write_bytes(gzip.compress(json.dumps({'atUtc':now(),'files':rows},ensure_ascii=False,indent=2).encode(),mtime=0))
write(w/'completed-helper-generated-staging-predeletion-verification-v1.json',{'atUtc':now(),'completedExecutionReceipts':[pin(p) for p in finished],'verification':verification,'originalFileManifest':pin(listing),'onlyGeneratedDirectories':[str(p.relative_to(root)) for p in pending]})
for d in pending:shutil.rmtree(d)
assert all(not d.exists() for d in pending)
for base,name,receipt_name in projects:
    source=base/name
    assert all(sha(base/p)==h for p,h in load(base/receipt_name).get('sourceHashes',load(base/receipt_name).get('prototypeSources',{})).items() if (base/p).parent==source)
write(w/'completed-helper-generated-staging-retirement-v1.json',{'atUtc':now(),'status':'ONLY_COMPLETED_GENERATED_BIN_OBJ_REMOVED_ALL_EXECUTED_FROZEN_PAYLOADS_HANDWRITTEN_SOURCES_FAILURES_AND_RESULTS_RETAINED','projects':9,'directories':18,'files':len(rows),'logicalBytes':sum(p['bytes'] for p in rows),'originalFileManifest':pin(listing),'predeletionVerification':pin(w/'completed-helper-generated-staging-predeletion-verification-v1.json'),'noPhysicalApfsReclaimInferred':True,'rootBuildsAppsInstallersRuntimeDirectoriesOfficialSourcesAndDatabasesUntouched':True})
print('Retired completed helper staging:',len(rows),'files,',sum(p['bytes'] for p in rows),'logical bytes;18 bin/obj directories;all nine executed DLL/PDBs and source originals verified and retained.')
