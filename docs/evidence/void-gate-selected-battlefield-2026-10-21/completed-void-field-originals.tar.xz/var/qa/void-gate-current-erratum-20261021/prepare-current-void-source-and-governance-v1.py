from pathlib import Path
import copy, datetime, gzip, hashlib, importlib.util, json, urllib.request

root=Path('/Users/dinghaolin/MyProjects/riftbound')
w=Path(__file__).resolve().parent
w36=root/'var/qa/nocturne-optional-current-cn16-20261021'
load=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p,value):
    with p.open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
def pin(p):return {'path':str(p.relative_to(root)),'sha256':sha(p)}

manifest=load(root/'docs/audit/current-manifest.json')
reviews=load(root/manifest['inputs']['reviews']['path'])
assert len(reviews['reviews'])==154 and len(manifest['reviewContexts'])==69
assert len(manifest['acceptanceGates'])==245 and len(manifest['laterSourceDeltas'])==7
stale=load(w/'current-implementation-context-hash-differences-prepublication-v1.json')
assert stale['oldManifestSha256']==sha(root/'docs/audit/current-manifest.json') and len(stale['records'])==44
prior=w/'prior-coherent-publication-governance-v1';prior.mkdir(exist_ok=True)
for p in [root/'docs/audit/current-manifest.json',root/manifest['inputs']['reviews']['path'],root/'docs/PROJECT_STATUS.md']:
    q=prior/(p.name+'.gz')
    if q.exists():assert gzip.decompress(q.read_bytes())==p.read_bytes()
    else:q.write_bytes(gzip.compress(p.read_bytes(),mtime=0))
originals=[{'id':r['id'],'oldCompleteContext':copy.deepcopy(manifest['reviewContexts'][r['id']]),'changes':r['changes']} for r in stale['records']]
(prior/'forty-four-complete-current-contexts-before-refresh.json.gz').write_bytes(gzip.compress(json.dumps(originals,ensure_ascii=False,indent=2).encode(),mtime=0))
spec=importlib.util.spec_from_file_location('governance',root/'scripts/audit/check-project-governance.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
enumeration=copy.deepcopy(manifest)
enumeration['inputs']['active']['sha256']=sha(root/manifest['inputs']['active']['path'])
before=mod.current_audit(root,enumeration)
assert len(before['remainingObligations'])==16962
(prior/'remaining-obligation-ids.json.gz').write_bytes(gzip.compress(json.dumps([r['id'] for r in before['remainingObligations']],ensure_ascii=False).encode(),mtime=0))
write(prior/'prepublication-index-observation.json',{'atUtc':now(),'obligations':16962,'reviews':154,'contexts':69,'gates':245,'sourceDeltas':7,'errorsBeforeRequiredCurrentInputRefresh':before['errors'],'activeCurrentHashUsedOnlyInReadOnlyTemporaryEnumerationCopy':True,'oldManifestNotMutated':True,'semanticCoverageCertified':False})

cn=load(root/manifest['inputs']['cn']['path'])
rows={c['id']:c for c in cn['cards']}
api='https://lol-api.playloltcg.com/xcx/card/searchCardCraftWeb'
intake={'startedAtUtc':now(),'region':'CN','language':'zh-CN','adoptedCoreEffectiveDate':'2026-10-16','cards':[]}
for identity in [31509,34751]:
    old=rows[identity]
    body={'pageNum':1,'pageSize':100,'searchContent':old['cardName'],'cardCategoryList':[],'cardColorList':[],'rarityList':[],'productCodeList':[]}
    at=now()
    req=urllib.request.Request(api,data=json.dumps(body,ensure_ascii=False).encode(),headers={'Content-Type':'application/json','User-Agent':'Riftbound-source-audit/1.0'},method='POST')
    with urllib.request.urlopen(req,timeout=45) as response:raw=response.read();status=response.status
    parsed=json.loads(raw)
    def find(value):
        if isinstance(value,dict):
            if value.get('id')==identity and 'cardNo' in value:return [value]
            return [r for v in value.values() for r in find(v)]
        if isinstance(value,list):return [r for v in value for r in find(v)]
        return []
    matches=find(parsed);assert len(matches)==1
    row=matches[0];assert row==old,identity
    p=w/f'{identity}-current-adjacent-exact-original-api-v1.json.gz'
    with p.open('xb') as f:f.write(gzip.compress(raw,mtime=0))
    intake['cards'].append({'url':api,'request':body,'attemptedAtUtc':at,'receivedAtUtc':now(),'httpStatus':status,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'compressedOriginal':pin(p),'exactApiId':identity,'exactPrinting':row['cardNo'],'exactRow':row,'allOriginalKeysValuesAndNullsEqualPriorCn16Raw':True,'publicationDate':None,'effectiveDate':None})
intake.update(finishedAtUtc=now(),noNewLiveSourceVersion=True,allKnownSourceDatesPreserved=True)
write(w/'current-two-adjacent-selected-field-source-intake-v1.json',intake)

corpus=load(root/manifest['inputs']['corpus']['path'])
records={r['id']:r for r in corpus['records']}
rules=['DOC-01-P044-B022','DOC-01-P044-B023','DOC-16-P012-B006','DOC-16-P012-B007']
bounded_damage=[f'DOC-01-P106-B{n:03}' for n in range(9,16)]
open_damage=[f'DOC-01-P106-B{n:03}' for n in range(16,19)]
assert all(r in records for r in rules+bounded_damage+open_damage)
void=load(w36/'supporting-void-field-exact-provenance-and-open-disposition-v1.json')
check=load(w/'check-original-case-method-and-input-retention-v2.json')
sql=load(w/'actual-current-four-field-damage-sql-owner-terminal-v2.json')
assert check['actualCases']==13238 and check['passed']==13237 and check['failed']==1
assert sql['commands']==12 and sql['events']==29
branches=[
 {'id':'void-exact-existing-official-erratum-runtime-adoption','sourceRefs':['OGN-296/298','DOC-16-P012-B006','DOC-16-P012-B007']},
 {'id':'void-targeted-unit-spell-local-bonus','sourceRefs':['OGN-296/298','UNL-007/219','DOC-01-P106-B014']},
 {'id':'void-selected-battlefield-group-spell-local-bonus','sourceRefs':['OGN-296/298','OGS-002/024','DOC-01-P044-B022','DOC-01-P044-B023','DOC-16-P012-B006']},
 {'id':'firestorm-other-battlefield-only-its-enemy-occupants-base-three','sourceRefs':['OGS-002/024','OGN-296/298','DOC-01-P044-B022','DOC-16-P012-B006']},
 {'id':'firestorm-empty-real-battlefield-without-damage','sourceRefs':['OGS-002/024','DOC-01-P044-B022','DOC-01-P044-B023']},
 {'id':'firestorm-exactly-one-real-battlefield-atomic-invalid-intent','sourceRefs':['OGS-002/024','DOC-01-P044-B022','DOC-01-P044-B023']},
 {'id':'selected-field-damage-current-identity-full-frame-and-original-replay-forgery-rejection','sourceRefs':['OGS-002/024','UNL-007/219','OGN-296/298','DOC-16-P012-B006']}
]
scope={'atUtc':now(),'status':'BOUNDED_CURRENT_CN16_VOID_EXISTING_ERRATUM_ADOPTION_AND_ONE_SELECTED_BATTLEFIELD_FIRESTORM_DAMAGE_BRANCH_REVIEW','region':'CN','language':'zh-CN','observedAsOf':'2026-10-21','adoptedCoreEffectiveDate':'2026-10-16','subjectPrintings':['OGN-296/298','OGS-002/024','UNL-007/219'],'adjacentSelectedFieldConsumersRegressionOnly':['OGN-266/298','UNL-198/219'],'ruleRecords':rules+bounded_damage,'pendingRuleRecords':open_damage,'exactOriginalRuleTextHashes':{r:hashlib.sha256(records[r]['text'].encode()).hexdigest() for r in rules+bounded_damage+open_damage},'currentSourceEvidence':[pin(p) for p in [w/'current-finite-void-and-second-legend-source-intake-v1.json',w/'current-two-adjacent-selected-field-source-intake-v1.json',w36/'supporting-void-field-exact-provenance-and-open-disposition-v1.json',w36/'supporting-void-field-current-primary-errata-readback-v1.json']],'primarySources':[{k:v for k,v in doc.items() if k not in ['pages']} for doc in corpus['documents'] if doc['id'] in ['DOC-01','DOC-16']],'completePhysicalPagesActuallyViewed':[{'document':'DOC-01','page':n,**pin(w/f'current-core-{label}-p{n}.png')} for n,label in [(44,'selected-objects'),(106,'damage')]]+[{'document':'DOC-16','page':12,**void['physicalWholePageActuallyViewed']}],'noNewOfficialSourceVersionDiscovered':True,'officialSourceDeltaCountRemainsSeven':True,'existingOldSourceGapObjectRetainedUnchanged':'supporting-void-gate-current-official-erratum-not-yet-adopted','runtimeAdoption':load(w/'exact-void-current-catalog-adoption-v1.json'),'sourceOverlayCounterexample':pin(w/'current-void-gate-source-adoption-parser-regression-original-proof-v1.json'),'boundedBehaviorBranches':branches,'interpretationBoundary':'355.5 requires one battlefield selected by Firestorm; enemy units there are affected occupants, not unit targets. Current erratum is location-based, including this bounded group spell. Empty/other battlefield and invalid selection are separately executed.','openDamageSemanticReview':'715.3 distribution, 715.4 absence of a damage action versus evaluated zero, 715.4.a prevention/replacement, all other spell and ability consumers remain OPEN. No unverified zero-damage issue asserted.','exclusions':['Whole printings and all extra damage, skills, prevention, replacement, distribution and zero-action branches','Exhausted Reksai two printings and both confirmation orders remain the next separate batch','All prior finite observation consumers, source gaps and complete 1740 printing /14293 rule universe','Current new fixed full, visible hardware controls and paired clients, physical Windows and final-candidate product acceptance'],'actualRuleInputs':sql['actualRuleInputs'],'noOldDevelopmentMatchMigration':True,'wholePrintingOrGlobalCertification':False}
write(w/'current-void-and-selected-battlefield-exact-source-scope-review-v1.json',scope)
print('Prior154 reviews/69contexts/16962 obligations retained;44 full contexts archived;two adjacent exact API rows unchanged;seven bounded branches and explicit open damage semantics.')
