#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
int main(void){
int log=open("/Users/dinghaolin/MyProjects/riftbound/var/qa/void-gate-current-erratum-20261021/client-a.log",O_WRONLY|O_CREAT|O_APPEND,0600);if(log<0)return 125;dup2(log,1);dup2(log,2);close(log);
char *const args[]={"/Users/dinghaolin/MyProjects/riftbound/var/qa/void-gate-current-erratum-20261021/Riftbound-A.app/Contents/MacOS/符文战场","--resolution","1280x720","--position","0,30","--","--riftbound-server=http://127.0.0.1:15847","--riftbound-session-file=/Users/dinghaolin/MyProjects/riftbound/var/qa/void-gate-current-erratum-20261021/session-a.json","--riftbound-smoke-connect-only",0};execv(args[0],args);perror("execv native QA client");return 126;}
