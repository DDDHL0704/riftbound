import ast,datetime,fcntl,hashlib,json,os,plistlib,resource,socket,subprocess
from pathlib import Path

resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();load=lambda p:json.loads(p.read_text())
definition=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py';nodes=[n for n in ast.parse(definition.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(definition),'exec'),globals())
pub=load(w/'current-integrated-sql-frozen-inputs-v2.json');runtime=Path(pub['runtimeRoot']);reader=load(w/'independent-reader-frozen-inputs-v2.json');rr=Path(reader['runtimeRoot']);identity=load(w/'current-integrated-actual-rule-inputs-v2.json')
prior=load(w/'actual-current-four-field-damage-sql-owner-terminal-v1.json');assert prior['status'].startswith('FAILED_OR_INTERRUPTED') and prior['allOriginal262AuditSevenTablesExactAtStop'] and prior['allOriginal56NativeSevenTablesExactAtStop'] and prior['ownPostgresSmartStopped']
def frozen():
 for directory,files in [(runtime,pub['runtimeFiles']),(rr,reader['runtimeFiles'])]:assert all(sha(directory/p)==h for p,h in files.items())
 assert all(sha(root/p)==h and oct((root/p).stat().st_mode&0o777)==pub['sourceInputModes'][p] for p,h in pub['sourceInputHashes'].items())
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
terminal=w/'actual-current-four-field-damage-sql-owner-terminal-v2.json';assert not terminal.exists()
proof={'status':'RUNNING_CURRENT_FOUR_FIELD_DAMAGE_REAL_SQL','startedAtUtc':now(),'parentCommit':pub['parentCommit'],'actualRuleInputs':identity,'includesDeclaredUncommittedChanges':True,'lockAtStart':observe_lock(),'originalsAndEveryPriorRoomRetainedWithoutMigration':True}
power=writer=independent=None;started=False;audit=native=None;before_audit=before_native=None
try:
 frozen();assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid
 sock.mkdir(exist_ok=True);subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'current-field-damage-postgres-v2.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 audit=rooms('riftbound_acceptance');native=rooms('riftbound_here_native')
 assert audit==prior['actualAuditRoomsAtStop'] and len(audit)==263 and native==prior['actualNativeRoomsAtStop'] and len(native)==56
 before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',native)
 (w/'original263-audit56-native-seven-table-baseline-v2.json').write_text(json.dumps({'atUtc':now(),'auditRooms':audit,'nativeRooms':native,'auditSevenTables':before_audit,'nativeSevenTables':before_native},indent=2)+'\n')
 output=w/'actual-current-four-field-damage-sql-v2';assert not output.exists()
 env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit',RIFTBOUND_POSTGRES_EVIDENCE=str(output),DOTNET_DbgEnableMiniDump='0')
 command=['/Users/dinghaolin/.dotnet/dotnet',str(runtime/'Riftbound.PostgresAcceptance.dll'),'--battlefield-spell-damage-only'];proof['actualWriterCommand']=command
 with (w/'actual-current-field-damage-writer-v2.log').open('xb') as log:writer=subprocess.Popen(command,cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT);proof['writerExitCode']=writer.wait(timeout=300);assert proof['writerExitCode']==0
 branches=['targeted-unit','group-void','group-other','group-empty'];receipts=[load(output/'battlefield-spell-damage'/b/'receipt.json') for b in branches]
 assert all(c['status']=='REAL_SQL_CURRENT_VOID_ERRATUM_SELECTED_BATTLEFIELD_DAMAGE' and c['actualRuleInputs']==identity and c['commands']==c['coldRecoveries']==3 for c in receipts)
 added={c['room'] for c in receipts};assert len(added)==4 and set(rooms('riftbound_acceptance'))==set(audit)|added and rooms('riftbound_here_native')==native
 proof.update(writerCases=4,receipts=receipts,commands=sum(c['commands'] for c in receipts),events=sum(c['events'] for c in receipts),coldRecoveries=sum(c['coldRecoveries'] for c in receipts),directAtomicRejections=sum(c['directAtomicRejections'] for c in receipts),writerIndependentStructuralRejections=sum(c['independentStructuralRejections'] for c in receipts),newRooms=sorted(added))
 print('FOUR_CURRENT_FIELD_DAMAGE_REAL_SQL_WRITER_PASS',proof['commands'],proof['events'],flush=True)
 result=w/'independent-current-four-field-damage-all-history-v2.json'
 command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(rr/'Riftbound.PostgresAcceptance.deps.json'),'--runtimeconfig',str(rr/'Riftbound.PostgresAcceptance.runtimeconfig.json'),str(rr/(reader['assembly']+'.dll')),str(output),str(result)];proof['actualReadOnlyReaderCommand']=command
 with (w/'independent-current-field-damage-all-history-v2.log').open('xb') as log:independent=subprocess.Popen(command,cwd=rr,env=env,stdout=log,stderr=subprocess.STDOUT);proof['independentExitCode']=independent.wait(timeout=300);assert proof['independentExitCode']==0
 actual=load(result);proof['independentReadback']=actual;assert actual['actualReadOnlyConnection'] and set(actual['rooms'])==added and actual['actualRuleInputs']==identity and actual['commands']==proof['commands']==actual['authoritativeHistoricalStates'] and actual['events']==proof['events'] and actual['independentStructuralRejections']==36
 proof['status']='PASS_CURRENT_FOUR_FIELD_DAMAGE_REAL_JSONB_COLD_DEDUP_INDEPENDENT_ALL_HISTORY_EVERY_ORIGINAL_REPLAY';print(proof['status'],flush=True)
except BaseException as e:
 proof.update(status='FAILED_OR_INTERRUPTED_CURRENT_FIELD_DAMAGE_ORIGINALS_AND_ROOMS_RETAINED',errorType=type(e).__name__,error=str(e));raise
finally:
 for process in [writer,independent]:
  if process is not None and process.poll() is None:process.terminate();process.wait(timeout=20)
 if started:
  if before_audit is not None:
   proof['allOriginal263AuditSevenTablesExactAtStop']=digests('riftbound_acceptance',audit)==before_audit;proof['allOriginal56NativeSevenTablesExactAtStop']=digests('riftbound_here_native',native)==before_native;proof['actualAuditRoomsAtStop']=rooms('riftbound_acceptance');proof['actualNativeRoomsAtStop']=rooms('riftbound_here_native')
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None:
  if power.poll() is None:power.terminate();power.wait(timeout=10)
  proof['boundIdleAssertionEnded']=power.poll() is not None
 frozen();proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),frozenRuntimeAndAll3325SourceInputsStable=True);terminal.write_text(json.dumps(proof,indent=2)+'\n');fcntl.flock(guard,fcntl.LOCK_UN)
assert proof['allOriginal263AuditSevenTablesExactAtStop'] and proof['allOriginal56NativeSevenTablesExactAtStop'] and proof['ownPostgresSmartStopped']
