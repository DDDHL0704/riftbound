from pathlib import Path
import concurrent.futures,datetime,hashlib,json,os,subprocess,time,zipfile
os.umask(0o077);w=Path(__file__).resolve().parent;run=39539455481;fixed='646783cc05bb48ce19d69fc1c2fff50969438134'
raw=subprocess.check_output(['gh','api',f'repos/DDDHL0704/riftbound/actions/runs/{run}/artifacts']);metadata=json.loads(raw);(w/'ci-64678-complete-backend-artifact-metadata-v1.json').write_bytes(raw)
folder=w/'ci-64678-complete-originals-v1';folder.mkdir();names=['conformance-results']+['postgres-partition-'+str(i) for i in range(4)]+['postgres-results','native-network-results','full-verification-gate','verification-scope']
def download(name):
 a=next(a for a in metadata['artifacts'] if a['name']==name);assert not a['expired'] and a['workflow_run']['head_sha']==fixed;p=folder/(name+'.zip');attempts=[]
 for index in range(3):
  target=p if index==0 else folder/(name+'-attempt-'+str(index+1)+'.zip')
  with target.open('xb') as out:
   result=subprocess.run(['gh','api',f'repos/DDDHL0704/riftbound/actions/artifacts/{a["id"]}/zip'],stdout=out,stderr=subprocess.PIPE);attempts.append({'attempt':index+1,'exitCode':result.returncode,'path':str(target),'bytes':target.stat().st_size});(folder/(name+'-attempt-'+str(index+1)+'.stderr')).write_bytes(result.stderr)
  if result.returncode==0:break
  time.sleep(1)
 assert result.returncode==0
 digest=hashlib.sha256(target.read_bytes()).hexdigest();assert target.stat().st_size==a['size_in_bytes'] and a['digest']=='sha256:'+digest
 with zipfile.ZipFile(target) as z:assert z.testzip() is None
 row={'name':name,'id':a['id'],'path':str(target.relative_to(w.parents[2])),'bytes':target.stat().st_size,'sha256':digest,'backendDigest':a['digest'],'allZipCrcVerified':True,'attempts':attempts};print(name,'ORIGINAL_BACKEND_SIZE_SHA256_CRC_PASS',flush=True);return row
rows=[]
try:
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
  for result in pool.map(download,names):rows.append(result)
finally:
 (w/'ci-64678-original-artifacts-download-receipt-v1.json').write_text(json.dumps({'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runId':run,'fixedCommit':fixed,'artifacts':rows,'bothSupersededNativePackagesNotRedownloaded':True},indent=2)+'\n')
assert len(rows)==9
