import ast,datetime,hashlib,json,os,plistlib,resource,subprocess,time
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CORE,(0,0));root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
pub=load(w/'affected-pair-frozen-inputs-v1.json');runtime=Path(pub['runtimeRoot']);terminal=w/'affected-original20-owner-terminal-v1.json';assert not terminal.exists()
definition=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py';node=next(n for n in ast.parse(definition.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='observe_lock');exec(compile(ast.Module(body=[node],type_ignores=[]),str(definition),'exec'),globals())
def frozen():
 assert all(sha(runtime/p)==h for p,h in pub['runtimeFiles'].items())
 assert all(sha(root/p)==h and oct((root/p).stat().st_mode&0o777)==pub['sourceInputModes'][p] for p,h in pub['sourceInputHashes'].items())
proof={'status':'RUNNING_CURRENT20_ORIGINAL_VOID_PAIRS_NOT_FULL110','startedAtUtc':now(),'lockAtStart':observe_lock(),'actualRuleInputs':pub['actualRuleInputs'],'allOriginalNineFullSourcesRetained':True};power=process=None;started=time.monotonic()
try:
 frozen();power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid
 output=w/'affected-original20-current-result-v1.json';command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(runtime/'Riftbound.PostgresAcceptance.deps.json'),'--runtimeconfig',str(runtime/'Riftbound.PostgresAcceptance.runtimeconfig.json'),str(runtime/(pub['assembly']+'.dll')),str(output)];proof['actualCommand']=command
 env=dict(os.environ,DOTNET_DbgEnableMiniDump='0')
 for key in list(env):
  if key.startswith('ConnectionStrings__') or key.startswith('RIFTBOUND_') and 'EVIDENCE' in key:env.pop(key)
 with (w/'affected-original20-current-v1.log').open('xb') as log:process=subprocess.Popen(command,cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT);proof['ownedHelperPid']=process.pid;proof['exitCode']=process.wait(timeout=7200);assert proof['exitCode']==0
 result=load(output);assert result['status']=='PASS_CURRENT20_ORIGINAL_VOID_GATE_PAIR_HELPERS_NOT_ALL110_PUBLIC_METHOD_OR_FULL_CI' and len(result['completed'])==20 and result['seed']==424242 and result['originalDeckCount']==11 and result['originalFullMatrixPairCount']==110 and result['affectedDecks']==['kaisa-red-control']
 assert {key:result['actualRuleInputs'][key[0].upper()+key[1:]] for key in pub['actualRuleInputs']}==pub['actualRuleInputs']
 proof.update(status=result['status'],completedPairs=20,originalSeedAndVictoryReplayAssertionsExecuted=True,whole110OrFullCi=False)
except BaseException as e:proof.update(status='FAILED_OR_INTERRUPTED_CURRENT20_ORIGINAL_VOID_PAIR_RUN',errorType=type(e).__name__,error=str(e));raise
finally:
 if process is not None and process.poll() is None:process.terminate();process.wait(timeout=20)
 if power is not None and power.poll() is None:power.terminate();power.wait(timeout=10)
 frozen();proof.update(finishedAtUtc=now(),seconds=round(time.monotonic()-started,2),lockAtEnd=observe_lock(),allFrozenRuntimeAnd3325SourcesStable=True,boundIdleAssertionEnded=power is not None and power.poll() is not None);terminal.write_text(json.dumps(proof,indent=2)+'\n')
print(proof['status'],flush=True)
