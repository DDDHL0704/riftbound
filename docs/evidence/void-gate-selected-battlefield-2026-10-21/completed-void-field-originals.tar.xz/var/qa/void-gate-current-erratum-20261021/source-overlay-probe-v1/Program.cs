using System.Text.Json;
using Riftbound.CardCatalog;
using Riftbound.Contracts;
using Riftbound.Engine;

if(args.Length!=1||File.Exists(args[0]))throw new Exception("Fresh bounded source-overlay evidence required.");
var json=new JsonSerializerOptions(JsonSerializerDefaults.Web){WriteIndented=true};
var catalog=await OfficialCardCatalog.LoadDefaultAsync();var field=catalog.Cards.Single(c=>c.Id==31542);
var parsed=RuleTextParser.Parse(field);var steps=new List<object>();
var state=new MatchState("VOID-OFFICIAL-ERRATUM-PROBE",0,3,"P1",new Dictionary<string,string>{{"P1","P1"},{"P2","P2"}},status:MatchStatuses.InProgress,turnPlayerId:"P1",phase:MatchPhases.Main,timingState:TimingStates.NeutralOpen,
    runePools:new Dictionary<string,RunePool>{{"P1",new(20,20)},{"P2",new(20,20)}},
    playerZones:new Dictionary<string,PlayerZones>{{"P1",PlayerZones.Empty with {Hand=["SPELL"],Battlefields=["HILL"]}},{"P2",PlayerZones.Empty with {Battlefields=["OTHER","UNIT"]}}},
    cardObjects:new Dictionary<string,CardObjectState>{
        ["HILL"]=new("HILL",cardNo:"OGN·296/298",tags:[P6TokenFactoryCatalog.BattlefieldCardTag],ownerId:"P1",controllerId:"P2"),
        ["OTHER"]=new("OTHER",cardNo:"OGN·275/298",tags:[P6TokenFactoryCatalog.BattlefieldCardTag],ownerId:"P2",controllerId:"P2"),
        ["UNIT"]=new("UNIT",cardNo:"SFD·069/221",power:8,tags:[CardObjectTags.UnitCard],ownerId:"P2",controllerId:"P2"),
        ["SPELL"]=new("SPELL",cardNo:"UNL-007/219",tags:[CardObjectTags.SpellCard],ownerId:"P1",controllerId:"P1")},
    objectLocations:new Dictionary<string,ObjectLocationState>{{"HILL",new("P1","BATTLEFIELD","HILL")},{"OTHER",new("P2","BATTLEFIELD","OTHER")},{"UNIT",new("P2","BATTLEFIELD","HILL")},{"SPELL",new("P1","HAND")}});
var initial=state;var engine=new CoreRuleEngine();
await Act("P1",new PlayCardCommand("SPELL","UNL-007/219",["UNIT"]));
for(var i=0;i<2;i++)await Act(state.PriorityPlayerId!,new PassPriorityCommand());
var actual=state.CardObjects["UNIT"].Damage;
await File.WriteAllTextAsync(args[0],JsonSerializer.Serialize(new{
    status=actual==4?"CURRENT_OLD_TEXT_SOURCE_BUILT_BASELINE_DAMAGE4":"CURRENT_OFFICIAL_NEW_TEXT_WITH_UNCHANGED_PARSER_DAMAGE_REGRESSION",
    exactApiId=31542,exactPrinting=field.CardNo,effectiveCardText=field.CardEffect,parserStaticAbilities=parsed.StaticAbilities,
    expectedBaseSpellDamage=3,expectedCurrentOfficialBattlefieldBonus=1,expectedDamage=4,actualDamage=actual,
    actualRuleInputs=RuleInputIdentity.Current,originalExplicitControlledInitial=initial,allAcceptedSteps=steps,finalState=state,
    onlySourceOverlayNotRootIntegration=true,wholePrintingOrProductCertification=false},json));
Console.WriteLine($"VOID_OFFICIAL_EFFECT_PARSER_AND_DAMAGE actual={actual} expected=4 parsedStaticAbilities={parsed.StaticAbilities.Count}");
if(actual!=4)throw new Exception("Official current effect requires damage3+bonus1; current parser does not preserve the official rule after source adoption.");
async Task Act(string actor,GameCommand command)
{
    var raw=JsonSerializer.SerializeToElement(command,command.GetType(),json);var result=await engine.ResolveAsync(state,new("void-source-"+steps.Count,actor,command.CmdType),command,default);
    if(!result.Accepted)throw new Exception(result.ErrorMessage);state=result.State;steps.Add(new{actor,rawCommand=raw,result});
}
