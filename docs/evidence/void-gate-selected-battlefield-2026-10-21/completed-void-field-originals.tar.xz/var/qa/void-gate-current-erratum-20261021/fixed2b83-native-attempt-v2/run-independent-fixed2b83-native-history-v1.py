from pathlib import Path
import datetime, hashlib, json, os, resource, shutil, subprocess, time

resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
os.umask(0o077)
w = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
load = lambda p: json.loads(p.read_text())
pub = load(w / 'frozen-fixed2b83-native-composition-v1.json')
old = Path(pub['helperRuntimeRoot'])
reader = load(w / 'fixed2b83-native-history-reader-frozen-v1.json')
r = Path(reader['runtimeRoot']); files = reader['runtimeFiles']
assert all(sha(r / p) == h for p, h in files.items())
dll = r / 'Fixed2b83NativeHistoryReaderV1.dll'
assert all(sha(old / p) == h for p, h in pub['helperRuntimeFiles'].items())
result = w / 'independent-fixed2b83-native-history-result-v1.json'
receipt = w / 'independent-fixed2b83-native-history-run-v1.json'
stop = w / 'live-current-ci-main-stop-v2.json'
assert not any(p.exists() for p in [result, receipt, stop])
command = ['/Users/dinghaolin/.dotnet/dotnet', 'exec', '--depsfile', str(r / 'Riftbound.Api.deps.json'), '--runtimeconfig', str(r / 'Riftbound.Api.runtimeconfig.json'), str(r / dll.name), str(w), str(result)]
proof = {'startedAtUtc': now(), 'fixedCommit': pub['fixedCommit'], 'fixedCiRun': pub['fixedCiRun'], 'actualRuleInputs': pub['actualRuleInputs'], 'command': command, 'readerRuntimeFiles': files, 'status': 'WAITING_FIXED_CI_EXPORTED_PAIR_AND_NORMAL_SCORE_ORIGINALS'}
try:
    ready_path = w / 'live-current-ci-main-ready-v2.json'
    until = time.monotonic() + 1500
    while not ready_path.exists():
        assert time.monotonic() < until and not (w / 'live-current-ci-main-owner-terminal-v2.json').exists()
        time.sleep(1)
    ready = load(ready_path)
    with (w / 'independent-fixed2b83-native-history-v1.log').open('xb') as log:
        code = subprocess.run(command, cwd=r, env=dict(os.environ, ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit', DOTNET_DbgEnableMiniDump='0'), stdout=log, stderr=subprocess.STDOUT, timeout=300).returncode
    proof['exitCode'] = code
    assert code == 0
    d = load(result)
    assert d['status'] == 'PASS_INDEPENDENT_FIXED2B83_CI_EXPORTED_NATIVE3_GATEWAY17_ALL_SQL_HISTORY_AND_NORMAL_SCORE_REPLAY_NOT_VISIBLE_OR_WINDOWS'
    assert d['room'] == ready['room'] and d['commands'] == ready['totalCommands'] == ready['originalGatewayPrefixCommands'] + 20
    assert d['events'] == ready['events'] and d['actualRuleInputs'] == pub['actualRuleInputs'] and d['nativeAcceptedGameplayCommands'] == 3 and d['gatewayContinuationCommands'] == 17 and d['winningScore'] == 8
    assert all(sha(r / p) == h for p, h in files.items()) and all(sha(old / p) == h for p, h in pub['helperRuntimeFiles'].items())
    proof.update(status=d['status'], allFrozenApiReaderAndOriginalHelperHashesStable=True, actualAllHistoryCounts=d['actualHistoricalPayloads'], resultSha256=sha(result))
    stop.write_text(json.dumps({'atUtc': now(), 'room': ready['room'], 'independentReadOnlyHistoryAndFullReplayPass': True, 'result': str(result), 'resultSha256': sha(result), 'commands': d['commands'], 'events': d['events'], 'normalGatewayContinuationCommands': 17, 'nativeAcceptedGameplayCommands': 3, 'currentWholeFullCiVisibleAndPhysicalWindowsAcceptance': 'OPEN'}, indent=2))
except BaseException as e:
    proof.update(status='FAILED_FIXED_CI_READ_ONLY_READER_ORIGINALS_RETAINED_NO_SQL_WRITER_RERUN', errorType=type(e).__name__, error=str(e))
    raise
finally:
    proof['finishedAtUtc'] = now()
    receipt.write_text(json.dumps(proof, indent=2))
print(proof['status'], flush=True)
