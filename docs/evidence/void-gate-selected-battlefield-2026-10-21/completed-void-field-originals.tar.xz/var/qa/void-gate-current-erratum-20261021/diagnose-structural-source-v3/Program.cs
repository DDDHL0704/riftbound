using System.IO.Compression;
using System.Text.Json;
using Riftbound.Engine;

if(args.Length!=2||File.Exists(args[1]))throw new Exception("Original checkpoint and fresh diagnosis required.");
var json=new JsonSerializerOptions(JsonSerializerDefaults.Web){WriteIndented=true};
using var zip=new GZipStream(File.OpenRead(args[0]),CompressionMode.Decompress);
var frame=JsonSerializer.Deserialize<MatchRecoveryFrame>(zip,json)!;var state=frame.AuthoritativeState!;var item=state.StackItems.Single();var rows=new List<object>();
var initial=JsonSerializer.Deserialize<MatchState>(File.ReadAllText(Path.Combine(Path.GetDirectoryName(args[0])!,"explicit-original-controlled-initial.json")),json)!;
var baselineReplay=await MatchActionLogReplayer.VerifyFinalStateAsync(initial,frame.Commands,state,new CoreRuleEngine(),default,frame.Events);if(!baselineReplay.IsMatch)throw new Exception("Original replay must pass before a forgery probe.");
foreach(var (name,bad) in new[]{("unit-to-field",item with {TargetObjectIds=["HILL"]}),("generation",item with {TargetGenerations=new Dictionary<string,long>{{"UNIT",-1}}}),("damage99",item with {DamageAmount=99}),("controller",item with {ControllerId="P2"}),("source",item with {SourceObjectId="ALLY"})})
{
    var errors=MatchRecoveryValidator.Validate(state.RoomId,frame.LastEventSequence,frame.Commands,frame.Events,frame.PlayerViews,state with {StackItems=[bad]},frame.CurrentTick,frame.SpectatorReplayFrame);
    var replay=await MatchActionLogReplayer.VerifyFinalStateAsync(initial,frame.Commands,state with {StackItems=[bad]},new CoreRuleEngine(),default,frame.Events);
    rows.Add(new{name,errors,structurallyRejected=errors.Count>0,replayRejected=!replay.IsMatch,replayErrors=replay.Errors});
    if(replay.IsMatch)throw new Exception("Original action log must reject altered expected state: "+name);
}
await File.WriteAllTextAsync(args[1],JsonSerializer.Serialize(new{originalCheckpoint=args[0],actualRuleInputs=RuleInputIdentity.Current,originalErrors=MatchRecoveryValidator.Validate(state.RoomId,frame.LastEventSequence,frame.Commands,frame.Events,frame.PlayerViews,state,frame.CurrentTick),rows,originalControlledInitialReplayPassed=baselineReplay.IsMatch,readOnlyOfflineNoDatabaseOrHistoryMutation=true},json));
foreach(var row in rows)Console.WriteLine(JsonSerializer.Serialize(row,json));
