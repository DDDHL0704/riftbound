import datetime, gzip, hashlib, json, os, shutil, subprocess
from pathlib import Path

root = Path('/Users/dinghaolin/MyProjects/riftbound')
w = Path(__file__).resolve().parent
old = root / 'var/qa/deck-play-ordered-observation-20261021'
load = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
receipt = w / 'superseded-fixed64678-native-pair-and-two-archives-retirement-v1.json'
assert not receipt.exists()
boot = load(w / 'current-native-headless-boot-verification.json')
inputs = load(w / 'native-app-inputs.json')
assert boot['status'] == 'CURRENT_FIXED_DEFAULT_MAIN_HEADLESS_BOOT_PASS'
assert boot['fixedCommit'] == inputs['fixedCommit'] == '2b83ed2e6243f9e73cd92269f549867f02ea98ea'
assert len(boot['records']) == len(inputs['apps']) == 2
for record in boot['records']:
    assert record['returnCode'] == 0 and record['all373OriginalCiManagedAndPckFilesStillExact'] and record['deepStrictSignaturePass']
for app in inputs['apps']:
    path = Path(app['app'])
    assert path.parent == w and path.is_dir()
    assert all(sha(path / p) == h for p, h in inputs['ciManagedAndPckPayloads'].items())
    subprocess.run(['/usr/bin/codesign', '--verify', '--deep', '--strict', str(path)], check=True, capture_output=True)
for archive in inputs['platformArchiveAndLogProof']:
    path = w / 'native-current' / (archive['platform'] + '-ci-artifact.zip')
    assert sha(path) == archive['outerSha256']
old_inputs = load(old / 'native-app-inputs.json')
assert old_inputs['fixedCommit'] == '646783cc05bb48ce19d69fc1c2fff50969438134'
for original_app in old_inputs['apps']:
    original_path = Path(original_app['app'])
    assert original_path.parent == old and all(sha(original_path / p) == h for p, h in old_inputs['ciManagedAndPckPayloads'].items())
targets = [old / 'Riftbound-A.app', old / 'Riftbound-B.app', old / 'native-current/mac-ci-artifact.zip', old / 'native-current/windows-ci-artifact.zip']
processes = subprocess.run(['/bin/ps', '-axo', 'pid=,comm='], check=True, capture_output=True, text=True).stdout
assert all(str(p) not in processes for p in targets)
files = {}
for target in targets:
    assert target.exists() and not target.is_symlink()
    for path in sorted(target.rglob('*')) if target.is_dir() else [target]:
        if path.is_symlink():
            files[str(path.relative_to(root))] = {'symlink': os.readlink(path)}
        elif path.is_file():
            stat = path.stat()
            files[str(path.relative_to(root))] = {'bytes': stat.st_size, 'sha256': sha(path), 'mode': oct(stat.st_mode & 0o777)}
manifest = w / 'superseded-fixed64678-native-original-file-manifest-v1.json.gz'
with gzip.open(manifest, 'xt', encoding='utf-8') as handle:
    json.dump({'atUtc': now(), 'files': files, 'retiredTargets': [str(p.relative_to(root)) for p in targets]}, handle, ensure_ascii=False, indent=2)
with gzip.open(manifest, 'rt', encoding='utf-8') as handle:
    assert json.load(handle)['files'] == files
for path in targets:
    if path.is_dir():
        shutil.rmtree(path)
    else:
        path.unlink()
assert all(not p.exists() for p in targets)
proof = {'atUtc': now(), 'status': 'LATEST_USABLE_FIXED2B83_REPLACES_ONLY_COMPLETED_FIXED64678_APPS_AND_ARCHIVES', 'newCommit': inputs['fixedCommit'], 'newCiRun': inputs['runId'], 'retiredTargets': [str(p.relative_to(root)) for p in targets], 'originalManifest': str(manifest.relative_to(w)), 'originalManifestSha256': sha(manifest), 'retiredFileOrSymlinkCount': len(files), 'retiredLogicalBytes': sum(v.get('bytes', 0) for v in files.values()), 'physicalBytesRecoveredNotInferred': True, 'newPairAndBothArchivesRetained': True, 'allSourcesTestsOfficialSnapshotsFrozenRuntimesFailuresAndOriginalDatabaseRetained': True, 'oldRuntimeBinariesNotClaimedStillRetained': True, 'visibleAndPhysicalWindowsAcceptance': 'OPEN'}
receipt.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
print(proof['status'], proof['retiredFileOrSymlinkCount'], proof['retiredLogicalBytes'])
