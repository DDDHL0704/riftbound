from pathlib import Path
import copy, datetime, gzip, hashlib, json, re, tarfile

root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
w36=root/'var/qa/nocturne-optional-current-cn16-20261021'
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p,value):
    with p.open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
def pin(p,role=None):
    r={'path':str(p.relative_to(root)),'sha256':sha(p)}
    if role:r['role']=role
    return r

check=load(w/'check-original-case-method-and-input-retention-v2.json')
sql=load(w/'actual-current-four-field-damage-sql-owner-terminal-v2.json')
source=load(w/'current-void-and-selected-battlefield-exact-source-scope-review-v1.json')
remediation=load(w/'post-only-check-exact-source-expectation-remediation-v1.json')
final_focus=load(w/'final-focus-after-exact-source-remediation-union-v1.json')
assert check['actualCases']==13238 and check['actualMethods']==7508 and check['passed']==13237 and check['failed']==1 and check['skipped']==0
assert remediation['focusedCases']==161 and remediation['focusedMethods']==153
assert final_focus['distinctCases']==306 and final_focus['distinctMethods']==217
assert sql['commands']==12 and sql['events']==29 and sql['writerCases']==4 and sql['ownPostgresSmartStopped']
assert sql['allOriginal263AuditSevenTablesExactAtStop'] and sql['allOriginal56NativeSevenTablesExactAtStop']
assert all(sha(root/p)==h for p,h in remediation['finalSourceHashes'].items())
mp=root/'docs/audit/current-manifest.json';manifest=load(mp);rp=root/manifest['inputs']['reviews']['path'];reviews=load(rp)
assert len(reviews['reviews'])==154 and len(manifest['reviewContexts'])==69
assert len(manifest['acceptanceGates'])==245 and len(manifest['laterSourceDeltas'])==7
prior=w/'prior-coherent-publication-governance-v1'
for p in [mp,rp,root/'docs/PROJECT_STATUS.md']:assert gzip.decompress((prior/(p.name+'.gz')).read_bytes())==p.read_bytes()
stale=json.loads(gzip.decompress((prior/'forty-four-complete-current-contexts-before-refresh.json.gz').read_bytes()))
assert len(stale)==44 and all(manifest['reviewContexts'][r['id']]==r['oldCompleteContext'] for r in stale)
old_manifest=copy.deepcopy(manifest);old_reviews=copy.deepcopy(reviews)
ev=root/'docs/evidence/void-gate-selected-battlefield-2026-10-21';ev.mkdir(exist_ok=False)
standalone={
 'check-original-case-method-and-input-retention.json':'check-original-case-method-and-input-retention-v2.json',
 'original-tests-sql-and-focus-retention.json':'original-tests-sql-and-final-focus-union-retention-v1.json',
 'post-only-check-source-expectation-remediation.json':'post-only-check-exact-source-expectation-remediation-v1.json',
 'final-focus-after-source-remediation-union.json':'final-focus-after-exact-source-remediation-union-v1.json',
 'current-exact-source-scope-review.json':'current-void-and-selected-battlefield-exact-source-scope-review-v1.json',
 'real-integrated-four-sql-terminal.json':'actual-current-four-field-damage-sql-owner-terminal-v2.json',
 'independent-all-history-and-original-replay.json':'independent-current-four-field-damage-all-history-v2.json',
 'full-structural-frame-and-replay-original-diagnosis.json':'original-current-sql-structural-and-full-replay-rejection-diagnosis-v3.json',
 'source-overlay-parser-original-counterexample.json':'current-void-gate-source-adoption-parser-regression-original-proof-v1.json',
 'affected-original20-terminal.json':'affected-original20-owner-terminal-v1.json',
 'prior64678-full-independent.json':'ci-64678-entire-full-independent-verification-v1.json',
 'prior64678-terminal-hash-comparison.json':'ci-64678-vs-f059-original-terminal-hash-comparison-v1.json',
 'preceding-fixed2b83-headless-ci-native-subscope.json':'current-fixed2b83-ci-native-combined-subscope-readback-v1.json',
 'latest-only-native-retirement.json':'superseded-fixed64678-native-pair-and-two-archives-retirement-v1.json',
 'completed64678-extraction-retirement.json':'ci-64678-completed-duplicate-extraction-retirement-v1.json',
 'completed-helper-staging-retirement.json':'completed-helper-generated-staging-retirement-v1.json'
}
for name,p in standalone.items():(ev/name).write_bytes((w/p).read_bytes())
focus=load(w/'original-tests-sql-and-final-focus-union-retention-v1.json')
focus.update(newMethodNames=check['addedMethods'],newConformanceCases=7,newConformanceMethods=3,distinctFocusCases=306,distinctFocusMethods=217,wholePrintingCertified=False,postOnlyCheckSourceExpectationCorrection=pin(ev/'post-only-check-source-expectation-remediation.json'))
write(ev/'focus-executed-distinct-scope.json',focus)
refresh={'atUtc':now(),'status':'FORTY_FOUR_CURRENT_IMPLEMENTATION_INPUT_BINDINGS_ONLY_REFRESH_OLD_COMPLETE_CONTEXTS_AND_EVIDENCE_RETAINED','records':[{'id':r['id'],'changes':r['changes']} for r in stale],'oldWholeObjectsRetainedAsOriginalArchiveMembers':True,'historicalVerificationSourcesSourceDatesScopesAndEvidenceNotRebound':True,'noSemanticPromotion':True}
write(ev/'forty-four-current-input-only-context-refresh.json',refresh)

members=[];excluded=[]
for p in sorted(w.rglob('*')):
    if not p.is_file():continue
    parts=p.relative_to(w).parts
    reason=None
    if any(x.endswith('.app') for x in parts) or 'native-current' in parts:reason='Only latest applications/platform installers retained locally without evidence-archive duplication'
    elif {'bin','obj'} & set(parts) or any('-runtime-' in x or '-identity-probe-' in x for x in parts[:-1]):reason='Actual fixed runtime payloads retained locally, hashes retained in frozen receipts'
    elif p.name=='publish-void-field-owner-v1.log':reason='Running publication stdout retained complete separately after publication'
    elif p.name.startswith('session-') or p.suffix=='.env':reason='Private operational launch/account profile retained locally'
    if reason:
        if p.name.startswith('session-') or p.name=='publish-void-field-owner-v1.log':excluded.append({'path':str(p.relative_to(root)),'reason':reason})
        continue
    members.append(p)
extra=[
 w36/'supporting-void-field-exact-provenance-and-open-disposition-v1.json',
 w36/'supporting-void-field-current-primary-errata-readback-v1.json',
 w36/'current-hand-supporting-exact-api-source-intake-v1.json',
 w36/'bone-current-primary-pages-v1/next-void-field-errata-p12.png'
]
members.extend(extra)
safe=[]
for p in members:
    assert p.is_file()
    raw=p.read_bytes()
    try:plain=gzip.decompress(raw) if p.suffix=='.gz' else raw
    except (OSError,EOFError):plain=raw
    if re.search(rb'"(?:playerKey|reconnectToken|sessionToken|password|accessToken)"\s*:\s*"[^"\s]+"',plain,re.I):
        excluded.append({'path':str(p.relative_to(root)),'bytes':len(raw),'sha256':sha(p),'reason':'Credential-bearing operational original retained locally'});continue
    safe.append(p)
assert len(safe)==len(set(safe))
archive=ev/'completed-void-field-originals.tar.xz'
rows=[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in safe]
with tarfile.open(archive,'x:xz',preset=6) as tar:
    for p in safe:tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
with tarfile.open(archive,'r:xz') as tar:
    assert {p.name for p in tar.getmembers()}=={r['path'] for r in rows}
    for row in rows:
        raw=tar.extractfile(row['path']).read()
        assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
write(ev/'archive-map.json',{'atUtc':now(),'archive':pin(archive),'members':rows,'explicitOperationalOrRunningPublicationExclusionsRetainedLocally':excluded,'allMemberBytesHashesAndClosedSetVerified':True,'runtimeApplicationsInstallersPrimaryPdfOriginalsNotDuplicated':True,'nextN35ExhaustedLegendPrototypeNotThisCertificationScope':True})
implementation_paths=['data/official/card-catalog.zh-CN.json','src/Riftbound.CardCatalog/RuleTextParsers.cs','src/Riftbound.Engine/CardBehaviorRegistry.cs','src/Riftbound.Engine/CoreRuleEngine.SelectedBattlefield.cs','src/Riftbound.Engine/CoreRuleEngine.cs']
verification_paths=['tests/Riftbound.ConformanceTests/CurrentVoidGateErratumTests.cs','tests/Riftbound.ConformanceTests/FirestormEnemyBattlefieldDamageGuardTests.cs','tests/Riftbound.ConformanceTests/CardCatalogBaselineTests.cs','tests/Riftbound.ConformanceTests/Cn16RuleInputSelectionTests.cs','tests/Riftbound.ConformanceTests/AhriCombatMightTests.cs','tests/Riftbound.ConformanceTests/Fixtures/p2-preflight-play-firestorm-damage-enemy-battlefield-units.fixture.json','tests/Riftbound.ConformanceTests/Fixtures/p4-play-firestorm-explicit-unit-target-rejected.fixture.json','tests/Riftbound.PostgresAcceptance/BattlefieldSpellDamageSqlAcceptance.cs','tests/Riftbound.PostgresAcceptance/Program.cs','tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json','scripts/tests/test_sql_ci_gate.py']
implementation=[pin(root/p,'implementation') for p in implementation_paths]
verification=[pin(root/p,'verification-source') for p in verification_paths]
sm={'atUtc':now(),'status':'BOUNDED_CN16_VOID_KNOWN_ERRATUM_AND_FIRESTORM_SELECTED_FIELD_SQL_ONLY_CHECK_ONE_SOURCE_EXPECTATION_REMEDIATED_NEW_FIXED_FULL_PRODUCT_OPEN','region':'CN','language':'zh-CN','observedAsOf':'2026-10-21','adoptedCoreEffectiveDate':'2026-10-16','exactCurrentSourceReview':source,'baseCommit':sql['parentCommit'],'implementationIncludesDeclaredUncommittedChanges':True,'actualRuleInputs':sql['actualRuleInputs'],'implementation':implementation,'verificationSources':verification,'onlyCheckActualOutcome':{'cases':13238,'methods':7508,'passed':13237,'failed':1,'skipped':0},'postOnlyCheckThreeVerificationInputsCorrected':pin(ev/'post-only-check-source-expectation-remediation.json'),'gameCatalogAndSqlInputsUnchangedAfterSoleCheck':True,'allOriginal51SqlIdentitiesAndOrderRetainedOnly52ndAppended':'battlefield-spell-damage','allOriginal154ReviewObjectsRetained':True,'fortyFourOnlyCurrentImplementationBindingsRefreshed':pin(ev/'forty-four-current-input-only-context-refresh.json'),'archive':pin(archive),'wholePrintingCertified':False,'fixedCommitFullCurrentVisibleHardwarePairAndPhysicalWindows':'OPEN','precedingFixed2b83NativeNotNew56RuntimeProductAcceptance':True,'noOldDevelopmentMatchMigration':True}
write(ev/'source-manifest.json',sm);sp=pin(ev/'source-manifest.json','source-manifest')
identity='void-gate-selected-battlefield-current-cn16-2026-10-21'
assert identity not in manifest['reviewContexts']
reviews['reviews'].append({'id':identity,'scope':'Only existing Void Gate official erratum adoption, one selected battlefield Firestorm enemy damage and targeted-unit spell contrast, empty/other field and atomic invalid intents; all broader damage semantics and products remain OPEN.','subjects':source['subjectPrintings'],'ruleRecords':source['ruleRecords'],'pendingRuleRecords':source['pendingRuleRecords'],'status':'BOUNDED_VOID_SELECTED_FIELD_SQL12_29_CHECK13237PASS_1SOURCE_EXPECTATION_REMEDIATED_FOCUS161_NEW_FULL_PRODUCT_OPEN','sourceManifest':sp,'auditDocument':'docs/VOID_GATE_SELECTED_BATTLEFIELD_CURRENT_CN16_AUDIT_2026-10-21.md','validation':{'newConformanceCases':7,'newConformanceMethods':3,'distinctFocusCases':306,'distinctFocusMethods':217,'checkCases':13238,'checkMethods':7508,'checkPassed':13237,'checkFailed':1,'postCheckRemediationFocusCases':161,'postCheckRemediationFocusMethods':153,'sqlCommands':12,'sqlEvents':29,'sqlColdRecoveries':12,'allOriginal51SqlIdentitiesAnd143FullMethodsRetained':True,'wholeCardCertification':False},'exclusions':source['exclusions']})
branches=[{**b,'state':'RECORDED','sourceManifest':sp,'semanticReview':{'state':'BOUNDED_CURRENT_SOURCE_BRANCH_REVIEW','wholeClauseOrPrintingCertified':False},'implementation':{'state':'EXACT_CURRENT_ERRATUM_AND_EXISTING_FINITE_SELECTED_FIELD_DAMAGE_FLOW'},'testExecution':{'state':'ACTUAL_FOCUS_SQL_COLD_DEDUP_INDEPENDENT_ALL_HISTORY_ORIGINAL_REPLAY_AND_FORGERY_PASS'},'fixedCommitCi':{'state':'PENDING_NEW_FIXED_FULL'},'productAcceptance':{'state':'OPEN'},'decision':{'state':'OPEN','reason':'Bounded evidence does not close new fixed full, all semantic branches or final candidate product acceptance.'},'wholePrintingCertified':False,'existingAcceptanceGateDependencies':['FIXED_CURRENT_CANDIDATE_FULL','USER_WINDOWS_RUNTIME']} for b in source['boundedBehaviorBranches']]
manifest['reviewContexts'][identity]={'evidenceCommit':sql['parentCommit'],'currentImplementationCommit':sql['parentCommit'],'currentImplementationIncludesUncommittedChanges':True,'ciState':'PENDING','ciReceipts':[],'region':'CN','language':'zh-CN','applicableAsOf':'2026-10-21','adoptedCoreEffectiveDate':'2026-10-16','sourceManifest':sp,'implementation':implementation,'verificationSources':verification,'evidence':[pin(ev/'focus-executed-distinct-scope.json','focus'),pin(ev/'check-original-case-method-and-input-retention.json','check'),pin(ev/'real-integrated-four-sql-terminal.json','sql'),pin(ev/'independent-all-history-and-original-replay.json','independent-sql')],'branches':branches}
for row in stale:
    context=manifest['reviewContexts'][row['id']]
    for change in row['changes']:
        matches=[p for p in context['implementation'] if p['path']==change['path']]
        assert len(matches)==1 and matches[0]['sha256']==change['oldSha256'] and sha(root/change['path'])==change['currentSha256']
        matches[0]['sha256']=change['currentSha256']
    context.update(currentImplementationCommit=sql['parentCommit'],currentImplementationIncludesUncommittedChanges=True,ciState='PENDING',currentVoidSelectedFieldInputRefresh=pin(ev/'forty-four-current-input-only-context-refresh.json','current-input-refresh'))
source_gate=next(g for g in manifest['acceptanceGates'] if g['id']=='SOURCE_GAPS_AND_EFFECTIVE_DELTAS')
source_gate['currentVoidGateExistingErratumBoundedAdoption']=sp
manifest['currentVoidGateSelectedBattlefieldInputChange']=sp
manifest['precedingFixed64678ActualCompleteFullCiReadback']=pin(ev/'prior64678-full-independent.json','prior-fixed-full')
manifest['precedingFixed2b83BoundedHeadlessCiNativeReadback']=pin(ev/'preceding-fixed2b83-headless-ci-native-subscope.json','preceding-fixed-headless-native-subscope')
manifest['inputs']['active']['sha256']=sha(root/manifest['inputs']['active']['path'])
assert reviews['reviews'][:154]==old_reviews['reviews']
assert all(manifest['reviewContexts'][k]==v for k,v in old_manifest['reviewContexts'].items() if k not in {r['id'] for r in stale})
for i,g in enumerate(manifest['acceptanceGates']):
    if g['id']!='SOURCE_GAPS_AND_EFFECTIVE_DELTAS':assert g==old_manifest['acceptanceGates'][i]
    else:
        for k,v in old_manifest['acceptanceGates'][i].items():assert g[k]==v
assert all(manifest[k]==old_manifest[k] for k in ['certificationScope','laterSourceDeltas','cardCoverageManifest','officialNewsObligations'])
rp.write_text(json.dumps(reviews,ensure_ascii=False,indent=2)+'\n')
manifest['inputs']['reviews']['sha256']=sha(rp);mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
governance='本批155限定审查、70上下文、245门禁、七来源增量。原154审查完整不变，25上下文原样；44上下文只刷新当前实现输入绑定，完整原对象、旧证据、验证源和来源日期留存，ciState按新输入保持PENDING。244其他门禁原值不变，来源门禁仅追加当前采用观察，全部旧字段和OPEN状态保留。原16962义务身份全留，追加七限定分支至16969；历史虚空之门缺口身份不删除，不提升整卡、整条款或全量认证。'
text=(w/'void-field-audit-draft-v1.md').read_text().replace('{{GOVERNANCE_RESULT}}',governance)
assert '{{' not in text
doc=root/'docs/VOID_GATE_SELECTED_BATTLEFIELD_CURRENT_CN16_AUDIT_2026-10-21.md';assert not doc.exists();doc.write_text(text)
status=root/'docs/PROJECT_STATUS.md';previous=status.read_text();prefix='# 当前项目状态\n\n';assert previous.startswith(prefix)
status.write_text(prefix+(w/'void-field-status-lead-v1.md').read_text()+previous[len(prefix):])
write(ev/'publication-original-obligation-retention.json',{'atUtc':now(),'status':'BOUNDED_VOID_SELECTED_FIELD_PUBLISHED_NOT_GOAL_COMPLETION','allOriginal154ReviewsExact':True,'allUnaffected25ContextsExact':True,'fortyFourOnlyCurrentImplementationBindingsRefreshed':refresh['records'],'all244OtherGatesExactSourceGateAllOldFieldsRetained':True,'original16962ObligationIdsMustRemain':True,'expectedNewObligations':7,'allSourceDatesScopesDeltasCoverageAndUniverseRetained':True,'sourceManifest':sp,'archiveMembers':len(rows),'archiveBytes':archive.stat().st_size})
print('Published155 reviews70contexts245gates;154 original reviews/25contexts exact;44 current-input-only refreshes;seven new bounded branches;archive',len(rows),archive.stat().st_size)
