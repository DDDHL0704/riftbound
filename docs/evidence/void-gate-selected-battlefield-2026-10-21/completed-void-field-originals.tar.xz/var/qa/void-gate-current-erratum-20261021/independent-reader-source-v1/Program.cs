using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

var json=new JsonSerializerOptions(JsonSerializerDefaults.Web){WriteIndented=true};
if(args.SequenceEqual(new[]{"--identity-only"})){Console.WriteLine(JsonSerializer.Serialize(RuleInputIdentity.Current,json));return;}
Check(args.Length==2&&!File.Exists(args[1]),"Original evidence directory and fresh independent result required.");
var work=Path.GetFullPath(args[0]);var output=Path.GetFullPath(args[1]);
var settings=new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));Check(settings.Host=="127.0.0.1"&&settings.Port==55486&&settings.Database=="riftbound_acceptance"&&settings.Username=="codex_riftbound_audit","Only own audit database.");settings.Options="-c default_transaction_read_only=on";await using var source=NpgsqlDataSource.Create(settings.ConnectionString);
var results=new List<object>();var rooms=new List<string>();var totalStates=0;var totalSnapshots=0;var totalPrompts=0;var totalCommands=0;var totalEvents=0;var rejections=0;
foreach(var branch in new[]{"targeted-unit","group-void","group-other","group-empty"})
{
    var directory=Path.Combine(work,"battlefield-spell-damage",branch);using var receipt=JsonDocument.Parse(File.ReadAllText(Path.Combine(directory,"receipt.json")));var room=receipt.RootElement.GetProperty("room").GetString()!;rooms.Add(room);
    var initial=JsonSerializer.Deserialize<MatchState>(File.ReadAllText(Path.Combine(directory,"explicit-original-controlled-initial.json")),json)!;
    var frame=await new PostgresMatchRecoveryStore(source).LoadAsync(room,default)??throw new Exception("Actual retained SQL frame required.");using var original=Read(Path.Combine(directory,"final-original-frame.json.gz"));
    Check(Same(original.RootElement,JsonSerializer.SerializeToElement(frame,json)),"Every original complete final SQL frame field/null/omission equals the independent read.");
    Check(frame.IsConsistent&&frame.Commands.Count==3&&frame.Commands.Count==receipt.RootElement.GetProperty("commands").GetInt32()&&frame.Events.Count==receipt.RootElement.GetProperty("events").GetInt32()&&initial.RoomId==room&&initial.Tick==0&&initial.RuleInputs==RuleInputIdentity.Current&&frame.AuthoritativeState!.RuleInputs==RuleInputIdentity.Current,"Original controlled initial, three actual commands and exact frozen input identity.");
    Check(frame.ReplayInitialState is {Tick:0,CardObjects.Count:0}&&!Same(JsonSerializer.SerializeToElement(initial,json),JsonSerializer.SerializeToElement(frame.ReplayInitialState,json)),"Original blank metadata is not rewritten into the explicit controlled initial.");
    using var intents=JsonDocument.Parse(File.ReadAllText(Path.Combine(directory,"all-original-accepted-intents.json")));Check(intents.RootElement.GetArrayLength()==frame.Commands.Count,"All original raw intents retained.");
    for(var i=0;i<frame.Commands.Count;i++)Check(frame.Commands[i].Accepted&&frame.Commands[i].RuleInputs==RuleInputIdentity.Current&&frame.Commands[i].PlayerId==intents.RootElement[i].GetProperty("actor").GetString()&&Same(frame.Commands[i].RawCommand!.Value,intents.RootElement[i].GetProperty("rawCommand")),"Every raw actor/input/prompt/tick and rule identity equals the original accepted input.");
    var states=new Dictionary<(long,long),MatchState>();var counts=new Dictionary<string,int>();
    await using(var connection=await source.OpenConnectionAsync())
    {
        Check((string)(await new NpgsqlCommand("show transaction_read_only",connection).ExecuteScalarAsync())! =="on","Actual read-only SQL session.");
        await using(var q=new NpgsqlCommand("select last_event_sequence,payload::text from state_snapshots where match_id=@room order by id",connection))
        {
            q.Parameters.AddWithValue("room",room);await using var rows=await q.ExecuteReaderAsync();
            while(await rows.ReadAsync())
            {
                var raw=rows.GetString(1);var state=JsonSerializer.Deserialize<MatchState>(raw,json)!;
                Check(JsonNode.DeepEquals(JsonNode.Parse(raw),JsonSerializer.SerializeToNode(state,json))&&state.RuleInputs==RuleInputIdentity.Current&&states.TryAdd((state.Tick,rows.GetInt64(0)),state),"All original authority fields/nulls/omissions and tick/event identities are exact.");
                Check(state.PlayerZones["P2"].Hand.SequenceEqual(new[]{"SECRET_HAND"})&&state.PlayerZones["P2"].MainDeck.SequenceEqual(new[]{"SECRET_DECK"})&&state.RngCursor==initial.RngCursor,"Literal unrelated original hand/deck and RNG remain exact in every authority history.");
            }
        }
        Check(states.Count==3&&frame.Commands.All(c=>states.ContainsKey((c.CompletedTick,c.CompletedEventSequence))),"Every accepted original command retains its authority row.");
        var latest=frame.Commands.GroupBy(c=>c.CompletedTick).Select(g=>g.OrderBy(c=>c.CompletedEventSequence).Last()).ToArray();var expected=latest.SelectMany(c=>new[]{"P1","P2"}.Select(p=>(c.CompletedTick,c.CompletedEventSequence,p))).ToHashSet();
        foreach(var table in new[]{"snapshots","action_prompts"})
        {
            var column=table=="snapshots"?"snapshot_tick":"prompt_tick";await using(var constraint=new NpgsqlCommand($"select pg_get_constraintdef(oid) from pg_constraint where conrelid='{table}'::regclass and contype='u'",connection))Check((string)(await constraint.ExecuteScalarAsync())! ==$"UNIQUE (match_id, player_id, {column})","Actual private storage key remains original viewer/tick.");
            await using var q=new NpgsqlCommand($"select player_id,last_event_sequence,payload::text from {table} where match_id=@room order by id",connection);q.Parameters.AddWithValue("room",room);await using var rows=await q.ExecuteReaderAsync();var actual=new HashSet<(long,long,string)>();
            while(await rows.ReadAsync())
            {
                var actor=rows.GetString(0);var sequence=rows.GetInt64(1);var raw=rows.GetString(2);using var doc=JsonDocument.Parse(raw);var tick=doc.RootElement.GetProperty(table=="snapshots"?"tick":"snapshotTick").GetInt64();Check(states.TryGetValue((tick,sequence),out var state)&&actual.Add((tick,sequence,actor)),"Every private original row binds its authority, sequence, tick and viewer.");
                var typed=table=="snapshots"?JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<SnapshotDto>(raw,json),json):JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<ActionPromptDto>(raw,json),json);Check(JsonNode.DeepEquals(JsonNode.Parse(raw),typed),"All private fields/nulls/conditional omissions survive typed read.");
                var projection=table=="snapshots"?JsonSerializer.SerializeToNode(ResolutionResult.BuildSnapshots(state!)[actor],json):JsonSerializer.SerializeToNode(ResolutionResult.BuildPrompts(state!)[actor],json);Check(JsonNode.DeepEquals(JsonNode.Parse(raw),projection),"All retained private values equal the exact original historical authority projection.");
                if(actor=="P1")foreach(var id in new[]{"SECRET_HAND","SECRET_DECK"})Check(!raw.Contains("\""+id+"\"",StringComparison.Ordinal),"Independent literal hidden opponent identities never leak.");
                Check(!doc.RootElement.TryGetProperty("openingSeed",out _),"Private opening seed never leaks.");
            }
            Check(actual.SetEquals(expected),"Both original private rows at every tick retained exactly; no missing authority history.");counts[table]=actual.Count;
        }
    }
    foreach(var pair in states)
    {
        var commands=frame.Commands.Where(c=>c.CompletedEventSequence<=pair.Key.Item2).ToArray();var events=frame.Events.Where(e=>e.Sequence<=pair.Key.Item2).ToArray();var verified=await MatchActionLogReplayer.VerifyFinalStateAsync(initial,commands,pair.Value,new CoreRuleEngine(),default,events);Check(verified.IsMatch,"Every original full authority/event prefix replays from the explicit original controlled initial: "+string.Join(';',verified.Errors));
    }
    using(var doc=Read(Path.Combine(directory,"confirmed-before-damage-original-frame.json.gz")))
    {
        var checkpoint=doc.RootElement.Deserialize<MatchRecoveryFrame>(json)!;var state=checkpoint.AuthoritativeState!;var item=state.StackItems.Single();
        Check(Same(JsonSerializer.SerializeToElement(frame.Commands.Take(checkpoint.Commands.Count),json),doc.RootElement.GetProperty("commands"))&&Same(JsonSerializer.SerializeToElement(frame.Events.Take(checkpoint.Events.Count),json),doc.RootElement.GetProperty("events")),"Original checkpoint retains complete unmodified command/event prefix.");
        Check(MatchRecoveryValidator.Validate(room,checkpoint.LastEventSequence,checkpoint.Commands,checkpoint.Events,checkpoint.PlayerViews,state,checkpoint.CurrentTick).Count==0,"Original pre-damage frame valid before independent forgery.");
        var targeted=branch=="targeted-unit";var selected=targeted?"UNIT":branch=="group-other"?"OTHER":"HILL";
        Check(item.CardNo==(targeted?"UNL-007/219":"OGS·002/024")&&item.SourceObjectId=="SPELL"&&item.ControllerId=="P1"&&item.TargetObjectIds.SequenceEqual(new[]{selected})&&item.TargetGenerations![selected]==0&&item.DamageAmount==3&&state.CardObjects.Values.All(c=>c.Damage==0),"Independent literal source/selected kind/generation/base damage and no premature damage.");
        foreach(var bad in new[]{item with {TargetObjectIds=targeted?["HILL"]:["UNIT"]},item with {TargetGenerations=new Dictionary<string,long>{{selected,99}}},item with {DamageAmount=99},item with {ControllerId="P2"},item with {SourceObjectId="ALLY"},item with {CardNo=targeted?"OGS·002/024":"UNL-007/219"}})
        {
            Check(MatchRecoveryValidator.Validate(room,checkpoint.LastEventSequence,checkpoint.Commands,checkpoint.Events,checkpoint.PlayerViews,state with {StackItems=[bad]},checkpoint.CurrentTick).Count>0,"Independent target kind/generation/damage/controller/source/printing forgery rejected.");rejections++;
        }
        var inputs=state.RuleInputs!;
        foreach(var bad in new[]{inputs with {CatalogSha256=new string('0',64)},inputs with {AuthoritySha256=new string('0',64)},inputs with {ImplementationSha256=new string('0',64)}})
        {
            Check(MatchRecoveryValidator.Validate(room,checkpoint.LastEventSequence,checkpoint.Commands,checkpoint.Events,checkpoint.PlayerViews,state with {RuleInputs=bad},checkpoint.CurrentTick).Count>0,"Independent catalog/rules/implementation mismatches rejected without migration.");rejections++;
        }
    }
    var final=frame.AuthoritativeState!;var expectedUnit=branch is "targeted-unit" or "group-void"?4:0;var expectedSecond=branch=="group-void"?4:0;var expectedOutside=branch=="group-other"?3:0;
    Check(final.CardObjects["UNIT"].Damage==expectedUnit&&final.CardObjects["SECOND"].Damage==expectedSecond&&final.CardObjects["OUTSIDE"].Damage==expectedOutside&&final.CardObjects["ALLY"].Damage==0,"Independent literal expected damage4/4/0,4/0/0,0/0/3 or0/0/0, never derived from the implementation.");
    Check(final.StackItems.Count==0&&final.TriggerQueue.Count==0&&final.PendingCardChoice is null&&final.PendingPayment is null&&final.Status==MatchStatuses.InProgress&&final.PlayerScores.Values.All(p=>p==0),"No residual spell/choice/payment/trigger or incidental points.");
    var damages=frame.Events.Where(e=>e.Event.Kind=="DAMAGE_APPLIED").Select(e=>JsonSerializer.SerializeToElement(e.Event.Payload,json)).ToArray();var ids=branch=="targeted-unit"?new[]{"UNIT"}:branch=="group-void"?new[]{"SECOND","UNIT"}:branch=="group-other"?new[]{"OUTSIDE"}:Array.Empty<string>();
    Check(damages.Select(p=>p.GetProperty("targetObjectId").GetString()).Order(StringComparer.Ordinal).SequenceEqual(ids)&&damages.All(p=>p.GetProperty("damage").GetInt32()==(branch=="group-other"?3:4)),"Independent literal full damage-event set and amounts.");
    totalStates+=states.Count;totalSnapshots+=counts["snapshots"];totalPrompts+=counts["action_prompts"];totalCommands+=frame.Commands.Count;totalEvents+=frame.Events.Count;results.Add(new{branch,room,commands=frame.Commands.Count,events=frame.Events.Count,states=states.Count,snapshots=counts["snapshots"],prompts=counts["action_prompts"],allFieldsAndEveryOriginalActionEventReplayExact=true});
}
await File.WriteAllTextAsync(output,JsonSerializer.Serialize(new{status="PASS_INDEPENDENT_CURRENT_VOID_FIRESTORM_FOUR_BRANCHES_ALL_HISTORY_PRIVATE_FIELDS_EVERY_ORIGINAL_REPLAY",rooms,cases=4,commands=totalCommands,events=totalEvents,authoritativeHistoricalStates=totalStates,privateSnapshots=totalSnapshots,privatePrompts=totalPrompts,independentStructuralRejections=rejections,actualRuleInputs=RuleInputIdentity.Current,results,actualReadOnlyConnection=true,originalBlankReplayMetadataNotRewritten=true,visibleNormalOpeningWindowsOrWholePrintingAcceptance=false},json));
Console.WriteLine($"CURRENT_BATTLEFIELD_DAMAGE_INDEPENDENT_PASS {totalCommands} commands {totalEvents} events {totalStates} states {totalSnapshots} snapshots {totalPrompts} prompts {rejections} structural rejects");
bool Same(JsonElement left,JsonElement right)=>JsonNode.DeepEquals(JsonNode.Parse(left.GetRawText()),JsonNode.Parse(right.GetRawText()));
static JsonDocument Read(string path){using var zip=new GZipStream(File.OpenRead(path),CompressionMode.Decompress);return JsonDocument.Parse(zip);}
static void Check(bool value,string message){if(!value)throw new Exception(message);}
