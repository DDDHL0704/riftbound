from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,tarfile,io,subprocess,xml.etree.ElementTree as E
R=Path.cwd();Q=R/'var/qa/draven-battle-death-score-20261023';D=R/'docs/evidence/draven-battle-death-score-parallel-2026-10-23';D.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def trx(path):
 r=E.parse(path);defs={d.get('id'):d.find('t:TestMethod',ns).attrib for d in r.findall('.//t:UnitTest',ns)}
 return {'sha256':sha(path.read_bytes()),'counters':r.find('.//t:Counters',ns).attrib,'cases':[{'name':x.get('testName'),'method':defs[x.get('testId')]['className']+'.'+defs[x.get('testId')]['name'],'outcome':x.get('outcome'),'failure':x.find('.//t:Message',ns).text if x.find('.//t:Message',ns)is not None else None}for x in r.findall('.//t:UnitTestResult',ns)]}
runs={k:trx(Q/k/'focus/results.trx')for k in ['focus-v1','focus-and-adjacent-v2']}
for k,total,passed,failed in [('focus-v1',14,4,10),('focus-and-adjacent-v2',46,36,10)]:
 c=runs[k]['counters'];assert c['total']==str(total)and c['passed']==str(passed)and c['failed']==str(failed)and c['notExecuted']=='0'
receiptPath=R/'var/qa/battle-win-combined-20261023/applied-peer-fixed-n52-first45-v1.json';receipt=json.load(receiptPath.open());peer=Path(receipt['overlaySource']);assert sha(peer.read_bytes())==receipt['overlaySha256']
for f in receipt['files']:assert sha((R/f['path']).read_bytes())==f['afterSha256']
proof=[];ruleInputs=[]
for p in sorted((Q/'original-v2').glob('*.json.gz')):
 a=json.loads(gzip.decompress(p.read_bytes()));assert a['originalPrefixReplayCount']==len(a['commands'])==len(a['entries'])==len(a['states']);assert a['initial']['seed']==424242 and all(c['accepted']for c in a['commands'])
 events=[e for entry in a['entries']for e in entry['events']];assert events==[e['event']for e in a['events']]
 sourcePlayer='P2'if a['scenario']in('defender-death','defender-winning-point')else'P1';s=a['states'][-1]
 deaths=[e for e in events if e['kind']=='UNIT_DESTROYED'and e['payload'].get('targetObjectId')=='SOURCE']
 if a['scenario']=='zhonya-replacement':
  assert not deaths and 'SOURCE'in s['playerZones']['P1']['base']and'HOURGLASS'in s['playerZones']['P1']['graveyard']and a['failure']is None
  assert a['commands'][0]['commandType']=='PLAY_CARD'
 else:assert len(deaths)==1 and 'SOURCE'in s['playerZones'][sourcePlayer]['graveyard']
 if a['scenario']=='spell-outside-battle':assert a['failure']is None and not any(e['kind']in('BATTLE_RESULT_DETERMINED','BATTLE_CLOSED')for e in events)
 if a['scenario']=='spell-battle-death':assert [c['commandType']for c in a['commands']]==['MOVE_UNIT','PASS_FOCUS','PLAY_CARD','PASS_PRIORITY','PASS_PRIORITY']
 for c in a['commands']:
  if c['ruleInputs']not in ruleInputs:ruleInputs.append(c['ruleInputs'])
 proof.append({'caseId':a['caseId'],'scenario':a['scenario'],'commands':len(a['commands']),'events':len(events),'originalPrefixReplays':a['originalPrefixReplayCount'],'sha256':sha(p.read_bytes()),'failure':a['failure']})
assert len(proof)==14 and sum(x['commands']for x in proof)==58 and sum(x['events']for x in proof)==206 and len(ruleInputs)==1
assembly=R/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0/Riftbound.ConformanceTests.dll';assert json.load((Q/'focus-and-adjacent-v2/plan.json').open())['testAssemblySha256']==sha(assembly.read_bytes())
for p in Q.rglob('current-*-original-v1.json.gz'):
 a=json.loads(gzip.decompress(p.read_bytes()));assert sha(a['originalUtf8'].encode())==a['rawSha256']
faq=Q/'current-sfd-judge-faq-original-v1.pdf';meta=json.load((Q/'current-sfd-judge-faq-http-v1.json').open());assert sha(faq.read_bytes())==meta['sha256']=='16eeeea28baeeee2dae3765876c609f79cc77fdbdd6928d73f1b8fa5d5c277bc'and faq.stat().st_size==meta['bytes']==25623614
source='tests/Riftbound.ConformanceTests/OfficialDravenBattleDeathScoreTests.cs';consumer='src/Riftbound.Engine/CoreRuleEngine.DravenBattleDeathScore.cs'
assert (Q/'focus-and-adjacent-v2/test-source.cs').read_bytes()==(R/source).read_bytes()and(Q/'focus-and-adjacent-v2/consumer-source.cs').read_bytes()==(R/consumer).read_bytes()
extra=[source,consumer,'docs/DRAVEN_BATTLE_DEATH_SCORE_PARALLEL_2026-10-23.md','var/qa/draven-battle-win-score-20261023/current-core304-http-original-v1.json']
paths=[(str(p.relative_to(R)),p)for p in Q.rglob('*')if p.is_file()and p.suffix!='.pdf']+[(x,R/x)for x in extra]+[('inputs/peer-fixed-n52-first45-v1.tar.gz',peer),('inputs/applied-peer-fixed-n52-first45-v1.json',receiptPath)]
archive=D/'original-tests-fixed-inputs-and-sources-v1.tar.gz';members=[]
with archive.open('xb')as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as tar:
   for name,p in sorted(paths):
    data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data));members.append({'path':name,'bytes':len(data),'sha256':sha(data)})
with tarfile.open(archive,'r:gz')as tar:
 for m in members:
  data=tar.extractfile(m['path']).read();assert len(data)==m['bytes']and sha(data)==m['sha256']
manifest={'status':'SOURCE_RED_DRAVEN_BATTLE_DEATH_OPPONENT_SCORE_UNWIRED','atUtc':datetime.now(timezone.utc).isoformat(),'baseCommit':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'region':'CN','language':'zh-CN','coreEffectiveDate':'2026-10-16','peerOverlay':receipt,'all19SharedInputsUnchanged':True,'actualRuleInputs':ruleInputs[0],'testAssemblySha256':sha(assembly.read_bytes()),'source':{'path':source,'sha256':sha((R/source).read_bytes())},'consumer':{'path':consumer,'sha256':sha((R/consumer).read_bytes()),'sharedCallSites':0},'originalRuns':runs,'finalOriginalHistories':proof,'cases':14,'methods':1,'passed':4,'sourceFailures':10,'originalCommands':58,'accepted':58,'originalPrefixReplays':58,'originalEvents':206,'adjacentDeathObserverPassed':22,'adjacentZhonyaPassed':10,'seed':424242,'freshCompleteSourceRows':json.load((Q/'sources-v1/extra-rows.json').open()),'liveOfficialJudgeFAQ':meta,'largeSourceBodyPreservedLocallyOutsideArchive':str(faq),'sourceClause':'DOC-14-P025-B004; DOC-01 429.1.a.1.b and 808.1.d.1','normalVictoryAndHotFeprIntegrationStillOpen':True,'noExtraCheckOrFull':True,'noDatabaseExecution':True,'fullGameAcceptanceDeferredUntilIntegration':True,'allEarlierSourcesTestsSeedsAndFailuresPreserved':True,'backendGoalComplete':False,'sharedIntegrationOwner':'01a16770-8c1b-7da2-872b-a8ec5ae77413','parallelThread':'01a16771-220b-7e83-91c6-44acf6dfe4b0','archive':{'path':str(archive.relative_to(R)),'sha256':sha(archive.read_bytes()),'members':members}}
with(D/'source-and-red-test-manifest.json').open('x')as f:json.dump(manifest,f,ensure_ascii=False,indent=2)
print(manifest['status'],len(members),'members',archive.stat().st_size,'bytes;14 cases4pass10fail;58prefixes;32 adjacentpass')
