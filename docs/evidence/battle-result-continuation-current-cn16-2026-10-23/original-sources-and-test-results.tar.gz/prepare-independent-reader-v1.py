from pathlib import Path
r=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
old=r/'var/qa/burnout-inner-cleanup-and-garen-current-cn16-20261023/independent-seven-original-sql-reader-source-v3';dst=w/'independent-original-sql-reader-v1';dst.mkdir(exist_ok=False)
s=(old/'Program.cs').read_text().replace('seven-cleanup-garen','eleven-battle-result').replace('victory-cleanup-garen','battle-result-continuation').replace('VICTORY_CLEANUP_GAREN_SEVEN','BATTLE_RESULT_CONTINUATION_ELEVEN').replace('VICTORY_CLEANUP_GAREN','BATTLE_RESULT_CONTINUATION')
s=s.replace('var corrupt = branch == "reject-forged-mundo";', 'var corrupt = branch.StartsWith("forge-", StringComparison.Ordinal);')
a=s.index('    var garen =');b=s.index('    Check(frame.Commands.Select',a)
s=s[:a]+'''    var returned = branch.EndsWith("-return", StringComparison.Ordinal);
    var destroyed = branch.EndsWith("-destroy", StringComparison.Ordinal);
    var burnout = branch.EndsWith("-burnout", StringComparison.Ordinal);
    expectedTypes.AddRange(["MOVE_UNIT", "PASS_FOCUS", "PASS_FOCUS", "DECLARE_BATTLE"]);
    if (!corrupt)
    {
        if (returned) expectedTypes.AddRange(["PLAY_CARD", "PASS_PRIORITY", "PASS_PRIORITY"]);
        if (destroyed) expectedTypes.AddRange(["PASS_PRIORITY", "PLAY_CARD", "PASS_PRIORITY", "PASS_PRIORITY", "PASS_PRIORITY", "PLAY_CARD", "PASS_PRIORITY", "PASS_PRIORITY"]);
        expectedTypes.AddRange(["PASS_PRIORITY", "PASS_PRIORITY"]);
    }
'''+s[b:]
a=s.index('        var text = payload.GetRawText();');b=s.index('\n    }\n    var final =',a)
s=s[:a]+'''        var privateProbe = JsonNode.Parse(payload.GetRawText())!;
        if (table == "snapshots" && state.PlayerZones["alice"].Hand.Contains("SOURCE") && actor == "bob")
        {
            // Existing battle-history projections deliberately retain historical
            // public references. Independently require an older captured binding
            // before excluding just those history sections from current-zone scan.
            foreach (var history in state.BattleResolutions.Where(b => b.AttackerObjectIds.Contains("SOURCE")))
                Check(history.PublicObjectBindings?.Any(b => b.ObjectId == "SOURCE" && b.Generation < state.CardObjects["SOURCE"].ObjectGeneration) == true,
                    "Historical result source must be an older public incarnation.");
            foreach (var history in state.BattlefieldResolutions.Where(b => b.ParticipantObjectIds.Contains("SOURCE")))
                Check(history.PublicObjectBindings?.Any(b => b.ObjectId == "SOURCE" && b.Generation < state.CardObjects["SOURCE"].ObjectGeneration) == true,
                    "Historical field source must be an older public incarnation.");
            privateProbe["timing"]!.AsObject().Remove("battleResolutions");
            privateProbe["timing"]!.AsObject().Remove("battlefieldResolutions");
            foreach (var skill in privateProbe["stack"]!.AsArray())
                if (skill?["effectKind"]?.GetValue<string>() == "CAPTURED_UNIT_BATTLE_WIN_DRAW")
                    Check(skill["sourceObjectId"]!.GetValue<string>() == "HIDDEN"
                        && skill["cardNo"]!.GetValue<string>() == (branch.StartsWith("enforcer") ? "SFD·123/221" : "UNL-114/219"),
                        "Public earned skill retains original printing but hides current private source identity.");
        }
        var text = privateProbe.ToJsonString();
        foreach (var enemy in state.Seats.Keys.Where(p => p != actor)) foreach (var id in state.PlayerZones[enemy].Hand.Concat(state.PlayerZones[enemy].MainDeck))
            Check(!text.Contains(JsonSerializer.Serialize(id), StringComparison.Ordinal), "Independent literal opponent hand/deck boundary outside validated historical battle references.");'''+s[b:]
a=s.index('    if (garen) {');b=s.index('    Check((await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame',a)
s=s[:a]+'''    Check(setupState.CardObjects["SOURCE"].Power == 4 && setupState.CardObjects["SOURCE"].Damage == 0
        && setupState.PlayerZones["alice"].Base.SequenceEqual(["SOURCE"]), "Actual printed source starts undamaged in base.");
    var resultCommand = frame.Commands[6]; var resultState = states[(resultCommand.CompletedTick, resultCommand.CompletedEventSequence)];
    Check(resultState.PendingBattleResult is { Stage: "RESULT_TRIGGERS", WinnerPlayerId: "alice" }
        && resultState.CardObjects["FIELD"].ControllerId == "bob" && resultState.PlayerScores["alice"] == 0
        && resultState.CardObjects["SOURCE"].IsAttacking && resultState.CardObjects["SOURCE"].Damage == 0
        && resultState.StackItems.Single().UnitBattleWinDraw is { ControllerId: "alice" },
        "Independent result-before-control, post-cleanup, still-attacking captured source boundary.");
    if (!corrupt)
    {
        Check(kinds.Count(k => k == "CARD_DRAWN") == 1 && final.PlayerZones["alice"].Hand.Contains("DRAW"), "Exactly one captured draw despite response departure.");
        Check(final.PlayerScores["alice"] == (returned || destroyed || burnout ? 0 : 1), "Control score uses actual post-response occupancy.");
        if (burnout)
            Check(final.Status == MatchStatuses.Finished && final.WinnerPlayerId == "bob" && final.PlayerScores["bob"] == 8
                && final.PendingBattleResult is not null && !kinds.Contains("BATTLE_CLOSED") && !kinds.Contains("BATTLEFIELD_CONQUERED")
                && kinds.IndexOf("CARD_DRAWN") < kinds.IndexOf("MATCH_WON"), "Normal burnout win precedes control and battle end after parent draw.");
        else
        {
            Check(final.Status == MatchStatuses.InProgress && final.WinnerPlayerId is null && final.PendingBattleResult is null
                && kinds.IndexOf("CARD_DRAWN") < kinds.IndexOf("BATTLE_CLOSED"), "The whole result chain precedes battle close.");
            Check(final.BattleResolutions.Single(b => b.Kind == "CLOSED").WinnerPlayerId == "alice", "Original winner survives removal in captured history.");
            Check(returned ? final.PlayerZones["alice"].Hand.Contains("SOURCE") : destroyed ? final.PlayerZones["alice"].Graveyard.Contains("SOURCE") : final.ObjectLocations["SOURCE"].BattlefieldObjectId == "FIELD", "Actual physical response outcome.");
            if (destroyed) Check(frame.Commands.Count(c => c.CommandType == "PLAY_CARD") == 2
                && frame.Commands.Where(c => c.CommandType == "PLAY_CARD").All(c => c.RawCommand!.Value.GetProperty("cardNo").GetString() == "OGN·127/298"), "Both damage reactions use actual allowed printing.");
            if (returned) Check(frame.Commands.Single(c => c.CommandType == "PLAY_CARD").RawCommand!.Value.GetProperty("cardNo").GetString() == "OGN·104/298", "Actual return is a legal reaction printing.");
        }
    }
'''+s[b:]
a=s.index('        Check(!live.IsConsistent');b=s.index('        var directForgeryReplay',a)
s=s[:a]+'''        Check(live.IsConsistent, "All coordinated forged private views are structurally consistent before journal authentication.");
        var actualSkill = live.AuthoritativeState!.StackItems.Single(); var originalSkill = final.StackItems.Single();
        if (branch == "forge-generation") Check(actualSkill.UnitBattleWinDraw!.Source.Generation == originalSkill.UnitBattleWinDraw!.Source.Generation + 1, "Exact generation attack retained.");
        else if (branch == "forge-printing") Check(actualSkill.UnitBattleWinDraw!.CardNo == "SFD·123/221" && actualSkill.CardNo == "SFD·123/221", "Exact coordinated printing attack retained.");
        else Check(actualSkill.UnitBattleWinDraw!.ResultTick + 1 == originalSkill.UnitBattleWinDraw!.ResultTick
            && live.AuthoritativeState.PendingBattleResult!.ResultTick == actualSkill.UnitBattleWinDraw.ResultTick, "Exact coordinated result tick attack retained.");
'''+s[b:]
a=s.index('Check(seenBranches.SetEquals');b=s.index('static JsonDocument Read',a)
s=s[:a]+'''Check(seenBranches.SetEquals(new[] { "nidalee-keep", "nidalee-return", "nidalee-destroy", "nidalee-burnout",
    "enforcer-keep", "enforcer-return", "enforcer-destroy", "enforcer-burnout", "forge-generation", "forge-printing", "forge-result-tick" })
    && counts["commands"] == 115 && counts["authority"] == 115 && counts["snapshots"] == 219 && counts["prompts"] == 219
    && counts["prefixReplays"] == 115 && counts["actualForgeryRefusals"] == 3, "All11 original rooms,115 prefixes,219 each private rows and three structurally-consistent actual forgery refusals.");
await File.WriteAllTextAsync(args[1], JsonSerializer.Serialize(new { status = "PASS_INDEPENDENT_BATTLE_RESULT_ELEVEN_ORIGINAL_SQL_ROOMS115_PREFIXES219_EACH_PRIVATE_THREE_ORIGINAL_BIRTH_REFUSALS",
    actualReadOnlyConnection = true, actualLoadedFourAssemblies = loaded, totals = counts, rooms = outcomes,
    allOriginalFieldsNullsOmissionsAndSeedsRetained = true, controlledPositionsNotOrdinaryOpenings = true,
    wholePrintingsAndCurrentFixedCiStillSeparate = true, desktopClientAndWindowsHardwareDeferredToClientPhase = true,
    actualForgedViewsStructurallyConsistent = true }, json));
'''+s[b:]
(dst/'Program.cs').write_text(s)
(dst/'probe.csproj').write_text((old/'probe.csproj').read_text().replace('IndependentVictoryCleanupGarenSqlOriginalsV3','IndependentBattleResultSqlOriginalsV1'))
print(dst)
