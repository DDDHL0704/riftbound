from pathlib import Path
import gzip,json,hashlib,datetime,subprocess,xml.etree.ElementTree as E
w=Path(__file__).resolve().parent;s=json.loads(gzip.decompress((w/'sole-check-frozen-candidate-start-v1.json.gz').read_bytes()));root=Path(s['frozenRoot']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
n={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};p=w/'frozen-sole-check-v1/check/results.trx';r=E.parse(p).getroot();rows=r.findall('.//t:UnitTestResult',n);c=r.find('.//t:Counters',n).attrib
assert int(c['total'])==13766 and int(c['passed'])==13765 and int(c['failed'])==1 and int(c['notExecuted'])==0
bad=[x.get('testName') for x in rows if x.get('outcome')!='Passed'];assert bad==['Riftbound.ConformanceTests.ConformanceFixtureRunnerTests.P79LegendTriggerDravenDrawsWhenControllerWinsBattle']
plan=json.loads((w/'frozen-sole-check-v1/plan.json').read_text());defs={x.get('id'):x.find('t:TestMethod',n).attrib for x in r.findall('.//t:UnitTest',n)};actual={defs[x.get('testId')]['className']+'.'+defs[x.get('testId')]['name'] for x in rows};assert actual==set(plan['shards'][0]['methods'])
changed=[rel for rel,v in s['sourceInputs'].items() if sha(root/rel)!=v['sha256'] or oct((root/rel).stat().st_mode & 0o777)!=v['mode']];assert not changed
console=(w/'frozen-sole-check-v1/check/test.log').read_text();assert '13765' in console and '13766' in console
procs=subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True);running=[x for x in procs.splitlines() if str(root) in x and ('dotnet test' in x or 'testhost.dll' in x)];assert not running
record={'status':'FAIL_ORIGINAL_OUTPUT_RETAINED_NO_SECOND_CHECK','observedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'frozenRoot':str(root),'baseCommit':s['baseCommit'],'exitCode':None,'ownerTerminalUnavailable':True,'wrapperExitCodeNotObserved':True,'failureProvenByOriginalCompletedTrxAndConsole':True,'trxTimes':r.find('t:Times',n).attrib,'counters':c,'methods':len(actual),'allPlannedMethodsExecuted':True,'failedCases':bad,'sourceCount':len(s['sourceInputs']),'allSourceInputsAndModesStable':True,'noFrozenTestProcessesRemain':True,'originalTrxSha256':sha(p),'originalConsoleSha256':sha(w/'frozen-sole-check-v1/check/test.log'),'noRerun':True}
(w/'sole-check-independent-completion-observation-v1.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
