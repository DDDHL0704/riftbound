import collections,datetime,gzip,hashlib,json,pathlib,urllib.request
work=pathlib.Path(__file__).resolve().parent
root=work.parents[2]
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda b:hashlib.sha256(b).hexdigest()
url='https://lol-api.playloltcg.com/xcx/card/searchCardCraftWeb'
prior_meta=json.loads((root/'docs/evidence/public-reveal-wording-2026-10-19/cn-rad-preview-id-transition.json').read_text())
prior_path=root/prior_meta['sourceDeltaView'];assert sha(prior_path.read_bytes())==prior_meta['sourceDeltaViewSha256']
prior=json.loads(prior_path.read_text())['data']
records=[]
def acquire(label,payload):
 record={'label':label,'url':url,'request':payload,'requestedAtUtc':now(),'region':'CN','language':'zh-CN'}
 req=urllib.request.Request(url,data=json.dumps(payload,ensure_ascii=False).encode(),headers={'Content-Type':'application/json','User-Agent':'Riftbound exact source version audit'})
 with urllib.request.urlopen(req,timeout=40) as response:
  raw=response.read();record.update(httpStatus=response.status,httpDate=response.headers.get('Date'),resolvedUrl=response.url)
 body=json.loads(raw);assert body['code']==0
 result=body['result'];rows=result if isinstance(result,list) else result['list'];total=len(rows) if isinstance(result,list) else result['total']
 p=work/(label+'-complete-response-v1.json.gz');assert not p.exists();p.write_bytes(gzip.compress(raw,mtime=0))
 record.update(receivedAtUtc=now(),rawSha256=sha(raw),rawBytes=len(raw),rawGzip=str(p.relative_to(root)),reportedTotal=total,returnedRows=len(rows));records.append(record)
 return rows,total
base={'pageNum':1,'pageSize':2000,'searchContent':'','cardCategoryList':[],'cardColorList':[],'rarityList':[],'productCodeList':[]}
rows,total=acquire('whole-cn-page01',base)
assert len(rows)==total,'Single complete response required; partial source kept, no universe update.'
assert len(rows)==len({r['id'] for r in rows})==len({r['cardNo'] for r in rows})
repeat=dict(base,pageSize=100,searchContent='缄默术');named,named_total=acquire('silence-after-whole-list',repeat)
assert len(named)==named_total==1
before={r['cardNo']:r for r in prior};after={r['cardNo']:r for r in rows}
initial=json.loads((work/'source-version-and-impact-readback-v1.json').read_text());first=next(x for x in initial['records'] if x.get('searchName')=='缄默术')
first_raw=json.loads(gzip.decompress((root/first['completeResponse']).read_bytes()))['result']['list'][0]
consistency=first_raw==named[0]==after.get('RAD·041/167')
changes=[]
for card_no in sorted(set(before)&set(after)):
 a,b=before[card_no],after[card_no]
 if a!=b:
  fields=sorted(k for k in set(a)|set(b) if a.get(k)!=b.get(k))
  changes.append({'exactRawCardNo':card_no,'beforeOfficialId':a['id'],'afterOfficialId':b['id'],'beforeRawRowSha256':sha(json.dumps(a,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()),'afterRawRowSha256':sha(json.dumps(b,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()),'changedFields':fields,'exactFieldChanges':{k:{'before':a.get(k),'after':b.get(k)} for k in fields},'publicationDate':None,'effectiveDate':None,'wholePrintingCertified':False})
view={'metadata':{'totalItems':len(rows),'region':'CN','language':'zh-CN','role':'AUDIT_ADAPTER_FROM_RETAINED_PUBLIC_API_COMPLETE_RESPONSE_NO_ROW_NORMALIZATION','runtimeAdopted':False},'data':rows}
out=work/'current-complete-cn-source-version-view-v1.json';assert not out.exists();out.write_text(json.dumps(view,ensure_ascii=False,indent=2)+'\n')
proof={'status':'COMPLETE_CURRENT_CN_SOURCE_VERSION_COMPARED_TO_PREVIOUS_OBSERVED_CN19','recordedAtUtc':now(),'region':'CN','language':'zh-CN','previousObservedSource':prior_meta['sourceDeltaView'],'previousObservedSourceSha256':sha(prior_path.read_bytes()),'currentSourceView':str(out.relative_to(root)),'currentSourceViewSha256':sha(out.read_bytes()),'sourceRowsBefore':len(prior),'sourceRowsAfter':len(rows),'exactPrintingNumbersAdded':sorted(set(after)-set(before)),'exactPrintingNumbersRemoved':sorted(set(before)-set(after)),'unchangedExactRows':sum(before[c]==after[c] for c in set(before)&set(after)),'changedExactRows':len(changes),'changedFieldCounts':dict(collections.Counter(k for c in changes for k in c['changedFields'])),'initialNameWholeListAndFinalNameExactRowConsistent':consistency,'acquisitions':records,'changes':changes,'runtimeSourceAndAllOriginalLedgerEntriesDatesRemainUnchanged':True,'singlePrintingApplicabilityNotDerivedFromApiFlagsOrProductLabels':True,'semanticCoverageCertified':False}
p=work/'cn20-source-version-transition-and-field-impact-v1.json';assert not p.exists();p.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:proof[k] for k in ['status','sourceRowsBefore','sourceRowsAfter','unchangedExactRows','changedExactRows','changedFieldCounts','exactPrintingNumbersAdded','exactPrintingNumbersRemoved','initialNameWholeListAndFinalNameExactRowConsistent']},ensure_ascii=False))
