import concurrent.futures
import datetime
import gzip
import hashlib
import json
import pathlib
import tempfile
import urllib.request

work=pathlib.Path(__file__).resolve().parent
root=work.parents[2]
prior_path=root/'var/qa/graveyard-lifecycle-source-followup-20261020/shared-typed-stack-finite-consumer-followup-v2.json'
prior=json.loads(prior_path.read_text())
old={r['id']:r for r in json.loads((root/prior['snapshot']).read_text())['cards']}
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda b:hashlib.sha256(b).hexdigest()
base='https://lol-api.playloltcg.com'
name_targets={}
for r in prior['exactRows']:name_targets.setdefault(r['officialSnapshotRow']['cardName'],[]).append(r)
jobs=[('rules-directory',base+'/xcx/gameRule/getGameRuleList',{'pageNum':1,'pageSize':1000},None,[])]
for index,(name,targets) in enumerate(name_targets.items(),1):
 jobs.append((f'card-name-{index:02d}',base+'/xcx/card/searchCardCraftWeb',{'pageNum':1,'pageSize':100,'searchContent':name,'cardCategoryList':[],'cardColorList':[],'rarityList':[],'productCodeList':[]},None,targets))
source_prior=json.loads((root/'var/qa/graveyard-lifecycle-source-followup-20261020/pre-fix-current-source-refresh-v3.json').read_text())
for label in ['core','faq']:
 r=next(r for r in source_prior['records'] if r['label']==label)
 jobs.append((label,r['url'],None,r,[]))
def acquire(job):
 label,url,payload,pdf,targets=job
 record={'label':label,'url':url,'request':payload,'requestedAtUtc':now(),'region':'CN','language':'zh-CN','singlePrintingPublicationDate':None,'singlePrintingEffectiveDate':None}
 try:
  request=urllib.request.Request(url,data=None if payload is None else json.dumps(payload,ensure_ascii=False).encode(),headers={'Content-Type':'application/json','User-Agent':'Riftbound bounded official source audit'})
  with urllib.request.urlopen(request,timeout=35) as response:
   record.update(httpStatus=response.status,httpDate=response.headers.get('Date'),resolvedUrl=response.url)
   if pdf:
    digest=hashlib.sha256();size=0
    with tempfile.NamedTemporaryFile(dir=work,delete=False) as stream:
     path=pathlib.Path(stream.name)
     for chunk in iter(lambda:response.read(1024*1024),b''):
      digest.update(chunk);size+=len(chunk);stream.write(chunk)
    same=digest.hexdigest()==pdf['rawSha256']
    record.update(rawSha256=digest.hexdigest(),rawBytes=size,retainedCanonical=pdf['canonical'],exactSameBytesAsRetainedCanonical=same)
    if same:path.unlink();record['unchangedDuplicatePdfNotRetained']=True
    else:
     target=work/(label+'-changed-'+digest.hexdigest()[:16]+'.pdf');path.rename(target)
     record['changedSourceRetainedForSeparateVersionAndImpactDisposition']=str(target.relative_to(root))
   else:
    raw=response.read();body=json.loads(raw);assert body['code']==0
    path=work/(label+'-complete-response-v1.json.gz');assert not path.exists();path.write_bytes(gzip.compress(raw,mtime=0))
    result=body['result'];rows=result if isinstance(result,list) else result['list'];total=None if isinstance(result,list) else result['total']
    record.update(rawSha256=sha(raw),rawBytes=len(raw),completeResponse=str(path.relative_to(root)),returnedRows=len(rows),reportedTotal=total)
    record['completeReturnedPageCompared']=total is None or len(rows)==total
    if label=='rules-directory':
     saved=next(x for x in source_prior['records'] if x['label']=='rules-directory')
     prev=json.loads(gzip.decompress((root/saved['path']).read_bytes()))['result'];prev=prev if isinstance(prev,list) else prev['list']
     record['allOriginalDirectoryRowsExactAndInSameOrder']=rows==prev
    else:
     current={r['id']:r for r in rows}
     record['searchName']=payload['searchContent']
     record['everyReturnedRowComparedToOriginal1504']=[{'apiId':r['id'],'cardNo':r['cardNo'],'entireRowMatchesOriginal':r==old.get(r['id']),'fullRowSha256':sha(json.dumps(r,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())} for r in rows]
     record['exactDistinctPrintingTargets']=[]
     for target in targets:
      row=current.get(target['apiId'])
      record['exactDistinctPrintingTargets'].append({'apiId':target['apiId'],'retainedPrintingIdentity':target['exactPrinting'],'exactParentIds':target['alreadyExistingWholePrintingObligationIds'],'returned':row is not None,'rawCardNo':None if row is None else row['cardNo'],'exactSameRawOriginalRow':row==target['officialSnapshotRow'],'fullRowSha256':None if row is None else sha(json.dumps(row,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()),'wholePrintingSemanticCertification':False})
  record['status']='ACQUIRED_COMPLETE_RESPONSE_AND_EXACT_IDENTITY_COMPARISON'
 except Exception as error:
  record.update(status='ACQUISITION_OR_ADAPTER_FAILED_NOT_OFFICIAL_SOURCE_ABSENCE',errorType=type(error).__name__,errorMessage=str(error))
 finally:
  record['receivedAtUtc']=now();(work/(label+'-receipt-v1.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
 return record
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:records=list(executor.map(acquire,jobs))
proof={'status':'CURRENT_BOUNDED_TYPED_STACK_CONSUMER_SOURCE_READBACK_NOT_SEMANTIC_CERTIFICATION','recordedAtUtc':now(),'region':'CN','language':'zh-CN','rulesApplicableBaseline':'2026-10-16','priorCandidateManifest':str(prior_path.relative_to(root)),'priorManifestSha256':sha(prior_path.read_bytes()),'distinctPrintingTargetCount':17,'nameRequestCount':len(name_targets),'totalRequests':len(jobs),'records':records,'allOriginalParentIdsAndRawIdentitiesPreserved':True,'futureOrNonRuntimeEntriesRequireIndependentApplicabilityDisposition':True,'newSourceVersionNeverSilentlyAdopted':True,'noSourceTestsOrRuntimeOrOriginalHistoryMutation':True,'entireCardOrRuleFamilyCertified':False}
output=work/'source-version-and-impact-readback-v1.json';assert not output.exists();output.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'requests':len(jobs),'acquired':sum(r['status']=='ACQUIRED_COMPLETE_RESPONSE_AND_EXACT_IDENTITY_COMPARISON' for r in records),'targets':sum(len(r.get('exactDistinctPrintingTargets',[])) for r in records),'targetRowsUnchanged':sum(t['exactSameRawOriginalRow'] for r in records for t in r.get('exactDistinctPrintingTargets',[])),'directorySame':next(r.get('allOriginalDirectoryRowsExactAndInSameOrder') for r in records if r['label']=='rules-directory'),'coreFaqSame':[r.get('exactSameBytesAsRetainedCanonical') for r in records if r['label'] in ['core','faq']]}))
