import datetime
import hashlib
import json
import os
import pathlib
import shutil
import subprocess

work = pathlib.Path(__file__).resolve().parent
root = work.parents[2]
dotnet = '/Users/dinghaolin/.dotnet/dotnet'
inputs = json.loads((work / 'fixed-commit-inputs-v1.json').read_text())
fixed = inputs['fixedCommit']
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
write = lambda p, d: p.write_text(json.dumps(d, indent=2) + '\n')
out = work / 'fixed-api-and-sql-helper-publication-v1.json'
assert not out.exists() and not (work / 'fixed-api').exists()
proof = {'startedAtUtc': now(), 'fixedCommit': fixed, 'status': 'BUILDING_FIXED_API_AND_SEPARATE_SQL_HELPERS',
         'noWholeCheckoutNewDatabaseOrGodotBuild': True, 'sqlActuallyExecuted': False, 'steps': []}
power = process = None

def verify_sources():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == fixed
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root)
    assert all(sha(root / p) == h for p, h in inputs['sourceInputHashes'].items())

def run(args, label):
    global process
    log = work / (label + '.log')
    assert not log.exists()
    with log.open('xb') as stream:
        process = subprocess.Popen(args, cwd=root, stdout=stream, stderr=subprocess.STDOUT)
        code = process.wait(timeout=300)
    proof['steps'].append({'label': label, 'exitCode': code, 'logSha256': sha(log)})
    assert code == 0, label

try:
    verify_sources()
    power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())])
    proof.update(ownRunnerPid=os.getpid(), boundIdleSleepAssertionPid=power.pid)
    api = work / 'fixed-api'
    run([dotnet, 'publish', 'src/Riftbound.Api/Riftbound.Api.csproj', '-c', 'Release', '-o', str(api), '-v:q', '--nologo'], 'fixed-api-publish-v1')
    shared = ['Riftbound.Engine.dll', 'Riftbound.Contracts.dll', 'Riftbound.CardCatalog.dll', 'Riftbound.Persistence.dll', 'Npgsql.dll']
    data = ['card-catalog.zh-CN.json', 'armaments.json', 'rule-input-scope.json']
    for name in data:
        assert sha(api / 'data/official' / name) == sha(root / 'data/official' / name)
    helpers = {}
    for name in ['sql-prefix-driver', 'sql-independent-reader']:
        folder = work / name
        assert not (folder / 'bin').exists()
        run([dotnet, 'build', str(folder / 'probe.csproj'), '-c', 'Release', '-v:q', '--nologo'], name + '-build-v1')
        binary = folder / 'bin/Release/net10.0'
        assert all(sha(binary / file) == sha(api / file) for file in shared)
        (binary / 'data/official').mkdir(parents=True)
        for file in data:
            shutil.copy2(api / 'data/official' / file, binary / 'data/official' / file)
        (binary / 'Fixtures').mkdir()
        shutil.copy2(root / 'tests/Riftbound.ConformanceTests/Fixtures/destruction-graveyard-openings.json', binary / 'Fixtures/destruction-graveyard-openings.json')
        helpers[name] = {'sourceHashes': {p.name: sha(p) for p in folder.iterdir() if p.is_file()},
                         'runtimeHashes': {str(p.relative_to(binary)): sha(p) for p in binary.rglob('*') if p.is_file()},
                         'command': [dotnet, str(binary / 'probe.dll')]}
    identity_probe = root / 'var/qa/destruction-graveyard-implementation-20261020/identity-probe/bin/Debug/net10.0/probe.dll'
    actual = json.loads(subprocess.check_output([dotnet, str(identity_probe), str(api)], cwd=api, text=True))
    reader_identity = json.loads(subprocess.check_output(helpers['sql-independent-reader']['command'] + ['identity-print'], cwd=root, text=True))
    assert actual['actualRuleInputs'] == reader_identity
    verify_sources()
    proof.update(status='PASS_FIXED_API_AND_SEPARATE_SQL_HELPERS_PUBLISHED',
                 actualRuleInputs=actual['actualRuleInputs'], actualCoreModules=actual['modules'],
                 apiRuntimeHashes={str(p.relative_to(api)): sha(p) for p in api.rglob('*') if p.is_file()},
                 helpers=helpers, allFiveHelperApiModulesByteExact=True,
                 all3303FixedSourcesStillExact=True, sqlActuallyExecuted=False,
                 newFixedFullRealSqlVisibleAndPhysicalWindows='OPEN')
except BaseException as error:
    proof.update(status='FAILED_BUILD_PREFIX_RETAINED', errorType=type(error).__name__, errorMessage=str(error))
    raise
finally:
    if process is not None and process.poll() is None:
        process.terminate()
        process.wait(timeout=30)
    if power is not None:
        if power.poll() is None:
            power.terminate()
            power.wait(timeout=10)
        proof['boundIdleSleepAssertionEnded'] = power.poll() is not None
    proof['finishedAtUtc'] = now()
    write(out, proof)
print(proof['status'], fixed, flush=True)
