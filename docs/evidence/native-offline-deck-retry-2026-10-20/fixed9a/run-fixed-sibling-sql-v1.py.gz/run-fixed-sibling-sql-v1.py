import datetime
import hashlib
import json
import os
import pathlib
import plistlib
import resource
import subprocess

resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
work = pathlib.Path(__file__).resolve().parent
root = work.parents[2]
inputs = json.loads((work / 'fixed-commit-inputs-v1.json').read_text())
publication = json.loads((work / 'fixed-api-and-sql-helper-publication-v1.json').read_text())
prior = json.loads((root / 'var/qa/destruction-fixed-e262-20261020/fixed-native-independent-verification-v2.json').read_text())
pg = pathlib.Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin')
cluster = root / 'var/qa/permanent-play-here-base-20261017/postgres'
socket = pathlib.Path('/tmp/rft-here-family-20261018-55486')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
write = lambda p, d: p.write_text(json.dumps(d, indent=2) + '\n')
out = work / 'fixed-sibling-real-sql-verification-v1.json'
assert not out.exists()
assert publication['status'] == 'PASS_FIXED_API_AND_SEPARATE_SQL_HELPERS_PUBLISHED'
assert publication['fixedCommit'] == inputs['fixedCommit']
assert len(prior['priorAuditRooms']) == 190 and len(prior['priorNativeRooms']) == 39
proof = {'status': 'RUNNING_FIXED_SIBLING_REAL_SQL', 'startedAtUtc': now(), 'fixedCommit': inputs['fixedCommit'],
         'actualRuleInputs': publication['actualRuleInputs'], 'priorAuditRooms': prior['priorAuditRooms'],
         'priorNativeRooms': prior['priorNativeRooms'], 'priorAuditSevenTables': prior['priorAuditSevenTables'],
         'priorNativeSevenTables': prior['priorNativeSevenTables'], 'noNewDatabaseOrCheckoutOrGodotBuild': True}
started = False
power = None
children = []
tables = ['matches', 'match_players', 'command_log', 'game_events', 'state_snapshots', 'snapshots', 'action_prompts']

def verify_inputs():
    assert all(sha(root / p) == h for p, h in inputs['sourceInputHashes'].items())
    assert all(sha(work / 'fixed-api' / p) == h for p, h in publication['apiRuntimeHashes'].items())
    for name, meta in publication['helpers'].items():
        assert all(sha(work / name / p) == h for p, h in meta['sourceHashes'].items())
        assert all(sha(work / name / 'bin/Release/net10.0' / p) == h for p, h in meta['runtimeHashes'].items())

def lock_observation():
    raw = plistlib.loads(subprocess.check_output(['/usr/sbin/ioreg', '-n', 'Root', '-d', '1', '-a']))
    return {'atUtc': now(), 'roots': [{'rootLocked': item.get('IOConsoleLocked'),
            'sessions': [s['CGSSessionScreenIsLocked'] for s in item.get('IOConsoleUsers', []) if 'CGSSessionScreenIsLocked' in s]}
            for item in raw], 'missingSessionIndicatorRemainsUnknown': True}

def command(db, sql):
    return [str(pg / 'psql'), '-XAt', '-h', '127.0.0.1', '-p', '55486', '-U', 'codex_riftbound_audit',
            '-d', db, '-v', 'ON_ERROR_STOP=1', '-c', sql]

readonly_env = dict(os.environ, PGOPTIONS='-c default_transaction_read_only=on')

def query(db, sql):
    return subprocess.check_output(command(db, sql), env=readonly_env, text=True).strip()

def rooms(db):
    return query(db, 'select match_id from matches order by match_id').splitlines()

def digests(db, ids):
    where = 'where match_id=ANY(ARRAY[' + ','.join("'" + p.replace("'", "''") + "'" for p in ids) + ']::text[])'
    result = {}
    for table in tables:
        args = command(db, f'select row_to_json(t)::text from {table} t {where} order by row_to_json(t)::text')
        process = subprocess.Popen(args, env=readonly_env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        value = hashlib.sha256()
        size = 0
        for data in iter(lambda: process.stdout.read(1024 * 1024), b''):
            value.update(data)
            size += len(data)
        error = process.stderr.read()
        assert process.wait() == 0, error.decode(errors='replace')[:500]
        if not size:
            value.update(b'\n')
        result[table] = value.hexdigest()
    return result

try:
    verify_inputs()
    assert subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), 'status'], capture_output=True).returncode == 3
    power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())])
    proof.update(ownRunnerPid=os.getpid(), boundIdleSleepAssertionPid=power.pid, lockAtStart=lock_observation())
    write(out, proof)
    socket.mkdir(exist_ok=True)
    subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-l', str(work / 'own-sibling-sql-postgres-v1.log'),
                    '-o', f'-p 55486 -h 127.0.0.1 -k {socket}', '-w', 'start'], capture_output=True, check=True)
    started = True
    assert rooms('riftbound_acceptance') == prior['priorAuditRooms']
    assert rooms('riftbound_here_native') == prior['priorNativeRooms']
    assert digests('riftbound_acceptance', prior['priorAuditRooms']) == prior['priorAuditSevenTables']
    assert digests('riftbound_here_native', prior['priorNativeRooms']) == prior['priorNativeSevenTables']
    assert all(query(db, 'show transaction_read_only') == 'on' for db in ['riftbound_acceptance', 'riftbound_here_native'])
    proof['allOriginal190Audit39NativeSevenTablesBeforeExactToPreviousIndependentBaseline'] = True
    env = dict(os.environ, ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit')
    env.pop('PGOPTIONS', None)
    results = work / 'actual-sibling-sql-v1'
    results.mkdir()
    writers = []
    for name in ['CoreRules', 'ChinaStandard20260724']:
        log = work / ('sql-writer-' + name + '-v1.log')
        stream = log.open('xb')
        child = subprocess.Popen(publication['helpers']['sql-prefix-driver']['command'] + [str(results / name), name],
                                 env=env, cwd=root, stdout=stream, stderr=subprocess.STDOUT)
        children.append(child)
        writers.append((name, child, stream))
    proof['ownSqlWriterPids'] = [p.pid for _, p, _ in writers]
    write(out, proof)
    codes = []
    for name, child, stream in writers:
        code = child.wait(timeout=1800)
        stream.close()
        codes.append(code)
        print('ACTUAL_SQL_WRITER', name, code, flush=True)
    assert codes == [0, 0], codes
    receipts = [json.loads((results / name / 'receipt.json').read_text()) for name, _, _ in writers]
    assert all(r['actualRuleInputs'] == publication['actualRuleInputs'] and r['commands'] == 116 and r['events'] == 482
               and r['coldCount'] == 5 and r['nextMatches'] == 4 and r['earnedSkills'] == 2 for r in receipts)
    new_rooms = [r['room'] for r in receipts]
    assert rooms('riftbound_acceptance') == sorted(prior['priorAuditRooms'] + new_rooms)
    assert rooms('riftbound_here_native') == prior['priorNativeRooms']
    assert digests('riftbound_acceptance', prior['priorAuditRooms']) == prior['priorAuditSevenTables']
    assert digests('riftbound_here_native', prior['priorNativeRooms']) == prior['priorNativeSevenTables']
    baseline = {'auditRooms': rooms('riftbound_acceptance'), 'nativeRooms': rooms('riftbound_here_native')}
    baseline['auditSevenTables'] = digests('riftbound_acceptance', baseline['auditRooms'])
    baseline['nativeSevenTables'] = digests('riftbound_here_native', baseline['nativeRooms'])
    write(work / 'after-sibling-writers-before-readonly-baseline-v1.json', baseline)
    log = work / 'sql-independent-reader-execution-v1.log'
    with log.open('xb') as stream:
        child = subprocess.Popen(publication['helpers']['sql-independent-reader']['command'] +
                                 [str(results), str(work / 'actual-independent-sibling-sql-readonly-v1.json')],
                                 env=env, cwd=root, stdout=stream, stderr=subprocess.STDOUT)
        children.append(child)
        code = child.wait(timeout=1800)
    assert code == 0, 'Independent actual SQL reader failed; preserve every original room and result.'
    independent = json.loads((work / 'actual-independent-sibling-sql-readonly-v1.json').read_text())
    assert independent['status'] == 'PASS_INDEPENDENT_READONLY_REAL_POSTGRES_TWO_FORMAT_SIBLING_ORIGINAL_HISTORY_AND_REPLAY'
    assert independent['actualRuleInputs'] == publication['actualRuleInputs'] and len(independent['checks']) == 2
    assert rooms('riftbound_acceptance') == baseline['auditRooms'] and rooms('riftbound_here_native') == baseline['nativeRooms']
    assert digests('riftbound_acceptance', baseline['auditRooms']) == baseline['auditSevenTables']
    assert digests('riftbound_here_native', baseline['nativeRooms']) == baseline['nativeSevenTables']
    verify_inputs()
    proof.update(status='PASS_FIXED_REAL_POSTGRES_TWO_FORMAT_SIBLING_ORIGINAL_HISTORY_COLD_AND_INDEPENDENT_REPLAY',
                 results=receipts, acceptedCommands=232, events=964, coldRestores=10, originalNextCommandsMatched=8,
                 allOriginal190Audit39NativeSevenTablesRetained=True, allCurrent192Audit39NativeSevenTablesUnchangedByIndependentRead=True,
                 independentResult=independent, all3303FixedSourcesAndApiHelperRuntimeInputsStillExact=True,
                 currentFixedFull='PENDING', ordinaryReentryVisibleNativeAndPhysicalWindows='OPEN')
except BaseException as error:
    proof.update(status='FAILED_ORIGINAL_SQL_PREFIX_RETAINED', errorType=type(error).__name__, errorMessage=str(error))
    raise
finally:
    for child in children:
        if child.poll() is None:
            child.terminate()
            child.wait(timeout=30)
    if started:
        proof['ownPostgresSmartStopped'] = subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-m', 'smart', '-w', '-t', '20', 'stop'],
                                                        capture_output=True).returncode == 0
    if power is not None:
        if power.poll() is None:
            power.terminate()
            power.wait(timeout=10)
        proof['boundIdleSleepAssertionEnded'] = power.poll() is not None
    proof.update(finishedAtUtc=now(), lockAtEnd=lock_observation(), originalDatabaseRetained=True)
    write(out, proof)
print(proof['status'], flush=True)
