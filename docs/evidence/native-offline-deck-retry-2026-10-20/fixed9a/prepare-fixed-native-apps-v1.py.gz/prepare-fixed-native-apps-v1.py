# coding: utf-8
import os
os.umask(0o077)
import datetime,hashlib,json,plistlib,shutil,subprocess,zipfile
from pathlib import Path
p=Path(__file__).resolve().parent;n=p/'native-current';temp=n/'temporary-package';temp.mkdir(exist_ok=False)
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
logs=[]
for platform,innername in [('mac','macos/Riftbound.zip'),('windows','windows/Riftbound-windows-x64.zip')]:
 with zipfile.ZipFile(n/(platform+'-ci-artifact.zip')) as z:
  assert z.testzip() is None
  for name in ['exported-boot.log','rune-table-lifecycle.log']:
   raw=z.read('ci-logs/'+name);target=n/'ci-logs'/platform/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
  assert b'[Riftbound] Client booted. Waiting for server authority.' in (n/'ci-logs'/platform/'exported-boot.log').read_bytes()
  assert b'RUNE_TABLE_LIFECYCLE_PASS: 2 freed-control transitions, 4 native signals' in (n/'ci-logs'/platform/'rune-table-lifecycle.log').read_bytes()
  inner=temp/(platform+'.zip');inner.write_bytes(z.read(innername))
 with zipfile.ZipFile(inner) as z:
  assert z.testzip() is None;entries=len(z.namelist());safe_root=(temp/"unpacked").resolve();assert all((safe_root/name).resolve().is_relative_to(safe_root) for name in z.namelist())
 logs.append({'platform':platform,'outerSha256':sha(n/(platform+'-ci-artifact.zip')),'bootLogSha256':sha(n/'ci-logs'/platform/'exported-boot.log'),'lifecycleLogSha256':sha(n/'ci-logs'/platform/'rune-table-lifecycle.log'),'bothSeparateLogMarkersVerified':True,'innerCrcVerified':True,'innerEntries':entries,'fixedCommit':'9a57068e986850a5e86bbeb9d0bbb2a92f44b7b4','fixedCiRun':39352144607,'physicalWindowsNotClaimed':True})
subprocess.run(['/usr/bin/ditto','-x','-k',str(temp/'mac.zip'),str(temp/'unpacked')],check=True)
apps=list((temp/'unpacked').rglob('*.app'));assert len(apps)==1;original=apps[0]
originals={str(f.relative_to(original)):sha(f) for f in original.rglob('*') if f.is_file()};payload={k:v for k,v in originals.items() if k.endswith(('.dll','.pck'))};assert len(payload)==373,len(payload)
records=[]
for label in ['a','b']:
 app=p/('Riftbound-'+label.upper()+'.app');assert not app.exists();subprocess.run(['cp','-cR',str(original),str(app)],check=True)
 info=app/'Contents/Info.plist';d=plistlib.loads(info.read_bytes());d['CFBundleIdentifier']='com.riftbound.qa.current-9a57068e.'+label;d['CFBundleName']='Riftbound-'+label.upper();d['CFBundleDisplayName']=d['CFBundleName'];d['CFBundleExecutable']='riftbound-qa-launcher';info.write_bytes(plistlib.dumps(d))
 executable=app/'Contents/MacOS/\u7b26\u6587\u6218\u573a';assert executable.exists();executable.chmod(0o755)
 source=p/('qa-launcher-'+label+'.c');log=p/('client-'+label+'.log');profile=p/('session-'+label+'.json')
 args=[str(executable),'--resolution','1280x720','--position','0,30','--','--riftbound-server=http://127.0.0.1:15847','--riftbound-session-file='+str(profile)]
 code='#include <unistd.h>\n#include <fcntl.h>\n#include <stdio.h>\nint main(void){\nint log=open('+json.dumps(str(log))+',O_WRONLY|O_CREAT|O_APPEND,0600);if(log<0)return 125;dup2(log,1);dup2(log,2);close(log);\nchar *const args[]={'+','.join(json.dumps(x,ensure_ascii=False) for x in args)+',0};execv(args[0],args);perror("execv native QA client");return 126;}\n'
 source.write_text(code);launcher=app/'Contents/MacOS/riftbound-qa-launcher';subprocess.run(['clang',str(source),'-o',str(launcher)],check=True,capture_output=True)
 subprocess.run(['codesign','--force','--deep','--sign','-',str(app)],check=True,capture_output=True);subprocess.run(['codesign','--verify','--deep','--strict',str(app)],check=True,capture_output=True)
 for k,v in payload.items():assert sha(app/k)==v,k
 changed=[k for k,v in originals.items() if sha(app/k)!=v]
 records.append({'label':label,'app':str(app),'bundleId':d['CFBundleIdentifier'],'all373CiManagedAndPckFilesExact':True,'deepStrictAdHocSignatureVerified':True,'changedNativeOrBundleFiles':changed,'launcherSourceSha256':sha(source),'profilePath':str(profile),'launcherPath':str(launcher)})
receipt={'recordedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fixedCommit':'9a57068e986850a5e86bbeb9d0bbb2a92f44b7b4','runId':39352144607,'originalInnerZipCrcVerified':True,'originalPackageFiles':originals,'ciManagedAndPckPayloads':payload,'apps':records,'platformArchiveAndLogProof':logs,'notYetVisibleAcceptance':True,'localVisibleBootNotYetExecuted':True,'supersededPairWillBeRetiredAfterCiPayloadSignatureArchiveChecksPerOnlyLatestInstruction':True,'physicalWindows':'OPEN'}
(p/'native-app-inputs.json').write_text(json.dumps(receipt,indent=2)+'\n');shutil.rmtree(temp)
print('new fixed9a57068e A/B ready;373 CI managed/PCK files each exact; signatures and both platform archive/boot/lifecycle proofs verified; temporary third app and inner ZIPs removed',flush=True)
