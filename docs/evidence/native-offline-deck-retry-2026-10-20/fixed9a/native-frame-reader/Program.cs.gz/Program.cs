using System.IO.Compression;
using System.Text.Json;
using Npgsql;
using Riftbound.Engine;
using Riftbound.Persistence;
var root = Path.GetFullPath(Environment.GetEnvironmentVariable("RIFTBOUND_FIXED_ACCEPTANCE_ROOT") ?? throw new Exception("Fixed acceptance evidence root required."));
if (!File.Exists(Path.Combine(root, "fixed-commit-inputs-v1.json"))) throw new Exception("Exact fixed publication required.");
var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
if (args.SequenceEqual(new[] { "identity-print" }))
{ Console.WriteLine(JsonSerializer.Serialize(RuleInputIdentity.Current, json)); return; }
var settings = new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
if (settings.Host != "127.0.0.1" || settings.Port != 55486 || settings.Username != "codex_riftbound_audit")
    throw new Exception("Only the existing dedicated audit cluster.");
settings.Options = "-c default_transaction_read_only=on";
await using var source = NpgsqlDataSource.Create(settings.ConnectionString);
if (args.Length == 3 && args[0] == "native-frame" && settings.Database == "riftbound_here_native")
{
    var frame = await new PostgresMatchRecoveryStore(source).LoadAsync(args[1], default)
        ?? throw new Exception("Missing original real native-network room.");
    if (!frame.IsConsistent || frame.AuthoritativeState is not { } state || state.RuleInputs != RuleInputIdentity.Current
        || frame.ReplayInitialState is not { Tick: 0 } initial || initial.CardObjects.Count != 0
        || frame.OpeningSeed == 0)
        throw new Exception("Original ordinary current-version frame invariant failed: " + string.Join(';',frame.ValidationErrors));
    var errors = await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame, new CoreRuleEngine(), default);
    if (errors.Count != 0) throw new Exception("Original real action-log replay failed: " + string.Join(';',errors));
    var path = Path.GetFullPath(args[2]);
    if (!path.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.Ordinal) || File.Exists(path))
        throw new Exception("Only a fresh bounded original-frame evidence file.");
    await using (var file = File.Create(path)) await using (var zip = new GZipStream(file, CompressionLevel.SmallestSize))
        await JsonSerializer.SerializeAsync(zip, frame, json);
    Console.WriteLine(JsonSerializer.Serialize(new { status="ORIGINAL_REAL_NATIVE_NETWORK_FRAME_FULL_REPLAY_PASS",
        room=args[1], commands=frame.Commands.Count, events=frame.Events.Count, stateHash=MatchStateHasher.Hash(state),
        actualRuleInputs=state.RuleInputs, originalNonZeroPrivateSeedPreserved=true, noOldHistoryMigration=true }, json)); return;
}
throw new Exception("Only fixed identity or a fresh original native frame.");
