# coding: utf-8
import datetime,hashlib,json,os,pathlib,subprocess,zipfile
os.umask(0o077);n=pathlib.Path(__file__).resolve().parent;index=json.loads((n/'fixed-native-artifact-index-v1.json').read_text());directory=n/'native-current';directory.mkdir(exist_ok=True);proof=[]
for name,file in [('native-macos-latest','mac-ci-artifact.zip'),('native-windows-latest','windows-ci-artifact.zip')]:
 meta=next(v for v in index['index']['artifacts'] if v['name']==name);assert not meta['expired'];target=directory/file;assert not target.exists()
 with target.open('xb') as out:subprocess.run(['gh','api',f'repos/DDDHL0704/riftbound/actions/artifacts/{meta["id"]}/zip'],stdout=out,check=True)
 actual=hashlib.sha256(target.read_bytes()).hexdigest();assert target.stat().st_size==meta['size_in_bytes'] and 'sha256:'+actual==meta['digest']
 with zipfile.ZipFile(target) as archive:assert archive.testzip() is None;entries=[{'name':v.filename,'bytes':v.file_size,'crc32':format(v.CRC,'08x')} for v in archive.infolist()]
 proof.append({'name':name,'id':meta['id'],'bytes':target.stat().st_size,'sha256':actual,'archive':str(target),'outerCrcVerified':True,'entries':entries});print(name,'DOWNLOADED_OUTER_SHA256_SIZE_AND_CRC_VERIFIED',flush=True)
(n/'fixed-native-download-v1.json').write_text(json.dumps({'observedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fixedCommit':index['fixedCommit'],'runId':index['runId'],'artifacts':proof,'nativeBootAndInnerArchiveChecksStillRequired':True,'oldE262PairNotRetiredBeforeUsableNewPairVerified':True},indent=2)+'\n')
