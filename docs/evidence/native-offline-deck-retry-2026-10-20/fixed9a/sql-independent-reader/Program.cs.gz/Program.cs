using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.CardCatalog;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
try
{
    if (args.SequenceEqual(["identity-print"])) { Console.WriteLine(JsonSerializer.Serialize(RuleInputIdentity.Current, json)); return; }
    Check(args.Length == 2 && !File.Exists(args[1]), "Original two-case SQL evidence root and fresh independent receipt required.");
    var work = Path.GetFullPath(args[0]);
    var settings = new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
    Check(settings.Host == "127.0.0.1" && settings.Port == 55486 && settings.Database == "riftbound_acceptance"
        && settings.Username == "codex_riftbound_audit", "Existing dedicated original database required.");
    settings.Options = "-c default_transaction_read_only=on";
    await using var source = NpgsqlDataSource.Create(settings.ConnectionString);
    var checks = new List<object>();
    var catalog = await OfficialCardCatalog.LoadDefaultAsync();
    foreach (var format in new[] { "CoreRules", "ChinaStandard20260724" })
    {
        var file = Path.Combine(work, format, "final-original-frame.json.gz");
        var originalBytes = File.ReadAllBytes(file); var hash = Convert.ToHexStringLower(SHA256.HashData(originalBytes));
        await using var zip = new GZipStream(new MemoryStream(originalBytes), CompressionMode.Decompress);
        var node = await JsonNode.ParseAsync(zip) ?? throw new Exception("Original SQL frame required.");
        var original = node.Deserialize<MatchRecoveryFrame>(json)!;
        Check(JsonNode.DeepEquals(node, JsonSerializer.SerializeToNode(original, json)), "All original saved SQL frame fields and nulls survive typed read.");
        var frame = await new PostgresMatchRecoveryStore(source).LoadAsync(original.RoomId, default) ?? throw new Exception("Actual original database frame required.");
        Check(JsonNode.DeepEquals(node, JsonSerializer.SerializeToNode(frame, json)), "All fields, nulls, commands, events, original private views and prompts equal actual database.");
        Check(frame.IsConsistent && frame.OpeningSeed == 0 && frame.ReplayInitialState is { Tick: 0, Seed: 0 } blank && blank.CardObjects.Count == 0
            && frame.Commands.Count == 116 && frame.Events.Count == 482 && frame.Commands.All(c => c.Accepted && c.RuleInputs == RuleInputIdentity.Current)
            && frame.AuthoritativeState!.RuleInputs == RuleInputIdentity.Current, "Actual blank original seed, 116 accepted commands, 482 events and actual fixed runtime identity.");
        const string phoenix = "P1-MAIN-OGN-037-298-01";
        var state = frame.AuthoritativeState!;
        Check(state.Status == MatchStatuses.InProgress && state.PlayerZones["P1"].Base.Contains(phoenix) && state.CardObjects[phoenix].ObjectGeneration == 4
            && state.StackItems.Count == 0 && state.TriggerQueue.Count == 0 && state.PendingEffectPlay is null && state.PendingPayment is null,
            "Actual ordinary original-generation play and final old sibling no-op; this remains a prefix.");
        Check(frame.Commands.Count(c => c.CommandType == CommandTypes.SubmitDeck) == 2
            && frame.Commands.All(c => c.CommandType != "SURRENDER" && c.CommandType != "DEV_SEED_SCENARIO"), "Two actually submitted decks, no injected state or surrender.");
        foreach (var command in frame.Commands.Where(c => c.CommandType == CommandTypes.SubmitDeck))
        {
            var deck = (SubmitDeckCommand)GameCommandJsonMapper.Map(command.RawCommand!.Value);
            foreach (var f in new[] { OfficialDeckFormat.CoreRules, OfficialDeckFormat.ChinaStandard20260724 })
                Check(OfficialDeckValidator.Validate(new(deck.LegendCardNo, deck.ChampionCardNo, deck.MainDeck, deck.RuneDeck, deck.Battlefields), catalog, f).IsValid, "Both actual decks independently legal in both exact formats.");
        }
        var confirmed = frame.Events.Count(e => e.Event.Kind == "TRIGGER_CONFIRMED" && Payload(e).GetProperty("sourceObjectId").GetString() == phoenix);
        var declined = frame.Events.Count(e => e.Event.Kind == "TRIGGER_PAYMENT_DECLINED" && Payload(e).GetProperty("sourceObjectId").GetString() == phoenix);
        Check(confirmed == 2 && declined == 1, "First actual self skill declined, two later skills independently confirmed.");
        var originalPhases = new Dictionary<string, MatchRecoveryFrame>();
        foreach (var phasePath in Directory.GetFiles(Path.Combine(work, format), "*-original-frame.json.gz").Where(p => Path.GetFileName(p) != "last-original-frame.json.gz"))
        {
            await using var phaseZip = new GZipStream(File.OpenRead(phasePath), CompressionMode.Decompress);
            var phaseNode = await JsonNode.ParseAsync(phaseZip) ?? throw new Exception("Original SQL phase required.");
            var phase = phaseNode.Deserialize<MatchRecoveryFrame>(json)!;
            Check(JsonNode.DeepEquals(phaseNode, JsonSerializer.SerializeToNode(phase, json)), "All original SQL phase fields and nulls retained.");
            originalPhases.Add(Path.GetFileName(phasePath), phase);
        }
        Check(originalPhases.Count == 5, "All five original SQL cold checkpoints required.");
        var two = originalPhases["two-original-skills-paid-original-frame.json.gz"].AuthoritativeState!;
        var effect = originalPhases["original-effect-play-with-sibling-original-frame.json.gz"].AuthoritativeState!;
        Check(two.PendingPayment is null && two.StackItems.Count == 2 && two.StackItems.All(s => s.GraveyardPlay!.Source == new ObjectBinding(phoenix, 3)
            && s.TriggerCost!.Mana == 1 && s.TriggerCost.Power == 1), "Both actual independent fees and original incarnation at persisted two-skill checkpoint.");
        Check(effect.PendingEffectPlay!.Parent.GraveyardPlay!.Source == new ObjectBinding(phoenix, 3)
            && effect.StackItems.Single().GraveyardPlay!.Source == new ObjectBinding(phoenix, 3), "Persisted effect-play and surviving sibling are independent original references.");
        var deaths = frame.Events.Where(e => e.Event.Kind == "UNIT_DESTROYED").ToArray();
        Check(deaths.Count(e => Payload(e).GetProperty("destructionAttribution").GetProperty("cardNo").GetString() == "UNL-180/219") == 2,
            "Two actual units destroyed by the declared Ruination spell.");
        var history = new Dictionary<string, int>();
        var matchedPhases = new HashSet<string>();
        await using (var connection = await source.OpenConnectionAsync())
        {
            Check((string)(await new NpgsqlCommand("show transaction_read_only", connection).ExecuteScalarAsync())! == "on", "Actual database enforces read-only independent validation.");
            foreach (var table in new[] { "state_snapshots", "snapshots", "action_prompts" })
            {
                await using var query = new NpgsqlCommand($"select payload::text from {table} where match_id=@room order by id", connection);
                query.Parameters.AddWithValue("room", frame.RoomId); await using var rows = await query.ExecuteReaderAsync(); var count = 0;
                while (await rows.ReadAsync())
                {
                    var raw = rows.GetString(0); var originalPayload = JsonNode.Parse(raw);
                    var restored = table switch {
                        "state_snapshots" => JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<MatchState>(raw, json), json),
                        "snapshots" => JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<SnapshotDto>(raw, json), json),
                        _ => JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<ActionPromptDto>(raw, json), json) };
                    Check(JsonNode.DeepEquals(originalPayload, restored), "Every original historical state/private snapshot/prompt field and null retained."); count++;
                    if (table == "state_snapshots")
                        foreach (var pair in originalPhases)
                            if (JsonNode.DeepEquals(originalPayload, JsonSerializer.SerializeToNode(pair.Value.AuthoritativeState, json))) matchedPhases.Add(pair.Key);
                }
                Check(count > 0, "Actual historical rows required."); history[table] = count;
            }
        }
        Check(matchedPhases.Count == 5, "All five original authoritative cold checkpoint states exactly match actual historical database payloads.");
        var errors = await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame, new CoreRuleEngine(), default);
        Check(errors.Count == 0, "Full original SQL action/event/final-state replay: " + string.Join(';', errors));
        Check(Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(file))) == hash, "Original saved frame was not rewritten.");
        checks.Add(new { room = frame.RoomId, format, commands = 116, events = 482, confirmed, declined,
            actualHistoricalPayloads = history, matchedOriginalSqlCheckpointStates = matchedPhases.Count, originalFrameSha256 = hash, allOriginalFieldsNullsAndPrivateHistoryMatch = true,
            fullOriginalReplayMatched = true });
    }
    await File.WriteAllTextAsync(args[1], JsonSerializer.Serialize(new { status = "PASS_INDEPENDENT_READONLY_REAL_POSTGRES_TWO_FORMAT_SIBLING_ORIGINAL_HISTORY_AND_REPLAY",
        actualRuleInputs = RuleInputIdentity.Current, checks, noNewGameplayOrStateSeedHistoryRewrite = true,
        completeGameReentryVisibleWindowsOrWholePrintingCertified = false }, json));
    Console.WriteLine("PASS_INDEPENDENT_READONLY_REAL_POSTGRES_TWO_FORMAT_SIBLING_ORIGINAL_HISTORY_AND_REPLAY");
}
catch (Exception error) { Console.Error.WriteLine(error); Environment.ExitCode = 1; }
static JsonElement Payload(RecoveredEvent e) => JsonSerializer.SerializeToElement(e.Event.Payload);
static void Check(bool value, string reason) { if (!value) throw new Exception(reason); }
