import datetime
import hashlib
import json
import os
import pathlib
import plistlib
import socket
import subprocess
import time
import urllib.request

work = pathlib.Path(__file__).resolve().parent
root = work.parents[2]
pg = pathlib.Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin')
cluster = root / 'var/qa/permanent-play-here-base-20261017/postgres'
sock = pathlib.Path('/tmp/rft-here-family-20261018-55486')
inputs = json.loads((work / 'fixed-commit-inputs-v1.json').read_text())
publication = json.loads((work / 'fixed-api-and-sql-helper-publication-v1.json').read_text())
baseline = json.loads((work / 'after-sibling-writers-before-readonly-baseline-v2.json').read_text())
sql_proof = json.loads((work / 'fixed-sibling-real-sql-verification-v2.json').read_text())
assert sql_proof['status'].startswith('PASS_FIXED_REAL_POSTGRES') and sql_proof['ownPostgresSmartStopped']
assert len(baseline['auditRooms']) == 192 and len(baseline['nativeRooms']) == 39
assert 'RB-9A5706' not in baseline['nativeRooms']
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
write = lambda p, d: p.write_text(json.dumps(d, indent=2) + '\n')
out = work / 'visible-native-api-owner-v1.json'
ready = work / 'visible-native-api-ready-v1.json'
stop = work / 'visible-native-api-stop-v1.json'
restart = work / 'visible-native-api-restart-request-v1.json'
assert not any(p.exists() for p in [out, ready, stop, restart])
proof = {'status': 'STARTING_OWN_FIXED_VISIBLE_NATIVE_API', 'startedAtUtc': now(), 'fixedCommit': inputs['fixedCommit'],
         'actualRuleInputs': publication['actualRuleInputs'], 'allowedNewNativeRoom': 'RB-9A5706',
         'priorAuditRooms': baseline['auditRooms'], 'priorNativeRooms': baseline['nativeRooms'],
         'priorAuditSevenTables': baseline['auditSevenTables'], 'priorNativeSevenTables': baseline['nativeSevenTables'],
         'acceptanceNotInferredFromRunningServices': True, 'ownedApiProcesses': [], 'restartRequestsHandled': 0}
started = False
api = power = None
tables = ['matches', 'match_players', 'command_log', 'game_events', 'state_snapshots', 'snapshots', 'action_prompts']
read_env = dict(os.environ, PGOPTIONS='-c default_transaction_read_only=on')

def query(db, sql):
    return subprocess.check_output([str(pg / 'psql'), '-XAt', '-h', '127.0.0.1', '-p', '55486', '-U', 'codex_riftbound_audit',
                                    '-d', db, '-v', 'ON_ERROR_STOP=1', '-v', 'FETCH_COUNT=8', '-c', sql], env=read_env, text=True).strip()

def rooms(db):
    return query(db, 'select match_id from matches order by match_id').splitlines()

def digests(db, ids):
    where = 'where match_id=ANY(ARRAY[' + ','.join("'" + p.replace("'", "''") + "'" for p in ids) + ']::text[])'
    result = {}
    for table in tables:
        args = [str(pg / 'psql'), '-XAt', '-h', '127.0.0.1', '-p', '55486', '-U', 'codex_riftbound_audit', '-d', db,
                '-v', 'ON_ERROR_STOP=1', '-v', 'FETCH_COUNT=8', '-c', f'select row_to_json(t)::text from {table} t {where} order by row_to_json(t)::text']
        process = subprocess.Popen(args, env=read_env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        value = hashlib.sha256()
        size = 0
        for block in iter(lambda: process.stdout.read(1024 * 1024), b''):
            value.update(block)
            size += len(block)
        error = process.stderr.read()
        assert process.wait() == 0, error.decode(errors='replace')[:500]
        if not size:
            value.update(b'\n')
        result[table] = value.hexdigest()
    return result

def verify_inputs():
    assert all(sha(root / p) == h for p, h in inputs['sourceInputHashes'].items())
    assert all(sha(work / 'fixed-api' / p) == h for p, h in publication['apiRuntimeHashes'].items())

def observe_lock():
    data = plistlib.loads(subprocess.check_output(['/usr/sbin/ioreg', '-n', 'Root', '-d', '1', '-a']))
    return {'atUtc': now(), 'roots': [{'rootLocked': p.get('IOConsoleLocked'),
            'sessions': [s['CGSSessionScreenIsLocked'] for s in p.get('IOConsoleUsers', []) if 'CGSSessionScreenIsLocked' in s]}
            for p in (data if isinstance(data, list) else [data])], 'missingValuesRemainUnknown': True}

def start_api(index):
    global api
    log = work / ('visible-native-api-' + str(index) + '.log')
    with log.open('xb') as stream:
        api = subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet', str(work / 'fixed-api/Riftbound.Api.dll')], cwd=work / 'fixed-api',
                               env=dict(os.environ, ASPNETCORE_ENVIRONMENT='Production', ASPNETCORE_URLS='http://127.0.0.1:15847',
                                        ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit'),
                               stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    for attempt in range(150):
        assert api.poll() is None
        try:
            with urllib.request.urlopen('http://127.0.0.1:15847/health', timeout=1) as response:
                health = json.load(response)
            assert health['persistenceMode'] == 'postgres' and health['environment'] == 'Production'
            assert set(subprocess.check_output(['/usr/sbin/lsof', '-tiTCP:15847', '-sTCP:LISTEN'], text=True).splitlines()) == {str(api.pid)}
            proof['ownedApiProcesses'].append({'pid': api.pid, 'index': index, 'log': log.name, 'startedAtUtc': now(), 'health': health})
            return
        except OSError:
            time.sleep(.1)
    raise AssertionError('Own exact published production API did not become ready.')

try:
    verify_inputs()
    assert subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), 'status'], capture_output=True).returncode == 3
    with socket.socket() as guard:
        guard.settimeout(.5)
        assert guard.connect_ex(('127.0.0.1', 15847)) != 0
    power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())])
    proof.update(ownRunnerPid=os.getpid(), idleAssertionPid=power.pid, lockAtStart=observe_lock())
    write(out, proof)
    sock.mkdir(exist_ok=True)
    subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-l', str(work / 'visible-native-postgres-v1.log'),
                    '-o', f'-p 55486 -h 127.0.0.1 -k {sock}', '-w', 'start'], capture_output=True, check=True)
    started = True
    assert rooms('riftbound_acceptance') == baseline['auditRooms'] and rooms('riftbound_here_native') == baseline['nativeRooms']
    assert digests('riftbound_acceptance', baseline['auditRooms']) == baseline['auditSevenTables']
    assert digests('riftbound_here_native', baseline['nativeRooms']) == baseline['nativeSevenTables']
    proof['allOriginal192Audit39NativeSevenTablesMatchedBeforeApi'] = True
    start_api(0)
    proof['status'] = 'OWN_FIXED_PRODUCTION_API_READY_NOT_YET_VISIBLE_ACCEPTANCE'
    write(out, proof)
    write(ready, {'atUtc': now(), 'fixedCommit': inputs['fixedCommit'], 'apiPid': api.pid, 'url': 'http://127.0.0.1:15847',
                  'realDatabase': 'riftbound_here_native', 'actualRuleInputs': publication['actualRuleInputs'], 'allowedNewNativeRoom': 'RB-9A5706'})
    print('OWN_FIXED_PRODUCTION_NATIVE_API_READY', api.pid, flush=True)
    deadline = time.monotonic() + 5400
    while not stop.exists():
        assert api.poll() is None
        assert time.monotonic() < deadline, 'Owned visible acceptance session expired; original database retained.'
        if restart.exists() and proof['restartRequestsHandled'] == 0:
            verify_inputs()
            api.terminate()
            assert api.wait(timeout=30) == 0
            proof['restartRequestsHandled'] = 1
            start_api(1)
            write(work / 'visible-native-api-restart-complete-v1.json', {'atUtc': now(), 'fixedCommit': inputs['fixedCommit'], 'newApiPid': api.pid,
                                                                     'originalApiPid': proof['ownedApiProcesses'][0]['pid'], 'actualRuleInputs': publication['actualRuleInputs']})
            write(out, proof)
            print('OWN_FIXED_NATIVE_API_COLD_RESTART_READY', api.pid, flush=True)
        time.sleep(.5)
    proof['status'] = 'OWN_VISIBLE_API_STOP_REQUESTED_PENDING_ORIGINAL_ROW_VERIFICATION'
finally:
    if api is not None and api.poll() is None:
        api.terminate()
        proof['ownApiGracefulStopExit'] = api.wait(timeout=30)
    if started:
        proof['originalAuditRoomsStillExact'] = rooms('riftbound_acceptance') == baseline['auditRooms']
        proof['allOriginal192AuditSevenTablesUnchanged'] = digests('riftbound_acceptance', baseline['auditRooms']) == baseline['auditSevenTables']
        proof['allOriginal39NativeSevenTablesUnchanged'] = digests('riftbound_here_native', baseline['nativeRooms']) == baseline['nativeSevenTables']
        proof['allNativeRoomsAfter'] = rooms('riftbound_here_native')
        proof['onlyExpectedNewNativeRoom'] = set(proof['allNativeRoomsAfter']) - set(baseline['nativeRooms']) <= {'RB-9A5706'}
        verify_inputs()
        proof['all3303SourceAndPublishedApiInputsStillExact'] = True
        proof['ownPostgresSmartStopped'] = subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-m', 'smart', '-w', '-t', '20', 'stop'], capture_output=True).returncode == 0
    if power is not None:
        if power.poll() is None:
            power.terminate()
            power.wait(timeout=10)
        proof['boundIdleSleepAssertionEnded'] = power.poll() is not None
    proof.update(finishedAtUtc=now(), lockAtEnd=observe_lock(), originalDatabaseRetained=True)
    write(out, proof)
