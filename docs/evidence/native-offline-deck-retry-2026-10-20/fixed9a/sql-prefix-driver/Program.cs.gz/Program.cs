using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;
using Npgsql;
using Riftbound.Persistence;
using System.Text.Json;
using System.Text.Json.Nodes;
using Riftbound.CardCatalog;
using Riftbound.Contracts;
using Riftbound.Engine;

if (args.Length != 2) throw new Exception("Fresh output and exact format required.");
var output = Path.GetFullPath(args[0]);
if (Directory.Exists(output)) throw new Exception("Original outputs must not be replaced.");
Directory.CreateDirectory(output);
var format = Enum.Parse<OfficialDeckFormat>(args[1]);
var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
using var recipe = JsonDocument.Parse(await File.ReadAllTextAsync(Path.Combine(AppContext.BaseDirectory, "Fixtures", "destruction-graveyard-openings.json")));
var settings = new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
Check(settings.Host == "127.0.0.1" && settings.Port == 55486 && settings.Database == "riftbound_acceptance"
    && settings.Username == "codex_riftbound_audit", "Existing dedicated original audit database required.");
await using var source = NpgsqlDataSource.Create(settings.ConnectionString);
string databaseVersion;
await using (var connection = await source.OpenConnectionAsync())
    databaseVersion = (string)(await new NpgsqlCommand("select version()", connection).ExecuteScalarAsync())!;
Check(databaseVersion.StartsWith("PostgreSQL 16.13", StringComparison.Ordinal), "Actual original PostgreSQL server required.");
var initial = MatchReplayInitialStateBuilder.FromSeats("postgres-sibling-source-" + format + "-" + Guid.NewGuid().ToString("N"),
    new Dictionary<string, string> { ["P1"] = "P1", ["P2"] = "P2" });
Check(initial.Tick == 0 && initial.Seed == 0 && initial.CardObjects.Count == 0, "Actual blank initial and original zero seed.");
var engine = new CoreRuleEngine(); var journal = new Journal(new PostgresMatchJournal(source));
var players = new PostgresMatchPlayerStore(source); var store = new PostgresMatchRecoveryStore(source);
foreach (var player in initial.Seats.Keys)
    await players.SavePlayerSessionAsync(initial.RoomId, player, player, ReconnectTokenHasher.Hash("sibling-sql-" + Guid.NewGuid().ToString("N")), default);
var options = new MatchSessionOptions(AllowLegacyReadyWithoutDeck: false, DeckFormat: format);
IMatchSession session = new MatchSession(initial, engine, journal, players, options);
var state = initial; var coldCount = 0; var nextMatches = 0; var afterCold = false;
var milestones = new List<object>();
MatchRecoveryFrame Frame()
{
    var sequence = journal.Entries[^1].CompletedEventSequence;
    var snapshots = ResolutionResult.BuildSnapshots(state); var prompts = ResolutionResult.BuildPrompts(state);
    var views = initial.Seats.Keys.ToDictionary(p => p, p => new RecoveredPlayerView(p, state.Tick, sequence,
        snapshots[p], state.Tick, sequence, prompts[p]));
    var spectator = MatchReplayRedactor.BuildSpectatorFrame(initial.RoomId, state.Tick, sequence, [], state);
    var errors = MatchRecoveryValidator.Validate(initial.RoomId, sequence, journal.Commands(), journal.Events(), views, state, state.Tick, spectator);
    return new(initial.RoomId, state.Tick, sequence, journal.Commands(), journal.Events(), views, errors, state, initial, spectator);
}
async Task Act(string actor, GameCommand command)
{
    if (command is SubmitDeckCommand deck)
    {
        var catalog = await OfficialCardCatalog.LoadDefaultAsync();
        foreach (var f in new[] { OfficialDeckFormat.CoreRules, OfficialDeckFormat.ChinaStandard20260724 })
        {
            var valid = OfficialDeckValidator.Validate(new(deck.LegendCardNo, deck.ChampionCardNo, deck.MainDeck, deck.RuneDeck, deck.Battlefields), catalog, f);
            Check(valid.IsValid, string.Join(';', valid.Errors));
        }
    }
    var intent = "ordinary-sibling-v2-" + journal.Entries.Count;
    var fields = JsonSerializer.SerializeToNode(command, command.GetType(), json)!.AsObject();
    fields["promptId"] = session.PromptFor(actor).PromptId; fields["snapshotTick"] = state.Tick;
    var raw = JsonSerializer.SerializeToElement(fields, json);
    var expected = afterCold ? await engine.ResolveAsync(state, new(intent, actor, command.CmdType), command, default) : null;
    var result = command switch {
        SubmitDeckCommand submitted => await session.SubmitDeckAsync(actor, intent, submitted, raw, default),
        ReadyCommand => await session.ReadyAsync(actor, intent, raw, default),
        _ => await session.SubmitAsync(actor, intent, command, raw, default) };
    Check(result.Accepted, command.CmdType + ": " + result.ErrorMessage);
    if (afterCold)
    {
        Check(expected!.Accepted && MatchStateHasher.Hash(expected.State) == MatchStateHasher.Hash(result.State)
            && JsonNode.DeepEquals(JsonSerializer.SerializeToNode(expected.Events), JsonSerializer.SerializeToNode(result.Events)), "Original next command remains equal after cold restore.");
        nextMatches++;
    }
    state = result.State; afterCold = false;
    Check(Frame().ValidationErrors.Count == 0, "Accepted command retained valid recovery shape.");
}
async Task Cold(string label)
{
    var digestBefore = await Digest();
    var before = await store.LoadAsync(initial.RoomId, default) ?? throw new Exception("Actual original SQL recovery frame required.");
    Check(before.IsConsistent && before.Commands.Count == journal.Entries.Count && before.OpeningSeed == 0
        && MatchStateHasher.Hash(before.AuthoritativeState!) == MatchStateHasher.Hash(state), "Actual SQL original history and current state.");
    Check(before.ValidationErrors.Count == 0, "Ordinary actual SQL frame shape.");
    var original = JsonSerializer.SerializeToNode(before, json);
    var restored = JsonSerializer.Deserialize<MatchRecoveryFrame>(JsonSerializer.Serialize(before, json), json)!;
    Check(JsonNode.DeepEquals(original, JsonSerializer.SerializeToNode(restored, json)), "Every original field and null survives typed roundtrip.");
    var errors = await MatchActionLogReplayer.ValidateRecoveryFrameAsync(restored, engine, default);
    Check(errors.Count == 0, label + ": full original ordinary opening/action/event replay " + string.Join(';', errors));
    var previous = session;
    session = await new InMemoryMatchSessionRegistry(engine, journal, store, players, options).GetOrCreateAsync(initial.RoomId, default);
    foreach (var player in initial.Seats.Keys)
    {
        Check(JsonNode.DeepEquals(JsonSerializer.SerializeToNode(previous.SnapshotFor(player)), JsonSerializer.SerializeToNode(session.SnapshotFor(player))), "Private snapshot restored.");
        Check(JsonNode.DeepEquals(JsonSerializer.SerializeToNode(previous.PromptFor(player)), JsonSerializer.SerializeToNode(session.PromptFor(player))), "Private prompt restored.");
    }
    Check(await Digest() == digestBefore, "Cold database reads, replay and registry restore preserve every original row in all seven tables.");
    coldCount++; afterCold = true;
    await Save(label + "-original-frame.json.gz", before);
    milestones.Add(new { label, state.Tick, commands = before.Commands.Count, events = before.Events.Count, hash = MatchStateHasher.Hash(state) });
}
async Task Save(string name, object value)
{
    await using var file = new FileStream(Path.Combine(output, name), FileMode.CreateNew);
    await using var zip = new GZipStream(file, CompressionLevel.SmallestSize);
    await JsonSerializer.SerializeAsync(zip, value, value.GetType(), json);
}
async Task Resources(int mana, int red)
{
    while (state.RunePools["P1"].Mana < mana)
    {
        var rune = state.PlayerZones["P1"].Base.FirstOrDefault(id => state.CardObjects[id].Tags.Contains(CardObjectTags.RuneCard) && !state.CardObjects[id].IsExhausted);
        Check(rune is not null, "Enough actual ready runes for this new ordinary prefix.");
        await Act("P1", new TapRuneCommand(rune!));
    }
    while (state.RunePools["P1"].PowerByTrait.GetValueOrDefault("red") < red)
    {
        var rune = state.PlayerZones["P1"].Base.FirstOrDefault(id => state.CardObjects[id].Tags.Contains(CardObjectTags.RuneCard) && state.CardObjects[id].Tags.Contains("COLOR:red"));
        Check(rune is not null, "Enough actual red runes for independent leading fees.");
        if (!state.CardObjects[rune!].IsExhausted) await Act("P1", new TapRuneCommand(rune!));
        await Act("P1", new RecycleRuneCommand(rune!));
    }
}
async Task Top() { await Act(state.PriorityPlayerId!, new PassPriorityCommand()); await Act(state.PriorityPlayerId!, new PassPriorityCommand()); }
async Task Pay()
{
    var payment = state.PendingPayment ?? throw new Exception("Independent leading confirmation required.");
    Check(payment.ManaCost == 1 && payment.PowerCostByTrait.GetValueOrDefault("red") == 1, "Original printed leading fee.");
    await Resources(1, 1); await Act("P1", new PayCostCommand(payment.PaymentId, payment.PaymentWindow, ["PAY"]));
}
try
{
    var inputIndex = 0;
    foreach (var row in recipe.RootElement.GetProperty("openingIntents").EnumerateArray())
    {
        var command = GameCommandJsonMapper.Map(row.GetProperty("rawCommand"));
        if (inputIndex == 0)
        {
            var originalDeck = (SubmitDeckCommand)command;
            Check(originalDeck.MainDeck.Count(c => c == "SFD·018/221") == 3, "Three exact filler cards identified.");
            command = originalDeck with { MainDeck = originalDeck.MainDeck.Select(c => c == "SFD·018/221" ? "UNL-180/219" : c).ToArray() };
        }
        await Act(row.GetProperty("playerId").GetString()!, command); inputIndex++;
    }
    Check(journal.Entries.Count == 82, "Original next 81 intents retained; first deck explicitly substitutes three fillers only.");
    await Cold("derived-legal-82-prefix");
    var phoenix = recipe.RootElement.GetProperty("phoenixObjectId").GetString()!;
    await Resources(1, 1);
    await Act("P1", GameCommandJsonMapper.Map(recipe.RootElement.GetProperty("selfRayIntent").GetProperty("rawCommand"))); await Top();
    Check(state.PlayerZones["P1"].Graveyard.Contains(phoenix) && state.CardObjects[phoenix].ObjectGeneration == 3, "Actual self spell first graveyard incarnation.");
    var declined = state.PendingPayment ?? throw new Exception("Actual self leading confirmation.");
    await Act("P1", new PayCostCommand(declined.PaymentId, declined.PaymentWindow, ["DECLINE"]));
    Check(state.StackItems.Count == 0 && state.PendingEffectPlay is null, "Original self skill explicitly declined.");
    await Cold("original-self-skill-declined");
    var extra = state.PlayerZones["P1"].Hand.First(id => state.CardObjects[id].CardNo == "OGN·010/298");
    await Resources(2, 0); await Act("P1", new PlayCardCommand(extra, "OGN·010/298", []));
    Check(state.CardObjects[extra].IsExhausted, "No unnecessary Haste fee; actual ordinary unit in base.");
    await Act("P1", new EndTurnCommand()); await Act("P2", new EndTurnCommand());
    await Resources(11, 2);
    while (state.RunePools["P1"].PowerByTrait.GetValueOrDefault("yellow") < 3)
    {
        var rune = state.PlayerZones["P1"].Base.First(id => state.CardObjects[id].Tags.Contains(CardObjectTags.RuneCard) && state.CardObjects[id].Tags.Contains("COLOR:yellow"));
        if (!state.CardObjects[rune].IsExhausted) await Act("P1", new TapRuneCommand(rune));
        await Act("P1", new RecycleRuneCommand(rune));
    }
    var ruin = state.PlayerZones["P1"].Hand.First(id => state.CardObjects[id].CardNo == "UNL-180/219");
    await Act("P1", new PlayCardCommand(ruin, "UNL-180/219", [])); await Top();
    var earned = state.TriggerQueue.Count;
    Check(earned >= 2 && state.TriggerQueue.All(t => t.GraveyardPlay?.Source == new ObjectBinding(phoenix, 3)), "Actual mass destruction earns at least two independent original-generation skills.");
    await Act("P1", new OrderTriggersCommand(OrderedTriggerIds: state.TriggerQueue.Select(t => t.TriggerId).Order(StringComparer.Ordinal).ToArray()));
    for (var i = 0; i < earned; i++)
    {
        if (i < 2) await Pay();
        else { var cost = state.PendingPayment ?? throw new Exception("Every later skill has its own optional leading fee.");
            await Act("P1", new PayCostCommand(cost.PaymentId, cost.PaymentWindow, ["DECLINE"])); }
    }
    Check(state.StackItems.Count == 2 && state.PendingPayment is null, "Exactly two actual independently paid skills remain.");
    await Cold("two-original-skills-paid"); await Top();
    Check(state.PendingEffectPlay is not null && state.StackItems.Count == 1, "Shared effect play opens with sibling remaining.");
    await Cold("original-effect-play-with-sibling");
    await Act("P1", new PlayCardCommand(phoenix, "OGN·037/298", []));
    Check(state.PlayerZones["P1"].Base.Contains(phoenix) && state.CardObjects[phoenix].ObjectGeneration == 4, "Ordinary original Phoenix play accepts despite sibling reference.");
    await Top();
    Check(state.StackItems.Count == 0 && state.TriggerQueue.Count == 0 && state.PendingEffectPlay is null && state.PendingPayment is null, "Old sibling independently finishes without borrowing new source.");
    await Cold("final");
    await File.WriteAllTextAsync(Path.Combine(output, "receipt.json"), JsonSerializer.Serialize(new { status = "PASS_REAL_POSTGRES_BLANK_LEGAL_DERIVED_DECK_SEED_AND_ACTUAL_TWO_SKILLS_SHARED_PLAY",
        room = initial.RoomId, format, databaseVersion, commands = journal.Commands().Length, events = journal.Events().Length, coldCount, nextMatches, earnedSkills = earned, actualRuleInputs = state.RuleInputs,
        originalNext81IntentsAndSeedRetained = true, explicitlyDerivedDeckThreeFillerSubstitutions = true, noStateMutation = true, completeOrdinaryOriginalReplayMatched = true,
        visibleProductOrReentryOrWholePrintingCertified = false, actualRealPostgresOriginalHistory = true, actualLoadedModules = new[] { typeof(CoreRuleEngine).Assembly, typeof(GameCommand).Assembly, typeof(OfficialCardCatalog).Assembly, typeof(PostgresMatchJournal).Assembly, typeof(NpgsqlDataSource).Assembly }.Select(a => new { file = Path.GetFileName(a.Location), sha256 = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(a.Location))), mvid = a.ManifestModule.ModuleVersionId }).ToArray() }, json));
    Console.WriteLine("PASS_REAL_POSTGRES_BLANK_LEGAL_DERIVED_DECK_SEED_AND_ACTUAL_TWO_SKILLS_SHARED_PLAY");
}
catch (Exception error)
{
    Console.Error.WriteLine(error.ToString()); Environment.ExitCode = 1;
    await File.WriteAllTextAsync(Path.Combine(output, "driver-failure.txt"), error.ToString());
}
finally
{
    await Save("original-command-attempts.json.gz", journal.Entries);
    await Save("last-original-frame.json.gz", Frame());
    await File.WriteAllTextAsync(Path.Combine(output, "milestones.json"), JsonSerializer.Serialize(milestones, json));
}
async Task<string> Digest()
{
    using var hash = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
    await using var connection = await source.OpenConnectionAsync();
    foreach (var table in new[] { "matches", "match_players", "command_log", "game_events", "state_snapshots", "snapshots", "action_prompts" })
    {
        hash.AppendData(Encoding.UTF8.GetBytes(table + "\n")); var any = false;
        await using var command = new NpgsqlCommand($"select row_to_json(t)::text from {table} t where match_id=@room order by row_to_json(t)::text", connection);
        command.Parameters.AddWithValue("room", initial.RoomId); await using var rows = await command.ExecuteReaderAsync();
        while (await rows.ReadAsync()) { any = true; hash.AppendData(Encoding.UTF8.GetBytes(rows.GetString(0) + "\n")); }
        if (!any) hash.AppendData(Encoding.UTF8.GetBytes("\n"));
    }
    return Convert.ToHexStringLower(hash.GetHashAndReset());
}
static void Check(bool value, string message) { if (!value) throw new Exception(message); }
sealed class Journal(PostgresMatchJournal inner) : IMatchJournal
{
    public List<MatchJournalEntry> Entries { get; } = [];
    public async ValueTask RecordAsync(MatchJournalEntry e, CancellationToken token) { await inner.RecordAsync(e, token); Entries.Add(e); }
    public RecoveredCommand[] Commands() => Entries.Select(e => new RecoveredCommand(e.PlayerId, e.ClientIntentId, e.CommandType, e.RawCommand,
        e.StartedTick, e.CompletedTick, e.StartedEventSequence, e.CompletedEventSequence, e.Accepted, e.ErrorMessage) { RuleInputs = e.RuleInputs }).ToArray();
    public RecoveredEvent[] Events() => Entries.SelectMany(e => e.Events.Select((ev, i) => new RecoveredEvent(e.StartedEventSequence + i + 1, e.CompletedTick, i, ev))).ToArray();
}
