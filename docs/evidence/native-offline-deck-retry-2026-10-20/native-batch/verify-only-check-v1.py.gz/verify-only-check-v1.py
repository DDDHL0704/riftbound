import collections,datetime,hashlib,json,pathlib,re,stat,subprocess,xml.etree.ElementTree as ET
work=pathlib.Path(__file__).resolve().parent
root=work.parents[2]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
terminal=load(work/'only-check-terminal-integrity-v1.json')
assert terminal['checkExitCode']==0 and terminal['allDeclaredInputsAndRuntimeFilesStable'] and terminal['boundIdleSleepAssertionEnded'] and terminal['noSecondCheck']
assert not terminal['changedSourceInputs'] and not terminal['changedConformanceRuntimeFiles']
summary=load(work/'only-check/summary.json');assert summary['status']=='PASSED' and summary['total']==13107
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def read(path):
 tree=ET.parse(path);defs={d.attrib['id']:d.find('t:TestMethod',ns).attrib for d in tree.findall('.//t:UnitTest',ns)}
 rows=tree.findall('.//t:UnitTestResult',ns)
 cases=collections.Counter(row.attrib['testName'] for row in rows)
 methods={defs[row.attrib['testId']]['className']+'.'+defs[row.attrib['testId']]['name'] for row in rows}
 return cases,methods,collections.Counter(row.attrib['outcome'] for row in rows)
current_path=work/'only-check/check/results.trx';previous_path=work.parent/'graveyard-lifecycle-source-followup-20261020/only-check/check/results.trx'
cases,methods,outcomes=read(current_path);old_cases,old_methods,old_outcomes=read(previous_path)
assert cases==old_cases and methods==old_methods and sum(cases.values())==13107 and len(methods)==7467
assert outcomes=={'Passed':13107}
baseline=load(work/'baseline-and-native-regression-scope-v1.json');unchanged=baseline['allOriginalTestsAndScripts']
assert all(sha(root/p)==h for p,h in unchanged.items()) and len(unchanged)==1859
stage=subprocess.check_output(['git','ls-tree','-rz','HEAD','--','tests','scripts'],cwd=root)
mode_checks=0
for row in stage.split(b'\0'):
 if not row:continue
 meta,name=row.split(b'\t',1);mode=meta.split()[0].decode();path=root/name.decode()
 if mode not in ['100644','100755']:continue
 assert bool(path.stat().st_mode & 0o111)==(mode=='100755'),str(path)
 mode_checks+=1
full=baseline['nineOriginalFullGameSourceHashes'];assert len(full)==9 and all(sha(root/p)==h for p,h in full.items())
full_methods={name for p in full for name in re.findall(r'\bpublic\s+(?:async\s+)?(?:Task|void)\s+(\w+)\s*\(', (root/p).read_text())};assert len(full_methods)==143
start=load(work/'only-check-start-inputs-v1.json')
assert all(sha(root/p)==h for p,h in start['sourceInputHashes'].items()) and all(sha(root/p)==h for p,h in start['actualConformanceRuntimeFileHashes'].items())
identity=load(work/'actual-conformance-rule-inputs-v1.json');assert identity['status'].startswith('PASS_ACTUAL_CHECK_RUNTIME')
proof={'status':'SOLE_CHECK13107_ALL_ORIGINAL_CASES_AND7467_METHODS_EXACTLY_RETAINED_PASS','recordedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cases':13107,'methods':7467,'failed':0,'skipped':0,'sourceInputCount':len(start['sourceInputHashes']),'runtimeInputCount':len(start['actualConformanceRuntimeFileHashes']),'allOriginalCaseMultisetAndMethodsExactlyEqual':True,'originalTestAndScriptFiles':len(unchanged),'unchangedGitExecutableModePaths':mode_checks,'originalFullGameSourceFiles':9,'originalFullGameMethodIdentities':143,'original110PairsSeed424242VictoryReplayAssertionsNotModified':True,'actualTrxSha256':sha(current_path),'previousCheckTrxSha256':sha(previous_path),'allSourceAndRuntimeInputsStableThroughTerminal':True,'actualConformanceRuleInputs':identity['actualRuleInputs'],'mainChangedLineNotExecutedByConformance':True,'newFixedNativeOfflineSameServerRegressionRequired':True,'noOptionalSqlSmokeMisrepresentedAsRealDatabase':True,'noGodotSdkOrProjectBuild':True,'noSecondCheck':True}
out=work/'only-check-retention-and-disposition-v1.json';assert not out.exists();out.write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
