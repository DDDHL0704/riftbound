import collections
import datetime
import gzip
import hashlib
import json
import pathlib
import re
import xml.etree.ElementTree as ET
import zipfile

work = pathlib.Path(__file__).resolve().parent
root = work.parents[2]
sha = lambda b: hashlib.sha256(b).hexdigest()
ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
commit = 'e262ebf164e448cc9738d94db8e557f302cfc295'
run = 39340733951
terminal = json.loads((work / f'ci-terminal-or-progress-{run}-v1.json').read_text())
assert terminal['headSha'] == commit and terminal['status'] == 'completed' and terminal['conclusion'] == 'success'
assert len(terminal['jobs']) == 11 and all(j['status'] == 'completed' and j['conclusion'] == 'success' for j in terminal['jobs'])
index = json.loads((work / 'prior-fixed-ci-available-evidence-v1.json').read_text())
artifacts = {x['run']: {a['name']: a for a in x['actual']['artifacts']} for x in index}
zip_paths = {
 0: work / 'ci-originals/39340733951-postgres-partition-0.zip',
 1: work.parent / 'graveyard-source-fixed-candidate-20261020/original-e262-ci-postgres-partition-1.zip',
 2: work.parent / 'destruction-fixed-e262-20261020/original-ci-postgres-partition-2.zip',
 3: work.parent / 'destruction-fixed-e262-20261020/original-ci-postgres-partition-3.zip'}
manifest_path = root / 'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'
manifest_hash = sha(manifest_path.read_bytes())
case_ids = [c['id'] for c in json.loads(manifest_path.read_text())['cases']]
assert len(case_ids) == len(set(case_ids)) == 45
partitions = []
for i, p in zip_paths.items():
 a = artifacts[run][f'postgres-partition-{i}']
 assert sha(p.read_bytes()) == a['digest'][7:] and p.stat().st_size == a['size_in_bytes']
 with zipfile.ZipFile(p) as z:
  assert z.testzip() is None
  receipt_bytes = z.read('ci-postgres/partition-receipt.json')
  d = json.loads(receipt_bytes)
  expected = case_ids[i::4]
  assert d['status'] == 'REAL_POSTGRES_PARTITION_COMPLETE' and d['fixedCommit'] == commit
  assert d['partitionIndex'] == i and d['partitionCount'] == 4 and d['manifestSha256'] == manifest_hash
  assert d['orderedDefaultCases'] == case_ids and d['expectedCases'] == d['completedCases'] == expected
  assert [e['id'] for e in d['executions']] == expected and all(e['status'] == 'PASSED' and e['seconds'] >= 0 for e in d['executions'])
  assert [e['ordinal'] for e in d['executions']] == list(range(len(expected)))
  outputs = []
  for row in d['outputFiles']:
   payload = z.read('ci-postgres/' + row['path'])
   assert len(payload) == row['bytes'] and sha(payload) == row['sha256']
   outputs.append(row['path'])
  assert len(outputs) == len(set(outputs)) and len(d['runtimeAssemblies']) == 5
  partitions.append({'partitionIndex': i, 'cases': expected, 'outputFilesVerified': len(outputs),
   'receiptSha256': sha(receipt_bytes), 'actualRuleInputs': d['actualRuleInputs'], 'runtimeAssemblies': d['runtimeAssemblies'],
   'originalZip': str(p.relative_to(root)), 'originalZipSha256': sha(p.read_bytes())})
assert len({json.dumps(p['actualRuleInputs'],sort_keys=True) for p in partitions}) == 1
assert len({json.dumps(p['runtimeAssemblies'],sort_keys=True) for p in partitions}) == 1
assert sum(len(p['cases']) for p in partitions) == 45 and set(c for p in partitions for c in p['cases']) == set(case_ids)
with zipfile.ZipFile(work / 'ci-originals/39340733951-postgres-results.zip') as z:
 gate = json.loads(z.read('result.json'))
 assert gate['status'] == 'FIXED_COMMIT_ALL_SQL_PARTITIONS_AND_NATIVE_NETWORK_PASS' and gate['fixedCommit'] == commit
 assert gate['manifestSha256'] == manifest_hash and gate['caseCount'] == 45 and gate['orderedDefaultCases'] == case_ids
 assert gate['partitionCount'] == 4 and all(v == 'success' for v in gate['jobs'].values())
 for g, p in zip(gate['partitions'], partitions):
  assert g['partitionIndex'] == p['partitionIndex'] and g['receiptSha256'] == p['receiptSha256'] and g['cases'] == p['cases']
  assert g['actualRuleInputs'] == p['actualRuleInputs'] and g['runtimeAssemblies'] == p['runtimeAssemblies']
with zipfile.ZipFile(work / 'ci-originals/39340733951-full-verification-gate.zip') as z:
 full_gate = json.loads(z.read('result.json'))
 assert full_gate['status'] == 'FIXED_COMMIT_FULL_CHILD_JOBS_ALL_SUCCEEDED' and full_gate['commit'] == commit
 assert all(v == 'success' for v in full_gate['jobs'].values())

cases = collections.Counter(); methods = set(); trx_hashes = {}; matrix_records = []
with zipfile.ZipFile(work / 'ci-originals/39340733951-conformance-results.zip') as z:
 assert z.testzip() is None and z.read('ci-rule-suite-commit.txt').decode().strip() == commit
 plan = json.loads(z.read('ci-rules/plan.json')); summary = json.loads(z.read('ci-rules/summary.json'))
 assert summary['status'] == 'PASSED' and summary['profile'] == 'full' and summary['total'] == 13249
 assert all(s['total'] == s['passed'] and not s['failed'] and not s['notExecuted'] for s in summary['shards'])
 planned = [m for s in plan['shards'] for m in s['methods']]
 assert len(planned) == len(set(planned)) == plan['discoveredMethods'] == 7605
 for name in z.namelist():
  if not name.endswith('/results.trx'): continue
  data = z.read(name); trx_hashes[name] = sha(data); tree = ET.fromstring(data)
  defs = {d.attrib['id']: d.find('t:TestMethod',ns).attrib for d in tree.findall('.//t:UnitTest',ns)}
  actual_shard = set()
  for result in tree.findall('.//t:UnitTestResult',ns):
   assert result.attrib['outcome'] == 'Passed'
   definition = defs[result.attrib['testId']]
   method = definition['className'] + '.' + definition['name']
   actual_shard.add(method); methods.add(method); cases[result.attrib['testName']] += 1
   for stdout in result.findall('.//t:StdOut',ns):
    for line in (stdout.text or '').splitlines():
     if line.startswith('PRECONSTRUCTED_MATRIX '): matrix_records.append(json.loads(line[len('PRECONSTRUCTED_MATRIX '):]))
  shard = name.split('/')[-2]
  assert actual_shard == set(next(s['methods'] for s in plan['shards'] if s['name'] == shard))
 assert methods == set(planned) and sum(cases.values()) == 13249
assert len(matrix_records) == 1
matrix = matrix_records[0]
actual_decks = json.loads(gzip.decompress((work.parent / 'graveyard-source-fixed-candidate-20261020/native-visible-v1/live-api-eleven-preconstructed-decks-original.json.gz').read_bytes()))
ids = [d['id'] for d in actual_decks]
assert len(ids) == len(set(ids)) == 11
expected_pairs = {a + '-vs-' + b for a in ids for b in ids if a != b}
assert matrix['seed'] == 424242 and matrix['deckCount'] == 11 and matrix['pairCount'] == 110
assert set(matrix['completed']) == expected_pairs and len(matrix['completed']) == 110
assert all(re.fullmatch('[0-9a-f]{64}', value) for value in matrix['completed'].values())
fullgame_source_files = sorted((root / 'tests/Riftbound.ConformanceTests').glob('FullGameEndToEndTests*.cs'))
expected_methods = {'Riftbound.ConformanceTests.FullGameEndToEndTests.' + name for p in fullgame_source_files
 for name in re.findall(r'\bpublic\s+(?:async\s+)?(?:Task|void)\s+(\w+)\s*\(',p.read_text())}
actual_fullgame = {m for m in methods if m.startswith('Riftbound.ConformanceTests.FullGameEndToEndTests.')}
assert len(fullgame_source_files) == 9 and len(expected_methods) == 143 and actual_fullgame == expected_methods
baseline_tree = ET.parse(work.parent / 'graveyard-lifecycle-source-followup-20261020/only-check/check/results.trx')
baseline_cases = collections.Counter(r.attrib['testName'] for r in baseline_tree.findall('.//t:UnitTestResult',ns)
 if not r.attrib['testName'].startswith('Riftbound.ConformanceTests.DestructionGraveyardSourceOccupationTests.'))
assert sum(baseline_cases.values()) == 13100 and not baseline_cases - cases
network = work.parent / 'destruction-fixed-e262-20261020/original-ci-native-network-results.zip'
assert sha(network.read_bytes()) == artifacts[run]['native-network-results']['digest'][7:]
with zipfile.ZipFile(network) as z:
 assert z.testzip() is None
 network_json = {n:json.loads(z.read(n)) for n in z.namelist() if n.endswith('.json')}
result = {'status':'PASS_INDEPENDENT_ACTUAL_E262_FULL_CI_ALL_ORIGINAL_CASES_143_METHODS110PAIRS_AND45_SQL_IDENTITIES',
 'observedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'fixedCommit':commit, 'run':run,
 'actualCompletedSuccessJobs':len(terminal['jobs']), 'actualCases':13249, 'actualUniqueMethods':7605,
 'all13100PrecedingOriginalCheckCasesRetained':True, 'nineFullGameSourceFiles':9,'all143OriginalFullGameMethodsPass':True,
 'preconstructedMatrix':matrix,'originalTrxSha256':trx_hashes,'actualConformanceTestAssemblySha256':plan['testAssemblySha256'],
 'ordered45DefaultSqlCases':case_ids,'manifestSha256':manifest_hash,'partitions':partitions,
 'aggregateGateReceiptMatchesEveryOriginalPartition':True,'fullGateAllFixedChildrenPass':True,
 'originalNetworkArtifactSha256':sha(network.read_bytes()),'actualNetworkReceipts':network_json,
 'separateFromNineAOrFutureNativeAndCurrentFull':True,'wholeRuleOrCardSemanticsOrPhysicalWindowsCertified':False}
out = work / 'prior-e262-full-ci-independent-all-gates-readback-v1.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'cases':13249,'uniqueMethods':7605,'originalFullGameMethods':143,'pairs':110,'sqlIdentities':45,
 'sqlOutputFiles':sum(p['outputFilesVerified'] for p in partitions),'proof':str(out.relative_to(root))}))
