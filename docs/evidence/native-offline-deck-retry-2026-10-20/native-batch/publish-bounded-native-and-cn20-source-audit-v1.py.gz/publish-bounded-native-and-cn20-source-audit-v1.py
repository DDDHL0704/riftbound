import copy,datetime,gzip,hashlib,importlib.util,json,os,pathlib,subprocess
work=pathlib.Path(__file__).resolve().parent
root=work.parents[2]
evidence=root/'docs/evidence/native-offline-deck-retry-2026-10-20'
identity='native-offline-start-same-server-preconstructed-retry-2026-10-20'
base='9a57068e986850a5e86bbeb9d0bbb2a92f44b7b4'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p,value):
 assert not p.exists(),str(p)
 p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def pin(p,role=None):
 return {'path':str(p.relative_to(root)),'sha256':sha(p),'role':role or p.stem}
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==base
check=load(work/'only-check-retention-and-disposition-v1.json')
assert check['status'].startswith('SOLE_CHECK13107') and check['failed']==check['skipped']==0
assert check['allOriginalCaseMultisetAndMethodsExactlyEqual'] and check['allSourceAndRuntimeInputsStableThroughTerminal']
start=load(work/'only-check-start-inputs-v1.json')
assert all(sha(root/p)==h for p,h in start['sourceInputHashes'].items())
assert all(sha(root/p)==h for p,h in start['actualConformanceRuntimeFileHashes'].items())
assert load(work/'focus-native-lobby-adapters-v1/summary.json')['total']==18
source=root/'var/qa/typed-stack-consumer-source-readback-20261020'
impact=load(source/'current-source-change-and-doc03-visual-impact-disposition-v1.json')
assert impact['currentDoc03BytesExactlyMatchRetainedOctober10Pdf'] and impact['all241AffectedRowsCurrentlyOutsideActiveRuntime']
assert impact['sourceVersionComparison']['changedFullRows']==241
fixed=root/'var/qa/graveyard-source-fixed-candidate-20261020'
native=load(fixed/'native-visible-v1/fixed-visible-mac-native-acceptance-v1.json')
assert native['normalVictory']['acceptedCommands']==28 and native['normalVictory']['events']==206
assert native['ownApiAndPgGracefullyStopped'] and native['allOriginal192Audit39NativeSevenTablesUnchanged']
prior_ci=load(work/'prior-e262-full-ci-independent-all-gates-readback-v1.json')
assert prior_ci['actualCases']==13249 and prior_ci['actualUniqueMethods']==7605 and len(prior_ci['preconstructedMatrix']['completed'])==110
assert load(work/'nine-a-four-sql-and-native-network-independent-original-readback-v1.json')['originalSqlOutputFilesVerified']==242
manifest_path=root/'docs/audit/current-manifest.json'
reviews_path=root/'docs/evidence/rules-reaudit-2026-10-11/review-decisions.json'
prior=load(manifest_path);old_reviews=load(reviews_path)
assert len(prior['reviewContexts'])==58 and len(prior['acceptanceGates'])==235 and len(old_reviews['reviews'])==143
prior_ids=set(json.loads(gzip.decompress((root/'docs/evidence/graveyard-source-occupation-2026-10-20/remaining-obligation-ids.json.gz').read_bytes())))
assert len(prior_ids)==16908
for p,name in [(manifest_path,'prior-original-current-manifest.json.gz'),(reviews_path,'prior-original-review-decisions.json.gz')]:
 q=work/name;assert not q.exists();q.write_bytes(gzip.compress(p.read_bytes(),mtime=0))
archive=load(work/'fixed-nine-a-and-cn20-canonical-archive-map-precheck-v2.json')['records']
raw={'.json','.jsonl','.gz','.zip','.png','.jpg','.jpeg','.webp'}
text={'.py','.cs','.csproj','.trx','.log','.md','.c','.txt','.yml','.yaml'}
for p in sorted(work.rglob('*')):
 rel=p.relative_to(work)
 if not p.is_file() or {'bin','obj','__pycache__','actual-check-identity-read-v1','publication-draft'}.intersection(rel.parts) or p.suffix not in raw|text or rel.as_posix()=='publication-v1.log':continue
 target=evidence/'native-batch'/rel;compressed=p.suffix in text
 if compressed:target=target.with_name(target.name+'.gz')
 target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists()
 b=p.read_bytes()
 if compressed:target.write_bytes(gzip.compress(b,mtime=0))
 else:os.link(p,target)
 assert (gzip.decompress(target.read_bytes()) if compressed else target.read_bytes())==b
 archive.append({'originalPath':str(p.relative_to(root)),'originalSha256':sha(p),'originalBytes':len(b),'canonical':pin(target),'gzipOriginalBytes':compressed,'samePhysicalFileHardlinked':not compressed})
assert all((root/x['canonical']['path']).stat().st_size<10*2**20 for x in archive)
assert not any('/native-current/' in x['canonical']['path'] and x['canonical']['path'].endswith('.zip') for x in archive)
write(evidence/'archive-map.json',{'records':archive,'originalBytesAndHashesVerified':True,'runtimeSdkDatabaseAppsAndTwoAuthenticationProfilesExcluded':True,'onlyTwoExactNativePackageAliasesRemovedBeforeCommit':True,'necessaryFourCiBootLifecycleLogsRetained':True})
source_pin=pin(evidence/'cn20-sources/current-source-change-and-doc03-visual-impact-disposition-v1.json','cn20-source-impact')
source_view_pin=pin(evidence/'cn20-sources/current-complete-cn-source-version-view-v1.json','cn20-complete-source-version')
native_pin=pin(evidence/'fixed9a/native-visible-v1/fixed-visible-mac-native-acceptance-v1.json','fixed9a-visible-native-original-score')
sql_pin=pin(evidence/'fixed9a/fixed-sibling-real-sql-verification-v2.json','fixed9a-two-format-sibling-real-sql')
check_pin=pin(evidence/'native-batch/only-check-retention-and-disposition-v1.json','sole-check-all-original-cases-retained')
ci_pin=pin(evidence/'native-batch/prior-e262-full-ci-independent-all-gates-readback-v1.json','prior-e262-full-ci-independent')
net_pin=pin(evidence/'native-batch/prior-e262-network-original-log-independent-readback-v1.json','prior-e262-original-network-independent')
current_sql_pin=pin(evidence/'native-batch/nine-a-four-sql-and-native-network-independent-original-readback-v1.json','fixed9a-original-sql-and-network-ci')
source_manifest={'recordedAtUtc':now(),'region':'CN','language':'zh-CN','applicableRuleBaseline':'2026-10-16','scope':'One native empty-list fetch retry; independent preceding fixed9a SQL/native and source-only CN20 version evidence.','baseCommit':base,'includesOneUncommittedNativeImplementationChange':True,'implementation':pin(root/'clients/godot/scripts/Main.cs','implementation'),'allEngineContractsCatalogDataAndTestSourceFilesUnchanged':True,'originalFailure':pin(evidence/'fixed9a/native-visible-v1/offline-start-deck-list-defect-checkpoint-v1.json'),'nativeIssue':'https://github.com/DDDHL0704/riftbound/issues/70','sourceVersionIssue':'https://github.com/DDDHL0704/riftbound/issues/71','oldFixed9aRestartWorkaroundDoesNotFixOriginalPath':True,'currentFocus':{'cases':18,'methods':17,'actualNewMainOfflineRetryNotExercised':True},'soleCheck':check_pin,'actualCurrentConformanceDebugInputs':check['actualConformanceRuleInputs'],'fixed9aMacReleaseInputs':native['actualBackendRuleInputs'],'actualLinuxCiInputsSeparatelyRecordedInOriginalReceipts':True,'earlierE262FullCi':ci_pin,'earlierE262Network':net_pin,'fixed9aSiblingSql':sql_pin,'fixed9aVisibleProduct':native_pin,'fixed9aAllFourSqlAndNetworkCi':current_sql_pin,'newCandidateNativeSameProcessOfflineOnlineSameServerSubmission':'OPEN_AWAIT_NEW_FIXED_NATIVE_PACKAGE_ACTUAL_PATH','newCandidateFixedFull':'PENDING_AFTER_COMMIT','physicalWindows':'OPEN','currentCn20SourceImpact':source_pin,'currentCn20FullSourceView':source_view_pin,'newSourceVersionRecordedWithoutRuntimeAdoption':True,'wholeCardOrWholeFamilyOrGlobalAuditCertified':False,'allOriginal143FullGameMethods110PairsAndSeedsRetained':True,'noOldDevelopmentMatchMigrationOrDslExpansion':True,'onlyLatestUsablePairAndOnePackagePerOsRetained':True,'noNewLocalGodotSdkProjectBuildWholeCheckoutOrDatabase':True}
write(evidence/'source-manifest.json',source_manifest);manifest_pin=pin(evidence/'source-manifest.json','source-manifest')
doc_path=root/'docs/NATIVE_OFFLINE_DECK_RETRY_AUDIT_2026-10-20.md';assert not doc_path.exists()
check_text=('本批唯一check实际13107例/7467方法全过、零失败零跳过，与前一check全部用例多重集合及方法完全相同。1859个原测试/脚本及Git执行位、九份FullGame143方法、110配对/原种子/胜利回放断言保留；3303源码和1399执行载荷在检查期间精确一致，无第二次check。当前Debug实际身份'+check['actualConformanceRuleInputs']['identitySha256']+'与固定9a Mac Release10ab、Linux CI bd90和旧e262身份分别绑定。18条相邻检查通过，Main修改行并不在Conformance编译范围，实际新原生路径仍OPEN。')
doc_path.write_text((work/'native-offline-deck-retry-audit-draft-v1.md').read_text().replace('@CHECK_DETAILS@',check_text))
reviews=copy.deepcopy(old_reviews)
reviews['reviews'].append({'id':identity,'scope':'Native lobby preconstructed fetch after offline startup and later same-server connection; no rule semantics change.','status':'ONE_NATIVE_CONDITION_FOCUS18_SOLECHECK13107_PASS_NEW_FIXED_NATIVE_AND_FULL_OPEN','subjects':[],'ruleRecords':[],'pendingRuleRecords':[],'sourceManifest':manifest_pin,'auditDocument':str(doc_path.relative_to(root)),'testExecution':{'cases':18,'conformanceCheckCases':13107,'actualChangedMainPathExercised':False},'exclusions':['WHOLE_CARD_OR_RULE_FAMILY_SEMANTICS','NEW_MAIN_NATIVE_OFFLINE_RETRY_ACCEPTANCE','CURRENT_FIXED_FULL','PHYSICAL_WINDOWS']})
reviews_path.write_text(json.dumps(reviews,ensure_ascii=False,indent=2)+'\n')
spec=importlib.util.spec_from_file_location('governance',root/'scripts/audit/check-project-governance.py');checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
revision=checker.digest(checker.gameplay_inputs(root));manifest=copy.deepcopy(prior);rebindings=[]
for key,context in manifest['reviewContexts'].items():
 changes=[]
 for field in ['implementation','verificationSources']:
  for ref in context.get(field,[]):
   actual=sha(root/ref['path'])
   if actual!=ref['sha256']:
    changes.append({'field':field,'path':ref['path'],'previousSha256':ref['sha256'],'currentSha256':actual});ref['sha256']=actual
 previous={f:context.get(f) for f in ['currentInputRevision','currentImplementationCommit','currentImplementationIncludesUncommittedChanges','ciState']}
 context.setdefault('implementationPinUpdates',[]).append({'batch':identity,'changes':changes,'previousCurrentMetadata':previous,'previousEntireContextPreservedIn':str((evidence/'native-batch/prior-original-current-manifest.json.gz').relative_to(root)),'scope':'Only native empty-list retry changed. Original source/semantic/runtime evidence retained; new fixed full and native still required.'})
 context.update(currentInputRevision=revision,currentImplementationCommit=base,currentImplementationIncludesUncommittedChanges=True,ciState='PENDING',revalidationReason='One native catalog retry condition; new exported Main and fixed full separate.')
 rebindings.append({'review':key,'previousEntireContextSha256':checker.digest(prior['reviewContexts'][key]),'changedPins':changes})
manifest['inputs']['reviews']=pin(reviews_path,prior['inputs']['reviews'].get('role','reviews'))
manifest['reviewContexts'][identity]={'evidenceCommit':base,'currentImplementationCommit':base,'currentImplementationIncludesUncommittedChanges':True,'evidenceCommitScope':'Fixed9a actual negative and preceding native score; base9a plus one Main source change for this check. No new compiled Main acceptance claimed.','currentInputRevision':revision,'ciState':'PENDING','ciReceipts':[],'region':'CN','language':'zh-CN','applicableAsOf':'2026-10-16','sourceManifest':manifest_pin,'implementation':[pin(root/'clients/godot/scripts/Main.cs','implementation')],'verificationSources':[],'evidence':[check_pin,ci_pin,net_pin,current_sql_pin,native_pin,sql_pin,source_pin],'branches':[]}
for gate in manifest['acceptanceGates']:
 if gate['id']=='GRAVEYARD_SOURCE_OCCUPATION_FIXED_FULL_SIBLING_SQL_VISIBLE_AND_WINDOWS':gate['postCommitFixedNineAReadback']={'fixedCommit':base,'actualMacReleaseIdentity':native['actualBackendRuleInputs']['identitySha256'],'realTwoFormatSiblingSql':sql_pin,'boundedVisibleMacColdReconnectNormalScoreAndOriginalDbReplay':native_pin,'allFourSqlAndNativeNetworkCi':current_sql_pin,'originalGateAndRemainingRequirementsPreserved':True,'offlineStartupAndPhysicalWindowsStillOpen':True,'wholePrintingCertified':False}
manifest['acceptanceGates'].extend([
 {'id':'NATIVE_OFFLINE_START_SAME_SERVER_DECK_RETRY_NEW_FIXED_NATIVE_FULL_AND_WINDOWS','state':'OPEN','region':'CN','language':'zh-CN','sourceManifest':manifest_pin,'requirement':'New exported Main in the same process: offline startup, service availability, same-server connect, deck choices and authoritative submission. Preserve loaded/changed-server paths, fixed full and physical Windows; restart workaround is not closure.','semanticReview':'NO_RULE_SEMANTIC_CHANGE','implementation':'ONE_EXISTING_LOADER_RETRY_CONDITION','testExecution':'ADJACENT18_AND_SOLECHECK13107_PASS_MAIN_PATH_SEPARATE','fixedCommitCi':'PENDING','productAcceptance':'OPEN_NEW_EXPORTED_MAIN_REQUIRED','wholePrintingCertified':False},
 {'id':'CN20_241_API_ROW_VERSION_AND_FOUR_RAD_ERRATA_REGIONAL_IMPLEMENTATION_ACCEPTANCE','state':'OPEN','region':'CN','language':'zh-CN','sourceManifest':source_pin,'requirement':'Retain all241 exact API versions and original printing parents; distinguish metadata/T1S newline/API-errata changes from unchanged DOC03. Independently close regional format/date applicability and each of four exact RAD shared behavior, implementation, tests, fixed CI, native/Windows acceptance. No automatic runtime adoption.','semanticReview':'COMPLETE1504_ROW_DIFF_AND_FOUR_FULL_PDF_PAGES_ONLY','implementation':'ALL241_AFFECTED_ROWS_OUTSIDE_CURRENT_RUNTIME','testExecution':'OPEN_FOR_FUTURE_APPLICABLE_BEHAVIORS','fixedCommitCi':'OPEN_FOR_FUTURE_IMPLEMENTATION','productAcceptance':'OPEN','wholePrintingCertified':False}])
manifest['laterSourceDeltas'].append({'kind':'cn_cards','region':'CN','language':'zh-CN','before':prior['laterSourceDeltas'][-1]['after'],'after':source_view_pin,'impact':source_pin,'disposition':'Same1504 raw card-number set;241 API rows change.236 RAD IDs/products plus4 existing-DOC03 errata fields;5 T1S IDs with3 CRLF/LF-only effects and1 preview flag. No current runtime rows bound; prior versions/date gaps/printing parents retained. New API snapshot is separate from original DOC03 and never silently runtime-adopted.'})
manifest['currentNativeOfflineDeckRetryInputChange']=manifest_pin
manifest['currentFixedNineASiblingSqlAndVisibleScoreReadback']={'sourceManifest':manifest_pin,'fixedCommit':base,'realSql':sql_pin,'visibleMac':native_pin,'allFourSqlAndNetworkCi':current_sql_pin,'newCandidateOrWholePrintingNotCertified':True}
manifest['currentCn20CompleteSourceVersionAndFourErrataReadback']=source_pin
manifest['previousE262ActualFullCiReadback']=ci_pin
manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
result=checker.current_audit(root,manifest);assert result['governanceValid'],result['errors']
new_ids={x['id'] for x in result['remainingObligations']}
assert prior_ids<=new_ids and len(new_ids-prior_ids)==3 and len(new_ids)==16911
assert reviews['reviews'][:-1]==old_reviews['reviews'] and manifest['laterSourceDeltas'][:-1]==prior['laterSourceDeltas']
for old_gate,new_gate in zip(prior['acceptanceGates'],manifest['acceptanceGates']):assert all(new_gate[k]==v for k,v in old_gate.items())
write(evidence/'remaining-obligation-ids.json',sorted(new_ids))
write(evidence/'current-context-rebindings.json',{'priorEntireManifest':pin(evidence/'native-batch/prior-original-current-manifest.json.gz'),'changedMainSourcePins':[x for x in rebindings if x['changedPins']],'allPrior58ContextsAndOriginalScopesEvidencePreserved':True,'newInputRevision':revision})
write(evidence/'unified-obligation-retention.json',{'priorReviews':143,'currentReviews':144,'priorContexts':58,'currentContexts':59,'priorGates':235,'currentGates':237,'priorRemainingObligations':16908,'currentRemainingObligations':16911,'allOriginalIdsRetained':True,'newIds':sorted(new_ids-prior_ids),'allOriginal235GateKeyValues143ReviewsFiveSourceDeltasPreserved':True,'sixthSourceDeltaOnlyAppended':True,'allOriginal1740Printings14293RuleBlocksEn8GapsAndCn236DispositionsRemain':True,'semanticCoverageCertified':False})
compact={k:v for k,v in result.items() if k not in ['inputManifest','reviewView','remainingObligations','laterSourceDeltas']};compact['remainingObligationCount']=len(new_ids);write(evidence/'governance-validation.json',compact)
status_path=root/'docs/PROJECT_STATUS.md';previous=status_path.read_text();marker='# 当前项目状态\n\n';assert previous.startswith(marker)
lead=(work/'project-status-lead-draft-v1.md').read_text();status_path.write_text(marker+lead+'\n'+previous[len(marker):])
assert all(sha(root/p)==h for p,h in start['sourceInputHashes'].items())
print(json.dumps({'status':'PUBLISHED_BOUNDED_NATIVE_RETRY_AND_EXACT_SOURCE_DELTA_NO_SEMANTIC_PROMOTION','reviews':144,'contexts':59,'gates':237,'remaining':16911,'archiveRecords':len(archive),'changedMainContexts':sum(bool(x['changedPins']) for x in rebindings),'newNativeAndFixedFullStillOpen':True}))
