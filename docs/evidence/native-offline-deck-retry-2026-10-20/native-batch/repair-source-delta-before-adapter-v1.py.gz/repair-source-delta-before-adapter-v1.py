import copy,datetime,gzip,hashlib,importlib.util,json,os,pathlib
work=pathlib.Path(__file__).resolve().parent
root=work.parents[2]
evidence=root/'docs/evidence/native-offline-deck-retry-2026-10-20'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p,value):
 assert not p.exists(),str(p)
 p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def pin(p,role=None):return {'path':str(p.relative_to(root)),'sha256':sha(p),'role':role or p.stem}
mp=root/'docs/audit/current-manifest.json';rp=root/'docs/evidence/rules-reaudit-2026-10-11/review-decisions.json'
manifest=load(mp);reviews=load(rp)
prior=json.loads(gzip.decompress((work/'prior-original-current-manifest.json.gz').read_bytes()))
old_reviews=json.loads(gzip.decompress((work/'prior-original-review-decisions.json.gz').read_bytes()))
assert len(manifest['reviewContexts'])==59 and len(reviews['reviews'])==144 and reviews['reviews'][:-1]==old_reviews['reviews']
assert len(manifest['acceptanceGates'])==237 and manifest['laterSourceDeltas'][:-1]==prior['laterSourceDeltas']
snapshot=work/'publication-first-draft-before-source-delta-adapter-correction.json.gz';assert not snapshot.exists();snapshot.write_bytes(gzip.compress(mp.read_bytes(),mtime=0))
original_ref=prior['laterSourceDeltas'][-1]['after'];original_path=root/original_ref['path'];assert sha(original_path)==original_ref['sha256']
original=load(original_path);assert len(original['data'])==1504
adapter={'metadata':{'region':'CN','language':'zh-CN','totalItems':1504,'role':'BEFORE_SIDE_CARDS_WRAPPER_FOR_EXISTING_SOURCE_DELTA_CHECKER_NOT_NEW_OFFICIAL_VERSION','originalCompleteSourceView':original_ref,'rawRowsAndOrderUnchanged':True,'runtimeAdopted':False},'cards':original['data']}
ap=evidence/'cn19-before-source-delta-adapter.json';write(ap,adapter);assert load(ap)['cards']==original['data']
assert manifest['laterSourceDeltas'][-1]['before']==original_ref
manifest['laterSourceDeltas'][-1].update(before=pin(ap,'cn19-before-side-source-adapter'),beforeOriginalSourceView=original_ref,beforeAdapterDisposition='Existing checker requires cards for before and data for after. Exact original1504 dictionaries and order retained; wrapper only, no new source version or normalization.')
mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
write(work/'publication-source-delta-before-adapter-disposition-v1.json',{'status':'CORRECTED_AUDIT_BEFORE_SIDE_WRAPPER_AFTER_ORIGINAL_PUBLISHER_SHAPE_FAILURE','recordedAtUtc':now(),'originalPublisherSourceSha256':sha(work/'publish-bounded-native-and-cn20-source-audit-v1.py'),'originalFailedPublicationLog':'publication-v1.log','originalFailure':'KeyError: cards in existing source_delta before side, after root draft was written.','originalDraftSnapshotSha256':sha(snapshot),'originalCn19RawSourceView':original_ref,'adapter':pin(ap),'all1504OriginalRowsAndOrderExactlyEqual':True,'allOriginalFiveDeltaDictionariesAndSourceVersionsPreserved':True,'noOriginalSourceOrGameplayOrTestChange':True,'noSecondCheckOrCiRerun':True})
spec=importlib.util.spec_from_file_location('governance',root/'scripts/audit/check-project-governance.py');checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
result=checker.current_audit(root,manifest);assert result['governanceValid'],result['errors']
prior_ids=set(json.loads(gzip.decompress((root/'docs/evidence/graveyard-source-occupation-2026-10-20/remaining-obligation-ids.json.gz').read_bytes())))
new_ids={x['id'] for x in result['remainingObligations']};assert len(prior_ids)==16908 and prior_ids<=new_ids and len(new_ids-prior_ids)==3 and len(new_ids)==16911
for a,b in zip(prior['acceptanceGates'],manifest['acceptanceGates']):assert all(b[k]==v for k,v in a.items())
write(evidence/'remaining-obligation-ids.json',sorted(new_ids))
changes=[{'review':key,'previousEntireContextSha256':checker.digest(prior['reviewContexts'][key]),'changedPins':context['implementationPinUpdates'][-1]['changes']} for key,context in manifest['reviewContexts'].items() if key in prior['reviewContexts'] and context['implementationPinUpdates'][-1]['changes']]
write(evidence/'current-context-rebindings.json',{'priorEntireManifest':pin(evidence/'native-batch/prior-original-current-manifest.json.gz'),'changedMainSourcePins':changes,'allPrior58ContextsAndOriginalScopesEvidencePreserved':True,'newInputRevision':checker.digest(checker.gameplay_inputs(root))})
write(evidence/'unified-obligation-retention.json',{'priorReviews':143,'currentReviews':144,'priorContexts':58,'currentContexts':59,'priorGates':235,'currentGates':237,'priorRemainingObligations':16908,'currentRemainingObligations':16911,'allOriginalIdsRetained':True,'newIds':sorted(new_ids-prior_ids),'allOriginal235GateKeyValues143ReviewsFiveSourceDeltasPreserved':True,'sixthSourceDeltaOnlyAppendedWithExplicitBeforeSideAdapter':True,'allOriginal1740Printings14293RuleBlocksEn8GapsAndCn236DispositionsRemain':True,'semanticCoverageCertified':False})
sp=root/'docs/PROJECT_STATUS.md';previous=sp.read_text();marker='# 当前项目状态\n\n';assert previous.startswith(marker) and not previous[len(marker):].startswith('2026-10-20 当前批次：[原生离线牌组重试')
sp.write_text(marker+(work/'project-status-lead-draft-v1.md').read_text()+'\n'+previous[len(marker):])
result=checker.current_audit(root,manifest);assert result['governanceValid'],result['errors']
compact={k:v for k,v in result.items() if k not in ['inputManifest','reviewView','remainingObligations','laterSourceDeltas']};compact['remainingObligationCount']=len(new_ids);write(evidence/'governance-validation.json',compact)
archive=load(evidence/'archive-map.json')
for name in ['publication-v1.log','publication-first-draft-before-source-delta-adapter-correction.json.gz','publication-source-delta-before-adapter-disposition-v1.json','repair-source-delta-before-adapter-v1.py']:
 p=work/name;target=evidence/'native-batch'/name;compressed=p.suffix in ['.py','.log']
 if compressed:target=target.with_name(target.name+'.gz')
 assert not target.exists()
 if compressed:target.write_bytes(gzip.compress(p.read_bytes(),mtime=0))
 else:os.link(p,target)
 assert (gzip.decompress(target.read_bytes()) if compressed else target.read_bytes())==p.read_bytes()
 archive['records'].append({'originalPath':str(p.relative_to(root)),'originalSha256':sha(p),'originalBytes':p.stat().st_size,'canonical':pin(target),'gzipOriginalBytes':compressed,'samePhysicalFileHardlinked':not compressed})
archive['generatedSourceAdapters']=[{'adapter':pin(ap),'rawOriginalView':original_ref,'entire1504SourceRowsAndOrderIdentical':True,'role':'Audit schema wrapper, not altered original or new temporal source version'}]
(evidence/'archive-map.json').write_text(json.dumps(archive,ensure_ascii=False,indent=2)+'\n')
start=load(work/'only-check-start-inputs-v1.json');assert all(sha(root/p)==h for p,h in start['sourceInputHashes'].items()) and all(sha(root/p)==h for p,h in start['actualConformanceRuntimeFileHashes'].items())
print(json.dumps({'status':'BOUNDED_PUBLICATION_SOURCE_ADAPTER_CORRECTED_GOVERNANCE_PASS','reviews':144,'contexts':59,'gates':237,'remaining':16911,'newIds':sorted(new_ids-prior_ids),'originalSourceRowsUnchanged':1504,'oldGateValuesAndSourceDeltasRetained':True,'all3303Source1399CheckRuntimeUnchanged':True}))
