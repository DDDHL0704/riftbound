import datetime
import hashlib
import json
import os
import pathlib
import plistlib
import subprocess
import sys
work = pathlib.Path(__file__).resolve().parent
root = work.parents[2]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')
def lock_observation():
    raw = plistlib.loads(subprocess.check_output(['/usr/sbin/ioreg', '-n', 'Root', '-d', '1', '-a']))
    return {'atUtc': now(), 'roots': [{'rootLocked': x.get('IOConsoleLocked'),
        'sessions': [u['CGSSessionScreenIsLocked'] for u in x.get('IOConsoleUsers', []) if 'CGSSessionScreenIsLocked' in u]}
        for x in (raw if isinstance(raw, list) else [raw])], 'missingValuesUnknown': True}
focus = json.loads((work / 'focus-native-lobby-adapters-v1/summary.json').read_text())
assert focus['status'] == 'PASSED' and focus['total'] == 18
baseline = json.loads((work / 'baseline-and-native-regression-scope-v1.json').read_text())
assert all(sha(root / p) == h for p, h in baseline['allOriginalTestsAndScripts'].items())
parent = json.loads((work.parent / 'graveyard-source-fixed-candidate-20261020/fixed-commit-inputs-v1.json').read_text())
changed = [p for p, h in parent['sourceInputHashes'].items() if sha(root / p) != h]
assert changed == ['clients/godot/scripts/Main.cs'], changed
assert not (work / 'only-check').exists()
paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '--',
    'src', 'clients/godot', 'tests', 'scripts', '.github', 'data', 'Directory.Build.props', 'Directory.Build.targets',
    'Directory.Packages.props', 'global.json', 'NuGet.Config'], cwd=root, text=True).splitlines()
inputs = {p: sha(root / p) for p in sorted(set(paths)) if (root / p).is_file() and not {'bin', 'obj', '.godot'} & set(pathlib.Path(p).parts)}
runtime = root / 'tests/Riftbound.ConformanceTests/bin/Debug/net10.0'
modules = {str(p.relative_to(root)): sha(p) for p in sorted(runtime.rglob('*')) if p.is_file()
    and (p.suffix in {'.dll', '.pdb'} or p.name.endswith(('.deps.json', '.runtimeconfig.json'))
        or p.is_relative_to(runtime / 'data') or p.is_relative_to(runtime / 'Fixtures'))}
start = {'recordedAtUtc': now(), 'parentCommit': parent['fixedCommit'], 'sourceInputHashes': inputs,
    'actualConformanceRuntimeFileHashes': modules, 'sourceInputCount': len(inputs), 'actualConformanceRuntimeFileCount': len(modules),
    'onlyOneCheckForThisBatch': True, 'noGodotSdkOrProjectBuild': True, 'nativeChangedLineNotExercisedByConformance': True,
    'actualNativeOfflineRetryRegressionStillRequired': True, 'optionalSqlNotClaimedAsRealDatabase': True, 'lockedAtStart': lock_observation()}
write(work / 'only-check-start-inputs-v1.json', start)
power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
code = None
try:
    env = dict(os.environ)
    env.pop('ConnectionStrings__Riftbound', None)
    with (work / 'only-check-runner.log').open('x') as log:
        code = subprocess.run(['python3', str(root / 'scripts/test-rules.py'), 'check', '--output', str(work / 'only-check')], cwd=root,
            env=env, stdout=log, stderr=subprocess.STDOUT).returncode
finally:
    if power.poll() is None:
        power.terminate(); power.wait(timeout=10)
    sources_changed = [p for p, h in inputs.items() if not (root / p).is_file() or sha(root / p) != h]
    modules_changed = [p for p, h in modules.items() if not (root / p).is_file() or sha(root / p) != h]
    write(work / 'only-check-terminal-integrity-v1.json', {'finishedAtUtc': now(), 'checkExitCode': code,
        'inputManifestSha256': sha(work / 'only-check-start-inputs-v1.json'), 'changedSourceInputs': sources_changed,
        'changedConformanceRuntimeFiles': modules_changed, 'allDeclaredInputsAndRuntimeFilesStable': not sources_changed and not modules_changed,
        'lockedAtEnd': lock_observation(), 'boundIdleSleepAssertionEnded': power.poll() is not None, 'noSecondCheck': True})
assert not sources_changed and not modules_changed
print('SOLE_CHECK_FINISHED_WITH_STABLE_INPUTS_AND_RUNTIME_EXIT_' + str(code), flush=True)
sys.exit(code if code is not None else 1)
