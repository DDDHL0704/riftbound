import ast
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import plistlib
import subprocess

os.umask(0o077)
work = Path(__file__).resolve().parent
root = work.parents[2]
runtime = work / 'sql-runtime-v1'
pg = Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin')
cluster = root / 'var/qa/permanent-play-here-base-20261017/postgres'
sock = Path('/tmp/rft-here-family-20261018-55486')
tables = ['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts']
read_env = dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
publication = json.loads((work / 'frozen-full-failure-sql-publication-v1.json').read_text())
prior = json.loads((work.parent / 'reversal-target-choice-audit-20261020/after-four-writers-before-readonly-baseline-v1.json').read_text())
source = work.parent / 'graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes = [n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}]
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),globals())
output = work / 'focused-clairvoyance-real-sql-verification-v1.json'
assert not output.exists()
def write(path,value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value,indent=2)+chr(10)); temporary.replace(path)
def frozen():
    assert all(sha(root / p) == h for p,h in publication['sourceInputHashes'].items())
    assert all(oct((root / p).stat().st_mode&0o777) == m for p,m in publication['sourceInputModes'].items())
    assert all(sha(runtime / p) == h for p,h in publication['runtimeFiles'].items())
    assert all(sha(work / p) == h for p,h in publication['readerSources'].items())
    assert json.loads(subprocess.check_output(publication['independentFrameReaderCommand']+['identity-print'],cwd=runtime,text=True)) == publication['actualRuleInputs']
frozen()
guard = (root / 'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a'); fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof = {'status':'RUNNING_NOT_ACCEPTANCE','startedAtUtc':now(),'baseCommit':publication['baseCommit'],
    'includesUncommittedThreeUiAndSqlSourcesPlusTwoNativeProofInputs':True,'actualRuleInputs':publication['actualRuleInputs'],
    'lockAtStart':observe_lock(),'sourceInputCount':3314,'runtimeFileCount':publication['runtimeFileCount'],
    'scope':'Current original five Clairvoyance controlled SQL fixtures, exact dispatcher ordinal17/47; not a full partition/all47/fixed CI or ordinary opening certification.'}
write(output,proof)
started = False; power = process = None; audit = native = None
try:
    assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode == 3
    power = subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof.update(ownRunnerPid=os.getpid(),boundIdleAssertionPid=power.pid)
    sock.mkdir(exist_ok=True)
    subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(work/'focused-clairvoyance-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],check=True,capture_output=True);started=True
    audit=rooms('riftbound_acceptance');native=rooms('riftbound_here_native')
    assert audit==prior['auditRooms'] and native==prior['nativeRooms'] and len(audit)==213 and len(native)==45
    before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',native)
    assert before_audit==prior['auditSevenTables'] and before_native==prior['nativeSevenTables']
    write(work/'focused-clairvoyance-original213-audit45-native-baseline-v1.json',{'atUtc':now(),'auditRooms':audit,'nativeRooms':native,'auditSevenTables':before_audit,'nativeSevenTables':before_native})
    evidence=work/'actual-clairvoyance-focused-partition-v1'
    env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit',RIFTBOUND_POSTGRES_EVIDENCE=str(evidence));env.pop('GITHUB_SHA',None);env.pop('DOTNET_STARTUP_HOOKS',None)
    args=['/Users/dinghaolin/.dotnet/dotnet',str(runtime/'Riftbound.PostgresAcceptance.dll'),'--ci-partition','17','47']
    with (work/'focused-clairvoyance-actual-writer-v1.log').open('xb') as log:
        process=subprocess.Popen(args,cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT);proof['ownedWriterPid']=process.pid;write(output,proof);code=process.wait(timeout=300)
    proof['writerExitCode']=code;assert code==0
    partition=json.loads((evidence/'partition-receipt.json').read_text());assert partition['status']=='REAL_POSTGRES_PARTITION_COMPLETE' and partition['fixedCommit'] is None
    assert partition['expectedCases']==partition['completedCases']==['clairvoyance'] and partition['partitionIndex']==17 and partition['partitionCount']==47
    assert partition['actualRuleInputs']==publication['actualRuleInputs'] and len(partition['orderedDefaultCases'])==47
    for item in partition['outputFiles']:
        q=evidence/item['path'];assert q.stat().st_size==item['bytes'] and sha(q)==item['sha256']
    for item in partition['runtimeAssemblies']: assert publication['runtimeFiles'][item['file']]==item['sha256']
    with (work/'focused-clairvoyance-independent-original-frame-reader-v1.log').open('xb') as log:
        code=subprocess.run(publication['independentFrameReaderCommand']+[str(evidence/'clairvoyance')],cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300).returncode
    proof['independentReaderExitCode']=code;assert code==0
    independent=json.loads((work/'focused-clairvoyance-independent-original-frame-reader-v1.log').read_text());assert independent['status']=='PASS_INDEPENDENT_FIVE_ORIGINAL_CLAIRVOYANCE_FRAMES_LITERAL_ORDER_CONTROL_AND_FULL_REPLAY'
    assert len(independent['results'])==5 and sum(r['commands'] for r in independent['results'])==28
    receipts=[json.loads((evidence/'clairvoyance'/branch/'receipt.json').read_text()) for branch in ['keep','some','all','burnout','control']]
    assert sum(r['submitted'] for r in receipts)==28 and sum(r['structuralTamperRejections'] for r in receipts)==15
    assert all(r['coldRecoveries']==r['submitted'] for r in receipts)
    assert rooms('riftbound_acceptance')==audit and rooms('riftbound_here_native')==native
    assert digests('riftbound_acceptance',audit)==before_audit and digests('riftbound_here_native',native)==before_native
    proof.update(status='PASS_CURRENT_FIVE_CLAIRVOYANCE_SQL_BRANCHES_AND_INDEPENDENT_ORIGINAL_FULL_REPLAY',branches=5,commands=28,
        events=sum(r['events'] for r in receipts),coldRecoveries=28,originalStructuralTamperRejections=15,
        allOriginalBranchesCommandsAssertionsColdDedupAndLiteralDrawOrderRetained=True,
        allOriginal213Audit45NativeSevenTablesExact=True,ownControlledFixtureCleanupUnchanged=True,
        allFiveFullOriginalFramesExportedBeforeOwnFixtureCleanup=True,
        originalFrameHashes={str(p.relative_to(evidence)):sha(p) for p in (evidence/'clairvoyance').rglob('*.json.gz')},
        originalFailedFixed0366CiStillFailure=True,newFixedFullStillRequired=True)
except BaseException as error:
    proof.update(status='FAILED_OR_INTERRUPTED_CURRENT_CLAIRVOYANCE_SQL_OR_READER_ORIGINAL_RETAINED',errorType=type(error).__name__,errorMessage=str(error));raise
finally:
    if process is not None and process.poll() is None:process.terminate();process.wait(timeout=30)
    if started:
        if audit is not None and 'before_audit' in globals():
            proof['allOriginal213AuditSevenTablesExactAtStop']=digests('riftbound_acceptance',audit)==before_audit
            proof['allOriginal45NativeSevenTablesExactAtStop']=digests('riftbound_here_native',native)==before_native
        proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
    if power is not None:
        if power.poll() is None:power.terminate();power.wait(timeout=10)
        proof['boundIdleAssertionEnded']=power.poll() is not None
    frozen();proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),allDeclaredSourceModesAndRuntimeFilesFrozen=True,originalDatabaseRetained=True);write(output,proof);fcntl.flock(guard,fcntl.LOCK_UN)
print(proof['status'],flush=True)
