import copy
import datetime
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import zipfile

work=Path(__file__).resolve().parent;root=work.parents[2]
evidence=root/'docs/evidence/native-spell-choice-presentation-2026-10-20'
previous=root/'docs/evidence/reversal-target-choice-2026-10-20'
base='0366bc247c1ac06502ed24bc065b8442ba769391'
identity='native-spell-choice-presentation-and-original-sql-driver-2026-10-20'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x') as out:out.write(json.dumps(value,ensure_ascii=False,indent=2)+chr(10))
def pin(path,role):return {'path':str(path.relative_to(root)),'sha256':sha(path),'role':role}

assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==base and not evidence.exists()
check=load(work/'only-check-retention-and-disposition-v1.json');assert check['cases']==13166 and check['methods']==7490 and check['entireOriginal13166CaseMultisetAnd7490MethodsExactlyEqual']
assert check['allDeclaredSourceModesConformanceAndNativeRuntimeStable'] and check['allOriginalConformanceSourcesMethodsTheoriesVictoryAndReplayAssertionsByteExact']
start=load(work/'only-check-start-inputs-v1.json');assert all(sha(root/p)==h for p,h in start['sourceInputHashes'].items())
assert all(sha(root/p)==h for p,h in start['actualNativeRuntimeFileHashes'].items())
sql=load(work/'combined-focused-clairvoyance-full-failure-correction-and-original-readback-v1.json');assert sql['commands']==28 and sql['events']==65 and sql['all213Audit45NativeSevenTablesExactAndOriginalDbNormallyStopped']
locked=load(work/'actual-locked-native-controls-original-run-v1.json');assert locked['status']=='PASS_ACTUAL_LOCKED_NATIVE_HEADLESS_CONTROLS' and locked['exitCode']==0
native=load(work/'native-original-after-fix-v1/receipt.json');assert native['commands']==6 and native['actualViews']==native['syntheticStartViews']==12 and not native['errors']
legacy=load(work/'legacy-six-native-regressions-result-v1.json');assert legacy['originalCommands']==33 and len(legacy['results'])==6
bundle=load(work/'legacy-native-compact-original-bundle-verification-v1.json');assert bundle['entries']==286 and bundle['compressedBytes']==686830
assert sha(work/'legacy253-inputs-and33-generated-commands-original-bytes-v1.jsonl.gz')==bundle['bundleSha256']
assert load(work/'python-tools-current-v1.json')['exitCode']==0
assert load(work/'current-three-consumer-official-source-readback-v1.json')['status'].startswith('PASS_THREE_CURRENT_EXACT')
manifest_path=root/'docs/audit/current-manifest.json';reviews_path=root/'docs/evidence/rules-reaudit-2026-10-11/review-decisions.json'
prior=load(manifest_path);old_reviews=load(reviews_path)
assert len(prior['reviewContexts'])==62 and len(prior['acceptanceGates'])==241 and len(old_reviews['reviews'])==147
old_ids=set(load(previous/'remaining-obligation-ids.json'));assert len(old_ids)==16925
for path,name in [(manifest_path,'prior-entire-current-manifest.json.gz'),(reviews_path,'prior-entire-review-decisions.json.gz')]:
    target=work/name;assert not target.exists();target.write_bytes(gzip.compress(path.read_bytes(),mtime=0))
face=load(work/'current-clairvoyance-exact-face-visual-and-identity-scope-v1.json');face_path=root/load(work/'current-three-consumer-official-source-readback-v1.json')['records'][2]['currentActualFaceReadback']['existingOriginal']
assert sha(face_path)==face['faceSha256']
face_alias=work/'current-exact-clairvoyance-37747-face.png';assert not face_alias.exists();os.link(face_path,face_alias)

# Scan exact existing private profile values without publishing them.
fixed43=root/'var/qa/native-signalr-runtime-patch-fixed-43d5b84e-20261020'
profiles=[fixed43/'session-a.json',fixed43/'session-b.json',fixed43/'actual-native-control-prefix-v1/session-native-a.json',fixed43/'actual-native-control-prefix-v1/session-native-b.json']
secrets=[load(p)[key].encode() for p in profiles for key in ['playerKey','reconnectToken']]
assert len(secrets)==8
text_exts={'.py','.cs','.csproj','.gd','.log','.trx','.md','.txt','.ndjson'}
raw_exts={'.json','.gz','.zip','.png','.jpg','.jpeg','.webp'}
exact_prose_drafts={'native-spell-choice-audit-draft-v1.md','project-status-lead-draft-v1.md'}
excluded={'bin','obj','__pycache__','legacy-native-inputs-v1','sql-runtime-v1','sql-readonly-frame-runtime-v2'}
records=[]
inputs=[p for p in sorted(work.rglob('*')) if p.is_file()]
def archive(path,verify_only):
    relative=path.relative_to(work)
    if path.name in exact_prose_drafts or path.name.startswith('session-') or path.name.endswith(('.deps.json','.runtimeconfig.json')):
        return
    if any(part in excluded or part.startswith('clairvoyance-independent-reader-build-') or part.endswith('.app') for part in relative.parts):return
    if path.suffix not in text_exts|raw_exts:return
    raw=path.read_bytes()
    if path.suffix=='.gz':blocks=[gzip.decompress(raw)]
    elif path.suffix=='.zip':
        with zipfile.ZipFile(path) as z:
            assert z.testzip() is None;blocks=[z.read(n) for n in z.namelist() if not n.endswith('/')]
    else:blocks=[raw]
    assert not any(secret in block for secret in secrets for block in blocks),str(relative)
    if verify_only:return
    compressed=path.suffix in text_exts;target=evidence/'n25'/relative
    if compressed:target=target.with_name(target.name+'.gz')
    target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists()
    if compressed:target.write_bytes(gzip.compress(raw,mtime=0))
    else:os.link(path,target)
    assert target.stat().st_size<10*2**20 and (gzip.decompress(target.read_bytes()) if compressed else target.read_bytes())==raw
    records.append({'originalPath':str(path.relative_to(root)),'originalSha256':sha(path),'originalBytes':len(raw),'canonical':pin(target,'original-evidence'),'gzipOriginalBytes':compressed,'samePhysicalFileHardlinked':not compressed})
for verify_only in [True,False]:
    for path in inputs:archive(path,verify_only)
write(evidence/'archive-map.json',{'records':records,'allOriginalBytesAndHashesVerified':True,'privateAuthValuesScannedWithoutDisclosure':True,'draftExclusionIsExactProseListOnly':sorted(exact_prose_drafts),'all286RetiredMaterializedBytesInVerifiedCompactBundle':True,'runtimeSdkAppsAndDatabaseExcluded':True})
def archived(name,role):return pin(evidence/'n25'/name,role)
check_ref=archived('only-check-retention-and-disposition-v1.json','check')
native_ref=archived('actual-locked-native-controls-original-run-v1.json','native')
legacy_ref=archived('legacy-six-native-regressions-result-v1.json','native-adjacency')
sql_ref=archived('combined-focused-clairvoyance-full-failure-correction-and-original-readback-v1.json','real-sql-original-controlled-initial')
source_ref=archived('current-three-consumer-official-source-readback-v1.json','primary-sources')
visual_ref=archived('current-clairvoyance-exact-face-visual-and-identity-scope-v1.json','exact-card-face-identity')
matrix_ref=archived('bounded-native6-and-original-sql5-two-branch-matrix-v1.json','actual-branch-matrix')
open_ref=archived('finite-choice-source-followup-and-explicit-open-scope-v1.json','remaining-precise-source-branches')
ci_fail_ref=archived('fixed0366-full-ci-original-first-sql-failure-v1.json','actual-failed-fixed-ci-child')
impl=['clients/godot/scripts/ui/MatchPhasePresentation.cs','clients/godot/scripts/interaction/PromptInteractionController.cs']
verify=['clients/godot/scripts/debug/SpellChoiceRemakeInteractionProof.cs','clients/godot/scenes/debug/SpellChoiceRemakeInteractionProof.tscn','tests/Riftbound.PostgresAcceptance/ClairvoyanceSqlAcceptance.cs','tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json']
matrix=load(work/'bounded-native6-and-original-sql5-two-branch-matrix-v1.json')
source_manifest={'recordedAtUtc':now(),'region':'CN','language':'zh-CN','applicableAsOf':'2026-10-20','adoptedCoreEffectiveDate':'2026-10-16',
    'scope':'Exact existing native public spell-choice owner/phase and atomic original intents, plus old controlled SQL driver completion. No rule-engine change or whole-printing certification.',
    'baseCommit':base,'includesUncommittedDeclaredUiAndSqlDriverInputs':True,'implementation':[pin(root/p,'implementation') for p in impl],'verificationSources':[pin(root/p,'verification-source') for p in verify],
    'currentPrimarySources':source_ref,'actualClairvoyanceExactFace':visual_ref,'existingSourceDatesAndAllSixDeltasRetained':True,'exactApiIds':[31296,37855,37747],
    'allSeparateParentPrintingIds':matrix['exactParentPrintingIdsKeptSeparate'],'singlePrintingIndependentPublishedEffectiveAndEventDates':None,
    'actualNativeLockedHeadless':native_ref,'actualLegacyNative':legacy_ref,'actualSqlExplicitControlledInitial':sql_ref,'actualBranchMatrix':matrix_ref,'soleCheck':check_ref,
    'currentReleaseRuleInputs':sql['actualRuleInputs'],'actualHeadlessClientAssemblySha256':native['actualClientAssemblySha256'],'actualHeadlessClientMvid':native['actualClientMvid'],
    'actualFailedFixed0366Ci':ci_fail_ref,'originalFailedCiNotRelabelled':True,'newFixedCompleteFullVisibleProductAndPhysicalWindows':'OPEN',
    'existingAcceptanceGateDependencies':matrix['existingAcceptanceGateDependencies'],'originalN24Archive357RecordMapUnchanged':pin(previous/'archive-map.json','prior-archive-map'),
    'originalDraftStageSupplement':pin(previous/'original-sql-draft-frame-archive-supplement.json','original-two-frame-supplement'),
    'preciseRemainingSourceBranches':open_ref,'newSourceDelta':False,'semanticOrWholePrintingCertification':False,
    'currentExpectedFullNotResult':{'cases':13315,'methods':7631,'sqlExecutionIdentities':47,'fullGameMethods':143,'pairs':110,'decks':11,'seed':424242}}
write(evidence/'source-manifest.json',source_manifest);manifest_ref=pin(evidence/'source-manifest.json','source-manifest')
check_text='实际13166例/7490方法全部通过，零失败零跳过，与原完整用例多重集合及方法精确相同；3314源码、1401Conformance与23原生载荷全程不变，无第二次check'
gov_text='148审查/63上下文/原241门禁原值不变/16927义务，全部原16925义务保留；新增两个限定分支依赖既有平台/语义门禁'
doc=(work/'native-spell-choice-audit-draft-v1.md').read_text().replace(' @CLAIR_FACE@ ',face['officialFaceUrl']).replace('@CHECK@',check_text).replace('@GOV@',gov_text)
assert '@CHECK@' not in doc and '@GOV@' not in doc and '@CLAIR_FACE@' not in doc
path=root/'docs/NATIVE_SPELL_CHOICE_PRESENTATION_AUDIT_2026-10-20.md';assert not path.exists();path.write_text(doc)
rule_refs=['CN-d6fd7140f106f9b5-P111-B016','CN-d6fd7140f106f9b5-P111-B018','CN-d6fd7140f106f9b5-P111-B020','CN-d6fd7140f106f9b5-P111-B021','CN-d6fd7140f106f9b5-P111-B022','CN-d6fd7140f106f9b5-P111-B024']
subjects=matrix['exactParentPrintingIdsKeptSeparate']
reviews=copy.deepcopy(old_reviews);reviews['reviews'].append({'id':identity,'scope':source_manifest['scope'],'subjects':subjects,'ruleRecords':rule_refs,'pendingRuleRecords':[],
    'status':'BOUNDED_NATIVE6_PLUS_OLD33_LOCKED_HEADLESS_SQL5_EXPLICIT_INITIAL_CHECK13166_NEW_FIXED_FULL_PRODUCT_WINDOWS_OPEN','sourceManifest':manifest_ref,'auditDocument':str(path.relative_to(root)),
    'validation':{'nativeOriginalCommands':6,'actualOriginalProjectionViews':12,'syntheticTurnStartControls':12,'oldNativeOriginalCommands':33,'oldLookRevealOrdinaryRows':20,'controlledSqlBranches':5,'controlledSqlCommands':28,'controlledSqlEvents':65,'coldRecoveries':28,'structuralRejects':15,'checkCases':13166,'checkMethods':7490,'allOriginalCasesMethodsTheoriesAndFullGameAssertionsPreserved':True},'exclusions':matrix['explicitRemaining']})
reviews_path.write_text(json.dumps(reviews,ensure_ascii=False,indent=2)+chr(10))
spec=importlib.util.spec_from_file_location('governance',root/'scripts/audit/check-project-governance.py');checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
revision=checker.digest(checker.gameplay_inputs(root));manifest=copy.deepcopy(prior);prior_ref=archived('prior-entire-current-manifest.json.gz','prior-entire-manifest');updates=[]
for key,context in manifest['reviewContexts'].items():
    changes=[]
    for field in ['implementation','verificationSources']:
        for ref in context.get(field,[]):
            current=sha(root/ref['path'])
            if current!=ref['sha256']:changes.append({'field':field,'path':ref['path'],'previousSha256':ref['sha256'],'currentSha256':current});ref['sha256']=current
    prior_current={f:context.get(f) for f in ['currentInputRevision','currentImplementationCommit','currentImplementationIncludesUncommittedChanges','ciState']}
    context.setdefault('implementationPinUpdates',[]).append({'batch':identity,'changes':changes,'previousCurrentMetadata':prior_current,'previousEntireContextPreservedIn':prior_ref,'scope':'Only two existing native presentation/selection summaries and one old SQL driver are changed; all rule-engine/Conformance inputs exact. No old semantic or product scope upgraded.'})
    context.update(currentInputRevision=revision,currentImplementationCommit=base,currentImplementationIncludesUncommittedChanges=True,ciState='PENDING',revalidationReason='New declared native and SQL verification inputs; original0366CI has an actual SQL child failure, current fixed full and current product evidence remain required.')
    if changes:updates.append({'review':key,'changedPins':changes,'priorContextSha256':checker.digest(prior['reviewContexts'][key])})
branches=[{**b,'sourceRefs':subjects+rule_refs,'sourceManifest':manifest_ref,'state':'RECORDED','decision':{'state':'OPEN','reason':'Bounded source/native/SQL/check evidence; new fixed full, current visible product/Windows and remaining source semantics stay open.'},'testExecution':'ACTUAL_NATIVE6_OLD33_SQL5_EXPLICIT_INITIAL_CHECK13166','existingAcceptanceGateDependencies':matrix['existingAcceptanceGateDependencies'],'remaining':matrix['explicitRemaining']} for b in matrix['branches']]
manifest['inputs']['reviews']=pin(reviews_path,prior['inputs']['reviews'].get('role','reviews'))
manifest['reviewContexts'][identity]={'evidenceCommit':base,'currentImplementationCommit':base,'currentImplementationIncludesUncommittedChanges':True,'currentInputRevision':revision,'ciState':'PENDING','ciReceipts':[],
    'evidenceCommitScope':'Fixed0366 plus explicitly declared current native and SQL driver inputs; failed0366full not promoted. CurrentRelease/native identities separately pinned.',
    'region':'CN','language':'zh-CN','applicableAsOf':'2026-10-20','adoptedCoreEffectiveDate':'2026-10-16','sourceManifest':manifest_ref,
    'implementation':source_manifest['implementation'],'verificationSources':source_manifest['verificationSources'],'evidence':[check_ref,native_ref,legacy_ref,sql_ref,source_ref,visual_ref,matrix_ref,open_ref,ci_fail_ref],
    'existingAcceptanceGateDependencies':matrix['existingAcceptanceGateDependencies'],'branches':branches}
manifest['currentNativeSpellChoicePresentationAndFullSqlDriverInputChange']=manifest_ref
assert manifest['acceptanceGates']==prior['acceptanceGates'] and len(manifest['acceptanceGates'])==241
assert manifest['laterSourceDeltas']==prior['laterSourceDeltas'] and len(prior['laterSourceDeltas'])==6
assert reviews['reviews'][:-1]==old_reviews['reviews'] and len(reviews['reviews'])==148
result=checker.current_audit(root,manifest);assert result['governanceValid'],result['errors']
ids={r['id'] for r in result['remainingObligations']};assert old_ids<=ids and len(ids)==16927
assert len(manifest['reviewContexts'])==63
manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+chr(10))
write(evidence/'remaining-obligation-ids.json',sorted(ids))
write(evidence/'current-context-rebindings.json',{'priorEntireManifest':prior_ref,'allOriginal62ScopesSourceVersionsAndEvidenceRetained':True,'currentInputRevision':revision,'changedContexts':updates})
write(evidence/'unified-obligation-retention.json',{'priorReviews':147,'currentReviews':148,'priorContexts':62,'currentContexts':63,'priorGates':241,'currentGates':241,'allOriginal241GateRecordsExact':True,
    'priorObligations':16925,'currentObligations':16927,'allOriginalIdsRetained':True,'onlyTwoNewBoundedBranches':True,'existingGateDependenciesReused':matrix['existingAcceptanceGateDependencies'],'allSixSourceDeltasAnd1740Printings14293BlocksEn8GapCn236DispositionsRetained':True,'semanticCoverageCertified':False})
compact={k:v for k,v in result.items() if k not in ['inputManifest','reviewView','remainingObligations','laterSourceDeltas']};compact['remainingObligationCount']=len(ids);write(evidence/'governance-validation.json',compact)
status=root/'docs/PROJECT_STATUS.md';text=status.read_text();marker='# 当前项目状态\n\n';assert text.startswith(marker)
lead=(work/'project-status-lead-draft-v1.md').read_text().replace('@CHECK@',check_text).replace('@GOV@',gov_text);assert '@CHECK@' not in lead and '@GOV@' not in lead
status.write_text(marker+lead+chr(10)+text[len(marker):])
print(json.dumps({'status':'PUBLISHED_BOUNDED_NATIVE_CHOICE_AND_ORIGINAL_SQL_DRIVER_FAILURE_CONVERGENCE','archivedOriginals':len(records),'reviews':148,'contexts':63,'unchangedGates':241,'obligations':16927,'globalCertification':False}),flush=True)
