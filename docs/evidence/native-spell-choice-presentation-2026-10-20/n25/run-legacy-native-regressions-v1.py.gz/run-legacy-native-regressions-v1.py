import ast
import datetime
import hashlib
import json
from pathlib import Path
import plistlib
import subprocess

work=Path(__file__).resolve().parent;root=work.parents[2]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
source=work.parent/'graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
node=next(n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='observe_lock')
exec(compile(ast.Module(body=[node],type_ignores=[]),str(source),'exec'),globals())
inputs=json.loads((work/'legacy-native-input-map-v1.json').read_text())
publication=json.loads((work/'frozen-full-failure-sql-publication-v1.json').read_text())
client=root/'clients/godot/.godot/mono/temp/bin/Debug/Riftbound.GodotClient.dll';client_hash=sha(client)
results=[]
for row in inputs['records']:
    assert all(sha(root/p)==h for p,h in publication['sourceInputHashes'].items())
    assert sha(client)==client_hash and sha(root/row['sourcePath'])==row['sourceSha256']
    assert all(sha(root/r['originalPath'])==sha(root/r['materializedPath'])==r['sha256'] for r in row['originalInputs'])
    log=work/('legacy-native-'+row['name']+'-v1.log');assert not log.exists()
    args=['/Users/dinghaolin/.local/share/riftbound-tools/godot-4.7.2/Godot_mono.app/Contents/MacOS/Godot','--headless','--path',str(root/'clients/godot'),'res://scenes/debug/'+row['scene']+'.tscn','--','--evidence='+row['inputRoot']]+row['flags']
    before=observe_lock()
    with log.open('xb') as out:process=subprocess.run(args,cwd=root,stdout=out,stderr=subprocess.STDOUT,timeout=90)
    text=log.read_text(errors='replace');record={'name':row['name'],'exitCode':process.returncode,'sourceSha256':row['sourceSha256'],'actualClientAssemblySha256':client_hash,'actualArguments':args,'logSha256':sha(log),'lockAtStart':before,'lockAtEnd':observe_lock()}
    for relative,expected in row['originalExpectedCommands'].items():
        current=Path(row['inputRoot'])/relative
        assert current.is_file() and json.loads(current.read_text())==expected['expected'],(row['name'],relative)
        assert sha(root/expected['originalPath'])==expected['sha256']
    record.update(originalGeneratedCommandCount=row['expectedCommandCount'],allOriginalCommandFieldsAndPromptTicksExact=True)
    assert all(sha(root/r['originalPath'])==sha(root/r['materializedPath'])==r['sha256'] for r in row['originalInputs'])
    with (work/('legacy-native-'+row['name']+'-run-v1.json')).open('x') as out:out.write(json.dumps(record,indent=2)+chr(10))
    assert process.returncode==0 and row['marker'] in text and 'ERROR:' not in text,(row['name'],text[-3500:])
    results.append(record);print(row['name'],'PASS',row['expectedCommandCount'],'original commands; unchanged original proof and input files',flush=True)
assert all(sha(root/p)==h for p,h in publication['sourceInputHashes'].items()) and sha(client)==client_hash
with (work/'legacy-six-native-regressions-result-v1.json').open('x') as out:out.write(json.dumps({'status':'PASS_SIX_UNCHANGED_ORIGINAL_NATIVE_CONTROL_SCENES_ALL_INPUTS_AND_COMMANDS_EXACT','atUtc':now(),'results':results,'originalCommands':33,'ordinaryLookRevealPresentationRows':20,'originalNativeProofSourcesAndAssertionsUnchanged':True,'all253OriginalInputsAndGeneratedCommandsExact':True,'all3314CurrentSourcesAndNativeClientBinaryStable':True,'legacyRuleChoiceActualTokenHeadings':20,'legacyRuleChoiceSyntheticTurnStartChecks':20,'legacyRuleChoiceOtherPublicKindSyntheticChecks':80,'newCurrentVisibleProductAndWindowsNotInferred':True},indent=2)+chr(10))
