import collections
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET

work=Path(__file__).resolve().parent;root=work.parents[2]
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
terminal=load(work/'only-check-terminal-integrity-v1.json');start=load(work/'only-check-start-inputs-v1.json')
assert terminal['checkExitCode']==0 and terminal['allDeclaredSourceModesConformanceAndNativeRuntimeStable']
assert terminal['boundIdleAssertionEnded'] and terminal['noSecondCheck'] and terminal['sourceManifestSha256']==sha(work/'only-check-start-inputs-v1.json')
assert all(sha(root/p)==h for p,h in start['sourceInputHashes'].items())
assert all(oct((root/p).stat().st_mode&0o777)==m for p,m in start['sourceInputModes'].items())
assert all(sha(root/p)==h for p,h in start['actualConformanceRuntimeFileHashes'].items())
assert all(sha(root/p)==h for p,h in start['actualNativeRuntimeFileHashes'].items())
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def read_cases(path):
    tree=ET.parse(path)
    definitions={d.attrib['id']:d.find('t:TestMethod',ns).attrib for d in tree.findall('.//t:UnitTest',ns)}
    rows=tree.findall('.//t:UnitTestResult',ns);assert rows and all(r.attrib['outcome']=='Passed' for r in rows)
    return collections.Counter(r.attrib['testName'] for r in rows),{definitions[r.attrib['testId']]['className']+'.'+definitions[r.attrib['testId']]['name'] for r in rows}
current_trx=work/'only-check/check/results.trx';baseline=root/start['originalBaselineTrx'];assert sha(baseline)==start['originalBaselineTrxSha256']
cases,methods=read_cases(current_trx);original,old_methods=read_cases(baseline)
assert cases==original and methods==old_methods and sum(cases.values())==13166 and len(methods)==7490
plan=load(work/'only-check/plan.json');assert len(plan['shards'])==1 and set(plan['shards'][0]['methods'])==methods
summary=load(work/'only-check/summary.json');assert summary['status']=='PASSED' and summary['profile']=='check' and summary['total']==13166
before=load(work/'original-fixed0366-source-inputs-and-test-baseline-v1.json')
changed=[p for p,h in before['sourceInputHashes'].items() if sha(root/p)!=h]
expected=['clients/godot/scripts/interaction/PromptInteractionController.cs','clients/godot/scripts/ui/MatchPhasePresentation.cs','tests/Riftbound.PostgresAcceptance/ClairvoyanceSqlAcceptance.cs']
assert sorted(changed)==sorted(expected)
assert all(sha(root/p)==h for p,h in before['sourceInputHashes'].items() if p.startswith('tests/Riftbound.ConformanceTests/'))
path=expected[-1];old=subprocess.check_output(['git','show',before['baseCommit']+':'+path],cwd=root,text=True).splitlines();cursor=iter((root/path).read_text().splitlines());assert all(any(line==prior for line in cursor) for prior in old)
full=[p for p in before['sourceInputHashes'] if re.fullmatch(r'tests/Riftbound.ConformanceTests/FullGameEndToEndTests[^/]*\.cs',p)]
assert len(full)==9 and all(sha(root/p)==before['sourceInputHashes'][p] for p in full)
full_methods={n for p in full for n in re.findall(r'\bpublic\s+(?:async\s+)?(?:Task|void)\s+(\w+)\s*\(', (root/p).read_text())};assert len(full_methods)==143
legacy=load(work/'legacy-six-native-regressions-result-v1.json');assert legacy['originalCommands']==33 and legacy['all253OriginalInputsAndGeneratedCommandsExact']
for row in load(work/'legacy-native-input-map-v1.json')['records']:
    assert sha(root/row['sourcePath'])==row['sourceSha256']
sql=load(work/'combined-focused-clairvoyance-full-failure-correction-and-original-readback-v1.json');assert sql['commands']==28 and sql['events']==65 and sql['all213Audit45NativeSevenTablesExactAndOriginalDbNormallyStopped']
assert load(work/'python-tools-current-v1.json')['exitCode']==0
assert sha(root/'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json')==before['sourceInputHashes']['tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json']
locked_path=work/'actual-locked-native-controls-original-run-v1.json';locked=load(locked_path) if locked_path.exists() else None
if locked:
    assert locked['status']=='PASS_ACTUAL_LOCKED_NATIVE_HEADLESS_CONTROLS' and locked['exitCode']==0
    assert locked['actualReceipt']['commands']==6 and locked['actualReceipt']['errors']==[]
result={'status':'PASS_SOLE_NATIVE_PROMPT_AND_SQL_FULL_FAILURE_BATCH_CHECK_EXACT_ORIGINAL_CASE_METHOD_AND_SOURCE_RETENTION',
    'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseCommit':before['baseCommit'],'cases':13166,'methods':7490,'failed':0,'skipped':0,
    'entireOriginal13166CaseMultisetAnd7490MethodsExactlyEqual':True,'addedConformanceCases':0,'addedConformanceMethods':0,
    'allOriginalConformanceSourcesMethodsTheoriesVictoryAndReplayAssertionsByteExact':True,
    'originalNineFullGameFiles143Methods110Pairs11DecksSeed424242Retained':True,'sourceInputCount':3314,
    'conformanceRuntimeFileCount':start['actualConformanceRuntimeFileCount'],'nativeRuntimeFileCount':start['actualNativeRuntimeFileCount'],
    'allDeclaredSourceModesConformanceAndNativeRuntimeStable':True,'exactOriginalSourceChanges':changed,'allOther3309OriginalSourcesAndAllModesExact':True,
    'allOriginalClairvoyanceSqlSourceLinesAndAssertionsExactSubsequence':True,'allOriginal47SqlIdsAndOrderByteExact':True,
    'oldSixNativeProofSourcesAndAllAssertionsAnd253InputsAnd33OriginalCommandsPreserved':True,
    'actualLockedHeadlessNativeProofPresent':locked is not None,'actualLockedProof':str(locked_path.relative_to(root)) if locked else None,
    'tools73Pass':True,'baselineTrxSha256':sha(baseline),'actualTrxSha256':sha(current_trx),'noSecondCheck':True,
    'originalFailed0366FullCiNotRelabelledAndNewFixedFullRequired':True,'newVisibleNativeProductAndPhysicalWindowsSeparatelyOpen':True,'wholePrintingOrGlobalCertification':False}
with (work/'only-check-retention-and-disposition-v1.json').open('x') as out:out.write(json.dumps(result,indent=2)+chr(10))
print(result['status'],result['cases'],result['methods'],flush=True)
