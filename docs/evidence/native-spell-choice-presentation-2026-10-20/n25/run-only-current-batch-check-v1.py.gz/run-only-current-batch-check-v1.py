import ast
import datetime
import hashlib
import json
import os
from pathlib import Path
import plistlib
import subprocess
import sys

work=Path(__file__).resolve().parent;root=work.parents[2]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
load=lambda p:json.loads(p.read_text())
source=work.parent/'graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
node=next(n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='observe_lock')
exec(compile(ast.Module(body=[node],type_ignores=[]),str(source),'exec'),globals())
publication=load(work/'frozen-full-failure-sql-publication-v1.json')
focus=load(work/'focus-clairvoyance-and-retarget-v1/summary.json');assert focus['status']=='PASSED' and focus['total']==46
sql=load(work/'combined-focused-clairvoyance-full-failure-correction-and-original-readback-v1.json');assert sql['commands']==28 and sql['events']==65 and sql['all213Audit45NativeSevenTablesExactAndOriginalDbNormallyStopped']
legacy=load(work/'legacy-six-native-regressions-result-v1.json');assert legacy['originalCommands']==33 and len(legacy['results'])==6
native=load(work/'native-original-after-fix-v1/receipt.json');assert native['commands']==6 and native['errors']==[] and native['actualViews']==native['syntheticStartViews']==12
assert load(work/'python-tools-current-v1.json')['exitCode']==0
assert not (work/'only-check').exists()
inputs=publication['sourceInputHashes'];modes=publication['sourceInputModes']
assert len(inputs)==3314 and all(sha(root/p)==h for p,h in inputs.items())
folder=root/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0'
runtime={str(p.relative_to(root)):sha(p) for p in sorted(folder.rglob('*')) if p.is_file() and
    (p.suffix in {'.dll','.pdb'} or p.name.endswith(('.deps.json','.runtimeconfig.json')) or p.is_relative_to(folder/'data') or p.is_relative_to(folder/'Fixtures'))}
client=root/'clients/godot/.godot/mono/temp/bin/Debug'
native_runtime={str(p.relative_to(root)):sha(p) for p in sorted(client.rglob('*')) if p.is_file() and
    (p.suffix in {'.dll','.pdb'} or p.name.endswith(('.deps.json','.runtimeconfig.json')))}
original=load(work/'original-fixed0366-source-inputs-and-test-baseline-v1.json');baseline=root/original['originalCheckTrx'];assert sha(baseline)==original['originalCheckTrxSha256']
start={'atUtc':now(),'baseCommit':original['baseCommit'],'sourceInputCount':len(inputs),'sourceInputHashes':inputs,'sourceInputModes':modes,
    'actualConformanceRuntimeFileCount':len(runtime),'actualConformanceRuntimeFileHashes':runtime,'actualNativeRuntimeFileCount':len(native_runtime),'actualNativeRuntimeFileHashes':native_runtime,
    'originalBaselineTrx':str(baseline.relative_to(root)),'originalBaselineTrxSha256':sha(baseline),'expectedCases':13166,'expectedMethods':7490,
    'originalNormalFullGame143Methods110Pairs11DecksAndSeed424242Preserved':True,'exactOneCheckForCoherentUiAndFullFailureDriverBatch':True,
    'originalFailed0366CiMustRemainFailureAndNewFixedFullRequired':True,'currentSqlUsesOriginalExplicitControlledInitialNotNormalOpening':True,'lockAtStart':observe_lock()}
with (work/'only-check-start-inputs-v1.json').open('x') as out:out.write(json.dumps(start,indent=2)+chr(10))
power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);code=None
try:
    env=dict(os.environ);env.pop('ConnectionStrings__Riftbound',None);env.pop('DOTNET_STARTUP_HOOKS',None)
    with (work/'only-check-runner-v1.log').open('xb') as log:
        code=subprocess.run(['python3',str(root/'scripts/test-rules.py'),'check','--jobs','3','--output',str(work/'only-check')],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
finally:
    if power.poll() is None:power.terminate();power.wait(timeout=10)
    changed_source=[p for p,h in inputs.items() if not(root/p).is_file() or sha(root/p)!=h]
    changed_modes=[p for p,m in modes.items() if oct((root/p).stat().st_mode&0o777)!=m]
    changed_runtime=[p for p,h in runtime.items() if not(root/p).is_file() or sha(root/p)!=h]
    changed_native=[p for p,h in native_runtime.items() if not(root/p).is_file() or sha(root/p)!=h]
    terminal={'finishedAtUtc':now(),'checkExitCode':code,'changedSourceInputs':changed_source,'changedSourceModes':changed_modes,
        'changedConformanceRuntimeFiles':changed_runtime,'changedNativeRuntimeFiles':changed_native,
        'allDeclaredSourceModesConformanceAndNativeRuntimeStable':not(changed_source or changed_modes or changed_runtime or changed_native),
        'boundIdleAssertionEnded':power.poll() is not None,'lockAtEnd':observe_lock(),'noSecondCheck':True,'sourceManifestSha256':sha(work/'only-check-start-inputs-v1.json')}
    with (work/'only-check-terminal-integrity-v1.json').open('x') as out:out.write(json.dumps(terminal,indent=2)+chr(10))
assert terminal['allDeclaredSourceModesConformanceAndNativeRuntimeStable']
print('SOLE_NATIVE_PRESENTATION_AND_SQL_DRIVER_BATCH_CHECK_EXIT_'+str(code),flush=True)
sys.exit(code if code is not None else 1)
