import ast
import datetime
import hashlib
import json
from pathlib import Path
import plistlib
import subprocess

work = Path(__file__).resolve().parent
root = work.parents[2]
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
source = root / 'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
node = next(n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name == 'observe_lock')
exec(compile(ast.Module(body=[node],type_ignores=[]),str(source),'exec'),globals())
baseline = json.loads((work / 'original-fixed0366-source-inputs-and-test-baseline-v1.json').read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
paths = ['clients/godot/scripts/ui/MatchPhasePresentation.cs','clients/godot/scripts/interaction/PromptInteractionController.cs']
assert all(sha(root / p) == baseline['sourceInputHashes'][p] for p in paths)
output = work / 'native-original-before-fix-v1'
log = work / 'native-original-before-fix-v1.log'
assert not output.exists() and not log.exists()
assembly = root / 'clients/godot/.godot/mono/temp/bin/Debug/Riftbound.GodotClient.dll'
actual_hash = sha(assembly)
args = ['/Users/dinghaolin/.local/share/riftbound-tools/godot-4.7.2/Godot_mono.app/Contents/MacOS/Godot',
    '--headless','--path',str(root / 'clients/godot'),'res://scenes/debug/SpellChoiceRemakeInteractionProof.tscn','--',
    '--evidence=' + str(work / 'inputs-v1'),'--output=' + str(output)]
start = observe_lock()
with log.open('xb') as stream:
    process = subprocess.run(args,cwd=root,stdout=stream,stderr=subprocess.STDOUT,timeout=90)
assert sha(assembly) == actual_hash and all(sha(root / p) == baseline['sourceInputHashes'][p] for p in paths)
proof = {'atUtc':now(),'exitCode':process.returncode,'lockAtStart':start,'lockAtEnd':observe_lock(),
    'actualArguments':args,'actualClientAssemblySha256':actual_hash,'actualLogSha256':sha(log),
    'bothOriginalProductionPresentationAndSelectionSourcesByteExactBeforeAfter':True,
    'genuineGodotControlProofNotVisibleAcceptance':True,'receiptExists':(output / 'receipt.json').exists()}
with (work / 'native-original-before-fix-run-v1.json').open('x') as out:
    out.write(json.dumps(proof,indent=2) + chr(10))
print(log.read_text(errors='replace')[-6500:])
print('ACTUAL_ORIGINAL_GODOT_EXIT',process.returncode,flush=True)
