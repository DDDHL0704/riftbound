import ast
import datetime
import hashlib
import json
from pathlib import Path
import plistlib
import subprocess

work=Path(__file__).resolve().parent;root=work.parents[2]
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=work.parent/'graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
node=next(n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='observe_lock')
exec(compile(ast.Module(body=[node],type_ignores=[]),str(source),'exec'),globals())
start=observe_lock()
def locked(observation):
    return any(r.get('rootLocked') is True or any(v is True for v in r.get('sessions',[])) for r in observation['roots'])
if not locked(start):
    print(json.dumps({'status':'NOT_RUN_CURRENT_LOCK_NOT_OBSERVED','observation':start,'noUnlockOrPersistentPowerChangeRequestedOrPerformed':True}),flush=True)
    raise SystemExit(0)
inputs=json.loads((work/'only-check-start-inputs-v1.json').read_text())
assert not (work/'native-controls-actually-locked-v1').exists()
assert all(sha(root/p)==h for p,h in inputs['sourceInputHashes'].items())
assert all(sha(root/p)==h for p,h in inputs['actualNativeRuntimeFileHashes'].items())
output=work/'native-controls-actually-locked-v1';log=work/'native-controls-actually-locked-v1.log'
assembly=root/'clients/godot/.godot/mono/temp/bin/Debug/Riftbound.GodotClient.dll'
args=['/Users/dinghaolin/.local/share/riftbound-tools/godot-4.7.2/Godot_mono.app/Contents/MacOS/Godot','--headless','--path',str(root/'clients/godot'),'res://scenes/debug/SpellChoiceRemakeInteractionProof.tscn','--','--evidence='+str(work/'inputs-v1'),'--output='+str(output),'--client-assembly='+str(assembly)]
with log.open('xb') as out:process=subprocess.run(args,cwd=root,stdout=out,stderr=subprocess.STDOUT,timeout=90)
end=observe_lock()
assert all(sha(root/p)==h for p,h in inputs['sourceInputHashes'].items()) and all(sha(root/p)==h for p,h in inputs['actualNativeRuntimeFileHashes'].items())
receipt=json.loads((output/'receipt.json').read_text())
result={'status':'PASS_ACTUAL_LOCKED_NATIVE_HEADLESS_CONTROLS' if process.returncode==0 and locked(end) and receipt['errors']==[] else 'ACTUAL_NATIVE_ATTEMPT_RETAINED_LOCK_OR_CONTROL_STATUS_NEEDS_REVIEW',
    'recordedAtUtc':now(),'exitCode':process.returncode,'lockAtStart':start,'lockAtEnd':end,'actualReceipt':receipt,
    'all3314CheckSourceInputsAnd23NativeRuntimeFilesStable':True,'actualClientAssemblySha256':sha(assembly),'actualLogSha256':sha(log),
    'noScreenUnlockLockPersistentPowerSettingOrOriginalDatabaseChange':True,'visibleDesktopOrWindowsPhysicalAcceptance':False}
with (work/'actual-locked-native-controls-original-run-v1.json').open('x') as out:out.write(json.dumps(result,indent=2)+chr(10))
print(json.dumps({'status':result['status'],'actualExitCode':process.returncode,'originalCommands':receipt['commands'],'actualProjectionViews':receipt['actualViews'],'syntheticTurnStart':receipt['syntheticStartViews'],'lockConfirmedAtBothEnds':locked(start) and locked(end)},indent=2),flush=True)
assert process.returncode==0 and receipt['errors']==[]
