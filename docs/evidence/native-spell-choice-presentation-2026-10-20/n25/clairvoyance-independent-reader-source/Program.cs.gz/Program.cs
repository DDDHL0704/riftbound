using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Nodes;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
if (args.SequenceEqual(new[] { "identity-print" })) { Console.WriteLine(JsonSerializer.Serialize(RuleInputIdentity.Current, json)); return; }
if (args.Length != 1) throw new Exception("Exact actual SQL output directory required.");
var results = new List<object>();
foreach (var branch in new[] { "keep", "some", "all", "burnout", "control" })
{
    var path = Path.Combine(args[0], branch, "complete-original-frame.json.gz");
    using var zip = new GZipStream(File.OpenRead(path), CompressionMode.Decompress);
    using var document = JsonDocument.Parse(zip);
    var raw = document.RootElement;
    var frame = raw.Deserialize<MatchRecoveryFrame>(json)!;
    Check(JsonNode.DeepEquals(JsonNode.Parse(raw.GetRawText()), JsonSerializer.SerializeToNode(frame, json)), "Entire typed original frame, every field/null and original intent must round trip exactly.");
    Check(frame.IsConsistent && frame.ValidationErrors.Count == 0 && frame.AuthoritativeState is not null, "Actual original frame consistency.");
    Check(frame.AuthoritativeState!.RuleInputs == RuleInputIdentity.Current && frame.Commands.All(c => c.Accepted), "Exact current runtime identity and every accepted original command.");
    Check((await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame, new CoreRuleEngine(), default)).Count == 0, "Complete original action/event/state/private-view/prompt recovery validation.");
    var state = raw.GetProperty("authoritativeState");
    var actor = branch == "control" ? "P2" : "P1";
    var hand = state.GetProperty("playerZones").GetProperty(actor).GetProperty("hand").EnumerateArray().Select(x => x.GetString()).ToArray();
    var expected = branch switch { "keep" => new[] { "D5", "D4" }, "some" => ["D5", "D3"], "all" => ["D6", "D7"], "control" => ["E2", "E1"], _ => ["D1"] };
    Check(hand.SequenceEqual(expected), "Independent literal retained top order and completed draws.");
    Check(state.GetProperty("stackItems").GetArrayLength() == 0 && (!state.TryGetProperty("pendingCardChoice", out var pending) || pending.ValueKind == JsonValueKind.Null), "Original spell and required Insight choices complete.");
    Check(state.GetProperty("status").GetString() == (branch == "burnout" ? MatchStatuses.Finished : MatchStatuses.InProgress), "Original burnout versus normal completion.");
    var expectedCommands = branch is "keep" or "some" ? 5 : branch == "control" ? 10 : 4;
    Check(frame.Commands.Count == expectedCommands, "Every original command remains, plus exactly one explicit control choice.");
    if (branch == "control")
    {
        var commands = raw.GetProperty("commands").EnumerateArray().ToArray();
        var types = commands.Select(c => c.GetProperty("commandType").GetString()).ToArray();
        Check(types.SequenceEqual(new[] { "PLAY_CARD", "PASS_PRIORITY", "PLAY_CARD", "PASS_PRIORITY", "PASS_PRIORITY", "PAY_COST", "PASS_PRIORITY", "PASS_PRIORITY", "CHOOSE_CARDS", "CHOOSE_CARDS" }), "Original nine command kinds/order with the exact explicit decision inserted.");
        var choice = commands[5]; var command = choice.GetProperty("rawCommand");
        Check(choice.GetProperty("playerId").GetString() == "P2" && command.GetProperty("paymentWindow").GetString() == "RULE_REPLACEMENT"
            && command.GetProperty("paymentChoiceIds").EnumerateArray().Select(x => x.GetString()).SequenceEqual(new[] { "KEEP_ALL" }), "Only the actual new controller explicitly retains choices.");
        Check(state.GetProperty("playerZones").GetProperty("P1").GetProperty("graveyard").EnumerateArray().Any(x => x.GetString() == "SPELL"), "Physical source returns to original owner.");
        var events = raw.GetProperty("events").EnumerateArray().Select(x => x.GetProperty("event").GetProperty("kind").GetString()).ToArray();
        Check(events.Count(x => x == "STACK_ITEM_CONTROL_GAINED") == 1 && !events.Contains("STACK_ITEM_COUNTERED") && !events.Contains("SPELL_CHOICES_REMADE"), "Keep transfers control without countering or remaking.");
    }
    results.Add(new { branch, commands = frame.Commands.Count, events = frame.Events.Count,
        allOriginalFieldsNullAndFullReplayExact = true, actualRuleInputs = frame.AuthoritativeState!.RuleInputs });
}
Console.WriteLine(JsonSerializer.Serialize(new { status = "PASS_INDEPENDENT_FIVE_ORIGINAL_CLAIRVOYANCE_FRAMES_LITERAL_ORDER_CONTROL_AND_FULL_REPLAY", results,
    explicitControlledFixturesNotOrdinaryOrWholeCardCertification = true }, json));
static void Check(bool condition, string message) { if (!condition) throw new Exception(message); }
