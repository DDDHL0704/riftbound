import copy
import datetime
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path

work=Path(__file__).resolve().parent
root=work.parents[2]
evidence=root/'docs/evidence/native-spell-choice-presentation-2026-10-20'
load=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
archive=load(evidence/'archive-map.json')
assert archive['allOriginalBytesAndHashesVerified'] and archive['draftExclusionIsExactProseListOnly']==['native-spell-choice-audit-draft-v1.md','project-status-lead-draft-v1.md']
for row in archive['records']:
    original=root/row['originalPath'];canonical=root/row['canonical']['path']
    assert original.is_file() and canonical.is_file()
    raw=gzip.decompress(canonical.read_bytes()) if row['gzipOriginalBytes'] else canonical.read_bytes()
    assert raw==original.read_bytes() and hashlib.sha256(raw).hexdigest()==row['originalSha256']
    assert len(raw)==row['originalBytes'] and sha(canonical)==row['canonical']['sha256']
    if row['samePhysicalFileHardlinked']:
        assert (original.stat().st_dev,original.stat().st_ino)==(canonical.stat().st_dev,canonical.stat().st_ino)
    assert canonical.stat().st_size<10*2**20
prior=json.loads(gzip.decompress((evidence/'n25/prior-entire-current-manifest.json.gz').read_bytes()))
old_reviews=json.loads(gzip.decompress((evidence/'n25/prior-entire-review-decisions.json.gz').read_bytes()))
manifest=load(root/'docs/audit/current-manifest.json')
reviews=load(root/'docs/evidence/rules-reaudit-2026-10-11/review-decisions.json')
assert reviews['reviews'][:-1]==old_reviews['reviews'] and len(reviews['reviews'])==148 and len(old_reviews['reviews'])==147
assert manifest['acceptanceGates']==prior['acceptanceGates'] and len(manifest['acceptanceGates'])==241
assert manifest['laterSourceDeltas']==prior['laterSourceDeltas'] and len(manifest['laterSourceDeltas'])==6
assert set(prior['reviewContexts'])<set(manifest['reviewContexts']) and len(manifest['reviewContexts'])==63
new_id='native-spell-choice-presentation-and-original-sql-driver-2026-10-20'
allowed={'currentInputRevision','currentImplementationCommit','currentImplementationIncludesUncommittedChanges','ciState','revalidationReason','implementationPinUpdates','implementation','verificationSources'}
for key,old in prior['reviewContexts'].items():
    current=manifest['reviewContexts'][key]
    assert {k:v for k,v in current.items() if k not in allowed}=={k:v for k,v in old.items() if k not in allowed}
    updates=current['implementationPinUpdates'];assert updates[:-1]==old.get('implementationPinUpdates',[]) and updates[-1]['batch']==new_id
    assert updates[-1]['previousCurrentMetadata']=={f:old.get(f) for f in ['currentInputRevision','currentImplementationCommit','currentImplementationIncludesUncommittedChanges','ciState']}
    for field in ['implementation','verificationSources']:
        assert len(current.get(field,[]))==len(old.get(field,[]))
        for before,after in zip(old.get(field,[]),current.get(field,[])):
            assert {k:v for k,v in before.items() if k!='sha256'}=={k:v for k,v in after.items() if k!='sha256'}
            assert sha(root/after['path'])==after['sha256']
new=manifest['reviewContexts'][new_id]
assert new['ciState']=='PENDING' and not new['ciReceipts'] and len(new['branches'])==2
assert all(b['decision']['state']=='OPEN' for b in new['branches'])
old_ids=set(load(root/'docs/evidence/reversal-target-choice-2026-10-20/remaining-obligation-ids.json'))
new_ids=set(load(evidence/'remaining-obligation-ids.json'))
assert len(old_ids)==16925 and len(new_ids)==16927 and old_ids<new_ids and len(new_ids-old_ids)==2
start=load(work/'only-check-start-inputs-v1.json')
assert all(sha(root/p)==h for p,h in start['sourceInputHashes'].items())
assert all(sha(root/p)==h for p,h in start['actualConformanceRuntimeFileHashes'].items())
assert all(sha(root/p)==h for p,h in start['actualNativeRuntimeFileHashes'].items())
manifest_source=load(evidence/'source-manifest.json')
for row in manifest_source['implementation']+manifest_source['verificationSources']:
    assert sha(root/row['path'])==row['sha256']
assert manifest_source['newFixedCompleteFullVisibleProductAndPhysicalWindows']=='OPEN'
assert manifest_source['currentExpectedFullNotResult']=={'cases':13315,'methods':7631,'sqlExecutionIdentities':47,'fullGameMethods':143,'pairs':110,'decks':11,'seed':424242}
previous=root/'docs/evidence/reversal-target-choice-2026-10-20'
assert sha(previous/'archive-map.json')==manifest_source['originalN24Archive357RecordMapUnchanged']['sha256']
supplement=load(previous/'original-sql-draft-frame-archive-supplement.json')
assert manifest_source['originalFailedCiNotRelabelled'] and not manifest_source['semanticOrWholePrintingCertification']
text=(root/'docs/NATIVE_SPELL_CHOICE_PRESENTATION_AUDIT_2026-10-20.md').read_text()
assert not any(p in text for p in ['@CHECK@','@GOV@','@CLAIR_FACE@'])
spec=importlib.util.spec_from_file_location('gov',root/'scripts/audit/check-project-governance.py');checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
result=checker.current_audit(root,manifest)
assert result['governanceValid'] and {r['id'] for r in result['remainingObligations']}==new_ids
out={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_CANONICAL_ORIGINAL_BYTE_HASH_INODE_AND_FULL_PRIOR_SCOPE_RETENTION',
    'archivedOriginals':len(archive['records']),'everyOriginalRawByteSha256AndHardlinkInodeVerified':True,
    'all147OriginalReviewsAnd62ContextScopesSourceVersionsAndEvidencePreserved':True,'all241OriginalGatesAndSixSourceDeltasExact':True,
    'all16925OriginalObligationIdsRetained':True,'currentObligations':16927,'onlyTwoNewBoundedOpenBranches':True,
    'all3314Sources1401ConformanceAnd23NativeRuntimeStillStable':True,'governanceValid':True,'governanceErrors':result['errors'],
    'currentFixedFullAndVisiblePhysicalAcceptanceStillOpen':True,'wholePrintingAndGlobalCertification':False}
with (evidence/'final-original-retention-and-publication-verification.json').open('x') as stream:json.dump(out,stream,ensure_ascii=False,indent=2)
print(json.dumps(out,ensure_ascii=False),flush=True)
