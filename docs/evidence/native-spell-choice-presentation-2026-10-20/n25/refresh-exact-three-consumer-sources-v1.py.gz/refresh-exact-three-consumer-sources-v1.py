import datetime
import gzip
import hashlib
import json
from pathlib import Path
import urllib.request

work=Path(__file__).resolve().parent;root=work.parents[2];folder=work/'current-three-consumer-sources-v1';folder.mkdir(exist_ok=False)
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
prior_path=root/'var/qa/typed-stack-consumer-source-readback-20261020/current-complete-cn-source-version-view-v1.json'
prior=json.loads(prior_path.read_text())['data'];rows=[]
result={'startedAtUtc':now(),'region':'CN','language':'zh-CN','applicableAsOf':'2026-10-20','adoptedCoreEffectiveDate':'2026-10-16',
    'priorWholeSourceView':str(prior_path.relative_to(root)),'priorWholeSourceViewSha256':sha(prior_path.read_bytes()),'records':rows,
    'singlePrintingPublishedAndIndependentEffectiveDates':None,'noRuntimeLedgerPriorEvidenceDateOrGameHistoryMutation':True,'allSixGameSourceDeltasRemainRetained':True,'wholePrintingCertified':False}
try:
    for name,identity,number in [('倒转神通',31296,'OGN·080/298'),('灵魂折镜',37855,'VEN·152'),('千里眼',37747,'VEN·056')]:
        payload={'pageNum':1,'pageSize':100,'searchContent':name,'cardCategoryList':[],'cardColorList':[],'rarityList':[],'productCodeList':[]}
        url='https://lol-api.playloltcg.com/xcx/card/searchCardCraftWeb';start=now()
        request=urllib.request.Request(url,data=json.dumps(payload,ensure_ascii=False).encode(),headers={'Content-Type':'application/json','User-Agent':'RiftboundRulesAudit/1.0'})
        with urllib.request.urlopen(request,timeout=45) as response:
            raw=response.read();entry={'name':name,'exactApiId':identity,'exactCardNo':number,'url':url,'request':payload,'requestedAtUtc':start,'receivedAtUtc':now(),'httpStatus':response.status,'httpDate':response.headers.get('Date'),'bytes':len(raw),'sha256':sha(raw)}
        target=folder/(str(identity)+'-entire-original-response.json.gz');target.write_bytes(gzip.compress(raw,mtime=0));entry['originalResponse']=str(target.relative_to(root));rows.append(entry)
        data=json.loads(raw);assert data['code']==0 and data['result']['total']==len(data['result']['list'])==1
        card=data['result']['list'][0];assert card['id']==identity and card['cardNo']==number
        old=next(r for r in prior if r['id']==identity and r['cardNo']==number);entry['entireRawCardRowExactToPriorCompleteCn20Source']=card==old
        entry['canonicalEntireRowSha256']=sha(json.dumps(card,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode());assert card==old
        if identity==37747:
            old_face=root/'var/qa/clairvoyance-20261015/card-image.png';start=now()
            with urllib.request.urlopen(urllib.request.Request(card['frontImage'],headers={'User-Agent':'RiftboundRulesAudit/1.0'}),timeout=45) as response:face=response.read();face_meta={'url':card['frontImage'],'requestedAtUtc':start,'receivedAtUtc':now(),'httpStatus':response.status,'httpDate':response.headers.get('Date'),'bytes':len(face),'sha256':sha(face)}
            face_meta.update(existingOriginal=str(old_face.relative_to(root)),entireFaceByteExact=face==old_face.read_bytes(),duplicateImageNotSaved=True);entry['currentActualFaceReadback']=face_meta
            if face!=old_face.read_bytes():
                (folder/'37747-changed-unadopted-face.png').write_bytes(face)
                raise RuntimeError('Current exact consumer face changed; register separate source delta before adoption.')
    result['status']='PASS_THREE_CURRENT_EXACT_CONSUMER_ENTIRE_ROWS_AND_CURRENT_CLAIRVOYANCE_FACE_UNCHANGED'
except BaseException as error:
    result.update(status='FAILED_OR_CHANGED_SOURCE_REQUIRES_SEPARATE_INTAKE',errorType=type(error).__name__,errorMessage=str(error));raise
finally:
    result['finishedAtUtc']=now();(work/'current-three-consumer-official-source-readback-v1.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+chr(10))
print(result['status'],flush=True)
