from pathlib import Path
import json,gzip,hashlib
R=Path.cwd();Q=Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();proof=[]
frozen=json.load((Q/'frozen-inputs-v2.json').open())
for p,h in frozen['ruleInputs'].items():assert sha((R/p).read_bytes())==h
for p in sorted((Q/'original-v2').glob('*.json.gz')):
 x=json.load(gzip.open(p,'rt'));assert x['failure']is None;cs=x['commands'];es=[e['event']for e in x['events']];assert len(cs)==x['originalPrefixReplayCount']==len(x['states'])==len(x['entries']);assert sum(not c['accepted']for c in cs)==2
 assert [c['commandType']for c in cs[:6]]==['MOVE_UNIT','PASS_FOCUS','PASS_FOCUS','DECLARE_BATTLE','ASSIGN_COMBAT_DAMAGE','ASSIGN_COMBAT_DAMAGE']
 assert sum(p['kind']=='idempotent-order'for p in x['probes'])==1
 draws=sum(e['kind']=='CARD_DRAWN'for e in es);expected=x['scorePosition']if x['initialScore']==7 else 2;assert draws==expected
 s=x['states'][-1];assert s['playerScores']['P1']==(8 if x['initialScore']==7 else 2)
 if x['initialScore']==7:assert s['winnerPlayerId']=='P1'and s['cardObjects']['FIELD']['controllerId']=='P2'and not any(e['kind']in('BATTLE_CLOSED','BATTLEFIELD_CONQUERED')for e in es)
 else:assert s['winnerPlayerId']is None and sum(e['kind']=='BATTLE_CLOSED'for e in es)==1
 proof.append({'caseId':x['caseId'],'printing':x['cardNo'],'initialScore':x['initialScore'],'scorePosition':x['scorePosition'],'commands':len(cs),'accepted':sum(c['accepted']for c in cs),'rejected':sum(not c['accepted']for c in cs),'events':len(es),'originalPrefixReplays':x['originalPrefixReplayCount'],'probes':len(x['probes']),'draws':draws,'sha256':sha(p.read_bytes())})
assert len(proof)==12
for k,n in [('commands',168),('accepted',144),('rejected',24),('events',468),('originalPrefixReplays',168),('probes',48)]:assert sum(p[k]for p in proof)==n
with(Q/'verified-multisource-v2.json').open('x')as f:json.dump(proof,f,ensure_ascii=False,indent=2)
print('Verified 12 scenarios, 168 original prefixes, 468 events, 24 rejected unchanged commands, 12 idempotency probes, 12 hidden opponent projections')
