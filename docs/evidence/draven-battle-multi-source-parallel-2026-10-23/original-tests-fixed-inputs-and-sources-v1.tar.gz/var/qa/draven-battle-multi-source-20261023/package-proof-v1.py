from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,tarfile,io,subprocess,xml.etree.ElementTree as E
R=Path.cwd();Q=R/'var/qa/draven-battle-multi-source-20261023';D=R/'docs/evidence/draven-battle-multi-source-parallel-2026-10-23';D.mkdir(parents=True,exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest();ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
frozen=json.load((Q/'frozen-inputs-v2.json').open())
for p,h in frozen['ruleInputs'].items():assert sha((R/p).read_bytes())==h
receiptPath=Q/'applied-n53-overlay-v1.json';receipt=json.load(receiptPath.open());peer=Path(receipt['overlaySource']);assert sha(peer.read_bytes())==receipt['overlaySha256']
oldReceipt=Path(receipt['parentReceipt']);assert sha(oldReceipt.read_bytes())==receipt['parentReceiptSha256'];old=json.load(oldReceipt.open());oldPeer=Path(old['overlaySource']);assert sha(oldPeer.read_bytes())==old['overlaySha256']
assembly=R/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0/Riftbound.ConformanceTests.dll';runs={}
for name,expected in [('focus-v2',12),('adjacent-and-original-games-v2',41)]:
 r=E.parse(Q/name/'focus/results.trx');c=r.find('.//t:Counters',ns).attrib;assert c['total']==str(expected)and c['passed']==str(expected)and c['failed']=='0'and c['notExecuted']=='0'
 plan=json.load((Q/name/'plan.json').open());assert plan['testAssemblySha256']==sha(assembly.read_bytes())
 runs[name]={'counters':c,'methods':plan['shards'][0]['methods'],'trxSha256':sha((Q/name/'focus/results.trx').read_bytes()),'testCases':[x.get('testName')for x in r.findall('.//t:UnitTestResult',ns)]}
histories={};actual=[]
for folder,n,commands,events in [('original-v2',12,168,468),('adjacent-interaction-v2',12,126,450),('adjacent-combined-v2',22,252,708),('adjacent-late-v2',4,34,136)]:
 proofs=[]
 for p in sorted((Q/folder).glob('*.gz')):
  x=json.load(gzip.open(p,'rt'));assert x.get('failure')is None;assert len(x['commands'])==len(x['states'])==len(x['entries'])==x['originalPrefixReplayCount'];assert [e for item in x['entries']for e in item['events']]==[e['event']for e in x['events']]
  proofs.append({'caseId':x.get('caseId',p.stem),'commands':len(x['commands']),'accepted':sum(c['accepted']for c in x['commands']),'events':len(x['events']),'originalPrefixReplays':x['originalPrefixReplayCount'],'sha256':sha(p.read_bytes())})
  for c in x['commands']:
   if c['ruleInputs']not in actual:actual.append(c['ruleInputs'])
 assert len(proofs)==n and sum(x['commands']for x in proofs)==commands and sum(x['events']for x in proofs)==events
 histories[folder]=proofs
assert len(actual)==1
source='tests/Riftbound.ConformanceTests/DravenBattleWinMultiSourceTests.cs';assert(Q/'focus-v2/test-source.cs').read_bytes()==(R/source).read_bytes()
extra=[source,'docs/DRAVEN_BATTLE_MULTI_SOURCE_PARALLEL_2026-10-23.md','tests/Riftbound.ConformanceTests/BattleWinCombinedTriggerTests.cs','tests/Riftbound.ConformanceTests/BattleWinLateParticipantTests.cs','tests/Riftbound.ConformanceTests/FullGameEndToEndTests.cs','var/qa/draven-battle-win-score-20261023/current-core304-http-original-v1.json']
paths=[(str(p.relative_to(R)),p)for p in Q.rglob('*')if p.is_file()]+[(x,R/x)for x in extra]+[('inputs/n53-exact-main-overlay-after71-green-v1.tar.gz',peer),('inputs/peer-fixed-n52-first45-v1.tar.gz',oldPeer),('inputs/applied-peer-fixed-n52-first45-v1.json',oldReceipt)]
for name,p in paths:
 if p.name.startswith('current-')and p.name.endswith('-original-v1.json.gz'):
  x=json.load(gzip.open(p,'rt'));assert sha(x['originalUtf8'].encode())==x['rawSha256']
archive=D/'original-tests-fixed-inputs-and-sources-v1.tar.gz';members=[]
with archive.open('xb')as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as t:
   for name,p in sorted(paths):
    b=p.read_bytes();i=tarfile.TarInfo(name);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b));members.append({'path':name,'bytes':len(b),'sha256':sha(b)})
with tarfile.open(archive,'r:gz')as t:
 for m in members:
  b=t.extractfile(m['path']).read();assert len(b)==m['bytes']and sha(b)==m['sha256']
manifest={'status':'PASS_SCOPED_THREE_RESULT_SKILLS_ON_FIXED_N53_OVERLAY','atUtc':datetime.now(timezone.utc).isoformat(),'baseCommit':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'region':'CN','language':'zh-CN','peerOverlay':receipt,'frozenSpecifiedInputs':frozen,'all25SpecifiedInputsUnchanged':True,'actualRuleInputs':actual[0],'testAssemblySha256':sha(assembly.read_bytes()),'source':{'path':source,'sha256':sha((R/source).read_bytes())},'originalRuns':runs,'originalHistories':histories,'newScenarios':json.load((Q/'verified-multisource-v2.json').open()),'cases':53,'passed':53,'failed':0,'skipped':0,'methods':11,'newCases':12,'newCommands':168,'newAccepted':144,'newRejected':24,'newEvents':468,'newOriginalPrefixReplays':168,'newIdempotencyProbes':12,'newOpponentProjectionProbes':12,'adjacentCases':38,'originalFullGameMethods':3,'allArchivedHistories':50,'allArchivedCommands':580,'allArchivedEvents':1762,'allArchivedOriginalPrefixReplays':580,'freshCompleteSourceRows':json.load((Q/'sources-v1/extra-rows.json').open()),'initialBuildFailurePreserved':'CS8604 nullable idempotent-call arguments; no rule execution','initialFixtureDoesNotCertifyLegalDeckOrCrossDomainAcquisition':True,'noExtraCheckOrFull':True,'noDatabaseExecution':True,'wholePrintingCertified':False,'deathScoreAndVoidGateAoeRemainOpen':True,'backendGoalComplete':False,'archive':{'path':str(archive.relative_to(R)),'sha256':sha(archive.read_bytes()),'members':members}}
with(D/'source-and-test-manifest.json').open('x')as f:json.dump(manifest,f,ensure_ascii=False,indent=2)
print('Verified',len(members),'archive members;',archive.stat().st_size,'bytes; 53/53, 580 original prefixes')
