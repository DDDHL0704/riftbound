from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import gzip, hashlib, json, urllib.request

Q = Path(__file__).parent/'sources-v1'; Q.mkdir(exist_ok=True)
M = Path('/Users/dinghaolin/MyProjects/riftbound')
sha = lambda data: hashlib.sha256(data).hexdigest()
now = lambda: datetime.now(timezone.utc).isoformat()
api = 'https://lol-api.playloltcg.com/xcx/card/searchCardCraftWeb'
pdf = 'https://cdn.playloltcg.com/lol/2026/10/2026-10-10/a21ead876c6b44d6abe386b6ae54ea28.pdf'
wanted = {33240,33241,33283,34653,31405,31522,31457}
baseline = {}
for line in gzip.open(M/'var/qa/current-cn-source-readback-20261023/current-complete-cn-original-pages-v1.jsonl.gz', 'rt'):
    for row in json.loads(json.loads(line)['originalUtf8'])['result']['list']:
        if row['id'] in wanted:
            baseline[row['id']] = row
assert set(baseline) == wanted

def get(name):
    query = {'pageNum': 1, 'pageSize': 1000, 'searchContent': name, 'cardCategoryList': [],
             'cardColorList': [], 'rarityList': [], 'productCodeList': []}
    started = now()
    req = urllib.request.Request(api, data=json.dumps(query, ensure_ascii=False).encode(),
        headers={'Content-Type': 'application/json', 'Accept': 'application/json'}, method='POST')
    with urllib.request.urlopen(req, timeout=45) as r:
        body = r.read()
        record = {'url': api, 'request': query, 'startedAtUtc': started, 'receivedAtUtc': now(),
                  'httpStatus': r.status, 'headers': dict(r.headers), 'rawSha256': sha(body),
                  'originalUtf8': body.decode()}
    with (Q/('current-' + name + '-original-v1.json.gz')).open('xb') as f:
        f.write(gzip.compress(json.dumps(record, ensure_ascii=False).encode(), mtime=0))
    result = json.loads(body)['result']
    assert result['total'] == len(result['list'])
    return result['list']

names = sorted({row['cardName'] for row in baseline.values()})
with ThreadPoolExecutor(max_workers=3) as pool:
    results = list(pool.map(get, names))
rows = {r['id']: r for result in results for r in result if r['id'] in wanted}
assert rows == baseline

with (Q/'extra-rows.json').open('x') as f:json.dump(list(rows.values()),f,ensure_ascii=False,indent=2)
print('extra rows unchanged',len(rows))
