# -*- coding: utf-8 -*-
from pathlib import Path
import datetime, hashlib, json, re

w = Path(__file__).resolve().parent
root = Path('/Users/dinghaolin/MyProjects/riftbound')
load = lambda p: json.loads(p.read_text())
cases = load(w / 'all-fifty-current-controller-actual-new-case-identities-v1.json')['cases']
assert len(cases) == len(set(cases)) == 50
normalize = lambda s: s.replace('\u00b7', '-').upper()
common = ['OGS-001/024', 'DOC-01-P057-B012', 'DOC-01-P057-B014', 'DOC-01-P030-B007', 'DOC-01-P106-B010', 'DOC-01-P106-B013']
branches = []
for name in cases:
    method = name.split('(')[0].split('.')[-1]
    params = {}
    for key, value in re.findall(r'([A-Za-z]+): ("[^"]*"|-?\d+|True|False)', name):
        params[key] = json.loads(value) if value.startswith('"') else value == 'True' if value in {'True', 'False'} else int(value)
    refs = common[:]
    sql = False
    expected = {}
    if method == 'CountedDefendAddsControllerAndLocalBonusesOnceAndPreservesNoActionAtZero':
        printing = normalize(params['printing'])
        count = params['count']; local = params['local']
        identity = 'controller-counted-' + printing.replace('/', '-').lower().replace('*', 's') + '-count-' + str(count) + '-local-' + str(local).lower()
        refs += [printing, 'DOC-01-P074-B018', 'DOC-01-P106-B014', 'DOC-01-P106-B017']
        if local: refs += ['OGN-296/298']
        expected = {'targetDamage': 0 if count == 0 else count + 1 + int(local), 'damageActions': 0 if count == 0 else 1, 'originalRevealBaseAmount': count, 'noZeroCountDamageAction': count == 0}
        sql = local
    elif method == 'CountedSkillUsesItsControllersCurrentFieldSources':
        identity = 'controller-counted-source-' + params['zone'].lower() + '-' + params['controller'].lower() + '-copies-' + str(params['copies'])
        refs += ['OGN-121/298', 'DOC-01-P074-B018', 'DOC-01-P106-B014']
        expected = {'targetDamage': params['expected'], 'damageActions': 1}
    elif method == 'OfficialStarfallExampleAddsControllerBonusPerTargetAndLocalBonusOnlyAtItsTarget':
        identity = 'controller-starfall-copies-' + str(params['copies']) + '-local-' + str(params['local']).lower()
        refs += ['OGN-105/298', 'DOC-01-P106-B015']
        if params['local']: refs += ['OGN-296/298']
        expected = {'battlefieldTargetDamage': 6 + params['copies'] + int(params['local']), 'baseTargetDamage': 6 + params['copies'], 'damageActions': 2}
    elif method == 'SelectedBattlefieldDoesNotDoubleTheSharedControllerOrLocalBonus':
        identity = 'controller-selected-field-copies-' + str(params['copies']) + '-local-' + str(params['local']).lower()
        refs += ['OGS-002/024', 'DOC-01-P106-B015']
        if params['local']: refs += ['OGN-296/298']
        expected = {'eachEnemyUnitDamage': 3 + params['copies'] + int(params['local']), 'damageActions': 2}
    elif method == 'ActivatedXerathSkillAddsCurrentControllerAndTargetLocalBonuses':
        identity = 'controller-xerath-copies-' + str(params['copies']) + '-local-' + str(params['local']).lower()
        refs += ['UNL-026/219', 'DOC-01-P074-B012', 'DOC-01-P106-B014']
        if params['local']: refs += ['OGN-296/298']
        expected = {'targetDamage': 3 + params['copies'] + int(params['local']), 'damageActions': 1, 'sourceExhausts': True}
    elif method == 'ActualResponseSacrificeRemovesBonusBeforeTheOriginalSpellResolves':
        identity = 'controller-source-sacrificed-in-actual-response-before-starfall-resolution'
        refs += ['OGN-105/298', 'SFD-163/221', 'DOC-01-P106-B015']
        expected = {'eachOriginalStarfallTargetDamage': 6, 'annieInGraveyard': True, 'drawsExplicitOriginalDrawCard': True, 'noBurnoutConflation': True, 'noPureSacrificeSpellDamage': True}
    else:
        raise AssertionError('Unknown actual executed test method: ' + method)
    branches.append({'id': identity, 'sourceRefs': list(dict.fromkeys(refs)), 'state': 'RECORDED', 'boundedCase': {'actualExecutedCase': name, 'parameters': params, 'literalSourceGroundedExpectedValues': expected, 'countedSqlExactSamePrintingCountAndLocalBonus': sql}, 'semanticReview': {'state': 'BOUNDED_CURRENT_PRIMARY_SOURCE_REVIEW_NOT_WHOLE_CLAUSE_OR_PRINTING', 'numericCombinationNotMisrepresentedAsOfficialTeemoTwoCardExample': True}, 'implementation': {'state': 'THREE_EXISTING_SHARED_AMOUNT_ROUTES_CURRENT_CONTROLLER_ENUMERATION'}, 'testExecution': {'state': 'CONFORMANCE_AND_EXACT_COUNTED_SQL_HISTORY_PASS' if sql else 'CONFORMANCE_PASS_NO_EXTRA_SQL_CERTIFICATION_FROM_OTHER_CASES'}, 'fixedCommitCi': {'state': 'PENDING_NEW_FIXED_FULL'}, 'productAcceptance': {'state': 'OPEN_CURRENT_NATIVE_VISIBLE_AND_PHYSICAL_WINDOWS'}, 'decision': {'state': 'OPEN', 'reason': 'Bounded source and executable checks do not close new fixed CI, current required product acceptance or the other family branches.'}, 'wholePrintingCertified': False, 'existingAcceptanceGateDependencies': ['DECK_OBSERVATION_FAMILY_ALL_APPLICABLE_CONSUMERS', 'FIXED_CURRENT_CANDIDATE_FULL', 'USER_WINDOWS_RUNTIME']})
assert len(branches) == len({b['id'] for b in branches}) == 50
assert sum(b['boundedCase']['countedSqlExactSamePrintingCountAndLocalBonus'] for b in branches) == 12
m = load(root / 'docs/audit/current-manifest.json')
cards = {r['id'] for r in load(root / m['inputs']['cards']['path'])['records']}
corpus = {r['id'] for r in load(root / m['inputs']['corpus']['path'])['records']}
rules = {r['id'] for r in load(root / m['inputs']['rules']['path'])['records']}
assert all(set(b['sourceRefs']) <= cards | corpus | rules for b in branches)
p = w / 'fifty-source-bound-controller-behavior-branch-identities-v1.json'
assert not p.exists()
p.write_text(json.dumps({'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'newBranchIdentities': 50, 'exactCountedSqlBranches': 12, 'original16992ObligationIdsMustRemain': True, 'expectedCurrentTotalAfterPublication': 17042, 'allDecisionsOpenForCurrentFixedCiProductAndRemainingSemanticBranches': True, 'branches': branches}, ensure_ascii=False, indent=2))
print('Prepared 50 exact actual case/source branches;12 exact SQL matches; original16992 IDs retained -> expected17042; decisions OPEN')
