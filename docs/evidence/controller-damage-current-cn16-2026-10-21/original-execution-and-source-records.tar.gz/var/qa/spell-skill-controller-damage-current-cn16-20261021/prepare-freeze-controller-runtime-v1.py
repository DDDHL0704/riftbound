from pathlib import Path
import datetime, gzip, hashlib, json, os, shutil, subprocess

root = Path('/Users/dinghaolin/MyProjects/riftbound')
w = Path(__file__).resolve().parent
prior = root / 'var/qa/teemo-counted-damage-current-cn16-20261021'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
old = load(prior / 'current-counted-frozen-runtime-inputs-v2.json')
previous = Path(old['runtimeRoot'])
assert all(sha(previous / p) == h for p, h in old['runtimeFiles'].items())
paths = set(old['sourceInputHashes']) | {
    'tests/Riftbound.ConformanceTests/CurrentControllerDamageBonusTests.cs',
    'tests/Riftbound.PostgresAcceptance/ControllerDamageBonusSqlAcceptance.cs'}
inputs = {p: sha(root / p) for p in sorted(paths)}
modes = {p: oct((root / p).stat().st_mode & 0o777) for p in inputs}
assert not subprocess.check_output(['git', 'diff', '--name-only', '--', 'tests/Riftbound.ConformanceTests'], cwd=root)
full = [p for p in inputs if Path(p).name.startswith('FullGameEndToEndTests') and p.endswith('.cs')]
assert len(full) == 9
for p in full:
    assert (root / p).read_bytes() == subprocess.check_output(['git', 'show', '99e20b4f0640d7b32adbfb9e7dc0c7661b22d37a:' + p], cwd=root)
runtime = w / 'controller-runtime-v1'
runtime.mkdir(exist_ok=False)
sql = root / 'tests/Riftbound.PostgresAcceptance/bin/Debug/net10.0'
conformance = root / 'tests/Riftbound.ConformanceTests/bin/Debug/net10.0'
assert sha(sql / 'Riftbound.Engine.dll') == sha(conformance / 'Riftbound.Engine.dll')
links, clones = [], []
def retain(source, name):
    target = runtime / name
    if target.exists():
        assert sha(target) == sha(source)
        return
    target.parent.mkdir(parents=True, exist_ok=True)
    if name in old['runtimeFiles'] and sha(source) == old['runtimeFiles'][name]:
        target.symlink_to(previous / name)
        links.append(name)
    else:
        subprocess.run(['/bin/cp', '-c', str(source), str(target)], check=True)
        assert source.stat().st_ino != target.stat().st_ino and sha(source) == sha(target)
        clones.append(name)
for p in sorted(sql.rglob('*')):
    if p.is_file(): retain(p, str(p.relative_to(sql)))
for name in ['Riftbound.ConformanceTests.dll', 'Riftbound.ConformanceTests.pdb'] + [p.name for p in conformance.glob('xunit*.dll')]:
    retain(conformance / name, name)
reader = w / 'controller-independent-reader-source-v1'
assert reader.is_dir() and not any(reader.iterdir())
s = (prior / 'current-counted-independent-reader-source-v2/Program.cs').read_text()
assert s.count('printedCount+1') == 3
s = s.replace('printedCount+1', 'printedCount+2').replace('CURRENT_TEEMO', 'CURRENT_CONTROLLER_COUNTED')
s = s.replace('A positive counted Deal action receives the one Void Gate bonus.', 'A positive counted Deal action receives one current controller Annie bonus plus one Void Gate bonus.')
a = '    var frame=await new PostgresMatchRecoveryStore(source).LoadAsync(room,default)'
assert s.count(a) == 1
s = s.replace(a, '    Check(initial.CardObjects["ANNIE"].CardNo=="OGS·001/024"&&initial.CardObjects["ANNIE"].ControllerId=="P2"&&!initial.CardObjects["ANNIE"].IsFaceDown&&initial.PlayerZones["P2"].Base.Contains("ANNIE")&&initial.CardObjects["FIELD"].CardNo=="OGN·296/298","Independent literal Annie printing/controller/faceup/base and Void sources; expected bonus is not derived from writer or production helper.");\n' + a)
(reader / 'Program.cs').write_text(s)
pairs = w / 'original-all110-pair-source-v1'
pairs.mkdir(exist_ok=False)
s = (prior / 'affected-original-pair-source-v1/Program.cs').read_text()
a = 'var teemoPrintings = new[]{"OGN·121/298","OGN·121a/298","SFD·230/221","SFD·230*/221"};'
assert a in s
s = s.replace(a, 'const string controllerBonusPrinting = "OGS·001/024";')
a = 'var affectedDecks = decks.Where(d => d.Decklist.Battlefields.Contains("OGN·296/298", StringComparer.Ordinal) || d.Decklist.MainDeck.Any(teemoPrintings.Contains)).Select(d => d.Id).ToHashSet(StringComparer.Ordinal);'
assert a in s
s = s.replace(a, 'var literalAnnieMainDecks = decks.Where(d => d.Decklist.MainDeck.Contains(controllerBonusPrinting, StringComparer.Ordinal)).Select(d => d.Id).ToHashSet(StringComparer.Ordinal);')
a = 'var affected = pairs.Where(p => affectedDecks.Contains(p.A.Id) || affectedDecks.Contains(p.B.Id)).ToArray();'
assert a in s
s = s.replace(a, 'var selected = pairs;')
a = 'if (decks.Count != 11 || pairs.Length != 110 || !affectedDecks.Contains("kaisa-red-control") || affected.Length < 20 || affected.Length > 110) throw new Exception("Original eleven-deck/110-pair universe and exact Teemo-or-Void affected direction set required.");'
assert a in s
s = s.replace(a, 'if (decks.Count != 11 || pairs.Length != 110 || selected.Length != 110 || literalAnnieMainDecks.Count != 0) throw new Exception("Original eleven decks and all110 directions required; no literal Annie in the measured main decks.");')
s = s.replace('affectedDecks = affectedDecks.Order()', 'literalAnnieMainDecks = literalAnnieMainDecks.Order()')
s = s.replace('actualAffectedPairs', 'actualSelectedPairs').replace('affectedPairs', 'selectedPairs')
s = s.replace('affected.', 'selected.').replace('ForEachAsync(affected,', 'ForEachAsync(selected,')
s = s.replace('AFFECTED_ORIGINAL_PAIR_PASS', 'ORIGINAL_ALL110_PAIR_PASS')
s = s.replace('PASS_CURRENT_AFFECTED_ORIGINAL_TEEMO_OR_VOID_PAIR_HELPERS_NOT_ALL110_PUBLIC_METHOD_OR_FULL_CI', 'PASS_CURRENT_CONTROLLER_ALL110_ORIGINAL_PAIR_HELPERS_NOT_ALL143_PUBLIC_METHODS_OR_FULL_CI')
s = s.replace('FAILED_ADDITIONAL_AFFECTED_ORIGINAL_PAIR_RUN_NOT_FULL_PASS', 'FAILED_CURRENT_CONTROLLER_ALL110_ORIGINAL_PAIR_RUN_NOT_FULL_PASS')
(pairs / 'Program.cs').write_text(s)
projects = [(reader, 'CurrentControllerIndependentReaderV1'), (pairs, 'CurrentControllerOriginalAll110PairRunnerV1')]
refs = ['Riftbound.Contracts', 'Riftbound.Engine', 'Riftbound.CardCatalog', 'Riftbound.Persistence', 'Npgsql']
for directory, assembly in projects:
    project = '<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFramework>net10.0</TargetFramework><OutputType>Exe</OutputType><AssemblyName>' + assembly + '</AssemblyName><ImplicitUsings>enable</ImplicitUsings><Nullable>enable</Nullable><UseAppHost>false</UseAppHost></PropertyGroup><ItemGroup>'
    for ref in refs:
        project += '<Reference Include="' + ref + '"><HintPath>' + str(runtime / (ref + '.dll')) + '</HintPath><Private>false</Private></Reference>'
    project += '</ItemGroup></Project>'
    (directory / 'probe.csproj').write_text(project)
    with (w / (directory.name + '-build-v1.log')).open('xb') as log:
        subprocess.run(['/Users/dinghaolin/.dotnet/dotnet', 'build', str(directory / 'probe.csproj'), '--configuration', 'Release', '--nologo'], cwd=root, stdout=log, stderr=subprocess.STDOUT, check=True)
    for suffix in ['.dll', '.pdb']:
        retain(directory / 'bin/Release/net10.0' / (assembly + suffix), assembly + suffix)
files = {str(p.relative_to(runtime)): sha(p) for p in runtime.rglob('*') if p.is_file()}
command = ['/Users/dinghaolin/.dotnet/dotnet', 'exec', '--depsfile', str(runtime / 'Riftbound.PostgresAcceptance.deps.json'), '--runtimeconfig', str(runtime / 'Riftbound.PostgresAcceptance.runtimeconfig.json'), str(runtime / 'CurrentControllerIndependentReaderV1.dll'), '--identity']
identity = json.loads(subprocess.check_output(command, cwd=runtime))
assert identity['authoritySha256'] == '70ccda5893a1b8b56cdceadee35e084b1e3f5b297ef64e1ce7d0cbeb141ce2d4'
assert identity['catalogSha256'] == 'e7455edc32d43f8253a9d0c6fedb83c347bebafbef064f9b8dffaaabc4b4d266'
assert all(sha(root / p) == h for p, h in inputs.items())
proof = {'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'parentCommit': '99e20b4f0640d7b32adbfb9e7dc0c7661b22d37a', 'runtimeRoot': str(runtime), 'runtimeFiles': files, 'sourceInputHashes': inputs, 'sourceInputModes': modes, 'actualRuleInputs': identity, 'unchangedImmutableLinks': links, 'independentApfsClones': clones, 'allNineOriginalFullGameSourcesByteExact': full, 'allTrackedPriorConformanceSourcesAndAssertionsUnchanged': True, 'original54SqlCasesRetainedOnly55Appended': True, 'uncommittedBoundedBatch': True}
(w / 'current-controller-frozen-runtime-inputs-v1.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2))
print('FROZEN_CURRENT_CONTROLLER', len(files), 'files;', len(links), 'unchanged links;', len(clones), 'independent APFS clones; identity', identity['identitySha256'], flush=True)
