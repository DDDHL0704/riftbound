using System.Collections.Concurrent;
using System.Reflection;
using System.Runtime.Loader;
using System.Text.Json;
using Riftbound.CardCatalog;
using Riftbound.Contracts;
using Riftbound.Engine;

if (args.Length != 1 || File.Exists(args[0])) throw new Exception("Unused result path required.");
AssemblyLoadContext.Default.Resolving += (context, name) => {
    var path = Path.Combine(AppContext.BaseDirectory, name.Name + ".dll");
    return File.Exists(path) ? context.LoadFromAssemblyPath(path) : null;
};
var assembly = AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.Combine(AppContext.BaseDirectory, "Riftbound.ConformanceTests.dll"));
var type = assembly.GetType("Riftbound.ConformanceTests.FullGameEndToEndTests", throwOnError: true)!;
var seed = Convert.ToInt64(type.GetField("LowCurveReplaySeed", BindingFlags.NonPublic | BindingFlags.Static)!.GetRawConstantValue());
if (seed != 424242) throw new Exception("Original seed must remain unchanged.");
var method = type.GetMethod("AssertFullGameScoreVictoryActionLogReplaysToFinalStateHashAsync", BindingFlags.NonPublic | BindingFlags.Static)
    ?? throw new Exception("Exact original full-game assertion helper required.");
var catalog = await OfficialCardCatalog.LoadDefaultAsync();
var decks = PreconstructedDeckCatalog.Build(catalog);
var pairs = decks.SelectMany(a => decks.Where(b => a.Id != b.Id).Select(b => (A: a, B: b, Id: a.Id + "-vs-" + b.Id))).ToArray();
const string controllerBonusPrinting = "OGS·001/024";
var literalAnnieMainDecks = decks.Where(d => d.Decklist.MainDeck.Contains(controllerBonusPrinting, StringComparer.Ordinal)).Select(d => d.Id).ToHashSet(StringComparer.Ordinal);
var selected = pairs;
if (decks.Count != 11 || pairs.Length != 110 || selected.Length != 110 || literalAnnieMainDecks.Count != 0) throw new Exception("Original eleven decks and all110 directions required; no literal Annie in the measured main decks.");
await File.WriteAllTextAsync(args[0]+".plan.json", JsonSerializer.Serialize(new { seed, decks = decks.Select(d => new { d.Id, exactBattlefields = d.Decklist.Battlefields, exactMainDeck = d.Decklist.MainDeck }), originalAll110Pairs = pairs.Select(p => p.Id).Order().ToArray(), actualSelectedPairs = selected.Select(p => p.Id).Order().ToArray(), originalVictoryReplayAndSeedAssertionsUnchanged = true }, new JsonSerializerOptions { WriteIndented=true }));
var completed = new ConcurrentDictionary<string, string>(StringComparer.Ordinal);
try
{
    await Parallel.ForEachAsync(selected, new ParallelOptions { MaxDegreeOfParallelism = Math.Min(2, Environment.ProcessorCount) }, async (pair, _) => {
        var original = method.Invoke(null, new object[] {
            "b0-full-game-preconstructed-catalog-replay-room-" + pair.Id,
            "b0-full-preconstructed-catalog-replay-score-" + pair.Id, pair.A.Decklist, pair.B.Decklist });
        var hash = await (ValueTask<string>)original!;
        if (!completed.TryAdd(pair.Id, hash)) throw new Exception("Duplicate affected original pair.");
        Console.WriteLine("ORIGINAL_ALL110_PAIR_PASS " + JsonSerializer.Serialize(new { pair = pair.Id, finalHash = hash, completed = completed.Count, expected = selected.Length }));
    });
    if (!selected.Select(p => p.Id).Order(StringComparer.Ordinal).SequenceEqual(completed.Keys.Order(StringComparer.Ordinal))) throw new Exception("Missing original affected pair.");
    var result = new { status = "PASS_CURRENT_CONTROLLER_ALL110_ORIGINAL_PAIR_HELPERS_NOT_ALL143_PUBLIC_METHODS_OR_FULL_CI",
        seed, originalDeckCount = decks.Count, originalFullMatrixPairCount = pairs.Length, literalAnnieMainDecks = literalAnnieMainDecks.Order().ToArray(),
        selectedPairs = selected.Select(p => p.Id).Order().ToArray(), completed = completed.OrderBy(p => p.Key).ToDictionary(p => p.Key, p => p.Value),
        actualRuleInputs = RuleInputIdentity.Current, originalVictoryReplayInitialDeckRoomIntentAndSeedAssertionsExecutedUnchanged = true,
        all110MatrixAnd143PublicFullGameMethodSourcesRetained = true, sourceCardPrintingOrWholeFamilyCertification = false };
    await File.WriteAllTextAsync(args[0], JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }));
    Console.WriteLine(result.status);
}
catch (Exception e)
{
    await File.WriteAllTextAsync(args[0] + ".failure.json", JsonSerializer.Serialize(new { status = "FAILED_CURRENT_CONTROLLER_ALL110_ORIGINAL_PAIR_RUN_NOT_FULL_PASS",
        completed, expectedPairs = selected.Select(p => p.Id).ToArray(), error = (e is TargetInvocationException t ? t.InnerException : e)?.ToString() }, new JsonSerializerOptions { WriteIndented = true }));
    throw;
}
