# -*- coding: utf-8 -*-
from pathlib import Path
import copy, datetime, gzip, hashlib, io, json, re, tarfile

root = Path('/Users/dinghaolin/MyProjects/riftbound')
w = Path(__file__).resolve().parent
native = root / 'var/qa/fixed99e-early-native-20261021'
prior = w / 'prior-current-controller-publication-v1'
load = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(path, value):
    with path.open('x') as stream: json.dump(value, stream, ensure_ascii=False, indent=2)
def pin(path, role=None):
    value = {'path': str(path.relative_to(root)), 'sha256': sha(path)}
    if role: value['role'] = role
    return value
check = load(w / 'check-original-case-method-and-input-retention-v1.json')
assert check['status'] == 'CHECK_AND_EXACT_CASE_METHOD_PARITY_PASS' and check['failed'] == check['skipped'] == 0
assert (check['actualCases'], check['actualMethods']) == (13304, 7516)
focus = load(w / 'final-current-controller-focus-union-v1.json')
assert (focus['distinctCases'], focus['distinctMethods']) == (863, 522)
sql = load(w / 'actual-current-controller-sql-owner-terminal-v1.json')
assert sql['commands'] == 48 and sql['events'] == 152 and sql['ownPostgresStopped'] and sql['allOriginal288AuditSevenTablesExactAtStop'] and sql['allOriginal62NativeSevenTablesExactAtStop']
pairs = load(w / 'original-all110-pairs-independent-exact-readback-v2.json')
assert pairs['status'].startswith('PASS_INDEPENDENT_CURRENT_ALL110') and pairs['originalPairs'] == 110
frozen = load(w / 'current-controller-frozen-runtime-inputs-v2.json')
assert all(sha(root / p) == h for p, h in frozen['sourceInputHashes'].items())
mp = root / 'docs/audit/current-manifest.json'; manifest = load(mp)
rp = root / manifest['inputs']['reviews']['path']; reviews = load(rp)
assert len(reviews['reviews']) == 157 and len(manifest['reviewContexts']) == 72 and len(manifest['acceptanceGates']) == 245 and len(manifest['laterSourceDeltas']) == 7
for p in [mp, rp, root / 'docs/PROJECT_STATUS.md']:
    assert gzip.decompress((prior / (p.name + '.gz')).read_bytes()) == p.read_bytes()
old_manifest = copy.deepcopy(manifest); old_reviews = copy.deepcopy(reviews)
stale = json.loads(gzip.decompress((prior / 'complete-current-contexts-before-input-refresh.json.gz').read_bytes()))
assert len(stale) == 37 and all(manifest['reviewContexts'][v['id']] == v['oldCompleteContext'] for v in stale)
ev = root / 'docs/evidence/controller-damage-current-cn16-2026-10-21'
ev.mkdir(exist_ok=False)
final_source = load(w / 'current-controller-three-paths-exact-source-scope-review-v2.json')
final_source['priorSourceReviewBeforeCheckClosed'] = pin(w / 'current-controller-three-paths-exact-source-scope-review-v2.json')
final_source['atUtc'] = now()
final_source['state'] = 'BOUNDED_CURRENT_SOURCE_FOCUS_SQL_ALL110_AND_ONE_CHECK_PASS_NEW_FIXED_FULL_AND_PRODUCT_OPEN'
final_source['soleCheck'] = {'status': check['status'], 'cases': check['actualCases'], 'methods': check['actualMethods'], 'failed': 0, 'skipped': 0}
final_source_path = w / 'current-controller-three-paths-exact-source-scope-review-v3.json'
if final_source_path.exists():
    retained_final = load(final_source_path)
    assert retained_final['soleCheck'] == final_source['soleCheck'] and retained_final['ruleRecords'] == final_source['ruleRecords'] and retained_final['actualRuleInputs'] == final_source['actualRuleInputs']
    final_source = retained_final
else:
    write(final_source_path, final_source)
standalone = {
    'check-original-case-method-and-input-retention.json': 'check-original-case-method-and-input-retention-v1.json',
    'final-distinct-focus-execution.json': 'final-current-controller-focus-union-v1.json',
    'real-twelve-sql-terminal.json': 'actual-current-controller-sql-owner-terminal-v1.json',
    'independent-all-history-and-original-replay.json': 'independent-current-controller-all-history-v1.json',
    'original-all110-independent-readback.json': 'original-all110-pairs-independent-exact-readback-v2.json',
    'original-all110-owner-wrapper-failure-retained.json': 'original-all110-pairs-owner-terminal-v1.json',
    'actual-runtime-loader-link-correction.json': 'actual-runtime-loader-link-correction-v1.json',
    'actual-executing-assemblies-after-loader-correction.json': 'actual-after-metadata-link-repair-executing-assemblies-v2.json',
    'current-exact-source-review.json': 'current-controller-three-paths-exact-source-scope-review-v3.json',
    'all-fifty-exact-case-identities.json': 'all-fifty-current-controller-actual-new-case-identities-v1.json',
    'all-direct-damage-callsite-scope.json': 'pre-change-exact-callsite-classification-clarification-v2.json',
    'completed-duplicate-ci-extraction-retirement.json': 'completed-fixed25c-duplicate-extraction-retirement-v1.json',
    'completed-helper-staging-retirement.json': 'completed-controller-three-helper-staging-retirement-v1.json',
    'preceding-fixed25c-complete-full.json': 'ci25c-entire-full-independent-verification-v1.json'}
for name, source in standalone.items(): (ev / name).write_bytes((w / source).read_bytes())
(ev / '37-prior-complete-contexts.json.gz').write_bytes((prior / 'complete-current-contexts-before-input-refresh.json.gz').read_bytes())
for name, source in {
    'preceding-fixed708-complete-full.json': root / 'var/qa/teemo-counted-damage-current-cn16-20261021/ci708-entire-full-independent-verification-v1.json',
    'preceding-fixed99e-native-owner.json': native / 'live-current-ci-main-owner-terminal-v2.json',
    'preceding-fixed99e-native-independent-readback.json': native / 'independent-fixed99e-native-history-result-v2.json',
    'superseded-native-pair-and-two-installers-retirement.json': native / 'superseded-fixed708-native-pair-and-two-archives-retirement-v1.json'}.items():
    (ev / name).write_bytes(source.read_bytes())
members = {}
excluded = []
private = {native / 'session-a.json', native / 'session-b.json', native / 'actual-safe-native-prefix-v2/session-native-a.json', native / 'actual-safe-native-prefix-v2/session-native-b.json'}
runtime_roots = [w / 'controller-runtime-v1', native / 'fixed99e-api-gameplay-closure-runtime-v1', native / 'fixed99e-native-helpers-runtime-v1', native / 'fixed99e-native-history-reader-runtime-v1', native / 'Riftbound-A.app', native / 'Riftbound-B.app', native / 'native-current']
secret_pattern = re.compile(rb'(?i)(?:playerKey|reconnectToken)[\"\s]*[:=][\s\"]*([a-z0-9_+/-]{16,})')
for folder in [w, native]:
    for p in sorted(folder.rglob('*')):
        if any(p.is_relative_to(r) for r in runtime_roots) or {'bin', 'obj', '__pycache__'} & set(p.relative_to(folder).parts): continue
        if not p.is_file(): continue
        if p in private or p.name.startswith('publish-current-controller-owner') or p.name.startswith('postpublication-'):
            excluded.append({'path': str(p.relative_to(root)), 'sha256': sha(p), 'reason': 'PRIVATE_SESSION_OR_OPERATIONAL_PUBLICATION_OUTPUT_RETAINED_SEPARATELY'})
            continue
        raw = p.read_bytes()
        if p.suffix in {'.json', '.log', '.ndjson'}:
            assert not secret_pattern.search(raw), 'Unexpected token-bearing data must remain private: ' + str(p)
        members[str(p.relative_to(root))] = p
old_archive_map = load(root / 'docs/evidence/teemo-counted-current-cn16-2026-10-21/archive-map.json')
old_members = {v['path']: v for v in old_archive_map['members']}
older_refs = []
older = root / 'var/qa/teemo-counted-damage-current-cn16-20261021'
extra = [p for p in older.glob('ci708*') if p.is_file()]
extra += [older / 'verify-completed-fixed708-full-originals-v1.py', root / 'var/qa/fixed708-early-native-20261021/verify-completed-fixed2b83-full-originals-v1.py', root / 'var/qa/void-gate-current-erratum-20261021/current-core-damage-p106.png']
extra += [(Path(v['path']) if Path(v['path']).is_absolute() else root / v['path']) for v in load(older / 'ci708-entire-full-independent-verification-v1.json')['artifacts']]
for p in extra:
    name = str(p.relative_to(root))
    if name in old_members and old_members[name]['sha256'] == sha(p):
        older_refs.append({'path': name, 'sha256': sha(p), 'existingArchiveMap': pin(root / 'docs/evidence/teemo-counted-current-cn16-2026-10-21/archive-map.json')})
    else: members[name] = p
archive = ev / 'original-execution-and-source-records.tar.gz'
rows = []
with tarfile.open(archive, 'w:gz', compresslevel=9) as tar:
    for name, p in sorted(members.items()):
        raw = p.read_bytes(); item = tarfile.TarInfo(name); item.size = len(raw); item.mode = p.stat().st_mode & 0o777; item.mtime = 0
        tar.addfile(item, io.BytesIO(raw)); rows.append({'path': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
with tarfile.open(archive, 'r:gz') as tar:
    assert set(tar.getnames()) == {v['path'] for v in rows}
    for row in rows:
        raw = tar.extractfile(row['path']).read(); assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
write(ev / 'archive-map.json', {'atUtc': now(), 'archive': pin(archive), 'members': rows, 'existingIdenticalOlderArchiveMembersNotDuplicated': older_refs, 'privateOrOperationalExclusionsRetainedLocally': excluded, 'allMembersBytesHashesAndClosedSetVerified': True, 'applicationsInstallersEqualPrimaryPdfsAndFrozenRuntimePayloadsNotDuplicated': True})
source_manifest = {'schemaVersion': 1, 'id': 'controller-damage-current-cn16-2026-10-21', 'atUtc': now(), 'region': 'CN', 'language': 'zh-CN', 'applicableAsOf': '2026-10-21', 'adoptedCoreEffectiveDate': '2026-10-16', 'primaryCoreId': 'DOC-01', 'primaryCoreSha256': 'd6fd7140f106f9b5b3dc0d5817fd040110fe870a6da9ee335ba7f4f70f892d11', 'sourceVersionChanged': False, 'oldPublicationEffectiveAndAcquisitionDatesNotRewritten': True, 'currentSourceReview': pin(ev / 'current-exact-source-review.json'), 'archive': pin(archive), 'archiveMap': pin(ev / 'archive-map.json'), 'actualRuleInputs': frozen['actualRuleInputs'], 'parentCommit': frozen['parentCommit'], 'declaredUncommittedBatch': True, 'scope': 'Only three existing shared spell/skill amount routes and50 bounded cases;12 exact counted SQL cases. Other direct consumers, complete printings, current fixed full, visible/physical Windows remain open.', 'fullScopeRetained': {'printings': 1740, 'ruleBlocks': 14293, 'cnRows': 1504, 'enRows': 1408, 'enReported': 1416, 'enGap': 8, 'active': 1035, 'outsideActive': 705, 'cnDispositions': 236, 'news': 139, 'sourceDeltas': 7}, 'semanticCoverageCertified': False}
write(ev / 'source-manifest.json', source_manifest)
sp = pin(ev / 'source-manifest.json', 'source-manifest')
for row in stale:
    context = manifest['reviewContexts'][row['id']]
    for ref in context['implementation']:
        for change in row['changes']:
            if ref['path'] == change['path']: ref['sha256'] = change['currentSha256']
    context['currentImplementationCommit'] = frozen['parentCommit']; context['currentImplementationIncludesUncommittedChanges'] = True
    context['ciState'] = 'PENDING'
refresh = {'atUtc': now(), 'status': '37_CURRENT_IMPLEMENTATION_BINDINGS_REFRESHED_COMPLETE_OLD_OBJECTS_RETAINED', 'records': [{'id': v['id'], 'changes': v['changes']} for v in stale], 'oldCompleteContexts': pin(ev / '37-prior-complete-contexts.json.gz'), 'allHistoricalSourceVersionsEvidenceAndVerificationSourcesRetained': True}
write(ev / '37-current-input-context-refresh.json', refresh)
branches = copy.deepcopy(load(w / 'fifty-source-bound-controller-behavior-branch-identities-v1.json')['branches'])
for branch in branches: branch['sourceManifest'] = sp
review_id = source_manifest['id']
implementation = ['src/Riftbound.Engine/CoreRuleEngine.cs', 'src/Riftbound.Engine/CoreRuleEngine.DamageDistribution.cs', 'src/Riftbound.Engine/CardStaticAbilitySpecRules.cs', 'src/Riftbound.Engine/AttachedRuleText.cs', 'src/Riftbound.Engine/RuleInputIdentity.cs', 'src/Riftbound.CardCatalog/RuleTextParsers.cs', 'data/official/card-catalog.zh-CN.json']
verification = ['tests/Riftbound.ConformanceTests/CurrentControllerDamageBonusTests.cs', 'tests/Riftbound.PostgresAcceptance/ControllerDamageBonusSqlAcceptance.cs', 'tests/Riftbound.PostgresAcceptance/Program.cs', 'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json', 'scripts/tests/test_sql_ci_gate.py']
manifest['reviewContexts'][review_id] = {'evidenceCommit': frozen['parentCommit'], 'currentImplementationCommit': frozen['parentCommit'], 'currentImplementationIncludesUncommittedChanges': True, 'ciState': 'PENDING', 'ciReceipts': [], 'region': 'CN', 'language': 'zh-CN', 'applicableAsOf': '2026-10-21', 'adoptedCoreEffectiveDate': '2026-10-16', 'sourceManifest': sp, 'implementation': [pin(root / p, 'implementation') for p in implementation], 'verificationSources': [pin(root / p, 'verification-source') for p in verification], 'evidence': [pin(ev / p, role) for p, role in [('final-distinct-focus-execution.json', 'focus'), ('check-original-case-method-and-input-retention.json', 'check'), ('real-twelve-sql-terminal.json', 'sql'), ('independent-all-history-and-original-replay.json', 'independent-sql'), ('original-all110-independent-readback.json', 'original-pair-helpers')]], 'branches': branches}
finding_context = manifest['reviewContexts']['teemo-counted-current-cn16-2026-10-21']
finding = next(b for b in finding_context['branches'] if b['id'] == 'supporting-own-on-field-annie-one-count-teemo-defense-global-skill-bonus-omitted')
old_finding = copy.deepcopy(finding)
finding['currentBoundedStageFollowup'] = {'review': review_id, 'sourceManifest': sp, 'oldCounterexampleAndSourceManifestRetained': True, 'currentTestedNeutralOneCountDamage': 2, 'currentBoundedFixDoesNotCloseOtherDirectConsumersOrWholeAnnie': True}
finding['implementation'] = {'state': 'CURRENT_THREE_SHARED_PATH_BOUNDED_FIX_OTHER_DIRECT_PATHS_OPEN', 'sourceManifest': sp}
finding['testExecution'] = {'state': 'CURRENT_FOCUS_SQL_ALL110_AND_ONE_CHECK_BOUNDED_PASS', 'sourceManifest': sp}
finding['fixedCommitCi'] = {'state': 'PENDING_NEW_FIXED_FULL'}
finding['decision'] = {'state': 'OPEN', 'reason': 'Historical counterexample retained. Current bounded source/implementation/tests pass; new fixed full, current product and other family paths remain open.'}
write(ev / 'prior-annie-finding-explicit-current-stage-followup.json', {'atUtc': now(), 'oldCompleteBranch': old_finding, 'newCompleteBranch': finding, 'oldSourceManifestRefsBoundedCounterexampleAndIssueUnchanged': True})
source = final_source
subjects = ['OGS-001/024', 'OGN-121/298', 'OGN-121A/298', 'SFD-230/221', 'SFD-230*/221', 'OGN-296/298', 'OGN-105/298', 'OGS-002/024', 'UNL-026/219', 'SFD-163/221']
reviews['reviews'].append({'id': review_id, 'scope': source_manifest['scope'], 'subjects': subjects, 'ruleRecords': [v['id'] for v in source['ruleRecords']], 'status': 'BOUNDED_CURRENT_CONTROLLER_THREE_PATHS_FOCUS863_CHECK13304_SQL48_ALL110_PASS_NEW_FIXED_FULL_AND_PRODUCT_OPEN', 'sourceManifest': sp, 'auditDocument': 'docs/CONTROLLER_DAMAGE_CURRENT_CN16_AUDIT_2026-10-21.md', 'validation': {'newConformanceCases': 50, 'newConformanceMethods': 6, 'distinctFocusCases': 863, 'distinctFocusMethods': 522, 'checkCases': 13304, 'checkMethods': 7516, 'sqlCases': 12, 'sqlCommands': 48, 'sqlEvents': 152, 'sqlColdRecoveries': 48, 'originalPairHelperDirections': 110, 'allOriginal143FullMethods54SqlIdentitiesAndTheoriesRetained': True, 'wholeCardCertification': False}, 'exclusions': source['boundaries']})
assert reviews['reviews'][:157] == old_reviews['reviews'] and manifest['acceptanceGates'] == old_manifest['acceptanceGates'] and manifest['laterSourceDeltas'] == old_manifest['laterSourceDeltas']
rp.write_text(json.dumps(reviews, ensure_ascii=False, indent=2) + '\n')
manifest['inputs']['reviews']['sha256'] = sha(rp)
manifest['currentControllerSpellSkillDamageInputChange'] = {'sourceManifest': sp, 'auditDocument': 'docs/CONTROLLER_DAMAGE_CURRENT_CN16_AUDIT_2026-10-21.md', 'newBranches': 50, 'original16992ObligationIdsMustRemain': True, 'expectedCurrentTotal': 17042, 'all157OldReviewsExact': True, 'all245GateObjectsAndSevenDeltasExact': True, '37CurrentInputRefreshes': pin(ev / '37-current-input-context-refresh.json'), 'explicitOldAnnieFindingFollowup': pin(ev / 'prior-annie-finding-explicit-current-stage-followup.json'), 'fullOrWholePrintingCertification': False}
manifest['precedingFixed25cActualCompleteFullCiReadback'] = pin(ev / 'preceding-fixed25c-complete-full.json')
manifest['precedingFixed708ActualCompleteFullCiReadback'] = pin(ev / 'preceding-fixed708-complete-full.json')
manifest['precedingFixed99eBoundedHeadlessCiNativeReadback'] = pin(ev / 'preceding-fixed99e-native-independent-readback.json')
mp.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
governance = '本批158限定审查、73上下文、245门禁、七来源增量。原157审查完整；35上下文整对象原样、37上下文仅刷新当前实现绑定并留完整旧对象，其中既有安妮发现另有显式当前限定阶段跟进，原反例、来源与Issue保留。原245门禁和七来源增量整对象不改。原16992义务身份全留，只增50限定行为至17042，语义全量仍false。'
check_text = '本批唯一check实际13304例/7516方法全部通过、零失败零跳过。原13254用例名称/次数和7510方法全留，只增50/6；原check两次旧来源期望失败的原件保留，不重写成绿。3330源/模式、1419 Conformance与23原生Debug文件全程稳定，后者仅记录稳定，不称本批原生执行验收。没有第二check，新固定full仍独立待核。'
ci_text = '固定99e整次full在本批发布时仍按最后实际读取状态单独待核；已有原生和部分CI通过不得代替整次full。'
text = (w / 'current-controller-audit-draft-v1.md').read_text().replace('{{CHECK_RESULT}}', check_text).replace('{{GOVERNANCE_RESULT}}', governance).replace('{{PRIOR99E_CI_STATE}}', ci_text)
assert '{{' not in text
(root / 'docs/CONTROLLER_DAMAGE_CURRENT_CN16_AUDIT_2026-10-21.md').write_text(text)
status = root / 'docs/PROJECT_STATUS.md'; previous = status.read_text(); prefix = '# 当前项目状态\n\n'; assert previous.startswith(prefix)
lead = '2026-10-21 本批：[控制者法术/技能加成三个共享入口](CONTROLLER_DAMAGE_CURRENT_CN16_AUDIT_2026-10-21.md)。现行三完整API行与原CN16一致，核心30/57/74/106来源保留；普通/已确认技能、正数计数技能、泽拉斯复用当前场上控制者加成，并保留原本地加成、零张无行动、分摊和独立安全验证，不改目录或DSL。新50/6，去重focus863/522；唯一check13304/7516全过、原13254/7510全留，3330源/1419运行/23原生Debug输入稳定。原110配对助手均以424242及原正常胜利/回放断言执行；143公共完整方法、十一牌组、全部Theory和断言保留，非整次full替代。\n\n十二计数SQL48命令152事件48冷恢复48直接/48结构拒绝；独立48历史/96快照/96提示、全部原回放及48结构拒绝。原288审计/62原生七表不变，留至300审计，库正常停止；原54SQL身份顺序及独立类保留，只加55。此前冻结deps链接加载旧引擎在提交任何新SQL动作前被实际探针发现，改独立控制元数据后实际目录/程序集SHA/MVID及62a383身份一致；生产身份算法不改。响应/泽拉斯准备及110汇总字段大小写错误全部原件保留，既有原对局不重跑不改写。\n\n固定708和25c整次11项success，独立13387/7649、143/110/11/424242、各自52/53SQL及网络15/0通过。固定99e实际CI导出双端93命令664事件、63回合8:0、三生产交互路由命令、同进程冷重连、独立93历史/182快照/182提示及全部原回放通过；API952442与本批62a383分开。它不覆盖本批新加成，可见控件/双窗、Windows及新固定full仍OPEN。\n\n' + governance + ' 只留最新99e A/B及每平台一包；旧708双端/两包与已完成重复解压/助手暂存按字节核对后清退，原件、执行文件与库保留，不推定物理回收。Goal active / NOT READY。\n\n以下原批按原范围与当时终态保留。\n\n'
status.write_text(prefix + lead + previous[len(prefix):])
write(ev / 'publication-original-obligation-retention.json', {'atUtc': now(), 'status': 'BOUNDED_CONTROLLER50_NEW_FULL_AND_PRODUCT_OPEN_NOT_GOAL_COMPLETION', 'originalReviews': 157, 'currentReviews': 158, 'oldContextCount': 72, 'currentContextCount': 73, 'oldWholeContextsUnchanged': 35, 'currentInputRefreshes': 37, 'all245GateObjectsAndSevenDeltasExact': True, 'oldObligations': 16992, 'newBoundedBranches': 50, 'expectedCurrentObligations': 17042, 'allOldSourceDatesVersionsScopesAndGapsRetained': True, 'archiveMembers': len(rows), 'archiveBytes': archive.stat().st_size, 'sourceManifest': sp})
print('Published158reviews73contexts245gates;157old reviews/35whole contexts exact;37 current pins+explicit prior Annie stage;16992+50=17042 expected;archive', len(rows), archive.stat().st_size, flush=True)
