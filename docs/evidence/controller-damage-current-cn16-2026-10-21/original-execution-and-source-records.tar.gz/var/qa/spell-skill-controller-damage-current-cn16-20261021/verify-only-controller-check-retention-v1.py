from pathlib import Path
import collections, datetime, hashlib, json, subprocess, xml.etree.ElementTree as ET

root = Path('/Users/dinghaolin/MyProjects/riftbound')
w = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def read(path):
    tree = ET.parse(path)
    definitions = {t.get('id'): t.find('t:TestMethod', ns).attrib for t in tree.findall('.//t:UnitTest', ns)}
    rows = tree.findall('.//t:UnitTestResult', ns)
    counts = collections.Counter(t.get('testName') for t in rows)
    methods = {definitions[t.get('testId')]['className'] + '.' + definitions[t.get('testId')]['name'] for t in rows}
    return rows, counts, methods
start = load(w / 'only-check-start-inputs-v1.json')
terminal = load(w / 'only-check-owner-terminal-v1.json')
assert terminal['exitCode'] == 0
assert all(terminal[k] for k in ['all3330SourceHashesAndModesStable', 'all1419ConformanceRuntimeInputsStable', 'all23NativeDebugRuntimeInputsStable'])
current = w / 'only-check-v1/check/results.trx'
before = root / start['originalBaselineTrx']
assert sha(before) == start['originalBaselineTrxSha256']
rows, counts, methods = read(current)
oldrows, oldcounts, oldmethods = read(before)
assert len(rows) == 13304 and len(methods) == 7516 and all(t.get('outcome') == 'Passed' for t in rows)
assert len(oldrows) == 13254 and len(oldmethods) == 7510
assert not oldcounts - counts and oldmethods <= methods
assert sum((counts - oldcounts).values()) == 50 and len(methods - oldmethods) == 6
expected = load(w / 'all-fifty-current-controller-actual-new-case-identities-v1.json')['cases']
assert set((counts - oldcounts).elements()) == set(expected)
f = load(w / 'current-controller-frozen-runtime-inputs-v2.json')
assert len(f['sourceInputHashes']) == 3330
assert all(sha(root / p) == h and oct((root / p).stat().st_mode & 0o777) == f['sourceInputModes'][p] for p, h in f['sourceInputHashes'].items())
full = [p for p in f['sourceInputHashes'] if Path(p).name.startswith('FullGameEndToEndTests') and p.endswith('.cs')]
assert len(full) == 9
for p in full:
    assert (root / p).read_bytes() == subprocess.check_output(['git', 'show', '25c628e74b25ea13f02602bae0d1056cc5b190ae:' + p], cwd=root)
assert not subprocess.check_output(['git', 'diff', '--name-only', '--', 'tests/Riftbound.ConformanceTests'], cwd=root)
sql = load(root / 'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json')
oldsql = json.loads(subprocess.check_output(['git', 'show', '99e20b4f0640d7b32adbfb9e7dc0c7661b22d37a:tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'], cwd=root))
assert len(sql['cases']) == 55 and sql['cases'][:54] == oldsql['cases'] and sql['cases'][-1]['id'] == 'controller-damage-bonus'
pairs = load(w / 'original-all110-pairs-independent-exact-readback-v2.json')
assert pairs['status'].startswith('PASS_INDEPENDENT_CURRENT_ALL110') and pairs['originalPairs'] == 110 and pairs['seed'] == 424242
proof = {'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': 'CHECK_AND_EXACT_CASE_METHOD_PARITY_PASS', 'actualCases': 13304, 'actualMethods': 7516, 'passed': 13304, 'failed': 0, 'skipped': 0, 'oldCases': 13254, 'oldMethods': 7510, 'oldCasesPreserved': True, 'oldMethodsPreserved': True, 'oldOriginalCheckOutcomesRetainedNotRelabeled': dict(collections.Counter(t.get('outcome') for t in oldrows)), 'newCases': 50, 'newMethods': 6, 'newMethodNames': sorted(methods - oldmethods), 'frozenInputsUnchanged': True, 'sourceInputs': 3330, 'conformanceRuntimeFiles': 1419, 'nativeDebugRuntimeFilesStableNotCurrentNativeExecutionCertification': 23, 'onlyCheckTrx': {'path': str(current.relative_to(root)), 'sha256': sha(current)}, 'originalBaselineTrx': {'path': str(before.relative_to(root)), 'sha256': sha(before)}, 'allNineOriginalFullSourcesByteExactAgainstIndependentlyVerified25c': full, 'allOriginal143PublicFullMethods110Pairs11Decks424242AndAssertionsRetained': True, 'actual110OriginalHelperDirectionsExecutedSeparately': True, 'allOriginal54SqlIdentitiesAndOrderRetainedOnly55Appended': True, 'lockAtStart': start['lockAtStart'], 'lockAtStop': terminal['lockAtStop'], 'currentFixedFullVisibleAndPhysicalWindowsAndWholePrintingCertification': 'OPEN', 'noSecondCheck': True}
p = w / 'check-original-case-method-and-input-retention-v1.json'
assert not p.exists()
p.write_text(json.dumps(proof, ensure_ascii=False, indent=2))
print('PASS onlycheck13304/7516;old13254/7510 case multiset and methods retained;50/6 added;3330/1419/23 stable;143/110/11/424242 retained')
