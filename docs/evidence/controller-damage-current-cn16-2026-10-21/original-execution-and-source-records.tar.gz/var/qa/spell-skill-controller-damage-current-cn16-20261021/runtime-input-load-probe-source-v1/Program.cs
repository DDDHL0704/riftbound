using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using Riftbound.Engine;
using Riftbound.Contracts;
using Riftbound.CardCatalog;
Console.WriteLine(JsonSerializer.Serialize(new {baseDirectory=AppContext.BaseDirectory,actualRuleInputs=RuleInputIdentity.Current,hasCurrentSharedHelper=typeof(CoreRuleEngine).GetMethod("ApplySpellSkillDamageBonuses",BindingFlags.Static|BindingFlags.NonPublic) is not null,assemblies=new[]{typeof(CoreRuleEngine).Assembly,typeof(GameCommand).Assembly,typeof(OfficialCardCatalog).Assembly}.Select(a=>new{name=a.GetName().Name,path=a.Location,mvid=a.ManifestModule.ModuleVersionId,sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(a.Location))).ToLowerInvariant()})},new JsonSerializerOptions(JsonSerializerDefaults.Web){WriteIndented=true}));
