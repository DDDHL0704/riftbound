from pathlib import Path
import datetime,gzip,hashlib,json,os,shutil,subprocess
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
old=root/'var/qa/fixed708-early-native-20261021'
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
new=load(w/'native-app-inputs.json');boot=load(w/'current-native-headless-boot-verification.json')
previous=load(old/'native-app-inputs.json');downloads=load(old/'current-fixed-native-download-original-result-v1.json')
assert new['fixedCommit']=='99e20b4f0640d7b32adbfb9e7dc0c7661b22d37a' and boot['status']=='CURRENT_FIXED_DEFAULT_MAIN_HEADLESS_BOOT_PASS'
processes=subprocess.check_output(['ps','-axo','command='],text=True).splitlines()
targets=[]
for row in previous['apps']:
    p=Path(row['app']);assert p.parent==old and p.is_dir() and not p.is_symlink()
    assert not any(str(p)+'/Contents/MacOS/' in s for s in processes)
    assert all(sha(p/k)==v for k,v in previous['ciManagedAndPckPayloads'].items())
    subprocess.run(['codesign','--verify','--deep','--strict',str(p)],capture_output=True,check=True)
    targets.append(p)
for row in downloads['artifacts']:
    p=old/'native-current'/row['filename'];assert p.is_file() and p.stat().st_size==row['actualBytes'] and sha(p)==row['actualSha256'];targets.append(p)
assert len(targets)==4
records=[]
for target in targets:
    children=sorted(target.rglob('*')) if target.is_dir() else [target]
    for p in children:
        if p.is_symlink():records.append({'path':str(p.relative_to(root)),'type':'symlink','bytes':p.lstat().st_size,'target':os.readlink(p)})
        elif p.is_file():records.append({'path':str(p.relative_to(root)),'type':'file','bytes':p.stat().st_size,'sha256':sha(p)})
manifest=w/'superseded-fixed708-native-original-file-manifest-v1.json.gz'
manifest.write_bytes(gzip.compress(json.dumps({'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'originalFilesAndLinks':records},ensure_ascii=False,indent=2).encode(),mtime=0))
for target in targets:
    if target.is_dir():shutil.rmtree(target)
    else:target.unlink()
assert all(not p.exists() for p in targets)
for row in new['apps']:
    p=Path(row['app']);assert all(sha(p/k)==v for k,v in new['ciManagedAndPckPayloads'].items())
result={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ONLY_PREVIOUS_FIXED708_A_B_AND_TWO_INSTALLER_ARCHIVES_RETIRED_AFTER_NEW99E_USABILITY_AND_ALL373_PAYLOAD_VERIFICATION','oldCommit':previous['fixedCommit'],'currentCommit':new['fixedCommit'],'filesAndLinks':len(records),'logicalBytes':sum(r['bytes'] for r in records),'originalManifest':{'path':str(manifest.relative_to(root)),'sha256':sha(manifest)},'retiredPaths':[str(p.relative_to(root)) for p in targets],'onlyLatestPairAndOneArchivePerPlatformKept':[r['app'] for r in new['apps']]+[str(w/'native-current'/n) for n in ['mac-ci-artifact.zip','windows-ci-artifact.zip']],'allOldSourcesVerificationReceiptsExecutedHelpersAndDatabaseRetained':True,'rootOnlyCheckSourceAndRuntimeInputsUntouched':True,'physicalApfsReclaimNotInferred':True}
with (w/'superseded-fixed708-native-pair-and-two-archives-retirement-v1.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print('Retired superseded fixed708 A/B +two archives:',len(records),'files/links,',result['logicalBytes'],'logical bytes;only current usable99e pair/platform archives remain.')
