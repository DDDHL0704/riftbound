# coding: utf-8
"""Run exported default Main without a desktop or a checkout build."""
import datetime, hashlib, json, os, plistlib, subprocess
from pathlib import Path
os.umask(0o077)
n=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def lock():
    data=plistlib.loads(subprocess.check_output(['/usr/sbin/ioreg','-n','Root','-d','1','-a']))
    return {'atUtc':now(),'roots':[{'rootLocked':v.get('IOConsoleLocked'),'sessions':[u['CGSSessionScreenIsLocked'] for u in v.get('IOConsoleUsers',[]) if 'CGSSessionScreenIsLocked' in u]} for v in (data if isinstance(data,list) else [data])],'missingValuesRemainUnknown':True}

proof=json.loads((n/'native-app-inputs.json').read_text())
assert proof['fixedCommit']=='99e20b4f0640d7b32adbfb9e7dc0c7661b22d37a'
out=n/'current-native-headless-boot-verification.json'; assert not out.exists()
result={'atUtc':now(),'fixedCommit':proof['fixedCommit'],'fixedCiRun':39594660433,
        'lockAtStart':lock(),'records':[],'notVisibleControlsOrPairedGameAcceptance':True,'physicalWindows':'OPEN'}
try:
    for row in proof['apps']:
        app=Path(row['app']); label=row['label'];log=n/('current-native-default-headless-'+label+'.log')
        profile=n/('never-written-default-headless-'+label+'-session.json');assert not profile.exists()
        assert all(sha(app/k)==v for k,v in proof['ciManagedAndPckPayloads'].items())
        executable=app/'Contents/MacOS/符文战场'
        args=[str(executable),'--headless','--max-fps','60','--quit-after','120','--','--riftbound-ephemeral-session',
              '--riftbound-server=http://127.0.0.1:15847','--riftbound-session-file='+str(profile)]
        with log.open('x') as stream:
            process=subprocess.Popen(args,cwd='/tmp',stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
            try:code=process.wait(timeout=45)
            finally:
                if process.poll() is None:process.terminate();process.wait(timeout=10)
        raw=log.read_text()
        record={'label':label,'ownNativePid':process.pid,'returnCode':code,
                'defaultMainBootMarker':'[Riftbound] Client booted. Waiting for server authority.' in raw,
                'officialCatalogBootMarker':'[Riftbound] Official catalog loaded: 1035 cards.' in raw,
                'noGodotErrorOrUnhandledException':not any(x in raw for x in ['ERROR:','Unhandled exception','SCRIPT ERROR:']),
                'log':log.name,'logSha256':sha(log),'outsideCheckoutCwd':'/tmp',
                'exactArguments':args,'ephemeralNoProfileWritten':not profile.exists(),
                'all373OriginalCiManagedAndPckFilesStillExact':all(sha(app/k)==v for k,v in proof['ciManagedAndPckPayloads'].items())}
        subprocess.run(['codesign','--verify','--deep','--strict',str(app)],capture_output=True,check=True)
        record['deepStrictSignaturePass']=True;result['records'].append(record)
        assert code==0 and all(record[k] for k in ['defaultMainBootMarker','officialCatalogBootMarker',
            'noGodotErrorOrUnhandledException','ephemeralNoProfileWritten','all373OriginalCiManagedAndPckFilesStillExact'])
    result['status']='CURRENT_FIXED_DEFAULT_MAIN_HEADLESS_BOOT_PASS'
except BaseException as e:
    result.update(status='FAILED_OR_INTERRUPTED_PREFIX_RETAINED',errorType=type(e).__name__)
    raise
finally:
    result.update(finishedAtUtc=now(),lockAtEnd=lock());out.write_text(json.dumps(result,indent=2)+'\n')
print(result['status'],flush=True)
