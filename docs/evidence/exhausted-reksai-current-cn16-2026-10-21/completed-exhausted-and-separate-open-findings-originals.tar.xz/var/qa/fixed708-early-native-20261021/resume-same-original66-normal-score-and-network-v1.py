import ast,datetime,fcntl,gzip,hashlib,json,os,plistlib,resource,socket,subprocess,time,urllib.request
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
definition=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes=[n for n in ast.parse(definition.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}]
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(definition),'exec'),globals())
pub=load(w/'frozen-fixed708-native-composition-v1.json');first=load(w/'live-current-ci-main-owner-terminal-v2.json')
score=load(w/'fixed708-original-score-resume-frozen-v1.json');runtime=Path(pub['apiRuntimeRoot']);helpers=Path(pub['helperRuntimeRoot']);score_runtime=Path(score['runtimeRoot'])
room=first['room'];assert room==score['sameRoom'] and first['nativeAcceptedGameplayCommands']==3 and first['originalGatewayPrefixCommands']==63 and first['ownPostgresSmartStopped']
baseline=load(w/'actual-safe-native-main-v2/original275-audit58-native-seven-table-baseline-v2.json')
audit=baseline['auditRooms'];native=baseline['nativeRooms'];assert len(audit)==275 and len(native)==58
old_path=w/'actual-safe-native-main-v2/owner-final-current-ci-native-original-frame-v2.json.gz'
old=json.loads(gzip.decompress(old_path.read_bytes()));assert len(old['commands'])==66
field=next(k for k,c in old['authoritativeState']['cardObjects'].items() if c['cardNo']=='OGN·278/298')
destination='BATTLEFIELD:'+field
for label in ['a','b']:assert load(w/f'session-{label}.json')['roomId']==room
def stable():
    return all(sha(d/p)==h for d,files in [(runtime,pub['runtimeFiles']),(helpers,pub['helperRuntimeFiles']),(score_runtime,score['runtimeFiles']),(Path(pub['networkRuntimeRoot']),pub['networkRuntimeFiles'])] for p,h in files.items())
def export(name):
    target=w/'actual-safe-native-main-v2'/(name+'.json.gz');assert not target.exists()
    command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(helpers/'Riftbound.Api.deps.json'),'--runtimeconfig',str(helpers/'Riftbound.Api.runtimeconfig.json'),str(helpers/'FixedNativeFrameExport.dll'),room,str(target)]
    env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit;Options=-c default_transaction_read_only=on',DOTNET_DbgEnableMiniDump='0')
    metadata=json.loads(subprocess.check_output(command,cwd=helpers,env=env));assert metadata['actualRuleInputs']==pub['actualRuleInputs']
    frame=json.loads(gzip.decompress(target.read_bytes()));assert frame['isConsistent'] and frame['authoritativeState']['ruleInputs']==pub['actualRuleInputs']
    return target,frame
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
terminal=w/'current-original-score-resume-owner-terminal-v1.json';assert not terminal.exists()
proof={'status':'RUNNING_SAME_ORIGINAL66_CURRENT_FIXED708_SCORE_RESUMPTION','startedAtUtc':now(),'room':room,'fixedCommit':pub['fixedCommit'],'actualRuleInputs':pub['actualRuleInputs'],'originalFailureReceiptSha256':sha(w/'live-current-ci-main-owner-terminal-v2.json'),'original66CommandsAndSeedNeverResubmitted':True,'exactRecordedDestination':destination,'correctedOnlyScoringHarnessFieldLiteral':True,'lockAtStart':observe_lock()}
api=power=driver=None;started=False
try:
    assert stable() and subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
    with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
    power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid
    subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'same-original66-score-resume-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
    assert rooms('riftbound_acceptance')==audit and set(rooms('riftbound_here_native'))==set(native)|{room}
    assert digests('riftbound_acceptance',audit)==baseline['auditSevenTables'] and digests('riftbound_here_native',native)==baseline['nativeSevenTables']
    before_path,before=export('before-same-original66-score-resume-v1')
    assert before['commands']==old['commands'] and before['events']==old['events'] and before['authoritativeState']==old['authoritativeState'] and before['openingSeed']==old['openingSeed']
    env=dict(os.environ,ASPNETCORE_ENVIRONMENT='Production',ASPNETCORE_URLS='http://127.0.0.1:15847',ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit',DOTNET_DbgEnableMiniDump='0')
    env.pop('DOTNET_STARTUP_HOOKS',None)
    with (w/'same-original66-score-resume-api-v1.log').open('xb') as log:api=subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet',str(runtime/'Riftbound.Api.dll')],cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT)
    until=time.monotonic()+25
    while True:
        assert api.poll() is None and time.monotonic()<until
        try:
            with urllib.request.urlopen('http://127.0.0.1:15847/health',timeout=.5) as response:health=json.load(response)
            assert health['persistenceMode']=='postgres'
            assert set(subprocess.check_output(['/usr/sbin/lsof','-tiTCP:15847','-sTCP:LISTEN'],text=True).splitlines())=={str(api.pid)}
            break
        except OSError:time.sleep(.1)
    proof['ownedApiPid']=api.pid
    output=w/'actual-safe-normal-score-continuation-v2';assert not output.exists()
    command=['/Users/dinghaolin/.dotnet/dotnet',str(score_runtime/'Fixed708OriginalBandleTreeScoreV1.dll'),'http://127.0.0.1:15847',str(output),str(w),str(w/'actual-safe-native-prefix-v2/pending-original-native-prefix-receipt.json'),str(w/'actual-safe-native-main-v2/after-native-priority-pass-2-original-frame-v2.json.gz'),destination]
    proof['actualScoreWriterCommand']=command
    with (w/'actual-same-original66-normal-score-writer-v1.log').open('xb') as log:
        driver=subprocess.Popen(command,cwd=score_runtime,stdout=log,stderr=subprocess.STDOUT,env=env);proof['scoreWriterExitCode']=driver.wait(timeout=330)
    assert proof['scoreWriterExitCode']==0
    receipt=load(output/'normal-original-score-continuation-receipt.json');assert receipt['continuationCommands']==17 and receipt['winningScore']==8
    final_path,final=export('after-same-original66-current-ci-native-normal-score-final-v1')
    assert len(final['commands'])==83 and final['commands'][:66]==old['commands'] and final['events'][:len(old['events'])]==old['events']
    assert final['openingSeed']==old['openingSeed'] and final['replayInitialState']==old['replayInitialState']
    network_log=w/'actual-current-network-smoke-resumed-v1.log';network_before=rooms('riftbound_here_native')
    with network_log.open('xb') as log:
        driver=subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet',str(Path(pub['networkRuntimeRoot'])/'Riftbound.NativeNetworkSmoke.dll')],cwd=pub['networkRuntimeRoot'],stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,RIFTBOUND_SERVER_URL='http://127.0.0.1:15847',DOTNET_DbgEnableMiniDump='0'));assert driver.wait(timeout=90)==0
    text=network_log.read_text();wire=json.loads(next(x[len('NATIVE_ROOM_IDENTITY_EVIDENCE '):] for x in text.splitlines() if x.startswith('NATIVE_ROOM_IDENTITY_EVIDENCE ')))
    assert wire['rejectedActions']==15 and wire['leakedPrivateMessages']==0 and wire['validReconnectTokenWasSupplied']
    assert 'Native network recovery passed: socket loss, authenticated room restore, fresh snapshot, rejected-token guard.' in text
    added=set(rooms('riftbound_here_native'))-set(network_before);assert len(added)==1 and next(iter(added)).startswith('NETWORK-')
    proof.update(totalCommands=83,events=len(final['events']),normalGatewayCommands=17,networkOriginalEvidence=wire,separateNewNetworkRoom=next(iter(added)))
    ready={k:v for k,v in first.items() if k not in ['error','errorType']}
    ready.update(status='CURRENT_ORIGINAL66_RESUMED_NORMAL_SCORE_NETWORK_READY_FOR_INDEPENDENT_HISTORY',actualOriginalLegalBandleTreeDestination=destination,totalCommands=83,events=len(final['events']),winningScore=8,losingScore=0,finalTurn=final['authoritativeState']['turnNumber'],normalGatewayCommands=17,apiPid=api.pid,rawFinalFrame=str(final_path),originalScoreIntentFile=str(output/'all-original-normal-score-continuation-intents.json'),actualDatabase='riftbound_here_native',sameFirst66PreservedAndOnly17NewGatewayCommands=True)
    (w/'live-current-ci-main-ready-v2.json').write_text(json.dumps(ready,indent=2))
    print('SAME_ORIGINAL66_RESUMED83_NORMAL_SCORE_NETWORK_PASS_WAITING_INDEPENDENT_REPLAY',flush=True)
    stop=w/'live-current-ci-main-stop-v2.json';until=time.monotonic()+900
    while not stop.exists():assert api.poll() is None and time.monotonic()<until;time.sleep(.2)
    completion=load(stop);assert completion['independentReadOnlyHistoryAndFullReplayPass'] and completion['room']==room
    proof.update(status='PASS_SAME_ORIGINAL66_PLUS17_FIXED708_NATIVE3_COLD_RECONNECT_NORMAL_SCORE_NETWORK_INDEPENDENT_ALL_HISTORY_REPLAY',independentReadback=completion)
except BaseException as e:
    proof.update(status='FAILED_SAME_ORIGINAL66_RESUMPTION_ORIGINALS_AND_ALL_ACCEPTED_HISTORY_RETAINED',errorType=type(e).__name__,error=str(e));raise
finally:
    if driver is not None and driver.poll() is None:driver.terminate();driver.wait(timeout=20)
    if started:
        try:export('owner-final-same-original66-resumed-v1')
        except BaseException as e:proof['finalFrameExportErrorType']=type(e).__name__
    if api is not None:
        if api.poll() is None:api.terminate();api.wait(timeout=25)
        proof['ownApiStopped']=api.poll() is not None
    if started:
        proof['allOriginal275AuditSevenTablesExactAtStop']=digests('riftbound_acceptance',audit)==baseline['auditSevenTables']
        proof['allOriginal58NativeSevenTablesExactAtStop']=digests('riftbound_here_native',native)==baseline['nativeSevenTables']
        proof['actualAuditRoomsAtStop']=rooms('riftbound_acceptance');proof['actualNativeRoomsAtStop']=rooms('riftbound_here_native')
        proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
    if power is not None and power.poll() is None:power.terminate();power.wait(timeout=10)
    proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),allFrozenInputsStable=stable(),boundIdleAssertionEnded=power is not None and power.poll() is not None)
    terminal.write_text(json.dumps(proof,indent=2));fcntl.flock(guard,fcntl.LOCK_UN)
assert proof['allOriginal275AuditSevenTablesExactAtStop'] and proof['allOriginal58NativeSevenTablesExactAtStop'] and proof['ownPostgresSmartStopped'] and proof['allFrozenInputsStable']
