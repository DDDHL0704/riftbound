from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
old_work=root/'var/qa/void-gate-current-erratum-20261021'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
def files(folder):return {str(p.relative_to(folder)):sha(p) for p in sorted(folder.rglob('*')) if p.is_file()}
def write(p,j):
    with p.open('x') as f:json.dump(j,f,ensure_ascii=False,indent=2);f.write('\n')
fixed='708a3558040f9acd4c66122a00db8ca085f460cf'
api=load(w/'fixed708-api-gameplay-closure-frozen-inputs-v1.json');runtime=Path(api['runtimeRoot'])
assert api['fixedCommit']==fixed and files(runtime)==api['runtimeFiles']
assert all(sha(root/p)==h for p,h in api['allDeclaredApiGameplaySourceInputsExactFixedCommit'].items())
old=load(old_work/'frozen-fixed2b83-native-composition-v1.json')
old_helpers=Path(old['helperRuntimeRoot']);old_network=Path(old['networkRuntimeRoot'])
assert files(old_helpers)==old['helperRuntimeFiles'] and files(old_network)==old['networkRuntimeFiles']
assert all(sha(root/p)==h for p,h in old['networkSourceHashes'].items())
helpers=w/'fixed708-native-helpers-runtime-v1';network=w/'fixed708-native-network-net8-runtime-v1'
assert not helpers.exists() and not network.exists()
subprocess.run(['cp','-cR',str(old_helpers),str(helpers)],check=True)
for p in api['runtimeFiles']:
    target=helpers/p;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(runtime/p,target)
subprocess.run(['cp','-cR',str(old_network),str(network)],check=True)
assert files(network)==old['networkRuntimeFiles']
reader_source=w/'fixed708-native-history-reader-source-v1';reader_source.mkdir()
original=old_work/'fixed2b83-native-history-reader-source-v1'
t=(original/'Program.cs').read_text()
t=t.replace('2b83ed2e6243f9e73cd92269f549867f02ea98ea',fixed).replace('fixed2b83','fixed708').replace('FIXED2B83','FIXED708')
before='Check(args.Length==2,"Exact original evidence and unused output required.");'
assert t.count(before)==1
t=t.replace(before,'if(args.SequenceEqual(new[]{"--identity-only"})){Console.WriteLine(JsonSerializer.Serialize(RuleInputIdentity.Current,new JsonSerializerOptions(JsonSerializerDefaults.Web)));return;}\n'+before)
(reader_source/'Program.cs').write_text(t)
project=(original/'probe.csproj').read_text().replace('Fixed2b83NativeHistoryReaderV1','Fixed708NativeHistoryReaderV1').replace('../fixed2b83-clean-api-runtime-v1',str(runtime))
assert '../fixed2b83-clean-api-runtime-v1' not in project and str(runtime) in project
(reader_source/'probe.csproj').write_text(project)
with (w/'build-fixed708-native-history-reader-v1.log').open('xb') as log:
    subprocess.run(['/Users/dinghaolin/.dotnet/dotnet','build',str(reader_source/'probe.csproj'),'--configuration','Release','--nologo'],cwd=reader_source,stdout=log,stderr=subprocess.STDOUT,check=True)
reader_runtime=w/'fixed708-native-history-reader-runtime-v1';shutil.copytree(runtime,reader_runtime)
assembly='Fixed708NativeHistoryReaderV1'
for suffix in ['.dll','.pdb']:shutil.copy2(reader_source/'bin/Release/net10.0'/(assembly+suffix),reader_runtime/(assembly+suffix))
command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(reader_runtime/'Riftbound.Api.deps.json'),'--runtimeconfig',str(reader_runtime/'Riftbound.Api.runtimeconfig.json'),str(reader_runtime/(assembly+'.dll')),'--identity-only']
identity=json.loads(subprocess.check_output(command,cwd=reader_runtime,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0')))
assert identity['authoritySha256']=='70ccda5893a1b8b56cdceadee35e084b1e3f5b297ef64e1ce7d0cbeb141ce2d4'
assert identity['catalogSha256']=='a940e5f8bcd5e1ead68a85c7f983e530333d6179a4b8429ed1f8fe2ee20b8397'
write(w/'fixed708-api-actual-rule-inputs-v1.json',identity)
write(w/'fixed708-native-history-reader-frozen-v1.json',{'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runtimeRoot':str(reader_runtime),'runtimeFiles':files(reader_runtime),'sourceHashes':{str(p.relative_to(w)):sha(p) for p in reader_source.iterdir() if p.is_file()},'assembly':assembly,'exactActualApiRuleInputs':identity})
write(w/'fixed708-native-helper-and-network-frozen-v1.json',{'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fixedCommit':fixed,'apiRuntimeRoot':str(runtime),'runtimeFiles':api['runtimeFiles'],'apiBuildInputsManifest':str(w/'fixed708-api-gameplay-closure-frozen-inputs-v1.json'),'apiBuildInputsManifestSha256':sha(w/'fixed708-api-gameplay-closure-frozen-inputs-v1.json'),'actualRuleInputs':identity,'helperRuntimeRoot':str(helpers),'helperRuntimeFiles':files(helpers),'networkRuntimeRoot':str(network),'networkRuntimeFiles':files(network),'networkSourceHashes':old['networkSourceHashes'],'networkDriverDependencyFramework':'net8.0','rootConformanceAndNativeCheckPayloadsNotWritten':True,'apiAndHelpersNotClaimedCiExported':True,'apiCurrentGameplayClosureExactFixed708WithUnrelatedSql53ChangesDeclared':True,'oldGamesNotMigrated':True})
assert files(runtime)==api['runtimeFiles'] and files(old_helpers)==old['helperRuntimeFiles'] and files(old_network)==old['networkRuntimeFiles']
print('Fixed708 API/native helpers and independent reader frozen;separate net8 network exact;actual API identity',identity['identitySha256'],'runtime files',len(files(runtime)),len(files(helpers)),len(files(network)),len(files(reader_runtime)))
