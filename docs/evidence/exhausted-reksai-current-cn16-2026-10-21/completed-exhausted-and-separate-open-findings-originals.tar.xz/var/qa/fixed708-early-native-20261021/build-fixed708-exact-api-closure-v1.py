from pathlib import Path
import datetime,hashlib,io,json,subprocess,tarfile
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
fixed='708a3558040f9acd4c66122a00db8ca085f460cf'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=['src/Riftbound.Api','src/Riftbound.Engine','src/Riftbound.CardCatalog','src/Riftbound.Contracts','src/Riftbound.Persistence','data/official/card-catalog.zh-CN.json','data/official/rule-input-scope.json','data/official/armaments.json','Directory.Build.props','global.json']
tracked=set(subprocess.check_output(['git','ls-tree','-r','--name-only',fixed]).decode().splitlines())
paths=[p for p in paths if p in tracked or any(x.startswith(p+'/') for x in tracked)]
archive=subprocess.check_output(['git','archive',fixed,*paths])
records={}
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:') as tar:
    for member in tar.getmembers():
        if member.isfile():
            raw=tar.extractfile(member).read()
            assert (root/member.name).read_bytes()==raw,member.name
            records[member.name]=hashlib.sha256(raw).hexdigest()
runtime=w/'fixed708-api-gameplay-closure-runtime-v1';assert not runtime.exists()
with (w/'build-fixed708-exact-api-closure-v1.log').open('xb') as log:
    subprocess.run(['/Users/dinghaolin/.dotnet/dotnet','publish','src/Riftbound.Api/Riftbound.Api.csproj','--configuration','Release','--nologo','--output',str(runtime)],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
assert all(sha(root/p)==h for p,h in records.items())
files={str(p.relative_to(runtime)):sha(p) for p in runtime.rglob('*') if p.is_file()}
with (w/'fixed708-api-gameplay-closure-frozen-inputs-v1.json').open('x') as f:json.dump({'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fixedCommit':fixed,'runtimeRoot':str(runtime),'runtimeFiles':files,'allDeclaredApiGameplaySourceInputsExactFixedCommit':records,'unrelatedCurrentUncommittedSql53VerificationChangesDeclared':True,'notClaimedEntireWorkingTreeClean':True,'notCiExportedApiBinary':True,'ownApiNotStarted':True},f,indent=2);f.write('\n')
print('Fixed708 API gameplay source closure exact:',len(records),'source files;',len(files),'runtime files;unrelated SQL53 verification edits explicitly separate.')
