from pathlib import Path
import copy,datetime,gzip,hashlib,json,re,tarfile
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
n=root/'var/qa/fixed708-early-native-20261021';t=root/'var/qa/teemo-counted-damage-current-cn16-20261021'
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def pin(p,role=None):
    r={'path':str(p.relative_to(root)),'sha256':sha(p)}
    if role:r['role']=role
    return r
def write(p,j):
    with p.open('x') as f:json.dump(j,f,ensure_ascii=False,indent=2);f.write('\n')
check=load(w/'check-original-case-method-and-input-retention-v1.json')
sql=load(w/'actual-current-integrated-four-exhausted-sql-owner-terminal-v1.json')
source=load(w/'current-integrated-exhausted-exact-source-scope-review-v1.json')
finding=load(t/'current-teemo-exact-provenance-and-two-open-dispositions-v1.json')
native=load(n/'current-fixed708-ci-native-combined-subscope-readback-v1.json')
prior_full=load(n/'ci-2b83-entire-full-independent-verification-v1.json')
frozen=load(w/'current-integrated-exhausted-sql-frozen-inputs-v1.json')
assert check['status']=='CHECK_AND_EXACT_CASE_METHOD_PARITY_PASS' and check['actualCases']==check['passed']==13238 and check['actualMethods']==7508 and check['failed']==check['skipped']==0
assert sql['commands']==32 and sql['events']==88 and sql['ownPostgresSmartStopped'] and sql['allOriginal271AuditSevenTablesExactAtStop'] and sql['allOriginal58NativeSevenTablesExactAtStop']
assert native['totalCommands']==83 and native['events']==574 and native['ownApiAndPostgresStopped'] and native['actualRuleInputs']==sql['actualRuleInputs']
assert prior_full['actualCases']==13380 and prior_full['actualMethods']==7646 and prior_full['sql']['caseCount']==51 and len(prior_full['jobs'])==11
assert all(sha(root/p)==h for p,h in frozen['sourceInputHashes'].items())
mp=root/'docs/audit/current-manifest.json';manifest=load(mp);rp=root/manifest['inputs']['reviews']['path'];reviews=load(rp)
prior=w/'prior-coherent-publication-governance-v1'
for p in [mp,rp,root/'docs/PROJECT_STATUS.md']:assert gzip.decompress((prior/(p.name+'.gz')).read_bytes())==p.read_bytes()
assert len(reviews['reviews'])==155 and len(manifest['reviewContexts'])==70 and len(manifest['acceptanceGates'])==245 and len(manifest['laterSourceDeltas'])==7
old_manifest=copy.deepcopy(manifest);old_reviews=copy.deepcopy(reviews)
ev=root/'docs/evidence/exhausted-reksai-current-cn16-2026-10-21';ev.mkdir(exist_ok=False)
standalone={
 'check-original-case-method-and-input-retention.json':w/'check-original-case-method-and-input-retention-v1.json',
 'current-exact-source-scope-review.json':w/'current-integrated-exhausted-exact-source-scope-review-v1.json',
 'current-root-integrated-source-transfer.json':w/'current-root-integration-exact-source-transfer-v1.json',
 'real-integrated-four-sql-terminal.json':w/'actual-current-integrated-four-exhausted-sql-owner-terminal-v1.json',
 'independent-all-history-and-original-replay.json':w/'independent-current-integrated-four-exhausted-all-history-v1.json',
 'preceding-fixed708-headless-ci-native-subscope.json':n/'current-fixed708-ci-native-combined-subscope-readback-v1.json',
 'prior2b83-full-independent.json':n/'ci-2b83-entire-full-independent-verification-v1.json',
 'prior2b83-terminal-hash-comparison.json':n/'ci-2b83-vs-64678-original-terminal-hash-comparison-v1.json',
 'completed2b83-extraction-retirement.json':n/'ci-2b83-completed-duplicate-extraction-retirement-v1.json',
 'latest-only-native-retirement.json':n/'superseded-fixed2b83-native-pair-and-two-archives-retirement-v1.json',
 'completed-helper-staging-retirement.json':n/'completed-current-three-helper-generated-staging-retirement-v1.json',
 'separate-open-teemo-source-and-positive-damage-findings.json':t/'current-teemo-exact-provenance-and-two-open-dispositions-v1.json'
}
for name,p in standalone.items():(ev/name).write_bytes(p.read_bytes())
focus=load(w/'focus-current-root-exhausted-and-original-adjacent-v1/summary.json')
assert focus['status']=='PASSED' and focus['total']==54
plan=load(w/'focus-current-root-exhausted-and-original-adjacent-v1/plan.json')
methods=sorted({m for s in plan['shards'] for m in s['methods']});assert len(methods)==27
write(ev/'focus-executed-distinct-scope.json',{'atUtc':now(),'status':'ACTUAL_FOCUS54_27_AND_CURRENT_INTEGRATED_SQL32_88_PASS','newMethodNames':[],'newConformanceCases':0,'newConformanceMethods':0,'distinctCases':54,'distinctMethods':27,'methodNames':methods,'oneOriginalCandlelitNormalScoreFullReplayIncluded':True,'allOriginalConformanceSourcesUnchanged':True,'wholePrintingCertified':False})
members=[];excluded=[]
for base in [w,n,t]:
    for p in sorted(base.rglob('*')):
        if not p.is_file():continue
        parts=p.relative_to(base).parts
        if any(x.endswith('.app') for x in parts) or {'bin','obj'}&set(parts) or any('-runtime-' in x or '-identity-probe-' in x for x in parts[:-1]):continue
        if 'native-current' in parts and p.suffix=='.zip':continue
        if p.name=='publish-current-exhausted-owner-v1.log':
            excluded.append({'path':str(p.relative_to(root)),'reason':'Own running publication stdout retained completely after execution'});continue
        if p.name.startswith('session-') or p.suffix=='.env':
            excluded.append({'path':str(p.relative_to(root)),'reason':'Private operational profile retained locally'});continue
        raw=p.read_bytes()
        try:plain=gzip.decompress(raw) if p.suffix=='.gz' else raw
        except (OSError,EOFError):plain=raw
        if re.search(rb'"(?:playerKey|reconnectToken|sessionToken|password|accessToken)"\s*:\s*"[^"\s]+"',plain,re.I):
            excluded.append({'path':str(p.relative_to(root)),'bytes':len(raw),'sha256':sha(p),'reason':'Credential-bearing original retained locally'});continue
        members.append(p)
faq=root/'var/qa/nocturne-optional-current-cn16-20261021/bone-current-primary-pages-v1/judge-faq-p20.png';members.append(faq)
assert len(members)==len(set(members))
rows=[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in members]
archive=ev/'completed-exhausted-and-separate-open-findings-originals.tar.xz'
with tarfile.open(archive,'x:xz',preset=6) as tar:
    for p in members:tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
with tarfile.open(archive,'r:xz') as tar:
    assert {p.name for p in tar.getmembers()}=={r['path'] for r in rows}
    for row in rows:
        raw=tar.extractfile(row['path']).read();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
write(ev/'archive-map.json',{'atUtc':now(),'archive':pin(archive),'members':rows,'allMemberBytesHashesAndClosedSetVerified':True,'privateOperationalAndRunningPublicationExclusionsRetainedLocally':excluded,'applicationsInstallersAndActualFrozenRuntimesRetainedLocallyNotDuplicated':True,'separateTeemoCounterexamplesNotClaimedFixedOrSemanticallyCertified':True})
implementation=[pin(root/p,'implementation') for p in ['src/Riftbound.Engine/CoreRuleEngine.LegendConquest.cs','src/Riftbound.Engine/CoreRuleEngine.TriggerCosts.cs','src/Riftbound.Engine/CoreRuleEngine.Insight.cs','src/Riftbound.Engine/CoreRuleEngine.DeckObservation.cs','src/Riftbound.Engine/MatchRecovery.cs','src/Riftbound.Engine/CoreRuleEngine.cs','data/official/card-catalog.zh-CN.json']]
verification=[pin(root/p,'verification-source') for p in ['tests/Riftbound.PostgresAcceptance/ExhaustedLegendConfirmationSqlAcceptance.cs','tests/Riftbound.PostgresAcceptance/Program.cs','tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json','scripts/tests/test_sql_ci_gate.py','tests/Riftbound.ConformanceTests/OfficialLegendDeckPlayTests.cs']]
sm={'atUtc':now(),'status':'BOUNDED_EXHAUSTED_REKSAI_FOUR_CURRENT_INTEGRATED_SQL_BRANCHES_AND_TWO_SEPARATE_OPEN_TEEMO_FINDINGS_CHECK_PASS_NEW_FIXED_FULL_PRODUCT_OPEN','region':'CN','language':'zh-CN','observedAsOf':'2026-10-21','adoptedCoreEffectiveDate':'2026-10-16','baseCommit':frozen['parentCommit'],'implementationIncludesDeclaredUncommittedSqlVerificationChanges':True,'gameplayInputsUnchangedFromFixed708':True,'exactCurrentSourceReview':source,'separateOpenTeemoSourceAndDamageReview':pin(ev/'separate-open-teemo-source-and-positive-damage-findings.json'),'actualRuleInputs':sql['actualRuleInputs'],'implementation':implementation,'verificationSources':verification,'allOriginal52SqlCasesAndOrderRetainedOnly53rdAppended':'exhausted-legend-confirmation','allOriginal155ReviewsAnd70CompleteContextsRetained':True,'zeroExistingImplementationBindingRefreshesNeeded':True,'onlyCheckActualOutcome':{'cases':13238,'methods':7508,'passed':13238,'failed':0,'skipped':0},'precedingFixed708Native83AndCurrentIntegratedSqlActualIdentityMeasuredEqual':True,'newFixedN35FullAndAllSourceSemanticCertificationVisiblePhysicalWindows':'OPEN','archive':pin(archive),'wholePrintingCertified':False,'noOldDevelopmentMatchMigration':True}
write(ev/'source-manifest.json',sm);sp=pin(ev/'source-manifest.json','source-manifest')
identity='exhausted-reksai-current-cn16-2026-10-21';assert identity not in manifest['reviewContexts']
reviews['reviews'].append({'id':identity,'scope':'Only two exact exhausted Reksai printings in both original confirmation orders, independent Candlelit private Insight and source/identity/cold replay; separately record two OPEN current Teemo source-adoption and positive-count damage gaps without implementation changes.','subjects':source['subjectPrintings']+finding['subjectPrintings']+[finding['supportingField']],'ruleRecords':source['ruleRecords'],'pendingRuleRecords':finding['ruleRecords'],'status':'BOUNDED_INTEGRATED_EXHAUSTED4_SQL32_88_CHECK13238PASS_TWO_SEPARATE_TEEMO_SOURCE_DAMAGE_GAPS_OPEN_FULL_PRODUCT_OPEN','sourceManifest':sp,'auditDocument':'docs/EXHAUSTED_REKSAI_CURRENT_CN16_SQL_AUDIT_2026-10-21.md','validation':{'newConformanceCases':0,'newConformanceMethods':0,'distinctFocusCases':54,'distinctFocusMethods':27,'checkCases':13238,'checkMethods':7508,'checkPassed':13238,'checkFailed':0,'sqlCommands':32,'sqlEvents':88,'sqlColdRecoveries':32,'allOriginal52SqlCasesAnd143FullMethodsRetained':True,'wholeCardCertification':False},'exclusions':source['exclusions']+['Both separate Teemo catalog-adoption and positive counted-damage gaps remain unimplemented; zero-count controls already match, broader count/zero/prevention semantics OPEN']})
branches=[{**b,'state':'RECORDED','sourceManifest':sp,'semanticReview':{'state':'BOUNDED_CURRENT_SOURCE_BRANCH_REVIEW','wholeClauseOrPrintingCertified':False},'implementation':{'state':'EXISTING_SHARED_CONFIRMATION_AND_INSIGHT_NO_GAMEPLAY_CHANGE'},'testExecution':{'state':'ACTUAL_CURRENT_FOCUS_REAL_SQL_COLD_DEDUP_INDEPENDENT_ALL_HISTORY_ORIGINAL_REPLAY_AND_FORGERY_PASS'},'fixedCommitCi':{'state':'PENDING_NEW_FIXED_FULL'},'productAcceptance':{'state':'OPEN'},'decision':{'state':'OPEN','reason':'Bounded four-branch evidence does not close new fixed full, all semantic branches or final product acceptance.'},'wholePrintingCertified':False,'existingAcceptanceGateDependencies':['DECK_OBSERVATION_FAMILY_ALL_APPLICABLE_CONSUMERS','FIXED_CURRENT_CANDIDATE_FULL','USER_WINDOWS_RUNTIME']} for b in source['boundedBehaviorBranches']]
for b in finding['sourceBranchDefinitions']:
    branches.append({**b,'state':'OPEN','sourceManifest':sp,'findingEvidence':pin(ev/'separate-open-teemo-source-and-positive-damage-findings.json'),'issue':finding['issue'],'semanticReview':{'state':'EXACT_CURRENT_SOURCE_ADOPTION_GAP_OR_POSITIVE_DAMAGE_COUNTEREXAMPLE_CONFIRMED_NOT_FIXED'},'implementation':{'state':'OPEN_UNCHANGED_CURRENT_GAMEPLAY'},'testExecution':{'state':'SOURCE_EVIDENCE_AND_EIGHT_ACTUAL_COMMAND_COUNTEREXAMPLES_NOT_IMPLEMENTATION_PASS'},'fixedCommitCi':{'state':'OPEN'},'productAcceptance':{'state':'OPEN'},'decision':{'state':'OPEN','reason':'Four exact runtime text gaps and four positive-count missing bonuses require separate fixes; four zero-count controls already match. No current branch certification.'},'wholePrintingCertified':False})
manifest['reviewContexts'][identity]={'evidenceCommit':frozen['parentCommit'],'currentImplementationCommit':frozen['parentCommit'],'currentImplementationIncludesUncommittedChanges':True,'ciState':'PENDING','ciReceipts':[],'region':'CN','language':'zh-CN','applicableAsOf':'2026-10-21','adoptedCoreEffectiveDate':'2026-10-16','sourceManifest':sp,'implementation':implementation,'verificationSources':verification,'evidence':[pin(ev/'focus-executed-distinct-scope.json','focus'),pin(ev/'check-original-case-method-and-input-retention.json','check'),pin(ev/'real-integrated-four-sql-terminal.json','sql'),pin(ev/'independent-all-history-and-original-replay.json','independent-sql')],'branches':branches}
deck=next(g for g in manifest['acceptanceGates'] if g['id']=='DECK_OBSERVATION_FAMILY');deck['currentExhaustedReksaiFourIntegratedSqlBranches']=sp
gaps=next(g for g in manifest['acceptanceGates'] if g['id']=='SOURCE_GAPS_AND_EFFECTIVE_DELTAS');gaps['currentSupportingTeemoTwoSeparateOpenSourceDamageFindings']=pin(ev/'separate-open-teemo-source-and-positive-damage-findings.json')
manifest['currentExhaustedReksaiFourIntegratedSqlInputChange']=sp
manifest['currentSupportingTeemoOpenSourceAndCountedDamageFindings']=pin(ev/'separate-open-teemo-source-and-positive-damage-findings.json')
manifest['precedingFixed2b83ActualCompleteFullCiReadback']=pin(ev/'prior2b83-full-independent.json','prior-fixed-full')
manifest['precedingFixed708BoundedHeadlessCiNativeReadback']=pin(ev/'preceding-fixed708-headless-ci-native-subscope.json','preceding-fixed-headless-native-subscope')
assert reviews['reviews'][:155]==old_reviews['reviews']
assert all(manifest['reviewContexts'][k]==v for k,v in old_manifest['reviewContexts'].items())
for before,after in zip(old_manifest['acceptanceGates'],manifest['acceptanceGates']):
    assert all(after[k]==v for k,v in before.items())
    if before['id'] not in {'DECK_OBSERVATION_FAMILY','SOURCE_GAPS_AND_EFFECTIVE_DELTAS'}:assert before==after
assert all(manifest[k]==old_manifest[k] for k in ['certificationScope','laterSourceDeltas','cardCoverageManifest','officialNewsObligations'])
rp.write_text(json.dumps(reviews,ensure_ascii=False,indent=2)+'\n');manifest['inputs']['reviews']['sha256']=sha(rp);mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
check_prose='本批唯一一次check实际13,238例/7,508方法全部通过，零失败/跳过；原13,238例名称/次数多重集合与7,508方法完全相同，没有新增或删除Conformance方法。前版自身记录的一个旧来源期望失败不回写为通过；本批运行覆盖已校准的最终验证输入。3,326源文件/模式、1,419 Conformance及23原生载荷全程不变，无第二check。最终固定full仍须覆盖第53个SQL身份及全部原143完整方法/110配对。'
native_prose='固定708a3558的实际CI双端默认入口/每端373托管PCK字节/签名和两平台包SHA256/大小/内外ZIP CRC已核验。当前API249份游戏来源与该Git固定候选逐字节一致，未提交的SQL53验证变动明确独立；本地API并非CI导出二进制。实测API与本批SQL总身份同为7c999c7d…，未来新提交构建身份不假设相等。\n\n普通局63条网关开局、3条实际CI原生交互控制器提交后，续行助手错误限定OGN277战场而停止。本局实际OGN278原件和当前API全字段再次核对不变；保留全部66条原动作/411事件、原随机种子/初态及原失败，仅校准助手的精确战场卡号和断言说明。API/库从原检查点恢复，只追加17条正常得分网关动作，最终83命令574事件、第53回合8:0、一征服七据守、非投降或耗尽。\n\n原两同进程实际CI客户端已在API冷重启后重新认证和恢复；五个原生进程均0退出、PTY日志完整。独立只读核对83个权威历史、双方162快照和162提示的所有字段/null/省略、原始意图/提示tick及完整顺序动作/事件/状态回放，生产完整恢复帧验证也通过；网络15拒绝/零泄露、有效token/断线恢复通过。原275审计/58原生七表不变，新普通及网络局保留至60原生；API/库正常停止。无窗口运行不称可见控件或Windows实机，原等待助手失败不被改写。\n\n前固定2b83ed2e/CI39549071591实际11项success，九原产物大小/SHA256/ZIP CRC及独立SQL门禁核实13,380例/7,646方法、143原完整方法/110配对/十一牌组/424242、51SQL全部输出与网络15/0。原64678的13,379/7,645全留，仅增1例/1方法；110实际新终态哈希另记，旧值不改。本批固定新full和708整个full终态继续独立核验。'
governance='156限定审查、71上下文、245门禁、七来源增量；原155审查和70完整上下文原样，零当前实现绑定刷新。243其他门禁原值不变，观察族与来源门禁仅追加本批限定观察/独立OPEN缺口，全部旧字段和状态保留。原16969义务身份全部保留，新增四个限定SQL行为及两个独立OPEN提莫来源/实现缺口至16975，不提升整卡、条款或全量认证。'
draft=(w/'integrated-exhausted-audit-draft-v1.md').read_text().replace('{{SOLE_CHECK_RESULT}}',check_prose).replace('{{FIXED708_NATIVE_RESULT}}',native_prose).replace('{{GOVERNANCE_RESULT}}',governance)
extra='\n## 辅助来源发现：提莫两项独立OPEN义务\n\n四个提莫精确印次的当前官网非空errata与起源勘误物理第9页明确新文本一致，运行目录cardEffect仍匹配明确旧文本。全部原API键/null和PDF哈希不变，登记现存来源采用缺口，未静默改目录。当前行为注册已经采用防守时确认，目录差异不自动证明错误待命出牌触发。\n\n独立冻结7c运行件复用只读原Conformance初态构造器，经真实移动、防守者目标选择和两次优先权命令执行八场32动作。每印次展示一张印有待命的卡牌时，对虚空之门目标实际仅1点、来源要求2点；零张的四个对照正确没有伤害行动。共享正数计数路径绕过本地伤害加成已由原始状态/事件确认；多计数分段、一般求值零、防止/替换及其他消费者仍OPEN。反例只在var冻结运行，不修改本批3326根输入或真实库，不称修复通过；见#81原始补充讨论及本批独立finding原件。后续同族实现先核对当前完整CI终态并闭合失败。\n'
draft=draft.replace('\n## 固定候选原生证据及治理\n',extra+'\n## 固定候选原生证据及治理\n')
assert '{{' not in draft
doc=root/'docs/EXHAUSTED_REKSAI_CURRENT_CN16_SQL_AUDIT_2026-10-21.md';assert not doc.exists();doc.write_text(draft)
status=root/'docs/PROJECT_STATUS.md';previous=status.read_text();prefix='# 当前项目状态\n\n';assert previous.startswith(prefix)
lead='2026-10-21 本批：[已休眠雷克塞两印次/两顺序常驻SQL](EXHAUSTED_REKSAI_CURRENT_CN16_SQL_AUDIT_2026-10-21.md)。CN/zh-CN、核心10-16生效，官网三行/两主PDF不变、整页41/85及FAQ20实看；游戏/目录/Conformance/原生源码不改，原52SQL身份/顺序/类全留，只加第53项四分支。真实32命令88事件32冷恢复、32直接/16写入结构拒绝，独立32历史/64快照/64提示/全原回放及16结构拒绝通过，原271审计58原生七表不变、四新局留至275，库正常停止。54/27含原完整正常胜利回放、74工具通过；唯一check13238/7508全过、原精确用例多重集合/方法/9完整源码/143/110/11/424242与断言保留，3326源/模式、1419Conformance、23原生载荷稳定，无第二check。\n\n固定708实际CI双端63网关+3原生+17续行，83命令574事件、第53回合8:0；原两同进程冷重连、五进程0退出，独立83历史/162私有快照/162提示与全原回放、网络15/0通过。旧助手错误限定277在66动作后停止，原失败/原66历史/种子留存，仅校准实际278来源后同局续17条，未重提动作。原275审计58原生七表不变、留至60原生，服务正常停止；实际API249游戏来源等于固定708且身份与本批SQL同7c，未提交SQL53变动独立，不称CI导出API/可见/Windows或未来新构建身份相等。\n\n前2b83完整CI39549071591实际11项success，九原产物独立13380/7646、原143/110/11/424242、51SQL及网络15/0；64678原13379/7645全留，仅+1/1，110新实际终态哈希另记。当前708整次full及本批新固定full仍独立待核。辅助提莫四印次当前勘误采用缺口和正数计数漏加虚空之门伤害已独立复现：八场32动作、四正数1应2、四零数正确无伤害行动；两项OPEN另列，未混改当前实现或宣称修复。\n\n156限定审查71上下文245门禁7增量，原155审查/70完整上下文原样，243其他门禁原值/两个门禁全部旧字段和OPEN状态保留；16969原义务全留加四限定行为及两OPEN缺口至16975。全来源宇宙/日期/缺口不减，语义false。仅最新708A/B和每平台一包，退役旧945969799逻辑字节、446文件6816202重复解压及助手6目录91文件2231102字节；必要来源/执行载荷/失败/原库保留，不推定物理回收。Goal active / NOT READY。\n\n以下原批次按原范围与当时终态保留。\n\n'
status.write_text(prefix+lead+previous[len(prefix):])
write(ev/'publication-original-obligation-retention.json',{'atUtc':now(),'status':'BOUNDED_INTEGRATED_EXHAUSTED4_AND_SEPARATE_OPEN_TEEMO2_NOT_GOAL_COMPLETION','allOriginal155ReviewObjectsExact':True,'allOriginal70CompleteContextsExact':True,'all245OldGateFieldsAndStatesExact':True,'all243OtherGatesWholeObjectsExact':True,'allSourceUniverseDatesDeltasAndCoverageRetained':True,'original16969ObligationIdsMustRemain':True,'newBoundedBranches':4,'newSeparateOpenSourceDamageBranches':2,'expectedCurrentObligations':16975,'sourceManifest':sp,'archiveMembers':len(rows),'archiveBytes':archive.stat().st_size})
print('Published bounded SQL4 +separate OPEN Teemo2;156reviews71contexts245gates;155old reviews/70contexts exact;archive',len(rows),archive.stat().st_size)
