from pathlib import Path
import datetime,gzip,hashlib,json,urllib.request,urllib.parse
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p,j):
    with p.open('x') as f:json.dump(j,f,ensure_ascii=False,indent=2);f.write('\n')
def pin(p):return {'path':str(p.relative_to(root)),'sha256':sha(p)}
cn=load(root/'data/official/upstream/2026-10-16/source-refresh-20261015T160523Z/card-catalog.zh-CN.json')
rows={r['id']:r for r in cn['cards']}
corpus=load(root/'docs/evidence/rules-reaudit-2026-10-11/official-corpus.json')
out={'startedAtUtc':now(),'region':'CN','language':'zh-CN','adoptedCoreEffectiveDate':'2026-10-16','cards':[],'primarySources':[],'rootIntegrationNotYetExecuted':True}
url='https://lol-api.playloltcg.com/xcx/card/searchCardCraftWeb'
for query,ids in [('虚空遁地兽',[33285,33354]),('烛光圣殿',[31536])]:
    body={'pageNum':1,'pageSize':100,'searchContent':query,'cardCategoryList':[],'cardColorList':[],'rarityList':[],'productCodeList':[]}
    at=now();req=urllib.request.Request(url,data=json.dumps(body,ensure_ascii=False).encode(),headers={'Content-Type':'application/json','User-Agent':'Riftbound-source-audit/1.0'},method='POST')
    with urllib.request.urlopen(req,timeout=45) as response:raw=response.read();status=response.status
    original=w/f'current-root-integration-{ids[0]}-original-api-response-v1.json.gz'
    with original.open('xb') as f:f.write(gzip.compress(raw,mtime=0))
    parsed=json.loads(raw)
    def find(value,identity):
        if isinstance(value,dict):
            if value.get('id')==identity and 'cardNo' in value:return [value]
            return [r for v in value.values() for r in find(v,identity)]
        if isinstance(value,list):return [r for v in value for r in find(v,identity)]
        return []
    for identity in ids:
        matches=find(parsed,identity);assert len(matches)==1
        row=matches[0];assert row==rows[identity],identity
        out['cards'].append({'url':url,'request':body,'attemptedAtUtc':at,'receivedAtUtc':now(),'httpStatus':status,'rawBytes':len(raw),'rawSha256':hashlib.sha256(raw).hexdigest(),'original':pin(original),'exactApiId':identity,'exactPrinting':row['cardNo'],'exactRow':row,'allOriginalKeysValuesAndNullsEqualPriorCn16Raw':True,'publicationDate':None,'effectiveDate':None})
for identity in ['DOC-01','DOC-09']:
    doc=next(r for r in corpus['documents'] if r['id']==identity)
    at=now();request_url=urllib.parse.quote(doc['url'],safe=':/?=&%')
    with urllib.request.urlopen(urllib.request.Request(request_url,headers={'User-Agent':'Riftbound-source-audit/1.0'}),timeout=45) as response:raw=response.read();status=response.status
    actual=hashlib.sha256(raw).hexdigest()
    original=root/'var/qa/cn-effective-20261016/whole-rule-source-readback/CN'/f'{identity}.pdf'
    assert actual==doc['sha256'] and original.is_file() and sha(original)==actual
    out['primarySources'].append({'document':identity,'url':doc['url'],'requestUrl':request_url,'attemptedAtUtc':at,'receivedAtUtc':now(),'httpStatus':status,'bytes':len(raw),'sha256':actual,'original':pin(original),'originalBytesAlreadyRetainedWithoutAnotherDuplicate':True,'officialDirectoryUpdatedDateRetained':doc.get('updated'),'publicationDate':None,'effectiveDate':doc.get('effectiveDate')})
out.update(finishedAtUtc=now(),noNewLiveSourceVersion=True,allOldAcquisitionPublicationEffectiveDatesRetained=True,wholePrintingOrGlobalCertification=False)
write(w/'current-root-integration-three-printings-and-two-primary-source-intake-v1.json',out)
print('Current source intake:three exact API printings and both original primary PDFs unchanged;original dates/unknowns preserved;no root/gameplay claim.')
