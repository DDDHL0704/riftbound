import ast,datetime,fcntl,hashlib,json,os,plistlib,resource,socket,subprocess
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();load=lambda p:json.loads(p.read_text())
definition=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py';nodes=[n for n in ast.parse(definition.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(definition),'exec'),globals())
pub=load(w/'current-four-exhausted-legend-reader-frozen-inputs-v1.json');runtime=Path(pub['runtimeRoot']);identity=pub['actualRuleInputs'];prior=load(w/'actual-current-four-exhausted-legend-prototype-owner-terminal-v1.json')
assert prior['writerExitCode']==0 and prior['errorType']=='KeyError' and prior['error']=="'printing'" and prior['allOriginal267AuditSevenTablesExactAtStop'] and prior['allOriginal56NativeSevenTablesExactAtStop'] and prior['ownPostgresSmartStopped']
output=w/'actual-current-four-exhausted-legend-prototype-sql-v1';receipts=[]
for label,printing in [('sfd187','SFD\u00b7187/221'),('sfd243','SFD\u00b7243/221')]:
 for branch in ['legend-first','battlefield-first']:
  folder=output/label/branch;p=folder/'receipt.json';original=load(p);initial=load(folder/'explicit-original-controlled-initial.json')
  assert original['branch']==branch and original['commands']==original['coldRecoveries']==8 and original['events']==22 and original['actualRuleInputs']==identity and initial['cardObjects']['LEGEND']['cardNo']==printing
  receipts.append({'originalReceipt':str(p),'originalReceiptSha256':sha(p),'exactPrintingFromOriginalControlledInitial':printing,'originalReceiptHasNoAddedPrintingField':True,**original})
assert len({r['room'] for r in receipts})==4
def frozen():
 assert all(sha(runtime/p)==h for p,h in pub['runtimeFiles'].items())
 assert all(sha(root/p)==h and oct((root/p).stat().st_mode&0o777)==pub['sourceInputModes'][p] for p,h in pub['sourceInputHashes'].items())
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB);terminal=w/'current-four-exhausted-legend-combined-writer-and-resumed-reader-v2.json';assert not terminal.exists()
proof={'status':'RUNNING_READ_ONLY_RESUME_CURRENT_FOUR_EXHAUSTED_LEGEND','startedAtUtc':now(),'actualRuleInputs':identity,'originalWriterOwnerOutcomeRetained':str(w/'actual-current-four-exhausted-legend-prototype-owner-terminal-v1.json'),'reason':'All four original writers exited0; outer coordinator expected a new printing field absent from retained receipts. Bind the precise original printing using the original controlled initial, without rewriting receipts or resubmitting commands.','writerReceiptsWithSeparatePrintingProvenance':receipts,'additionalGameCommandsSubmitted':0,'rootIntegration':False,'lockAtStart':observe_lock()}
power=reader=None;started=False;audit=native=None;before_audit=before_native=None
try:
 frozen();assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid
 sock.mkdir(exist_ok=True);subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'current-four-exhausted-legend-read-resume-postgres-v2.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 audit=rooms('riftbound_acceptance');native=rooms('riftbound_here_native');assert audit==prior['actualAuditRoomsAtStop'] and len(audit)==271 and native==prior['actualNativeRoomsAtStop'] and len(native)==56
 before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',native)
 (w/'original271-audit56-native-read-resume-baseline-v2.json').write_text(json.dumps({'atUtc':now(),'auditRooms':audit,'nativeRooms':native,'auditSevenTables':before_audit,'nativeSevenTables':before_native},indent=2)+'\n')
 result=w/'independent-current-four-exhausted-legend-prototype-all-history-v2.json';command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(runtime/'Riftbound.PostgresAcceptance.deps.json'),'--runtimeconfig',str(runtime/'Riftbound.PostgresAcceptance.runtimeconfig.json'),str(runtime/(pub['assembly']+'.dll')),str(output),str(result)];proof['actualReadOnlyReaderCommand']=command
 env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit;Options=-c default_transaction_read_only=on',DOTNET_DbgEnableMiniDump='0')
 with (w/'independent-current-four-exhausted-legend-resumed-all-history-v2.log').open('xb') as log:reader=subprocess.Popen(command,cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT);proof['independentExitCode']=reader.wait(timeout=600);assert proof['independentExitCode']==0
 actual=load(result);proof['independentReadback']=actual;assert actual['actualReadOnlyConnection'] and actual['cases']==4 and set(actual['rooms'])=={r['room'] for r in receipts} and actual['actualRuleInputs']==identity and actual['commands']==actual['authoritativeHistoricalStates']==32 and actual['events']==88 and actual['independentStructuralRejections']==16
 proof.update(status='PASS_CURRENT_FOUR_EXHAUSTED_LEGEND_ORIGINAL_WRITERS_AND_RESUMED_INDEPENDENT_ALL_HISTORY_ORIGINAL_REPLAY_NOT_ROOT_INTEGRATION',commands=32,events=88,coldRecoveries=32,directAtomicRejections=sum(r['directAtomicRejections'] for r in receipts),writerIndependentStructuralRejections=sum(r['independentStructuralRejections'] for r in receipts),newRoomsFromOriginalWriterOnly=sorted(r['room'] for r in receipts));print(proof['status'],flush=True)
except BaseException as e:proof.update(status='FAILED_OR_INTERRUPTED_READ_ONLY_FOUR_EXHAUSTED_LEGEND_RESUME_ORIGINALS_RETAINED',errorType=type(e).__name__,error=str(e));raise
finally:
 if reader is not None and reader.poll() is None:reader.terminate();reader.wait(timeout=20)
 if started:
  if before_audit is not None:proof['allOriginal271AuditSevenTablesExactAtStop']=digests('riftbound_acceptance',audit)==before_audit;proof['allOriginal56NativeSevenTablesExactAtStop']=digests('riftbound_here_native',native)==before_native;proof['actualAuditRoomsAtStop']=rooms('riftbound_acceptance');proof['actualNativeRoomsAtStop']=rooms('riftbound_here_native')
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None and power.poll() is None:power.terminate();power.wait(timeout=10)
 frozen();proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),frozenRuntimeAndAll3325SourceInputsStable=True,boundIdleAssertionEnded=power is not None and power.poll() is not None);terminal.write_text(json.dumps(proof,indent=2)+'\n');fcntl.flock(guard,fcntl.LOCK_UN)
assert proof['allOriginal271AuditSevenTablesExactAtStop'] and proof['allOriginal56NativeSevenTablesExactAtStop'] and proof['ownPostgresSmartStopped']
