using Npgsql;
if(args.Length!=1)throw new Exception("Fresh bounded output required.");
var settings=new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound")??throw new Exception("Real own SQL required."));
if(settings.Host!="127.0.0.1"||settings.Port!=55486||settings.Database!="riftbound_acceptance"||settings.Username!="codex_riftbound_audit")throw new Exception("Only own dedicated SQL.");
await using var source=NpgsqlDataSource.Create(settings.ConnectionString);
await ExhaustedLegendSqlPrototypeV1.RunAsync(source,args[0]);
