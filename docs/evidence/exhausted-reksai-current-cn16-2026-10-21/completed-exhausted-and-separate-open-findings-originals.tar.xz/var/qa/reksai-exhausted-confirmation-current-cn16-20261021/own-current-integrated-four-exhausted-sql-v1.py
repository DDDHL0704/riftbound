import ast,datetime,fcntl,hashlib,json,os,plistlib,resource,socket,subprocess
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
w38=root/'var/qa/void-gate-current-erratum-20261021'
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres'
sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts']
read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
load=lambda p:json.loads(p.read_text())
definition=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes=[n for n in ast.parse(definition.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}]
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(definition),'exec'),globals())
pub=load(w/'current-integrated-exhausted-sql-frozen-inputs-v1.json');runtime=Path(pub['runtimeRoot'])
reader=load(w/'current-integrated-exhausted-reader-frozen-inputs-v1.json');rr=Path(reader['runtimeRoot'])
identity=load(w/'current-integrated-exhausted-actual-rule-inputs-v1.json')
old_audit=load(w/'current-four-exhausted-legend-combined-writer-and-resumed-reader-v2.json')['actualAuditRoomsAtStop']
old_native=load(w38/'fixed2b83-native-attempt-v2/live-current-ci-main-owner-terminal-v2.json')['actualNativeRoomsAtStop']
assert len(old_audit)==271 and len(old_native)==58
def stable():
    return all(sha(d/p)==h for d,files in [(runtime,pub['runtimeFiles']),(rr,reader['runtimeFiles'])] for p,h in files.items()) and all(sha(root/p)==h and oct((root/p).stat().st_mode&0o777)==pub['sourceInputModes'][p] for p,h in pub['sourceInputHashes'].items())
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
terminal=w/'actual-current-integrated-four-exhausted-sql-owner-terminal-v1.json';assert not terminal.exists()
proof={'status':'RUNNING_CURRENT_INTEGRATED_FOUR_EXHAUSTED_SQL','startedAtUtc':now(),'parentCommit':pub['parentCommit'],'actualRuleInputs':identity,'includesDeclaredUncommittedChanges':True,'lockAtStart':observe_lock(),'allOriginalRoomsAndActionsRetainedWithoutMigration':True,'original52SqlIdentitiesAndOrderRetainedOnly53rdAppended':True}
power=writer=independent=None;started=False;audit=native=None;before_audit=before_native=None
try:
    assert stable()
    assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
    with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
    power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid
    sock.mkdir(exist_ok=True)
    subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'current-integrated-four-exhausted-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
    audit=rooms('riftbound_acceptance');native=rooms('riftbound_here_native')
    assert audit==old_audit and native==old_native
    before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',native)
    (w/'original271-audit58-native-seven-table-baseline-v1.json').write_text(json.dumps({'atUtc':now(),'auditRooms':audit,'nativeRooms':native,'auditSevenTables':before_audit,'nativeSevenTables':before_native},indent=2)+'\n')
    output=w/'actual-current-integrated-four-exhausted-sql-v1';assert not output.exists()
    env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit',RIFTBOUND_POSTGRES_EVIDENCE=str(output),DOTNET_DbgEnableMiniDump='0')
    command=['/Users/dinghaolin/.dotnet/dotnet',str(runtime/'Riftbound.PostgresAcceptance.dll'),'--exhausted-legend-confirmation-only']
    proof['actualWriterCommand']=command
    with (w/'actual-current-integrated-four-exhausted-writer-v1.log').open('xb') as f:
        writer=subprocess.Popen(command,cwd=runtime,env=env,stdout=f,stderr=subprocess.STDOUT);proof['writerExitCode']=writer.wait(timeout=300)
    assert proof['writerExitCode']==0
    receipts=[load(output/'exhausted-legend-confirmation'/p/b/'receipt.json') for p in ['sfd187','sfd243'] for b in ['legend-first','battlefield-first']]
    expected={(p,b) for p in ['SFD·187/221','SFD·243/221'] for b in ['legend-first','battlefield-first']}
    assert {(r['printing'],r['branch']) for r in receipts}==expected
    assert all(r['rootIntegration'] and r['status']=='REAL_SQL_CURRENT_EXHAUSTED_REKSAI_CAPTURE_CONFIRMATION_FAILURE_CANDLELIT_ONLY' and r['actualRuleInputs']==identity and r['commands']==r['coldRecoveries']==8 and r['events']==22 and r['directAtomicRejections']==8 and r['independentStructuralRejections']==4 for r in receipts)
    added={r['room'] for r in receipts};assert len(added)==4 and set(rooms('riftbound_acceptance'))==set(audit)|added and rooms('riftbound_here_native')==native
    proof.update(writerCases=4,receipts=receipts,commands=32,events=88,coldRecoveries=32,directAtomicRejections=32,writerIndependentStructuralRejections=16,newRooms=sorted(added))
    print('CURRENT_INTEGRATED_FOUR_EXHAUSTED_SQL_WRITER_PASS32commands88events',flush=True)
    result=w/'independent-current-integrated-four-exhausted-all-history-v1.json'
    command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(rr/'Riftbound.PostgresAcceptance.deps.json'),'--runtimeconfig',str(rr/'Riftbound.PostgresAcceptance.runtimeconfig.json'),str(rr/(reader['assembly']+'.dll')),str(output/'exhausted-legend-confirmation'),str(result)]
    proof['actualReadOnlyReaderCommand']=command
    with (w/'independent-current-integrated-four-exhausted-all-history-v1.log').open('xb') as f:
        independent=subprocess.Popen(command,cwd=rr,env=env,stdout=f,stderr=subprocess.STDOUT);proof['independentExitCode']=independent.wait(timeout=300)
    assert proof['independentExitCode']==0
    actual=load(result);proof['independentReadback']=actual
    assert actual['rootIntegration'] and actual['actualReadOnlyConnection'] and set(actual['rooms'])==added and actual['actualRuleInputs']==identity
    assert actual['commands']==actual['authoritativeHistoricalStates']==32 and actual['events']==88 and actual['privateSnapshots']==actual['privatePrompts']==64 and actual['independentStructuralRejections']==16
    proof['status']='PASS_CURRENT_INTEGRATED_FOUR_EXHAUSTED_PRINTINGS_ORDERS_REAL_JSONB_COLD_DEDUP_ALL_HISTORY_ORIGINAL_REPLAY'
    print(proof['status'],flush=True)
except BaseException as e:
    proof.update(status='FAILED_OR_INTERRUPTED_CURRENT_INTEGRATED_EXHAUSTED_SQL_ORIGINALS_RETAINED',errorType=type(e).__name__,error=str(e));raise
finally:
    for process in [writer,independent]:
        if process is not None and process.poll() is None:process.terminate();process.wait(timeout=20)
    if started:
        if before_audit is not None:
            proof['allOriginal271AuditSevenTablesExactAtStop']=digests('riftbound_acceptance',audit)==before_audit
            proof['allOriginal58NativeSevenTablesExactAtStop']=digests('riftbound_here_native',native)==before_native
            proof['actualAuditRoomsAtStop']=rooms('riftbound_acceptance');proof['actualNativeRoomsAtStop']=rooms('riftbound_here_native')
        proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
    if power is not None and power.poll() is None:power.terminate();power.wait(timeout=10)
    proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),frozenRuntimeAndAll3326SourceInputsStable=stable(),boundIdleAssertionEnded=power is not None and power.poll() is not None)
    terminal.write_text(json.dumps(proof,indent=2)+'\n');fcntl.flock(guard,fcntl.LOCK_UN)
assert proof['allOriginal271AuditSevenTablesExactAtStop'] and proof['allOriginal58NativeSevenTablesExactAtStop'] and proof['ownPostgresSmartStopped'] and proof['frozenRuntimeAndAll3326SourceInputsStable']
