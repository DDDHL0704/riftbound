from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
w38=root/'var/qa/void-gate-current-erratum-20261021'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text());now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p,j):
    with p.open('x') as f:json.dump(j,f,ensure_ascii=False,indent=2);f.write('\n')
def files(folder):return {str(p.relative_to(folder)):sha(p) for p in sorted(folder.rglob('*')) if p.is_file() and p.relative_to(folder).parts[0]!='var'}
focus=w/'focus-current-root-exhausted-and-original-adjacent-v1'
summary=load(focus/'summary.json')
assert summary.get('profile')=='focus' and summary.get('status')=='PASSED'
previous=load(w38/'post-only-check-exact-source-expectation-remediation-v1.json')
source_hashes={p:sha(root/p) for p in previous['finalSourceHashes']}
new_source='tests/Riftbound.PostgresAcceptance/ExhaustedLegendConfirmationSqlAcceptance.cs'
assert new_source not in source_hashes;source_hashes[new_source]=sha(root/new_source)
assert len(source_hashes)==3326
changed=[p for p,h in previous['finalSourceHashes'].items() if source_hashes[p]!=h]
assert set(changed)=={'tests/Riftbound.PostgresAcceptance/Program.cs','tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json','scripts/tests/test_sql_ci_gate.py'}
source_modes={p:oct((root/p).stat().st_mode&0o777) for p in source_hashes}
parent=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()
assert parent=='708a3558040f9acd4c66122a00db8ca085f460cf'
log=w/'build-current-integrated-exhausted-sql-v1.log'
with log.open('xb') as f:
    subprocess.run(['/Users/dinghaolin/.dotnet/dotnet','build','tests/Riftbound.PostgresAcceptance/Riftbound.PostgresAcceptance.csproj','--configuration','Release','--nologo'],cwd=root,stdout=f,stderr=subprocess.STDOUT,check=True)
runtime=w/'current-integrated-exhausted-sql-runtime-v1'
output=root/'tests/Riftbound.PostgresAcceptance/bin/Release/net10.0'
assert not runtime.exists()
shutil.copytree(output,runtime,ignore=lambda folder,names:['var'] if 'var' in names else [])
sql_files=files(runtime)
assert len(load(runtime/'SqlAcceptanceCases.json')['cases'])==53
frozen={'atUtc':now(),'parentCommit':parent,'runtimeRoot':str(runtime),'runtimeFiles':sql_files,'sourceInputHashes':source_hashes,'sourceInputModes':source_modes,'includesDeclaredUncommittedChanges':True,'allOriginal3325SourcePathsAndOnlyNewSqlClassRetained':True,'changedOriginalSourcePaths':changed,'noGameplaySourceChangedFromFixed708':True,'rootMutableRuntimeInodesShared':False}
assert all((runtime/p).stat().st_ino!=(output/p).stat().st_ino for p in sql_files)
write(w/'current-integrated-exhausted-sql-frozen-inputs-v1.json',frozen)
reader_source=w/'current-integrated-exhausted-reader-source-v1';reader_source.mkdir()
old=w/'current-four-exhausted-legend-reader-source-v1'
text=(old/'Program.cs').read_text()
before='Check(args.Length==2&&!File.Exists(args[1]),'
assert text.count(before)==1
text=text.replace(before,'if(args.SequenceEqual(new[]{\"--identity\"})){Console.WriteLine(JsonSerializer.Serialize(RuleInputIdentity.Current,new JsonSerializerOptions(JsonSerializerDefaults.Web){WriteIndented=true}));return;}\n'+before)
before='var initial=JsonSerializer.Deserialize<MatchState>(File.ReadAllText(Path.Combine(directory,\"explicit-original-controlled-initial.json\")),json)!;'
assert text.count(before)==1
text=text.replace(before,before+'\n    Check(receipt.RootElement.GetProperty(\"printing\").GetString()==printing&&receipt.RootElement.GetProperty(\"branch\").GetString()==branch&&receipt.RootElement.GetProperty(\"rootIntegration\").GetBoolean(),\"Exact separately executed printing and order in the integrated original receipt.\");')
text=text.replace('PASS_INDEPENDENT_PROTOTYPE_CURRENT_EXHAUSTED_REKSAI_BOTH_ORDERS_CAPTURE_COST_FAILURE_PRIVATE_LOOK_ALL_HISTORY_AND_ORIGINAL_REPLAY','PASS_INDEPENDENT_CURRENT_INTEGRATED_EXHAUSTED_REKSAI_TWO_PRINTINGS_BOTH_ORDERS_ALL_HISTORY_AND_ORIGINAL_REPLAY').replace('rootIntegration=false','rootIntegration=true').replace('EXHAUSTED_REKSAI_INDEPENDENT_PROTOTYPE_PASS','EXHAUSTED_REKSAI_INDEPENDENT_CURRENT_INTEGRATED_PASS')
(reader_source/'Program.cs').write_text(text)
project=(old/'probe.csproj').read_text().replace('CurrentFourExhaustedLegendIndependentReaderV1','CurrentIntegratedExhaustedLegendIndependentReaderV1').replace(str(w38/'current-integrated-sql-runtime-v2'),str(runtime))
assert str(runtime) in project and str(w38/'current-integrated-sql-runtime-v2') not in project
(reader_source/'probe.csproj').write_text(project)
with (w/'build-current-integrated-exhausted-reader-v1.log').open('xb') as f:
    subprocess.run(['/Users/dinghaolin/.dotnet/dotnet','build',str(reader_source/'probe.csproj'),'--configuration','Release','--nologo'],cwd=root,stdout=f,stderr=subprocess.STDOUT,check=True)
reader_runtime=w/'current-integrated-exhausted-reader-runtime-v1'
shutil.copytree(runtime,reader_runtime)
assembly='CurrentIntegratedExhaustedLegendIndependentReaderV1'
for suffix in ['.dll','.pdb']:shutil.copy2(reader_source/'bin/Release/net10.0'/(assembly+suffix),reader_runtime/(assembly+suffix))
reader_files=files(reader_runtime)
reader={'atUtc':now(),'parentCommit':parent,'runtimeRoot':str(reader_runtime),'runtimeFiles':reader_files,'assembly':assembly,'sourceHashes':{str(p.relative_to(w)):sha(p) for p in reader_source.iterdir() if p.is_file()},'onlyFrozenRuntimeReferences':True,'noMutableRootInodesShared':True}
command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(reader_runtime/'Riftbound.PostgresAcceptance.deps.json'),'--runtimeconfig',str(reader_runtime/'Riftbound.PostgresAcceptance.runtimeconfig.json'),str(reader_runtime/(assembly+'.dll')),'--identity']
result=subprocess.check_output(command,cwd=reader_runtime,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0'))
identity=json.loads(result)
assert identity['authoritySha256']=='70ccda5893a1b8b56cdceadee35e084b1e3f5b297ef64e1ce7d0cbeb141ce2d4'
assert identity['catalogSha256']=='a940e5f8bcd5e1ead68a85c7f983e530333d6179a4b8429ed1f8fe2ee20b8397'
reader['actualRuleInputs']=identity
assert all(sha(root/p)==h for p,h in source_hashes.items()) and files(runtime)==sql_files
write(w/'current-integrated-exhausted-actual-rule-inputs-v1.json',identity)
write(w/'current-integrated-exhausted-reader-frozen-inputs-v1.json',reader)
print('Current integrated SQL and independent reader frozen:',len(sql_files),len(reader_files),'runtime files;',len(source_hashes),'source inputs;actual identity',identity['identitySha256'])
