using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

if(args.SequenceEqual(new[]{"--identity"})){Console.WriteLine(JsonSerializer.Serialize(RuleInputIdentity.Current,new JsonSerializerOptions(JsonSerializerDefaults.Web){WriteIndented=true}));return;}
Check(args.Length==2&&!File.Exists(args[1]),"Exact evidence directory and fresh independent output required.");
var work=Path.GetFullPath(args[0]);var output=Path.GetFullPath(args[1]);var json=new JsonSerializerOptions(JsonSerializerDefaults.Web){WriteIndented=true};
var settings=new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));Check(settings.Host=="127.0.0.1"&&settings.Port==55486&&settings.Database=="riftbound_acceptance"&&settings.Username=="codex_riftbound_audit","Only own audit database.");settings.Options="-c default_transaction_read_only=on";await using var source=NpgsqlDataSource.Create(settings.ConnectionString);
var results=new List<object>();var rooms=new List<string>();var totalStates=0;var totalSnapshots=0;var totalPrompts=0;var totalCommands=0;var totalEvents=0;var rejections=0;
foreach(var printing in new[]{"SFD\u00b7187/221","SFD\u00b7243/221"})foreach(var branch in new[]{"legend-first","battlefield-first"})
{
    var directory=Path.Combine(work,printing.Contains("187")?"sfd187":"sfd243",branch);using var receipt=JsonDocument.Parse(File.ReadAllText(Path.Combine(directory,"receipt.json")));var room=receipt.RootElement.GetProperty("room").GetString()!;rooms.Add(room);
    var initial=JsonSerializer.Deserialize<MatchState>(File.ReadAllText(Path.Combine(directory,"explicit-original-controlled-initial.json")),json)!;
    Check(receipt.RootElement.GetProperty("printing").GetString()==printing&&receipt.RootElement.GetProperty("branch").GetString()==branch&&receipt.RootElement.GetProperty("rootIntegration").GetBoolean(),"Exact separately executed printing and order in the integrated original receipt.");
    var frame=await new PostgresMatchRecoveryStore(source).LoadAsync(room,default)??throw new Exception("Real retained SQL frame required.");using var original=Read(Path.Combine(directory,"final-original-frame.json.gz"));
    Check(Same(original.RootElement,JsonSerializer.SerializeToElement(frame,json)),"Every original final SQL frame field/null/omission equals the actual independent read.");
    Check(frame.IsConsistent&&frame.Commands.Count==receipt.RootElement.GetProperty("commands").GetInt32()&&frame.Events.Count==receipt.RootElement.GetProperty("events").GetInt32()&&initial.RoomId==room&&initial.Tick==0&&initial.RuleInputs==RuleInputIdentity.Current&&frame.AuthoritativeState!.RuleInputs==RuleInputIdentity.Current,"Exact controlled initial and current frozen identity.");
    Check(frame.ReplayInitialState is {Tick:0,CardObjects.Count:0}&&!Same(JsonSerializer.SerializeToElement(initial,json),JsonSerializer.SerializeToElement(frame.ReplayInitialState,json)),"Original blank replay metadata remains separate; explicit original controlled initial is supplied only to the independent replay.");
    using var intents=JsonDocument.Parse(File.ReadAllText(Path.Combine(directory,"all-original-accepted-intents.json")));Check(intents.RootElement.GetArrayLength()==frame.Commands.Count,"All original intents retained.");
    for(var i=0;i<frame.Commands.Count;i++)Check(frame.Commands[i].Accepted&&frame.Commands[i].RuleInputs==RuleInputIdentity.Current&&frame.Commands[i].PlayerId==intents.RootElement[i].GetProperty("actor").GetString()&&Same(frame.Commands[i].RawCommand!.Value,intents.RootElement[i].GetProperty("rawCommand")),"Every actor/full raw command and identity equals the original accepted input.");
    var states=new Dictionary<(long,long),MatchState>();var counts=new Dictionary<string,int>();
    await using(var connection=await source.OpenConnectionAsync())
    {
        Check((string)(await new NpgsqlCommand("show transaction_read_only",connection).ExecuteScalarAsync())! =="on","Actual read-only SQL session.");
        await using(var q=new NpgsqlCommand("select last_event_sequence,payload::text from state_snapshots where match_id=@room order by id",connection))
        {
            q.Parameters.AddWithValue("room",room);await using var rows=await q.ExecuteReaderAsync();
            while(await rows.ReadAsync())
            {
                var raw=rows.GetString(1);var state=JsonSerializer.Deserialize<MatchState>(raw,json)!;
                Check(JsonNode.DeepEquals(JsonNode.Parse(raw),JsonSerializer.SerializeToNode(state,json))&&state.RuleInputs==RuleInputIdentity.Current&&states.TryAdd((state.Tick,rows.GetInt64(0)),state),"All original authority fields/nulls, current identity and tick/event-sequence identity survive independent read.");
                Check(state.CardObjects["LEGEND"].IsExhausted&&state.RunePools["P1"].Mana==20&&state.RunePools["P1"].Power==10&&state.RngCursor==initial.RngCursor,"Literal already exhausted legend, resources and RNG remain unchanged in every original history.");
                foreach(var trigger in state.TriggerQueue.Where(t=>t.SourceObjectId=="LEGEND"))Check(trigger.ControllerId=="P1"&&trigger.TriggeredByEventKind=="BATTLEFIELD_CONQUERED"&&trigger.LegendConquest?.CardNo==printing&&trigger.LegendConquest is {Kind:"EXHAUST_DECK_PLAY",SourceGeneration:0,BattlefieldId:"BF"},"Original exhausted legendary source still genuinely captures the conquest event with its literal identity and generation.");
                if(state.PendingCardChoice is { } choice)Check(choice.PlayerId=="P1"&&choice.ChoiceWindow is "INSIGHT" or "INSIGHT_ORDER"&&choice.LegalObjectIds.SequenceEqual(new[]{"DRAW1","DRAW2"}),"Only the original battlefield's private pair is selectable after the failed legendary cost.");
                Check(state.PendingEffectPlay is null&&state.PendingPayment is null,"Failed legendary source cost creates neither a paid prompt nor a play permission.");
            }
        }
        Check(states.Count==frame.Commands.Count&&frame.Commands.All(c=>states.ContainsKey((c.CompletedTick,c.CompletedEventSequence))),"Each accepted command retains its exact authoritative historical row.");
        var latest=frame.Commands.GroupBy(c=>c.CompletedTick).Select(g=>g.OrderBy(c=>c.CompletedEventSequence).Last()).ToArray();var expected=latest.SelectMany(c=>new[]{"P1","P2"}.Select(p=>(c.CompletedTick,c.CompletedEventSequence,p))).ToHashSet();
        foreach(var table in new[]{"snapshots","action_prompts"})
        {
            var column=table=="snapshots"?"snapshot_tick":"prompt_tick";await using(var constraint=new NpgsqlCommand($"select pg_get_constraintdef(oid) from pg_constraint where conrelid='{table}'::regclass and contype='u'",connection))Check((string)(await constraint.ExecuteScalarAsync())! ==$"UNIQUE (match_id, player_id, {column})","Actual existing private storage key is viewer/tick.");
            await using var q=new NpgsqlCommand($"select player_id,last_event_sequence,payload::text from {table} where match_id=@room order by id",connection);q.Parameters.AddWithValue("room",room);await using var rows=await q.ExecuteReaderAsync();var actual=new HashSet<(long,long,string)>();
            while(await rows.ReadAsync())
            {
                var actor=rows.GetString(0);var sequence=rows.GetInt64(1);var raw=rows.GetString(2);using var doc=JsonDocument.Parse(raw);var tick=doc.RootElement.GetProperty(table=="snapshots"?"tick":"snapshotTick").GetInt64();Check(states.TryGetValue((tick,sequence),out var state)&&actual.Add((tick,sequence,actor)),"Each private original row binds its original authority, sequence, tick and viewer.");
                var typed=table=="snapshots"?JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<SnapshotDto>(raw,json),json):JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<ActionPromptDto>(raw,json),json);Check(JsonNode.DeepEquals(JsonNode.Parse(raw),typed),"Every private field/null and conditional omission survives typed read.");
                var projection=table=="snapshots"?JsonSerializer.SerializeToNode(ResolutionResult.BuildSnapshots(state!)[actor],json):JsonSerializer.SerializeToNode(ResolutionResult.BuildPrompts(state!)[actor],json);Check(JsonNode.DeepEquals(JsonNode.Parse(raw),projection),"Every original private value equals its exact historical state projection.");
                var other=actor=="P1"?"P2":"P1";var visible=state!.PendingEffectPlay?.RevealedHand?.Cards.Keys.ToHashSet()??new HashSet<string>();
                foreach(var id in state.PlayerZones[other].MainDeck.Concat(state.PlayerZones[other].Hand).Except(visible))Check(!raw.Contains("\""+id+"\"",StringComparison.Ordinal),"Literal opponent hidden identity absent outside the original reveal window.");
                Check(!raw.Contains("\"HIDDEN_DECK\"",StringComparison.Ordinal)&&!doc.RootElement.TryGetProperty("openingSeed",out _),"Unrelated original deck identity and private opening seed never leak.");

            }
            Check(actual.SetEquals(expected),"Both players retain exactly the latest original projection at each tick according to the actual existing key; no missing historical authority.");counts[table]=actual.Count;
        }
    }
    foreach(var pair in states)
    {
        var commands=frame.Commands.Where(c=>c.CompletedEventSequence<=pair.Key.Item2).ToArray();var events=frame.Events.Where(e=>e.Sequence<=pair.Key.Item2).ToArray();
        var verified=await MatchActionLogReplayer.VerifyFinalStateAsync(initial,commands,pair.Value,new CoreRuleEngine(),default,events);Check(verified.IsMatch,"Every original authority history independently replays from its exact original controlled initial: "+string.Join(';',verified.Errors));
    }
    using var capturedDocument=Read(Path.Combine(directory,"before-order-original-frame.json.gz"));var captured=capturedDocument.RootElement.Deserialize<MatchRecoveryFrame>(json)!;var captureState=captured.AuthoritativeState!;
    Check(captureState.CardObjects["LEGEND"].IsExhausted&&captureState.TriggerQueue.Count==2&&captureState.TriggerQueue.Select(t=>t.SourceObjectId).Order(StringComparer.Ordinal).SequenceEqual(new[]{"BF","LEGEND"}),"Actual exhausted legend and distinct battlefield both capture before any confirmation cost is checked.");
    var order=frame.Commands.Single(c=>c.CommandType=="ORDER_TRIGGERS");var originalIds=order.RawCommand!.Value.GetProperty("orderedTriggerIds").EnumerateArray().Select(i=>i.GetString()).ToArray();
    var expectedSources=branch=="legend-first"?new[]{"LEGEND","BF"}:new[]{"BF","LEGEND"};
    Check(order.PlayerId=="P1"&&originalIds.SequenceEqual(expectedSources.Select(id=>captureState.TriggerQueue.Single(t=>t.SourceObjectId==id).TriggerId)),"Literal original actor separately selected each relative resolution order, including the already exhausted captured legend.");
    var originalLegend=captureState.TriggerQueue.Single(t=>t.SourceObjectId=="LEGEND");
    foreach(var bad in new[]{originalLegend with {LegendConquest=originalLegend.LegendConquest! with {SourceGeneration=-1}},originalLegend with {LegendConquest=originalLegend.LegendConquest! with {Kind="PAY_READY_SELF"}},originalLegend with {EffectKind="SPELL"},originalLegend with {TriggeredByEventKind="UNIT_PLAYED"}})
    {
        var forged=captureState with {TriggerQueue=captureState.TriggerQueue.Select(t=>t.SourceObjectId=="LEGEND"?bad:t).ToArray()};
        Check(MatchRecoveryValidator.Validate(room,captured.LastEventSequence,captured.Commands,captured.Events,captured.PlayerViews,forged,captured.CurrentTick,captured.SpectatorReplayFrame).Count>0,"Independent literal malformed-generation/definition/effect/event capture rejected.");rejections++;
    }
    using var failedDocument=Read(Path.Combine(directory,"failed-legend-cost-before-battlefield-look-original-frame.json.gz"));var failed=failedDocument.RootElement.Deserialize<MatchRecoveryFrame>(json)!;
    Check(Same(JsonSerializer.SerializeToElement(frame.Commands.Take(failed.Commands.Count),json),failedDocument.RootElement.GetProperty("commands"))&&Same(JsonSerializer.SerializeToElement(frame.Events.Take(failed.Events.Count),json),failedDocument.RootElement.GetProperty("events")),"Every accepted original failed-cost checkpoint action/event field remains an exact final prefix.");
    Check(failed.AuthoritativeState is {PendingCardChoice:null,PendingPayment:null,PendingEffectPlay:null}&&failed.AuthoritativeState.StackItems.Count==1&&failed.AuthoritativeState.StackItems[0].SourceObjectId=="BF"&&failed.AuthoritativeState.CardObjects["LEGEND"].IsExhausted&&failed.AuthoritativeState.PlayerZones["P1"].MainDeck.SequenceEqual(new[]{"DRAW1","DRAW2","DRAW3"}),"Failed confirmation removes the original legendary item before any response or reveal while the actual battlefield waits independently.");
    var final=frame.AuthoritativeState!;
    Check(final.Status==MatchStatuses.InProgress&&final.PlayerScores["P1"]==1&&final.PlayerScores["P2"]==0&&final.PendingCardChoice is null&&final.PendingEffectPlay is null&&final.PendingPayment is null&&final.StackItems.Count==0&&final.TriggerQueue.Count==0,"Exactly the original conquest with no residual failed cost, queue or play window.");
    Check(final.PlayerZones["P1"].MainDeck.SequenceEqual(new[]{"DRAW2","DRAW1","DRAW3"})&&final.CardObjects["LEGEND"].IsExhausted&&final.CardObjects["BF"].OwnerId=="P2"&&final.RunePools["P1"].Mana==20&&final.RunePools["P1"].Power==10&&final.RngCursor==initial.RngCursor,"Only the original conqueror's private captured pair reorders; exhausted source, distinct printed battlefield owner, pool and RNG remain literal.");
    Check(frame.Events.Count(e=>e.Event.Kind=="TRIGGER_NOT_CONFIRMED")==1&&frame.Events.Where(e=>e.Event.Kind=="TRIGGER_NOT_CONFIRMED").All(e=>JsonSerializer.SerializeToElement(e.Event.Payload,json).GetProperty("sourceObjectId").GetString()=="LEGEND")&&frame.Events.All(e=>e.Event.Kind is not("CARDS_REVEALED" or "CARD_DRAWN" or "MAIN_DECK_BURNED_OUT")),"Exactly one original exhausted legendary item is discarded at confirmation; its public reveal, draw and burnout never occur.");
    totalStates+=states.Count;totalSnapshots+=counts["snapshots"];totalPrompts+=counts["action_prompts"];totalCommands+=frame.Commands.Count;totalEvents+=frame.Events.Count;results.Add(new{printing,branch,room,commands=frame.Commands.Count,events=frame.Events.Count,states=states.Count,snapshots=counts["snapshots"],prompts=counts["action_prompts"],allFieldsAndEveryOriginalHistoricalReplayExact=true});
}
await File.WriteAllTextAsync(output,JsonSerializer.Serialize(new{status="PASS_INDEPENDENT_CURRENT_INTEGRATED_EXHAUSTED_REKSAI_TWO_PRINTINGS_BOTH_ORDERS_ALL_HISTORY_AND_ORIGINAL_REPLAY",rooms,cases=4,commands=totalCommands,events=totalEvents,authoritativeHistoricalStates=totalStates,privateSnapshots=totalSnapshots,privatePrompts=totalPrompts,independentStructuralRejections=rejections,actualRuleInputs=RuleInputIdentity.Current,results,actualReadOnlyConnection=true,originalBlankReplayMetadataNotRewritten=true,rootIntegration=true,wholePrintingOrProductCertification=false},json));
Console.WriteLine($"EXHAUSTED_REKSAI_INDEPENDENT_CURRENT_INTEGRATED_PASS {totalCommands} commands {totalEvents} events {totalStates} states {totalSnapshots} snapshots {totalPrompts} prompts {rejections} structural rejects");
bool Same(JsonElement left,JsonElement right)=>JsonNode.DeepEquals(JsonNode.Parse(left.GetRawText()),JsonNode.Parse(right.GetRawText()));
static JsonDocument Read(string path){using var zip=new GZipStream(File.OpenRead(path),CompressionMode.Decompress);return JsonDocument.Parse(zip);}
static void Check(bool value,string message){if(!value)throw new Exception(message);}
