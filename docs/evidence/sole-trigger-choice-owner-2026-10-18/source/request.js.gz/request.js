// request.js
const BASE_URL = 'https://lol-api.playloltcg.com'; //pro
const API_PATH = '';

async function sendGetRequest(endpoint, params) {
  try {
    const url = `${BASE_URL}${API_PATH}${endpoint}`;
    const response = await axios.get(url, { params });
    return response.data;
  } catch (error) {
    console.error('Error sending GET request:', error);
    throw error;
  }
}

async function sendPostRequest(endpoint, data) {
  try {
    const url = `${BASE_URL}${API_PATH}${endpoint}`;
    const response = await axios.post(url, data);
    return response.data;
  } catch (error) {
    console.error('Error sending POST request:', error);
    throw error;
  }
}
