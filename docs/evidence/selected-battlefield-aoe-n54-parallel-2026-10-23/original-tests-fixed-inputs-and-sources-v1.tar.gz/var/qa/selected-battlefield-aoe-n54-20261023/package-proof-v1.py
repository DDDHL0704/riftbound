from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,tarfile,io,subprocess,xml.etree.ElementTree as E
R=Path.cwd();Q=R/'var/qa/selected-battlefield-aoe-n54-20261023';D=R/'docs/evidence/selected-battlefield-aoe-n54-parallel-2026-10-23';D.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
frozen=json.load((Q/'frozen-inputs-v1.json').open())
for p,h in frozen['ruleInputs'].items():assert sha((R/p).read_bytes())==h
runs=[]
for name,total,methods in [('focus-v1',85,10),('adjacent-and-games-v1',53,9)]:
 t=E.parse(Q/name/'focus/results.trx');c=t.find('.//t:Counters',ns).attrib;assert[c['total'],c['passed'],c['failed'],c['notExecuted']]==[str(total),str(total),'0','0']
 plan=json.load((Q/name/'plan.json').open());assert len(plan['shards'][0]['methods'])==methods;runs.append({'path':name,'counters':c,'plan':plan,'cases':[{'name':x.get('testName'),'outcome':x.get('outcome')}for x in t.findall('.//t:UnitTestResult',ns)]})
assert runs[0]['plan']['testAssemblySha256']==runs[1]['plan']['testAssemblySha256']
assembly=R/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0/Riftbound.ConformanceTests.dll';assert runs[0]['plan']['testAssemblySha256']==sha(assembly.read_bytes())
source='tests/Riftbound.ConformanceTests/SelectedBattlefieldAreaDamageTests.cs';assert(Q/'focus-v1/test-source.cs').read_bytes()==(R/source).read_bytes()
proof=json.load((Q/'verified-results-v1.json').open());assert len(proof)==78 and sum(x['commands']for x in proof)==178 and sum(x['accepted']for x in proof)==148 and sum(x['events']for x in proof)==540 and sum(x['duplicates']for x in proof)==32
actual=[]
for folder in ['selected-original-v1','untargeted-original-v1','tibbers-original-v1']:
 for p in (Q/folder).glob('*.json.gz'):
  x=json.load(gzip.open(p,'rt'));assert x['failure']is None
  for c in x['commands']:
   if c['ruleInputs']not in actual:actual.append(c['ruleInputs'])
assert len(actual)==1
receipt=json.load((Q/'applied-n54-overlay-v1.json').open());peer=Path(receipt['overlaySource']);assert sha(peer.read_bytes())==receipt['overlaySha256']
n53receipt=Path(receipt['parentReceipt']);n53=json.load(n53receipt.open());n53peer=Path(n53['overlaySource']);assert sha(n53peer.read_bytes())==n53['overlaySha256'];n52receipt=Path(n53['parentReceipt']);n52=json.load(n52receipt.open());n52peer=Path(n52['overlaySource']);assert sha(n52peer.read_bytes())==n52['overlaySha256']
sourceDirs=[R/'var/qa/selected-battlefield-aoe-20261023/sources-v1',R/'var/qa/battlefield-aoe-source-scope-20261023/sources-v1',R/'var/qa/void-gate-untargeted-damage-20261023/sources-v1',R/'var/qa/tibbers-untargeted-damage-20261023/sources-v1']
for root in sourceDirs:
 for p in root.glob('current-*-original-v1.json.gz'):
  x=json.load(gzip.open(p,'rt'));assert sha(x['originalUtf8'].encode())==x['rawSha256']
previous=[]
for slug in ['selected-battlefield-aoe','void-gate-untargeted-damage','tibbers-untargeted-damage']:
 path=R/f'docs/evidence/{slug}-parallel-2026-10-23/source-and-red-test-manifest.json';x=json.load(path.open());ap=R/x['archive']['path'];assert sha(ap.read_bytes())==x['archive']['sha256'];previous.append({'manifest':str(path.relative_to(R)),'manifestSha256':sha(path.read_bytes()),'archive':str(ap.relative_to(R)),'archiveSha256':sha(ap.read_bytes())})
extra=[source,'tests/Riftbound.ConformanceTests/VoidGateUntargetedDamageTests.cs','tests/Riftbound.ConformanceTests/TibbersUntargetedDamageTests.cs','tests/Riftbound.ConformanceTests/CurrentVoidGateErratumTests.cs','tests/Riftbound.ConformanceTests/CurrentControllerDamageBonusTests.cs','tests/Riftbound.ConformanceTests/FullGameEndToEndTests.cs','docs/SELECTED_BATTLEFIELD_AOE_N54_PARALLEL_2026-10-23.md']+[x['manifest']for x in previous]
paths=[(str(p.relative_to(R)),p)for root in [Q]+sourceDirs for p in root.rglob('*')if p.is_file()]+[(x,R/x)for x in extra]+[('inputs/n54-fixed-overlay-v1.tar.gz',peer),('inputs/applied-n53-overlay-v1.json',n53receipt),('inputs/n53-fixed-overlay-v1.tar.gz',n53peer),('inputs/applied-n52-overlay-v1.json',n52receipt),('inputs/n52-fixed-overlay-v1.tar.gz',n52peer)]
assert len(paths)==len(set(n for n,p in paths));archive=D/'original-tests-fixed-inputs-and-sources-v1.tar.gz';members=[]
with archive.open('xb')as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as t:
   for name,p in sorted(paths):
    b=p.read_bytes();i=tarfile.TarInfo(name);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b));members.append({'path':name,'bytes':len(b),'sha256':sha(b)})
with tarfile.open(archive,'r:gz')as t:
 for m in members:
  b=t.extractfile(m['path']).read();assert len(b)==m['bytes']and sha(b)==m['sha256']
manifest={'status':'SCOPED_GREEN_ON_PEER_N54_V1','atUtc':datetime.now(timezone.utc).isoformat(),'baseCommit':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'region':'CN','peerOverlay':receipt,'frozenSpecifiedInputs':frozen,'all33SpecifiedInputsUnchanged':True,'actualRuleInputs':actual[0],'testAssemblySha256':sha(assembly.read_bytes()),'source':{'path':source,'sha256':sha((R/source).read_bytes())},'runs':runs,'histories':proof,'originalFailureReferences':previous,'canonicalCases':62,'canonicalLegalCases':32,'canonicalRejectedCases':30,'idempotentResubmissions':32,'allOriginalCommandPrefixes':178,'commands':178,'accepted':148,'rejected':30,'events':540,'historiesCount':78,'totalTests':138,'passed':138,'failed':0,'skipped':0,'methods':19,'originalFullGames':3,'noLocalRuntimeImplementationChanges':True,'noExtraCheckOrFull':True,'noSqlOrLiveApiOrColdRestart':True,'wholePrintingCertified':False,'backendGoalComplete':False,'archive':{'path':str(archive.relative_to(R)),'sha256':sha(archive.read_bytes()),'members':members}}
with(D/'source-and-green-test-manifest.json').open('x')as f:json.dump(manifest,f,ensure_ascii=False,indent=2)
print('Verified',len(members),'members,',archive.stat().st_size,'bytes;138PASS/19methods;178prefixes32duplicate')
