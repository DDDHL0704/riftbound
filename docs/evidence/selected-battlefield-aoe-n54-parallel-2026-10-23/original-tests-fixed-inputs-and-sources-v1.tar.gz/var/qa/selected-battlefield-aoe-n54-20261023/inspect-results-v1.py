from pathlib import Path
import json,gzip,hashlib,xml.etree.ElementTree as E
q=Path(__file__).parent;ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};rows=[]
for name in ['focus-v1','adjacent-and-games-v1']:
 p=q/name/'focus/results.trx'
 if p.exists():print(name,E.parse(p).find('.//t:Counters',ns).attrib)
f=json.loads((q/'frozen-inputs-v1.json').read_text());assert all(hashlib.sha256(Path(k).read_bytes()).hexdigest()==v for k,v in f['ruleInputs'].items())
for folder,expected in [('selected-original-v1',62),('untargeted-original-v1',12),('tibbers-original-v1',4)]:
 ps=sorted((q/folder).glob('*.gz'));assert len(ps)==expected
 for p in ps:
  x=json.loads(gzip.decompress(p.read_bytes()));assert x['failure']is None;assert len(x['commands'])==len(x['states'])==len(x['entries'])==x['originalPrefixReplayCount']
  assert[e for j in x['entries']for e in j['events']]==[e['event']for e in x['events']]
  if folder=='selected-original-v1':
   invalid=x['kind'].startswith('invalid-');assert len(x['commands'])==(1 if invalid else 3);assert all(c['accepted']!=invalid for c in x['commands']);assert len(x['duplicates'])==(0 if invalid else 1)
   if invalid:assert not x['events']and x['initial']==x['states'][0]
   for d in x['duplicates']:assert d['accepted']and d['journalBefore']==d['journalAfter']and d['beforeState']==d['afterState']
  es=[e['event']for e in x['events']];damage=[e['payload']for e in es if e['kind']=='DAMAGE_APPLIED'];row={'path':str(p),'caseId':x['caseId'],'family':folder,'kind':x.get('kind'),'card':x.get('card',x.get('cardNo',x.get('spell'))),'commands':len(x['commands']),'accepted':sum(c['accepted']for c in x['commands']),'events':len(es),'originalPrefixReplays':x['originalPrefixReplayCount'],'duplicates':len(x.get('duplicates',[])),'actualDamage':damage,'failure':x['failure']}
  rows.append(row)
print('Total histories',len(rows),'commands',sum(x['commands']for x in rows),'accepted',sum(x['accepted']for x in rows),'events',sum(x['events']for x in rows),'prefixes',sum(x['originalPrefixReplays']for x in rows),'duplicates',sum(x['duplicates']for x in rows))
with(q/'verified-results-v1.json').open('x')as f:json.dump(rows,f,ensure_ascii=False,indent=2)
