using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

Check(args.Length==2&&!File.Exists(args[1]),"Exact evidence directory and fresh independent output required.");
var work=Path.GetFullPath(args[0]);var output=Path.GetFullPath(args[1]);var json=new JsonSerializerOptions(JsonSerializerDefaults.Web){WriteIndented=true};
var settings=new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));Check(settings.Host=="127.0.0.1"&&settings.Port==55486&&settings.Database=="riftbound_acceptance"&&settings.Username=="codex_riftbound_audit","Only own audit database.");settings.Options="-c default_transaction_read_only=on";await using var source=NpgsqlDataSource.Create(settings.ConnectionString);
var results=new List<object>();var rooms=new List<string>();var totalStates=0;var totalSnapshots=0;var totalPrompts=0;var totalCommands=0;var totalEvents=0;var rejections=0;
foreach(var branch in new[]{"keep-reverse","recycle-one","recycle-two","short-empty","short-one"})
{
    var directory=Path.Combine(work,"candlelit-private-look",branch);using var receipt=JsonDocument.Parse(File.ReadAllText(Path.Combine(directory,"receipt.json")));var room=receipt.RootElement.GetProperty("room").GetString()!;rooms.Add(room);
    var initial=JsonSerializer.Deserialize<MatchState>(File.ReadAllText(Path.Combine(directory,"explicit-original-controlled-initial.json")),json)!;
    var frame=await new PostgresMatchRecoveryStore(source).LoadAsync(room,default)??throw new Exception("Real retained SQL frame required.");using var original=Read(Path.Combine(directory,"final-original-frame.json.gz"));
    Check(Same(original.RootElement,JsonSerializer.SerializeToElement(frame,json)),"Every original final SQL frame field/null/omission equals the actual independent read.");
    Check(frame.IsConsistent&&frame.Commands.Count==receipt.RootElement.GetProperty("commands").GetInt32()&&frame.Events.Count==receipt.RootElement.GetProperty("events").GetInt32()&&initial.RoomId==room&&initial.Tick==0&&initial.RuleInputs==RuleInputIdentity.Current&&frame.AuthoritativeState!.RuleInputs==RuleInputIdentity.Current,"Exact controlled initial and current frozen identity.");
    Check(frame.ReplayInitialState is {Tick:0,CardObjects.Count:0}&&!Same(JsonSerializer.SerializeToElement(initial,json),JsonSerializer.SerializeToElement(frame.ReplayInitialState,json)),"Original blank replay metadata remains separate; explicit original controlled initial is supplied only to the independent replay.");
    using var intents=JsonDocument.Parse(File.ReadAllText(Path.Combine(directory,"all-original-accepted-intents.json")));Check(intents.RootElement.GetArrayLength()==frame.Commands.Count,"All original intents retained.");
    for(var i=0;i<frame.Commands.Count;i++)Check(frame.Commands[i].Accepted&&frame.Commands[i].RuleInputs==RuleInputIdentity.Current&&frame.Commands[i].PlayerId==intents.RootElement[i].GetProperty("actor").GetString()&&Same(frame.Commands[i].RawCommand!.Value,intents.RootElement[i].GetProperty("rawCommand")),"Every actor/full raw command and identity equals the original accepted input.");
    var states=new Dictionary<(long,long),MatchState>();var counts=new Dictionary<string,int>();
    await using(var connection=await source.OpenConnectionAsync())
    {
        Check((string)(await new NpgsqlCommand("show transaction_read_only",connection).ExecuteScalarAsync())! =="on","Actual read-only SQL session.");
        await using(var q=new NpgsqlCommand("select last_event_sequence,payload::text from state_snapshots where match_id=@room order by id",connection))
        {
            q.Parameters.AddWithValue("room",room);await using var rows=await q.ExecuteReaderAsync();
            while(await rows.ReadAsync())
            {
                var raw=rows.GetString(1);var state=JsonSerializer.Deserialize<MatchState>(raw,json)!;
                Check(JsonNode.DeepEquals(JsonNode.Parse(raw),JsonSerializer.SerializeToNode(state,json))&&state.RuleInputs==RuleInputIdentity.Current&&states.TryAdd((state.Tick,rows.GetInt64(0)),state),"All original authority fields/nulls, current identity and tick/event-sequence identity survive independent read.");
                foreach(var item in state.StackItems.Where(i=>i.InsightContext?.Kind=="CONQUEST_LOOK"))Check(item.ControllerId=="P1"&&item.SourceObjectId=="BF"&&item.InsightContext is {Count:2,BattlefieldObjectId:"BF",ControllerId:"P1"}&&item.InsightContext.SourceGeneration==state.CardObjects["BF"].ObjectGeneration&&state.CardObjects["BF"].OwnerId=="P2","Literal captured conqueror, printed source/count/generation, and distinct battlefield owner.");
                if(state.PendingCardChoice is {ChoiceWindow:"INSIGHT"} choice)Check(choice.PlayerId=="P1"&&choice.RequiredCount==0&&choice.MaxCount==Math.Min(2,initial.PlayerZones["P1"].MainDeck.Count)&&choice.LegalObjectIds.SequenceEqual(initial.PlayerZones["P1"].MainDeck.Take(2)),"Literal private zero-to-available original top subset at every historical look.");
            }
        }
        Check(states.Count==frame.Commands.Count&&frame.Commands.All(c=>states.ContainsKey((c.CompletedTick,c.CompletedEventSequence))),"Each accepted command retains its exact authoritative historical row.");
        var latest=frame.Commands.GroupBy(c=>c.CompletedTick).Select(g=>g.OrderBy(c=>c.CompletedEventSequence).Last()).ToArray();var expected=latest.SelectMany(c=>new[]{"P1","P2"}.Select(p=>(c.CompletedTick,c.CompletedEventSequence,p))).ToHashSet();
        foreach(var table in new[]{"snapshots","action_prompts"})
        {
            var column=table=="snapshots"?"snapshot_tick":"prompt_tick";await using(var constraint=new NpgsqlCommand($"select pg_get_constraintdef(oid) from pg_constraint where conrelid='{table}'::regclass and contype='u'",connection))Check((string)(await constraint.ExecuteScalarAsync())! ==$"UNIQUE (match_id, player_id, {column})","Actual existing private storage key is viewer/tick.");
            await using var q=new NpgsqlCommand($"select player_id,last_event_sequence,payload::text from {table} where match_id=@room order by id",connection);q.Parameters.AddWithValue("room",room);await using var rows=await q.ExecuteReaderAsync();var actual=new HashSet<(long,long,string)>();
            while(await rows.ReadAsync())
            {
                var actor=rows.GetString(0);var sequence=rows.GetInt64(1);var raw=rows.GetString(2);using var doc=JsonDocument.Parse(raw);var tick=doc.RootElement.GetProperty(table=="snapshots"?"tick":"snapshotTick").GetInt64();Check(states.TryGetValue((tick,sequence),out var state)&&actual.Add((tick,sequence,actor)),"Each private original row binds its original authority, sequence, tick and viewer.");
                var typed=table=="snapshots"?JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<SnapshotDto>(raw,json),json):JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<ActionPromptDto>(raw,json),json);Check(JsonNode.DeepEquals(JsonNode.Parse(raw),typed),"Every private field/null and conditional omission survives typed read.");
                var projection=table=="snapshots"?JsonSerializer.SerializeToNode(ResolutionResult.BuildSnapshots(state!)[actor],json):JsonSerializer.SerializeToNode(ResolutionResult.BuildPrompts(state!)[actor],json);Check(JsonNode.DeepEquals(JsonNode.Parse(raw),projection),"Every original private value equals its exact historical state projection.");
                var other=actor=="P1"?"P2":"P1";foreach(var id in state!.PlayerZones[other].MainDeck.Concat(state.PlayerZones[other].Hand))Check(!raw.Contains("\""+id+"\"",StringComparison.Ordinal),"Independent literal check: opponent hidden object identity absent.");Check(!doc.RootElement.TryGetProperty("openingSeed",out _),"Private opening seed not exposed.");
            }
            Check(actual.SetEquals(expected),"Both players retain exactly the latest original projection at each tick according to the actual existing key; no missing historical authority.");counts[table]=actual.Count;
        }
    }
    using var capturedOriginal=Read(Path.Combine(directory,"before-response-original-frame.json.gz"));var captured=capturedOriginal.RootElement.Deserialize<MatchRecoveryFrame>(json)!;var capturedState=captured.AuthoritativeState!;
    Check(Same(JsonSerializer.SerializeToElement(frame.Commands.Take(captured.Commands.Count),json),capturedOriginal.RootElement.GetProperty("commands"))&&Same(JsonSerializer.SerializeToElement(frame.Events.Take(captured.Events.Count),json),capturedOriginal.RootElement.GetProperty("events")),"Original response checkpoint commands/events are an unchanged exact final prefix.");
    Check(MatchRecoveryValidator.Validate(room,captured.LastEventSequence,captured.Commands,captured.Events,captured.PlayerViews,capturedState,captured.CurrentTick).Count==0,"Genuine original capture is structurally valid before independent mutations.");
    var capturedItem=capturedState.StackItems.Single();
    foreach(var field in new[]{"count","source","battlefield","generation"})
    {
        var context=capturedItem.InsightContext!;var item=capturedItem;
        if(field=="source")item=item with {SourceObjectId="UNIT"};else context=field switch {"count"=>context with {Count=99},"battlefield"=>context with {BattlefieldObjectId="UNIT"},_=>context with {SourceGeneration=99}};
        var forged=capturedState with {StackItems=[item with {InsightContext=context}]};Check(MatchRecoveryValidator.Validate(room,captured.LastEventSequence,captured.Commands,captured.Events,captured.PlayerViews,forged,captured.CurrentTick).Count>0,"Independent literal captured-source structural mutation rejected: "+field);rejections++;
    }
    var final=frame.AuthoritativeState!;Check(final.PlayerScores["P1"]==1&&final.PlayerScores["P2"]==0&&final.Status==MatchStatuses.InProgress&&final.PendingCardChoice is null&&final.StackItems.Count==0,"Literal one conquest and no residual window/extra score.");
    Check(frame.Events.All(e=>e.Event.Kind is not("CARDS_REVEALED" or "CARD_DRAWN" or "MAIN_DECK_BURNED_OUT")),"No reveal, draw or burnout in any original event.");
    var deck=final.PlayerZones["P1"].MainDeck;
    if(branch=="keep-reverse")Check(deck.SequenceEqual(new[]{"DRAW2","DRAW1","DRAW3"})&&final.RngCursor==initial.RngCursor,"Literal selected reverse top order and unchanged RNG for zero recycle.");
    if(branch=="recycle-one")Check(deck.SequenceEqual(new[]{"DRAW2","DRAW3","DRAW1"})&&final.RngCursor==initial.RngCursor,"Exactly one selected card at bottom.");
    if(branch=="recycle-two")Check(deck[0]=="DRAW3"&&deck.Skip(1).Order().SequenceEqual(new[]{"DRAW1","DRAW2"})&&final.RngCursor==initial.RngCursor+1,"Exactly selected pair randomized once, preserving original seed.");
    if(branch.StartsWith("short-",StringComparison.Ordinal))Check(deck.SequenceEqual(initial.PlayerZones["P1"].MainDeck),"Literal short original deck retained.");
    var replay=await MatchActionLogReplayer.VerifyFinalStateAsync(initial,frame.Commands,final,new CoreRuleEngine(),default,frame.Events);Check(replay.IsMatch,string.Join(';',replay.Errors));
    totalStates+=states.Count;totalSnapshots+=counts["snapshots"];totalPrompts+=counts["action_prompts"];totalCommands+=frame.Commands.Count;totalEvents+=frame.Events.Count;results.Add(new{branch,room,commands=frame.Commands.Count,events=frame.Events.Count,states=states.Count,snapshots=counts["snapshots"],prompts=counts["action_prompts"],allFieldsAndOriginalActionEventReplayExact=true});
}
await File.WriteAllTextAsync(output,JsonSerializer.Serialize(new{status="PASS_INDEPENDENT_FINAL_ROOT_CANDLELIT_FIVE_ALL_SQL_HISTORY_PRIVATE_FIELDS_LITERAL_BRANCHES_AND_EXPLICIT_INITIAL_REPLAY",rooms,cases=5,commands=totalCommands,events=totalEvents,authoritativeHistoricalStates=totalStates,privateSnapshots=totalSnapshots,privatePrompts=totalPrompts,independentStructuralRejections=rejections,actualRuleInputs=RuleInputIdentity.Current,results,actualReadOnlyConnection=true,originalBlankReplayMetadataNotRewritten=true,visibleNormalOpeningWindowsOrWholePrintingAcceptance=false},json));
Console.WriteLine($"CANDLELIT_ROOT_INDEPENDENT_PASS {totalCommands} commands {totalEvents} events {totalStates} states {totalSnapshots} snapshots {totalPrompts} prompts {rejections} structural rejects");
bool Same(JsonElement left,JsonElement right)=>JsonNode.DeepEquals(JsonNode.Parse(left.GetRawText()),JsonNode.Parse(right.GetRawText()));
static JsonDocument Read(string path){using var zip=new GZipStream(File.OpenRead(path),CompressionMode.Decompress);return JsonDocument.Parse(zip);}
static void Check(bool value,string message){if(!value)throw new Exception(message);}
