from pathlib import Path
import datetime, hashlib, json, os, resource, shutil, subprocess, time

resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
os.umask(0o077)
w = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
load = lambda p: json.loads(p.read_text())
pub = load(w / 'frozen-final-root-inputs-v1.json')
old = Path(pub['runtimeRoot'])
r = w / 'independent-reader-runtime-v1'
r.mkdir(exist_ok=False)
assert all(sha(old / p) == h for p, h in pub['runtimeFiles'].items())
for p in old.rglob('*'):
    if p.is_file():
        q = r / p.relative_to(old)
        q.parent.mkdir(parents=True, exist_ok=True)
        os.link(p, q)
dll = w / 'independent-reader-source-v1/bin/Release/net10.0/FinalRootCandlelitIndependentSqlReaderV1.dll'
shutil.copyfile(dll, r / dll.name)
files = {str(p.relative_to(r)): sha(p) for p in r.rglob('*') if p.is_file()}
assert len(files) == 91
result = w / 'independent-final-root-candlelit-history-result-v1.json'
receipt = w / 'independent-final-root-candlelit-history-run-v1.json'
stop = w / 'actual-final-root-five-candlelit-sql-stop-v2.json'
assert not any(p.exists() for p in [result, receipt, stop])
command = ['/Users/dinghaolin/.dotnet/dotnet', 'exec', '--depsfile', str(r / 'Riftbound.PostgresAcceptance.deps.json'), '--runtimeconfig', str(r / 'Riftbound.PostgresAcceptance.runtimeconfig.json'), str(r / dll.name), str(w), str(result)]
proof = {'startedAtUtc': now(), 'parentCommit': pub['parentCommit'], 'actualRuleInputs': pub['actualRuleInputs'], 'command': command, 'readerRuntimeFiles': files, 'status': 'WAITING_FINAL_ROOT_WRITER_READINESS'}
try:
    ready_path = w / 'actual-final-root-five-candlelit-sql-ready-v2.json'
    until = time.monotonic() + 600
    while not ready_path.exists():
        assert time.monotonic() < until and not (w / 'actual-final-root-five-candlelit-sql-owner-terminal-v2.json').exists()
        time.sleep(1)
    ready = load(ready_path)
    with (w / 'independent-final-root-candlelit-history-v1.log').open('xb') as f:
        code = subprocess.run(command, cwd=r, env=dict(os.environ, ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit', DOTNET_DbgEnableMiniDump='0'), stdout=f, stderr=subprocess.STDOUT, timeout=300).returncode
    proof['exitCode'] = code
    assert code == 0
    d = load(result)
    assert d['status'] == 'PASS_INDEPENDENT_FINAL_ROOT_CANDLELIT_FIVE_ALL_SQL_HISTORY_PRIVATE_FIELDS_LITERAL_BRANCHES_AND_EXPLICIT_INITIAL_REPLAY'
    assert d['cases'] == 5 and d['commands'] == ready['commands'] == 30 and d['events'] == ready['events'] == 90
    assert d['authoritativeHistoricalStates'] == 30 and d['privateSnapshots'] == d['privatePrompts'] == 60
    assert d['independentStructuralRejections'] == 20 and d['actualRuleInputs'] == pub['actualRuleInputs'] and set(d['rooms']) == set(ready['newRooms'])
    assert all(sha(r / p) == h for p, h in files.items()) and all(sha(old / p) == h for p, h in pub['runtimeFiles'].items())
    proof.update(status=d['status'], allOriginalFrozenRuntimeFilesExact=True, counts={k: d[k] for k in ['cases', 'commands', 'events', 'authoritativeHistoricalStates', 'privateSnapshots', 'privatePrompts', 'independentStructuralRejections']}, resultSha256=sha(result))
    stop.write_text(json.dumps({'atUtc': now(), 'independentReadOnlyAllHistoryAndReplayPass': True, 'rooms': d['rooms'], 'result': str(result), 'resultSha256': sha(result), 'counts': proof['counts'], 'fixedCandidateFullVisibleWindowsAndWholePrintingAcceptance': 'OPEN'}, indent=2))
except BaseException as e:
    proof.update(status='FAILED_OR_INTERRUPTED_FINAL_ROOT_READ_ONLY_READER_NO_WRITER_RERUN', errorType=type(e).__name__, error=str(e))
    raise
finally:
    proof['finishedAtUtc'] = now()
    receipt.write_text(json.dumps(proof, indent=2))
print(proof['status'], flush=True)
