import ast, datetime, fcntl, hashlib, json, os, plistlib, resource, socket, subprocess, time
from pathlib import Path

resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
os.umask(0o077)
root = Path('/Users/dinghaolin/MyProjects/riftbound')
w = Path(__file__).resolve().parent
pg = Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin')
cluster = root / 'var/qa/permanent-play-here-base-20261017/postgres'
sock = Path('/tmp/rft-here-family-20261018-55486')
tables = ['matches', 'match_players', 'command_log', 'game_events', 'state_snapshots', 'snapshots', 'action_prompts']
read_env = dict(os.environ, PGOPTIONS='-c default_transaction_read_only=on')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
load = lambda p: json.loads(p.read_text())
definition = root / 'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes = [n for n in ast.parse(definition.read_text()).body if isinstance(n, ast.FunctionDef) and n.name in {'query', 'rooms', 'digests', 'observe_lock'}]
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(definition), 'exec'), globals())
pub = load(w / 'frozen-final-root-inputs-v1.json')
r = Path(pub['runtimeRoot'])
previous = load(w.parent / 'actual-five-candlelit-sql-owner-terminal-v1.json')
original = load(root / 'var/qa/canonical-room-player-identity-20261021/actual-safe-native-main-v1/original231-audit48-native-seven-table-baseline-v1.json')
assert previous['ownPostgresSmartStopped'] and previous['status'].startswith('PASS_')
ready = w / 'actual-final-root-five-candlelit-sql-ready-v2.json'
stop = w / 'actual-final-root-five-candlelit-sql-stop-v2.json'
terminal = w / 'actual-final-root-five-candlelit-sql-owner-terminal-v2.json'
assert not any(p.exists() for p in [ready, stop, terminal])
def frozen():
    assert all(sha(r / p) == h for p, h in pub['runtimeFiles'].items())
    assert all(sha(root / p) == h for p, h in pub['sourceInputHashes'].items())
    assert all(oct((root / p).stat().st_mode & 0o777) == m for p, m in pub['sourceInputModes'].items())
guard = (root / 'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a')
fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
proof = {'status': 'RUNNING_FINAL_ROOT_FIVE_CONTROLLED_CANDLELIT_SQL_CASES_NOT_FULL_CARD_OR_NATIVE', 'startedAtUtc': now(), 'parentCommit': pub['parentCommit'], 'actualRuleInputs': pub['actualRuleInputs'], 'lockAtStart': observe_lock(), 'controlledOriginalSourceFixturesOnly': True}
power = writer = None
started = False
audit = native = before_audit = before_native = None
try:
    frozen()
    assert subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), 'status'], capture_output=True).returncode == 3
    with socket.socket() as s: assert s.connect_ex(('127.0.0.1', 15847)) != 0
    power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())])
    proof['boundIdleAssertionPid'] = power.pid
    sock.mkdir(exist_ok=True)
    subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-l', str(w / 'own-postgres-v2.log'), '-o', f'-p 55486 -h 127.0.0.1 -k {sock}', '-w', 'start'], capture_output=True, check=True)
    started = True
    audit = rooms('riftbound_acceptance')
    native = rooms('riftbound_here_native')
    assert audit == previous['actualAuditRoomsAtStop'] and len(audit) == 236
    assert native == previous['actualNativeRoomsAtStop'] and len(native) == 50
    before_audit = digests('riftbound_acceptance', audit)
    before_native = digests('riftbound_here_native', native)
    assert digests('riftbound_acceptance', original['auditRooms']) == original['auditSevenTables']
    assert digests('riftbound_here_native', original['nativeRooms']) == original['nativeSevenTables']
    (w / 'original236-audit50-native-seven-table-baseline-v2.json').write_text(json.dumps({'atUtc': now(), 'auditRooms': audit, 'nativeRooms': native, 'auditSevenTables': before_audit, 'nativeSevenTables': before_native}, indent=2))
    command = ['/Users/dinghaolin/.dotnet/dotnet', str(r / 'Riftbound.PostgresAcceptance.dll'), '--candlelit-private-look-only']
    proof['command'] = command
    with (w / 'actual-final-root-five-candlelit-writer-v2.log').open('xb') as f:
        writer = subprocess.Popen(command, cwd=r, env=dict(os.environ, ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit', RIFTBOUND_POSTGRES_EVIDENCE=str(w), DOTNET_DbgEnableMiniDump='0'), stdout=f, stderr=subprocess.STDOUT)
        assert writer.wait(timeout=540) == 0
    receipts = [load(w / 'candlelit-private-look' / branch / 'receipt.json') for branch in ['keep-reverse', 'recycle-one', 'recycle-two', 'short-empty', 'short-one']]
    assert all(c['status'].startswith('REAL_SQL_CURRENT_CANDLELIT_') and c['actualRuleInputs'] == pub['actualRuleInputs'] and c['coldRecoveries'] == c['commands'] for c in receipts)
    added = {c['room'] for c in receipts}
    assert len(added) == 5 and set(rooms('riftbound_acceptance')) == set(audit) | added
    assert rooms('riftbound_here_native') == native and digests('riftbound_acceptance', audit) == before_audit and digests('riftbound_here_native', native) == before_native
    proof.update(status='FINAL_ROOT_FIVE_CANDLELIT_SQL_WRITER_PASS_INDEPENDENT_ALL_HISTORY_PENDING', newRooms=sorted(added), cases=5, commands=sum(c['commands'] for c in receipts), events=sum(c['events'] for c in receipts), coldRecoveries=sum(c['coldRecoveries'] for c in receipts), directAtomicRejections=sum(c['directAtomicRejections'] for c in receipts), independentStructuralRejections=sum(c['independentStructuralRejections'] for c in receipts))
    ready.write_text(json.dumps(proof, indent=2))
    print('WRITER_PASS_WAITING_INDEPENDENT_READ_ONLY_HISTORY', flush=True)
    until = time.monotonic() + 900
    while not stop.exists():
        assert time.monotonic() < until
        time.sleep(.2)
    completed = load(stop)
    assert completed['independentReadOnlyAllHistoryAndReplayPass'] and set(completed['rooms']) == added
    proof.update(status='PASS_FINAL_ROOT_FIVE_CURRENT_CANDLELIT_SQL_COLD_DEDUP_STRUCTURAL_REJECTION_AND_INDEPENDENT_ALL_HISTORY_REPLAY', independentReadback=completed)
except BaseException as e:
    proof.update(status='FAILED_OR_INTERRUPTED_FINAL_ROOT_CANDLELIT_ORIGINALS_AND_NEW_ROOMS_RETAINED', errorType=type(e).__name__, error=str(e))
    raise
finally:
    if writer is not None and writer.poll() is None: writer.terminate(); writer.wait(timeout=20)
    if started:
        if before_audit is not None:
            proof['allOriginal236AuditSevenTablesExactAtStop'] = digests('riftbound_acceptance', audit) == before_audit
            proof['allOriginal50NativeSevenTablesExactAtStop'] = digests('riftbound_here_native', native) == before_native
            proof['actualAuditRoomsAtStop'] = rooms('riftbound_acceptance')
            proof['actualNativeRoomsAtStop'] = rooms('riftbound_here_native')
        proof['ownPostgresSmartStopped'] = subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-m', 'smart', '-w', '-t', '20', 'stop'], capture_output=True).returncode == 0
    if power is not None:
        if power.poll() is None: power.terminate(); power.wait(timeout=10)
        proof['boundIdleAssertionEnded'] = power.poll() is not None
    frozen()
    proof.update(finishedAtUtc=now(), lockAtEnd=observe_lock(), finalRootSourcesModesAndFrozenRuntimeHashesStable=True)
    terminal.write_text(json.dumps(proof, indent=2))
    fcntl.flock(guard, fcntl.LOCK_UN)
print(proof['status'], flush=True)
