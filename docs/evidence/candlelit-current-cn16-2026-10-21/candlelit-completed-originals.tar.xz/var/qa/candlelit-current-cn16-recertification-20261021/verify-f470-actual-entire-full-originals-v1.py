from pathlib import Path
import ast, collections, datetime, gzip, hashlib, json, re, subprocess, xml.etree.ElementTree as ET, zipfile

w = Path(__file__).resolve().parent; root = w.parents[2]
fixed = 'f4704291ff87c99b1599d93f0fc71700f0433cae'; run = 39499635645
load = lambda p: json.loads(p.read_text()); sha = lambda b: hashlib.sha256(b).hexdigest()
terminal = load(w / 'ci-39499635645-before-final49-publication-v1.json')
metadata = load(w / 'preceding-f470-actual-terminal-artifacts-original-v1.json'); artifacts = {a['name']: a for a in metadata['artifacts']}
assert terminal['headSha'] == fixed and terminal['status'] == 'completed' and terminal['conclusion'] == 'success' and len(terminal['jobs']) == 11 and all(j['status'] == 'completed' and j['conclusion'] == 'success' for j in terminal['jobs'])
out = w / 'preceding-f470-actual-full-final-originals-v1'; out.mkdir(exist_ok=False)
originals = []
for name in ['conformance-results', 'full-verification-gate']:
    a = artifacts[name]; assert a['workflow_run']['head_sha'] == fixed and not a['expired']; p = out / (name + '.zip')
    with p.open('xb') as stream: subprocess.run(['gh', 'api', f'repos/DDDHL0704/riftbound/actions/artifacts/{a["id"]}/zip'], stdout=stream, check=True)
    assert p.stat().st_size == a['size_in_bytes'] and 'sha256:' + sha(p.read_bytes()) == a['digest']
    with zipfile.ZipFile(p) as z: assert z.testzip() is None
    originals.append({'name': name, 'artifactId': a['id'], 'path': str(p.relative_to(root)), 'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes()), 'backendSizeDigestAndAllCrcExact': True})
ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def collect(path, with_plan=False):
    cases = collections.Counter(); methods = set(); matrices = []; trx_hashes = {}
    with zipfile.ZipFile(path) as z:
        if with_plan:
            assert z.read('ci-rule-suite-commit.txt').decode().strip() == fixed
            plan = json.loads(z.read('ci-rules/plan.json')); summary = json.loads(z.read('ci-rules/summary.json'))
            assert summary['status'] == 'PASSED' and summary['profile'] == 'full' and summary['total'] == 13363
            planned = [m for s in plan['shards'] for m in s['methods']]; assert len(planned) == len(set(planned)) == plan['discoveredMethods'] == 7640
            assert all(s['total'] == s['passed'] and not s['failed'] and not s['notExecuted'] for s in summary['shards'])
        for name in z.namelist():
            if not name.endswith('/results.trx'): continue
            raw = z.read(name); trx_hashes[name] = sha(raw); t = ET.fromstring(raw); actual = set()
            definitions = {d.attrib['id']: d.find('t:TestMethod', ns).attrib for d in t.findall('.//t:UnitTest', ns)}
            for r in t.findall('.//t:UnitTestResult', ns):
                assert r.attrib['outcome'] == 'Passed'; d = definitions[r.attrib['testId']]; method = d['className'] + '.' + d['name']; methods.add(method); actual.add(method); cases[r.attrib['testName']] += 1
                for output in r.findall('.//t:StdOut', ns):
                    for line in (output.text or '').splitlines():
                        if line.startswith('PRECONSTRUCTED_MATRIX '): matrices.append(json.loads(line[len('PRECONSTRUCTED_MATRIX '):]))
            if with_plan: assert actual == set(next(s['methods'] for s in plan['shards'] if s['name'] == name.split('/')[-2]))
        if with_plan: assert methods == set(planned) and sum(cases.values()) == 13363
    return cases, methods, matrices, trx_hashes
current_zip = out / 'conformance-results.zip'; cases, methods, matrices, trx_hashes = collect(current_zip, True)
previous = load(root / 'var/qa/canonical-room-player-identity-20261021/preceding-a56137-entire-full-independent-original-verification-v1.json')
old_artifact = next(a for a in previous['originalArtifacts'] if a['name'] == 'conformance-results'); old_zip = root / old_artifact['path']; assert sha(old_zip.read_bytes()) == old_artifact['sha256']
before_cases, before_methods, _, _ = collect(old_zip)
assert sum(before_cases.values()) == 13325 and len(before_methods) == 7635 and not before_cases - cases and before_methods <= methods
assert sum((cases - before_cases).values()) == 38 and len(methods - before_methods) == 5
assert all('SpellRemakeSingleTargetCompletionTests' in m for m in methods - before_methods)
full_sources = {}; expected = set()
for p in sorted((root / 'tests/Riftbound.ConformanceTests').glob('FullGameEndToEndTests*.cs')):
    rel = str(p.relative_to(root)); raw = subprocess.check_output(['git', 'show', fixed + ':' + rel], cwd=root); assert p.read_bytes() == raw; full_sources[rel] = sha(raw)
    expected.update('Riftbound.ConformanceTests.FullGameEndToEndTests.' + m for m in re.findall(r'\bpublic\s+(?:async\s+)?(?:Task|void)\s+(\w+)\s*\(', raw.decode()))
assert len(full_sources) == 9 and len(expected) == 143 and {m for m in methods if m.startswith('Riftbound.ConformanceTests.FullGameEndToEndTests.')} == expected
assert len(matrices) == 1; matrix = matrices[0]
deck_path = root / 'var/qa/graveyard-source-fixed-candidate-20261020/native-visible-v1/live-api-eleven-preconstructed-decks-original.json.gz'; decks = json.loads(gzip.decompress(deck_path.read_bytes())); deck_ids = [d['id'] for d in decks]; expected_pairs = {a + '-vs-' + b for a in deck_ids for b in deck_ids if a != b}
assert len(deck_ids) == len(set(deck_ids)) == 11 and matrix['seed'] == 424242 and matrix['deckCount'] == 11 and matrix['pairCount'] == 110 and len(matrix['completed']) == 110 and set(matrix['completed']) == expected_pairs and all(re.fullmatch('[0-9a-f]{64}', h) for h in matrix['completed'].values())
sql = load(w / 'preceding-f470-all4-sql-and-network-original-readback-v2.json'); assert sql['status'].startswith('PASS_FIXED_F470_') and sql['outputFiles'] == 320 and len(sql['partitions']) == 4
for artifact in sql['artifacts']:
    a = artifacts[artifact['name']]; p = root / artifact['path']; assert p.stat().st_size == a['size_in_bytes'] and 'sha256:' + sha(p.read_bytes()) == a['digest'] and sha(p.read_bytes()) == artifact['sha256']; originals.append(artifact)
with zipfile.ZipFile(out / 'full-verification-gate.zip') as z:
    gate = json.loads(z.read('result.json')); assert gate['status'] == 'FIXED_COMMIT_FULL_CHILD_JOBS_ALL_SUCCEEDED' and gate['commit'] == fixed and all(v == 'success' for v in gate['jobs'].values())
with zipfile.ZipFile(root / next(a['path'] for a in sql['artifacts'] if a['name'] == 'postgres-results')) as z:
    actual = json.loads(z.read('result.json')); independent = sql['actualGateIndependentResult']; assert actual == independent
source = root / 'scripts/audit/check-project-governance.py'; function = next(n for n in ast.parse(source.read_text()).body if isinstance(n, ast.FunctionDef) and n.name == 'gameplay_path'); exec(compile(ast.Module(body=[function], type_ignores=[]), str(source), 'exec'), globals())
blobs = []
for row in subprocess.check_output(['git', 'ls-tree', '-rz', fixed], cwd=root).split(b'\0'):
    if not row: continue
    header, name = row.split(b'\t', 1); mode, kind, blob = header.decode().split(); path = name.decode()
    if kind == 'blob' and gameplay_path(path): blobs.append((path, blob))
batch = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=root, stdin=subprocess.PIPE, stdout=subprocess.PIPE); raw, _ = batch.communicate(('\n'.join(b for _, b in blobs) + '\n').encode()); assert batch.returncode == 0; offset = 0; inputs = {}
for path, blob in blobs:
    end = raw.index(b'\n', offset); got, kind, size = raw[offset:end].decode().split(); assert got == blob and kind == 'blob'; offset = end + 1; payload = raw[offset:offset + int(size)]; inputs[path] = sha(payload); offset += int(size) + 1
assert offset == len(raw) and inputs
result = {'status': 'FIXED_COMMIT_FULL_CI_AND_PARITY_VERIFIED', 'verifiedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'commit': fixed, 'runId': run, 'url': terminal['url'], 'jobs': {j['name']: j['conclusion'] for j in terminal['jobs']}, 'actualCases': 13363, 'actualMethods': 7640, 'fullGameMethods': 143, 'preconstructedPairs': 110, 'decks': 11, 'seed': 424242, 'allOriginal13325CasesAnd7635MethodsRetained': True, 'addedCases': 38, 'addedMethods': 5, 'originalTrxSha256': trx_hashes, 'originalFullGameSourceHashes': full_sources, 'originalMatrix': matrix, 'sqlCases': 48, 'sqlOriginalOutputs': 320, 'sqlPartitions': sql['partitions'], 'actualSqlRuleInputs': sql['actualCiRuleInputs'], 'runtimeBinariesNotUploadedNotClaimedIndependentlyDownloaded': True, 'network': sql['originalNativeNetworkEvidence'], 'gameplaySourceInputs': {'commit': fixed, 'files': inputs, 'derivedFromExactGitBlobsWithoutCheckoutOrBuild': True}, 'originalArtifacts': originals, 'oldDesktopJobsActuallySucceededOldPackagesNotDownloadedBecauseLatestC2PairAlreadyVerified': True, 'currentC2AndNew49SqlCandidateNotCovered': True, 'visibleCurrentPairedPhysicalWindowsWholePrintingAndGoalCompletion': False}
with (w / 'preceding-f470-entire-full-independent-original-verification-v1.json').open('x') as f: json.dump(result, f, indent=2)
print('PASS fixedf470 all11 success;13363/7640;old13325/7635 retained+38/5;143 full110 pairs;SQL48/320;network15/0; currentC2/49 remain separate', flush=True)
