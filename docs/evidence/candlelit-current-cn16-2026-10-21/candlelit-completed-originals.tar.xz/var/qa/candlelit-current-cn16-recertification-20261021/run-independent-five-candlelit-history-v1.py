from pathlib import Path
import datetime,hashlib,json,os,resource,shutil,subprocess
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
w=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();load=lambda p:json.loads(p.read_text())
pub=load(w/'fixed-f470-sql-runtime-v1.json');ready=load(w/'actual-five-candlelit-sql-ready-v1.json');old=w/'fixed-f470-sql-runtime-v1';r=w/'independent-fixed-f470-reader-runtime-v1';r.mkdir(exist_ok=False)
assert all(sha(old/p)==h for p,h in pub['runtimeFiles'].items())
for p in old.rglob('*'):
    if p.is_file():q=r/p.relative_to(old);q.parent.mkdir(parents=True,exist_ok=True);os.link(p,q)
p=w/'independent-reader-source-v1/bin/Release/net10.0/CurrentCandlelitIndependentSqlReaderV1.dll';shutil.copyfile(p,r/p.name);files={str(p.relative_to(r)):sha(p) for p in r.rglob('*') if p.is_file()};assert len(files)==49
result=w/'independent-five-candlelit-history-result-v1.json';receipt=w/'independent-five-candlelit-history-run-v1.json';stop=w/'actual-five-candlelit-sql-stop-v1.json';assert not any(p.exists() for p in [result,receipt,stop])
command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(r/'Riftbound.Api.deps.json'),'--runtimeconfig',str(r/'Riftbound.Api.runtimeconfig.json'),str(r/'CurrentCandlelitIndependentSqlReaderV1.dll'),str(w),str(result)]
proof={'startedAtUtc':now(),'fixedCommit':pub['fixedCommit'],'actualRuleInputs':pub['actualRuleInputs'],'command':command,'readerRuntimeFiles':files,'status':'RUNNING_READ_ONLY_ORIGINAL_FIVE_SQL_HISTORIES'}
try:
    with (w/'independent-five-candlelit-history-v1.log').open('xb') as f:
        code=subprocess.run(command,cwd=r,env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit',DOTNET_DbgEnableMiniDump='0'),stdout=f,stderr=subprocess.STDOUT,timeout=300).returncode
    proof['exitCode']=code;assert code==0
    d=load(result);assert d['status']=='PASS_INDEPENDENT_FIXED_F470_CANDLELIT_FIVE_ALL_SQL_HISTORY_PRIVATE_FIELDS_LITERAL_BRANCHES_AND_EXPLICIT_INITIAL_REPLAY' and d['cases']==5 and d['commands']==ready['commands']==30 and d['events']==ready['events']==90 and d['authoritativeHistoricalStates']==30 and d['independentStructuralRejections']==20 and d['actualRuleInputs']==pub['actualRuleInputs'] and set(d['rooms'])==set(ready['newRooms'])
    assert all(sha(r/p)==h for p,h in files.items()) and all(sha(old/p)==h for p,h in pub['runtimeFiles'].items())
    proof.update(status=d['status'],allOriginalFrozenRuntimeFilesExact=True,counts={k:d[k] for k in ['cases','commands','events','authoritativeHistoricalStates','privateSnapshots','privatePrompts','independentStructuralRejections']},resultSha256=sha(result))
    stop.write_text(json.dumps({'atUtc':now(),'independentReadOnlyAllHistoryAndReplayPass':True,'rooms':d['rooms'],'result':str(result),'resultSha256':sha(result),'counts':proof['counts'],'fixedCandidateFullVisibleWindowsAndWholePrintingAcceptance':'OPEN'},indent=2))
except BaseException as e:
    proof.update(status='FAILED_OR_INTERRUPTED_READ_ONLY_READER_NO_WRITER_RERUN',errorType=type(e).__name__,error=str(e));raise
finally:
    proof['finishedAtUtc']=now();receipt.write_text(json.dumps(proof,indent=2))
print(proof['status'],flush=True)
