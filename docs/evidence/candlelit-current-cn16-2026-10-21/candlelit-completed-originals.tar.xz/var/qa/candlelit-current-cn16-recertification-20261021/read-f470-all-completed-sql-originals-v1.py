from pathlib import Path
import datetime, hashlib, importlib.util, json, math, subprocess, zipfile

w = Path(__file__).resolve().parent; root = w.parents[2]
fixed = 'f4704291ff87c99b1599d93f0fc71700f0433cae'
load = lambda p: json.loads(p.read_text()); sha = lambda b: hashlib.sha256(b).hexdigest()
metadata = load(w / 'preceding-f470-all4-sql-ready-artifacts-original-v1.json')
jobs = load(w / 'ci-39499635645-after-current-c2-normal-score-v1.json')
assert jobs['headSha'] == fixed and jobs['status'] == 'in_progress'
required = ['scope', 'native_network', 'postgres'] + ['postgres_partitions (' + str(i) + ')' for i in range(4)]
assert all(next(j for j in jobs['jobs'] if j['name'] == name)['conclusion'] == 'success' for name in required)
out = w / 'preceding-f470-all4-sql-originals-v1'; out.mkdir(exist_ok=False)
raw_manifest = subprocess.check_output(['git', 'show', fixed + ':tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'], cwd=root)
(out / 'fixed-original48-sql-manifest.json').write_bytes(raw_manifest)
ids = [r['id'] for r in json.loads(raw_manifest)['cases']]; assert len(ids) == len(set(ids)) == 48
old = load(root / 'var/qa/canonical-room-player-identity-20261021/fixed-f470-only-parts12-original-independent-readback-v1.json')
rows = []; downloads = []; reference_inputs = reference_runtime = None
def get_archive(name, reused=None):
    a = next(x for x in metadata['artifacts'] if x['name'] == name)
    assert a['workflow_run']['head_sha'] == fixed and not a['expired']
    target = reused if reused else out / (name + '.zip')
    if reused is None:
        with target.open('xb') as f: subprocess.run(['gh', 'api', f'repos/DDDHL0704/riftbound/actions/artifacts/{a["id"]}/zip'], stdout=f, check=True)
    raw = target.read_bytes(); digest = sha(raw)
    assert len(raw) == a['size_in_bytes'] and a['digest'] == 'sha256:' + digest
    with zipfile.ZipFile(target) as z: assert z.testzip() is None
    downloads.append({'name': name, 'artifactId': a['id'], 'path': str(target.relative_to(root)), 'bytes': len(raw), 'sha256': digest, 'backendDigestSizeAndEveryOuterCrcExact': True, 'existingOriginalReusedWithoutDuplicateDownload': reused is not None})
    return target
result = {'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': 'RUNNING_INDEPENDENT_FIXED_F470_ALL4_SQL_ORIGINAL_READBACK', 'fixedCommit': fixed, 'runId': 39499635645, 'partitions': rows, 'artifacts': downloads, 'entireFixedFullRulesNativeVisibleOrWindowsCertified': False}
try:
    for index in range(4):
        reused = root / next(r['path'] for r in old['records'] if r['partitionIndex'] == index) if index in [1, 2] else None
        archive = get_archive('postgres-partition-' + str(index), reused)
        with zipfile.ZipFile(archive) as z:
            raw_receipt = z.read('ci-postgres/partition-receipt.json'); receipt = json.loads(raw_receipt)
            expected = ids[index::4]
            assert receipt['status'] == 'REAL_POSTGRES_PARTITION_COMPLETE' and receipt['fixedCommit'] == fixed and receipt['partitionIndex'] == index and receipt['partitionCount'] == 4
            assert receipt['orderedDefaultCases'] == ids and receipt['expectedCases'] == receipt['completedCases'] == expected and receipt['manifestSha256'] == sha(raw_manifest)
            assert [e['id'] for e in receipt['executions']] == expected and [e['ordinal'] for e in receipt['executions']] == list(range(index, 48, 4))
            assert all(e['status'] == 'PASSED' and math.isfinite(e['seconds']) and e['seconds'] >= 0 for e in receipt['executions'])
            if reference_inputs is None: reference_inputs = receipt['actualRuleInputs']; reference_runtime = receipt['runtimeAssemblies']
            else: assert receipt['actualRuleInputs'] == reference_inputs and receipt['runtimeAssemblies'] == reference_runtime
            members = []
            for f in receipt['outputFiles']:
                name = 'ci-postgres/' + f['path']; raw = z.read(name)
                assert len(raw) == f['bytes'] and sha(raw) == f['sha256']; members.append(name)
            assert len(members) == len(set(members)) and {n for n in z.namelist() if not n.endswith('/')} == set(members) | {'ci-postgres/partition-receipt.json', 'ci-postgres-partition-commit.txt'}
            assert z.read('ci-postgres-partition-commit.txt').decode().strip() == fixed
            target = out / ('partition-' + str(index)); target.mkdir(); (target / 'partition-receipt.json').write_bytes(raw_receipt)
            rows.append({'index': index, 'orderedExecutedIdentities': expected, 'outputs': len(members), 'allOriginalOutputBytesHashesClosedMemberSetAndCommitExact': True, 'receiptSha256': sha(raw_receipt), 'actualCiRuleInputs': receipt['actualRuleInputs'], 'ciReportedRuntimeAssemblies': receipt['runtimeAssemblies']})
        print('f470 original part', index, len(expected), 'identities', len(members), 'output files verified', flush=True)
    for name in ['postgres-results', 'native-network-results']:
        p = get_archive(name)
        with zipfile.ZipFile(p) as z:
            downloads[-1]['originalMembers'] = [{'name': n, 'bytes': len(z.read(n)), 'sha256': sha(z.read(n))} for n in z.namelist() if not n.endswith('/')]
            if name == 'native-network-results':
                text = '\n'.join(z.read(n).decode(errors='replace') for n in z.namelist() if not n.endswith('/'))
                evidence = json.loads(next(line[len('NATIVE_ROOM_IDENTITY_EVIDENCE '):] for line in text.splitlines() if line.startswith('NATIVE_ROOM_IDENTITY_EVIDENCE ')))
                assert evidence['rejectedActions'] == 15 and evidence['leakedPrivateMessages'] == 0 and evidence['validReconnectTokenWasSupplied']
                assert 'Native network recovery passed: socket loss, authenticated room restore, fresh snapshot, rejected-token guard.' in text
                result['originalNativeNetworkEvidence'] = evidence
    specification = importlib.util.spec_from_file_location('original_gate', root / 'scripts/sql-ci-gate.py'); gate = importlib.util.module_from_spec(specification); specification.loader.exec_module(gate)
    verified = gate.verify(fixed, out / 'fixed-original48-sql-manifest.json', out, dict(scope='success', postgres_partitions='success', native_network='success'))
    assert verified['caseCount'] == 48 and verified['orderedDefaultCases'] == ids
    result.update(status='PASS_FIXED_F470_ACTUAL_ALL4_SQL48_ORIGINALS_AND_NATIVE15_GATE_NOT_ENTIRE_FULL', outputFiles=sum(r['outputs'] for r in rows), actualCiRuleInputs=reference_inputs, actualGateIndependentResult=verified, ciReportedRuntimeIdentitiesEqualAcrossAllFourParts=True, independentlyDownloadedRuntimeDllsNotClaimed=True, actualWholeRunStatusAtObservation=jobs['status'])
finally:
    with (w / 'preceding-f470-all4-sql-and-network-original-readback-v1.json').open('x') as f: json.dump(result, f, indent=2)
print(result['status'], result.get('outputFiles'), 'original outputs', flush=True)
