from pathlib import Path
import datetime, hashlib, json, os, shutil, subprocess

os.umask(0o077)
root = Path('/Users/dinghaolin/MyProjects/riftbound')
w = Path(__file__).resolve().parent
native = root / 'var/qa/fixed-c2bea309-native-locked-20261021'
load = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
sql = load(w / 'root-final-sql-v1/actual-final-root-five-candlelit-sql-owner-terminal-v2.json')
owner = load(native / 'same-original42-fixed-ci-score-owner-terminal-v2.json')
assert sql['status'].startswith('PASS_FINAL_ROOT_') and sql['ownPostgresSmartStopped']
assert owner['status'].startswith('PASS_SAME_ORIGINAL39_PLUS3_') and owner['ownApiStopped'] and owner['ownPostgresSmartStopped']
running = load(w / 'only-check-start-inputs-v1.json')
def current_check_inputs():
    return {'source': {p: sha(root / p) for p in running['sourceInputHashes']}, 'modes': {p: oct((root / p).stat().st_mode & 0o777) for p in running['sourceInputModes']}, 'conformance': {p: sha(root / p) for p in running['actualConformanceRuntimeFileHashes']}, 'native': {p: sha(root / p) for p in running['actualNativeRuntimeFileHashes']}}
before = current_check_inputs()
assert before['source'] == running['sourceInputHashes'] and before['conformance'] == running['actualConformanceRuntimeFileHashes'] and before['native'] == running['actualNativeRuntimeFileHashes']
frozen = [(w / 'root-final-sql-v1/runtime-v1', load(w / 'root-final-sql-v1/frozen-final-root-inputs-v1.json')['runtimeFiles']), (w / 'root-final-sql-v1/independent-reader-runtime-v1', load(w / 'root-final-sql-v1/independent-final-root-candlelit-history-run-v1.json')['readerRuntimeFiles']), (native / 'same-original-explicit-score-runtime-v2', load(native / 'same-original-explicit-score-runtime-inputs-v2.json')['runtimeFiles']), (native / 'fixed-c2-ci59-history-reader-runtime-v2', load(native / 'independent-fixed-c2-ci59-history-run-v2.json')['readerRuntimeFiles'])]
for folder, hashes in frozen: assert all(sha(folder / p) == h for p, h in hashes.items())
staging = w / 'root-sql-build-staging-v1'
assert all(sha(w / 'root-final-sql-v1/runtime-v1' / p.relative_to(staging)) == sha(p) for p in staging.rglob('*') if p.is_file())
paths = [staging]
for folder in [w / 'root-final-sql-v1/independent-reader-source-v1'] + [native / name for name in ['fixed-canonical-room-reader-source-v1', 'fixed-canonical-room-reader-source-v2', 'same-original-fixed-ci-reader-source-v1', 'same-original-fixed-ci-reader-source-v2', 'fixed-c2-ci59-history-reader-source-v1', 'fixed-c2-ci59-history-reader-source-v2', 'same-original-explicit-score-source-v1', 'same-original-explicit-score-source-v2']]:
    paths.extend(folder / name for name in ['bin', 'obj'])
commands = subprocess.check_output(['ps', '-axo', 'pid=,command='], text=True)
assert not any(str(path) in line for path in paths for line in commands.splitlines())
removed = []
for path in paths:
    assert path.is_dir() and not path.is_symlink() and path.resolve().is_relative_to(root / 'var/qa')
    files = [p for p in path.rglob('*') if p.is_file()]
    removed.append({'path': str(path.relative_to(root)), 'files': len(files), 'logicalBytes': sum(p.stat().st_size for p in files), 'completedBuildOnlyActualExecutedImmutableRuntimeAndSourceLogRetained': True})
    shutil.rmtree(path)
assert current_check_inputs() == before
for folder, hashes in frozen: assert all(sha(folder / p) == h for p, h in hashes.items())
result = {'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': 'COMPLETED_OWNED_DUPLICATE_BUILD_STAGING_RETIRED_DURING_SOLE_CHECK_WITH_ALL_RUNNING_INPUTS_EXACT', 'removed': removed, 'logicalBytesRetired': sum(x['logicalBytes'] for x in removed), 'all3319SourceModes1419ConformanceAnd23NativeInputsExactBeforeAfter': True, 'allActualExecutedSqlScoreAndIndependentReaderImmutableFilesKept': True, 'allSourcesOfficialFacesPageRendersOriginalFailuresLogsAndDatabasesKept': True, 'userEditorSharedSdkAndToolTemplateUntouched': True, 'physicalDiskReclaimNotInferredFromLogicalBytes': True}
with (w / 'completed-owned-build-staging-retirement-v1.json').open('x') as f: json.dump(result, f, indent=2)
print(result['status'], len(removed), 'directories', result['logicalBytesRetired'], 'logical bytes', flush=True)
