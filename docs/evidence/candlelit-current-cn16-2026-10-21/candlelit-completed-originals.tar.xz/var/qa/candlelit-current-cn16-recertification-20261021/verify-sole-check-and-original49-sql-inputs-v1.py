from pathlib import Path
import ast, collections, datetime, gzip, hashlib, json, re, xml.etree.ElementTree as ET

w = Path(__file__).resolve().parent
root = w.parents[2]
load = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
owner = load(w / 'only-check-owner-terminal-v1.json')
start = load(w / 'only-check-start-inputs-v1.json')
summary = load(w / 'only-check-v1/summary.json')
plan = load(w / 'only-check-v1/plan.json')
assert owner['exitCode'] == 0 and owner['status'] == 'CHECK_PROCESS_EXIT_ZERO_INDEPENDENT_PARITY_STILL_REQUIRED'
for field in ['all3319SourceHashesUnchanged', 'allSourceModesUnchanged', 'allConformanceInputPayloadsUnchanged', 'all23NativePayloadsUnchanged', 'boundIdleAssertionEnded']: assert owner[field], field
assert summary['status'] == 'PASSED' and summary['total'] == 13219 and plan['discoveredMethods'] == 7642
assert sum(len(s['methods']) for s in plan['shards']) == 7501
def read(path):
    tree = ET.parse(path)
    definitions = {d.attrib['id']: d.find('t:TestMethod', ns).attrib for d in tree.findall('.//t:UnitTest', ns)}
    cases = collections.Counter()
    methods = set()
    for r in tree.findall('.//t:UnitTestResult', ns):
        assert r.attrib['outcome'] == 'Passed'
        d = definitions[r.attrib['testId']]
        cases[r.attrib['testName']] += 1
        methods.add(d['className'] + '.' + d['name'])
    return cases, methods
baseline = root / start['originalBaselineTrx']
current = w / 'only-check-v1/check/results.trx'
before_cases, before_methods = read(baseline)
cases, methods = read(current)
assert before_cases == cases and before_methods == methods
assert sum(cases.values()) == 13219 and len(methods) == 7501
assert methods == {m for shard in plan['shards'] for m in shard['methods']}
fixed = load(root / 'var/qa/fixed-c2bea309-native-locked-20261021/fixed-clean-api-runtime-source-and-identity-v1.json')
sources = start['sourceInputHashes']
changed = {p for p, h in fixed['sourceInputHashes'].items() if sources[p] != h}
assert changed == {'tests/Riftbound.PostgresAcceptance/Program.cs', 'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json', 'scripts/tests/test_sql_ci_gate.py'}
assert set(sources) - set(fixed['sourceInputHashes']) == {'tests/Riftbound.PostgresAcceptance/CandlelitPrivateLookSqlAcceptance.cs'}
assert len(sources) == 3319 and all(sha(root / p) == h for p, h in sources.items())
assert all(oct((root / p).stat().st_mode & 0o777) == m for p, m in start['sourceInputModes'].items())
conformance = {p: h for p, h in fixed['sourceInputHashes'].items() if p.startswith('tests/Riftbound.ConformanceTests/')}
assert all(sources[p] == h for p, h in conformance.items())
full = {p: h for p, h in conformance.items() if Path(p).name.startswith('FullGameEndToEndTests') and p.endswith('.cs')}
assert len(full) == 9
full_methods = {m for p in full for m in re.findall(r'\bpublic\s+(?:async\s+)?(?:Task|void)\s+(\w+)\s*\(', (root / p).read_text())}
assert len(full_methods) == 143
prior = load(w / 'root-original-input-retention-v1.json')
manifest = load(root / 'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json')
assert len(manifest['cases']) == 49 and manifest['cases'][:48] == prior['original48Cases']
assert manifest['cases'][48] == {'id': 'candlelit-private-look', 'sourceType': 'CandlelitPrivateLookSqlAcceptance'}
original_gate = gzip.decompress((w / 'root-original-before-sql-integration-v1/test_sql_ci_gate.py.gz').read_bytes()).decode()
expected = original_gate.replace("self.assertEqual(48, result['caseCount'])", "self.assertEqual(49, result['caseCount'])").replace("self.assertEqual('conditional-counter-payment', self.ids[-3])", "self.assertEqual('conditional-counter-payment', self.ids[45])").replace("self.assertEqual('reversal-target-choice', self.ids[-2])", "self.assertEqual('reversal-target-choice', self.ids[46])").replace("self.assertEqual('spell-remake-declaration', self.ids[-1])", "self.assertEqual('spell-remake-declaration', self.ids[47])\n        self.assertEqual('candlelit-private-look', self.ids[48])")
assert expected == (root / 'scripts/tests/test_sql_ci_gate.py').read_text()
test_names = lambda text: {n.name for n in ast.walk(ast.parse(text)) if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')}
assert test_names(original_gate) == test_names(expected)
sql = load(w / 'root-final-sql-v1/actual-final-root-five-candlelit-sql-owner-terminal-v2.json')
independent = load(w / 'root-final-sql-v1/independent-final-root-candlelit-history-result-v1.json')
assert sql['status'].startswith('PASS_FINAL_ROOT_') and sql['commands'] == independent['commands'] == 30 and sql['events'] == independent['events'] == 90
assert sql['coldRecoveries'] == 30 and sql['directAtomicRejections'] == 21 and sql['independentStructuralRejections'] == 20
assert sql['ownPostgresSmartStopped'] and sql['allOriginal236AuditSevenTablesExactAtStop'] and sql['allOriginal50NativeSevenTablesExactAtStop']
result = {'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': 'CHECK_AND_EXACT_CASE_METHOD_PARITY_PASS', 'profile': 'check', 'baseCommit': start['baseCommit'], 'actualCases': 13219, 'actualMethods': 7501, 'allFullDiscoveryMethods': 7642, 'fullDiscoveryNotExecution': True, 'originalCaseCount': 13219, 'originalMethodCount': 7501, 'newConformanceCases': 0, 'newConformanceMethods': 0, 'oldCasesPreserved': True, 'oldMethodsPreserved': True, 'frozenInputsUnchanged': True, 'failed': 0, 'skipped': 0, 'allOriginalCaseNameCountMultisetAndMethodsExact': True, 'allOriginalConformanceSourceFilesAndTheoryRowsUnchanged': True, 'original143FullMethodsNineSourceFiles11Decks110Pairs424242VictoryAndReplayAssertionsUnchanged': True, 'original48SqlIdentitiesAndOrderExactOnly49thAdded': True, 'allOriginalPythonGateMethodsAndIndependentNegativeAssertionsRetained': True, 'all3319SourceHashesModes1419ConformanceAnd23NativeInputsStableThroughoutCheck': True, 'actualTrxSha256': sha(current), 'baselineTrxSha256': sha(baseline), 'actualTestAssemblySha256': plan['testAssemblySha256'], 'summary': summary, 'ownerTerminal': owner, 'onlyOneCheckExecutedForThisCoherentBatch': True, 'fixedCommitFullCurrentVisibleAndPhysicalWindowsAcceptance': 'OPEN', 'wholePrintingAndGlobalCertification': False}
target = w / 'check-original-case-method-and-input-retention-v1.json'
with target.open('x') as f: json.dump(result, f, indent=2)
print(result['status'], '13219 cases /7501 methods exact; original48 SQL +49th; no source/runtime drift', flush=True)
