from pathlib import Path
import copy, datetime, gzip, hashlib, json, os, tarfile

os.umask(0o077)
root = Path('/Users/dinghaolin/MyProjects/riftbound'); w = Path(__file__).resolve().parent
n = root / 'var/qa/fixed-c2bea309-native-locked-20261021'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest(); load = lambda p: json.loads(p.read_text())
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p, value):
    with p.open('x') as f: json.dump(value, f, ensure_ascii=False, indent=2); f.write('\n')
def pin(p, role=None):
    value = {'path': str(p.relative_to(root)), 'sha256': sha(p)}
    if role: value['role'] = role
    return value
check = load(w / 'check-original-case-method-and-input-retention-v1.json')
assert check['status'] == 'CHECK_AND_EXACT_CASE_METHOD_PARITY_PASS' and check['actualCases'] == 13219 and check['actualMethods'] == 7501
assert check['oldCasesPreserved'] and check['oldMethodsPreserved'] and check['frozenInputsUnchanged']
sql = load(w / 'root-final-sql-v1/actual-final-root-five-candlelit-sql-owner-terminal-v2.json')
independent = load(w / 'root-final-sql-v1/independent-final-root-candlelit-history-result-v1.json')
assert sql['status'].startswith('PASS_FINAL_ROOT_') and sql['commands'] == independent['commands'] == 30 and sql['events'] == independent['events'] == 90
assert sql['ownPostgresSmartStopped'] and sql['allOriginal236AuditSevenTablesExactAtStop'] and sql['allOriginal50NativeSevenTablesExactAtStop']
native = load(n / 'current-fixed-c2-ci-native-combined-subscope-readback-v1.json')
assert native['commands'] == 59 and native['events'] == 358 and native['historicalPayloads'] == {'state_snapshots': 59, 'snapshots': 114, 'action_prompts': 114}
assert native['ownApiDatabaseAndIdleAssertionNormallyStopped'] and native['allOriginal241AuditAnd50NativeSevenTablesExact']
prior_sql = load(w / 'preceding-f470-all4-sql-and-network-original-readback-v2.json')
assert prior_sql['status'].startswith('PASS_FIXED_F470_') and prior_sql['outputFiles'] == 320
prior_full = load(w / 'preceding-f470-entire-full-independent-original-verification-v1.json')
assert prior_full['status'] == 'FIXED_COMMIT_FULL_CI_AND_PARITY_VERIFIED' and prior_full['actualCases'] == 13363 and prior_full['actualMethods'] == 7640 and all(v == 'success' for v in prior_full['jobs'].values())
manifest_path = root / 'docs/audit/current-manifest.json'; manifest = load(manifest_path)
reviews_path = root / manifest['inputs']['reviews']['path']; reviews = load(reviews_path)
assert len(reviews['reviews']) == 150 and len(manifest['reviewContexts']) == 65 and len(manifest['acceptanceGates']) == 245 and len(manifest['laterSourceDeltas']) == 7
before_manifest = copy.deepcopy(manifest); before_reviews = copy.deepcopy(reviews)
prior = w / 'prior-original-governance-inputs-v1'; prior.mkdir(exist_ok=False)
for p in [manifest_path, reviews_path]:
    with (prior / (p.name + '.gz')).open('xb') as f: f.write(gzip.compress(p.read_bytes(), mtime=0))
evidence = root / 'docs/evidence/candlelit-current-cn16-2026-10-21'; evidence.mkdir(exist_ok=False)
sources = load(w / 'source-intake-current-observation-v1.json')
branches = load(w / 'current-five-candlelit-bounded-source-review-and-obligations-v1.json')
fixed_api = load(n / 'fixed-clean-api-runtime-source-and-identity-v1.json')
frozen = load(w / 'root-final-sql-v1/frozen-final-root-inputs-v1.json')
assert frozen['actualRuleInputs'] == fixed_api['actualRuleInputs'] == sql['actualRuleInputs']
assert len(branches['fiveBranches']) == 5 and len(branches['exactSourceClauseRecords']) == 36
for filename, original in {
    'check-exact-original-case-method-and-input-retention.json': w / 'check-original-case-method-and-input-retention-v1.json',
    'focus-original-candlelit-and-adjacent.json': w / 'focus-current-candlelit-and-original-game-v1/summary.json',
    'real-sql-final-root-five-terminal.json': w / 'root-final-sql-v1/actual-final-root-five-candlelit-sql-owner-terminal-v2.json',
    'real-sql-independent-all-history.json': w / 'root-final-sql-v1/independent-final-root-candlelit-history-result-v1.json',
    'five-current-source-branch-records.json': w / 'current-five-candlelit-bounded-source-review-and-obligations-v1.json',
    'fixed-c2-ci-native-combined-subscope.json': n / 'current-fixed-c2-ci-native-combined-subscope-readback-v1.json',
    'preceding-f470-all4-sql-originals.json': w / 'preceding-f470-all4-sql-and-network-original-readback-v2.json',
    'preceding-f470-entire-full-originals.json': w / 'preceding-f470-entire-full-independent-original-verification-v1.json',
    'latest-only-native-replacement.json': n / 'latest-only-verified-replacement-and-old-a56137-retirement-v1.json',
    'completed-build-staging-retirement.json': w / 'completed-owned-build-staging-retirement-v1.json',
}.items():
    target = evidence / filename; target.write_bytes(original.read_bytes()); assert sha(target) == sha(original)

runtime_dirs = {'fixed-f470-sql-runtime-v1', 'independent-fixed-f470-reader-runtime-v1', 'runtime-v1', 'independent-reader-runtime-v1', 'root-sql-build-staging-v1'}
late_files = {'publish-final-candlelit-cn16-batch-v1.log', 'publication-independent-readback-v1.json', 'verify-published-candlelit-cn16-batch-v1.log', 'actual-final-governance-v1.json', 'actual-final-governance-v1.log', 'publication-and-verification-supplement-v1.json'}
maps = []
private_values = set()
for profile_path in [n / 'session-a.json', n / 'session-b.json', n / 'actual-safe-native-prefix-v2/session-native-a.json', n / 'actual-safe-native-prefix-v2/session-native-b.json']:
    profile = load(profile_path)
    private_values.update(v.encode() for k, v in profile.items() if k.lower() in {'playerkey', 'reconnecttoken'} and isinstance(v, str) and v)
def has_raw_credentials(value):
    if isinstance(value, dict):
        return any((k.lower() in {'playerkey', 'reconnecttoken', 'sessiontoken', 'password'} and isinstance(v, str) and bool(v)) or has_raw_credentials(v) for k, v in value.items())
    if isinstance(value, list): return any(has_raw_credentials(v) for v in value)
    return False
def safe_original(p):
    raw = p.read_bytes()
    if p.suffix == '.gz': raw = gzip.decompress(raw)
    assert not any(secret in raw for secret in private_values), 'Private QA credential must stay local: ' + str(p.relative_to(root))
    if p.suffix == '.json' or p.name.endswith('.json.gz'):
        assert not has_raw_credentials(json.loads(raw)), 'Raw credential JSON must stay local: ' + str(p.relative_to(root))
def package(base, name, native_scope=False):
    members = []; exclusions = []
    sensitive_names = {'session-a.json', 'session-b.json', 'session-native-a.json', 'session-native-b.json', 'native-credentials-for-regular-continuation.json', 'original-private-native-wire-snapshots-prompts.ndjson.gz', 'original-private-score-gateway-wire.ndjson.gz'}
    for p in sorted(base.rglob('*')):
        if not p.is_file(): continue
        rel = p.relative_to(base); parts = rel.parts
        if {'bin', 'obj'} & set(parts) or any(a.endswith('.app') for a in parts): continue
        if any(a in runtime_dirs or ('runtime' in a and p.parent != base) for a in parts[:-1]): continue
        if p.name in late_files or p.suffix == '.tmp': continue
        if native_scope:
            if parts[0] == 'native-current' and (len(parts) < 3 or parts[1] != 'ci-logs'): continue
            server_log = p.suffix == '.log' and p.parent == base and any(a in p.name for a in ['-api-1-', '-api-2-'])
            if p.name in sensitive_names or server_log:
                exclusions.append({'path': str(p.relative_to(root)), 'reason': 'private-account-or-operational-wire/server-log-retained-locally', 'bytes': p.stat().st_size, 'sha256': sha(p)})
                continue
        safe_original(p)
        members.append(p)
    archive = evidence / (name + '.tar.xz')
    with tarfile.open(archive, 'x:xz', preset=6) as tar:
        for p in members: tar.add(p, arcname=str(p.relative_to(root)), recursive=False)
    rows = [{'path': str(p.relative_to(root)), 'bytes': p.stat().st_size, 'sha256': sha(p)} for p in members]
    with tarfile.open(archive, 'r:xz') as tar:
        actual = tar.getmembers(); assert {a.name for a in actual} == {r['path'] for r in rows} and len(actual) == len(rows)
        by_name = {a.name: a for a in actual}
        for row in rows:
            raw = tar.extractfile(by_name[row['path']]).read(); assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
    value = {'archive': pin(archive), 'members': rows, 'explicitPrivateExclusionsRetainedLocally': exclusions, 'runtimeSourceBuildAndPackagePayloadsReferencedByOriginalManifestsRatherThanDuplicated': True}
    maps.append(value)
    return value
root_archive = package(w, 'candlelit-completed-originals')
native_archive = package(n, 'fixed-c2-native-completed-originals', True)
write(evidence / 'archive-map.json', {'atUtc': now(), 'archives': maps, 'allSelectedOriginalMembersBytesAndClosedSetsIndependentlyCheckedAtPublication': True, 'latePublicationVerificationAndGovernanceOutputsRequireSeparateSupplement': True})
source_manifest = {'atUtc': now(), 'status': 'BOUNDED_CN16_CANDLELIT_PRIVATE_LOOK_SQL49_SOURCE_AND_EXECUTION_READBACK_FULL_AND_PRODUCT_OPEN', 'region': 'CN', 'language': 'zh-CN', 'observedAsOf': '2026-10-21', 'adoptedCoreEffectiveAsOf': '2026-10-16', 'exactPrinting': {'apiId': 31536, 'printing': 'OGN-291/298', 'printedName': '烛光圣殿', 'firstPublicationDate': None, 'printingEffectiveDate': None}, 'officialObservation': sources, 'exactClauseAndBranchReview': pin(evidence / 'five-current-source-branch-records.json'), 'allCompleteOriginalPhysicalPagesViewed': [8, 9, 29, 40, 41, 63, 69, 73, 82, 85], 'oldReviewOriginalDateJulySourceEightBranchesAndEvidenceUnchanged': True, 'noOfficialBodyChangeDetectedInExactTwoCardRowsDirectoryAndThreePrimaryPdfsOnly': True, 'cardQaNullAndLiteralTermAbsenceDoNotProveNoFaq': True, 'originalAllPrintingsRuleQaNewsSourceGapsAndSevenDeltasRetained': True, 'sourceRefreshDoesNotReplaceFinalApplicableSourceRefresh': True, 'implementationChange': 'NO_GAMEPLAY_SOURCE_CHANGE_NEW_PERMANENT_SQL_VERIFICATION_ONLY', 'parentCommit': fixed_api['fixedCommit'], 'actualFinalRootSqlRuleInputs': frozen['actualRuleInputs'], 'actualPrototypeF470RuleInputs': load(w / 'fixed-f470-sql-runtime-v1.json')['actualRuleInputs'], 'prototypeAndFinalRunsRetainedSeparatelyNotMerged': True, 'sourceInputCount': 3319, 'onlyChangedExistingInputs': ['tests/Riftbound.PostgresAcceptance/Program.cs', 'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json', 'scripts/tests/test_sql_ci_gate.py'], 'newSource': pin(root / 'tests/Riftbound.PostgresAcceptance/CandlelitPrivateLookSqlAcceptance.cs'), 'original48SqlIdsAndOrderOnly49thAdded': True, 'currentSqlFive': {'commands': 30, 'events': 90, 'coldRecoveries': 30, 'directAtomicRejections': 21, 'independentStructuralRejections': 20, 'authorityHistories': 30, 'privateSnapshots': 60, 'privatePrompts': 60, 'controlledInitialNotOrdinaryOpening': True, 'originalBlankReplayMetadataNotRewritten': True, 'structuralRejectionsUseForgedCopiesOfActualStoredFrameNotDatabaseMutation': True}, 'focus': {'cases': 76, 'methods': 47, 'originalCandlelitScoreVictoryAndFullReplayIncluded': True}, 'onlyCheck': pin(evidence / 'check-exact-original-case-method-and-input-retention.json'), 'pythonTools': {'passed': 73, 'originalMethodsAndNegativeAssertionsPreserved': True}, 'precedingFixedC2HeadlessCiNativeScope': pin(evidence / 'fixed-c2-ci-native-combined-subscope.json'), 'precedingF470Sql48Native15Only': pin(evidence / 'preceding-f470-all4-sql-originals.json'), 'archives': [root_archive['archive'], native_archive['archive']], 'archiveMap': pin(evidence / 'archive-map.json'), 'finalCurrentFixedFullVisibleHardwareAndPhysicalWindowsAcceptance': 'OPEN', 'wholePrintingOrGlobalCertification': False}
write(evidence / 'source-manifest.json', source_manifest)
source_manifest['precedingFixedF470ActualCompleteFull'] = pin(evidence / 'preceding-f470-entire-full-originals.json', 'previous-fixed-full')
(evidence / 'source-manifest.json').write_text(json.dumps(source_manifest, ensure_ascii=False, indent=2) + '\n')
doc = root / 'docs/CANDLELIT_CURRENT_CN16_SQL_AUDIT_2026-10-21.md'
text = (w / 'current-candlelit-audit-document-draft-v1.md').read_text()
needle = '唯一 check 的实际终态及旧用例/方法、输入稳定性核对在发布前写入本批独立收据；'
assert text.count(needle) == 1
text = text.replace(needle, '本批唯一 check 实际 13,219 例/7,501 方法全过，零失败/跳过；原用例名称/次数多重集合和方法精确相同，3,319 源码/模式、1,419 Conformance 与 23 原生输入全程稳定；')
text += '\n固定 C2 补证：同一普通局 39 网关开局、3 次 CI 导出原生交互提交、17 条正常网关续行，共 59 命令358事件，第29回合8:0，一征服七驻守、非投降且双牌堆非空。59权威历史/双方合计114快照和114提示及全原回放独立通过；五个原生进程均正常退出无错误，两个同进程经专用API冷重启恢复。全部原39/42动作、种子和初态保留，原241审计50原生七表不变，新普通及网络局保留至52，服务正常停止。早退/管道采集/旧路径和目的地假设的原失败全部保留，原生三动作未重放；精确目的地来自同局原OGN278及当前合法提示，不改变原牌组。该证据只属C2无窗口子范围，可见/硬件/Windows及本批新固定full仍OPEN。\n'
text += '\n前一固定 f470 完整 CI39499635645 已实际11项success，原始TRX独立核对13363例/7640方法，原a56137的13325/7635全部保留，只新增38/5；原143完整方法、110配对、11牌组和424242及全部配对终态哈希保留。四SQL片48身份320原输出及网络15拒绝零泄露、两个汇总门禁原产物均独立核验；CI仅上报的SQL程序集身份不说成已下载DLL实证。该结果不覆盖之后C2账号/原生连接及本批第49 SQL身份。\n'
with doc.open('x') as f: f.write(text)
identity = 'candlelit-current-cn16-five-private-look-sql-2026-10-21'
assert identity not in manifest['reviewContexts'] and not any(r['id'] == identity for r in reviews['reviews'])
source_pin = pin(evidence / 'source-manifest.json', 'source-manifest')
review = {'id': identity, 'scope': 'Current CN16 exact OGN291 mandatory conquest response, private top2 optional recycle/retained order and zero/one short deck only; five controlled SQL branches. No gameplay implementation change or whole-card/other-consumer certification.', 'subjects': ['OGN-291/298'], 'ruleRecords': [r['exactRuleRecord'] for r in branches['exactSourceClauseRecords']], 'pendingRuleRecords': [], 'status': 'BOUNDED_CURRENT_SOURCE_FOCUS76_SQL5_30_90_INDEPENDENT_HISTORY_ONLY_CHECK13219_PASS_NEW_FIXED_FULL_PRODUCT_OPEN', 'sourceManifest': source_pin, 'auditDocument': str(doc.relative_to(root)), 'validation': {'newConformanceCases': 0, 'newConformanceMethods': 0, 'currentFocusCases': 76, 'currentFocusMethods': 47, 'currentSqlBranches': 5, 'currentSqlCommands': 30, 'currentSqlEvents': 90, 'currentCheckCases': 13219, 'currentCheckMethods': 7501, 'original48SqlOrderOnly49thAdded': True, 'wholeCardCertification': False}, 'exclusions': ['Nocturne original-set, simultaneous legend and other pending items require their own current SQL/product evidence', 'Actual reaction adjusted deck, copies, other consumers/printings and full effects', 'New fixed49 full and final visible paired hardware and physical Windows', 'All retained official source gaps, later changes and full-scope obligations']}
reviews['reviews'].append(review)
impl_paths = ['src/Riftbound.Engine/CoreRuleEngine.Conquest.cs', 'src/Riftbound.Engine/CoreRuleEngine.InsightTriggers.cs', 'src/Riftbound.Engine/CoreRuleEngine.Insight.cs', 'src/Riftbound.Engine/CoreRuleEngine.DeckObservation.cs', 'src/Riftbound.Engine/MatchRecovery.cs', 'src/Riftbound.CardCatalog/RuleTextParsers.cs']
context_branches = []
for b in branches['fiveBranches']:
    value = copy.deepcopy(b); value['state'] = 'RECORDED'; value['sourceManifest'] = source_pin; value['decision'] = {'state': 'OPEN', 'reason': 'Bounded current source and exact execution pass are recorded separately; final fixed49 full/product and other semantic obligations remain.'}; value['wholePrintingCertified'] = False; value['existingAcceptanceGateDependencies'] = ['DECK_OBSERVATION_FAMILY_ALL_APPLICABLE_CONSUMERS', 'FIXED_CURRENT_CANDIDATE_FULL', 'USER_WINDOWS_RUNTIME']; context_branches.append(value)
manifest['reviewContexts'][identity] = {'evidenceCommit': fixed_api['fixedCommit'], 'currentImplementationCommit': fixed_api['fixedCommit'], 'currentImplementationIncludesUncommittedChanges': True, 'ciState': 'PENDING', 'ciReceipts': [], 'region': 'CN', 'language': 'zh-CN', 'applicableAsOf': '2026-10-21', 'adoptedCoreEffectiveDate': '2026-10-16', 'sourceManifest': source_pin, 'implementation': [pin(root / p, 'implementation') for p in impl_paths], 'verificationSources': [pin(root / 'tests/Riftbound.PostgresAcceptance/CandlelitPrivateLookSqlAcceptance.cs', 'verification-source'), pin(root / 'tests/Riftbound.ConformanceTests/CandlelitSanctumTests.cs', 'unchanged-original-test-source')], 'evidence': [pin(evidence / 'focus-original-candlelit-and-adjacent.json', 'focus'), pin(evidence / 'check-exact-original-case-method-and-input-retention.json', 'check'), pin(evidence / 'real-sql-final-root-five-terminal.json', 'sql-actual-terminal'), pin(evidence / 'real-sql-independent-all-history.json', 'independent-sql-readback')], 'branches': context_branches, 'oldCandlelitJulySourceContextRetainedWholeAndUnchanged': True}
gate = next(g for g in manifest['acceptanceGates'] if g['id'] == 'ROOM_IDENTITY_BOUNDARY')
gate['currentFixedC2CiExportedHeadlessPairObservation'] = pin(evidence / 'fixed-c2-ci-native-combined-subscope.json', 'fixed-ci-headless-pair-subscope')
gate['currentFixedC2PlatformLimit'] = 'Actual current CI373x2/clean API cold pair/native3/SQL59 normal8/full replay pass; earlier failures retained; whole fixed full, visible hardware and physical Windows remain separate OPEN.'
manifest['currentCandlelitCn16FivePrivateLookSqlInputChange'] = source_pin
manifest['precedingFixedC2ActualLockedCiNativePairReadback'] = pin(evidence / 'fixed-c2-ci-native-combined-subscope.json', 'fixed-ci-headless-pair-subscope')
manifest['precedingFixedF470ActualAllFourSqlAndNetworkOnlyReadback'] = pin(evidence / 'preceding-f470-all4-sql-originals.json', 'partial-ci-sql48-network15')
manifest['precedingFixedF470ActualCompleteFullCiReadback'] = pin(evidence / 'preceding-f470-entire-full-originals.json', 'previous-fixed-full')
assert reviews['reviews'][:150] == before_reviews['reviews'] and all(manifest['reviewContexts'][k] == v for k, v in before_manifest['reviewContexts'].items())
assert manifest['certificationScope'] == before_manifest['certificationScope'] and manifest['laterSourceDeltas'] == before_manifest['laterSourceDeltas'] and manifest['cardCoverageManifest'] == before_manifest['cardCoverageManifest']
assert all(g == before_manifest['acceptanceGates'][i] for i, g in enumerate(manifest['acceptanceGates']) if g['id'] != 'ROOM_IDENTITY_BOUNDARY')
reviews_path.write_text(json.dumps(reviews, ensure_ascii=False, indent=2) + '\n'); manifest['inputs']['reviews']['sha256'] = sha(reviews_path); manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
status_path = root / 'docs/PROJECT_STATUS.md'; original_status = status_path.read_text()
with (prior / 'PROJECT_STATUS.md.gz').open('xb') as f: f.write(gzip.compress(original_status.encode(), mtime=0))
lead = '2026-10-21 本批：[烛光圣殿当前CN16与常驻SQL](CANDLELIT_CURRENT_CN16_SQL_AUDIT_2026-10-21.md)。精确API31536/OGN291、当前三主PDF与两卡面原件复核，十个完整物理页/36精确条款；旧10-14/July结论与全部八分支原对象不变。本批只五个私有征服看牌/回收/排序/短牌堆分支，不改游戏实现，不升整卡。76/47定向含原完整胜利/回放、73工具通过；唯一check13219/7501全部通过，旧用例名称/次数与方法精确相同，3319源/模式、1419Conformance及23原生载荷稳定；原143方法110配对11牌组424242及全部断言保留。\n\nSQL默认只追加第49身份，原48身份/顺序与助手不变。最终类真实5场30命令90事件30冷恢复21直接/20结构拒绝；独立30状态/双方合计60快照60提示和全原受控初态回放通过，原blank元数据不改；原236审计50原生七表不变，新5局保留至241，数据库正常停止。较早干净f470原型为独立运行，不跨输入合并证明。\n\n固定C2实际CI导出双端在锁屏下完成同局39开局+3原生交互+17正常续行，59命令358事件、29回合8:0、一征服七驻守；59状态/114私有快照提示及全原回放独立通过，两同进程冷重连、五进程0退出无错误。原39/42历史与种子/初态不变，原241审计50原生七表不变，新普通/网络留至52，服务正常停止。原早退、管道、配置路径及目的地助手失败全保留，PTY/帧率及显式原输入只修正验收采集；不称可见/硬件/Windows或本批新固定full。\n\n父f470完整CI39499635645实际11项success，原产物独立核对13363/7640、原143方法110配对/11牌组/424242及SQL48/320输出/网络15拒绝0泄露，原a56137的13325/7635全留只增38/5；C2完整CI仍独立待核。本批151限定审查66上下文245门禁7增量，原150审查65上下文完整不变、244门禁原值不变，身份门禁只追加C2子范围证据；16944原义务身份、1740印次14293规则块/CN236/EN8/139公告及原适用日期保留，新增五限定分支。只有最新C2 A/B与每平台一包，清退旧包945967800及19构建暂存18220240逻辑字节，不推定APFS物理回收；来源/失败/有效冻结输入/原库保留，无新SDK/checkout/数据库。Goal active / NOT READY。\n\n以下原批次文字按当时精确范围与终态保留。\n\n'
assert original_status.startswith('# 当前项目状态\n\n'); status_path.write_text('# 当前项目状态\n\n' + lead + original_status[len('# 当前项目状态\n\n'):])
write(w / 'publication-root-governance-retention-v1.json', {'atUtc': now(), 'status': 'PUBLISHED_BOUNDED_CANDLELIT_RECORDS_NOT_GOAL_COMPLETION', 'original150ReviewObjectsAnd65EntireContextsExact': True, 'original244UnchangedGatesAndFullPriorRoomGateRetained': True, 'originalSourceScopeDatesCardCoverageAndSevenDeltasExact': True, 'newReviews': 1, 'newContexts': 1, 'newBranches': 5, 'newGateIdentities': 0, 'originalPrintingRuleNewsAndGapUniverseNotReduced': True, 'sourceManifest': pin(evidence / 'source-manifest.json'), 'lateGovernanceAndPublicationOutputsRequireSupplement': True})
print('Published151 reviews/66 contexts/245 unchanged gate identities/+5 bounded branches; archives', sum((root / a['archive']['path']).stat().st_size for a in maps), 'bytes; new fixed49 full and product remain open', flush=True)
