from pathlib import Path
import datetime, hashlib, json, os, shutil, subprocess

os.umask(0o077)
root = Path('/Users/dinghaolin/MyProjects/riftbound')
w = Path(__file__).resolve().parent
out = w / 'root-final-sql-v1'
out.mkdir(exist_ok=False)
r = out / 'runtime-v1'
r.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
fixed = json.loads((root / 'var/qa/fixed-c2bea309-native-locked-20261021/fixed-clean-api-runtime-source-and-identity-v1.json').read_text())
paths = list(fixed['sourceInputHashes']) + ['tests/Riftbound.PostgresAcceptance/CandlelitPrivateLookSqlAcceptance.cs']
assert len(paths) == len(set(paths)) == 3319
inputs = {p: sha(root / p) for p in paths}
modes = {p: oct((root / p).stat().st_mode & 0o777) for p in paths}
changed = [p for p in fixed['sourceInputHashes'] if inputs[p] != fixed['sourceInputHashes'][p]]
assert set(changed) == {'tests/Riftbound.PostgresAcceptance/Program.cs', 'tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json', 'scripts/tests/test_sql_ci_gate.py'}
mutable = {(p.stat().st_dev, p.stat().st_ino) for p in (root / p for p in paths)}
for folder in ['src', 'tests', 'clients/godot/.godot/mono/temp/bin']:
    for p in (root / folder).rglob('*'):
        if p.is_file() and ('bin' in p.parts or 'obj' in p.parts): mutable.add((p.stat().st_dev, p.stat().st_ino))
staging = w / 'root-sql-build-staging-v1'
mutable.update((p.stat().st_dev, p.stat().st_ino) for p in staging.rglob('*') if p.is_file())
known = {}
for folder in ['var/qa/fixed-c2bea309-native-locked-20261021/api-runtime-v1', 'var/qa/canonical-room-player-identity-20261021/live-acceptance-helper-runtime-v1']:
    for p in (root / folder).rglob('*'):
        if p.is_file() and (p.stat().st_dev, p.stat().st_ino) not in mutable: known.setdefault((p.stat().st_size, sha(p)), p)
shared = []
def retain(p, relative):
    target = r / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    assert not target.exists()
    h = sha(p)
    old = known.get((p.stat().st_size, h))
    if old:
        os.link(old, target)
        shared.append({'path': str(relative), 'immutableSource': str(old.relative_to(root)), 'sha256': h})
    else: shutil.copy2(p, target)
    assert sha(target) == h and (target.stat().st_dev, target.stat().st_ino) not in mutable
    known.setdefault((target.stat().st_size, h), target)
for p in staging.rglob('*'):
    if p.is_file(): retain(p, p.relative_to(staging))
reader = root / 'var/qa/fixed-c2bea309-native-locked-20261021/api-runtime-v1/ClairvoyanceIndependentFrameReaderV2.dll'
retain(reader, Path(reader.name))
command = ['/Users/dinghaolin/.dotnet/dotnet', 'exec', '--depsfile', str(r / 'Riftbound.PostgresAcceptance.deps.json'), '--runtimeconfig', str(r / 'Riftbound.PostgresAcceptance.runtimeconfig.json'), str(r / reader.name), 'identity-print']
identity = json.loads(subprocess.check_output(command, cwd=r))
assert identity == fixed['actualRuleInputs']
plan_raw = subprocess.check_output(['/Users/dinghaolin/.dotnet/dotnet', str(r / 'Riftbound.PostgresAcceptance.dll'), '--ci-partition-plan'], cwd=r)
(out / 'actual-default-sql-plan-original-v1.json').write_bytes(plan_raw)
plan = json.loads(plan_raw)
old = json.loads((w / 'root-original-input-retention-v1.json').read_text())
assert plan['cases'][:48] == old['original48Cases'] and len(plan['cases']) == 49
assert plan['cases'][48] == {'id': 'candlelit-private-look', 'sourceType': 'CandlelitPrivateLookSqlAcceptance'}
files = {str(p.relative_to(r)): sha(p) for p in r.rglob('*') if p.is_file()}
proof = {'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': 'FINAL_ROOT_SQL_CLASS_AND49_CASE_PLAN_FROZEN_NOT_DATABASE_ACCEPTANCE', 'parentCommit': 'c2bea309e2b73cdd730f57bf8761bb04a6c42ce8', 'sourceInputHashes': inputs, 'sourceInputModes': modes, 'runtimeFiles': files, 'sharedImmutableFiles': shared, 'actualRuleInputs': identity, 'identityReaderCommand': command, 'original48IdsAndOrderExact': True, 'noMutableRootSourceOrBuildInodesShared': True, 'runtimeRoot': str(r)}
(out / 'frozen-final-root-inputs-v1.json').write_text(json.dumps(proof, indent=2) + '\n')
src = out / 'independent-reader-source-v1'
src.mkdir()
oldsrc = w / 'independent-reader-source-v1'
text = (oldsrc / 'Program.cs').read_text()
assert text.count('"actual-five-candlelit-sql-v1"') == 1
text = text.replace('"actual-five-candlelit-sql-v1"', '"candlelit-private-look"').replace('PASS_INDEPENDENT_FIXED_F470_CANDLELIT_FIVE_', 'PASS_INDEPENDENT_FINAL_ROOT_CANDLELIT_FIVE_').replace('C32_INDEPENDENT_PASS', 'CANDLELIT_ROOT_INDEPENDENT_PASS')
(src / 'Program.cs').write_text(text)
project = (oldsrc / 'probe.csproj').read_text().replace('var/qa/fixed-f470429-native-locked-20261021/api-runtime-v1', str(r.relative_to(root))).replace('CurrentCandlelitIndependentSqlReaderV1', 'FinalRootCandlelitIndependentSqlReaderV1')
(src / 'probe.csproj').write_text(project)
print('Frozen final root SQL', len(files), 'files;', len(shared), 'immutable shares; original48 exact; 3319 source inputs;', json.dumps(identity), flush=True)
