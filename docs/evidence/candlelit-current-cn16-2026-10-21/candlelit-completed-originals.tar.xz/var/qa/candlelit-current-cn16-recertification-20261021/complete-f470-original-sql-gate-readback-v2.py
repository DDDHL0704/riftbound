from pathlib import Path
import datetime, hashlib, importlib.util, json, zipfile

w = Path(__file__).resolve().parent; root = w.parents[2]
out = w / 'preceding-f470-all4-sql-originals-v1'
prior = json.loads((w / 'preceding-f470-all4-sql-and-network-original-readback-v1.json').read_text())
fixed = prior['fixedCommit']; assert fixed == 'f4704291ff87c99b1599d93f0fc71700f0433cae'
assert len(prior['partitions']) == 4 and sum(r['outputs'] for r in prior['partitions']) == 320
sha = lambda b: hashlib.sha256(b).hexdigest()
materialized = []
for row in prior['partitions']:
    index = row['index']; artifact = next(x for x in prior['artifacts'] if x['name'] == 'postgres-partition-' + str(index))
    archive = root / artifact['path']; assert sha(archive.read_bytes()) == artifact['sha256']
    directory = out / ('partition-' + str(index)); receipt = json.loads((directory / 'partition-receipt.json').read_text())
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for f in receipt['outputFiles']:
            target = directory / f['path']; assert not target.exists() and target.resolve().is_relative_to(directory.resolve())
            raw = z.read('ci-postgres/' + f['path']); assert len(raw) == f['bytes'] and sha(raw) == f['sha256']
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as stream: stream.write(raw)
            materialized.append({'path': str(target.relative_to(root)), 'bytes': len(raw), 'sha256': f['sha256']})
spec = importlib.util.spec_from_file_location('gate', root / 'scripts/sql-ci-gate.py'); gate = importlib.util.module_from_spec(spec); spec.loader.exec_module(gate)
verified = gate.verify(fixed, out / 'fixed-original48-sql-manifest.json', out, dict(scope='success', postgres_partitions='success', native_network='success'))
assert verified['caseCount'] == 48 and len(verified['partitions']) == 4
prior.update(atUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(), status='PASS_FIXED_F470_ACTUAL_ALL4_SQL48_ORIGINAL320_OUTPUTS_AND_NATIVE15_GATE_NOT_ENTIRE_FULL', outputFiles=320, actualCiRuleInputs=prior['partitions'][0]['actualCiRuleInputs'], actualGateIndependentResult=verified, ciReportedRuntimeIdentitiesEqualAcrossAllFourParts=True, independentlyDownloadedRuntimeDllsNotClaimed=True, originalV1PreMaterializationGateFailureRetained=True, correctedOnlyOriginalOutputFilesMaterializationNoDownloadOrCiRerun=True, materializedOriginalFiles=materialized, entireFixedFullRulesNativeVisibleOrWindowsCertified=False)
with (w / 'preceding-f470-all4-sql-and-network-original-readback-v2.json').open('x') as f: json.dump(prior, f, indent=2)
print(prior['status'], flush=True)
