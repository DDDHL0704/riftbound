from pathlib import Path
import gzip, hashlib, json, tarfile

w = Path(__file__).resolve().parent; root = w.parents[2]
load = lambda p: json.loads(p.read_text()); sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
evidence = root / 'docs/evidence/candlelit-current-cn16-2026-10-21'
manifest = load(root / 'docs/audit/current-manifest.json')
prior = json.loads(gzip.decompress((w / 'prior-original-governance-inputs-v1/current-manifest.json.gz').read_bytes()))
reviews = load(root / manifest['inputs']['reviews']['path'])
old_reviews = json.loads(gzip.decompress((w / 'prior-original-governance-inputs-v1/review-decisions.json.gz').read_bytes()))
assert len(reviews['reviews']) == 151 and reviews['reviews'][:150] == old_reviews['reviews']
assert len(manifest['reviewContexts']) == 66 and all(manifest['reviewContexts'][k] == v for k, v in prior['reviewContexts'].items())
assert manifest['certificationScope'] == prior['certificationScope'] and manifest['laterSourceDeltas'] == prior['laterSourceDeltas'] and len(manifest['laterSourceDeltas']) == 7 and manifest['cardCoverageManifest'] == prior['cardCoverageManifest']
assert len(manifest['acceptanceGates']) == 245
old_gates = {g['id']: g for g in prior['acceptanceGates']}; gates = {g['id']: g for g in manifest['acceptanceGates']}
assert set(gates) == set(old_gates) and all(gates[k] == v for k, v in old_gates.items() if k != 'ROOM_IDENTITY_BOUNDARY')
assert all(gates['ROOM_IDENTITY_BOUNDARY'][k] == v for k, v in old_gates['ROOM_IDENTITY_BOUNDARY'].items())
assert gates['ROOM_IDENTITY_BOUNDARY']['state'] == 'OPEN'
archives = load(evidence / 'archive-map.json'); members = 0
for block in archives['archives']:
    archive = root / block['archive']['path']; assert sha(archive) == block['archive']['sha256']
    with tarfile.open(archive, 'r:xz') as tar:
        entries = tar.getmembers(); expected = {r['path']: r for r in block['members']}
        assert len(entries) == len(expected) and {e.name for e in entries} == set(expected)
        for entry in entries:
            r = expected[entry.name]; raw = tar.extractfile(entry).read()
            assert len(raw) == r['bytes'] and hashlib.sha256(raw).hexdigest() == r['sha256']
            assert sha(root / entry.name) == r['sha256'], entry.name
        members += len(entries)
    assert not any('/runtime' in p['path'] or p['path'].endswith('.app') for p in block['members'])
source = load(evidence / 'source-manifest.json'); assert source['region'] == 'CN' and source['language'] == 'zh-CN' and source['adoptedCoreEffectiveAsOf'] == '2026-10-16' and source['wholePrintingOrGlobalCertification'] is False
identity = 'candlelit-current-cn16-five-private-look-sql-2026-10-21'; context = manifest['reviewContexts'][identity]
assert context['ciState'] == 'PENDING' and not context['ciReceipts'] and len(context['branches']) == 5
assert all(b['decision']['state'] == 'OPEN' and b['wholePrintingCertified'] is False and b['semanticReview']['state'] == 'BOUNDED_CURRENT_SOURCE_AND_LITERAL_BRANCH_REVIEW_PASS' and b['fixedCommitCi']['state'] == 'PENDING_NEW49_SQL_FIXED_CANDIDATE' and b['productAcceptance']['state'] == 'OPEN' for b in context['branches'])
new_gov = load(w / 'actual-final-governance-v2.json'); old_gov = load(root / 'var/qa/canonical-room-player-identity-20261021/actual-post-publication-governance-full-v1.json')
assert new_gov['governanceValid'] and new_gov['errors'] == [] and new_gov['semanticCoverageCertified'] is False
assert new_gov['counts'] == old_gov['counts'] and new_gov['currentReviewCount'] == 151
old_rows = {r['id']: r for r in old_gov['remainingObligations']}; new_rows = {r['id']: r for r in new_gov['remainingObligations']}
assert len(old_rows) == 16944 and len(new_rows) == 16949 and set(old_rows) <= set(new_rows)
expected_added = {'BRANCH:' + identity + ':' + b['id'] for b in context['branches']}
assert set(new_rows) - set(old_rows) == expected_added
allowed_changes = {'CARD:OGN-291/298', 'GATE:ROOM_IDENTITY_BOUNDARY'} | {'RULE:' + r for r in reviews['reviews'][-1]['ruleRecords']}
changed = {k for k in old_rows if old_rows[k] != new_rows[k]}
assert changed <= allowed_changes
for key in changed - {'GATE:ROOM_IDENTITY_BOUNDARY'}:
    before = old_rows[key]; after = new_rows[key]
    assert set(after) == set(before) and all(after[k] == v for k, v in before.items() if k != 'scopedReviewRefs')
    assert after['scopedReviewRefs'] == before['scopedReviewRefs'] + [identity]
compact = {'status': 'PASS_INDEPENDENT_PUBLICATION_ALL_ORIGINAL_REVIEW_CONTEXT_GATE_SOURCE_AND16944_OBLIGATION_IDENTITIES_RETAINED', 'archives': len(archives['archives']), 'originalArchiveMembersVerified': members, 'original150ReviewObjectsAnd65WholeContextsValueExact': True, 'original245GateIdentitiesAnd244WholeGatesValueExact': True, 'oldRoomIdentityGateFieldsExactWithCurrentC2SubscopeOnlyAdded': True, 'original16944ObligationIdsKeptOnlyFivePreciseNewBranchIdsAdded': True, 'changedOldRowsOnlyAppendNewScopedReviewRefOrRoomSubscopeEvidence': sorted(changed), 'actualObligations': 16949, 'actualReviews': 151, 'actualContexts': 66, 'actualGates': 245, 'actualDeltas': 7, 'allOriginalSourceCoverageDatesCountsAndGapsExact': True, 'currentGovernanceValid': True, 'semanticCoverageCertified': False, 'wholePrintingCurrentFixedFullVisibleAndPhysicalWindowsAcceptance': 'OPEN'}
with (w / 'publication-independent-readback-v2.json').open('x') as f: json.dump(compact, f, indent=2)
with (evidence / 'actual-governance-summary.json').open('x') as f: json.dump({k: new_gov[k] for k in ['governanceValid', 'semanticCoverageCertified', 'counts', 'errors', 'warnings', 'currentReviewCount', 'branchObligationStates', 'completionRate']}, f, ensure_ascii=False, indent=2)
with (evidence / 'publication-independent-readback.json').open('x') as f: json.dump(compact, f, indent=2)
print(compact['status'], members, 'original members;151/66/245/7/16949; no global certification', flush=True)
