from pathlib import Path
import datetime, hashlib, json, tarfile

root = Path('/Users/dinghaolin/MyProjects/riftbound'); w = Path(__file__).resolve().parent
e = root / 'docs/evidence/candlelit-current-cn16-2026-10-21'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
names = ['publish-final-candlelit-cn16-batch-v1.log', 'publication-root-governance-retention-v1.json',
    'prior-original-governance-inputs-v1/PROJECT_STATUS.md.gz',
    'actual-final-governance-v1.json', 'actual-final-governance-v1.log',
    'actual-final-governance-v2.json', 'actual-final-governance-v2.log',
    'actual-final-governance-v3.json', 'actual-final-governance-v3.log',
    'verify-published-candlelit-cn16-batch-v1.log', 'verify-published-candlelit-cn16-batch-v2.py',
    'verify-published-candlelit-cn16-batch-v2.log', 'publication-independent-readback-v2.json',
    'verify-published-candlelit-cn16-batch-v3.py', 'verify-published-candlelit-cn16-batch-v3.log',
    'publication-independent-readback-v3.json', 'post-check-governance-alias-red-inputs-v1.json',
    'post-check-governance-alias-originals-v1/check-project-governance.py.gz',
    'post-check-governance-alias-originals-v1/test_project_governance.py.gz',
    'governance-alias-current-audit-red-v1.log', 'governance-alias-red-v1-incomplete-fixture-test-source.py.gz',
    'governance-alias-current-audit-red-v2.log', 'governance-alias-real-red-v2-test-source.py.gz',
    'python-post-check-governance-alias-green-v1.log', 'post-check-governance-alias-correction-readback-v1.json',
    'package-final-governance-and-publication-supplement-v1.py']
files = [w / p for p in names] + [root / 'scripts/audit/check-project-governance.py', root / 'scripts/tests/test_project_governance.py']
assert all(p.is_file() for p in files)
rows = [{'path': str(p.relative_to(root)), 'bytes': p.stat().st_size, 'sha256': sha(p)} for p in files]
archive = e / 'publication-and-tool-correction-originals.tar.xz'
with tarfile.open(archive, 'x:xz', preset=6) as tar:
    for p in files: tar.add(p, arcname=str(p.relative_to(root)), recursive=False)
with tarfile.open(archive, 'r:xz') as tar:
    assert len(tar.getmembers()) == len(rows) and {m.name for m in tar.getmembers()} == {r['path'] for r in rows}
    for row in rows:
        raw = tar.extractfile(row['path']).read(); assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
result = {'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': 'LOSSLESS_ORIGINAL_PUBLICATION_FAILURE_REAL_ALIAS_RED_AND_CORRECTION_FINAL_GOVERNANCE_SUPPLEMENT_VERIFIED', 'archive': {'path': str(archive.relative_to(root)), 'bytes': archive.stat().st_size, 'sha256': sha(archive)}, 'members': rows, 'originalInitialShadowedViewAndFailedStrictRetentionReadbackPreserved': True, 'realTwoAliasRedSubscopesAndFixtureSetupFailureDistinct': True, 'allOriginal73PythonMethodsPlusOneNewMethod74Pass': True, 'soleRuleCheckAndPostCheckVerificationChangesRemainSeparatelyRecorded': True, 'old150Reviews65ContextsAnd16944IdsNotReduced': True, 'final151Reviews66Contexts245Gates7Deltas16949ObligationsRemainUncertifiedGlobally': True}
with (e / 'publication-and-tool-correction-supplement.json').open('x') as f: json.dump(result, f, indent=2)
print(result['status'], len(rows), 'original files;', archive.stat().st_size, 'archive bytes', flush=True)
