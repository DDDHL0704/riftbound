import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

spec = importlib.util.spec_from_file_location('governance', Path(__file__).parents[1] / 'audit/check-project-governance.py')
gov = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gov)


class GovernanceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        (self.root/'proof.json').write_text('{}')
        cn_cards = [{'id': 1, 'cardNo': 'ARC\u00b7001/006'},
                    {'id': 2, 'cardNo': 'ARC\u00b7001a/006'}]
        en_cards = [{'id': 'arc-001-006', 'publicCode': 'ARC-001/006'}]
        cards = []
        for c in cn_cards:
            sources = [dict(language='zh-CN', sourceId=c['id'], cardNo=c['cardNo'], sha256=gov.digest(c))]
            if c['id'] == 1:
                e = en_cards[0]
                sources.append(dict(language='en-US', sourceId=e['id'], cardNo=e['publicCode'], sha256=gov.digest(e)))
            cards.append(dict(id=gov.number(c['cardNo']), sources=sources,
                              activeCardNo=c['cardNo'] if c['id'] == 1 else None, reviewStatus='NOT_REVIEWED'))
        cn_hash, en_hash = 'a'*64, 'b'*64
        cn_id, en_id = 'CN-'+cn_hash[:16], 'EN-'+en_hash[:16]
        self.data = dict(
            cards=dict(date='2026-10-11', records=cards),
            rules=dict(date='2026-10-11', documents=[
                dict(id=cn_id, sha256=cn_hash, url='https://example.invalid/cn'),
                dict(id=en_id, sha256=en_hash, url='https://example.invalid/en')], records=[
                dict(id=cn_id+'-P001-B001', document=cn_id, sourceRecord='DOC-01-P001-B001',
                     textHash=gov.digest('rule text'), reviewStatus='NOT_REVIEWED'),
                dict(id=en_id+'-P001-B001', document=en_id, text='global rule',
                     textHash=gov.digest('global rule'), reviewStatus='NOT_REVIEWED')]),
            corpus=dict(date='2026-10-11', documents=[dict(id='DOC-01', sha256=cn_hash,
                url='https://example.invalid/cn', pages=[dict(page=1, blocks=['DOC-01-P001-B001'])])],
                records=[dict(id='DOC-01-P001-B001', document='DOC-01', page=1, text='rule text')]),
            reviews=dict(overallStatus='IN_PROGRESS_NOT_READY', reviews=[dict(id='partial',
                status='VERIFIED_SCOPED_BEHAVIOR', scope='One bounded behavior', subjects=['ARC-001/006'],
                ruleRecords=['DOC-01-P001-B001'], evidence=['proof.json'], validation=dict(wholeCardCertification=False),
                exclusions=['Other printed abilities'])]),
            summary=dict(date='2026-10-11', goalStatus='IN_PROGRESS_NOT_READY', verifiedByIndexing=0,
                combinedExactPrintingNumbers=2, sourceDocuments=2, sourceBlocks=2, cnOfficialPrintings=2,
                enReturnedPrintings=1, enReportedTotal=2, enSourceCountGap=1, activeCatalogEntries=1,
                outsideActiveCatalog=1, cnQaFields=2, cnNonemptyQaFields=0, sourceFetchErrors=[]),
            cn=dict(cards=cn_cards), en=dict(cards=en_cards, reportedTotal=2), active=dict(cards=[cn_cards[0]]),
            qa=dict(entries=[dict(cardQaList=[]), dict(cardQaList=[])]),
            **{'global': dict(records=[dict(sha256=en_hash, url='https://example.invalid/en', text='global rule')], errors=[])})

    def validate(self):
        return gov.validate(self.data, self.root)

    def test_valid_index_retains_source_gap_variants_and_never_certifies_gameplay(self):
        result = self.validate()
        self.assertTrue(result['governanceValid'], result['errors'])
        self.assertFalse(result['semanticCoverageCertified'])
        self.assertEqual(2, result['counts']['combinedExactPrintingNumbers'])
        self.assertEqual(1, result['counts']['enSourceCountGap'])
        self.assertTrue(result['warnings'])

    def test_duplicate_id_and_dangling_reference_cannot_pass(self):
        original = copy.deepcopy(self.data)
        for key, field in [('cards', 'records'), ('rules', 'records'), ('corpus', 'records'), ('reviews', 'reviews')]:
            with self.subTest(key=key):
                self.data = copy.deepcopy(original)
                self.data[key][field].append(copy.deepcopy(self.data[key][field][0]))
                with self.assertRaisesRegex(ValueError, 'duplicate identity'):
                    self.validate()
        self.data = original
        self.data['reviews']['reviews'][0]['ruleRecords'] = ['DOC-99-P001-B001']
        self.assertFalse(self.validate()['governanceValid'])

    def test_source_text_hash_and_universe_changes_cannot_pass(self):
        original = copy.deepcopy(self.data)
        mutations = [lambda: self.data['cards']['records'][0]['sources'][0].update(sha256='0'*64),
                     lambda: self.data['rules']['records'][0].update(textHash='0'*64),
                     lambda: self.data['rules']['records'].pop(),
                     lambda: self.data['corpus']['documents'][0]['pages'][0]['blocks'].clear()]
        for mutate in mutations:
            self.data = copy.deepcopy(original)
            mutate()
            self.assertFalse(self.validate()['governanceValid'])

    def test_summary_mismatch_index_promotion_and_scoped_whole_card_claim_fail(self):
        original = copy.deepcopy(self.data)
        mutations = [lambda: self.data['summary'].update(sourceBlocks=1),
                     lambda: self.data['summary'].update(verifiedByIndexing=1),
                     lambda: self.data['summary'].update(goalStatus='COMPLETE'),
                     lambda: self.data['reviews']['reviews'][0]['validation'].update(wholeCardCertification=True)]
        for mutate in mutations:
            self.data = copy.deepcopy(original)
            mutate()
            self.assertFalse(self.validate()['governanceValid'])

    def test_freeform_legacy_review_stays_open_without_promoting_coverage(self):
        review = self.data['reviews']['reviews'][0]
        for key in ['ruleRecords', 'validation', 'exclusions']:
            del review[key]
        review['rules'] = ['DOC-01 123.1 (freeform scope)']
        result = self.validate()
        self.assertTrue(result['governanceValid'])
        self.assertFalse(result['semanticCoverageCertified'])
        self.assertTrue(any('heterogeneous' in warning for warning in result['warnings']))

    def test_future_effective_source_and_missing_evidence_fail(self):
        doc = self.data['rules']['documents'][0]
        doc.update(effectiveDate='2026-10-16', versionStatus='CURRENT')
        self.assertFalse(self.validate()['governanceValid'])
        doc['versionStatus'] = 'PUBLISHED_FUTURE_EFFECTIVE'
        self.assertTrue(self.validate()['governanceValid'])
        (self.root/'proof.json').unlink()
        self.assertFalse(self.validate()['governanceValid'])

    def test_missing_and_escaped_governance_links_fail(self):
        for name in gov.CANONICAL_DOCS:
            path = self.root/name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text('# policy\n')
        self.assertEqual([], gov.check_documents(self.root))
        (self.root/'README.md').write_text('[Missing](docs/missing.md)\n[Escape](../escape.md)\n')
        self.assertEqual(2, len(gov.check_documents(self.root)))


    def test_cn_delta_retains_reissued_ids_without_coalescing_printing(self):
        before = dict(cards=[dict(id=100, cardNo='RAD·001/167', isPreview=True)])
        after = dict(metadata=dict(totalItems=1), data=[dict(id=101, cardNo='RAD·001/167', isPreview=False)])
        result = gov.source_delta(before, after, 'cn_cards')
        self.assertEqual([100], result['removedIds'])
        self.assertEqual([101], result['addedIds'])
        self.assertEqual([], result['changed'])
        self.assertEqual(0, result['reportedMinusReturned'])
        self.assertFalse(result['semanticCertification'])
        self.assertEqual('REQUIRES_EXPLICIT_VERSION_DISPOSITION', result['applicability'])

    def test_cn_delta_records_changed_errata_and_removed_null_field(self):
        before = dict(cards=[dict(id=100, cardNo='RAD·001/167', errata='old text', cardQaList=None)])
        after = dict(metadata=dict(totalItems=1), data=[dict(id=100, cardNo='RAD·001/167', errata='new text')])
        result = gov.source_delta(before, after, 'cn_cards')
        self.assertEqual([dict(id=100, printing='RAD·001/167', changedFields=['cardQaList', 'errata'])], result['changed'])
        self.assertEqual([], result['addedIds'])
        self.assertEqual([], result['removedIds'])
        self.assertFalse(result['semanticCertification'])

    def test_en_delta_retains_public_code_and_source_gap(self):
        before = dict(cards=[dict(id='rad-001-167', publicCode='RAD-001/167', flags=['new'])])
        after = dict(metadata=dict(totalItems=2), data=[dict(id='rad-001-167', publicCode='RAD-001/167', flags=None)])
        result = gov.source_delta(before, after, 'cards')
        self.assertEqual([dict(id='rad-001-167', printing='RAD-001/167', changedFields=['flags'])], result['changed'])
        self.assertEqual(1, result['reportedMinusReturned'])
        self.assertFalse(result['semanticCertification'])
        with self.assertRaisesRegex(ValueError, 'Unsupported source delta kind'):
            gov.source_delta({}, {}, 'unknown')

    def test_current_rule_review_references_merge_ledger_and_corpus_ids(self):
        for name in gov.CANONICAL_DOCS:
            path = self.root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text('# Fixture governance document\n')

        def store(name, value):
            path = self.root / (name + '.json')
            path.write_text(json.dumps(value))
            return dict(path=path.name, sha256=gov.hashlib.sha256(path.read_bytes()).hexdigest())

        inputs = {key: store(key, value) for key, value in self.data.items() if key != 'qa'}
        qa = dict(catalogSha256=inputs['cn']['sha256'], entries=[
            dict(id=row['id'], cardNo=row['cardNo'], cardQaList=None) for row in self.data['cn']['cards']])
        inputs['qa'] = store('qa', qa)
        historical = store('historical', dict(reviews=[]))
        coverage = store('coverage', dict(scopedReviewDecisions=dict(sha256=historical['sha256']),
            counts={key: self.data['summary'][key] for key in ['combinedExactPrintingNumbers',
                'cnOfficialPrintings', 'enReturnedPrintings', 'enReportedTotal', 'enSourceCountGap', 'activeCatalogEntries']}))
        manifest = dict(schemaVersion=1, semanticCoverageCertified=False,
            certificationScope=dict(applicableAsOf='2026-10-11', region='CN', language='zh-CN',
                productPlayers=2, allOfficialObligationsRetained=True,
                sourceDates=dict.fromkeys(['cards', 'rules', 'corpus', 'summary'], '2026-10-11')),
            inputs=inputs, historicalReviewPin=historical, cardCoverageManifest=coverage,
            reviewContexts={}, acceptanceGates=[], laterSourceDeltas=[])
        original = copy.deepcopy(self.data['reviews']['reviews'][0])
        canonical = self.data['rules']['records'][0]['id']
        global_rule = self.data['rules']['records'][1]['id']
        both = dict(original, id='both', ruleRecords=['DOC-01-P001-B001', canonical])
        later = dict(original, id='later', ruleRecords=[canonical, global_rule])
        for rows, expected_cn, expected_global in [
            ([original], ['partial'], []),
            ([original, both], ['partial', 'both'], []),
            ([original, both, later], ['partial', 'both', 'later'], ['later']),
        ]:
            with self.subTest(reviews=[r['id'] for r in rows]):
                manifest['inputs']['reviews'] = store('reviews', dict(self.data['reviews'], reviews=rows))
                result = gov.current_audit(self.root, manifest)
                self.assertTrue(result['governanceValid'], result['errors'])
                self.assertFalse(result['semanticCoverageCertified'])
                rules = {r['sourceRecord']: r for r in result['remainingObligations'] if r['kind'] == 'RULE_RECORD'}
                self.assertEqual(expected_cn, rules[canonical]['scopedReviewRefs'])
                self.assertEqual(expected_global, rules[global_rule]['scopedReviewRefs'])
                self.assertEqual('NOT_CERTIFIED', rules[canonical]['semanticReview'])
                self.assertEqual({'RULE:' + canonical, 'RULE:' + global_rule},
                    {r['id'] for r in rules.values()})



if __name__ == '__main__':
    unittest.main()
