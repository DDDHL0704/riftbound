from pathlib import Path
import datetime, hashlib, json, os, shutil

os.umask(0o077)
root = Path('/Users/dinghaolin/MyProjects/riftbound')
w = Path(__file__).resolve().parent
old = root / 'var/qa/canonical-room-player-identity-20261021'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
api = load(w / 'fixed-clean-api-runtime-source-and-identity-v1.json')
app = load(w / 'native-app-inputs.json')
before = load(old / 'frozen-current-canonical-candidate-inputs-v3.json')
score = load(old / 'canonical-score-helper-runtime-v2.json')
assert api['fixedCommit'] == app['fixedCommit'] == 'c2bea309e2b73cdd730f57bf8761bb04a6c42ce8'
assert all(sha(w / 'api-runtime-v1' / p) == h for p, h in api['runtimeFiles'].items())
assert all(sha(old / 'canonical-score-helper-runtime-v2' / p) == h for p, h in score['runtimeFiles'].items())
assert all(sha(old / 'native-network-runtime-v1' / p) == h for p, h in before['networkRuntimeFiles'].items())
helpers = w / 'live-acceptance-helper-runtime-v1'
helpers.mkdir(exist_ok=False)
for relative, h in score['runtimeFiles'].items():
    source = w / 'api-runtime-v1' / relative if relative in api['runtimeFiles'] else old / 'canonical-score-helper-runtime-v2' / relative
    target = helpers / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    os.link(source, target)
for relative, h in api['runtimeFiles'].items():
    if (helpers / relative).exists(): continue
    target = helpers / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    os.link(w / 'api-runtime-v1' / relative, target)
network = w / 'native-network-runtime-v1'
network.mkdir(exist_ok=False)
for relative, h in before['networkRuntimeFiles'].items():
    target = network / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    os.link(old / 'native-network-runtime-v1' / relative, target)
source_scope = {p: h for p, h in api['sourceInputHashes'].items() if p.startswith(('src/', 'clients/')) or p.startswith('tests/Riftbound.NativeNetworkSmoke/')}
assert all(sha(root / p) == h for p, h in source_scope.items())
for row in app['apps']:
    assert all(sha(Path(row['app']) / p) == h for p, h in app['ciManagedAndPckPayloads'].items())
pub = {'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': 'FIXED_C2_CI_EXPORTED_PAIR_CLEAN_API_AND_FRESH_ROOM_HELPERS_FROZEN_NOT_GAME_ACCEPTANCE', 'fixedCommit': api['fixedCommit'], 'baseCommit': api['fixedCommit'], 'fixedCiRun': 39510792920, 'actualRuleInputs': api['actualRuleInputs'], 'runtimeFiles': api['runtimeFiles'], 'helperRuntimeFiles': {str(p.relative_to(helpers)): sha(p) for p in helpers.rglob('*') if p.is_file()}, 'networkRuntimeFiles': before['networkRuntimeFiles'], 'sourceScopeHashes': source_scope, 'identityReaderCommand': api['identityReaderCommand'], 'nativeApps': app['apps'], 'ciManagedAndPckPayloads': app['ciManagedAndPckPayloads'], 'helpersAreExistingSourceBuiltDriversReboundToExactCleanFixedC2ApiFiles': True, 'networkDriverSourceEqualsFixedC2ButBinaryOriginallyBuiltInN29NotClaimedCiArtifact': True, 'sourceBuiltNetworkBinarySha256': before['networkRuntimeFiles']['Riftbound.NativeNetworkSmoke.dll'], 'networkSourceSha256': sha(root / 'tests/Riftbound.NativeNetworkSmoke/Program.cs'), 'rootCurrentSqlOnlyBatchIsSeparateFromFixedC2NativeCandidate': True, 'allLinksAreBetweenPreviouslyFrozenImmutableRuntimes': True, 'noRootMutableBuildOrSourceFilesLinked': True}
with (w / 'frozen-fixed-c2-native-composition-v1.json').open('x') as f: json.dump(pub, f, indent=2)
print('Frozen fixedC2 CI373x2; API', len(pub['runtimeFiles']), 'helpers', len(pub['helperRuntimeFiles']), 'network', len(pub['networkRuntimeFiles']), 'source scope', len(source_scope), flush=True)
