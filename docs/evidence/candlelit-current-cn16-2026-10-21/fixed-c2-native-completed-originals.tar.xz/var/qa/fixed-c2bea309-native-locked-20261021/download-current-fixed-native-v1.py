import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import zipfile

os.umask(0o077)
work=Path(__file__).resolve().parent
metadata=json.loads((work/'native-current-ready-ci-artifacts-v1.json').read_text())
fixed='c2bea309e2b73cdd730f57bf8761bb04a6c42ce8'
folder=work/'native-current';folder.mkdir(exist_ok=False)
results=[]
try:
    for name,filename in [('native-macos-latest','mac-ci-artifact.zip'),('native-windows-latest','windows-ci-artifact.zip')]:
        meta=next(a for a in metadata['artifacts'] if a['name']==name)
        assert not meta['expired'] and meta['workflow_run']['head_sha']==fixed
        target=folder/filename
        with target.open('xb') as out:
            run=subprocess.run(['gh','api',f'repos/DDDHL0704/riftbound/actions/artifacts/{meta["id"]}/zip'],stdout=out,capture_output=False)
        digest=hashlib.sha256(target.read_bytes()).hexdigest()
        row={'name':name,'id':meta['id'],'filename':filename,'actualDownloadExitCode':run.returncode,'actualBytes':target.stat().st_size,'actualSha256':digest,'expectedBytes':meta['size_in_bytes'],'expectedDigest':meta['digest']};results.append(row)
        assert run.returncode==0 and row['actualBytes']==meta['size_in_bytes'] and meta['digest']=='sha256:'+digest
        with zipfile.ZipFile(target) as archive:
            assert archive.testzip() is None
            row['allOuterZipCrcVerified']=True
            row['entries']=[{'name':a.filename,'bytes':a.file_size,'crc32':format(a.CRC,'08x')} for a in archive.infolist()]
        print(name,'BACKEND_DIGEST_SIZE_AND_OUTER_CRC_PASS',row['actualBytes'],flush=True)
finally:
    with (work/'current-fixed-native-download-original-result-v1.json').open('x') as out:
        json.dump({'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fixedCommit':fixed,'runId':39510792920,'artifacts':results,'previousFixedA56137PairRetainedUntilNewUsabilityVerified':True,'newBootInnerPayloadAndPhysicalWindowsStillPending':True},out,indent=2)
