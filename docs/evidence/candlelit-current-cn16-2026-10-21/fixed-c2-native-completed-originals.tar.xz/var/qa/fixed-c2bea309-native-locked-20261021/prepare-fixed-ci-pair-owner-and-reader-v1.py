from pathlib import Path
import difflib, hashlib, json

root = Path('/Users/dinghaolin/MyProjects/riftbound')
w = Path(__file__).resolve().parent
old = root / 'var/qa/canonical-room-player-identity-20261021'
original = (old / 'run-current-source-tool-main-pair-v1.py').read_text()
text = original.replace(";prior_w=root/'var/qa/spell-remake-no-complete-choice-20261021'", '')
a = text.index("pub=load(w/'frozen-current-canonical-candidate-inputs-v3.json')")
b = text.index("cmd=pub['identityReaderCommand']")
text = text[:a] + '''pub=load(w/'frozen-fixed-c2-native-composition-v1.json');helper_pub={'runtimeFiles':pub['helperRuntimeFiles']}
previous=load(root/'var/qa/candlelit-current-cn16-recertification-20261021/root-final-sql-v1/actual-final-root-five-candlelit-sql-owner-terminal-v2.json')
original=load(root/'var/qa/candlelit-current-cn16-recertification-20261021/root-final-sql-v1/original236-audit50-native-seven-table-baseline-v2.json')
assert previous['status'].startswith('PASS_FINAL_ROOT_') and previous['ownPostgresSmartStopped'] and len(previous['actualAuditRoomsAtStop'])==241
''' + text[b:]
a = text.index('def frozen():')
b = text.index('def state(stage):')
text = text[:a] + '''def frozen():
 assert all(sha(api_runtime/p)==h for p,h in pub['runtimeFiles'].items())
 assert all(sha(helpers/p)==h for p,h in pub['helperRuntimeFiles'].items())
 assert all(sha(w/'native-network-runtime-v1'/p)==h for p,h in pub['networkRuntimeFiles'].items())
 assert all(sha(root/p)==h for p,h in pub['sourceScopeHashes'].items())
 assert all(sha(Path(a['app'])/p)==h for a in pub['nativeApps'] for p,h in pub['ciManagedAndPckPayloads'].items())
''' + text[b:]
a = text.index('def launch(role,label,frames,action=None):')
b = text.index('def native_wait(', a)
text = text[:a] + '''def launch(role,label,frames,action=None):
 app=Path(next(a['app'] for a in pub['nativeApps'] if a['label']==role));subprocess.run(['codesign','--verify','--deep','--strict',str(app)],check=True,capture_output=True)
 log=w/('live-ci-native-'+label+'-v1.log');args=[str(app/'Contents/MacOS/符文战场'),'--headless','--quit-after',str(frames),'--','--riftbound-server=http://127.0.0.1:15847','--riftbound-session-file='+str(w/('session-'+role+'.json')),'--riftbound-smoke-connect-only']
 if action:args+=['--riftbound-smoke-ui-action='+action,'--riftbound-smoke-ui-submit']
 env=dict(os.environ,DOTNET_DbgEnableMiniDump='0');env.pop('DOTNET_STARTUP_HOOKS',None)
 with log.open('xb') as stream:p=subprocess.Popen(args,cwd='/tmp',env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 record={'role':role,'label':label,'pid':p.pid,'actualCommand':args,'log':log.name,'action':action,'all373FixedCiManagedAndPckFilesAndDeepStrictSignatureVerifiedBeforeLaunch':True};proof['ownedNativeProcesses'].append(record);clients.append((p,record,log));return p,record,log

''' + text[b:]
needle="audit=rooms('riftbound_acceptance');native=rooms('riftbound_here_native');assert audit==prior['currentAuditRoomsAtStop'] and len(audit)==231 and native==previous_native['actualNativeRoomsAtStop'] and len(native)==48"
assert needle in text
text = text.replace(needle, "audit=rooms('riftbound_acceptance');native=rooms('riftbound_here_native');assert audit==previous['actualAuditRoomsAtStop'] and len(audit)==241 and native==previous['actualNativeRoomsAtStop'] and len(native)==50")
a = text.index(" old=load(prior_w/'independent-current-ten-and-clair-originals-run-v1.json')")
b = text.index(' start_api(1);', a)
text = text[:a] + text[b:]
text = text.replace("post['authoritativeState']['pendingRuleChoice'] is None", "post['authoritativeState']['pendingPayment'] is None")
text = text.replace('actualToolNativeInteractionControllerSubmissions=3', 'nativeAcceptedGameplayCommands=3')
text = text.replace("'fixedCommitOrCiAcceptance':False", "'fixedCommit':pub['fixedCommit'],'fixedCiRun':39510792920,'fixedExportedCiPayloads':True,'completeFixedCiAcceptanceStillPending':True,'networkToolBinaryFromN29WithExactCurrentSourceNotClaimedCiArtifact':True")
text = text.replace('UNCOMMITTED_SOURCE_CANDIDATE_TOOL', 'FIXED_C2_CI_EXPORTED').replace('CURRENT_SOURCE_TOOL', 'CURRENT_FIXED_CI_EXPORTED').replace('SOURCE_TOOL', 'FIXED_CI_EXPORTED')
text = text.replace('source tool', 'fixed CI exported').replace('tool', 'ci').replace('Tool', 'Ci')
text = text.replace('original231Audit48Native', 'original241Audit50Native').replace('Original231Audit48Native', 'Original241Audit50Native').replace('Original231Audit', 'Original241Audit').replace('Original48Native', 'Original50Native').replace('original231-audit48-native', 'original241-audit50-native')
text = text.replace('allFrozenApiHelperAndCurrent23CiPayloadHashesExact', 'allFrozenApiHelperAndBoth373CiPayloadHashesExact')
assert 'prior_w' not in text and 'previous_native' not in text and "['pendingRuleChoice']" not in text and '--path' not in text
assert text.count("'--riftbound-smoke-connect-only'") == 1
target = w / 'run-current-fixed-ci-main-pair-v1.py'
with target.open('x') as f: f.write(text)
(w / 'fixed-ci-pair-owner-derivation.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True), text.splitlines(True), fromfile=str(old / 'run-current-source-tool-main-pair-v1.py'), tofile=str(target))))
src = w / 'fixed-canonical-room-reader-source-v1'
src.mkdir(exist_ok=False)
reader = (old / 'canonical-room-history-reader-source-v2/Program.cs').read_text()
reader = reader.replace('same-canonical-room-score-ready-v2.json', 'live-current-ci-main-ready-v1.json')
reader = reader.replace('f4704291ff87c99b1599d93f0fc71700f0433cae', 'c2bea309e2b73cdd730f57bf8761bb04a6c42ce8')
reader = reader.replace('Current uncommitted source tool candidate; three actual native interaction submissions, fixed CI/visible acceptance open.', 'Exact fixed C2 candidate and three CI exported native interaction submissions; full CI and visible acceptance remain separate.')
reader = reader.replace('same-canonical-original-room-continuation-v2/after-same-original-canonical-normal-score-final-frame-v1.json.gz', 'actual-safe-native-main-v1/after-current-ci-native-normal-score-final-original-frame-v1.json.gz')
reader = reader.replace('before-tool-native-cold-reconnect', 'before-ci-native-cold-reconnect').replace('actual-safe-normal-score-continuation-v2', 'actual-safe-normal-score-continuation-v1')
reader = reader.replace('source-tool native', 'CI exported native').replace('PASS_INDEPENDENT_SAME_CANONICAL_ROOM_NATIVE3_GATEWAY17_ALL_SQL_HISTORY_AND_NORMAL_SCORE_REPLAY_NOT_FIXED_CI_OR_VISIBLE', 'PASS_INDEPENDENT_FIXED_C2_CI_EXPORTED_NATIVE3_GATEWAY17_ALL_SQL_HISTORY_AND_NORMAL_SCORE_REPLAY_NOT_VISIBLE_OR_WINDOWS')
reader = reader.replace('originalIssue77FixCandidateRequiresFixedCiAndVisibleAcceptance', 'completeCurrentCandidateFullCiVisibleAndWindowsAcceptanceRemainSeparate')
(src / 'Program.cs').write_text(reader)
project = (old / 'canonical-room-history-reader-source-v2/probe.csproj').read_text().replace('CurrentCanonicalRoomSqlReaderV2', 'FixedC2CanonicalRoomSqlReaderV1')
(src / 'probe.csproj').write_text(project)
(w / 'fixed-ci-pair-owner-and-reader-source-inputs-v1.json').write_text(json.dumps({'oldOwnerSha256': hashlib.sha256(original.encode()).hexdigest(), 'newOwnerSha256': hashlib.sha256(text.encode()).hexdigest(), 'newReaderSha256': hashlib.sha256(reader.encode()).hexdigest(), 'knownSerializedPendingPaymentAndCorrectedOwnBattlefieldScoreHelperRetained': True, 'allIndependentLiteralStatePrivacyTargetCostNormalScoreAndFullReplayAssertionsRetained': True, 'fixedCiExportEntryUsesDefaultMainWithoutSceneOverride': True}, indent=2))
print('Fixed C2 exported owner/independent reader prepared; inspect diff before execution', flush=True)
