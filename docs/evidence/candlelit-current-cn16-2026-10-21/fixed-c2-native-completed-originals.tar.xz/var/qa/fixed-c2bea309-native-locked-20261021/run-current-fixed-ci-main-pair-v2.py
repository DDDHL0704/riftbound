import ast,collections,datetime,fcntl,gzip,hashlib,json,os,plistlib,re,resource,socket,subprocess,time,urllib.request
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();load=lambda p:json.loads(p.read_text())
source=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v2.py';nodes=[n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),globals())
pub=load(w/'frozen-fixed-c2-native-composition-v1.json');helper_pub={'runtimeFiles':pub['helperRuntimeFiles']}
previous=load(root/'var/qa/candlelit-current-cn16-recertification-20261021/root-final-sql-v1/actual-final-root-five-candlelit-sql-owner-terminal-v2.json')
original=load(root/'var/qa/candlelit-current-cn16-recertification-20261021/root-final-sql-v1/original236-audit50-native-seven-table-baseline-v2.json')
assert previous['status'].startswith('PASS_FINAL_ROOT_') and previous['ownPostgresSmartStopped'] and len(previous['actualAuditRoomsAtStop'])==241
cmd=pub['identityReaderCommand'];api_runtime=Path(cmd[cmd.index('--depsfile')+1]).parent;helpers=w/'live-acceptance-helper-runtime-v1';evidence=w/'actual-safe-native-main-v2';evidence.mkdir(exist_ok=False)
terminal=w/'live-current-ci-main-owner-terminal-v2.json';ready=w/'live-current-ci-main-ready-v2.json';stop=w/'live-current-ci-main-stop-v2.json';assert not any(p.exists() for p in [terminal,ready,stop])
def checkpoint(name,data):
 p=evidence/name
 with p.open('x') as stream:json.dump(data,stream,ensure_ascii=False,indent=2)
def frozen():
 assert all(sha(api_runtime/p)==h for p,h in pub['runtimeFiles'].items())
 assert all(sha(helpers/p)==h for p,h in pub['helperRuntimeFiles'].items())
 assert all(sha(w/'native-network-runtime-v1'/p)==h for p,h in pub['networkRuntimeFiles'].items())
 assert all(sha(root/p)==h for p,h in pub['sourceScopeHashes'].items())
 assert all(sha(Path(a['app'])/p)==h for a in pub['nativeApps'] for p,h in pub['ciManagedAndPckPayloads'].items())
def state(stage):
 proof['stage']=stage;proof['updatedAtUtc']=now();tmp=w/'live-current-ci-owner-state-v2.tmp';tmp.write_text(json.dumps(proof,indent=2));tmp.replace(w/'live-current-ci-owner-state-v2.json');print(stage,flush=True)
def start_api(index):
 global api
 frozen();log=w/('live-current-ci-api-'+str(index)+'-v2.log');env=dict(os.environ,ASPNETCORE_ENVIRONMENT='Production',ASPNETCORE_URLS='http://127.0.0.1:15847',ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit',DOTNET_DbgEnableMiniDump='0');env.pop('DOTNET_STARTUP_HOOKS',None)
 with log.open('xb') as stream:api=subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet',str(api_runtime/'Riftbound.Api.dll')],cwd=api_runtime,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 until=time.monotonic()+20
 while time.monotonic()<until:
  assert api.poll() is None
  try:
   with urllib.request.urlopen('http://127.0.0.1:15847/health',timeout=.5) as response:health=json.load(response)
   assert health['persistenceMode']=='postgres' and health['environment']=='Production'
   assert set(subprocess.check_output(['/usr/sbin/lsof','-tiTCP:15847','-sTCP:LISTEN'],text=True).splitlines())=={str(api.pid)}
   proof['ownedApiProcesses'].append({'pid':api.pid,'index':index,'health':health,'log':log.name,'atUtc':now()});return
  except OSError:time.sleep(.1)
 raise AssertionError('Owned frozen API did not become ready')
def export(name):
 target=evidence/(name+'.json.gz');assert not target.exists()
 args=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(helpers/'Riftbound.Api.deps.json'),'--runtimeconfig',str(helpers/'Riftbound.Api.runtimeconfig.json'),str(helpers/'FixedNativeFrameExport.dll'),room,str(target)]
 env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit;Options=-c default_transaction_read_only=on',DOTNET_DbgEnableMiniDump='0')
 raw=subprocess.check_output(args,cwd=helpers,env=env);metadata=json.loads(raw);assert metadata['actualRuleInputs']==pub['actualRuleInputs'];checkpoint(name+'-metadata.json',metadata)
 frame=json.loads(gzip.decompress(target.read_bytes()));assert frame['isConsistent'] and not frame['validationErrors'] and frame['authoritativeState']['ruleInputs']==pub['actualRuleInputs'];return frame

def count():
 assert room is not None and re.fullmatch('N27-RETARGET-[0-9A-F]{10}',room)
 return int(query('riftbound_here_native',"select count(*) from command_log where match_id='"+room+"'"))
def launch(role,label,frames,action=None):
 app=Path(next(a['app'] for a in pub['nativeApps'] if a['label']==role));subprocess.run(['codesign','--verify','--deep','--strict',str(app)],check=True,capture_output=True)
 log=w/('live-ci-native-'+label+'-v2.log');args=[str(app/'Contents/MacOS/符文战场'),'--headless','--quit-after',str(frames),'--','--riftbound-server=http://127.0.0.1:15847','--riftbound-session-file='+str(w/('session-'+role+'.json')),'--riftbound-smoke-connect-only']
 if action:args+=['--riftbound-smoke-ui-action='+action,'--riftbound-smoke-ui-submit']
 env=dict(os.environ,DOTNET_DbgEnableMiniDump='0');env.pop('DOTNET_STARTUP_HOOKS',None)
 with log.open('xb') as stream:p=subprocess.Popen(args,cwd='/tmp',env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 record={'role':role,'label':label,'pid':p.pid,'actualCommand':args,'log':log.name,'action':action,'all373FixedCiManagedAndPckFilesAndDeepStrictSignatureVerifiedBeforeLaunch':True};proof['ownedNativeProcesses'].append(record);clients.append((p,record,log));return p,record,log

def native_wait(predicate,why,seconds=40,alive=()):
 until=time.monotonic()+seconds
 while not predicate():
  assert time.monotonic()<until,why
  assert api is not None and api.poll() is None,why+' API exited'
  assert all(p.poll() is None for p in alive),why+' native process exited'
  time.sleep(.1)
def log_count(path,channel):return path.read_text(errors='replace').count('[b]'+channel+'[/b]') if path.exists() else 0
def wait_exit(item,timeout):
 p,record,log=item;code=p.wait(timeout=timeout);record.update(exitCode=code,logSha256=sha(log));assert code==0,'Native default Main failed';assert 'ERROR:' not in log.read_text(errors='replace') and 'Unhandled exception' not in log.read_text(errors='replace')

guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof={'status':'RUNNING_FIXED_C2_CI_EXPORTED_MAIN_HEADLESS_PAIR_NOT_VISIBLE_OR_WINDOWS','startedAtUtc':now(),'baseCommit':pub['baseCommit'],'fixedCommit':pub['fixedCommit'],'fixedCiRun':39510792920,'fixedExportedCiPayloads':True,'completeFixedCiAcceptanceStillPending':True,'networkSourceBuiltBinaryFromN29WithExactCurrentSourceNotClaimedCiArtifact':True,'actualRuleInputs':pub['actualRuleInputs'],'lockAtStart':observe_lock(),'ownedApiProcesses':[],'ownedNativeProcesses':[],'visibleOrPhysicalWindowsAcceptance':False,'nativeSmokeUsesProductionInteractionControllerAndSubmitRouteNotHardwareButtonEvents':True,'original241Audit50NativeSevenTablesProtected':True}
api=power=driver=None;clients=[];started=False;room=None;audit=native=None;before_audit=before_native=None
try:
 frozen();assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof.update(ownPid=os.getpid(),boundIdleAssertionPid=power.pid);state('STARTING_OWN_PG_WITH_EXISTING_DATABASES')
 sock.mkdir(exist_ok=True);subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'live-current-ci-postgres-v2.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 audit=rooms('riftbound_acceptance');native=rooms('riftbound_here_native');assert audit==previous['actualAuditRoomsAtStop'] and len(audit)==241 and native==previous['actualNativeRoomsAtStop'] and len(native)==50
 before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',native)
 assert digests('riftbound_acceptance',original['auditRooms'])==original['auditSevenTables'] and digests('riftbound_here_native',original['nativeRooms'])==original['nativeSevenTables']
 checkpoint('original241-audit50-native-seven-table-baseline-v2.json',{'atUtc':now(),'auditRooms':audit,'nativeRooms':native,'auditSevenTables':before_audit,'nativeSevenTables':before_native})
 start_api(1);state('FIXED_CURRENT_API_READY_ORDINARY_NEW_ROOM_PREFIX')
 prefix=w/'actual-safe-native-prefix-v2';assert not prefix.exists()
 with (w/'live-current-ci-prefix-writer-v2.log').open('xb') as stream:
  driver=subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet',str(helpers/'Fixed564SafeNativeReversalPrefix.dll'),'http://127.0.0.1:15847',str(prefix),str(w)],cwd=helpers,stdout=stream,stderr=subprocess.STDOUT,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0'));assert driver.wait(timeout=780)==0,'Ordinary fresh prefix failed; keep its partial room'
 entry=load(prefix/'pending-original-native-prefix-receipt.json');room=entry['room'];n=entry['acceptedCommands'];a,b=entry['players'];proof.update(room=room,originalGatewayPrefixCommands=n);assert set(rooms('riftbound_here_native'))==set(native)|{room}
 initial=export('before-ci-native-cold-reconnect-original-frame-v2');assert len(initial['commands'])==n
 pair=[launch('a','observe-a',3600),launch('b','observe-b',3600)]
 native_wait(lambda:all(log_count(item[2],'Joined')>=1 and log_count(item[2],'Snapshot')>=1 and log_count(item[2],'Prompt')>=1 for item in pair),'Both actual FIXED_CI_EXPORTED default Main clients received their own original prompt',40,[item[0] for item in pair])
 counts=[{k:log_count(item[2],k) for k in ['Joined','Snapshot','Prompt']} for item in pair];before_cold=export('both-ci-main-before-cold-original-frame-v2');assert len(before_cold['commands'])==n
 state('BOTH_FIXED_CI_EXPORTED_DEFAULT_MAIN_CLIENTS_CURRENT_PENDING_WINDOW_RESTARTING_OWN_API')
 api.terminate();api.wait(timeout=25);start_api(2)
 native_wait(lambda:all(all(log_count(item[2],k)>counts[i][k] for k in ['Joined','Snapshot','Prompt']) for i,item in enumerate(pair)),'Both original FIXED_CI_EXPORTED native transports reauthenticated and received current restored projections',45,[item[0] for item in pair])
 after_cold=export('both-ci-main-after-cold-original-frame-v2');assert after_cold['commands']==before_cold['commands'] and after_cold['events']==before_cold['events'] and after_cold['authoritativeState']==before_cold['authoritativeState'] and count()==n
 checkpoint('actual-ci-native-cold-reconnect-v2.json',{'atUtc':now(),'bothOriginalNativeProcessesStillAlive':True,'beforeCounts':counts,'afterCounts':[{k:log_count(item[2],k) for k in ['Joined','Snapshot','Prompt']} for item in pair],'sameOriginalCommandsEventsAndWholeAuthoritativeState':True,'actualRuleInputs':pub['actualRuleInputs'],'sourceInitialAndPrivateSeedNotMigrated':True})
 for item in pair:wait_exit(item,75)
 state('LOCKED_CURRENT_FIXED_CI_EXPORTED_NATIVE_KEEP_AND_TWO_PRIORITY_SUBMISSION_ROUTES')
 own_a=launch('a','ui-pass-a',2400,'PASS_PRIORITY');own_b=launch('b','ui-keep-b',600,'PAY_COST')
 native_wait(lambda:count()==n+1,'Current controller made the original KEEP decision through actual exported Main',30,[own_a[0],own_b[0]])
 kept=export('after-ci-native-keep-original-frame-v2');last=kept['commands'][-1];assert last['playerId']==b and last['commandType']=='PAY_COST' and last['rawCommand']['paymentChoiceIds']==['KEEP_ALL']
 wait_exit(own_b,25);own_b_pass=launch('b','ui-pass-b',600,'PASS_PRIORITY')
 native_wait(lambda:count()==n+3,'Both actual FIXED_CI_EXPORTED native current prompt priority submissions completed the original parent',30,[own_a[0],own_b_pass[0]])
 post=export('after-native-priority-pass-2-original-frame-v2');assert len(post['commands'])==n+3 and not post['authoritativeState']['stackItems'] and post['authoritativeState']['pendingPayment'] is None
 assert post['commands'][:n]==initial['commands'] and post['events'][:len(initial['events'])]==initial['events'] and post['openingSeed']==initial['openingSeed'] and post['replayInitialState']==initial['replayInitialState']
 for item in [own_a,own_b_pass]:wait_exit(item,55)
 for item in [own_a,own_b,own_b_pass]:assert 'UI smoke staged '+item[1]['action'] in item[2].read_text()
 proof.update(nativeAcceptedGameplayCommands=3,hardwareButtonOrVisibleControlsClaim=False,actualColdRestartAndBothCiNativeRestore=True);state('CURRENT_ORIGINAL_NATIVE_ROOM_NORMAL_SCORE_CONTINUATION')
 score=w/'actual-safe-normal-score-continuation-v2';assert not score.exists()
 with (w/'live-current-ci-normal-score-writer-v2.log').open('xb') as stream:
  driver=subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet',str(helpers/'Fixed564SafeBandleScore.dll'),'http://127.0.0.1:15847',str(score),str(w)],cwd=helpers,stdout=stream,stderr=subprocess.STDOUT,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0'));assert driver.wait(timeout=330)==0,'Keep the original room and its current tokens if normal continuation fails'
 score_receipt=load(score/'normal-original-score-continuation-receipt.json');assert score_receipt['continuationCommands']==17 and score_receipt['winningScore']==8
 final=export('after-current-ci-native-normal-score-final-original-frame-v2');current=final['authoritativeState'];assert len(final['commands'])==n+20 and current['status']=='FINISHED' and current['winnerPlayerId']==a and current['playerScores']=={a:8,b:0}
 assert final['commands'][:n+3]==post['commands'] and final['events'][:len(post['events'])]==post['events'] and final['openingSeed']==initial['openingSeed'] and final['replayInitialState']==initial['replayInitialState']
 assert all(c['commandType']!='SURRENDER' for c in final['commands'])
 frozen();assert digests('riftbound_acceptance',audit)==before_audit and digests('riftbound_here_native',native)==before_native
 proof.update(status='CURRENT_FIXED_CI_EXPORTED_NATIVE_AND_NORMAL_SCORE_READY_FOR_INDEPENDENT_FULL_SQL_HISTORY_REPLAY',totalCommands=len(final['commands']),events=len(final['events']),winningScore=8,losingScore=0,finalTurn=current['turnNumber'],normalGatewayCommands=17,allOriginal241Audit50NativeSevenTablesExact=True)
 network_before=rooms('riftbound_here_native');network_log=w/'actual-current-network-smoke-v2.log'
 network_env=dict(os.environ,RIFTBOUND_SERVER_URL='http://127.0.0.1:15847',DOTNET_DbgEnableMiniDump='0')
 with network_log.open('xb') as stream:
  driver=subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet',str(w/'native-network-runtime-v1/Riftbound.NativeNetworkSmoke.dll')],cwd=w/'native-network-runtime-v1',env=network_env,stdout=stream,stderr=subprocess.STDOUT);assert driver.wait(timeout=90)==0,'Original native wire recovery plus mixed-case boundary failed'
 text=network_log.read_text();assert 'Native canonical room identity passed:' in text and 'Native network recovery passed: socket loss, authenticated room restore, fresh snapshot, rejected-token guard.' in text
 wire=json.loads(next(line[len('NATIVE_ROOM_IDENTITY_EVIDENCE '):] for line in text.splitlines() if line.startswith('NATIVE_ROOM_IDENTITY_EVIDENCE ')))
 assert wire['rejectedActions']==15 and wire['leakedPrivateMessages']==0 and wire['validReconnectTokenWasSupplied']
 network_added=set(rooms('riftbound_here_native'))-set(network_before);assert len(network_added)==1 and next(iter(network_added)).startswith('NETWORK-')
 proof.update(currentNativeWireCanonicalAndOriginalRecoveryPass=True,networkOriginalEvidence=wire,separateNewNetworkRoom=next(iter(network_added)))
 assert all(c['playerId']==c['playerId'].strip().lower() for c in final['commands']) and all(p==p.strip().lower() for p in [a,b])
 ready.write_text(json.dumps({**proof,'apiPid':api.pid,'rawFinalFrame':str(evidence/'after-current-ci-native-normal-score-final-original-frame-v2.json.gz'),'actualDatabase':'riftbound_here_native'},indent=2));state('WAITING_INDEPENDENT_CURRENT_ORIGINAL_SQL_HISTORY_AND_FULL_REPLAY')
 until=time.monotonic()+900
 while not stop.exists():assert api.poll() is None and time.monotonic()<until;time.sleep(.2)
 completion=load(stop);assert completion['independentReadOnlyHistoryAndFullReplayPass'] and completion['room']==room
 proof.update(status='PASS_FIXED_C2_CI_EXPORTED_DEFAULT_MAIN_PAIR_CANONICAL_COLD_RECONNECT_AND_NORMAL_SCORE_INDEPENDENT_SQL_REPLAY_NOT_VISIBLE_OR_WINDOWS',independentReadback=completion)
except BaseException as error:
 proof.update(status='FAILED_OR_INTERRUPTED_CURRENT_FIXED_CI_EXPORTED_NATIVE_ORIGINAL_ROOM_AND_INPUTS_RETAINED',errorType=type(error).__name__,error=str(error));print(proof['status'],type(error).__name__,flush=True);raise
finally:
 if driver is not None and driver.poll() is None:driver.terminate();driver.wait(timeout=20)
 for p,record,log in clients:
  if p.poll() is None:p.terminate();p.wait(timeout=20);record['terminatedOnlyForOwnedFailureCleanup']=True
  record.update(exitCode=p.returncode,logSha256=sha(log))
 if started and room is not None:
  try:export('owner-final-current-ci-native-original-frame-v2');proof['latestOwnRoomFrameRetainedAtStop']=True
  except BaseException as error:proof['finalOwnFrameExportErrorType']=type(error).__name__
 if api is not None:
  if api.poll() is None:api.terminate();api.wait(timeout=25)
  proof['ownApiStopped']=api.poll() is not None
 if started:
  if before_audit is not None:
   proof['allOriginal241AuditSevenTablesExactAtStop']=digests('riftbound_acceptance',audit)==before_audit;proof['allOriginal50NativeSevenTablesExactAtStop']=digests('riftbound_here_native',native)==before_native
   proof['actualNativeRoomsAtStop']=rooms('riftbound_here_native')
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None:
  if power.poll() is None:power.terminate();power.wait(timeout=10)
  proof['boundIdleAssertionEnded']=power.poll() is not None
 frozen();proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),allFrozenApiHelperAndBoth373CiPayloadHashesExact=True,originalDatabasesAndOwnRoomRetained=True);terminal.write_text(json.dumps(proof,indent=2));fcntl.flock(guard,fcntl.LOCK_UN)
print(proof['status'],flush=True)
