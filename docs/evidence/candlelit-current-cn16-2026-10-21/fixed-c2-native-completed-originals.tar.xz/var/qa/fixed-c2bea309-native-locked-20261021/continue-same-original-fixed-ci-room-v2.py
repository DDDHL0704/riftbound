import ast, errno, pty, threading, datetime, fcntl, gzip, hashlib, json, os, plistlib, re, resource, socket, subprocess, time, urllib.request
from pathlib import Path

resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
os.umask(0o077)
root = Path('/Users/dinghaolin/MyProjects/riftbound')
w = Path(__file__).resolve().parent
pg = Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin')
cluster = root / 'var/qa/permanent-play-here-base-20261017/postgres'
sock = Path('/tmp/rft-here-family-20261018-55486')
tables = ['matches', 'match_players', 'command_log', 'game_events', 'state_snapshots', 'snapshots', 'action_prompts']
read_env = dict(os.environ, PGOPTIONS='-c default_transaction_read_only=on')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
load = lambda p: json.loads(p.read_text())
definition = root / 'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes = [x for x in ast.parse(definition.read_text()).body if isinstance(x, ast.FunctionDef) and x.name in {'query', 'rooms', 'digests', 'observe_lock'}]
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(definition), 'exec'), globals())
pub = load(w / 'frozen-fixed-c2-native-composition-v1.json')
api_runtime = w / 'api-runtime-v1'
helpers = w / 'live-acceptance-helper-runtime-v1'
evidence = w / 'same-original-c2-ci-native-continuation-v2'
evidence.mkdir(exist_ok=False)
definition = w / 'run-current-fixed-ci-main-pair-v3.py'
text = definition.read_text().replace('live-current-ci-api-', 'same-original-c2-pty-ci-api-').replace('live-ci-native-', 'same-original-c2-ci-native-').replace('live-current-ci-owner-state-v2', 'same-original-c2-pty-ci-owner-state-v2')
needle = "'--headless','--quit-after',str(frames)"
assert text.count(needle) == 1
text = text.replace(needle, "'--headless','--max-fps','60','--quit-after',str(frames)")
functions = {'checkpoint', 'frozen', 'state', 'start_api', 'export', 'count', 'launch', 'native_wait', 'log_count', 'wait_exit'}
nodes = [x for x in ast.parse(text).body if isinstance(x, ast.FunctionDef) and x.name in functions]
assert {x.name for x in nodes} == functions
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(definition), 'exec'), globals())
pumps = {}
def launch(role, label, frames, action=None):
    app = Path(next(a['app'] for a in pub['nativeApps'] if a['label'] == role))
    subprocess.run(['codesign', '--verify', '--deep', '--strict', str(app)], check=True, capture_output=True)
    log = w / ('same-original-c2-pty-ci-native-' + label + '-v2.log')
    args = [str(app / 'Contents/MacOS/符文战场'), '--headless', '--max-fps', '60', '--quit-after', str(frames), '--', '--riftbound-server=http://127.0.0.1:15847', '--riftbound-session-file=' + str(w / ('session-' + role + '.json')), '--riftbound-smoke-connect-only']
    if action: args += ['--riftbound-smoke-ui-action=' + action, '--riftbound-smoke-ui-submit']
    env = dict(os.environ, DOTNET_DbgEnableMiniDump='0')
    env.pop('DOTNET_STARTUP_HOOKS', None)
    master, slave = pty.openpty()
    stream = log.open('xb', buffering=0)
    p = subprocess.Popen(args, cwd='/tmp', env=env, stdin=subprocess.DEVNULL, stdout=slave, stderr=slave, start_new_session=True)
    os.close(slave)
    def drain():
        try:
            while True:
                try: data = os.read(master, 65536)
                except OSError as e:
                    if e.errno == errno.EIO: break
                    raise
                if not data: break
                stream.write(data)
        finally:
            os.close(master)
            stream.close()
    pump = threading.Thread(target=drain, daemon=True)
    pumps[p.pid] = pump
    pump.start()
    record = {'role': role, 'label': label, 'pid': p.pid, 'actualCommand': args, 'log': log.name, 'action': action, 'nativeProcessOwnsPtyStdoutOnlyNoDesktopOrInputEvents': True, 'all373FixedCiPayloadsAndSignatureVerified': True}
    proof['ownedNativeProcesses'].append(record)
    clients.append((p, record, log))
    return p, record, log
def wait_exit(item, timeout):
    p, record, log = item
    code = p.wait(timeout=timeout)
    pumps[p.pid].join(timeout=10)
    assert not pumps[p.pid].is_alive(), 'Native PTY log must reach EOF.'
    record.update(exitCode=code, logSha256=sha(log), ptyFullyDrained=True)
    assert code == 0, 'Native default Main failed.'
    raw = log.read_text(errors='replace')
    assert 'ERROR:' not in raw and 'Unhandled exception' not in raw, 'Original native error log retained; no pass from exit code alone.'

failed = load(w / 'live-current-ci-main-owner-terminal-v2.json')
baseline = load(w / 'actual-safe-native-main-v2/original241-audit50-native-seven-table-baseline-v2.json')
entry = load(w / 'actual-safe-native-prefix-v2/pending-original-native-prefix-receipt.json')
room = entry['room']
a, b = entry['players']
n = entry['acceptedCommands']
assert room == failed['room'] and n == failed['originalGatewayPrefixCommands'] == 39
assert failed['ownApiStopped'] and failed['ownPostgresSmartStopped'] and failed['allOriginal241AuditSevenTablesExactAtStop'] and failed['allOriginal50NativeSevenTablesExactAtStop']
original_path = w / 'actual-safe-native-main-v2/owner-final-current-ci-native-original-frame-v2.json.gz'
original = json.loads(gzip.decompress(original_path.read_bytes()))
assert len(original['commands']) == n and not original['authoritativeState']['winnerPlayerId']
ready = w / 'same-original-fixed-ci-room-ready-v2.json'
stop = w / 'same-original-fixed-ci-room-stop-v2.json'
terminal = w / 'same-original-fixed-ci-room-owner-terminal-v2.json'
assert not any(p.exists() for p in [ready, stop, terminal])
guard = (root / 'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a')
fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
proof = {'status': 'RUNNING_SAME_ORIGINAL39_FIXED_CI_NATIVE_ROOM_WITH_MAX_FPS60_AND_LIVE_PTY_CAPTURE', 'startedAtUtc': now(), 'fixedCommit': pub['fixedCommit'], 'baseCommit': pub['fixedCommit'], 'fixedCiRun': 39510792920, 'room': room, 'originalGatewayPrefixCommands': n, 'actualRuleInputs': pub['actualRuleInputs'], 'lockAtStart': observe_lock(), 'ownedApiProcesses': [], 'ownedNativeProcesses': [], 'fixedCi373ManagedAndPckPayloads': True, 'headlessProductionInteractionRoutesNotHardwareOrVisible': True, 'previousEarlyExitErrorsRetainedAndNotDeclaredResolved': True}
api = power = driver = None
clients = []
started = False
try:
    frozen()
    assert subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), 'status'], capture_output=True).returncode == 3
    with socket.socket() as s: assert s.connect_ex(('127.0.0.1', 15847)) != 0
    power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())])
    proof['boundIdleAssertionPid'] = power.pid
    sock.mkdir(exist_ok=True)
    subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-l', str(w / 'same-original-c2-ci-postgres-v2.log'), '-o', f'-p 55486 -h 127.0.0.1 -k {sock}', '-w', 'start'], capture_output=True, check=True)
    started = True
    assert rooms('riftbound_acceptance') == baseline['auditRooms'] and set(rooms('riftbound_here_native')) == set(baseline['nativeRooms']) | {room}
    assert digests('riftbound_acceptance', baseline['auditRooms']) == baseline['auditSevenTables'] and digests('riftbound_here_native', baseline['nativeRooms']) == baseline['nativeSevenTables']
    start_api(1)
    before = export('same-original39-before-any-new-native-v1')
    assert before == original and count() == n
    checkpoint('same-original39-start-exact-readback-v1.json', {'atUtc': now(), 'originalFrameSha256': sha(original_path), 'allWholeFrameFieldsNullsCommandsEventsSeedAndInitialExact': True, 'nativeAcceptedGameplayCommandsBeforeRetry': 0})
    pair = [launch('a', 'observe-a', 3600), launch('b', 'observe-b', 3600)]
    native_wait(lambda: all(all(log_count(x[2], k) >= 1 for k in ['Joined', 'Snapshot', 'Prompt']) for x in pair), 'Both actual CI exported clients must bind and receive their private prompts', 40, [x[0] for x in pair])
    counts = [{k: log_count(x[2], k) for k in ['Joined', 'Snapshot', 'Prompt']} for x in pair]
    before_cold = export('both-current-ci-clients-before-cold-v1')
    assert before_cold == before
    state('SAME_ORIGINAL39_BOTH_FIXED_CI_CLIENTS_RESTARTING_ONLY_OWN_API')
    api.terminate(); api.wait(timeout=25)
    start_api(2)
    native_wait(lambda: all(all(log_count(x[2], k) > counts[i][k] for k in ['Joined', 'Snapshot', 'Prompt']) for i, x in enumerate(pair)), 'Same two actual CI processes must reauthenticate and restore without a game action', 45, [x[0] for x in pair])
    after_cold = export('both-current-ci-clients-after-cold-v1')
    assert after_cold == before and count() == n
    checkpoint('both-fixed-ci-processes-actual-cold-reconnect-v1.json', {'atUtc': now(), 'sameBothNativeProcesses': [x[0].pid for x in pair], 'beforeCounts': counts, 'afterCounts': [{k: log_count(x[2], k) for k in ['Joined', 'Snapshot', 'Prompt']} for x in pair], 'entireOriginal39CommandFrameExactBeforeAfterCold': True})
    for item in pair: wait_exit(item, 75)
    state('SAME_ORIGINAL39_FIXED_CI_KEEP_AND_TWO_PRIORITY_ROUTES')
    own_a = launch('a', 'ui-pass-a', 2400, 'PASS_PRIORITY')
    own_b = launch('b', 'ui-keep-b', 600, 'PAY_COST')
    native_wait(lambda: count() == n + 1, 'Actual CI new controller submits KEEP for the unchanged original choice', 30, [own_a[0], own_b[0]])
    kept = export('after-same-original-ci-keep-v1')
    assert kept['commands'][-1]['playerId'] == b and kept['commands'][-1]['rawCommand']['paymentChoiceIds'] == ['KEEP_ALL']
    wait_exit(own_b, 25)
    own_b_pass = launch('b', 'ui-pass-b', 600, 'PASS_PRIORITY')
    native_wait(lambda: count() == n + 3, 'Both current CI native priority owners resolve the original spell', 30, [own_a[0], own_b_pass[0]])
    post = export('after-same-original-ci-native-three-v1')
    assert len(post['commands']) == n + 3 and not post['authoritativeState']['stackItems'] and post['authoritativeState']['pendingPayment'] is None
    assert post['commands'][:n] == before['commands'] and post['events'][:len(before['events'])] == before['events'] and post['openingSeed'] == before['openingSeed'] and post['replayInitialState'] == before['replayInitialState']
    for item in [own_a, own_b_pass]: wait_exit(item, 55)
    for item in [own_a, own_b, own_b_pass]: assert 'UI smoke staged ' + item[1]['action'] in item[2].read_text()
    proof.update(nativeAcceptedGameplayCommands=3, actualSameBothFixedCiColdReconnectPass=True)
    score = w / 'same-original-c2-ci-normal-score-v2'
    assert not score.exists()
    with (w / 'same-original-c2-ci-normal-score-writer-v2.log').open('xb') as log:
        driver = subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet', str(helpers / 'Fixed564SafeBandleScore.dll'), 'http://127.0.0.1:15847', str(score), str(w)], cwd=helpers, stdout=log, stderr=subprocess.STDOUT, env=dict(os.environ, DOTNET_DbgEnableMiniDump='0'))
        assert driver.wait(timeout=330) == 0
    score_receipt = load(score / 'normal-original-score-continuation-receipt.json')
    assert score_receipt['continuationCommands'] == 17 and score_receipt['winningScore'] == 8
    final = export('same-original-fixed-ci-normal-score-final-v1')
    current = final['authoritativeState']
    assert len(final['commands']) == n + 20 and current['status'] == 'FINISHED' and current['winnerPlayerId'] == a and current['playerScores'] == {a: 8, b: 0}
    assert final['commands'][:n + 3] == post['commands'] and final['events'][:len(post['events'])] == post['events'] and final['openingSeed'] == before['openingSeed'] and final['replayInitialState'] == before['replayInitialState']
    assert all(c['commandType'] != 'SURRENDER' and c['playerId'] == c['playerId'].strip().lower() for c in final['commands'])
    network_before = rooms('riftbound_here_native')
    with (w / 'same-original-fixed-ci-backend-network-v2.log').open('xb') as log:
        driver = subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet', str(w / 'native-network-runtime-v1/Riftbound.NativeNetworkSmoke.dll')], cwd=w / 'native-network-runtime-v1', stdout=log, stderr=subprocess.STDOUT, env=dict(os.environ, RIFTBOUND_SERVER_URL='http://127.0.0.1:15847', DOTNET_DbgEnableMiniDump='0'))
        assert driver.wait(timeout=90) == 0
    raw = (w / 'same-original-fixed-ci-backend-network-v2.log').read_text()
    assert 'Native canonical room identity passed:' in raw and 'Native network recovery passed: socket loss, authenticated room restore, fresh snapshot, rejected-token guard.' in raw
    wire = json.loads(next(x[len('NATIVE_ROOM_IDENTITY_EVIDENCE '):] for x in raw.splitlines() if x.startswith('NATIVE_ROOM_IDENTITY_EVIDENCE ')))
    assert wire['rejectedActions'] == 15 and wire['leakedPrivateMessages'] == 0 and wire['validReconnectTokenWasSupplied']
    added = set(rooms('riftbound_here_native')) - set(network_before)
    assert len(added) == 1 and next(iter(added)).startswith('NETWORK-')
    proof.update(status='SAME_ORIGINAL_FIXED_CI_NATIVE3_NORMAL_SCORE17_READY_FOR_INDEPENDENT_HISTORY', totalCommands=len(final['commands']), events=len(final['events']), winningScore=8, losingScore=0, finalTurn=current['turnNumber'], normalGatewayCommands=17, separateNewNetworkRoom=next(iter(added)), networkOriginalEvidence=wire, networkDriverOriginallyN29SourceBuiltNotCiArtifact=True)
    ready.write_text(json.dumps({**proof, 'rawFinalFrame': str(evidence / 'same-original-fixed-ci-normal-score-final-v1.json.gz')}, indent=2))
    state('WAITING_SAME_ORIGINAL_FIXED_CI_ALL_SQL_HISTORY_AND_FULL_REPLAY')
    until = time.monotonic() + 900
    while not stop.exists(): assert api.poll() is None and time.monotonic() < until; time.sleep(.2)
    completion = load(stop)
    assert completion['room'] == room and completion['independentReadOnlyHistoryAndFullReplayPass']
    proof.update(status='PASS_SAME_ORIGINAL39_FIXED_CI_EXPORTED_PAIR_COLD_NATIVE3_NORMAL_SCORE17_AND_INDEPENDENT_FULL_SQL_REPLAY_NOT_VISIBLE_OR_WINDOWS', independentReadback=completion)
except BaseException as e:
    proof.update(status='FAILED_OR_INTERRUPTED_SAME_ORIGINAL_FIXED_CI_ROOM_RETAINED_NO_RESET', errorType=type(e).__name__, error=str(e))
    raise
finally:
    if driver is not None and driver.poll() is None: driver.terminate(); driver.wait(timeout=20)
    for p, record, log in clients:
        if p.poll() is None: p.terminate(); p.wait(timeout=20); record['terminatedOnlyForOwnedFailureCleanup'] = True
        pumps[p.pid].join(timeout=10)
        assert not pumps[p.pid].is_alive()
        record.update(exitCode=p.returncode, logSha256=sha(log))
    if started:
        try: export('owner-final-same-original-fixed-ci-room-v1')
        except BaseException as e: proof['finalFrameExportFailure'] = type(e).__name__
    if api is not None:
        if api.poll() is None: api.terminate(); api.wait(timeout=25)
        proof['ownApiStopped'] = api.poll() is not None
    if started:
        proof['allOriginal241AuditSevenTablesExactAtStop'] = digests('riftbound_acceptance', baseline['auditRooms']) == baseline['auditSevenTables']
        proof['allOriginal50NativeSevenTablesExactAtStop'] = digests('riftbound_here_native', baseline['nativeRooms']) == baseline['nativeSevenTables']
        proof['actualNativeRoomsAtStop'] = rooms('riftbound_here_native')
        proof['ownPostgresSmartStopped'] = subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-m', 'smart', '-w', '-t', '20', 'stop'], capture_output=True).returncode == 0
    if power is not None:
        if power.poll() is None: power.terminate(); power.wait(timeout=10)
        proof['boundIdleAssertionEnded'] = power.poll() is not None
    frozen()
    proof.update(finishedAtUtc=now(), lockAtEnd=observe_lock(), allFixedApiHelperNetworkAndBoth373CiFilesExact=True, allOriginalAcceptedHistoryAndDatabasesRetained=True)
    terminal.write_text(json.dumps(proof, indent=2))
    fcntl.flock(guard, fcntl.LOCK_UN)
print(proof['status'], flush=True)
