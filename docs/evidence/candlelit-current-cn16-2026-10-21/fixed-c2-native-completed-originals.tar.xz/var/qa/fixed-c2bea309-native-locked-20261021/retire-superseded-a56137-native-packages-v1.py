from pathlib import Path
import datetime, hashlib, json, os, shutil, subprocess

os.umask(0o077)
root = Path('/Users/dinghaolin/MyProjects/riftbound')
w = Path(__file__).resolve().parent
old = root / 'var/qa/fixed-a56137-native-locked-20261021'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
new = load(w / 'native-app-inputs.json')
boot = load(w / 'current-native-headless-boot-verification.json')
downloads = load(w / 'current-fixed-native-download-original-result-v1.json')
assert new['fixedCommit'] == boot['fixedCommit'] == downloads['fixedCommit'] == 'c2bea309e2b73cdd730f57bf8761bb04a6c42ce8'
assert boot['status'] == 'CURRENT_FIXED_DEFAULT_MAIN_HEADLESS_BOOT_PASS' and len(boot['records']) == 2
for row in new['apps']:
    app = Path(row['app'])
    assert all(sha(app / p) == h for p, h in new['ciManagedAndPckPayloads'].items())
    subprocess.run(['codesign', '--verify', '--deep', '--strict', str(app)], check=True, capture_output=True)
for row in downloads['artifacts']:
    p = w / 'native-current' / row['filename']
    assert sha(p) == row['actualSha256'] and row['actualDownloadExitCode'] == 0 and row['allOuterZipCrcVerified']
processes = subprocess.check_output(['ps', '-axo', 'pid=,command='], text=True)
assert not any(str(old / ('Riftbound-' + label + '.app')) in line for label in ['A', 'B'] for line in processes.splitlines())
prior = load(old / 'native-app-inputs.json')
prior_downloads = load(old / 'current-fixed-native-download-original-result-v1.json')
assert prior['fixedCommit'] == 'a56137a93d48a38d6e2e62b5b7195aa03412577f'
removed = []
for label in ['A', 'B']:
    app = old / ('Riftbound-' + label + '.app')
    assert app.is_dir() and not app.is_symlink()
    assert all(sha(app / p) == h for p, h in prior['ciManagedAndPckPayloads'].items())
    subprocess.run(['codesign', '--verify', '--deep', '--strict', str(app)], check=True, capture_output=True)
    files = [p for p in app.rglob('*') if p.is_file()]
    removed.append({'path': str(app), 'files': len(files), 'logicalBytes': sum(p.stat().st_size for p in files), 'allOld373PayloadsAndSignatureVerifiedBeforeDeletion': True})
    shutil.rmtree(app)
for row in prior_downloads['artifacts']:
    p = old / 'native-current' / row['filename']
    assert p.is_file() and not p.is_symlink() and sha(p) == row['actualSha256'] and p.stat().st_size == row['actualBytes']
    removed.append({'path': str(p), 'logicalBytes': p.stat().st_size, 'sha256': sha(p), 'originalBackendDigestAndCrcReceiptRetained': True})
    p.unlink()
inventory = [str(p.relative_to(root)) for p in (root / 'var/qa').rglob('*.app') if p.is_dir()]
assert set(inventory) == {str(Path(a['app']).relative_to(root)) for a in new['apps']}
receipt = {'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': 'LATEST_USABLE_C2BEA309_PAIR_AND_ONE_ARCHIVE_PER_PLATFORM_OLD_A56137_RETIRED', 'newFixedCommit': new['fixedCommit'], 'newCiRun': 39510792920, 'removed': removed, 'logicalBytesRetired': sum(a['logicalBytes'] for a in removed), 'remainingOwnedNativeApps': inventory, 'newBootInnerOuterCrc373PayloadsAndSignaturesVerified': True, 'allOldSourceTestsLogsFailureReceiptsAndDatabasesRetained': True, 'oldFailedNativeBinaryRetiredNotClaimedRetained': True, 'physicalDiskSavingsNotAssumedFromLogicalBytesDueToApfsClones': True, 'userGodotEditorAndSharedSdksNotTouched': True, 'visibleAndPhysicalWindowsAcceptance': 'OPEN'}
target = w / 'latest-only-verified-replacement-and-old-a56137-retirement-v1.json'
with target.open('x') as f: json.dump(receipt, f, indent=2)
print(receipt['status'], receipt['logicalBytesRetired'], 'logical bytes;', inventory, flush=True)
