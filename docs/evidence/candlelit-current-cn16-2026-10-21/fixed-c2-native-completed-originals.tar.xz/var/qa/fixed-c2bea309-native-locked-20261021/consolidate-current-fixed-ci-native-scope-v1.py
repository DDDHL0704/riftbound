from pathlib import Path
import datetime, gzip, hashlib, json, subprocess

w = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
fixed = 'c2bea309e2b73cdd730f57bf8761bb04a6c42ce8'
pub = load(w / 'frozen-fixed-c2-native-composition-v1.json')
native = load(w / 'same-original-fixed-ci-room-owner-terminal-v2.json')
final = load(w / 'same-original42-fixed-ci-score-owner-terminal-v2.json')
reader = load(w / 'independent-fixed-c2-ci59-history-result-v2.json')
read_run = load(w / 'independent-fixed-c2-ci59-history-run-v2.json')
boot = load(w / 'current-native-headless-boot-verification.json')
entry = load(w / 'actual-safe-native-prefix-v2/pending-original-native-prefix-receipt.json')
assert pub['fixedCommit'] == final['fixedCommit'] == boot['fixedCommit'] == fixed
assert final['status'].startswith('PASS_SAME_ORIGINAL39_PLUS3_') and final['ownApiStopped'] and final['ownPostgresSmartStopped']
assert final['allOriginal241AuditSevenTablesExactAtStop'] and final['allOriginal50NativeSevenTablesExactAtStop'] and len(final['actualNativeRoomsAtStop']) == 52
assert native['nativeAcceptedGameplayCommands'] == 3 and native['actualSameBothFixedCiColdReconnectPass']
assert reader['commands'] == 59 and reader['events'] == 358 and reader['actualHistoricalPayloads'] == {'state_snapshots': 59, 'snapshots': 114, 'action_prompts': 114}
assert reader['actualRuleInputs'] == final['actualRuleInputs'] == pub['actualRuleInputs'] and reader['winningScore'] == 8 and reader['finalTurn'] == 29
assert read_run['allFrozenApiReaderAndOriginalHelperHashesStable'] and read_run['exitCode'] == 0
assert boot['status'] == 'CURRENT_FIXED_DEFAULT_MAIN_HEADLESS_BOOT_PASS'
logs = []
actors = dict(zip(['a', 'b'], entry['players']))
for row in native['ownedNativeProcesses']:
    p = w / row['log']; text = p.read_text(errors='replace')
    assert row['exitCode'] == 0 and row['ptyFullyDrained'] and not row.get('terminatedOnlyForOwnedFailureCleanup')
    assert 'ERROR:' not in text and 'Unhandled exception' not in text
    actor = actors[row['role']]
    assert 'Authenticate: Verified (' + actor + ').' in text and '[b]Joined[/b]' in text and 'player=' + actor + ' ' in text
    logs.append({'label': row['label'], 'pid': row['pid'], 'log': row['log'], 'sha256': sha(p), 'exitCode': 0, 'noErrorAndPtyFullyDrained': True, 'authenticatedAndProjectedActor': actor})
assert len(logs) == 5
frame = json.loads(gzip.decompress((w / 'same-original42-fixed-ci-score-continuation-v2/same-original-fixed-ci-normal-score-final-v1.json.gz').read_bytes()))
initial = json.loads(gzip.decompress((w / 'actual-safe-native-main-v2/before-ci-native-cold-reconnect-original-frame-v2.json.gz').read_bytes()))
assert len(initial['commands']) == 39 and frame['commands'][:39] == initial['commands'] and frame['events'][:len(initial['events'])] == initial['events'] and frame['openingSeed'] == initial['openingSeed'] and frame['replayInitialState'] == initial['replayInitialState']
assert all(c['playerId'] == c['playerId'].strip().lower() for c in frame['commands'])
assert set(frame['authoritativeState']['seats']) == set(entry['players'])
for row in pub['nativeApps']:
    app = Path(row['app']); assert all(sha(app / p) == h for p, h in pub['ciManagedAndPckPayloads'].items())
    subprocess.run(['codesign', '--verify', '--deep', '--strict', str(app)], check=True, capture_output=True)
wire = final['networkOriginalEvidence']; assert wire['rejectedActions'] == 15 and wire['leakedPrivateMessages'] == 0 and wire['validReconnectTokenWasSupplied']
result = {'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': 'PASS_FIXED_C2_CI_EXPORTED_MACOS_HEADLESS_PAIR_COLD_NATIVE3_NORMAL_SCORE17_AND_INDEPENDENT_COMPLETE_SQL_REPLAY_SUBSCOPE', 'fixedCommit': fixed, 'fixedCiRun': 39510792920, 'actualServerRuleInputs': pub['actualRuleInputs'], 'room': entry['room'], 'ordinaryGatewayOpeningCommands': 39, 'actualCiNativeProductionInteractionSubmissions': 3, 'normalGatewayScoreContinuationCommands': 17, 'commands': 59, 'events': 358, 'finalTurn': 29, 'winningScore': 8, 'losingScore': 0, 'oneConquestAndSevenHoldsNoSurrenderAndBothDecksNonempty': True, 'historicalPayloads': reader['actualHistoricalPayloads'], 'allOriginalRawIntentsFieldsNullsPrivateBoundariesPromptTicksAndFullActionEventStateReplayVerified': True, 'allOriginal39AndNative3HistoryOpeningSeedAndBlankInitialRetained': True, 'sameTwoCiNativeProcessColdReconnectAndWhole39CommandFrameExact': True, 'nativeProcesses': logs, 'all373ManagedAndPckPayloadsPerClientAndSignaturesExact': True, 'localNetwork15Rejects0Leaks': wire, 'networkDriverOriginallySourceBuiltN29NotCiArtifact': True, 'allOriginal241AuditAnd50NativeSevenTablesExact': True, 'newOrdinaryAndNetworkRoomsRetainedTotalNative52': True, 'ownApiDatabaseAndIdleAssertionNormallyStopped': True, 'priorUncappedPipeTimeoutForcedCleanupAndScorePrecommandFailuresRetained': True, 'livePtyStdoutAndFps60ChangeOnlyTheAuditHarnessNotProductOrPackage': True, 'earlyUncappedShutdownErrorsNotClaimedGenericallyFixed': True, 'completeFixedCiStatus': 'PENDING_ACTUAL_ENTIRE_RUN_TERMINAL_AND_ORIGINALS', 'visiblePairedWindowsHardwareControlsOrPhysicalWindowsAcceptance': 'OPEN', 'currentUncommittedCandlelitSql49FullCiAndWholePrintingCertification': False}
with (w / 'current-fixed-c2-ci-native-combined-subscope-readback-v1.json').open('x') as f: json.dump(result, f, indent=2)
print(result['status'], '59/358,59/114/114; all5 exit0; fixedC2 CI373x2; original241/50 unchanged', flush=True)
