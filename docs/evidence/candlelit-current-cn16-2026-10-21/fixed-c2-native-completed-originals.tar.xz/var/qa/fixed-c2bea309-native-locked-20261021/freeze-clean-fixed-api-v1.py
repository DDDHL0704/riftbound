from pathlib import Path
import datetime,hashlib,json,os,subprocess
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;r=w/'api-runtime-v1';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();fixed='c2bea309e2b73cdd730f57bf8761bb04a6c42ce8'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==fixed and not subprocess.check_output(['git','status','--porcelain'],cwd=root).strip()
prior=json.loads((root/'var/qa/canonical-room-player-identity-20261021/frozen-current-canonical-candidate-inputs-v3.json').read_text());inputs={p:sha(root/p) for p in prior['sourceInputHashes']};modes={p:oct((root/p).stat().st_mode&0o777) for p in inputs};assert inputs==prior['sourceInputHashes'] and modes==prior['sourceInputModes'] and len(inputs)==3318
mutable={(p.stat().st_dev,p.stat().st_ino) for p in [root/p for p in inputs]}
for folder in ['src','tests','clients/godot/.godot/mono/temp/bin']:
 for p in (root/folder).rglob('*'):
  if p.is_file() and ('bin' in p.parts or 'obj' in p.parts):mutable.add((p.stat().st_dev,p.stat().st_ino))
known={}
for folder in ['var/qa/fixed-f470429-native-locked-20261021/api-runtime-v1','var/qa/canonical-room-player-identity-20261021/api-runtime-v1']:
 for p in (root/folder).rglob('*'):
  if p.is_file() and (p.stat().st_dev,p.stat().st_ino) not in mutable:known.setdefault((p.stat().st_size,sha(p)),p)
shared=[]
for p in r.rglob('*'):
 if not p.is_file():continue
 h=sha(p);candidate=known.get((p.stat().st_size,h))
 if candidate and (p.stat().st_dev,p.stat().st_ino)!=(candidate.stat().st_dev,candidate.stat().st_ino):
  temp=p.with_name(p.name+'.immutable-link');assert not temp.exists();os.link(candidate,temp);os.replace(temp,p);shared.append({'path':str(p.relative_to(r)),'immutableExistingSource':str(candidate.relative_to(root)),'sha256':h})
 elif (p.stat().st_dev,p.stat().st_ino) in mutable:
  temp=p.with_name(p.name+'.independent-copy');temp.write_bytes(p.read_bytes());os.replace(temp,p)
reader=r/'ClairvoyanceIndependentFrameReaderV2.dll';assert not reader.exists();os.link(root/'var/qa/fixed-a56137-native-locked-20261021/api-runtime-v1/ClairvoyanceIndependentFrameReaderV2.dll',reader)
files={str(p.relative_to(r)):sha(p) for p in r.rglob('*') if p.is_file()};assert len(files)==47 and all((p.stat().st_dev,p.stat().st_ino) not in mutable for p in r.rglob('*') if p.is_file())
command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(r/'Riftbound.Api.deps.json'),'--runtimeconfig',str(r/'Riftbound.Api.runtimeconfig.json'),str(reader),'identity-print'];identity=json.loads(subprocess.check_output(command,cwd=r,text=True))
result={'recordedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'CLEAN_FIXED_C2BEA309_SOURCE_AND47_API_FILES_FROZEN_BEFORE_NEXT_AUTHORITY_INPUT_CHANGE_NOT_ACCEPTANCE','fixedCommit':fixed,'sourceInputCount':3318,'sourceInputHashes':inputs,'sourceInputModes':modes,'runtimeFileCount':47,'runtimeFiles':files,'sharedIdenticalImmutablePaths':shared,'noFrozenFileSharesMutableSourceOrBuildInode':True,'actualRuleInputs':identity,'identityReaderCommand':command,'newSdkCheckoutDatabaseOrNativeInstaller':False,'oldDevelopmentMatchMigration':False};p=w/'fixed-clean-api-runtime-source-and-identity-v1.json';assert not p.exists();p.write_text(json.dumps(result,indent=2));print('Frozen fixedc2bea309',len(shared),'shared immutable files',json.dumps(identity),flush=True)
