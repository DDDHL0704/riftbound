from pathlib import Path
import datetime, hashlib, json

w = Path(__file__).resolve().parent
old = w / 'continue-same-original-fixed-ci-room-v1.py'
text = old.read_text().replace('import ast, datetime,', 'import ast, errno, pty, threading, datetime,')
changes = {
    'same-original-c2-ci-native-continuation-v1': 'same-original-c2-ci-native-continuation-v2',
    'same-original-fixed-ci-room-ready-v1.json': 'same-original-fixed-ci-room-ready-v2.json',
    'same-original-fixed-ci-room-stop-v1.json': 'same-original-fixed-ci-room-stop-v2.json',
    'same-original-fixed-ci-room-owner-terminal-v1.json': 'same-original-fixed-ci-room-owner-terminal-v2.json',
    'same-original-c2-ci-postgres-v1.log': 'same-original-c2-ci-postgres-v2.log',
    'same-original-c2-ci-normal-score-v1': 'same-original-c2-ci-normal-score-v2',
    'same-original-c2-ci-normal-score-writer-v1.log': 'same-original-c2-ci-normal-score-writer-v2.log',
    'same-original-fixed-ci-backend-network-v1.log': 'same-original-fixed-ci-backend-network-v2.log',
    'same-original-c2-ci-api-': 'same-original-c2-pty-ci-api-',
    'same-original-c2-ci-owner-state-v1': 'same-original-c2-pty-ci-owner-state-v2',
}
for a, b in changes.items():
    assert a in text, a
    text = text.replace(a, b)
insertion = "failed = load(w / 'live-current-ci-main-owner-terminal-v2.json')"
assert text.count(insertion) == 1
override = '''pumps = {}
def launch(role, label, frames, action=None):
    app = Path(next(a['app'] for a in pub['nativeApps'] if a['label'] == role))
    subprocess.run(['codesign', '--verify', '--deep', '--strict', str(app)], check=True, capture_output=True)
    log = w / ('same-original-c2-pty-ci-native-' + label + '-v2.log')
    args = [str(app / 'Contents/MacOS/符文战场'), '--headless', '--max-fps', '60', '--quit-after', str(frames), '--', '--riftbound-server=http://127.0.0.1:15847', '--riftbound-session-file=' + str(w / ('session-' + role + '.json')), '--riftbound-smoke-connect-only']
    if action: args += ['--riftbound-smoke-ui-action=' + action, '--riftbound-smoke-ui-submit']
    env = dict(os.environ, DOTNET_DbgEnableMiniDump='0')
    env.pop('DOTNET_STARTUP_HOOKS', None)
    master, slave = pty.openpty()
    stream = log.open('xb', buffering=0)
    p = subprocess.Popen(args, cwd='/tmp', env=env, stdin=subprocess.DEVNULL, stdout=slave, stderr=slave, start_new_session=True)
    os.close(slave)
    def drain():
        try:
            while True:
                try: data = os.read(master, 65536)
                except OSError as e:
                    if e.errno == errno.EIO: break
                    raise
                if not data: break
                stream.write(data)
        finally:
            os.close(master)
            stream.close()
    pump = threading.Thread(target=drain, daemon=True)
    pumps[p.pid] = pump
    pump.start()
    record = {'role': role, 'label': label, 'pid': p.pid, 'actualCommand': args, 'log': log.name, 'action': action, 'nativeProcessOwnsPtyStdoutOnlyNoDesktopOrInputEvents': True, 'all373FixedCiPayloadsAndSignatureVerified': True}
    proof['ownedNativeProcesses'].append(record)
    clients.append((p, record, log))
    return p, record, log
def wait_exit(item, timeout):
    p, record, log = item
    code = p.wait(timeout=timeout)
    pumps[p.pid].join(timeout=10)
    assert not pumps[p.pid].is_alive(), 'Native PTY log must reach EOF.'
    record.update(exitCode=code, logSha256=sha(log), ptyFullyDrained=True)
    assert code == 0, 'Native default Main failed.'
    raw = log.read_text(errors='replace')
    assert 'ERROR:' not in raw and 'Unhandled exception' not in raw, 'Original native error log retained; no pass from exit code alone.'

'''
text = text.replace(insertion, override + insertion)
needle = "        record.update(exitCode=p.returncode, logSha256=sha(log))"
assert text.count(needle) == 1
text = text.replace(needle, "        pumps[p.pid].join(timeout=10)\n        assert not pumps[p.pid].is_alive()\n" + needle)
text = text.replace("'RUNNING_SAME_ORIGINAL39_FIXED_CI_NATIVE_ROOM_WITH_ACTUAL_MAX_FPS_60'", "'RUNNING_SAME_ORIGINAL39_FIXED_CI_NATIVE_ROOM_WITH_MAX_FPS60_AND_LIVE_PTY_CAPTURE'")
target = w / 'continue-same-original-fixed-ci-room-v2.py'
with target.open('x') as f: f.write(text)
compile(text, str(target), 'exec')
failure = json.loads((w / 'same-original-fixed-ci-room-owner-terminal-v1.json').read_text())
assert failure['ownApiStopped'] and failure['ownPostgresSmartStopped'] and failure['allOriginal241AuditSevenTablesExactAtStop'] and failure['allOriginal50NativeSevenTablesExactAtStop']
(w / 'same-original-native-pipe-timeout-and-pty-capture-disposition-v1.json').write_text(json.dumps({'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': 'BOTH_PRIVATE_PROMPTS_IN_RETAINED_LOGS_BUT_PIPE_COUNTS_TIMED_OUT_BEFORE_FORCED_CLEANUP', 'originalOwnerSourceSha256': hashlib.sha256(old.read_bytes()).hexdigest(), 'newOwnerSourceSha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'all39AcceptedCommandsAndWholeFinalFrameStillExact': True, 'newAttemptChangesOnlyBoundedRunCaptureToPtyAndFreshOutputNames': True, 'noProductSourceFrozenPackageOrOriginalRoomHistoryChanged': True, 'pipeBufferingHypothesisRequiresLivePtyReadback': True, 'priorForcedCleanupStringNameAndMutexErrorsRetainedNotIgnored': True}, indent=2))
print('same39 PTY capture prepared; exact fixed native process PID, own stdout only; all exit/error assertions retained', flush=True)
