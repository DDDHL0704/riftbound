from pathlib import Path
import datetime,gzip,hashlib,json,os,tarfile
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;native=root/'var/qa/fixed-a56137-native-locked-20261021';out=root/'docs/evidence/spell-remake-single-friendly-unit-2026-10-21';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
for file,name in [(root/'docs/audit/current-manifest.json','prior-entire-current-manifest.json.gz'),(root/'docs/evidence/rules-reaudit-2026-10-11/review-decisions.json','prior-entire-review-decisions.json.gz')]:
 p=w/name;assert not p.exists();p.write_bytes(gzip.compress(file.read_bytes(),mtime=0))
critical={
 w/'only-check-independent-case-method-and-input-retention-v1.json':'check-original-method-case-and-input-retention.json',
 w/'only-check-owner-terminal-v1.json':'check-actual-terminal.json',
 w/'finite-friendly-unit-consumer-source-and-scope-review-v1.json':'finite-consumer-source-review.json',
 w/'actual-ten-and-clairvoyance-owner-v2.json':'real-sql-ten-plus-clair-five-terminal.json',
 w/'independent-current-ten-and-clair-originals-result-v1.json':'real-sql-independent-original-history-readback.json',
 w/'affected-original-pairs-owner-v1.json':'original38-affected-pair-helpers-terminal.json',
 native/'native-handle-case-source-and-original-failure-disposition-v1.json':'native-handle-case-original-failure.json',
 native/'native-handle-case-issue-created-readback-v1.json':'native-handle-case-issue77-readback.json',
 native/'ci-exported-default-zero-target-controls-owner-v1.json':'fixed-a56137-exported-zero-target-native-controls.json',
 native/'same-original-room-gateway-owner-terminal-v1.json':'fixed-a56137-original-room-gateway-normal-score-terminal.json',
 native/'independent-same-original-room-all-sql-history-result-v2.json':'fixed-a56137-original-room-independent-sql-and-full-replay.json',
 native/'fixed-a56137-partition3-network-original-independent-readback-v2.json':'fixed-a56137-actual-part3-and-network-originals.json',
 native/'latest-only-verified-replacement-and-old564-retirement-v1.json':'latest-only-native-app-and-installer-retirement.json',
 native/'ci-fixed-a56137/postgres-partition-3.zip':'ci-originals/postgres-partition-3.zip',
 native/'ci-fixed-a56137/native-network-results.zip':'ci-originals/native-network-results.zip'}
faces=json.loads((w/'current-finite-consumer-faces-v1/source-manifest.json').read_text())['records']
for row in faces:critical[root/row['path']]='sources/'+Path(row['path']).name
critical[w/'current-exact-dueling-stance-31258.png']='sources/31258.png'
records=[];excluded=[];standalone={}
for p,name in critical.items():
 assert p.is_file(),str(p);q=out/name;q.parent.mkdir(parents=True,exist_ok=True);os.link(p,q);assert sha(p)==sha(q);standalone[p.resolve()]=q
secrets=[]
for p in list(native.glob('session-*.json'))+list((native/'actual-safe-native-prefix-v1').glob('session-native-*.json')):
 data=json.loads(p.read_text());secrets.extend(data[k].encode() for k in ['playerKey','reconnectToken'] if isinstance(data.get(k),str))
paths=[]
for label,base in [('n28',w),('a56137',native)]:
 for p in sorted(base.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(base);parts=rel.parts
  if any(s in ['obj','bin','.godot','__pycache__'] or '.app' in s or '-runtime-' in s or '-build-' in s for s in parts):continue
  if p.name.startswith('session-') or 'private' in p.name or p.name.startswith('live-fixed-ci-api-') or p.suffix in ['.dll','.pdb','.dylib','.exe']:
   excluded.append({'originalPath':str(p.relative_to(root)),'reason':'PRIVATE_AUTH_OPERATIONAL_OR_NON_SOURCE_EXECUTABLE_NOT_PUBLISHED','sha256':sha(p),'retainedLocally':True});continue
  if p.suffix=='.zip' and p.resolve() not in standalone:continue
  if p.suffix not in ['.json','.gz','.log','.txt','.cs','.csproj','.py','.png','.webp','.md','.c','.zip','.trx']:continue
  raw=p.read_bytes()
  if any(s and s in raw for s in secrets):
   excluded.append({'originalPath':str(p.relative_to(root)),'reason':'PRIVATE_QA_AUTH_LITERAL_FOUND_NO_REDACTION_OR_PUBLICATION','sha256':hashlib.sha256(raw).hexdigest(),'retainedLocally':True});continue
  paths.append((label,base,p))
archive=out/'completed-originals.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as tar:
 for label,base,p in paths:
  rec={'originalPath':str(p.relative_to(root)),'bytes':p.stat().st_size,'mode':oct(p.stat().st_mode&0o777),'sha256':sha(p)}
  q=standalone.get(p.resolve())
  if q:rec['canonicalPath']=str(q.relative_to(root))
  else:
   member=label+'/'+str(p.relative_to(base));tar.add(p,arcname=member,recursive=False);rec['archiveMember']=member
  records.append(rec)
assert archive.stat().st_size<10*1024*1024
with tarfile.open(archive,'r:xz') as tar:
 expected={r['archiveMember']:r for r in records if 'archiveMember' in r};assert set(tar.getnames())==set(expected)
 for name,r in expected.items():
  data=tar.extractfile(name).read();assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
for r in records:
 if 'canonicalPath' in r:assert sha(root/r['canonicalPath'])==r['sha256']
index={'recordedAtUtc':now(),'status':'ALL_SELECTED_ORIGINAL_BYTES_AND_EXPLICIT_PRIVATE_EXCLUSIONS_VERIFIED','archive':{'path':str(archive.relative_to(root)),'sha256':sha(archive),'bytes':archive.stat().st_size},'records':records,'explicitPrivateExclusions':excluded,'noOriginalSourceTestsTracesDatabaseOrRawFailuresDeletedOrRewritten':True,'noOldRoomMigrationOrNewSdkCheckoutDatabaseOrInstaller':True}
(out/'archive-map.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
print('CANONICAL_ORIGINALS_VERIFIED',len(records),'records',archive.stat().st_size,'archive bytes',len(excluded),'explicit private exclusions',flush=True)
