import ast
import datetime
import hashlib
import json
import os
from pathlib import Path
import plistlib
import resource
import signal
import subprocess
import time
import xml.etree.ElementTree as ET

resource.setrlimit(resource.RLIMIT_CORE,(0,0))
root=Path('/Users/dinghaolin/MyProjects/riftbound');work=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(path,value):
    with path.open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
def write_broad_once(path,value):
    if path.exists():
        old=json.loads(path.read_bytes());assert {k:v for k,v in old.items() if k!='atUtc'}=={k:v for k,v in value.items() if k!='atUtc'}
    else:write(path,value)
publication=json.loads((work/'current-release-sql-frozen-publication-v1.json').read_bytes())
assert all(sha(root/p)==h for p,h in publication['sourceInputHashes'].items())
assert all(oct((root/p).stat().st_mode&0o777)==m for p,m in publication['sourceInputModes'].items())
assert publication['sourceInputCount']==3317
for folder,cases,methods_expected in [('finite-consumer-focus-v1',134,42),('early-original-full-games-v1',2,2)]:
    p=work/folder;summary=json.loads((p/'summary.json').read_bytes());plan=json.loads((p/'plan.json').read_bytes())
    assert summary['status']=='PASSED' and summary['total']==cases
    raw=(p/'focus/results.trx').read_bytes();tree=ET.fromstring(raw);ns={'t':tree.tag.split('}')[0][1:]}
    results=tree.findall('.//t:UnitTestResult',ns);methods=set()
    for item in tree.findall('.//t:UnitTest',ns):
        m=item.find('t:TestMethod',ns);methods.add(m.attrib['className']+'.'+m.attrib['name'])
    assert len(results)==cases and len(methods)==methods_expected and all(r.attrib['outcome']=='Passed' for r in results)
    if folder=='early-original-full-games-v1':
        assert len(methods)==2 and all('.FullGameEndToEndTests.' in m for m in methods) and any('PiltoverAcademy' in m for m in methods) and any('MaraiSpire' in m for m in methods)
    write(work/(folder+'-actual-terminal-before-sole-check-v1.json'),{'atUtc':now(),'status':'PASS_ACTUAL_TRX_AND_ORIGINAL_METHOD_RETENTION','cases':cases,'methods':methods_expected,'trxSha256':hashlib.sha256(raw).hexdigest(),'actualTestAssemblySha256':plan['testAssemblySha256'],'full143And110RemainSeparate':True})
affected=json.loads((work/'affected-original-pairs-owner-v1.json').read_bytes());assert affected['exitCode']==0 and affected['completedPairs']==38 and affected['allRuntimeAndDeclaredSourceHashesUnchanged']
sql_owner=json.loads((work/'actual-ten-and-clairvoyance-owner-v2.json').read_bytes());assert sql_owner['status']=='PASS_CURRENT_TEN_AND_FIVE_REAL_SQL_PLUS_INDEPENDENT_HISTORY_REPLAY' and sql_owner['ownPostgresSmartStopped']
definition_source=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
definition=next(n for n in ast.parse(definition_source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='observe_lock')
exec(compile(ast.Module(body=[definition],type_ignores=[]),str(definition_source),'exec'),globals())
def runtime_files(folder):return {str(p.relative_to(root)):sha(p) for p in sorted(folder.rglob('*')) if p.is_file() and p.relative_to(folder).parts[0]!='var'}
conformance=runtime_files(root/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0')
native=runtime_files(root/'clients/godot/.godot/mono/temp/bin/Debug')
prior_runtime=json.loads((root/'var/qa/spell-remake-no-declaration-20261021/only-check-start-inputs-v1.json').read_bytes())['actualConformanceRuntimeFileHashes']
assert set(prior_runtime)<=set(conformance) and len(conformance)==1419 and len(native)==23
baseline=root/'var/qa/spell-remake-no-declaration-20261021/only-check-v1/check/results.trx'
assert baseline.is_file()
start={'atUtc':now(),'baseCommit':publication['baseCommit'],'includesDeclaredUncommittedChanges':True,
    'sourceInputCount':3317,'sourceInputHashes':publication['sourceInputHashes'],'sourceInputModes':publication['sourceInputModes'],
    'excludedGeneratedOutputDirectory':'tests/Riftbound.ConformanceTests/bin/Debug/net10.0/var/qa', 'allOriginal1401RuntimeInputPathsRetained':True, 'all18AdditionalApphostSqlAndWebResourceInputsAlsoFrozen':True, 'actualConformanceRuntimeFileCount':len(conformance),'actualConformanceRuntimeFileHashes':conformance,
    'actualNativeRuntimeFileCount':len(native),'actualNativeRuntimeFileHashes':native,
    'originalBaselineTrx':str(baseline.relative_to(root)),'originalBaselineTrxSha256':sha(baseline),
    'expectedCases':13214,'expectedMethods':7499,'exactOneCheckForCoherentSingleFriendlyUnitRemakeBatch':True,
    'original143FullMethods110Pairs11DecksSeed424242AndVictoryReplayAssertionsRetained':True,'lockAtStart':observe_lock()}
assert not (work/'only-check-v1').exists()
write(work/'only-check-start-inputs-v1.json',start)
power=process=None;record={'status':'STARTED_ONLY_CHECK_NOT_RESULT','startedAtUtc':now()};started=time.monotonic()
try:
    power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);record['boundIdleAssertionPid']=power.pid
    with (work/'only-check-v1.log').open('xb') as log:
        process=subprocess.Popen(['python3','scripts/test-rules.py','check','--output',str((work/'only-check-v1').relative_to(root))],cwd=root,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0'))
        record['ownedTestRunnerPid']=process.pid
        write(work/'only-check-owner-started-v1.json',record)
        code=process.wait();record['exitCode']=code
    record['status']='CHECK_PROCESS_EXIT_ZERO_INDEPENDENT_PARITY_STILL_REQUIRED' if code==0 else 'CHECK_FAILED_OR_INTERRUPTED_ORIGINAL_OUTPUT_RETAINED'
except BaseException as e:
    record.update(status='CHECK_OWNER_EXCEPTION_ORIGINAL_OUTPUT_RETAINED',errorType=type(e).__name__,error=str(e));raise
finally:
    if process is not None and process.poll() is None:
        os.killpg(process.pid,signal.SIGTERM);process.wait(timeout=30)
    if power is not None and power.poll() is None:power.terminate();power.wait(timeout=10)
    record.update(finishedAtUtc=now(),seconds=round(time.monotonic()-started,2),lockAtEnd=observe_lock(),
        all3317SourceHashesUnchanged=all(sha(root/p)==h for p,h in start['sourceInputHashes'].items()),
        allSourceModesUnchanged=all(oct((root/p).stat().st_mode&0o777)==m for p,m in start['sourceInputModes'].items()),
        allConformanceInputPayloadsUnchanged=conformance==runtime_files(root/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0'),
        all23NativePayloadsUnchanged=native==runtime_files(root/'clients/godot/.godot/mono/temp/bin/Debug'),boundIdleAssertionEnded=power is not None and power.poll() is not None)
    write(work/'only-check-owner-terminal-v1.json',record)
print(record['status'],flush=True)
assert record.get('exitCode')==0
