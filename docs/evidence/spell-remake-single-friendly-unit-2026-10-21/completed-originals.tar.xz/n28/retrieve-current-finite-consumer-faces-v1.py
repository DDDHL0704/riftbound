import datetime,hashlib,json,urllib.request
from pathlib import Path
w=Path(__file__).resolve().parent;out=w/'current-finite-consumer-faces-v1';out.mkdir(exist_ok=False)
d=json.loads((w/'friendly-single-slot-official-consumer-candidate-inventory-v1.json').read_text());records=[]
try:
 for r in d['records']:
  if r['registryCardNo'] in ['OGN·173/298','UNL-101/219','OGN·046/298']:continue
  a=r['fullCurrentApiRow'];url=a['frontImage'];start=datetime.datetime.now(datetime.timezone.utc).isoformat()
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Riftbound-official-source-audit/1.0'}),timeout=45) as response:
   raw=response.read();resolved=response.geturl();headers=dict(response.headers);status=response.status
  target=out/(str(a['id'])+Path(url).suffix);target.write_bytes(raw)
  row={'requestedAtUtc':start,'receivedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'region':'CN','language':'zh-CN','applicableAsOf':'2026-10-21','apiId':a['id'],'rawCardNo':a['cardNo'],'fullCurrentApiRow':a,'url':url,'resolvedUrl':resolved,'httpStatus':status,'responseHeaders':headers,'path':str(target),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'independentPublicationOrEffectiveDate':None,'facePixelsReviewed':False,'wholePrintingCertification':False};records.append(row)
  print(a['id'],a['cardNo'],len(raw),flush=True)
finally:
 (out/'source-manifest.json').write_text(json.dumps({'status':'ACTUAL_SOURCE_BYTES_RETAINED_PIXELS_PENDING','records':records,'originalRound21AllRowsAndScopeUnchanged':True},ensure_ascii=False,indent=2))
