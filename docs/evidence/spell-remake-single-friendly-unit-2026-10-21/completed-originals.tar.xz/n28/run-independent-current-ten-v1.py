import datetime,hashlib,json,os,resource,subprocess
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;r=w/'independent-sql-reader-runtime-v1';sql=w/'sql-runtime-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
publication=json.loads((w/'current-release-sql-frozen-publication-v1.json').read_text());reader=json.loads((w/'independent-current-reader-frozen-publication-v1.json').read_text());owner=json.loads((w/'actual-ten-and-clairvoyance-owner-v2.json').read_text())
assert owner['status']=='WAITING_INDEPENDENT_CURRENT_SQL_HISTORY_READER_NOT_FINAL_ACCEPTANCE' and owner['tenWriterExitCode']==owner['clairvoyanceWriterExitCode']==0
result=w/'independent-current-ten-and-clair-originals-result-v1.json';receipt=w/'independent-current-ten-and-clair-originals-run-v1.json';stop=w/'independent-readback-complete-stop-v1.json';assert not any(p.exists() for p in [result,receipt,stop])
def frozen():
 assert all(sha(root/p)==h for p,h in publication['sourceInputHashes'].items())
 assert all(oct((root/p).stat().st_mode&0o777)==m for p,m in publication['sourceInputModes'].items())
 assert all(sha(sql/p)==h for p,h in publication['runtimeFiles'].items())
 assert all(sha(r/p)==h for p,h in reader['runtimeFiles'].items())
frozen();command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(sql/'Riftbound.PostgresAcceptance.deps.json'),'--runtimeconfig',str(sql/'Riftbound.PostgresAcceptance.runtimeconfig.json'),str(r/'SingleFriendlyRemakeIndependentSqlReader.dll'),str(w),str(result)]
proof={'startedAtUtc':now(),'command':command,'runtimeFiles':reader['runtimeFiles'],'readerSources':reader['readerSourceFiles'],'status':'RUNNING_READ_ONLY_NOT_ACCEPTANCE'}
try:
 env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit',DOTNET_DbgEnableMiniDump='0')
 with (w/'independent-current-ten-and-clair-originals-v1.log').open('xb') as log:code=subprocess.run(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300).returncode
 proof['exitCode']=code;assert code==0
 d=json.loads(result.read_text());assert d['status']=='PASS_INDEPENDENT_CURRENT_TEN_ACTUAL_SQL_HISTORY_AND_FIVE_ORIGINAL_CLAIRVOYANCE_FULL_REPLAYS'
 assert d['retainedActualSqlFixtures']==10 and d['originalExportedClairvoyanceFixtures']==5 and d['totalAuthoritativeHistoricalSqlStates']==84 and d['bothPlayersCombinedHistoricalSqlSnapshots']==d['bothPlayersCombinedHistoricalSqlPrompts']==168
 assert d['actualRuleInputs']==publication['actualRuleInputs'];frozen()
 proof.update(status=d['status'],readOnlyValidationComplete=True,allReaderAndCurrentOwnerSourceAndRuntimeStable=True,resultSha256=sha(result))
 stop.write_text(json.dumps({'independentReadbackPassed':True,'atUtc':now(),'result':str(result),'resultSha256':sha(result),'tenActualSqlFixtures':10,'authoritativeHistoricalStates':84,'bothPlayersCombinedPrivateSnapshots':168,'bothPlayersCombinedPrivatePrompts':168,'allOriginalFieldsNullAndConditionalOmissionsPreserved':True,'completeOriginalCommandEventAndFinalStateReplaysVerified':True,'actualRuleInputs':publication['actualRuleInputs']},indent=2))
except BaseException as e:
 proof.update(status='FAILED_OR_INTERRUPTED_READ_ONLY_ORIGINALS_RETAINED',errorType=type(e).__name__,error=str(e))
 if not stop.exists():stop.write_text(json.dumps({'independentReadbackPassed':False,'reason':'Independent reader failed; stop own PostgreSQL normally and retain all originals.','atUtc':now()}))
 raise
finally:
 proof['finishedAtUtc']=now();receipt.write_text(json.dumps(proof,indent=2))
print(proof['status'],flush=True)
