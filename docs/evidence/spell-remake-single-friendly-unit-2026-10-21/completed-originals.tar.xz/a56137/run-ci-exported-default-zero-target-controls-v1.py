import ast,datetime,hashlib,json,os,plistlib,resource,subprocess
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
w=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
s=w/'verify-current-fixed-native-default-boot-v1.py';nodes=[n for n in ast.parse(s.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='lock'];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(s),'exec'),globals())
proof=json.loads((w/'native-app-inputs.json').read_text());projection=json.loads((w/'fixed-current-zero-target-input-and-runtime-v1.json').read_text());app=Path(proof['apps'][0]['app']);candidate=w/'fixed-current-zero-target-input-v1/candidate.json'
assert proof['fixedCommit']==projection['fixedCommit']=='a56137a93d48a38d6e2e62b5b7195aa03412577f' and sha(candidate)==projection['candidateSha256']
assert all(sha(app/p)==h for p,h in proof['ciManagedAndPckPayloads'].items())
args=[str(app/'Contents/MacOS/符文战场'),'--headless','--','--riftbound-play-card-proof','--candidate='+str(candidate),'--verify-preview']
receipt=w/'ci-exported-default-zero-target-controls-owner-v1.json';assert not receipt.exists();log=w/'ci-exported-default-zero-target-controls-v1.log'
result={'startedAtUtc':now(),'fixedCommit':proof['fixedCommit'],'fixedCiRun':39481821852,'lockAtStart':lock(),'candidateSha256':sha(candidate),'actualRuleInputsOfNewServerProjection':projection['actualRuleInputs'],'actualCommand':args,'existingDefaultMainProofEntryUsedWithoutScenePathOverrideOrPackageChanges':True,'realHttpQuoteCommandSubmitSqlVisiblePairedAndPhysicalWindowsClaim':False,'syntheticQuoteFreshnessControlsOnly':True};process=None
try:
 env=dict(os.environ,DOTNET_DbgEnableMiniDump='0');env.pop('DOTNET_STARTUP_HOOKS',None)
 with log.open('xb') as stream:
  process=subprocess.Popen(args,cwd='/tmp',env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True);result['ownNativePid']=process.pid;code=process.wait(timeout=60)
 raw=log.read_text();result.update(exitCode=code,originalFreshnessGuardPassMarker='PLAY_COST_PREVIEW_FRESHNESS_PASS' in raw,noGodotErrorOrUnhandledException=not any(s in raw for s in ['ERROR:','Unhandled exception','SCRIPT ERROR:']))
 assert code==0 and result['originalFreshnessGuardPassMarker'] and result['noGodotErrorOrUnhandledException']
 assert all(sha(app/p)==h for p,h in proof['ciManagedAndPckPayloads'].items()) and sha(candidate)==projection['candidateSha256'];subprocess.run(['codesign','--verify','--deep','--strict',str(app)],check=True,capture_output=True)
 result.update(status='PASS_ACTUAL_FIXED_CI_EXPORTED_DEFAULT_MAIN_ZERO_TARGET_AND_ORIGINAL_QUOTE_FRESHNESS_CONTROLS',all373CiPayloadsAndSignatureExact=True)
except BaseException as e:
 result.update(status='FAILED_OR_INTERRUPTED_ORIGINAL_EXPORTED_CONTROL_OUTPUT_RETAINED',errorType=type(e).__name__,error=str(e));raise
finally:
 if process is not None and process.poll() is None:process.terminate();process.wait(timeout=15)
 result.update(finishedAtUtc=now(),lockAtEnd=lock(),ownNativeProcessEnded=process is not None and process.poll() is not None,logSha256=sha(log));receipt.write_text(json.dumps(result,indent=2))
print(result['status'],flush=True)
