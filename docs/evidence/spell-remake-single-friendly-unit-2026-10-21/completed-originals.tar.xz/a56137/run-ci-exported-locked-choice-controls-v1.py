import ast,datetime,hashlib,json,os,plistlib,resource,subprocess
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
source=w/'verify-current-fixed-native-default-boot-v1.py';nodes=[n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='lock'];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),globals())
proof=json.loads((w/'native-app-inputs.json').read_text());app=Path(proof['apps'][0]['app']);assert proof['fixedCommit']=='a56137a93d48a38d6e2e62b5b7195aa03412577f'
assert all(sha(app/p)==h for p,h in proof['ciManagedAndPckPayloads'].items())
assembly=app/'Contents/Resources/data_Riftbound.GodotClient_macos_arm64/Riftbound.GodotClient.dll';assert assembly.is_file()
folder=root/'var/qa/native-spell-choice-presentation-20261020/inputs-v1';index=json.loads((folder/'index.json').read_text());assert len(index)==6
originals={row['framePath']:row['frameSha256'] for row in index};assert all(sha(Path(p))==h for p,h in originals.items())
out=w/'ci-exported-headless-choice-controls-v1';assert not out.exists();receipt=w/'ci-exported-headless-choice-controls-owner-v1.json';assert not receipt.exists()
args=[str(app/'Contents/MacOS/符文战场'),'--headless','res://scenes/debug/SpellChoiceRemakeInteractionProof.tscn','--','--evidence='+str(folder),'--output='+str(out),'--client-assembly='+str(assembly)]
result={'startedAtUtc':now(),'fixedCommit':proof['fixedCommit'],'fixedCiRun':39481821852,'lockAtStart':lock(),'actualCiClientAssemblySha256':sha(assembly),'originalSixFrameHashes':originals,'originalIndexSha256':sha(folder/'index.json'),'actualCommand':args,'visiblePairedLiveHttpDatabaseOrPhysicalWindowsAcceptance':False}
process=None
try:
 with (w/'ci-exported-headless-choice-controls-v1.log').open('xb') as log:
  process=subprocess.Popen(args,cwd='/tmp',stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0'));result['ownNativePid']=process.pid;code=process.wait(timeout=60)
 result['exitCode']=code;assert code==0
 d=json.loads((out/'receipt.json').read_text());assert d['status']=='PASS_ORIGINAL_SQL_NATIVE_SPELL_CHOICE_CONTROLS_AND_PRESENTATION' and d['commands']==6 and d['actualViews']==d['syntheticStartViews']==12 and not d['errors']
 assert d['actualClientAssemblySha256']==sha(assembly) and d['displayDriver']=='headless'
 assert all(sha(app/p)==h for p,h in proof['ciManagedAndPckPayloads'].items()) and all(sha(Path(p))==h for p,h in originals.items())
 subprocess.run(['codesign','--verify','--deep','--strict',str(app)],check=True,capture_output=True)
 result.update(status='PASS_CURRENT_FIXED_CI_EXPORTED_HEADLESS_REAL_BUTTONS_SIX_ORIGINAL_INTENTS_AND_TWELVE_VIEWS',nativeReceipt=d,all373OriginalCiManagedAndPckHashesAndDeepStrictSignatureExact=True,allSixOriginalFramesAndIndexUnchanged=True)
except BaseException as e:
 result.update(status='FAILED_OR_INTERRUPTED_EXPORTED_NATIVE_PROOF_ORIGINALS_RETAINED',errorType=type(e).__name__,error=str(e));raise
finally:
 if process is not None and process.poll() is None:process.terminate();process.wait(timeout=15)
 result.update(finishedAtUtc=now(),lockAtEnd=lock(),ownNativeProcessEnded=process is not None and process.poll() is not None);receipt.write_text(json.dumps(result,indent=2))
print(result['status'],flush=True)
