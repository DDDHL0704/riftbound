import ast,collections,datetime,fcntl,gzip,hashlib,json,os,plistlib,re,resource,socket,subprocess,time,urllib.request
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();load=lambda p:json.loads(p.read_text())
pub=load(w/'fixed-clean-api-runtime-source-and-identity-v3.json');helper_pub=load(w/'same-original-room-gateway-frozen-publication-v1.json');desktop=load(w/'native-app-inputs.json');helpers=w/'same-original-room-gateway-runtime-v1';cmd=pub['identityReaderCommand'];api_runtime=Path(cmd[cmd.index('--depsfile')+1]).parent
entry=load(w/'actual-safe-native-prefix-v1/pending-original-native-prefix-receipt.json');room=entry['room'];n=entry['acceptedCommands'];a,b=entry['players'];original=load(w/'actual-safe-native-main-v1/original231-audit47-native-seven-table-baseline-v1.json');failed=load(w/'live-fixed-ci-main-owner-terminal-v1.json');assert failed['room']==room and failed['ownPostgresSmartStopped'] and failed['allOriginal231AuditSevenTablesExactAtStop'] and failed['allOriginal47NativeSevenTablesExactAtStop']
evidence=w/'actual-same-original-room-gateway-v1';evidence.mkdir(exist_ok=False);terminal=w/'same-original-room-gateway-owner-terminal-v1.json';ready=w/'same-original-room-gateway-score-ready-v1.json';stop=w/'same-original-room-gateway-stop-v1.json';assert not any(p.exists() for p in [terminal,ready,stop])
for source,names in [(root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py',{'query','rooms','digests','observe_lock'}),(w/'run-live-fixed-ci-main-pair-v1.py',{'checkpoint','frozen','start_api','export'})]:
 nodes=[v for v in ast.parse(source.read_text()).body if isinstance(v,ast.FunctionDef) and v.name in names];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),globals())
def state(stage):
 proof['stage']=stage;proof['updatedAtUtc']=now();tmp=w/'same-room-gateway-state-v1.tmp';tmp.write_text(json.dumps(proof,indent=2));tmp.replace(w/'same-room-gateway-owner-state-v1.json');print(stage,flush=True)
def history():
 assert re.fullmatch('N27-RETARGET-[0-9A-F]{10}',room);result={}
 for table in ['command_log','game_events','state_snapshots','snapshots','action_prompts']:
  args=[str(pg/'psql'),'-XAt','-h','127.0.0.1','-p','55486','-U','codex_riftbound_audit','-d','riftbound_here_native','-v','ON_ERROR_STOP=1','-c',f"select row_to_json(t)::text from {table} t where match_id='{room}' order by id"]
  process=subprocess.Popen(args,env=read_env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);values=[hashlib.sha256(line.rstrip(b'\n')).hexdigest() for line in process.stdout];error=process.stderr.read();assert process.wait()==0,error.decode(errors='replace')[:200];result[table]=values
 return result

guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof={'status':'RUNNING_SAME_ORIGINAL_FAILED_NATIVE_ROOM_GATEWAY_CONTINUATION_NOT_NATIVE_ACCEPTANCE','startedAtUtc':now(),'fixedCommit':pub['fixedCommit'],'actualRuleInputs':pub['actualRuleInputs'],'room':room,'originalGatewayPrefixCommands':n,'originalNativeAcceptedGameplayCommands':0,'originalNativeFailureIssue':77,'originalNativeFailureNotRelabeled':True,'ownedApiProcesses':[],'lockAtStart':observe_lock()};api=power=driver=None;started=False;before=None
try:
 frozen();assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof.update(ownPid=os.getpid(),boundIdleAssertionPid=power.pid);state('STARTING_OWN_DATABASE_FOR_EXACT_ORIGINAL_PARTIAL_ROOM')
 subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'same-original-room-gateway-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 assert rooms('riftbound_acceptance')==original['auditRooms'] and set(rooms('riftbound_here_native'))==set(original['nativeRooms'])|{room}
 assert digests('riftbound_acceptance',original['auditRooms'])==original['auditSevenTables'] and digests('riftbound_here_native',original['nativeRooms'])==original['nativeSevenTables']
 before=export('before-same-original-room-gateway-original-frame-v1');old=json.loads(gzip.decompress((w/'actual-safe-native-main-v1/owner-final-current-ci-native-original-frame-v1.json.gz').read_bytes()));assert before==old and len(before['commands'])==n
 before_history=history();checkpoint('original-five-history-table-full-row-hashes-before-v1.json',before_history)
 start_api(3);state('EXACT_CURRENT_ORIGINAL_PHASE_RESTORED_CONTINUING_ORIGINAL_IDENTITY')
 output=w/'same-original-room-gateway-actions-v1';assert not output.exists()
 with (w/'same-original-room-gateway-actions-v1.log').open('xb') as stream:
  driver=subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet',str(helpers/'FixedA561SameOriginalGatewayContinuation.dll'),'http://127.0.0.1:15847',str(output),str(w)],cwd=helpers,stdout=stream,stderr=subprocess.STDOUT,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0'));assert driver.wait(timeout=330)==0,'Keep original partial room, raw outputs and current legitimate session tokens.'
 result=load(output/'normal-original-score-continuation-receipt.json');assert result['continuationCommands']==20 and result['gatewayKeepPriorityCommands']==3 and result['normalScoreGatewayCommands']==17 and result['nativeAcceptedGameplayCommands']==0 and result['winningScore']==8
 final=export('after-same-original-room-gateway-normal-score-final-original-frame-v1');s=final['authoritativeState'];assert len(final['commands'])==n+20 and s['status']=='FINISHED' and s['winnerPlayerId']==a and s['playerScores']=={a:8,b:0}
 assert final['commands'][:n]==before['commands'] and final['events'][:len(before['events'])]==before['events'] and final['openingSeed']==before['openingSeed'] and final['replayInitialState']==before['replayInitialState']
 assert all(c['accepted'] and c['commandType']!='SURRENDER' for c in final['commands'])
 after_history=history()
 for table,values in before_history.items():
  prior=collections.Counter(values);actual=collections.Counter(after_history[table]);assert all(actual.get(key,0)>=amount for key,amount in prior.items()),table
 checkpoint('all-original-five-history-table-rows-retained-v1.json',{'allOriginalRowBytesAndMultiplicityPreserved':True,'beforeCounts':{k:len(v) for k,v in before_history.items()},'afterCounts':{k:len(v) for k,v in after_history.items()}})
 frozen();assert digests('riftbound_acceptance',original['auditRooms'])==original['auditSevenTables'] and digests('riftbound_here_native',original['nativeRooms'])==original['nativeSevenTables']
 proof.update(status='SAME_ORIGINAL_ROOM_GATEWAY_NORMAL_SCORE_READY_FOR_INDEPENDENT_ALL_HISTORY_REPLAY',totalCommands=len(final['commands']),events=len(final['events']),gatewayContinuationCommands=20,nativeAcceptedGameplayCommands=0,winningScore=8,losingScore=0,finalTurn=s['turnNumber'],original28PrefixAllFieldsEventsPrivateSeedAndBlankInitialExact=True,allOriginalFiveHistoryTablesRowBytesAndMultiplicityRetained=True,allOriginal231Audit47NativeSevenTablesExact=True)
 ready.write_text(json.dumps({**proof,'actualDatabase':'riftbound_here_native','rawFinalFrame':str(evidence/'after-same-original-room-gateway-normal-score-final-original-frame-v1.json.gz'),'apiPid':api.pid},indent=2));state('WAITING_INDEPENDENT_ORIGINAL_SQL_HISTORY_AND_FULL_REPLAY_NATIVE_FAILURE_STILL_OPEN')
 limit=time.monotonic()+900
 while not stop.exists():assert api.poll() is None and time.monotonic()<limit;time.sleep(.2)
 completion=load(stop);assert completion['room']==room and completion['independentReadOnlyHistoryAndFullReplayPass'];proof.update(status='PASS_SAME_ORIGINAL_ROOM_GATEWAY_NORMAL_SCORE_AND_INDEPENDENT_SQL_REPLAY_NATIVE_ACCEPTANCE_STILL_FAILED',independentReadback=completion)
except BaseException as error:
 proof.update(status='FAILED_OR_INTERRUPTED_SAME_ORIGINAL_ROOM_CONTINUATION_ORIGINALS_RETAINED',errorType=type(error).__name__,error=str(error));print(proof['status'],type(error).__name__,flush=True);raise
finally:
 if driver is not None and driver.poll() is None:driver.terminate();driver.wait(timeout=20)
 if started:
  try:export('owner-final-same-original-room-gateway-frame-v1');proof['latestOwnRoomOriginalFrameRetained']=True
  except BaseException as error:proof['finalFrameExportErrorType']=type(error).__name__
 if api is not None:
  if api.poll() is None:api.terminate();api.wait(timeout=25)
  proof['ownApiStopped']=api.poll() is not None
 if started:
  proof['allOriginal231AuditSevenTablesExactAtStop']=digests('riftbound_acceptance',original['auditRooms'])==original['auditSevenTables'];proof['allOriginal47NativeSevenTablesExactAtStop']=digests('riftbound_here_native',original['nativeRooms'])==original['nativeSevenTables'];proof['actualNativeRoomsAtStop']=rooms('riftbound_here_native')
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None:
  if power.poll() is None:power.terminate();power.wait(timeout=10)
  proof['boundIdleAssertionEnded']=power.poll() is not None
 frozen();proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),allFrozenCurrentApiHelpersAndBoth373CiPayloadHashesExact=True,originalNativeFailureIssue77StillOpen=True,visibleAndPhysicalWindowsAcceptance=False);terminal.write_text(json.dumps(proof,indent=2));fcntl.flock(guard,fcntl.LOCK_UN)
print(proof['status'],flush=True)
