from pathlib import Path
import datetime,hashlib,json,subprocess,zipfile
w=Path(__file__).resolve().parent;fixed='a56137a93d48a38d6e2e62b5b7195aa03412577f';root=w.parents[2];sha=lambda b:hashlib.sha256(b).hexdigest()
raw_manifest=subprocess.check_output(['git','show',fixed+':tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'],cwd=root);ids=[x['id'] for x in json.loads(raw_manifest)['cases']];expected=ids[3::4]
with zipfile.ZipFile(w/'ci-fixed-a56137/postgres-partition-3.zip') as z:
 receipt_raw=z.read('ci-postgres/partition-receipt.json');d=json.loads(receipt_raw)
 assert d['fixedCommit']==fixed and d['status']=='REAL_POSTGRES_PARTITION_COMPLETE' and d['partitionIndex']==3 and d['partitionCount']==4
 assert d['orderedDefaultCases']==ids and d['expectedCases']==d['completedCases']==expected and len(ids)==48 and d['manifestSha256']==sha(raw_manifest)
 assert [r['id'] for r in d['executions']]==expected and [r['ordinal'] for r in d['executions']]==list(range(3,48,4)) and all(r['status']=='PASSED' for r in d['executions'])
 files=[]
 for f in d['outputFiles']:
  name='ci-postgres/'+f['path'];raw=z.read(name);assert len(raw)==f['bytes'] and sha(raw)==f['sha256'];files.append(name)
 assert len(files)==len(set(files))==120
 actual={n for n in z.namelist() if not n.endswith('/')}
 assert actual==set(files)|{'ci-postgres/partition-receipt.json','ci-postgres-partition-commit.txt'} and z.read('ci-postgres-partition-commit.txt').decode().strip()==fixed
 cases=[]
 for mirror in ['reversal','mirror']:
  for branch in ['draw','mode','zero','echo']:
   r=json.loads(z.read('ci-postgres/spell-remake-declaration/'+mirror+'-'+branch+'/receipt.json'));assert r['actualRuleInputs']==d['actualRuleInputs'] and r['status']=='REAL_POSTGRES_DECLARATION_SCOPE_COLD_DEDUP_REPLAY_AND_ATOMIC_REJECTION_PASS' and r['coldRecoveries']==r['commands'];cases.append(r)
 assert sum(r['commands'] for r in cases)==69 and sum(r['events'] for r in cases)==145 and sum(r['atomicRejections'] for r in cases)==18
with zipfile.ZipFile(w/'ci-fixed-a56137/native-network-results.zip') as z:
 assert z.read('commit.txt').decode().strip()==fixed;raw=z.read('native-network.log').decode();prefix='NATIVE_ROOM_IDENTITY_EVIDENCE ';network=json.loads(next(x[len(prefix):] for x in raw.splitlines() if x.startswith(prefix)))
 assert network['rejectedActions']==15 and network['leakedPrivateMessages']==0 and network['validReconnectTokenWasSupplied'] and network['identities']==['ANONYMOUS','FAILED_KEY','OTHER_HANDLE']
 assert 'Native network recovery passed: socket loss, authenticated room restore, fresh snapshot, rejected-token guard.' in raw
result={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_FIXED_A56137_ONLY_PARTITION3_AND_NETWORK_ORIGINALS_NOT_ENTIRE_FULL','fixedCommit':fixed,'runId':39481821852,'fixedOrderedSqlManifestSha256':sha(raw_manifest),'allOriginal48SqlIdsAndOrderRetained':True,'verifiedPartition':3,'verifiedPartitionCases':expected,'all12ExecutionsActuallyPassed':True,'original120OutputFilesByteSizeHashAndClosedMemberSetExact':True,'partitionReceiptSha256':sha(receipt_raw),'actualCiRuntimeAssemblyIdentityReports':d['runtimeAssemblies'],'actualCiRuleInputs':d['actualRuleInputs'],'originalEightDeclarationBranches':{'commands':69,'events':145,'coldRecoveries':69,'directAtomicRejections':18,'controlledExplicitFixturesNotOrdinaryFullGames':True},'networkOriginalEvidence':network,'allOriginalNetworkRestorePassMarkersPresent':True,'backendZipProof':'current-ci-part3-and-network-original-download-v1.json','otherThreeSqlPartsRuleSuiteStableAggregateAndAllSourceSemanticCompletion':'OPEN','local210fcAndBde6RuntimeNotConflatedWithCiFf632Runtime':True}
p=w/'fixed-a56137-partition3-network-original-independent-readback-v2.json';assert not p.exists();p.write_text(json.dumps(result,indent=2))
(w/'part3-initial-member-layout-assumption-failure-disposition-v1.json').write_text(json.dumps({'atUtc':result['atUtc'],'status':'READ_ONLY_VERIFIER_ASSUMPTION_FAILURE_NOT_CI_OR_SOURCE_FAILURE','originalAssumption':'The SQL artifact commit file was commit.txt.','actualOriginalMember':'ci-postgres-partition-commit.txt','allOriginalDownloadBytesAnd120OutputsPreserved':True,'correctedReader':'verify-current-ci-part3-network-v2.py','ciOrSqlWritersRerun':False},indent=2))
print(result['status'],'12 SQL identities/120 original files;69 commands145events;15 network rejects0leaks',flush=True)
