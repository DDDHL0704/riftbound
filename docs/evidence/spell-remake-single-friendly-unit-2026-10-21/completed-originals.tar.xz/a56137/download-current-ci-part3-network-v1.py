import datetime,hashlib,json,os,subprocess,zipfile
from pathlib import Path
os.umask(0o077);w=Path(__file__).resolve().parent;out=w/'ci-fixed-a56137';out.mkdir(exist_ok=False);metadata=json.loads(sorted(w.glob('artifacts-*.json'))[-1].read_text());records=[]
try:
 for name,filename in [('postgres-partition-3','postgres-partition-3.zip'),('native-network-results','native-network-results.zip')]:
  a=next(a for a in metadata['artifacts'] if a['name']==name);assert not a['expired'] and a['workflow_run']['head_sha']=='a56137a93d48a38d6e2e62b5b7195aa03412577f'
  p=out/filename
  with p.open('xb') as stream:r=subprocess.run(['gh','api',f'repos/DDDHL0704/riftbound/actions/artifacts/{a["id"]}/zip'],stdout=stream)
  h=hashlib.sha256(p.read_bytes()).hexdigest();assert r.returncode==0 and p.stat().st_size==a['size_in_bytes'] and 'sha256:'+h==a['digest']
  row={'id':a['id'],'name':name,'path':str(p),'bytes':p.stat().st_size,'sha256':h,'backendSizeAndDigestExact':True}
  with zipfile.ZipFile(p) as z:
   assert z.testzip() is None;row['allZipCrcVerified']=True;row['entries']=[{'name':i.filename,'bytes':i.file_size,'sha256':hashlib.sha256(z.read(i.filename)).hexdigest()} for i in z.infolist() if not i.is_dir()]
   print(name,'PASS',len(row['entries']),'original members',flush=True)
  records.append(row)
finally:
 (w/'current-ci-part3-and-network-original-download-v1.json').write_text(json.dumps({'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fixedCommit':'a56137a93d48a38d6e2e62b5b7195aa03412577f','runId':39481821852,'records':records,'entireRunNotYetCertified':True},indent=2))
