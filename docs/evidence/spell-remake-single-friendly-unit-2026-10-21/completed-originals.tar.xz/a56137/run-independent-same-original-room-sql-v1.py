from pathlib import Path
import datetime,hashlib,json,os,resource,shutil,subprocess
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
w=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();pub=json.loads((w/'fixed-clean-api-runtime-source-and-identity-v3.json').read_text());ready=json.loads((w/'same-original-room-gateway-score-ready-v1.json').read_text());old=w/'same-original-room-gateway-runtime-v1';old_pub=json.loads((w/'same-original-room-gateway-frozen-publication-v1.json').read_text());r=w/'same-original-room-sql-reader-runtime-v1';r.mkdir(exist_ok=False)
assert all(sha(old/p)==h for p,h in old_pub['runtimeFiles'].items())
for p in old.rglob('*'):
 if p.is_file():q=r/p.relative_to(old);q.parent.mkdir(parents=True,exist_ok=True);os.link(p,q)
p=w/'same-original-room-sql-reader-build-v1/FixedA561SameOriginalSqlReader.dll';shutil.copyfile(p,r/p.name);files={str(p.relative_to(r)):sha(p) for p in r.rglob('*') if p.is_file()};assert len(files)==77
result=w/'independent-same-original-room-all-sql-history-result-v1.json';receipt=w/'independent-same-original-room-all-sql-history-run-v1.json';stop=w/'same-original-room-gateway-stop-v1.json';assert not any(p.exists() for p in [result,receipt,stop])
command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(r/'Riftbound.Api.deps.json'),'--runtimeconfig',str(r/'Riftbound.Api.runtimeconfig.json'),str(r/'FixedA561SameOriginalSqlReader.dll'),str(w),str(result)]
proof={'startedAtUtc':now(),'fixedCommit':pub['fixedCommit'],'room':ready['room'],'actualRuleInputs':pub['actualRuleInputs'],'command':command,'readerRuntimeFileHashes':files,'readerSourceHashes':{str(p):sha(p) for p in (w/'same-original-room-sql-reader-source-v1').glob('*') if p.is_file()},'status':'RUNNING_READ_ONLY_NOT_ACCEPTANCE'}
try:
 with (w/'independent-same-original-room-all-sql-history-v1.log').open('xb') as log:
  env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit',DOTNET_DbgEnableMiniDump='0');code=subprocess.run(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300).returncode
 proof['exitCode']=code;assert code==0
 d=json.loads(result.read_text());assert d['status']=='PASS_INDEPENDENT_SAME_ORIGINAL_ROOM_ALL_SQL_HISTORY_AND_GATEWAY_NORMAL_SCORE_REPLAY_NATIVE_FAILURE_OPEN' and d['room']==ready['room'] and d['commands']==48 and d['events']==259 and d['actualRuleInputs']==pub['actualRuleInputs'] and d['nativeAcceptedGameplayCommands']==0 and d['winningScore']==8
 assert all(sha(r/p)==h for p,h in files.items()) and all(sha(old/p)==h for p,h in old_pub['runtimeFiles'].items())
 proof.update(status=d['status'],allCurrentFrozenApiAndReaderHashesStable=True,actualAllHistoryCounts=d['actualHistoricalPayloads'],readOnlyValidationComplete=True,resultSha256=sha(result))
 stop.write_text(json.dumps({'atUtc':now(),'room':ready['room'],'independentReadOnlyHistoryAndFullReplayPass':True,'result':str(result),'resultSha256':sha(result),'commands':48,'events':259,'normalGatewayContinuationCommands':20,'nativeAcceptedGameplayCommands':0,'originalNativeFailureIssue77StillOpen':True},indent=2))
except BaseException as e:
 proof.update(status='FAILED_OR_INTERRUPTED_INDEPENDENT_READER_ORIGINALS_RETAINED_NO_SQL_WRITER_RERUN',errorType=type(e).__name__,error=str(e));raise
finally:
 proof['finishedAtUtc']=now();receipt.write_text(json.dumps(proof,indent=2))
print(proof['status'],flush=True)
