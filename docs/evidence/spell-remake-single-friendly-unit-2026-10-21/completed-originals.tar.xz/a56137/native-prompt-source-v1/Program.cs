using System.Text.Json;
using System.Text.Json.Nodes;
using Riftbound.Contracts;
using Riftbound.Engine;
if(args.Length!=1||Directory.Exists(args[0]))throw new Exception("Unused explicit fixture output required.");
var output=Path.GetFullPath(args[0]);
var json=new JsonSerializerOptions(JsonSerializerDefaults.Web){WriteIndented=true};
var cards=new Dictionary<string,CardObjectState>{
 ["SPELL"]=new("SPELL",cardNo:"SFD·080/221",manaCost:1,ownerId:"P1",controllerId:"P1",tags:[CardObjectTags.SpellCard]),
 ["UNIT-1"]=new("UNIT-1",power:9,cardNo:"OGN·001/298",ownerId:"P1",controllerId:"P1",tags:[CardObjectTags.UnitCard]),
 ["UNIT-2"]=new("UNIT-2",power:9,cardNo:"OGN·001/298",ownerId:"P2",controllerId:"P2",tags:[CardObjectTags.UnitCard])};
var initial=new MatchState("fixed-a56137-zero-target-controlled-projection",0,1,"P1",new Dictionary<string,string>{["P1"]="P1",["P2"]="P2"},
 status:MatchStatuses.InProgress,phase:MatchPhases.Main,timingState:TimingStates.NeutralOpen,cardObjects:cards,
 playerZones:new Dictionary<string,PlayerZones>{["P1"]=PlayerZones.Empty with{Hand=["SPELL"],Base=["UNIT-1"]},["P2"]=PlayerZones.Empty with{Base=["UNIT-2"]}},
 runePools:new Dictionary<string,RunePool>{["P1"]=new(30,30),["P2"]=new(30,30)});
var session=new MatchSession(initial,new CoreRuleEngine(),NoopMatchJournal.Instance);
var prompt=session.PromptFor("P1");var snapshot=session.SnapshotFor("P1");
var raw=JsonSerializer.SerializeToNode(prompt,json)!;
var candidate=raw["candidates"]!.AsArray().Single(c=>c!["action"]!.GetValue<string>()=="PLAY_CARD")!;
var requirements=candidate["metadata"]!["sourceRequirements"]!.AsArray();
var requirement=requirements.Single(r=>r!["sourceObjectId"]!.GetValue<string>()=="SPELL")!;
if(requirement["minTargetCount"]!.GetValue<int>()!=0||requirement["maxTargetCount"]!.GetValue<int>()!=3)throw new Exception("Current server prompt must expose exact zero-to-three.");
Directory.CreateDirectory(output);
await File.WriteAllTextAsync(Path.Combine(output,"explicit-current-initial.json"),JsonSerializer.Serialize(initial,json));
await File.WriteAllTextAsync(Path.Combine(output,"prompt.json"),JsonSerializer.Serialize(prompt,json));
await File.WriteAllTextAsync(Path.Combine(output,"snapshot.json"),JsonSerializer.Serialize(snapshot,json));
await File.WriteAllTextAsync(Path.Combine(output,"candidate.json"),candidate.ToJsonString(json));
await File.WriteAllTextAsync(Path.Combine(output,"receipt.json"),JsonSerializer.Serialize(new{
 status="ACTUAL_CURRENT_FROZEN_RELEASE_ZERO_TO_THREE_PUBLIC_PROMPT_GENERATED_NO_SQL_OR_NATIVE_EXECUTION_CLAIM",actualRuleInputs=initial.RuleInputs,
 source="SPELL",cardNo="SFD·080/221",minimum=0,maximum=3,
 legalTargetSelections=requirement["legalTargetSelections"],
 exactOriginalControlledInitialRetained=true,realSqlNativeVisibleWindowsOrWholePrintingCertification=false
},json));
Console.WriteLine("ACTUAL_CURRENT_PUBLIC_PROMPT_MIN0_MAX3");
