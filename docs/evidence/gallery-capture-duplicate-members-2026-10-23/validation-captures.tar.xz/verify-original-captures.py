from datetime import datetime, timezone
from pathlib import Path
import ast
import gzip
import hashlib
import importlib.util
import json
import subprocess
import tarfile
import tempfile
import types

WT = Path('/Users/dinghaolin/MyProjects/.worktrees/riftbound-parallel-official-audit-20261023')
Q = Path(__file__).resolve().parent
BASE = WT/'docs/evidence/en-gallery-gap-parallel-2026-10-23'
BASE_COMMIT = 'f0f4efc54f53af3e0b9043473af365392a243a82'
sha = lambda b: hashlib.sha256(b).hexdigest()
canonical = lambda v: json.dumps(v, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode()
spec=importlib.util.spec_from_file_location('fixed_gap',WT/'scripts/audit/gallery_gap_diagnostics.py')
fixed=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixed)
before_source=subprocess.check_output(['git','show',BASE_COMMIT+':scripts/audit/gallery_gap_diagnostics.py'],cwd=WT)
old=types.ModuleType('old_gap');exec(compile(before_source,'old_gap','exec'),old.__dict__)
after_source=(WT/'scripts/audit/gallery_gap_diagnostics.py').read_bytes()

def functions(source):
    text=source.decode()
    return {n.name:ast.get_source_segment(text,n) for n in ast.parse(text).body if isinstance(n,ast.FunctionDef)}
before_functions,after_functions=functions(before_source),functions(after_source)
assert before_functions.keys()==after_functions.keys()
assert [k for k in before_functions if before_functions[k]!=after_functions[k]]==['read_capture']
test_name='scripts/tests/test_gallery_gap_diagnostics.py'
assert subprocess.check_output(['git','show',BASE_COMMIT+':'+test_name],cwd=WT)==(WT/test_name).read_bytes()

archives=[];verified=[];parsed={};historical=[]
with tempfile.TemporaryDirectory() as temporary:
    temp=Path(temporary)
    for folder in (BASE,BASE/'v2'):
        index=json.loads((folder/'archive-index.json').read_text())
        archive=folder/'original-captures.tar.xz'
        assert sha(archive.read_bytes())==index['archiveSha256']
        entries={m.get('archiveMember',m.get('path')):m for m in index['members']}
        prefix='v2/' if folder.name=='v2' else 'v1/'
        archives.append(dict(path=str(archive.relative_to(WT)),sha256=sha(archive.read_bytes()),members=len(entries)))
        with tarfile.open(archive) as t:
            assert set(t.getnames())==set(entries)
            for name,entry in entries.items():
                raw=t.extractfile(name).read()
                assert sha(raw)==entry['sha256'] and len(raw)==entry['bytes']
                if name.endswith('.json.gz') or name=='whole-list.gz':
                    path=temp/name;path.write_bytes(raw)
                    original,old_ref=old.read_capture(path);current,new_ref=fixed.read_capture(path)
                    assert canonical(original)==canonical(current) and old_ref==new_ref
                    assert path.read_bytes()==raw
                    fixed.inspect_window(current)
                    parsed[prefix+name]=current
                    verified.append(dict(member=prefix+name,archiveSha256=sha(raw),rawSha256=new_ref['rawSha256'],
                        offset=current['metadata']['from'],limit=current['metadata']['limit'],rows=len(current['data'])))
                elif name=='historical-six-exact-responses.jsonl.gz':
                    for i,line in enumerate(gzip.decompress(raw).decode().splitlines()):
                        record=json.loads(line);payload=record['originalUtf8'].encode()
                        assert len(payload)==record['rawBytes'] and sha(payload)==record['rawSha256']
                        path=temp/f'historical-{i}.json';path.write_bytes(payload)
                        current,_=fixed.read_capture(path);original,_=old.read_capture(path)
                        assert canonical(current)==canonical(original)
                        historical.append(current)
                elif name=='cli-captured-window-result.json':
                    cli=json.loads(raw)

parent_name=Path(cli['capturedInputs']['parent']['path']).name
children_names=[Path(c['path']).name for c in cli['capturedInputs']['children']]
result=fixed.diagnose_partition(parsed['v1/'+parent_name],[parsed['v1/'+n] for n in children_names])
assert canonical(result)==canonical({k:v for k,v in cli.items()if k!='capturedInputs'})
historical_reports=[]
for start in (300,400):
    parent=next(x for x in historical if x['metadata']['from']==start and x['metadata']['limit']==100)
    children=[next(x for x in historical if x['metadata']['from']==offset and x['metadata']['limit']==50) for offset in (start,start+50)]
    report=fixed.diagnose_partition(parent,children)
    assert canonical(report)==canonical(old.diagnose_partition(parent,children))
    assert not report['supportsStableWindowObservation']
    assert report['sourceGapClosed'] is False and report['missingPrintingIdentities'] is None
    historical_reports.append(report)
empty_positions=sorted({x['offset'] for x in verified if x['member'].startswith('v2/') and x['limit']==1 and x['rows']==0})
assert empty_positions==[360,477,745,746,1038,1087,1228,1332]

counterexamples=json.loads((Q/'before-reproduction.json').read_text())
for case in counterexamples:
    path=Q/(case['name']+'.json');before=path.read_bytes()
    try:fixed.read_capture(path)
    except ValueError as error:case['currentRejection']=str(error)
    else:raise AssertionError('Ambiguous source accepted')
    assert path.read_bytes()==before

report=dict(schemaVersion=1,recordedAtUtc=datetime.now(timezone.utc).isoformat(),baseCommit=BASE_COMMIT,
    scope='Strict duplicate-object-member rejection at offline gallery capture read boundary only',
    beforeToolSha256=sha(before_source),afterToolSha256=sha(after_source),
    unchangedFunctions=[k for k in before_functions if k!='read_capture'],
    originalTenDiagnosticTestFile=dict(path=test_name,sha256=sha((WT/test_name).read_bytes())),
    syntheticCounterexamples=counterexamples,originalArchives=archives,verifiedApiCaptureCount=len(verified),verifiedApiCaptures=verified,
    originalHistoricalHttpResponsesRead=6,historicalMismatchReportsUnchanged=historical_reports,
    previousBoundedCliReportUnchanged=True,eightEmptySinglePositionsUnchanged=empty_positions,
    originalByteHashesAndParsedFieldsExact=True,officialDuplicateKeysActuallyObserved=False,
    sourceGapClosed=False,semanticCoverageCertified=False,original17DrawingsGatesUnchanged=True,
    networkRefetch=False,gameCheckOrFullRun=False)
(Q/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('PASS:',len(verified),'original API captures plus6 historical responses;2 historical mismatch reports and8 empty positions unchanged;onlyread_capture changed;original10 diagnostic tests byte-exact')
