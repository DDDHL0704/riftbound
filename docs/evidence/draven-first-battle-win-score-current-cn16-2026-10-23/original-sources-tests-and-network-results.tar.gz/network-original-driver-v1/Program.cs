using System.Collections.Concurrent;
using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Nodes;
using Microsoft.AspNetCore.SignalR.Client;
using Microsoft.Extensions.DependencyInjection;
using Npgsql;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

Check(args.Length == 3 && args[0] is "prepare" or "resume", "Explicit phase and fresh output/private paths required.");
var phase = args[0]; var output = Path.GetFullPath(args[1]); var secrets = Path.GetFullPath(args[2]);
Directory.CreateDirectory(output); Directory.CreateDirectory(secrets);
using var limit = new CancellationTokenSource(TimeSpan.FromMinutes(12)); var ct = limit.Token;
var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
await using var source = NpgsqlDataSource.Create(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound")! + ";Options=-c default_transaction_read_only=on");
var store = new PostgresMatchRecoveryStore(source);
using var http = new HttpClient();
var health = JsonNode.Parse(await http.GetStringAsync("http://127.0.0.1:15847/health", ct))!;
Check(health["environment"]!.GetValue<string>() == "Production" && health["persistenceMode"]!.GetValue<string>() == "postgres", "Dedicated real SQL Production API with explicitly enabled finite QA positions.");
var receipts = new List<object>();
foreach (var branch in new[] { "draven-return", "draven-alt-return", "draven-winning-return", "draven-alt-winning-return" })
{
    var folder = Path.Combine(output, branch); Directory.CreateDirectory(folder);
    var privatePath = Path.Combine(secrets, branch + ".json");
    JsonObject config;
    if (phase == "prepare")
    {
        Check(!File.Exists(privatePath), "Never replace original private room identity.");
        var suffix = Guid.NewGuid().ToString("N")[..12];
        config = new JsonObject { ["room"] = "N53-NET-" + suffix, ["a"] = Profile("n53a" + suffix), ["b"] = Profile("n53b" + suffix) };
        PrivateSave();
    }
    else config = JsonNode.Parse(File.ReadAllText(privatePath))!.AsObject();
    var room = config["room"]!.GetValue<string>();
    using var trace = new StreamWriter(new GZipStream(new FileStream(Path.Combine(folder, phase + "-original-wire.ndjson.gz"), FileMode.CreateNew), CompressionLevel.SmallestSize));
    await using var a = new Side(config["a"]!.AsObject(), room, trace, source, PrivateSave);
    await using var b = new Side(config["b"]!.AsObject(), room, trace, source, PrivateSave);
    var sides = new[] { a, b }; MatchRecoveryFrame frame = null!; var checkpoints = 0;
    foreach (var s in sides) await s.Connect(phase == "resume", ct);
    await Until(() => sides.All(s => s.Snapshot.GetProperty("players").EnumerateObject().Count() == 2));
    await Checkpoint("connected");
    var winning = branch.Contains("winning"); var alternate = branch.Contains("alt");
    if (phase == "prepare")
    {
        Check(frame.Commands.Count == 2 && frame.ReplayInitialState is { Tick: 0, Status: "EMPTY", Seats.Count: 0 }, "Both real seat commands start from EMPTY.");
        var before = frame.CurrentTick;
        var scenario = "battle-result-draven" + (alternate ? "-alt" : "") + (winning ? "-winning" : "");
        await a.Hub.InvokeAsync("SeedScenario", room, a.Actor, scenario, "original-finite-seed", ct);
        await Until(() => sides.All(s => s.Snapshot.GetProperty("tick").GetInt64() > before));
        await Checkpoint("seed");
        await Act(a.Actor, new MoveUnitCommand("SOURCE", "BASE", "BATTLEFIELD:FIELD", []), true);
        for (var i = 0; frame.AuthoritativeState!.FocusPlayerId is not null; i++)
        { Check(i < 4, "Bounded real movement focus."); await Act(frame.AuthoritativeState.FocusPlayerId, new PassFocusCommand()); }
        await Act(a.Actor, new DeclareBattleCommand("FIELD", ["SOURCE"], ["DEFENDER"], ["COMBAT_ASSIGNMENT"]));
        var earned = frame.AuthoritativeState!.StackItems.Single().DravenBattleWinScore!;
        Check(earned is not null && frame.AuthoritativeState.PendingBattleResult is { Stage: "RESULT_TRIGGERS" }
            && frame.AuthoritativeState.CardObjects["FIELD"].ControllerId == b.Actor, "Captured score before control has a real network response window.");
        await Act(a.Actor, new PlayCardCommand("RETURN", "OGN·104/298", ["SOURCE"]));
        var top = frame.AuthoritativeState!.StackItems.Last().StackItemId;
        for (var i = 0; frame.AuthoritativeState.StackItems.Any(s => s.StackItemId == top); i++)
        { Check(i < 4, "Bounded original return response."); await Act(frame.AuthoritativeState.PriorityPlayerId!, new PassPriorityCommand()); }
        var state = frame.AuthoritativeState;
        Check(state.PlayerZones[a.Actor].Hand.Contains("SOURCE") && state.StackItems.Single().DravenBattleWinScore == earned
            && state.CardObjects["SOURCE"].ObjectGeneration > earned!.Source.Generation
            && state.PlayerScores[a.Actor] == (winning ? 7 : 0), "Original earned skill survives the source becoming a new private incarnation.");
        CheckHidden();
        await Save("pre-restart-original-frame.json.gz", frame);
        await Save("pre-restart-original-network-views.json.gz", sides.ToDictionary(s => s.Actor, s => new { snapshot = s.Snapshot, prompt = s.Prompt }));
    }
    else
    {
        var original = await Read<MatchRecoveryFrame>("pre-restart-original-frame.json.gz");
        Check(MatchStateHasher.HashValue(frame) == MatchStateHasher.HashValue(original), "Actual process restart and both token rotations preserve original complete recovery frame.");
        var views = await Read<JsonElement>("pre-restart-original-network-views.json.gz");
        foreach (var s in sides)
        {
            Equal(views.GetProperty(s.Actor).GetProperty("snapshot"), s.Snapshot, "Original network private snapshot after real API restart.");
            Equal(views.GetProperty(s.Actor).GetProperty("prompt"), s.Prompt, "Original network prompt after real API restart.");
        }
        CheckHidden();
        for (var i = 0; frame.AuthoritativeState!.Status == MatchStatuses.InProgress && frame.AuthoritativeState.PriorityPlayerId is not null; i++)
        { Check(i < 4, "Bounded retained score continuation."); await Act(frame.AuthoritativeState.PriorityPlayerId, new PassPriorityCommand()); }
        var state = frame.AuthoritativeState!; var events = frame.Events.Select(e => e.Event).ToArray();
        Check(state.PlayerScores[a.Actor] == (winning ? 8 : 1) && state.WinnerPlayerId == (winning ? a.Actor : null)
            && events.Count(e => e.Kind == "SCORE_GAINED" && Equals(e.Payload.GetValueOrDefault("reason")?.ToString(), "CAPTURED_DRAVEN_FIRST_BATTLE_WIN_SCORE")) == 1
            && !events.Any(e => e.Kind is "BATTLEFIELD_CONQUERED" or "CARD_DRAWN"), "One original score, no draw or conquest after source departure.");
        Check(winning ? state.PendingBattleResult is not null && state.CardObjects["FIELD"].ControllerId == b.Actor && !events.Any(e => e.Kind == "BATTLE_CLOSED")
            : state.PendingBattleResult is null && events.Count(e => e.Kind == "BATTLE_CLOSED") == 1, "Normal winning parent or nonwinning close follows the retained score.");
        Check(frame.OpeningSeed == original.OpeningSeed && frame.Commands.Take(original.Commands.Count).Select(MatchStateHasher.HashValue).SequenceEqual(original.Commands.Select(MatchStateHasher.HashValue))
            && frame.Events.Take(original.Events.Count).Select(MatchStateHasher.HashValue).SequenceEqual(original.Events.Select(MatchStateHasher.HashValue)), "No original action, event or opening seed rewritten.");
        await Save("post-restart-original-final-frame.json.gz", frame);
    }
    foreach (var s in sides) await s.Drain();
    var receipt = new { status = "PASS_SCOPED_REAL_SIGNALR_" + phase.ToUpperInvariant(), room, branch, phase, originalCommands = frame.Commands.Count,
        originalEvents = frame.Events.Count, checkpoints, persistedBeforeObservedWireMessages = sides.Sum(s => s.PersistedMessages),
        actualRuleInputs = RuleInputIdentity.Current, controlledPositionNotOrdinaryOpening = true, realProcessRestart = phase == "resume", originalPrivateSeed = frame.OpeningSeed,
        wholeCardCertification = false, visibleDesktopOrHardwareAcceptance = false };
    await File.WriteAllTextAsync(Path.Combine(folder, phase + "-receipt.json"), JsonSerializer.Serialize(receipt, json), ct); receipts.Add(receipt);
    Console.WriteLine(JsonSerializer.Serialize(receipt));

    void PrivateSave()
    {
        File.WriteAllText(privatePath, config.ToJsonString(json));
        if (!OperatingSystem.IsWindows()) File.SetUnixFileMode(privatePath, UnixFileMode.UserRead | UnixFileMode.UserWrite);
    }
    async Task Until(Func<bool> condition)
    { while (!condition()) { foreach (var s in sides) s.CheckErrors(); await Task.Delay(20, ct); } foreach (var s in sides) s.CheckErrors(); }
    async Task Checkpoint(string label)
    {
        frame = (await store.LoadAsync(room, ct))!;
        Check(frame.IsConsistent && frame.AuthoritativeState!.RuleInputs == RuleInputIdentity.Current, "Actual network SQL loaded inputs: " + string.Join(";", frame.ValidationErrors));
        await Until(() => sides.All(s => s.Snapshot.GetProperty("tick").GetInt64() == frame.CurrentTick && s.Prompt.GetProperty("snapshotTick").GetInt64() == frame.CurrentTick));
        Check((await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame, new CoreRuleEngine(), ct)).Count == 0, "Entire original real SQL prefix replays.");
        foreach (var s in sides)
        {
            Equal(JsonSerializer.SerializeToElement(frame.PlayerViews[s.Actor].Snapshot, json), s.Snapshot, "Observed snapshot equals stored original private view.");
            Equal(JsonSerializer.SerializeToElement(frame.PlayerViews[s.Actor].Prompt, json), s.Prompt, "Observed prompt equals stored original private view.");
            await s.Drain();
        }
        await Save(phase + "-checkpoint-" + (++checkpoints).ToString("D2") + "-" + label + ".json.gz", frame);
    }
    async Task Act(string actor, GameCommand command, bool duplicate = false)
    {
        var side = sides.Single(s => s.Actor == actor);
        var raw = JsonSerializer.SerializeToNode(command, command.GetType(), json)!.AsObject(); raw["promptId"] = side.Prompt.GetProperty("promptId").GetString(); raw["snapshotTick"] = frame.CurrentTick;
        var intent = phase + "-original-" + frame.Commands.Count; var element = JsonSerializer.SerializeToElement(raw, json);
        var receipt = await side.Hub.InvokeAsync<CommandReceiptDto>("SubmitIntent", room, actor, intent, element, ct);
        lock (trace) { trace.WriteLine(JsonSerializer.Serialize(new { actor, kind = "OriginalIntent", intent, command = element, receipt })); trace.Flush(); }
        Check(receipt.Accepted, "Real original intent refused: " + receipt.ErrorCode + " " + receipt.Message);
        await Checkpoint(command.CmdType);
        if (duplicate)
        {
            var original = MatchStateHasher.HashValue(frame);
            var again = await side.Hub.InvokeAsync<CommandReceiptDto>("SubmitIntent", room, actor, intent, element, ct);
            Check(again.Accepted && again.ServerTick == receipt.ServerTick && MatchStateHasher.HashValue((await store.LoadAsync(room, ct))!) == original, "Actual duplicate network intent writes no second input/state/event.");
        }
    }
    void CheckHidden()
    {
        var stack = b.Snapshot.GetProperty("stack").EnumerateArray().Single();
        Check(stack.GetProperty("sourceObjectId").GetString() == "HIDDEN" && stack.GetProperty("cardNo").GetString() == (alternate ? "SFD·148a/221" : "SFD·148/221"), "Opponent sees original public skill printing but never new private source identity.");
    }
    async Task Save(string name, object value)
    { await using var f = new FileStream(Path.Combine(folder, name), FileMode.CreateNew); await using var z = new GZipStream(f, CompressionLevel.SmallestSize); await JsonSerializer.SerializeAsync(z, value, value.GetType(), json, ct); }
    async Task<T> Read<T>(string name)
    { await using var f = File.OpenRead(Path.Combine(folder, name)); await using var z = new GZipStream(f, CompressionMode.Decompress); return (await JsonSerializer.DeserializeAsync<T>(z, json, ct))!; }
}
await File.WriteAllTextAsync(Path.Combine(output, phase + "-receipts.json"), JsonSerializer.Serialize(receipts, json), ct);
static JsonObject Profile(string actor) => new() { ["handle"] = actor, ["playerKey"] = Guid.NewGuid().ToString("N") + Guid.NewGuid().ToString("N") };
static void Check(bool ok, string why) { if (!ok) throw new Exception(why); }
static void Equal(JsonElement a, JsonElement b, string why) => Check(JsonNode.DeepEquals(JsonNode.Parse(a.GetRawText()), JsonNode.Parse(b.GetRawText())), why);

sealed class Side : IAsyncDisposable
{
    readonly ConcurrentQueue<string> errors = new(); readonly ConcurrentQueue<Task> checks = new(); readonly object gate = new();
    readonly JsonObject profile; readonly string room; readonly StreamWriter trace; readonly NpgsqlDataSource source; readonly Action save;
    JsonElement snapshot, prompt; bool joined; int persisted;
    public string Actor => profile["handle"]!.GetValue<string>();
    public HubConnection Hub { get; }
    public JsonElement Snapshot { get { lock (gate) return snapshot; } }
    public JsonElement Prompt { get { lock (gate) return prompt; } }
    public int PersistedMessages => persisted;
    public Side(JsonObject profile, string room, StreamWriter trace, NpgsqlDataSource source, Action save)
    {
        this.profile = profile; this.room = room; this.trace = trace; this.source = source; this.save = save;
        Hub = new HubConnectionBuilder().WithUrl("http://127.0.0.1:15847/hubs/game").AddJsonProtocol(o => o.PayloadSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase).Build();
        foreach (var kind in new[] { "Joined", "Snapshot", "Prompt", "Events", "Error" }) Hub.On<WsServerMessage>(kind, m => Receive(kind, m));
    }
    void Receive(string kind, WsServerMessage message)
    {
        if (message.Payload is not JsonElement payload) return;
        lock (gate)
        {
            if (kind == "Joined") { profile["reconnectToken"] = payload.GetProperty("reconnectToken").GetString(); save(); joined = true; return; }
            if (kind == "Snapshot") snapshot = payload.Clone();
            if (kind == "Prompt") prompt = payload.Clone();
            if (kind == "Error") errors.Enqueue(payload.GetRawText());
            lock (trace) { trace.WriteLine(JsonSerializer.Serialize(new { actor = Actor, kind, payload })); trace.Flush(); }
            if (kind is "Snapshot" or "Prompt") checks.Enqueue(Persisted(kind, payload.Clone()));
        }
    }
    async Task Persisted(string kind, JsonElement payload)
    {
        var snapshot = kind == "Snapshot"; var table = snapshot ? "snapshots" : "action_prompts"; var column = snapshot ? "snapshot_tick" : "prompt_tick";
        await using var connection = await source.OpenConnectionAsync();
        await using var command = new NpgsqlCommand($"select payload::text from {table} where match_id=@room and player_id=@actor and {column}=@tick", connection);
        command.Parameters.AddWithValue("room", room); command.Parameters.AddWithValue("actor", Actor);
        command.Parameters.AddWithValue("tick", payload.GetProperty(snapshot ? "tick" : "snapshotTick").GetInt64());
        var stored = await command.ExecuteScalarAsync() as string;
        if (stored is null || !JsonNode.DeepEquals(JsonNode.Parse(stored), JsonNode.Parse(payload.GetRawText()))) throw new Exception("Observed original private wire message must already exist exactly in SQL.");
        Interlocked.Increment(ref persisted);
    }
    public async Task Connect(bool reconnect, CancellationToken ct)
    {
        await Hub.StartAsync(ct);
        var auth = await Hub.InvokeAsync<AuthResultDto>("Authenticate", Actor, profile["playerKey"]!.GetValue<string>(), ct);
        if (!auth.Authenticated) throw new Exception("Own authenticated identity rejected: " + auth.Status);
        var previous = profile["reconnectToken"]?.GetValue<string>();
        if (reconnect) await Hub.InvokeAsync("Reconnect", room, Actor, previous!, ct);
        else await Hub.InvokeAsync("JoinRoom", room, Actor, (string?)null, ct);
        while (!joined || Snapshot.ValueKind != JsonValueKind.Object || Prompt.ValueKind != JsonValueKind.Object) { CheckErrors(); await Task.Delay(20, ct); }
        if (reconnect && previous == profile["reconnectToken"]?.GetValue<string>()) throw new Exception("Original reconnect token must rotate.");
    }
    public void CheckErrors() { if (errors.TryPeek(out var error)) throw new Exception("Actual original network error: " + error); }
    public async Task Drain() { await Task.WhenAll(checks.ToArray()); CheckErrors(); }
    public ValueTask DisposeAsync() => Hub.DisposeAsync();
}
