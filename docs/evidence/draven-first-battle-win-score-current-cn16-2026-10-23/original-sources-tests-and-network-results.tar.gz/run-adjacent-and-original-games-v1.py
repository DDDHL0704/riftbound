from pathlib import Path
import datetime,gzip,hashlib,json,os,subprocess
r=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
out=w/'adjacent-and-twelve-original-games-v1';terminal=w/'adjacent-and-twelve-original-games-owner-terminal-v1.json';assert not out.exists() and not terminal.exists()
def inputs():
 paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z','--','src','tests','data','scripts','Directory.Build.props','Directory.Build.targets','global.json','NuGet.Config'],cwd=r).split(b'\0')
 return {p.decode():{'sha256':hashlib.sha256((r/p.decode()).read_bytes()).hexdigest(),'mode':oct((r/p.decode()).stat().st_mode & 0o777)} for p in paths if p and (r/p.decode()).is_file()}
original=inputs();classes=[]
for p in (r/'tests/Riftbound.ConformanceTests').glob('*.cs'):
 if any(x in p.stem for x in ['Battle','Conquest','Combat','Burnout','TriggerOrder','DravenKeywordUnitGuard','LegendActionSourceIdentity']) and ('[Fact]' in p.read_text() or '[Theory]' in p.read_text()): classes.append('Riftbound.ConformanceTests.'+p.stem+'.')
old=json.loads((r/'var/qa/burnout-inner-cleanup-and-garen-current-cn16-20261023/final-shared-cleanup-and-nine-original-games-focus-v5/plan.json').read_text())
games={n for s in old['shards'] for n in s['methods'] if '.FullGameEndToEndTests.' in n}
games.update(json.loads((r/'docs/evidence/battle-win-combined-parallel-2026-10-23/source-and-test-manifest.json').read_text())['originalFullGameMethods']);assert len(games)==12
matches=sorted(set(classes)|games|{'P79LegendTriggerGarenDrawsTwoOnConquerWithFourBattlefieldUnits'})
args=['python3','scripts/test-rules.py','focus','--include-games','--output',str(out)]
for m in matches:args+=['--match',m]
proof=dict(status='RUNNING',startedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),sourceInputs=original,command=args,originalFullGames=sorted(games),unrelatedClientChangesNotPartOfInput=True)
(w/'adjacent-and-twelve-original-games-start-v1.json.gz').write_bytes(gzip.compress(json.dumps(proof,ensure_ascii=False).encode(),mtime=0))
env=dict(os.environ)
for key,name in [('RIFTBOUND_DRAVEN_ORDER_EVIDENCE','draven'),('RIFTBOUND_UNIT_BATTLE_WIN_EVIDENCE','unit'),('RIFTBOUND_KHAZIX_BATTLE_WIN_EVIDENCE','khazix'),('RIFTBOUND_COMBINED_WIN_EVIDENCE','combined'),('RIFTBOUND_BATTLE_RESULT_RECOVERY_EVIDENCE','recovery'),('RIFTBOUND_LATE_BATTLE_PARTICIPANT_EVIDENCE','late'),('RIFTBOUND_DRAVEN_BATTLE_SCORE_EVIDENCE','score'),('RIFTBOUND_DRAVEN_INTERACTION_EVIDENCE','interaction'),('RIFTBOUND_DRAVEN_SCORE_RECOVERY_EVIDENCE','score-recovery'),('RIFTBOUND_DRAVEN_MULTI_SOURCE_EVIDENCE','multi-source')]:env[key]=str(w/('final-original-'+name+'-v2'))
try:
 with (w/'adjacent-and-twelve-original-games-console-v1.log').open('xb')as log:run=subprocess.run(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 proof['exitCode']=run.returncode;proof['status']='PASS' if run.returncode==0 else 'FAILED_ORIGINAL_RETAINED'
 if (out/'summary.json').exists():proof['summary']=json.loads((out/'summary.json').read_text())
finally:
 proof['sourceInputsStable']=inputs()==original;proof['finishedAtUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat();proof.pop('sourceInputs')
 terminal.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print(proof['status'],flush=True)
raise SystemExit(proof.get('exitCode',1))
