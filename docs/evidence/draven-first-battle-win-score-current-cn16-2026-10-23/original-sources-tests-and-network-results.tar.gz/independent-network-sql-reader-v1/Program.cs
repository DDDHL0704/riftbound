using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.CardCatalog;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
var modules = new[] { typeof(CoreRuleEngine).Assembly, typeof(GameCommand).Assembly, typeof(OfficialCardCatalog).Assembly, typeof(PostgresMatchRecoveryStore).Assembly };
var loaded = new { baseDirectory = AppContext.BaseDirectory, actualRuleInputs = RuleInputIdentity.Current,
    assemblies = modules.Select(a => new { name = a.GetName().Name, path = a.Location, mvid = a.ManifestModule.ModuleVersionId,
        sha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(a.Location))).ToLowerInvariant() }).ToArray() };
if (args is ["--loaded-inputs"]) { Console.WriteLine(JsonSerializer.Serialize(loaded, json)); return; }
Check(args.Length == 2 && !Directory.Exists(args[1]), "Completed original network evidence and fresh independent output required.");
var home = Path.GetFullPath(args[0]); var output = Path.GetFullPath(args[1]); Directory.CreateDirectory(output);
using var owner = JsonDocument.Parse(File.ReadAllText(Path.Combine(home, "real-signalr-four-draven-score-owner-terminal-v2.json")));
var top = owner.RootElement;
Check(top.GetProperty("status").GetString() == "PASS_FOUR_ORIGINAL_REAL_SIGNALR_ROOMS_ACTUAL_API_PROCESS_RESTART_RETAINED_PRIVATE_SOURCE_SCORE"
    && Same(top.GetProperty("actualLoadedFourAssemblies").GetProperty("actualRuleInputs"), JsonSerializer.SerializeToElement(RuleInputIdentity.Current, json)), "Actual completed API owner and actual loaded rule identity.");
var settings = new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
Check(settings.Host == "127.0.0.1" && settings.Port == 55486 && settings.Database == "riftbound_here_native" && settings.Username == "codex_riftbound_audit", "Only owned real network database.");
settings.Options = "-c default_transaction_read_only=on";
await using var source = NpgsqlDataSource.Create(settings.ConnectionString);
await using var connection = await source.OpenConnectionAsync();
Check((string)(await new NpgsqlCommand("show transaction_read_only", connection).ExecuteScalarAsync())! == "on", "Actually read-only connection.");
var counts = new Dictionary<string, int> { ["commands"] = 0, ["events"] = 0, ["authority"] = 0, ["snapshots"] = 0, ["prompts"] = 0, ["prefixReplays"] = 0, ["originalWireIntents"] = 0 };
var outcomes = new List<object>(); var seen = new HashSet<string>();
foreach (var receipt in top.GetProperty("resumeReceipts").EnumerateArray())
{
    var branch = receipt.GetProperty("branch").GetString()!; var room = receipt.GetProperty("room").GetString()!;
    Check(seen.Add(branch), "One of each original network branch.");
    var folder = Path.Combine(home, "real-signalr-four-draven-score-original-rooms-v2", branch);
    using var saved = Read(Path.Combine(folder, "post-restart-original-final-frame.json.gz"));
    using var before = Read(Path.Combine(folder, "pre-restart-original-frame.json.gz"));
    var frame = (await new PostgresMatchRecoveryStore(source).LoadAsync(room, default))!;
    Check(Same(JsonSerializer.SerializeToElement(frame, json), saved.RootElement) && frame.IsConsistent
        && frame.ReplayInitialState is { Tick: 0, Status: "EMPTY", Seats.Count: 0, CardObjects.Count: 0 }
        && frame.OpeningSeed != 0 && frame.Commands.All(c => c.Accepted && c.RuleInputs == RuleInputIdentity.Current), "Entire actual original frame, EMPTY opening, original seed and every input identity.");
    var a = frame.AuthoritativeState!.Seats.Single(p => p.Value == "P1").Key; var b = frame.AuthoritativeState.Seats.Single(p => p.Value == "P2").Key;
    var winning = branch.Contains("winning"); var alternate = branch.Contains("alt");
    var scenario = "battle-result-draven" + (alternate ? "-alt" : "") + (winning ? "-winning" : "");
    string[] expected = ["ROOM_SEAT", "ROOM_SEAT", "DEV_SEED_SCENARIO:" + scenario, "MOVE_UNIT", "PASS_FOCUS", "PASS_FOCUS", "DECLARE_BATTLE", "PLAY_CARD", "PASS_PRIORITY", "PASS_PRIORITY", "PASS_PRIORITY", "PASS_PRIORITY"];
    Check(frame.Commands.Select(c => c.CommandType).SequenceEqual(expected), "Independent twelve original input types in exact order.");
    for (var i = 0; i < 2; i++)
    {
        var command = frame.Commands[i]; var actor = i == 0 ? a : b; var seat = i == 0 ? "P1" : "P2"; var raw = command.RawCommand!.Value;
        Check(command.PlayerId == actor && command.ClientIntentId == "room-seat:" + seat && raw.EnumerateObject().Count() == 3
            && raw.GetProperty("cmdType").GetString() == "ROOM_SEAT" && raw.GetProperty("playerId").GetString() == actor && raw.GetProperty("seat").GetString() == seat, "Atomic literal seats with no credentials in original game raw schema.");
    }
    var original = before.RootElement.Deserialize<MatchRecoveryFrame>(json)!;
    Check(original.Commands.Count == 10 && original.OpeningSeed == frame.OpeningSeed
        && Same(JsonSerializer.SerializeToElement(frame.Commands.Take(10), json), before.RootElement.GetProperty("commands"))
        && Same(JsonSerializer.SerializeToElement(frame.Events.Take(original.Events.Count), json), before.RootElement.GetProperty("events")), "Exact original prefix survives actual process restart.");
    var tables = new Dictionary<string, JsonElement>();
    foreach (var table in new[] { "matches", "match_players", "command_log", "game_events", "state_snapshots", "snapshots", "action_prompts" })
    {
        await using var q = new NpgsqlCommand($"select coalesce(json_agg(t order by row_to_json(t)::text),'[]'::json)::text from (select * from {table} where match_id=@room)t", connection);
        q.Parameters.AddWithValue("room", room); using var value = JsonDocument.Parse((string)(await q.ExecuteScalarAsync())!); tables[table] = value.RootElement.Clone();
    }
    await Save(branch + "-independent-original-seven-tables.json.gz", tables);
    var states = new Dictionary<(long Tick, long Seq), MatchState>();
    foreach (var row in tables["state_snapshots"].EnumerateArray())
    {
        var payload = row.GetProperty("payload"); var state = payload.Deserialize<MatchState>(json)!;
        Check(Same(payload, JsonSerializer.SerializeToElement(state, json)) && state.RuleInputs == RuleInputIdentity.Current
            && states.TryAdd((state.Tick, row.GetProperty("last_event_sequence").GetInt64()), state), "Every exact complete authority payload and unique history key.");
    }
    Check(states.Count == 12, "Twelve actual independently stored authority checkpoints.");
    foreach (var (command, i) in frame.Commands.Select((c, i) => (c, i)))
    {
        var state = states[(command.CompletedTick, command.CompletedEventSequence)];
        var events = frame.Events.Where(e => e.Sequence <= command.CompletedEventSequence).ToArray();
        var replay = await MatchActionLogReplayer.VerifyFinalStateAsync(frame.ReplayInitialState!, frame.Commands.Take(i + 1).ToArray(), state, new CoreRuleEngine(), default, events);
        Check(replay.IsMatch, "Every entire original network prefix, including first and second seat, replays: " + string.Join(";", replay.Errors)); counts["prefixReplays"]++;
        if (i >= 3) Check(command.RawCommand!.Value.GetProperty("snapshotTick").GetInt64() == command.StartedTick, "Actual original intent retains its initial snapshot tick.");
    }
    foreach (var table in new[] { "snapshots", "action_prompts" }) foreach (var row in tables[table].EnumerateArray())
    {
        var actor = row.GetProperty("player_id").GetString()!; var payload = row.GetProperty("payload");
        var tick = row.GetProperty(table == "snapshots" ? "snapshot_tick" : "prompt_tick").GetInt64(); var seq = row.GetProperty("last_event_sequence").GetInt64(); var state = states[(tick, seq)];
        Check(state.Seats.ContainsKey(actor), "Only an actually seated historical viewer has a private row.");
        var typed = table == "snapshots" ? JsonSerializer.SerializeToElement(payload.Deserialize<SnapshotDto>(json), json) : JsonSerializer.SerializeToElement(payload.Deserialize<ActionPromptDto>(json), json);
        var projected = table == "snapshots" ? JsonSerializer.SerializeToElement(ResolutionResult.BuildSnapshots(state)[actor], json) : JsonSerializer.SerializeToElement(ResolutionResult.BuildPrompts(state)[actor], json);
        Check(Same(payload, typed) && Same(payload, projected), "Every original private field, null, omission and array order is retained and projects exactly.");
        Check(!payload.TryGetProperty("openingSeed", out _) && !payload.TryGetProperty("reconnectToken", out _) && !payload.TryGetProperty("playerKey", out _), "No seed or credential fields in game projections.");
        if (table == "snapshots" && actor == b && state.PlayerZones.TryGetValue(a, out var zones) && zones.Hand.Contains("SOURCE"))
            foreach (var skill in payload.GetProperty("stack").EnumerateArray())
                if (skill.GetProperty("effectKind").GetString() == "CAPTURED_DRAVEN_FIRST_BATTLE_WIN_SCORE")
                    Check(skill.GetProperty("sourceObjectId").GetString() == "HIDDEN" && skill.GetProperty("cardNo").GetString() == (alternate ? "SFD·148a/221" : "SFD·148/221"), "Original earned skill keeps public printing and hides its current private incarnation.");
    }
    var wireIntents = new List<JsonElement>();
    foreach (var phase in new[] { "prepare", "resume" })
    {
        using var zip = new GZipStream(File.OpenRead(Path.Combine(folder, phase + "-original-wire.ndjson.gz")), CompressionMode.Decompress); using var reader = new StreamReader(zip);
        while (await reader.ReadLineAsync() is { } line)
        {
            using var item = JsonDocument.Parse(line); var x = item.RootElement; var kind = x.GetProperty("kind").GetString();
            if (kind == "OriginalIntent") { wireIntents.Add(x.Clone()); continue; }
            if (kind is not ("Snapshot" or "Prompt")) continue;
            var actor = x.GetProperty("actor").GetString(); var payload = x.GetProperty("payload"); var snapshot = kind == "Snapshot";
            var tick = payload.GetProperty(snapshot ? "tick" : "snapshotTick").GetInt64();
            var row = tables[snapshot ? "snapshots" : "action_prompts"].EnumerateArray().Single(r => r.GetProperty("player_id").GetString() == actor && r.GetProperty(snapshot ? "snapshot_tick" : "prompt_tick").GetInt64() == tick);
            Check(Same(payload, row.GetProperty("payload")), "Every original observed wire snapshot/prompt exactly matches its stored row.");
        }
    }
    Check(wireIntents.Count == 9, "Nine actual original gameplay calls, beyond two seats and one original finite seed.");
    foreach (var x in wireIntents)
    {
        var c = frame.Commands.Single(c => c.ClientIntentId == x.GetProperty("intent").GetString() && c.PlayerId == x.GetProperty("actor").GetString());
        Check(Same(c.RawCommand!.Value, x.GetProperty("command")) && x.GetProperty("receipt").GetProperty("Accepted").GetBoolean(), "Complete original accepted wire intent equals actual SQL input.");
    }
    var captured = original.AuthoritativeState!.StackItems.Single().DravenBattleWinScore!;
    Check(captured.Source.ObjectId == "SOURCE" && captured.Source.Generation == 0 && captured.ControllerId == a && captured.TurnNumber == 5
        && original.AuthoritativeState.UntilEndOfTurnEffects.Contains("DRAVEN_FIRST_BATTLE_WIN:5:0:SOURCE")
        && original.AuthoritativeState.CardObjects["SOURCE"].ObjectGeneration == 1 && original.AuthoritativeState.PlayerZones[a].Hand.Contains("SOURCE")
        && original.AuthoritativeState.CardObjects["FIELD"].ControllerId == b && original.AuthoritativeState.PlayerScores[a] == (winning ? 7 : 0), "Independent original capture/marker/new-private-generation semantics before process restart.");
    var final = frame.AuthoritativeState; var actualEvents = frame.Events.Select(e => e.Event).ToArray();
    Check(final.PlayerScores[a] == (winning ? 8 : 1) && final.WinnerPlayerId == (winning ? a : null)
        && actualEvents.Count(e => e.Kind == "SCORE_GAINED" && e.Payload.GetValueOrDefault("reason")?.ToString() == "CAPTURED_DRAVEN_FIRST_BATTLE_WIN_SCORE") == 1
        && !actualEvents.Any(e => e.Kind is "BATTLEFIELD_CONQUERED" or "CARD_DRAWN"), "Exactly one skill score after restart, no conquest or draw.");
    Check(winning ? final.PendingBattleResult is not null && final.CardObjects["FIELD"].ControllerId == b && !actualEvents.Any(e => e.Kind == "BATTLE_CLOSED")
        : final.PendingBattleResult is null && actualEvents.Count(e => e.Kind == "BATTLE_CLOSED") == 1, "Normal terminal parent versus ordinary battle close.");
    counts["commands"] += frame.Commands.Count; counts["events"] += frame.Events.Count; counts["authority"] += states.Count;
    counts["snapshots"] += tables["snapshots"].GetArrayLength(); counts["prompts"] += tables["action_prompts"].GetArrayLength(); counts["originalWireIntents"] += wireIntents.Count;
    outcomes.Add(new { branch, room, commands = frame.Commands.Count, events = frame.Events.Count }); Console.WriteLine("INDEPENDENT_ORIGINAL_NETWORK_SQL_PASS " + branch);
}
Check(seen.SetEquals(["draven-return", "draven-alt-return", "draven-winning-return", "draven-alt-winning-return"]), "All four original branches retained.");
Check(counts["commands"] == 48 && counts["events"] == 130 && counts["authority"] == 48 && counts["snapshots"] == 92 && counts["prompts"] == 92 && counts["prefixReplays"] == 48 && counts["originalWireIntents"] == 36, "Independent complete original network counts.");
await File.WriteAllTextAsync(Path.Combine(output, "result.json"), JsonSerializer.Serialize(new { status = "PASS_FOUR_ORIGINAL_NETWORK_SQL_ALL48_PREFIXES", loaded, counts, outcomes, completeFieldNullOmissionAndArrayChecks = true, originalHistoriesNeverRewritten = true, wholeCardCertification = false }, json));
Console.WriteLine(JsonSerializer.Serialize(counts));
async Task Save(string name, object value) { await using var f = new FileStream(Path.Combine(output, name), FileMode.CreateNew); await using var z = new GZipStream(f, CompressionLevel.SmallestSize); await JsonSerializer.SerializeAsync(z, value, value.GetType(), json); }
static JsonDocument Read(string path) { using var zip = new GZipStream(File.OpenRead(path), CompressionMode.Decompress); return JsonDocument.Parse(zip); }
static bool Same(JsonElement a, JsonElement b) => JsonNode.DeepEquals(JsonNode.Parse(a.GetRawText()), JsonNode.Parse(b.GetRawText()));
static void Check(bool ok, string reason) { if (!ok) throw new InvalidOperationException(reason); }
