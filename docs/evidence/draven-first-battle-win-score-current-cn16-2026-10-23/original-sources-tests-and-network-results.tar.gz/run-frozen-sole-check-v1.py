from pathlib import Path
import datetime, gzip, hashlib, json, os, subprocess

w = Path(__file__).resolve().parent
start = json.loads(gzip.decompress((w / 'sole-check-frozen-candidate-start-v1.json.gz').read_bytes()))
root = Path(start['frozenRoot'])
output = w / 'frozen-sole-check-v1'
terminal = w / 'sole-check-frozen-owner-terminal-v1.json'
assert not output.exists() and not terminal.exists()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
proof = dict(startedAtUtc=now(), baseCommit=start['baseCommit'], frozenRoot=str(root), status='RUNNING')
env = dict(os.environ)
env.pop('ConnectionStrings__Riftbound', None)
args = ['python3', 'scripts/test-rules.py', 'check', '--output', str(output)]
proof['command'] = args
power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())])
proof['boundIdleAssertionPid'] = power.pid
try:
    with (w / 'sole-check-frozen-original-console-v1.log').open('xb') as log:
        run = subprocess.run(args, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    proof['exitCode'] = run.returncode
    if (output / 'summary.json').exists():
        proof['summary'] = json.loads((output / 'summary.json').read_text())
    proof['status'] = 'PASS' if run.returncode == 0 else 'FAIL_ORIGINAL_OUTPUT_RETAINED_NO_SECOND_CHECK'
finally:
    proof['allSourceInputsAndModesStable'] = all(
        (root / p).is_file() and sha(root / p) == v['sha256']
        and oct((root / p).stat().st_mode & 0o777) == v['mode']
        for p, v in start['sourceInputs'].items())
    if power.poll() is None:
        power.terminate()
        power.wait(timeout=10)
    proof['finishedAtUtc'] = now()
    proof['ownRuntimeHashes'] = {p.name: sha(p) for p in
        (root / 'tests/Riftbound.ConformanceTests/bin/Debug/net10.0').glob('Riftbound.*') if p.is_file()}
    terminal.write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps({k: v for k, v in proof.items() if k not in ['ownRuntimeHashes', 'summary']}), flush=True)
raise SystemExit(proof.get('exitCode', 1))
