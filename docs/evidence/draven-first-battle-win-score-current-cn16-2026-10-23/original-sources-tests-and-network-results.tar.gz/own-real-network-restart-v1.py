from pathlib import Path
import ast,datetime,fcntl,hashlib,json,os,plistlib,resource,socket,subprocess,time,urllib.request
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
functions=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
for node in ast.parse(functions.read_text()).body:
 if isinstance(node,ast.FunctionDef)and node.name in {'query','rooms','digests','observe_lock'}:exec(compile(ast.get_source_segment(functions.read_text(),node),str(functions),'exec'),globals())
runtime=w/'fixed-api-runtime-v1';driver=w/'fixed-network-driver-runtime-v1';output=w/'real-signalr-four-draven-score-original-rooms-v1';private=w/'private-network-auth-v1';terminal=w/'real-signalr-four-draven-score-owner-terminal-v1.json';assert not output.exists()and not terminal.exists()and not private.exists()
def hash_tree(path):return {str(p.relative_to(path)):sha(p)for p in path.rglob('*')if p.is_file()}
runtime_hashes=hash_tree(runtime);driver_hashes=hash_tree(driver)
for name in ['Riftbound.Engine','Riftbound.Contracts','Riftbound.CardCatalog','Riftbound.Persistence']:assert runtime_hashes[name+'.dll']==driver_hashes[name+'.dll']
def source_hashes():
 paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z','--','src/Riftbound.Engine','src/Riftbound.Contracts','src/Riftbound.CardCatalog','src/Riftbound.Persistence','src/Riftbound.Api','data'],cwd=root).split(b'\0')
 return {p.decode():sha(root/p.decode())for p in paths if p and(root/p.decode()).is_file()}
sources=source_hashes();own={str(p):sha(p)for p in [Path(__file__),functions,w/'network-original-driver-v1/Program.cs',w/'network-original-driver-v1/probe.csproj']}
def stable():
 assert source_hashes()==sources and hash_tree(runtime)==runtime_hashes and hash_tree(driver)==driver_hashes
 assert all(sha(Path(p))==h for p,h in own.items())
measurement_helper=root/'var/qa/fixed267ab-early-native-20261022/executed-own-native-readers-and-drivers-v1/IndependentFixed267abControlledLabV1.dll'
measure=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(runtime/'Riftbound.Api.deps.json'),'--runtimeconfig',str(runtime/'Riftbound.Api.runtimeconfig.json'),str(measurement_helper),'--loaded-inputs']
measured=json.loads(subprocess.check_output(measure,cwd=runtime,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0')))
assert Path(measured['baseDirectory'])==runtime and len(measured['assemblies'])==4
for a in measured['assemblies']:assert Path(a['path'])==runtime/(a['name']+'.dll')and a['sha256']==runtime_hashes[a['name']+'.dll']and a['mvid']
proof=dict(status='RUNNING_FOUR_FRESH_SIGNALR_SCORE_ROOMS_ACTUAL_API_PROCESS_RESTART',startedAtUtc=now(),baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),actualLoadedFourAssemblies=measured,runtimeInputHashes=runtime_hashes,driverInputHashes=driver_hashes,sourceInputHashes=sources,ownInputHashes=own,lockAtStart=observe_lock(),onlyFreshOwnedRoomsMayChange=True,ownedApiProcesses=[])
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a+');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB);started=False;power=None;api=None;before_audit=before_native=None
env=dict(os.environ,ASPNETCORE_ENVIRONMENT='Production',ASPNETCORE_URLS='http://127.0.0.1:15847',Riftbound__AllowDevSeedScenarios='true',ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit',DOTNET_DbgEnableMiniDump='0');env.pop('DOTNET_STARTUP_HOOKS',None)
def start_api(index):
 global api
 stable();log=w/f'own-n53-network-api-{index}-v1.log'
 with log.open('xb')as f:api=subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet',str(runtime/'Riftbound.Api.dll')],cwd=runtime,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 for i in range(150):
  assert api.poll()is None,'Owned API exited; original log retained'
  try:
   with urllib.request.urlopen('http://127.0.0.1:15847/health',timeout=1)as response:health=json.load(response)
   assert health['persistenceMode']=='postgres'and health['environment']=='Production'
   assert set(subprocess.check_output(['/usr/sbin/lsof','-tiTCP:15847','-sTCP:LISTEN'],text=True).splitlines())=={str(api.pid)}
   proof['ownedApiProcesses'].append(dict(pid=api.pid,index=index,startedAtUtc=now(),health=health,log=log.name));return
  except OSError:time.sleep(.1)
 raise AssertionError('Owned fixed API did not become ready')
try:
 stable();assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket()as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid;sock.mkdir(exist_ok=True)
 subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'own-n53-network-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 audit=rooms('riftbound_acceptance');native=rooms('riftbound_here_native');assert len(audit)==508 and len(native)==127
 before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',native)
 for index,phase in enumerate(['prepare','resume']):
  start_api(index)
  command=['/Users/dinghaolin/.dotnet/dotnet',str(driver/'N53OriginalSignalRRestartV1.dll'),phase,str(output),str(private)]
  with(w/f'real-signalr-four-score-{phase}-original-console-v1.log').open('xb')as log:r=subprocess.run(command,cwd=driver,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1000)
  proof[phase+'ExitCode']=r.returncode;assert r.returncode==0,'Original partial network rooms and logs retained; no silent retry'
  proof[phase+'Receipts']=load(output/(phase+'-receipts.json'))
  api.terminate();proof['ownedApiProcesses'][-1]['exitCode']=api.wait(timeout=30);assert api.returncode==0;api=None
  stable()
 new=set(rooms('riftbound_here_native'))-set(native);assert new=={r['room']for r in proof['prepareReceipts']}and len(new)==4
 assert all(r['actualRuleInputs']==measured['actualRuleInputs']for r in proof['prepareReceipts']+proof['resumeReceipts'])
 proof.update(status='PASS_FOUR_ORIGINAL_REAL_SIGNALR_ROOMS_ACTUAL_API_PROCESS_RESTART_RETAINED_PRIVATE_SOURCE_SCORE',newOriginalRooms=sorted(new),originalRoomRewrites=False,controlledPositionsNotOrdinaryOpening=True,visibleHardwareAcceptance=False)
except BaseException as error:proof.update(status='FAILED_ORIGINAL_NETWORK_PARTIAL_ROOMS_LOGS_INPUTS_RETAINED',errorType=type(error).__name__,error=str(error));raise
finally:
 if api is not None and api.poll()is None:api.terminate();proof['failedPhaseOwnedApiExitCode']=api.wait(timeout=30)
 if started:
  if before_audit is not None:proof.update(allOriginal508AuditSevenTablesExact=digests('riftbound_acceptance',audit)==before_audit,allOriginal127NativeSevenTablesExact=digests('riftbound_here_native',native)==before_native,actualAuditRoomsAtStop=rooms('riftbound_acceptance'),actualNativeRoomsAtStop=rooms('riftbound_here_native'))
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None and power.poll()is None:power.terminate();power.wait(timeout=10)
 stable();proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),allSourceRuntimeAndOwnInputsStable=True)
 with terminal.open('x')as f:json.dump(proof,f,ensure_ascii=False,indent=2)
 fcntl.flock(guard,fcntl.LOCK_UN)
assert all(proof[k]for k in ['allOriginal508AuditSevenTablesExact','allOriginal127NativeSevenTablesExact','ownPostgresSmartStopped','allSourceRuntimeAndOwnInputsStable']);print(proof['status'],flush=True)
