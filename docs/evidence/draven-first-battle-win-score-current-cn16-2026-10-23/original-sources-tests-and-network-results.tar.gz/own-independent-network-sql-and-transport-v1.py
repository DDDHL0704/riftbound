from pathlib import Path
import ast,datetime,fcntl,hashlib,json,os,plistlib,resource,socket,subprocess,time,urllib.request
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
functions=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
for node in ast.parse(functions.read_text()).body:
 if isinstance(node,ast.FunctionDef)and node.name in {'query','rooms','digests','observe_lock'}:exec(compile(ast.get_source_segment(functions.read_text(),node),str(functions),'exec'),globals())
previous=load(w/'real-signalr-four-draven-score-owner-terminal-v2.json');runtime=w/'fixed-api-runtime-v1';reader=w/'fixed-independent-network-reader-runtime-v1';smoke=w/'fixed-existing-network-smoke-runtime-v1';output=w/'independent-four-original-network-sql-v1';terminal=w/'independent-four-original-network-sql-and-transport-owner-terminal-v1.json';assert not terminal.exists()and not output.exists()
def hash_tree(path):return {str(p.relative_to(path)):sha(p)for p in path.rglob('*')if p.is_file()}
reader_hashes=hash_tree(reader);smoke_hashes=hash_tree(smoke)
for name in ['Riftbound.Engine','Riftbound.Contracts','Riftbound.CardCatalog','Riftbound.Persistence']:assert reader_hashes[name+'.dll']==previous['runtimeInputHashes'][name+'.dll']
own={str(p):sha(p)for p in [Path(__file__),functions,w/'independent-network-sql-reader-v1/Program.cs',w/'independent-network-sql-reader-v1/probe.csproj',root/'tests/Riftbound.NativeNetworkSmoke/Program.cs',root/'tests/Riftbound.NativeNetworkSmoke/Riftbound.NativeNetworkSmoke.csproj',root/'clients/godot/scripts/RiftboundGameHubClient.cs',root/'clients/godot/scripts/SnapshotCardRef.cs']}
def stable():
 assert hash_tree(runtime)==previous['runtimeInputHashes']and hash_tree(reader)==reader_hashes and hash_tree(smoke)==smoke_hashes
 assert all(sha(root/p)==h for p,h in previous['sourceInputHashes'].items())and all(sha(Path(p))==h for p,h in own.items())
proof=dict(status='RUNNING_INDEPENDENT_ORIGINAL_NETWORK_SQL_AND_EXISTING_TRANSPORT_GATE',startedAtUtc=now(),baseCommit=previous['baseCommit'],currentParentCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),actualRuleInputs=previous['actualLoadedFourAssemblies']['actualRuleInputs'],ownInputs=own,readerRuntimeHashes=reader_hashes,existingTransportRuntimeHashes=smoke_hashes,lockAtStart=observe_lock())
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a+');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB);started=False;power=None;api=None;before_audit=before_native=None
env=dict(os.environ,ASPNETCORE_ENVIRONMENT='Production',ASPNETCORE_URLS='http://127.0.0.1:15847',ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit',DOTNET_DbgEnableMiniDump='0',RIFTBOUND_SERVER_URL='http://127.0.0.1:15847');env.pop('DOTNET_STARTUP_HOOKS',None)
try:
 stable();assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket()as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid
 subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'independent-network-and-transport-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 audit=rooms('riftbound_acceptance');native=rooms('riftbound_here_native');assert audit==previous['actualAuditRoomsAtStop']and native==previous['actualNativeRoomsAtStop']and len(audit)==508 and len(native)==132
 before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',native)
 command=['/Users/dinghaolin/.dotnet/dotnet',str(reader/'IndependentN53OriginalNetworkSqlV1.dll'),str(w),str(output)];proof['readerCommand']=command
 with(w/'independent-network-sql-original-console-v1.log').open('xb')as log:r=subprocess.run(command,cwd=reader,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
 proof['readerExitCode']=r.returncode;assert r.returncode==0,'Original reader failure kept; no source or oracle weakening'
 result=load(output/'result.json');actual=result['loaded'];assert actual['actualRuleInputs']==proof['actualRuleInputs']and Path(actual['baseDirectory'])==reader
 for a in actual['assemblies']:assert Path(a['path'])==reader/(a['name']+'.dll')and a['sha256']==reader_hashes[a['name']+'.dll']and a['mvid']
 proof['independentOriginalCounts']=result['counts'];proof['resultSha256']=sha(output/'result.json')
 with(w/'own-existing-transport-api-v1.log').open('xb')as log:api=subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet',str(runtime/'Riftbound.Api.dll')],cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 for i in range(150):
  assert api.poll()is None
  try:
   with urllib.request.urlopen('http://127.0.0.1:15847/health',timeout=1)as response:health=json.load(response)
   assert health['persistenceMode']=='postgres'and health['environment']=='Production'
   assert set(subprocess.check_output(['/usr/sbin/lsof','-tiTCP:15847','-sTCP:LISTEN'],text=True).splitlines())=={str(api.pid)}
   proof['ownedApiProcess']=dict(pid=api.pid,health=health);break
  except OSError:time.sleep(.1)
 else:raise AssertionError('Own fixed API did not become ready')
 command=['/Users/dinghaolin/.dotnet/dotnet',str(smoke/'Riftbound.NativeNetworkSmoke.dll')];proof['transportCommand']=command
 with(w/'existing-native-network-smoke-original-console-v1.log').open('xb')as log:r=subprocess.run(command,cwd=smoke,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=100)
 proof['transportExitCode']=r.returncode;assert r.returncode==0,'Existing transport gate failure kept'
 api.terminate();proof['ownedApiProcess']['exitCode']=api.wait(timeout=30);assert api.returncode==0;api=None
 new=set(rooms('riftbound_here_native'))-set(native);assert len(new)==2 and all(x.startswith('NETWORK-')for x in new)
 proof.update(status='PASS_INDEPENDENT48_ORIGINAL_NETWORK_PREFIXES_AND_EXISTING_REAL_TRANSPORT_DROP_AUTH_RECOVERY_GATE',newOriginalTransportRooms=sorted(new),noOriginalInputHistoryRewritten=True,visibleHardwareAcceptance=False)
except BaseException as error:proof.update(status='FAILED_ORIGINAL_NETWORK_READER_OR_TRANSPORT_OUTPUT_RETAINED',errorType=type(error).__name__,error=str(error));raise
finally:
 if api is not None and api.poll()is None:api.terminate();proof['failedPhaseOwnedApiExitCode']=api.wait(timeout=30)
 if started:
  if before_audit is not None:proof.update(all508AuditSevenTablesExact=digests('riftbound_acceptance',audit)==before_audit,allOriginal132NativeSevenTablesExact=digests('riftbound_here_native',native)==before_native,actualAuditRoomsAtStop=rooms('riftbound_acceptance'),actualNativeRoomsAtStop=rooms('riftbound_here_native'))
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None and power.poll()is None:power.terminate();power.wait(timeout=10)
 stable();proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),allSourceRuntimeAndOwnInputsStable=True)
 with terminal.open('x')as f:json.dump(proof,f,ensure_ascii=False,indent=2)
 fcntl.flock(guard,fcntl.LOCK_UN)
assert all(proof[k]for k in ['all508AuditSevenTablesExact','allOriginal132NativeSevenTablesExact','ownPostgresSmartStopped','allSourceRuntimeAndOwnInputsStable']);print(proof['status'],flush=True)
