using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using NpgsqlTypes;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

internal static class DravenBattleWinScoreSqlAcceptance
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web) { WriteIndented = true };
    private static readonly string[] Tables = ["matches", "match_players", "command_log", "game_events", "state_snapshots", "snapshots", "action_prompts"];
    private const string Effect = "CAPTURED_DRAVEN_FIRST_BATTLE_WIN_SCORE";
    private static string Marker(DravenBattleWinScoreContext c) => $"DRAVEN_FIRST_BATTLE_WIN:{c.TurnNumber}:{c.Source.Generation}:{c.Source.ObjectId}";

    public static async Task RunAsync(NpgsqlDataSource source, string output)
    {
        Check(!Directory.Exists(output), "Fresh Draven score SQL evidence is required."); Directory.CreateDirectory(output);
        foreach (var branch in new[] { "draven-keep", "draven-return", "draven-winning", "draven-winning-return",
            "draven-alt-keep", "draven-alt-return", "draven-alt-winning", "draven-alt-winning-return",
            "forge-generation", "forge-printing", "forge-result-tick" }) await Run(branch);

        async Task Run(string branch)
        {
            var folder = Path.Combine(output, branch); Directory.CreateDirectory(folder);
            var room = "draven-first-battle-win-score-" + Guid.NewGuid().ToString("N");
            var journal = new OriginalJournal(new PostgresMatchJournal(source), folder);
            var players = new PostgresMatchPlayerStore(source); var store = new PostgresMatchRecoveryStore(source);
            IMatchSession session = new MatchSession(room, new CoreRuleEngine(), journal, players);
            var tokens = new Dictionary<string, string>(); MatchState state = null!; var cold = 0;
            tokens["alice"] = (await session.EnsurePlayerAsync("alice", default)).ReconnectToken; await Cold();
            tokens["bob"] = (await session.EnsurePlayerAsync("bob", default)).ReconnectToken; await Cold();
            var winning = branch.Contains("-winning", StringComparison.Ordinal);
            var returned = branch.EndsWith("-return", StringComparison.Ordinal);
            var alternate = branch.StartsWith("draven-alt", StringComparison.Ordinal);
            var forge = branch.StartsWith("forge-", StringComparison.Ordinal);
            var scenario = "battle-result-draven" + (alternate ? "-alt" : "") + (winning ? "-winning" : "");
            var setup = await session.SeedScenarioAsync("alice", "original-controlled-draven-position", scenario,
                JsonSerializer.SerializeToElement(new { cmdType = "DEV_SEED_SCENARIO", scenarioId = scenario }), default);
            Check(setup.Accepted, "The controlled position is an original accepted command."); await Cold();
            var original = (await store.LoadAsync(room, default))!;
            Check(original.OpeningSeed != 0 && original.ReplayInitialState is { Tick: 0, Status: "EMPTY", Seats.Count: 0 }
                && original.Commands.Count == 3 && original.Commands.Take(2).All(c => c.CommandType == "ROOM_SEAT"),
                "Original seats, private opening and controlled seed all remain in the action log.");
            await Submit("alice", new MoveUnitCommand("SOURCE", "BASE", "BATTLEFIELD:FIELD", []));
            for (var i = 0; i < 4 && state.FocusPlayerId is not null; i++) await Submit(state.FocusPlayerId, new PassFocusCommand());
            await Submit("alice", new DeclareBattleCommand("FIELD", ["SOURCE"], ["DEFENDER"], ["COMBAT_ASSIGNMENT"]));
            var earned = state.StackItems.Single().DravenBattleWinScore!;
            Check(earned is not null && state.PendingBattleResult is { Stage: "RESULT_TRIGGERS", WinnerPlayerId: "alice" }
                && state.CardObjects["FIELD"].ControllerId == "bob" && state.CardObjects["SOURCE"].IsAttacking
                && state.PlayerScores["alice"] == (winning ? 7 : 0) && state.UntilEndOfTurnEffects.Contains(Marker(earned)),
                "The first occurrence is captured before its score, control and battle end, with a real response window.");
            if (forge)
            {
                await Save("original-final-frame.json.gz", (await store.LoadAsync(room, default))!);
                await SaveRows("original-final-seven-tables.json.gz"); await CorruptAndRefuse();
            }
            else
            {
                if (returned)
                {
                    await Submit("alice", new PlayCardCommand("RETURN", "OGN·104/298", ["SOURCE"])); await Top();
                    Check(state.PlayerZones["alice"].Hand.Contains("SOURCE")
                        && state.CardObjects["SOURCE"].ObjectGeneration > earned!.Source.Generation,
                        "A legal response returns the source as a new private incarnation.");
                    Check(state.StackItems.Single().DravenBattleWinScore == earned, "The earned skill retains its original source and controller.");
                }
                for (var i = 0; state.Status == MatchStatuses.InProgress && state.PriorityPlayerId is not null; i++)
                { Check(i < 8, "The original score continuation must finish."); await Submit(state.PriorityPlayerId, new PassPriorityCommand()); }
                var events = journal.Entries.SelectMany(e => e.Events).ToArray();
                Check(state.PlayerScores["alice"] == (winning ? 8 : returned ? 1 : 2)
                    && state.WinnerPlayerId == (winning ? "alice" : null) && state.UntilEndOfTurnEffects.Contains(Marker(earned!))
                    && events.Count(e => e.Kind == "SCORE_GAINED" && Equals(e.Payload.GetValueOrDefault("reason"), Effect)) == 1
                    && !events.Any(e => e.Kind == "CARD_DRAWN"), "Exactly one earned first-occurrence point, independently of source departure.");
                if (winning)
                {
                    Check(state.PendingBattleResult is not null && state.CardObjects["FIELD"].ControllerId == "bob"
                        && !events.Any(e => e.Kind is "BATTLEFIELD_CONQUERED" or "BATTLE_CLOSED"),
                        "Normal victory finishes the score parent before control or battle close.");
                    var count = journal.Entries.Count;
                    var raw = JsonSerializer.SerializeToElement(new { cmdType = "END_TURN", promptId = session.PromptFor("alice").PromptId, snapshotTick = state.Tick });
                    var refused = false;
                    try { await session.SubmitAsync("alice", "post-finish-refusal", new EndTurnCommand(), raw, default); }
                    catch (MatchSessionException error) when (error.Code == ErrorCodes.MatchFinished) { refused = true; }
                    Check(refused && journal.Entries.Count == count, "Finished-session rejection never writes a new accepted or rejected history row.");
                }
                else Check(state.PendingBattleResult is null && events.Count(e => e.Kind == "BATTLE_CLOSED") == 1
                    && events.Count(e => e.Kind == "BATTLEFIELD_CONQUERED") == (returned ? 0 : 1),
                    "Control follows the earned score and uses actual surviving occupancy.");
                var final = (await store.LoadAsync(room, default))!;
                Check(final.OpeningSeed == original.OpeningSeed && final.Commands.Take(original.Commands.Count)
                    .Select(MatchStateHasher.HashValue).SequenceEqual(original.Commands.Select(MatchStateHasher.HashValue)), "Original histories and seeds are unchanged.");
                await Save("original-final-frame.json.gz", final); await SaveRows("original-final-seven-tables.json.gz");
            }
            Check(cold == journal.Entries.Count, "Every accepted prefix independently replayed and cold restored.");
            await File.WriteAllTextAsync(Path.Combine(folder, "receipt.json"), JsonSerializer.Serialize(new {
                status = "REAL_SQL_DRAVEN_FIRST_BATTLE_WIN_SCORE_SCOPED", room, branch, scenario,
                originalAcceptedInputs = journal.Entries.Count, coldRecoveries = cold,
                structurallyConsistentOriginalJournalForgeryRejected = forge, actualRuleInputs = RuleInputIdentity.Current,
                originalPrivateSeed = original.OpeningSeed, controlledPositionNotOrdinaryOpening = true,
                postFinishRejectedWithoutJournalChange = winning, noAcceptedHistoryRewrite = true, wholeCardCertification = false }, Json));
            Console.WriteLine($"DRAVEN_FIRST_WIN_SCORE_SQL_PASS {branch} inputs={journal.Entries.Count} cold={cold}");
