from pathlib import Path
import json,gzip,hashlib,copy,subprocess,datetime,tarfile,xml.etree.ElementTree as E,re
root=Path.cwd();w=Path(__file__).resolve().parent;prior=root/'var/qa/battle-result-continuation-n52-20261023';identity='draven-first-battle-win-score-current-cn16-2026-10-23';ev=root/'docs/evidence'/identity
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
start=json.loads(gzip.decompress((w/'sole-check-frozen-candidate-start-v1.json.gz').read_bytes()));frozen=Path(start['frozenRoot']);check=load(w/'sole-check-frozen-owner-terminal-v1.json');assert check['exitCode']==1 and check['allSourceInputsAndModesStable'];assert all(sha(frozen/p)==v['sha256'] and oct((frozen/p).stat().st_mode&0o777)==v['mode'] for p,v in start['sourceInputs'].items())
base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert base=='87b17f8f75b4145b9d5cbe2028b85b7050d04281'
indexed=load(w/'n53-staged-from-fixed-candidate-v1.json');assert indexed['baseCommit']==base
for p in indexed['paths']:
 assert hashlib.sha256(subprocess.check_output(['git','show',':'+p['path']])).hexdigest()==p['sha256'],p['path']
legacy='tests/Riftbound.ConformanceTests/ConformanceFixtureRunnerTests.cs';cal=load(prior/'p79-draven-current-source-calibration-v1.json');assert hashlib.sha256(subprocess.check_output(['git','show',':'+legacy])).hexdigest()==cal['newFileSha256']
repair=load(prior/'p79-current-source-and-adjacent-repair-v1/summary.json');assert repair['status']=='PASSED' and repair['total']==73
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};trx=E.parse(w/'frozen-sole-check-v1/check/results.trx');rows=trx.findall('.//t:UnitTestResult',ns);failed=[r for r in rows if r.get('outcome')!='Passed'];assert len(rows)==13823 and len(failed)==1 and failed[0].get('testName').endswith('.P79LegendTriggerDravenDrawsWhenControllerWinsBattle')
classes=['OfficialDravenBattleWinScoreTests','DravenBattleWinScoreInteractionTests','DravenBattleWinScoreRecoveryTests','DravenBattleWinMultiSourceTests'];new=[r.get('testName') for r in rows if any('.'+c+'.' in r.get('testName') for c in classes)];assert len(new)==57
plan=load(w/'frozen-sole-check-v1/plan.json');defs={x.get('id'):x.find('t:TestMethod',ns).attrib for x in trx.findall('.//t:UnitTest',ns)};methods={defs[x.get('testId')]['className']+'.'+defs[x.get('testId')]['name']for x in rows};assert methods==set(plan['shards'][0]['methods']) and len(methods)==7645
broad=load(w/'adjacent-and-twelve-original-games-owner-terminal-v1.json');assert broad['status']=='PASS' and broad['sourceInputsStable'] and broad['summary']['total']==824
sql=load(w/'independent-eleven-draven-score-sql-originals-readonly-owner-terminal-v1.json');assert sql['exitCode']==0 and sql['totals']==dict(commands=105,events=286,authority=105,snapshots=199,prompts=199,prefixReplays=105,actualForgeryRefusals=3)
network=load(w/'independent-four-original-network-sql-and-transport-owner-terminal-v1.json');assert network['readerExitCode']==0 and network['transportExitCode']==0 and network['allSourceRuntimeAndOwnInputsStable'] and network['allOriginal132NativeSevenTablesExact']
assert network['independentOriginalCounts']==dict(commands=48,events=130,authority=48,snapshots=92,prompts=92,prefixReplays=48,originalWireIntents=36)
wire=load(w/'real-signalr-four-draven-score-owner-terminal-v2.json');assert wire['prepareExitCode']==0 and wire['resumeExitCode']==0 and wire['allSourceRuntimeAndOwnInputsStable']
mp=root/'docs/audit/current-manifest.json';m=load(mp);old=copy.deepcopy(m);rp=root/m['inputs']['reviews']['path'];reviews=load(rp);assert len(reviews['reviews'])==173 and len(m['reviewContexts'])==88 and not ev.exists()
ev.mkdir();(ev/'original88-contexts.json.gz').write_bytes(gzip.compress(json.dumps(old['reviewContexts'],ensure_ascii=False).encode(),mtime=0))
def pin(p,role=None):
 rel=p.relative_to(root).as_posix();source=frozen/rel if rel in start['sourceInputs'] and rel!=legacy else p
 v=dict(path=rel,sha256=sha(source))
 if role:v['role']=role
 return v
selected={p for p in w.iterdir() if p.is_file() and p.suffix in ['.json','.gz','.py','.cs','.patch','.log','.md'] and p.name!='publication-console-v1.log'}
folders=['sources-v1','integration-focus-v1','integration-focus-v2','adjacent-and-twelve-original-games-v1','frozen-sole-check-v1','main-score-original-v2','main-interactions-original-v2','main-recovery-original-v2','real-sql-eleven-draven-score-original-rooms-v1','real-signalr-four-draven-score-original-rooms-v1','real-signalr-four-draven-score-original-rooms-v2','independent-four-original-network-sql-v1','network-original-driver-v1','network-original-driver-v2','independent-network-sql-reader-v1','independent-original-sql-reader-v1']
for d in folders:
 selected.update(p for p in (w/d).rglob('*') if p.is_file() and not set(p.relative_to(w).parts)&{'bin','obj'})
# Original auth material stays private locally. Inspect payload keys before publishing raw network evidence.
for p in selected:
 assert 'private-network-auth' not in str(p)
 if p.suffix in ['.json','.gz']:
  b=p.read_bytes()
  if p.name.endswith('.json.gz'):b=gzip.decompress(b)
  assert not re.search(rb'"(?:accessToken|reconnectToken|authorization|password|bearerToken)"\s*:',b,re.I),str(p)
extra=[prior/'p79-draven-current-source-calibration-v1.json']+[p for p in (prior/'p79-current-source-and-adjacent-repair-v1').rglob('*') if p.is_file()]
archive=ev/'original-sources-tests-and-network-results.tar.gz';members=[]
with tarfile.open(archive,'w:gz') as t:
 for p in sorted(selected):
  rel=p.relative_to(w).as_posix();t.add(p,arcname=rel,recursive=False);members.append(dict(path=rel,bytes=p.stat().st_size,sha256=sha(p)))
 for p in extra:
  rel='inherited-n52-calibration/'+p.relative_to(prior).as_posix();t.add(p,arcname=rel,recursive=False);members.append(dict(path=rel,bytes=p.stat().st_size,sha256=sha(p)))
write(ev/'archive-index.json',dict(archive=pin(archive),members=members,privateAuthenticationFilesExcluded=True))
peerpath=root/'docs/evidence/draven-battle-win-score-parallel-2026-10-23/source-and-red-test-manifest.json';peer=load(peerpath);clauses=list({c['id']:c for c in peer['source']['coreClauses']+peer['firstOccurrenceAndParentCompletionClauses']}.values());rules=load(root/m['inputs']['rules']['path']);rule_ids=[r['id']for r in rules['records']if r.get('sourceRecord') in {c['id']for c in clauses}];assert len(rule_ids)==len(clauses)
subjects=['SFD-148/221','SFD-148A/221'];cards=load(root/m['inputs']['cards']['path']);assert set(subjects).issubset({r['id']for r in cards['records']})
implementation=[pin(root/p['path'],'implementation')for p in indexed['paths']if p['path'].startswith('src/')];verification=[pin(root/p['path'],'verification-source')for p in indexed['paths']if p['path'].startswith(('tests/','scripts/'))]
# The calibrated P79 method is inherited unchanged from committed N52, never from N54 working sources.
verification.append(dict(path=legacy,sha256=cal['newFileSha256'],role='inherited-source-guided-calibration'))
scope='CN16 SFD148/148a first own battle-win score: capture first occurrence before responses, counter/removal does not refund, per-turn and source-generation continuity, captured controller receives one point before control, ordinary winning score halts continuation. Battle-death opponent score remains separate and OPEN.'
sm=dict(schemaVersion=1,id=identity,recordedAtUtc=now(),baseCommit=base,frozenCheckBaseCommit=start['baseCommit'],region='CN',language='zh-CN',applicableAsOf='2026-10-23',corePublicationDate='2026-10-10',coreEffectiveDate='2026-10-16',individualPrintingPublicationAndEffectiveDates='UNKNOWN unless explicitly retained',issue='https://github.com/DDDHL0704/riftbound/issues/102',scope=scope,subjects=subjects,rules=clauses,sourceRuleRecords=rule_ids,sourceOriginals=[pin(peerpath)],implementation=implementation,verificationSources=verification,newCases=57,newMethods=9,focus=dict(cases=824,methods=390,originalFullGames=12),check=dict(cases=13823,methods=7645,passed=13822,failed=1,skipped=0,exitCode=1,soleExecution=True,originalFailure=failed[0].get('testName'),inheritedN52LegacyCalibration=cal,noSecondCheck=True,sourceGuidedRepairFocus=dict(cases=73,methods=50,status='PASS_ON_THEN_CURRENT_N53_IMPLEMENTATION_BEFORE_N54'),all3427FrozenInputsAndModesStable=True,actualRuleInputs=load(w/'sole-check-frozen-runtime-identity-v1.json')['actualRuleInputs']),sql=dict(totals=sql['totals'],actualRuleInputs=sql['actualRuleInputs'],allOld508Audit127NetworkRoomsUnchanged=True),network=dict(originalCounts=network['independentOriginalCounts'],actualRuleInputs=network['actualRuleInputs'],realAuthenticatedPlayers=True,apiRestartWithSameFixedRuntime=True,originalPrefixReplay=True,tokenRotation=True,duplicateIntentNoMutation=True,observedPersistBeforePrivatePublicationMessages=216,boundedObservationNotAllSchedules=True,existingTransport15RejectionsZeroLeakAndActualSocketDrop=True,original508Audit132NativeRoomsUnchanged=True,partialFirstDriverRoomPreserved=True,controlledPositionsNotOrdinaryOpening=True,privateCredentialsExcluded=True),expectedNextFull=dict(cases=13972,methods=7786,sqlCases=67),allOriginalTestsTheoryRows143Methods151FullGames110Pairs11Decks424242Preserved=True,original1740Printings14293RulesAndAllSourceGapsRetained=True,wholePrintingCertified=False,semanticCoverageCertified=False,backendGoalComplete=False,followups=['Fixed complete CI remains pending for this exact commit.','Draven battle-death opponent score and simultaneous-death ordering are the peer-owned next module.','Ordinary opening-to-scored-end current-candidate validation remains separate from controlled positions.','All applicable source gaps and unresolved full-backend obligations remain OPEN.'],archives=[pin(archive),pin(ev/'archive-index.json')])
write(ev/'source-manifest.json',sm);sp=pin(ev/'source-manifest.json','source-manifest')
branches=[dict(id='N53-'+hashlib.sha256(n.encode()).hexdigest()[:16].upper(),sourceRefs=rule_ids+subjects,actualExecutedCase=n,sourceManifest=sp,decision=dict(state='OPEN',reason='Scoped focus, SQL and network/restart passed; frozen sole check retained inherited legacy failure, calibrated method has focused evidence; exact fixed full and overall backend remain OPEN.'),wholePrintingCertified=False)for n in new]
refreshed=[]
for name,context in m['reviewContexts'].items():
 changes=[]
 for ref in context['implementation']:
  h=sha(frozen/ref['path'])
  if h!=ref['sha256']:changes.append(dict(path=ref['path'],before=ref['sha256'],after=h));ref['sha256']=h
 if changes:refreshed.append(dict(id=name,changes=changes));context.update(currentImplementationCommit=base,currentImplementationIncludesUncommittedChanges=True,ciState='PENDING',currentN53InputRefresh=dict(sourceManifest=sp,priorEvidenceRetained=True,semanticCertification=False))
 assert context.get('verificationSources')==old['reviewContexts'][name].get('verificationSources')
write(ev/'current-input-refreshes.json',dict(refreshed=refreshed,originalContexts=pin(ev/'original88-contexts.json.gz'),unchangedContexts=88-len(refreshed)))
m['reviewContexts'][identity]=dict(evidenceCommit=base,currentImplementationCommit=base,currentImplementationIncludesUncommittedChanges=True,ciState='PENDING',ciReceipts=[],implementation=implementation,verificationSources=verification,branches=branches,evidence=[sp])
reviews['reviews'].append(dict(id=identity,scope=scope,subjects=subjects,ruleRecords=rule_ids,status='BOUNDED_FOCUS_SQL_NETWORK_PASS_SOLE_CHECK_INHERITED_LEGACY_FAILURE_FIXED_FULL_OPEN',sourceManifest=sp,auditDocument='docs/DRAVEN_FIRST_BATTLE_WIN_SCORE_CURRENT_CN16_AUDIT_2026-10-23.md'))
m['acceptanceGates'].append(dict(id='N53_CURRENT_FIXED_BACKEND_FULL_AND_ORDINARY_GAME',state='OPEN',requirement='Fixed full13972/7786/all67 SQL, current ordinary scored game and full backend source/semantic closure. Controlled SQL/API restart evidence is scoped and does not close the whole gate.',sourceManifest=sp))
write(rp,reviews);m['inputs']['reviews']['sha256']=sha(rp);coverage=load(root/m['cardCoverageManifest']['path']);coverage.update(previousCurrentScopedReviewDecisionsBeforeN53=copy.deepcopy(coverage['currentScopedReviewDecisions']),currentScopedReviewDecisions=copy.deepcopy(m['inputs']['reviews']),currentN53SourceManifest=sp);write(ev/'source-coverage.json',coverage);m['cardCoverageManifest']=pin(ev/'source-coverage.json','current-card-coverage')
m['currentN53DravenFirstBattleWinScore']=dict(sourceManifest=sp,soleCheckPassed=False,inheritedLegacyFailurePreservedAndCalibratedInN52=True,newBehaviorBranches=57,newGate=1,expectedRemainingObligations=17582,allOriginal17524IdentitiesRetained=True,goalStatus='ACTIVE',semanticCoverageCertified=False)
assert m['acceptanceGates'][:-1]==old['acceptanceGates'] and m['laterSourceDeltas']==old['laterSourceDeltas'];write(mp,m)
print('N53_PUBLISHED',len(rows),'cases;',len(new),'new;',len(refreshed),'refreshed;',len(members),'archive members')
