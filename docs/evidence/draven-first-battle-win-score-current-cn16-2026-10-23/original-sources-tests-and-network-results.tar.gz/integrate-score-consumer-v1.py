from pathlib import Path

root = Path('/Users/dinghaolin/MyProjects/riftbound')

def edit(name, changes):
    p = root / 'src/Riftbound.Engine' / name
    text = p.read_text()
    for old, new, count in changes:
        assert text.count(old) == count, (name, old, text.count(old), count)
        text = text.replace(old, new)
    p.write_text(text)

edit('MatchSession.cs', [
    ('public KhazixBattleWinContext? KhazixBattleWin { get; init; }',
     'public KhazixBattleWinContext? KhazixBattleWin { get; init; }\n    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]\n    public DravenBattleWinScoreContext? DravenBattleWinScore { get; init; }', 2),
    ('KhazixBattleWin = item.KhazixBattleWin,', 'KhazixBattleWin = item.KhazixBattleWin, DravenBattleWinScore = item.DravenBattleWinScore,', 2),
    ('if (trigger.KhazixBattleWin is not null) return "赢得战斗：获得1经验；双方响应后结算。";',
     'if (trigger.KhazixBattleWin is not null) return "赢得战斗：获得1经验；双方响应后结算。";\n        if (trigger.DravenBattleWinScore is not null) return "本回合首次赢得战斗：获得1分；双方响应后结算。";', 2),
    ('|| trigger.KhazixBattleWin is not null)', '|| trigger.KhazixBattleWin is not null || trigger.DravenBattleWinScore is not null)', 1),
    ('|| item.KhazixBattleWin is not null\n', '|| item.KhazixBattleWin is not null || item.DravenBattleWinScore is not null\n', 1),
])
edit('CoreRuleEngine.cs', [
    ('KhazixBattleWin = trigger.KhazixBattleWin,', 'KhazixBattleWin = trigger.KhazixBattleWin, DravenBattleWinScore = trigger.DravenBattleWinScore,', 1),
    ('if (stackItem.KhazixBattleWin is { } khazixBattleWin) return ResolveKhazixBattleWin(state, stackItem, khazixBattleWin);',
     'if (stackItem.KhazixBattleWin is { } khazixBattleWin) return ResolveKhazixBattleWin(state, stackItem, khazixBattleWin);\n        if (stackItem.DravenBattleWinScore is { } dravenScore) return ResolveDravenBattleWinScore(state, stackItem, dravenScore);', 1),
])
edit('CoreRuleEngine.BattleResultContinuation.cs', [
    ('if (queued.Count == 0) return false;',
     '''var scoreObservations = CaptureDravenBattleWinScoreObservations(resultState, battlefield, winner,
            attackers, defenders, resultState.Tick);
        queued.AddRange(scoreObservations.Select(x => x.Trigger with { DravenBattleWinScore = x.Context }));
        if (queued.Count == 0) return false;''', 1),
    ('?? trigger.KhazixBattleWin }', '?? (object?)trigger.KhazixBattleWin ?? trigger.DravenBattleWinScore }', 1),
    ('PendingBattleResult = continuation, TriggerQueue = resultState.TriggerQueue.Concat(queued).ToArray(),',
     '''PendingBattleResult = continuation, TriggerQueue = resultState.TriggerQueue.Concat(queued).ToArray(),
            UntilEndOfTurnEffects = scoreObservations.Aggregate(resultState.UntilEndOfTurnEffects,
                (effects, captured) => AddUntilEndOfTurnEffect(effects, captured.UsedMarker)),''', 1),
])
edit('BattleResultRecoveryRules.cs', [
    ('private const string Experience = "CAPTURED_KHAZIX_BATTLE_WIN_EXPERIENCE";',
     'private const string Experience = "CAPTURED_KHAZIX_BATTLE_WIN_EXPERIENCE";\n    private const string FirstWinScore = "CAPTURED_DRAVEN_FIRST_BATTLE_WIN_SCORE";', 1),
    ('KhazixBattleWinContext? khazix)', 'KhazixBattleWinContext? khazix, DravenBattleWinScoreContext? score)', 2),
    ('+ (khazix is null ? 0 : 1);', '+ (khazix is null ? 0 : 1) + (score is null ? 0 : 1);', 1),
    ('effect is not (UnitDraw or LegendDraw or Experience)', 'effect is not (UnitDraw or LegendDraw or Experience or FirstWinScore)', 1),
    *[(f'?? khazix!.{field}', f'?? khazix?.{field} ?? score!.{field}', 1)
      for field in ['Source', 'CardNo', 'ControllerId', 'BattlefieldId', 'ResultTick', 'Role']],
    ('_ => false\n        };',
     '''FirstWinScore => score is not null && CoreRuleEngine.HasValidDravenBattleWinScoreShape(score)
                && score.TurnNumber == state.TurnNumber
                && state.UntilEndOfTurnEffects.Contains(CoreRuleEngine.DravenBattleWinScoreUsedMarker(score), StringComparer.Ordinal)
                && (role == "ATTACKER" ? c.SurvivingAttackerObjectIds : c.SurvivingDefenderObjectIds).Contains(source),
            _ => false
        };''', 1),
    ('item.UnitBattleWinDraw, item.LegendBattleWinDraw, item.KhazixBattleWin)',
     'item.UnitBattleWinDraw, item.LegendBattleWinDraw, item.KhazixBattleWin, item.DravenBattleWinScore)', 4),
    ('|| item.KhazixBattleWin is not null)', '|| item.KhazixBattleWin is not null || item.DravenBattleWinScore is not null)', 2),
    ('cardNo, unit, legend, khazix)', 'cardNo, unit, legend, khazix, score)', 1),
    ('(object?)legend ?? khazix;', '(object?)legend ?? (object?)khazix ?? score;', 1),
])
print('Draven first battle-win score connected to existing shared result, privacy and original-birth validation')
