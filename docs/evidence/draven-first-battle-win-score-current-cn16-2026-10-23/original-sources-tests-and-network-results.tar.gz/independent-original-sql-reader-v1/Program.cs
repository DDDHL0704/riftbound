using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.CardCatalog;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
var modules = new[] { typeof(CoreRuleEngine).Assembly, typeof(GameCommand).Assembly, typeof(OfficialCardCatalog).Assembly, typeof(PostgresMatchRecoveryStore).Assembly };
var loaded = new { baseDirectory = AppContext.BaseDirectory, actualRuleInputs = RuleInputIdentity.Current,
    assemblies = modules.Select(a => new { name = a.GetName().Name, path = a.Location, mvid = a.ManifestModule.ModuleVersionId,
        sha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(a.Location))).ToLowerInvariant() }).ToArray() };
if (args is ["--loaded-inputs"]) { Console.WriteLine(JsonSerializer.Serialize(loaded, json)); return; }
Check(args.Length == 2 && !File.Exists(args[1]), "Original completed owner directory and unused result required.");
var home = Path.GetFullPath(args[0]);
using var owner = JsonDocument.Parse(File.ReadAllText(Path.Combine(home, "real-sql-eleven-draven-score-original-rooms-owner-terminal-v1.json")));
var top = owner.RootElement;
Check(top.GetProperty("status").GetString()!.StartsWith("PASS_DRAVEN_FIRST_WIN_SCORE_ELEVEN_ORIGINAL_REAL_SQL_ROOMS", StringComparison.Ordinal)
    && Same(top.GetProperty("actualLoadedFourAssemblies").GetProperty("actualRuleInputs"), JsonSerializer.SerializeToElement(RuleInputIdentity.Current, json)), "Original successful writer and actually loaded input identity.");
var settings = new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
Check(settings.Host == "127.0.0.1" && settings.Port == 55486 && settings.Database == "riftbound_acceptance"
    && settings.Username == "codex_riftbound_audit", "Only the actual owned acceptance database.");
settings.Options = "-c default_transaction_read_only=on";
await using var source = NpgsqlDataSource.Create(settings.ConnectionString);
await using var connection = await source.OpenConnectionAsync();
Check((string)(await new NpgsqlCommand("show transaction_read_only", connection).ExecuteScalarAsync())! == "on", "Actually read-only SQL connection.");
var counts = new Dictionary<string, int> { ["commands"] = 0, ["events"] = 0, ["authority"] = 0, ["snapshots"] = 0, ["prompts"] = 0, ["prefixReplays"] = 0, ["actualForgeryRefusals"] = 0 };
var outcomes = new List<object>(); var seenBranches = new HashSet<string>();
foreach (var receipt in top.GetProperty("receipts").EnumerateArray())
{
    var branch = receipt.GetProperty("branch").GetString()!; Check(seenBranches.Add(branch), "Every original branch occurs exactly once.");
    var room = receipt.GetProperty("room").GetString()!; var scenario = receipt.GetProperty("scenario").GetString()!;
    var folder = Path.Combine(home, "real-sql-eleven-draven-score-original-rooms-v1/draven-first-win-score", branch);
    var corrupt = branch.StartsWith("forge-", StringComparison.Ordinal);
    using var savedFrame = Read(Path.Combine(folder, "original-final-frame.json.gz"));
    var frame = savedFrame.RootElement.Deserialize<MatchRecoveryFrame>(json)!;
    using var savedRows = Read(Path.Combine(folder, "original-final-seven-tables.json.gz")); var originalRows = savedRows.RootElement;
    var live = (await new PostgresMatchRecoveryStore(source).LoadAsync(room, default))!;
    using var corruptRows = corrupt ? Read(Path.Combine(folder, "actual-corrupt-seven-tables.json.gz")) : null;
    using var corruptFrame = corrupt ? Read(Path.Combine(folder, "actual-corrupt-frame.json.gz")) : null;
    Check(Same(JsonSerializer.SerializeToElement(live, json), corrupt ? corruptFrame!.RootElement : savedFrame.RootElement), "Every actual current frame field, null and omission equals its original retained frame.");
    Check(frame.IsConsistent && frame.OpeningSeed != 0 && frame.ReplayInitialState is { Tick: 0, Status: "EMPTY", Seats.Count: 0, CardObjects.Count: 0 }
        && frame.Commands.All(c => c.Accepted && c.RuleInputs == RuleInputIdentity.Current), "Original EMPTY opening, private seed, all accepted inputs and current identity.");
    Check(frame.OpeningSeed == live.OpeningSeed && Same(JsonSerializer.SerializeToElement(frame.Commands, json), JsonSerializer.SerializeToElement(live.Commands, json))
        && Same(JsonSerializer.SerializeToElement(frame.Events, json), JsonSerializer.SerializeToElement(live.Events, json)), "Even deliberately corrupted rooms retain every original accepted input, event and private seed.");
    var expectedTypes = new List<string> { "ROOM_SEAT", "ROOM_SEAT", "DEV_SEED_SCENARIO:" + scenario };
    var returned = branch.EndsWith("-return", StringComparison.Ordinal);
    var winning = branch.Contains("-winning", StringComparison.Ordinal);
    var alternate = branch.StartsWith("draven-alt", StringComparison.Ordinal);
    expectedTypes.AddRange(["MOVE_UNIT", "PASS_FOCUS", "PASS_FOCUS", "DECLARE_BATTLE"]);
    if (!corrupt)
    {
        if (returned) expectedTypes.AddRange(["PLAY_CARD", "PASS_PRIORITY", "PASS_PRIORITY"]);
        expectedTypes.AddRange(["PASS_PRIORITY", "PASS_PRIORITY"]);
    }
    Check(frame.Commands.Select(c => c.CommandType).SequenceEqual(expectedTypes), "Independent literal complete command sequence, with no skipped natural stage or repeated unavailable damage input.");
    for (var i = 0; i < 2; i++) {
        var c = frame.Commands[i]; var raw = c.RawCommand!.Value; var actor = i == 0 ? "alice" : "bob"; var seat = i == 0 ? "P1" : "P2";
        Check(c.PlayerId == actor && c.ClientIntentId == "room-seat:" + seat && raw.EnumerateObject().Count() == 3
            && raw.GetProperty("playerId").GetString() == actor && raw.GetProperty("seat").GetString() == seat
            && raw.GetProperty("cmdType").GetString() == "ROOM_SEAT", "Literal server identities and reserved atomic seat inputs, without credentials in the public raw schema.");
    }
    var states = new Dictionary<(long Tick, long Seq), MatchState>();
    foreach (var table in new[] { "matches", "match_players", "command_log", "game_events", "state_snapshots", "snapshots", "action_prompts" })
    {
        await using var q = new NpgsqlCommand($"select coalesce(json_agg(t order by row_to_json(t)::text),'[]'::json)::text from (select * from {table} where match_id=@room)t", connection);
        q.Parameters.AddWithValue("room", room); using var actual = JsonDocument.Parse((string)(await q.ExecuteScalarAsync())!);
        Check(Same(actual.RootElement, (corrupt ? corruptRows!.RootElement : originalRows).GetProperty(table)), "All actual seven-table fields, nulls and omissions equal their own original captured bytes: " + table);
        if (corrupt && table is "matches" or "match_players" or "command_log" or "game_events")
            Check(Same(actual.RootElement, originalRows.GetProperty(table)), "Deliberate coordinated payload corruption never rewrites original game inputs, events or room/credential metadata.");
        if (table == "state_snapshots") foreach (var row in originalRows.GetProperty(table).EnumerateArray()) {
            var payload = row.GetProperty("payload"); var state = payload.Deserialize<MatchState>(json)!;
            Check(Same(payload, JsonSerializer.SerializeToElement(state, json)) && state.RuleInputs == RuleInputIdentity.Current
                && states.TryAdd((state.Tick, row.GetProperty("last_event_sequence").GetInt64()), state), "Every complete original authority value and unique original checkpoint.");
        }
    }
    Check(states.Count == frame.Commands.Count && frame.Commands.All(c => states.ContainsKey((c.CompletedTick, c.CompletedEventSequence))), "Every accepted original input has its independently stored original authority history.");
    foreach (var (command, index) in frame.Commands.Select((c, i) => (c, i)))
    {
        var state = states[(command.CompletedTick, command.CompletedEventSequence)];
        using var cold = Read(Path.Combine(folder, $"prefix-{index + 1:D2}-original-frame.json.gz"));
        Check(Same(cold.RootElement.GetProperty("authoritativeState"), JsonSerializer.SerializeToElement(state, json))
            && Same(cold.RootElement.GetProperty("commands"), JsonSerializer.SerializeToElement(frame.Commands.Take(index + 1), json)), "Every original recorded cold checkpoint has its entire exact original state and command prefix.");
        var events = frame.Events.Where(e => e.Sequence <= command.CompletedEventSequence).ToArray();
        var replay = await MatchActionLogReplayer.VerifyFinalStateAsync(frame.ReplayInitialState!, frame.Commands.Take(index + 1).ToArray(), state, new CoreRuleEngine(), default, events);
        Check(replay.IsMatch, "Every complete original prefix actually replays: " + string.Join("; ", replay.Errors)); counts["prefixReplays"]++;
        if (index >= 3) {
            using var input = JsonDocument.Parse(File.ReadAllText(Path.Combine(folder, $"input-{index:D2}-original-command.json")));
            using var prompt = JsonDocument.Parse(File.ReadAllText(Path.Combine(folder, $"input-{index:D2}-original-prompt.json")));
            Check(Same(input.RootElement, command.RawCommand!.Value)
                && input.RootElement.GetProperty("snapshotTick").GetInt64() == command.StartedTick
                && input.RootElement.GetProperty("promptId").GetString() == prompt.RootElement.GetProperty("promptId").GetString(), "Each actual gameplay raw intent retains every original field and its original private prompt/tick stamp.");
        }
    }
    foreach (var table in new[] { "snapshots", "action_prompts" }) foreach (var row in originalRows.GetProperty(table).EnumerateArray())
    {
        var actor = row.GetProperty("player_id").GetString()!; var payload = row.GetProperty("payload");
        var tick = row.GetProperty(table == "snapshots" ? "snapshot_tick" : "prompt_tick").GetInt64(); var seq = row.GetProperty("last_event_sequence").GetInt64(); var state = states[(tick, seq)];
        Check(state.Seats.ContainsKey(actor), "Only an actually existing historical viewer has a private row.");
        var typed = table == "snapshots" ? JsonSerializer.SerializeToElement(payload.Deserialize<SnapshotDto>(json), json) : JsonSerializer.SerializeToElement(payload.Deserialize<ActionPromptDto>(json), json);
        var projected = table == "snapshots" ? JsonSerializer.SerializeToElement(ResolutionResult.BuildSnapshots(state)[actor], json) : JsonSerializer.SerializeToElement(ResolutionResult.BuildPrompts(state)[actor], json);
        if (!Same(payload, typed) || !Same(payload, projected)) {
            var diagnostic = new { branch, room, table, actor, tick, seq, typedEqual = Same(payload, typed), projectedEqual = Same(payload, projected), original = payload, typed, projected };
            await File.WriteAllTextAsync(args[1] + ".first-complete-private-difference.json", JsonSerializer.Serialize(diagnostic, json));
        }
        Check(Same(payload, typed), $"Every complete typed original private field, omission and null: {branch}/{table}/{actor}/{tick}/{seq}.");
        Check(Same(payload, projected), $"Every complete original private projection value: {branch}/{table}/{actor}/{tick}/{seq}.");
        Check(!payload.TryGetProperty("openingSeed", out _) && !payload.TryGetProperty("reconnectToken", out _) && !payload.TryGetProperty("playerKey", out _), "No seed or credential fields appear in private game projections.");
        var privateProbe = JsonNode.Parse(payload.GetRawText())!;
        if (table == "snapshots" && state.PlayerZones["alice"].Hand.Contains("SOURCE") && actor == "bob")
        {
            // Existing battle-history projections deliberately retain historical
            // public references. Independently require an older captured binding
            // before excluding just those history sections from current-zone scan.
            foreach (var history in state.BattleResolutions.Where(b => b.AttackerObjectIds.Contains("SOURCE")))
                Check(history.PublicObjectBindings?.Any(b => b.ObjectId == "SOURCE" && b.Generation < state.CardObjects["SOURCE"].ObjectGeneration) == true,
                    "Historical result source must be an older public incarnation.");
            foreach (var history in state.BattlefieldResolutions.Where(b => b.ParticipantObjectIds.Contains("SOURCE")))
                Check(history.PublicObjectBindings?.Any(b => b.ObjectId == "SOURCE" && b.Generation < state.CardObjects["SOURCE"].ObjectGeneration) == true,
                    "Historical field source must be an older public incarnation.");
            privateProbe["timing"]!.AsObject().Remove("battleResolutions");
            privateProbe["timing"]!.AsObject().Remove("battlefieldResolutions");
            foreach (var skill in privateProbe["stack"]!.AsArray())
                if (skill?["effectKind"]?.GetValue<string>() == "CAPTURED_DRAVEN_FIRST_BATTLE_WIN_SCORE")
                    Check(skill["sourceObjectId"]!.GetValue<string>() == "HIDDEN"
                        && skill["cardNo"]!.GetValue<string>() == (alternate ? "SFD·148a/221" : "SFD·148/221"),
                        "Public earned skill retains original printing but hides current private source identity.");
        }
        var text = privateProbe.ToJsonString();
        foreach (var enemy in state.Seats.Keys.Where(p => p != actor)) foreach (var id in state.PlayerZones[enemy].Hand.Concat(state.PlayerZones[enemy].MainDeck))
            Check(!text.Contains(JsonSerializer.Serialize(id), StringComparison.Ordinal), "Independent literal opponent hand/deck boundary outside validated historical battle references.");
    }
    var final = frame.AuthoritativeState!;
    var kinds = frame.Events.Select(e => e.Event.Kind).ToList();
    Check(frame.Commands.All(c => c.CommandType != "SURRENDER"), "Every actual original branch finishes without surrender.");
    var setupState = states[(frame.Commands[2].CompletedTick, frame.Commands[2].CompletedEventSequence)];
    Check(setupState.CardObjects["SOURCE"].Power == 6 && setupState.CardObjects["SOURCE"].Damage == 0
        && setupState.PlayerZones["alice"].Base.SequenceEqual(["SOURCE"]), "Printed six-power Draven starts undamaged in base.");
    var resultCommand = frame.Commands[6]; var resultState = states[(resultCommand.CompletedTick, resultCommand.CompletedEventSequence)];
    var earned = resultState.StackItems.Single().DravenBattleWinScore!;
    var marker = "DRAVEN_FIRST_BATTLE_WIN:5:0:SOURCE";
    Check(resultState.PendingBattleResult is { Stage: "RESULT_TRIGGERS", WinnerPlayerId: "alice" }
        && resultState.CardObjects["FIELD"].ControllerId == "bob" && resultState.PlayerScores["alice"] == (winning ? 7 : 0)
        && resultState.CardObjects["SOURCE"].IsAttacking && resultState.CardObjects["SOURCE"].Damage == 0
        && earned is { ControllerId: "alice", BattlefieldId: "FIELD", Role: "ATTACKER", TurnNumber: 5 }
        && earned.Source.ObjectId == "SOURCE" && earned.Source.Generation == 0 && earned.ResultTick == resultCommand.CompletedTick
        && earned.CardNo == (alternate ? "SFD·148a/221" : "SFD·148/221") && resultState.UntilEndOfTurnEffects.Contains(marker),
        "Independent exact original binding and first occurrence precede score, control and battle end.");
    if (!corrupt)
    {
        Check(!kinds.Contains("CARD_DRAWN") && final.PlayerScores["alice"] == (winning ? 8 : returned ? 1 : 2)
            && final.WinnerPlayerId == (winning ? "alice" : null) && final.UntilEndOfTurnEffects.Contains(marker),
            "Exactly one first-occurrence point survives source departure; only a remaining unit also conquers.");
        var score = frame.Events.Single(e => e.Event.Kind == "SCORE_GAINED"
            && e.Event.Payload.GetValueOrDefault("reason")?.ToString() == "CAPTURED_DRAVEN_FIRST_BATTLE_WIN_SCORE");
        Check(score.Event.Payload.GetValueOrDefault("playerId")?.ToString() == "alice"
            && score.Event.Payload.GetValueOrDefault("amount")?.ToString() == "1", "The earned skill gives its original controller exactly one point.");
        if (winning)
            Check(final.Status == MatchStatuses.Finished && final.PendingBattleResult is not null
                && final.CardObjects["FIELD"].ControllerId == "bob" && !kinds.Contains("BATTLE_CLOSED") && !kinds.Contains("BATTLEFIELD_CONQUERED")
                && score.Sequence < frame.Events.Single(e => e.Event.Kind == "MATCH_WON").Sequence
                && receipt.GetProperty("postFinishRejectedWithoutJournalChange").GetBoolean()
                && frame.Commands.All(c => c.ClientIntentId != "post-finish-refusal"), "Normal score-parent victory precedes control and battle end; terminal refusal adds no history.");
        else
        {
            Check(final.Status == MatchStatuses.InProgress && final.PendingBattleResult is null
                && score.Sequence < frame.Events.Single(e => e.Event.Kind == "BATTLE_CLOSED").Sequence,
                "The original first-win score resolves before battle closure.");
            Check(kinds.Count(k => k == "BATTLEFIELD_CONQUERED") == (returned ? 0 : 1), "Control uses actual post-response occupancy.");
            if (!returned) Check(score.Sequence < frame.Events.Single(e => e.Event.Kind == "BATTLEFIELD_CONQUERED").Sequence,
                "The ordinary conquest follows the independently earned score.");
        }
        Check(returned ? final.PlayerZones["alice"].Hand.Contains("SOURCE")
            : final.ObjectLocations["SOURCE"].BattlefieldObjectId == "FIELD", "Actual physical return or retained source outcome.");
        if (returned) Check(frame.Commands.Single(c => c.CommandType == "PLAY_CARD").RawCommand!.Value.GetProperty("cardNo").GetString() == "OGN·104/298"
            && final.CardObjects["SOURCE"].ObjectGeneration > earned!.Source.Generation, "Actual legal return creates a new private incarnation while preserving the old earned point.");
    }
    Check((await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame, new CoreRuleEngine(), default)).Count == 0, "Complete original recovery-frame replay remains strict.");
    if (corrupt) {
        Check(live.IsConsistent, "All coordinated forged private views are structurally consistent before journal authentication.");
        var actualSkill = live.AuthoritativeState!.StackItems.Single(); var originalSkill = final.StackItems.Single();
        if (branch == "forge-generation") Check(actualSkill.DravenBattleWinScore!.Source.Generation == originalSkill.DravenBattleWinScore!.Source.Generation + 1, "Exact generation attack retained.");
        else if (branch == "forge-printing") Check(actualSkill.DravenBattleWinScore!.CardNo == "SFD·148a/221" && actualSkill.CardNo == "SFD·148a/221", "Exact coordinated printing attack retained.");
        else Check(actualSkill.DravenBattleWinScore!.ResultTick + 1 == originalSkill.DravenBattleWinScore!.ResultTick
            && live.AuthoritativeState.PendingBattleResult!.ResultTick == actualSkill.DravenBattleWinScore.ResultTick, "Exact coordinated result tick attack retained.");
        if (branch == "forge-generation") Check(live.AuthoritativeState.UntilEndOfTurnEffects.Contains("DRAVEN_FIRST_BATTLE_WIN:5:1:SOURCE")
            && !live.AuthoritativeState.UntilEndOfTurnEffects.Contains(marker), "The generation attack also coordinates the usage marker; original history remains the rejecting authority.");
        var directForgeryReplay = await MatchActionLogReplayer.VerifyFinalStateAsync(frame.ReplayInitialState!, frame.Commands,
            live.AuthoritativeState!, new CoreRuleEngine(), default, frame.Events);
        Check(!directForgeryReplay.IsMatch && directForgeryReplay.ReplayedStateHash != directForgeryReplay.ExpectedStateHash,
            "Direct whole original action/event replay rejects the forged state independently of the recovery frame's structural error.");
        Check((await MatchActionLogReplayer.ValidateRecoveryFrameAsync(live, new CoreRuleEngine(), default)).Count > 0, "Actual coordinated forgery fails unchanged original action-log audit.");
        var refused = false; try { await new InMemoryMatchSessionRegistry(new CoreRuleEngine(), new PostgresMatchJournal(source), new PostgresMatchRecoveryStore(source), new PostgresMatchPlayerStore(source)).GetOrCreateAsync(room, default); }
        catch (MatchSessionException e) when (e.Code == ErrorCodes.RecoveryInconsistent) { refused = true; }
        Check(refused, "A separately instantiated actual read-only registry refuses the original corrupt room."); counts["actualForgeryRefusals"]++;
    }
    counts["commands"] += frame.Commands.Count; counts["events"] += frame.Events.Count; counts["authority"] += states.Count;
    counts["snapshots"] += originalRows.GetProperty("snapshots").GetArrayLength(); counts["prompts"] += originalRows.GetProperty("action_prompts").GetArrayLength();
    outcomes.Add(new { branch, room, originalCommands = frame.Commands.Count, originalEvents = frame.Events.Count, actualCorruptionStillRetained = corrupt });
    Console.WriteLine("INDEPENDENT_ORIGINAL_DRAVEN_SCORE_PASS " + branch);
}
Check(seenBranches.SetEquals(new[] { "draven-keep", "draven-return", "draven-winning", "draven-winning-return",
    "draven-alt-keep", "draven-alt-return", "draven-alt-winning", "draven-alt-winning-return",
    "forge-generation", "forge-printing", "forge-result-tick" })
    && counts["commands"] == 105 && counts["authority"] == 105 && counts["snapshots"] == 199 && counts["prompts"] == 199
    && counts["prefixReplays"] == 105 && counts["actualForgeryRefusals"] == 3,
    "All11 original rooms,105 original prefixes,199 private rows per table and three actual coordinated forgery refusals.");
await File.WriteAllTextAsync(args[1], JsonSerializer.Serialize(new { status = "PASS_INDEPENDENT_DRAVEN_SCORE_ELEVEN_ORIGINAL_SQL_ROOMS105_PREFIXES199_EACH_PRIVATE_THREE_ORIGINAL_BIRTH_REFUSALS",
    actualReadOnlyConnection = true, actualLoadedFourAssemblies = loaded, totals = counts, rooms = outcomes,
    allOriginalFieldsNullsOmissionsAndSeedsRetained = true, controlledPositionsNotOrdinaryOpenings = true,
    wholePrintingsAndCurrentFixedCiStillSeparate = true, desktopClientAndWindowsHardwareDeferredToClientPhase = true,
    actualForgedViewsStructurallyConsistent = true }, json));
static JsonDocument Read(string path) { using var stream = new GZipStream(File.OpenRead(path), CompressionMode.Decompress); return JsonDocument.Parse(stream); }
static bool Same(JsonElement a, JsonElement b) => JsonNode.DeepEquals(JsonNode.Parse(a.GetRawText()), JsonNode.Parse(b.GetRawText()));
static void Check(bool value, string reason) { if (!value) throw new InvalidOperationException(reason); }

