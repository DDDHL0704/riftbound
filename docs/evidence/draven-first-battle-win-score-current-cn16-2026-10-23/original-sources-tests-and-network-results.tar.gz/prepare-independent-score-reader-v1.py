from pathlib import Path

root = Path('/Users/dinghaolin/MyProjects/riftbound')
w = Path(__file__).resolve().parent
old = root / 'var/qa/battle-result-continuation-n52-20261023/independent-original-sql-reader-v5'
project = w / 'independent-original-sql-reader-v1'
project.mkdir()
s = (old / 'Program.cs').read_text()
s = s.replace('real-sql-thirteen-battle-result-original-rooms-owner-terminal-v4', 'real-sql-eleven-draven-score-original-rooms-owner-terminal-v1')
s = s.replace('real-sql-thirteen-battle-result-original-rooms-v4/battle-result-continuation', 'real-sql-eleven-draven-score-original-rooms-v1/draven-first-win-score')
s = s.replace('PASS_BATTLE_RESULT_CONTINUATION_THIRTEEN_ORIGINAL_REAL_SQL_ROOMS', 'PASS_DRAVEN_FIRST_WIN_SCORE_ELEVEN_ORIGINAL_REAL_SQL_ROOMS')
s = s.replace('UnitBattleWinDraw', 'DravenBattleWinScore').replace('CAPTURED_UNIT_BATTLE_WIN_DRAW', 'CAPTURED_DRAVEN_FIRST_BATTLE_WIN_SCORE')
s = s.replace('(branch.StartsWith("enforcer") ? "SFD·123/221" : "UNL-114/219")', '(alternate ? "SFD·148a/221" : "SFD·148/221")')
start = s.index('    var lateDefender =')
end = s.index('    Check(frame.Commands.Select', start)
s = s[:start] + '''    var returned = branch.EndsWith("-return", StringComparison.Ordinal);
    var winning = branch.Contains("-winning", StringComparison.Ordinal);
    var alternate = branch.StartsWith("draven-alt", StringComparison.Ordinal);
    expectedTypes.AddRange(["MOVE_UNIT", "PASS_FOCUS", "PASS_FOCUS", "DECLARE_BATTLE"]);
    if (!corrupt)
    {
        if (returned) expectedTypes.AddRange(["PLAY_CARD", "PASS_PRIORITY", "PASS_PRIORITY"]);
        expectedTypes.AddRange(["PASS_PRIORITY", "PASS_PRIORITY"]);
    }
''' + s[end:]
start = s.index('    Check(setupState.CardObjects["SOURCE"].Power')
end = s.index('    Check((await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame', start)
s = s[:start] + '''    Check(setupState.CardObjects["SOURCE"].Power == 6 && setupState.CardObjects["SOURCE"].Damage == 0
        && setupState.PlayerZones["alice"].Base.SequenceEqual(["SOURCE"]), "Printed six-power Draven starts undamaged in base.");
    var resultCommand = frame.Commands[6]; var resultState = states[(resultCommand.CompletedTick, resultCommand.CompletedEventSequence)];
    var earned = resultState.StackItems.Single().DravenBattleWinScore!;
    var marker = "DRAVEN_FIRST_BATTLE_WIN:5:0:SOURCE";
    Check(resultState.PendingBattleResult is { Stage: "RESULT_TRIGGERS", WinnerPlayerId: "alice" }
        && resultState.CardObjects["FIELD"].ControllerId == "bob" && resultState.PlayerScores["alice"] == (winning ? 7 : 0)
        && resultState.CardObjects["SOURCE"].IsAttacking && resultState.CardObjects["SOURCE"].Damage == 0
        && earned is { ControllerId: "alice", BattlefieldId: "FIELD", Role: "ATTACKER", TurnNumber: 5 }
        && earned.Source.ObjectId == "SOURCE" && earned.Source.Generation == 0 && earned.ResultTick == resultCommand.CompletedTick
        && earned.CardNo == (alternate ? "SFD·148a/221" : "SFD·148/221") && resultState.UntilEndOfTurnEffects.Contains(marker),
        "Independent exact original binding and first occurrence precede score, control and battle end.");
    if (!corrupt)
    {
        Check(!kinds.Contains("CARD_DRAWN") && final.PlayerScores["alice"] == (winning ? 8 : returned ? 1 : 2)
            && final.WinnerPlayerId == (winning ? "alice" : null) && final.UntilEndOfTurnEffects.Contains(marker),
            "Exactly one first-occurrence point survives source departure; only a remaining unit also conquers.");
        var score = frame.Events.Single(e => e.Event.Kind == "SCORE_GAINED"
            && e.Event.Payload.GetValueOrDefault("reason")?.ToString() == "CAPTURED_DRAVEN_FIRST_BATTLE_WIN_SCORE");
        Check(score.Event.Payload.GetValueOrDefault("playerId")?.ToString() == "alice"
            && score.Event.Payload.GetValueOrDefault("amount")?.ToString() == "1", "The earned skill gives its original controller exactly one point.");
        if (winning)
            Check(final.Status == MatchStatuses.Finished && final.PendingBattleResult is not null
                && final.CardObjects["FIELD"].ControllerId == "bob" && !kinds.Contains("BATTLE_CLOSED") && !kinds.Contains("BATTLEFIELD_CONQUERED")
                && score.Sequence < frame.Events.Single(e => e.Event.Kind == "MATCH_WON").Sequence
                && receipt.GetProperty("postFinishRejectedWithoutJournalChange").GetBoolean()
                && frame.Commands.All(c => c.ClientIntentId != "post-finish-refusal"), "Normal score-parent victory precedes control and battle end; terminal refusal adds no history.");
        else
        {
            Check(final.Status == MatchStatuses.InProgress && final.PendingBattleResult is null
                && score.Sequence < frame.Events.Single(e => e.Event.Kind == "BATTLE_CLOSED").Sequence,
                "The original first-win score resolves before battle closure.");
            Check(kinds.Count(k => k == "BATTLEFIELD_CONQUERED") == (returned ? 0 : 1), "Control uses actual post-response occupancy.");
            if (!returned) Check(score.Sequence < frame.Events.Single(e => e.Event.Kind == "BATTLEFIELD_CONQUERED").Sequence,
                "The ordinary conquest follows the independently earned score.");
        }
        Check(returned ? final.PlayerZones["alice"].Hand.Contains("SOURCE")
            : final.ObjectLocations["SOURCE"].BattlefieldObjectId == "FIELD", "Actual physical return or retained source outcome.");
        if (returned) Check(frame.Commands.Single(c => c.CommandType == "PLAY_CARD").RawCommand!.Value.GetProperty("cardNo").GetString() == "OGN·104/298"
            && final.CardObjects["SOURCE"].ObjectGeneration > earned!.Source.Generation, "Actual legal return creates a new private incarnation while preserving the old earned point.");
    }
''' + s[end:]
s = s.replace('actualSkill.DravenBattleWinScore!.CardNo == "SFD·123/221" && actualSkill.CardNo == "SFD·123/221"',
              'actualSkill.DravenBattleWinScore!.CardNo == "SFD·148a/221" && actualSkill.CardNo == "SFD·148a/221"')
needle = '        var directForgeryReplay = await MatchActionLogReplayer.VerifyFinalStateAsync('
assert s.count(needle) == 1
s = s.replace(needle, '''        if (branch == "forge-generation") Check(live.AuthoritativeState.UntilEndOfTurnEffects.Contains("DRAVEN_FIRST_BATTLE_WIN:5:1:SOURCE")
            && !live.AuthoritativeState.UntilEndOfTurnEffects.Contains(marker), "The generation attack also coordinates the usage marker; original history remains the rejecting authority.");
''' + needle)
start = s.index('Check(seenBranches.SetEquals(')
end = s.index('await File.WriteAllTextAsync(args[1]', start)
s = s[:start] + '''Check(seenBranches.SetEquals(new[] { "draven-keep", "draven-return", "draven-winning", "draven-winning-return",
    "draven-alt-keep", "draven-alt-return", "draven-alt-winning", "draven-alt-winning-return",
    "forge-generation", "forge-printing", "forge-result-tick" })
    && counts["commands"] == 105 && counts["authority"] == 105 && counts["snapshots"] == 199 && counts["prompts"] == 199
    && counts["prefixReplays"] == 105 && counts["actualForgeryRefusals"] == 3,
    "All11 original rooms,105 original prefixes,199 private rows per table and three actual coordinated forgery refusals.");
''' + s[end:]
s = s.replace('PASS_INDEPENDENT_BATTLE_RESULT_THIRTEEN_ORIGINAL_SQL_ROOMS147_PREFIXES281_EACH_PRIVATE_THREE_ORIGINAL_BIRTH_REFUSALS',
              'PASS_INDEPENDENT_DRAVEN_SCORE_ELEVEN_ORIGINAL_SQL_ROOMS105_PREFIXES199_EACH_PRIVATE_THREE_ORIGINAL_BIRTH_REFUSALS')
s = s.replace('INDEPENDENT_ORIGINAL_BATTLE_RESULT_CONTINUATION_PASS', 'INDEPENDENT_ORIGINAL_DRAVEN_SCORE_PASS')
(project / 'Program.cs').write_text(s)
(project / 'probe.csproj').write_text((old / 'probe.csproj').read_text().replace('IndependentBattleResultSqlOriginalsV5', 'IndependentDravenScoreSqlOriginalsV1'))
print('Independent score reader prepared with literal commands, score/order, source privacy and original-birth assertions')
