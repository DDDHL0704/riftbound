using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using Npgsql;
using Riftbound.Engine;
using Riftbound.Persistence;

if (args.Length != 2 || File.Exists(args[1])) throw new Exception("Original room and fresh original-frame output required.");
var settings = new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
if (settings.Host != "127.0.0.1" || settings.Port != 55486 || settings.Database != "riftbound_here_native"
    || settings.Username != "codex_riftbound_audit") throw new Exception("Only the existing dedicated original native database.");
settings.Options = "-c default_transaction_read_only=on";
await using var database = NpgsqlDataSource.Create(settings.ConnectionString);
await using (var connection = await database.OpenConnectionAsync())
    if ((string)(await new NpgsqlCommand("show transaction_read_only", connection).ExecuteScalarAsync())! != "on")
        throw new Exception("Actual read-only connection required.");
var frame = await new PostgresMatchRecoveryStore(database).LoadAsync(args[0], default) ?? throw new Exception("Actual original frame required.");
if (!frame.IsConsistent || frame.AuthoritativeState!.RuleInputs != RuleInputIdentity.Current) throw new Exception("Consistent matching original runtime required.");
var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
await using (var target = new FileStream(args[1], FileMode.CreateNew))
await using (var compressed = new GZipStream(target, CompressionLevel.SmallestSize))
    await JsonSerializer.SerializeAsync(compressed, frame, json);
Console.WriteLine(JsonSerializer.Serialize(new
{
    status = "ACTUAL_ORIGINAL_FRAME_READONLY_EXPORT",
    room = args[0], commands = frame.Commands.Count, events = frame.Events.Count,
    tick = frame.AuthoritativeState.Tick,
    pendingKind = frame.AuthoritativeState.PendingRuleChoice?.Request.Kind,
    priorAnswers = frame.AuthoritativeState.PendingRuleChoice?.Answers.Count,
    actualRuleInputs = RuleInputIdentity.Current,
    authoritativeStateBytesSha256 = Convert.ToHexStringLower(SHA256.HashData(JsonSerializer.SerializeToUtf8Bytes(frame.AuthoritativeState, json))),
    originalFrameSha256 = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(args[1])))
}, json));
