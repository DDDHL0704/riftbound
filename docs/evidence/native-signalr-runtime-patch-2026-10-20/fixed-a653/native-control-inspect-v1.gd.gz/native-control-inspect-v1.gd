extends SceneTree

var evidence_root: String
var role: String
var main: Node

func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--qa-evidence="): evidence_root = arg.trim_prefix("--qa-evidence=")
		if arg.begins_with("--qa-role="): role = arg.trim_prefix("--qa-role=")
	call_deferred("_run")

func _run() -> void:
	if evidence_root.is_empty() or role not in ["a", "b"]:
		push_error("Exact own evidence directory and role required.")
		quit(1)
		return
	main = load("res://scenes/Main.tscn").instantiate()
	main.set("AutoConnectOnReady", true)
	root.add_child(main)
	var deadline := Time.get_ticks_msec() + 60000
	while Time.get_ticks_msec() < deadline:
		await create_timer(0.1).timeout
		var state := _state()
		var phase_found := false
		for label in state["labels"]:
			if "付款选择" in str(label["text"]): phase_found = true
		if phase_found:
			var path := evidence_root.path_join(role + "-native-control-inspection-v1.json")
			var file := FileAccess.open(path, FileAccess.WRITE)
			file.store_string(JSON.stringify(state, "\t"))
			file.close()
			print("FIXED_NATIVE_HEADLESS_ACTUAL_SCENE_INSPECTION_READY role=", role)
			main.queue_free()
			await process_frame
			quit(0)
			return
	push_error("Actual paired payment phase did not arrive within the bounded native wait.")
	var failure := FileAccess.open(evidence_root.path_join(role + "-native-control-inspection-failure-v1.json"), FileAccess.WRITE)
	failure.store_string(JSON.stringify(_state(), "\t"))
	failure.close()
	quit(1)

func _state() -> Dictionary:
	var labels: Array = []
	var buttons: Array = []
	for node in main.find_children("*", "Label", true, false):
		if node.is_visible_in_tree() and not node.text.is_empty():
			labels.append({"path": str(main.get_path_to(node)), "text": node.text})
	for node in main.find_children("*", "Button", true, false):
		if node.is_visible_in_tree():
			buttons.append({"path": str(main.get_path_to(node)), "text": node.text, "disabled": node.disabled})
	return {"scope": "HEADLESS_PRODUCTION_SCENE_ONLY_NOT_VISIBLE_DESKTOP_OR_WINDOWS_ACCEPTANCE", "role": role,
		"labels": labels, "buttons": buttons, "line_edit_values_and_auth_profiles_not_recorded": true}
