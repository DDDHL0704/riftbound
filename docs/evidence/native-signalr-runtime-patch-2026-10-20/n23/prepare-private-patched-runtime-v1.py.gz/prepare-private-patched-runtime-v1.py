import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile
import urllib.request

os.umask(0o077)
work = Path(__file__).resolve().parent
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
metadata = json.loads(gzip.decompress((work / 'dotnet10-release-metadata-original-response-v1.json.gz').read_bytes()))
release = next(row for row in metadata['releases'] if row['release-version'] == '10.0.13')
selected = next(row for row in release['aspnetcore-runtime']['files'] if row['name'] == 'aspnetcore-runtime-osx-arm64.tar.gz')
destination = work / 'patched-runtime'
assert not destination.exists()
original_global = subprocess.check_output(['/Users/dinghaolin/.dotnet/dotnet', '--list-runtimes'], text=True)
proof = {'status': 'PREPARING_PRIVATE_RUNTIME_NOT_SDK', 'startedAtUtc': now(), 'releaseDate': release['release-date'],
         'globalRuntimeListBefore': original_global, 'globalRuntimeAndSdkNotModified': True,
         'selectedOriginalMetadataSha256': hashlib.sha256((work / 'dotnet10-release-metadata-original-response-v1.json.gz').read_bytes()).hexdigest(),
         'downloadedArchives': [], 'noPersistentPowerOrScreenLockChange': True}
output = work / 'private-patched-runtime-publication-v1.json'
assert not output.exists()


def save():
    output.write_text(json.dumps(proof, indent=2) + '\n')


power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())])
proof.update(ownRunnerPid=os.getpid(), boundIdleAssertionPid=power.pid)
save()
try:
    destination.mkdir()
    required = [selected]
    for item in required:
        archive = work / item['name']
        assert not archive.exists()
        requested = now()
        digest = hashlib.sha512()
        with urllib.request.urlopen(urllib.request.Request(item['url'], headers={'User-Agent': 'Riftbound-runtime-audit'}), timeout=60) as response:
            headers = dict(response.headers)
            status = response.status
            with archive.open('xb') as stream:
                while True:
                    block = response.read(1024 * 1024)
                    if not block:
                        break
                    stream.write(block)
                    digest.update(block)
                    assert stream.tell() < 150 * 2**20
        assert digest.hexdigest() == item['hash']
        with tarfile.open(archive) as packed:
            members = packed.getmembers()
            assert sum(member.size for member in members) < 400 * 2**20
            for member in members:
                target = (destination / member.name).resolve()
                assert target.is_relative_to(destination.resolve())
                assert 'sdk' not in Path(member.name).parts and member.isdir() or (
                    'sdk' not in Path(member.name).parts and (member.isfile() or member.issym() or member.islnk()))
                if member.issym() or member.islnk():
                    link = (target.parent if member.issym() else destination) / member.linkname
                    assert link.resolve().is_relative_to(destination.resolve())
            packed.extractall(destination)
        proof['downloadedArchives'].append({'url': item['url'], 'requestedAtUtc': requested, 'receivedAtUtc': now(),
            'httpStatus': status, 'httpDate': headers.get('Date'), 'bytes': archive.stat().st_size,
            'sha512': digest.hexdigest(), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
            'originalOfficialMetadataHashMatched': True, 'archivePath': str(archive), 'tarEntries': len(members)})
        save()
        if not (destination / 'shared/Microsoft.NETCore.App/10.0.13').exists():
            core = next(row for row in release['runtime']['files'] if row['name'] == 'dotnet-runtime-osx-arm64.tar.gz')
            assert core not in required
            required.append(core)
    assert not (destination / 'sdk').exists()
    actual = subprocess.check_output([str(destination / 'dotnet'), '--list-runtimes'], text=True)
    sdk = subprocess.check_output([str(destination / 'dotnet'), '--list-sdks'], text=True)
    assert sdk == ''
    assert 'Microsoft.NETCore.App 10.0.13' in actual and 'Microsoft.AspNetCore.App 10.0.13' in actual
    assert subprocess.check_output(['/Users/dinghaolin/.dotnet/dotnet', '--list-runtimes'], text=True) == original_global
    files = {str(path.relative_to(destination)): hashlib.sha256(path.read_bytes()).hexdigest()
             for path in sorted(destination.rglob('*')) if path.is_file()}
    proof.update(status='PASS_PRIVATE_ORIGINAL_OFFICIAL_10_0_13_RUNTIME_ONLY_NO_SDK',
                 actualRuntimeList=actual, actualSdkList=sdk, actualRuntimeFileHashes=files,
                 runtimeFileCount=len(files), runtimeLogicalBytes=sum(path.stat().st_size for path in destination.rglob('*') if path.is_file()))
    for item in proof['downloadedArchives']:
        Path(item['archivePath']).unlink()
        item['compressedArchiveRetiredAfterOriginalHashExtractionAndRuntimeVerification'] = True
    save()
except BaseException as error:
    proof.update(status='FAILED_OR_INTERRUPTED_PRIVATE_RUNTIME_PREPARATION_RETAINED',
                 errorType=type(error).__name__, errorMessage=str(error))
    raise
finally:
    if power.poll() is None:
        power.terminate()
        power.wait(timeout=10)
    proof.update(finishedAtUtc=now(), boundIdleAssertionEnded=power.poll() is not None)
    save()
print(proof['status'], proof.get('runtimeFileCount'), proof.get('runtimeLogicalBytes'), flush=True)
