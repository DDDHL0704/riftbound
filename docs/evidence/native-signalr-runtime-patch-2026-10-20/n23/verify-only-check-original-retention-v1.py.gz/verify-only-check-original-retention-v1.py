import collections
import datetime
import hashlib
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

work = Path(__file__).resolve().parent
root = work.parents[2]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
terminal = load(work / 'only-check-terminal-integrity-v2.json')
assert terminal['checkExitCode'] == 0 and terminal['allDeclaredSourceAndRuntimeInputsStable']
assert terminal['boundIdleAssertionEnded'] and terminal['noSecondCheck']
start = load(work / 'only-check-start-inputs-v2.json')
assert sha(work / 'only-check-start-inputs-v2.json') == terminal['sourceManifestSha256']
assert all(sha(root / p) == h for p, h in start['sourceInputHashes'].items())
assert all(sha(root / p) == h for p, h in start['actualConformanceRuntimeFileHashes'].items())
baseline = root / start['unchangedOriginalCaseBaseline']
assert sha(baseline) == start['unchangedOriginalCaseBaselineSha256']


def cases(path):
    tree = ET.parse(path)
    definitions = {d.attrib['id']: d.find('t:TestMethod', ns).attrib
                   for d in tree.findall('.//t:UnitTest', ns)}
    rows = tree.findall('.//t:UnitTestResult', ns)
    assert rows and all(r.attrib['outcome'] == 'Passed' for r in rows)
    methods = {definitions[r.attrib['testId']]['className'] + '.' + definitions[r.attrib['testId']]['name'] for r in rows}
    return collections.Counter(r.attrib['testName'] for r in rows), methods


current_trx = work / 'only-check/check/results.trx'
current, methods = cases(current_trx)
original, old_methods = cases(baseline)
assert current == original and methods == old_methods
assert sum(current.values()) == 13139 and len(methods) == 7479
plan = load(work / 'only-check/plan.json')
assert len(plan['shards']) == 1 and set(plan['shards'][0]['methods']) == methods
summary = load(work / 'only-check/summary.json')
assert summary['status'] == 'PASSED' and summary['profile'] == 'check' and summary['total'] == 13139
assert all(s['total'] == s['passed'] and s['failed'] == s['notExecuted'] == 0 for s in summary['shards'])
host = load(work / 'actual-sole-check-testhost-mapped-framework-v1.json')
assert host['allObservedMappedFrameworkVersions'] == '10.0.13'
assert all(sha(Path(p['path'])) == p['sha256'] for p in host['actualMappedFrameworkFiles'])
before = load(work / 'before-security-dependency-edit-all-source-test-retention-v1.json')
changed = [p for p, h in before['sourceInputHashes'].items() if sha(root / p) != h]
expected = ['Directory.Build.props', 'clients/godot/Riftbound.GodotClient.csproj',
            'src/Riftbound.Api/Riftbound.Api.csproj', 'tests/Riftbound.NativeNetworkSmoke/Riftbound.NativeNetworkSmoke.csproj']
assert sorted(changed) == sorted(expected)
assert len(before['sourceInputHashes']) == 3308
assert all(sha(root / p) == h for p, h in before['originalAllTestToolFileHashes'].items()
           if p != 'tests/Riftbound.NativeNetworkSmoke/Riftbound.NativeNetworkSmoke.csproj')
assert all(sha(root / p) == h for p, h in before['originalNineFullGameFileHashes'].items())
full = {name for p in before['originalNineFullGameFileHashes']
        for name in re.findall(r'\bpublic\s+(?:async\s+)?(?:Task|void)\s+(\w+)\s*\(', (root / p).read_text())}
assert len(full) == 143 and before['retainedPairs'] == 110 and before['retainedDecks'] == 11 and before['retainedSeed'] == 424242
receipt = {
    'status': 'PASS_SOLE_SECURITY_BATCH_CHECK_ENTIRE_CASE_MULTISET_METHODS_SOURCES_AND_ACTUAL_RUNTIME_STABLE',
    'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'baseCommit': start['baseCommit'],
    'totalCases': sum(current.values()), 'passed': sum(current.values()), 'failed': 0, 'skipped': 0,
    'uniqueMethods': len(methods), 'allOriginalCaseMultisetAndMethodsExactlyRetained': True,
    'sourceInputCount': len(start['sourceInputHashes']),
    'actualConformanceRuntimeFileCount': len(start['actualConformanceRuntimeFileHashes']),
    'allSourceAndRuntimeInputsStableThroughTerminal': True, 'exactChangedBuildInputs': changed,
    'allOther3304SourcesByteExact': True, 'originalTestToolFiles': len(before['originalAllTestToolFileHashes']),
    'originalNineFullGameFilesAnd143MethodsByteExact': True, 'retainedPairs': 110, 'retainedDecks': 11,
    'retainedSeed': 424242, 'allOriginalTestMethodsTheoryRowsFixturesVictoryAndReplayAssertionsRetained': True,
    'originalNativeNetworkProgramUnchangedOnlyDependencyProjectVersionChanged': True,
    'baselineTrxSha256': sha(baseline), 'actualTrxSha256': sha(current_trx),
    'actualRuntimeHost': '10.0.13', 'actualOwnedTesthostMappedFrameworkReadback': 'actual-sole-check-testhost-mapped-framework-v1.json', 'summary': summary,
    'originalCliParseOnlyAttemptWasNotAnExecutedCheck': True, 'noSecondCheck': True,
    'fixedCommitFullNativeArtifactAndPhysicalWindowsSeparatelyOpen': True}
output = work / 'only-check-retention-and-disposition-v1.json'
with output.open('x') as f:
    f.write(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: v for k, v in receipt.items() if k != 'summary'}))
