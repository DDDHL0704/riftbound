import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

work = Path(__file__).resolve().parent
root = work.parents[2]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
publication = json.loads((work / 'patched-production-runtime-publication-v1.json').read_text())
focus = json.loads((work / 'focus-native-auth-identity-prompts-v1/summary.json').read_text())
positive = json.loads((work / 'actual-real-patched-network-verification-v1.json').read_text())
assert focus['status'] == 'PASSED' and focus['total'] == 309
assert positive['status'].startswith('PASS_PATCHED_ACTUAL_COMMON8_0_32') and positive['ownApiGracefulExitCode'] == 0
assert positive['ownPostgresSmartStopped'] and positive['boundIdleAssertionEnded']
assert json.loads((work / 'default-host-positive-api-startup-verification-v1.json').read_text())['ownApiGracefulExitCode'] == 0
assert not (work / 'only-check').exists()
inputs = publication['sourceInputHashes']
assert all(sha(root / p) == h for p, h in inputs.items())
folder = root / 'tests/Riftbound.ConformanceTests/bin/Debug/net10.0'
runtime = {str(p.relative_to(root)): sha(p) for p in sorted(folder.rglob('*')) if p.is_file()
           and (p.suffix in {'.dll', '.pdb'} or p.name.endswith(('.deps.json', '.runtimeconfig.json'))
                or p.is_relative_to(folder / 'data') or p.is_relative_to(folder / 'Fixtures'))}
baseline = root / 'var/qa/conditional-counter-payment-audit-20261020/only-check/check/results.trx'
assert sha(baseline) == '3b32d76540788996d34c5e8ddbdee911793e006c81032e8ffd21145b51001cb5'
start = {'atUtc': now(), 'baseCommit': publication['baseCommit'], 'sourceInputHashes': inputs,
         'sourceInputCount': len(inputs), 'actualConformanceRuntimeFileHashes': runtime,
         'actualConformanceRuntimeFileCount': len(runtime), 'unchangedOriginalCaseBaseline': str(baseline.relative_to(root)),
         'unchangedOriginalCaseBaselineSha256': sha(baseline), 'onlyOneCheckForThisSecurityBatch': True,
         'currentFocus309AndRealDbOriginalNetworkPassed': True,
         'currentDefaultHostRuntimeList': subprocess.check_output(['/Users/dinghaolin/.dotnet/dotnet', '--list-runtimes'], text=True),
         'currentSdkList': subprocess.check_output(['/Users/dinghaolin/.dotnet/dotnet', '--list-sdks'], text=True),
         'separateFrozenNativeCandidateAndCiDoNotUseThisRootBin': True}
with (work / 'only-check-start-inputs-v2.json').open('x') as stream:
    stream.write(json.dumps(start, indent=2) + '\n')
power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())])
code = None
try:
    environment = dict(os.environ)
    environment.pop('ConnectionStrings__Riftbound', None)
    environment.pop('DOTNET_STARTUP_HOOKS', None)
    with (work / 'only-check-runner-v2.log').open('xb') as log:
        code = subprocess.run(['python3', str(root / 'scripts/test-rules.py'), 'check', '--jobs', '3',
            '--output', str(work / 'only-check')],
            cwd=root, stdout=log, stderr=subprocess.STDOUT, env=environment).returncode
finally:
    if power.poll() is None:
        power.terminate()
        power.wait(timeout=10)
    changed_source = [p for p, h in inputs.items() if not (root / p).is_file() or sha(root / p) != h]
    changed_runtime = [p for p, h in runtime.items() if not (root / p).is_file() or sha(root / p) != h]
    terminal = {'finishedAtUtc': now(), 'checkExitCode': code,
        'changedSourceInputs': changed_source, 'changedConformanceRuntimeFiles': changed_runtime,
        'allDeclaredSourceAndRuntimeInputsStable': not changed_source and not changed_runtime,
        'boundIdleAssertionEnded': power.poll() is not None, 'noSecondCheck': True,
        'sourceManifestSha256': sha(work / 'only-check-start-inputs-v2.json')}
    with (work / 'only-check-terminal-integrity-v2.json').open('x') as stream:
        stream.write(json.dumps(terminal, indent=2) + '\n')
assert not changed_source and not changed_runtime
print('SOLE_SECURITY_BATCH_CHECK_FINISHED_EXIT_' + str(code), flush=True)
sys.exit(code if code is not None else 1)
