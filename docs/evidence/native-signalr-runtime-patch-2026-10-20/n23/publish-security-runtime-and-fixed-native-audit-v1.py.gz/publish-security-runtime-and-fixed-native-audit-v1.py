import copy
import datetime
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import zipfile

work = Path(__file__).resolve().parent
root = work.parents[2]
fixed = root / 'var/qa/conditional-counter-payment-fixed-a653e547-20261020'
old48 = root / 'var/qa/native-offline-deck-retry-fixed-48e7ff87-20261020'
evidence = root / 'docs/evidence/native-signalr-runtime-patch-2026-10-20'
base = 'a653e54772bddb4ed14d85c4f0b13150f2f3cbfa'
identity = 'native-signalr-dependency-and-runtime-patch-2026-10-20'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as out:
        out.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def pin(path, role=None):
    return {'path': str(path.relative_to(root)), 'sha256': sha(path), 'role': role or path.stem}


assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == base
assert not evidence.exists()
check = load(work / 'only-check-retention-and-disposition-v1.json')
assert check['totalCases'] == check['passed'] == 13139 and check['uniqueMethods'] == 7479
assert check['allOriginalCaseMultisetAndMethodsExactlyRetained'] and check['allSourceAndRuntimeInputsStableThroughTerminal']
publication = load(work / 'patched-production-runtime-publication-v1.json')
assert all(sha(root / p) == h for p, h in publication['sourceInputHashes'].items())
network = load(work / 'actual-real-patched-network-verification-v1.json')
assert network['clientExitCode'] == network['ownApiGracefulExitCode'] == 0
assert network['nativeIdentityRejects'] == 15 and network['actualTokenPossessionRejected']
assert network['ownPostgresSmartStopped'] and network['boundIdleAssertionEnded']
native = load(fixed / 'fixed-native-original-normal-score-independent-readback-v3.json')
assert native['commands'] == 105 and native['events'] == 718 and native['actualNativeButtonCommands'] == 22
assert native['wholeGameNormalScoreCertified'] and native['physicalWindowsNotCertified']
owner = load(fixed / 'fixed-native-control-owner-v1.json')
assert owner['ownApiGracefulExitCode'] == 0 and owner['ownPostgresSmartStopped'] and owner['boundIdleAssertionEnded']
assert owner['allOriginal209AuditSevenTablesExactAtStop'] and owner['allOriginal43NativeSevenTablesExactAtStop']
old_full = load(old48 / 'fixed48-full-ci-terminal-independent-original-readback-v1.json')
assert old_full['actualCompletedSuccessfulJobs'] == 11 and old_full['actualCases'] == 13256 and old_full['actualUniqueMethods'] == 7608
assert load(work / 'python-verification-tools-v1.json')['exitCode'] == 0
manifest_path = root / 'docs/audit/current-manifest.json'
reviews_path = root / 'docs/evidence/rules-reaudit-2026-10-11/review-decisions.json'
prior, old_reviews = load(manifest_path), load(reviews_path)
assert len(prior['reviewContexts']) == 60 and len(prior['acceptanceGates']) == 239 and len(old_reviews['reviews']) == 145
original_ids = set(load(root / 'docs/evidence/conditional-counter-payment-2026-10-20/remaining-obligation-ids.json'))
assert len(original_ids) == 16918 and not prior['semanticCoverageCertified']
for path, filename in [(manifest_path, 'prior-original-current-manifest.json.gz'),
                       (reviews_path, 'prior-original-review-decisions.json.gz')]:
    target = work / filename
    assert not target.exists()
    target.write_bytes(gzip.compress(path.read_bytes(), mtime=0))

# Preserve original evidence, excluding auth profiles and every runtime/install/cache tree.
profiles = [fixed / 'session-a.json', fixed / 'session-b.json',
            fixed / 'actual-native-control-prefix-v1/session-native-a.json',
            fixed / 'actual-native-control-prefix-v1/session-native-b.json']
secrets = [load(p)[key].encode() for p in profiles for key in ['playerKey', 'reconnectToken']]
assert len(secrets) == 8 and all(len(s) > 10 for s in secrets)
source_exts = {'.py', '.cs', '.csproj', '.gd', '.c', '.trx', '.log', '.ndjson', '.md', '.txt'}
raw_exts = {'.json', '.gz', '.png', '.jpg', '.jpeg', '.webp', '.zip'}
excluded = {'bin', 'obj', 'out', '__pycache__', 'patched-runtime', 'patched-api-v1',
            'patched-native-network-v1', 'fixed-api', 'reader-runtime', 'normal-score-reader-runtime-v3', 'native-payment-prefix'}
archive = []


def archive_file(path, group, folder, verify_only=False):
    rel = path.relative_to(folder)
    if (path in profiles or path.name.startswith('session-') or 'draft' in path.name
            or any(part in excluded or part.endswith('.app') for part in rel.parts)
            or path.name.endswith(('.deps.json', '.runtimeconfig.json'))
            or path.name in {'mac-ci-artifact.zip', 'windows-ci-artifact.zip'}
            or path.suffix not in source_exts | raw_exts):
        return
    original = path.read_bytes()
    if path.suffix == '.gz':
        blocks = [gzip.decompress(original)]
    elif path.suffix == '.zip':
        with zipfile.ZipFile(path) as z:
            assert z.testzip() is None
            blocks = [z.read(name) for name in z.namelist() if not name.endswith('/')]
    else:
        blocks = [original]
    assert not any(secret in block for secret in secrets for block in blocks), str(rel)
    if verify_only:
        return
    compressed = path.suffix in source_exts
    target = evidence / group / rel
    if compressed:
        target = target.with_name(target.name + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    assert not target.exists()
    if compressed:
        target.write_bytes(gzip.compress(original, mtime=0))
    else:
        os.link(path, target)
    assert (gzip.decompress(target.read_bytes()) if compressed else target.read_bytes()) == original
    assert target.stat().st_size < 10 * 2**20
    archive.append({'originalPath': str(path.relative_to(root)), 'originalSha256': sha(path),
                    'originalBytes': len(original), 'canonical': pin(target),
                    'gzipOriginalBytes': compressed, 'samePhysicalFileHardlinked': not compressed})


archive_inputs = []
for folder, group in [(work, 'n23'), (fixed, 'fixed-a653')]:
    archive_inputs.extend((path, group, folder) for path in sorted(folder.rglob('*')) if path.is_file())
for filename in ['fixed48-full-ci-terminal-independent-original-readback-v1.json',
                 'verify-fixed48-terminal-original-ci-v2.py', 'fixed48-terminal-artifacts-v1.json',
                 'ci-progress-during-following-security-batch-v6.json',
                 'full-terminal-reader-zip-layout-correction-disposition-v1.json']:
    archive_inputs.append((old48 / filename, 'fixed48-terminal', old48))
existing = {sha(p) for p in (root / 'docs/evidence/conditional-counter-payment-2026-10-20').rglob('*') if p.is_file()}
for path in sorted((old48 / 'ci-originals').glob('39365877913-*.zip')):
    if sha(path) not in existing:
        archive_inputs.append((path, 'fixed48-terminal', old48))
for verify_only in [True, False]:
    for path, group, folder in archive_inputs:
        archive_file(path, group, folder, verify_only)
write(evidence / 'archive-map.json', {'records': archive, 'allOriginalBytesAndHashesVerified': True,
      'eightPrivateProfileValuesScannedWithoutDisclosure': True, 'allPrivateAuthProfilesExcluded': True,
      'allRuntimeSdkInstallPackagesDatabaseAndUnneededCacheExcluded': True,
      'originalSourceLogsFailuresTrxVisualCapturesAndFramesRetained': True})


def archived(name, role=None, group='n23'):
    return pin(evidence / group / name, role)


check_pin = archived('only-check-retention-and-disposition-v1.json', 'sole-check13139-entire-case-and-input-retention')
network_pin = archived('actual-real-patched-network-verification-v1.json', 'patched-actual-common-versions-real-db-original-network')
sources_pin = archived('current-primary-patched-version-readback-v2.json', 'primary-publisher-and-official-runtime-source-readback')
runtime_pin = archived('private-patched-runtime-publication-v1.json', 'official-sha512-private-runtime-no-sdk')
default_pin = archived('default-user-runtime-additive-patch-verification-v1.json', 'additive-default-runtime-333-hardlinks-no-old-file-overwrite')
default_start_pin = archived('default-host-positive-api-startup-verification-v1.json', 'actual-default-host-framework13-startup')
negative_pin = archived('old-common-transitive-audit-policy-negative-verification-v1.json', 'original-common-transitive-nu1903-negative')
old_host_pin = archived('actual-runtime-minimum-old-host-negative-verification-v1.json', 'actual-old-host-exit150-before-managed-start')
native_pin = archived('fixed-native-visible-controls-and-normal-score-publication-v1.json', 'fixed-a653-visible-controls-reconnect-normal-score', 'fixed-a653')
native_reader_pin = archived('fixed-native-original-normal-score-independent-readback-v3.json', 'fixed-a653-all-original-private-history-and-entire-replay', 'fixed-a653')
native_owner_pin = archived('fixed-native-control-owner-v1.json', 'fixed-a653-original209-and43-seven-table-invariance-normal-stop', 'fixed-a653')
old_full_pin = archived('fixed48-full-ci-terminal-independent-original-readback-v1.json', 'previous-fixed48-actual-full-terminal-all-original-artifacts', 'fixed48-terminal')
ci_progress_pin = archived('ci-progress-at-security-publication-v4.json', 'fixed-a653-actual-ci-at-security-publication', 'fixed-a653')
ci = load(fixed / 'ci-progress-at-security-publication-v4.json')['actualRun']
assert ci['headSha'] == base
ci_text = '实际仍在运行，规则与SQL0待终态，其他已完成子任务按原收据记录，不算整体通过' if ci['status'] != 'completed' else '已取得实际终态，按原收据限定使用；本批补丁尚不在该提交内'
impl_paths = ['Directory.Build.props', 'clients/godot/Riftbound.GodotClient.csproj',
              'src/Riftbound.Api/Riftbound.Api.csproj', 'tests/Riftbound.NativeNetworkSmoke/Riftbound.NativeNetworkSmoke.csproj']
source_manifest = {'recordedAtUtc': now(), 'scope': 'Software dependency/runtime patch and separate preceding fixed native product evidence; no game source adoption.',
    'region': 'CROSS_PLATFORM_SOFTWARE', 'language': 'en-US', 'applicabilityObservedAt': '2026-10-20',
    'baseCommit': base, 'includesUncommittedFourBuildInputChanges': True,
    'publisherAdvisory': {'id': 'GHSA-334f-vvp4-7g6p', 'cve': 'CVE-2026-70159',
        'url': 'https://github.com/dotnet/aspnetcore/security/advisories/GHSA-334f-vvp4-7g6p',
        'publishedAt': '2026-10-13T18:22:57Z', 'updatedAt': '2026-10-15T21:43:58Z',
        'effectiveDateSeparateFromPublication': None, 'originalSources': sources_pin},
    'patchedClientCommon': '8.0.32', 'minimumApiSharedFramework': '10.0.13',
    'implementation': [pin(root / p, 'implementation') for p in impl_paths],
    'originalNu1903Negative': negative_pin, 'actualOldHostExit150': old_host_pin,
    'privateOfficialRuntime': runtime_pin, 'subsequentDefaultUserRuntimeAddition': default_pin,
    'actualDefaultHostApiStartup': default_start_pin, 'actualPatchedRealDatabaseNetwork': network_pin,
    'soleCheck': check_pin, 'currentFocusCases': 309, 'currentFocusMethods': 260,
    'originalTestsToolCount': 1863, 'allOriginalMethodTheoryFixtureFullGameSeedVictoryReplayAssertionsRetained': True,
    'allOther3304SourcesByteExact': True, 'defaultSqlAll46IdentitiesAndOrderUnchanged': True,
    'currentActualRuleInputs': publication['actualRuleInputs'], 'actualThreeRuleModulesByteExactToFixedA653': True,
    'precedingFixedNativeVisibleProduct': native_pin, 'precedingFixedNativeEntireHistoryReadback': native_reader_pin,
    'precedingFixedNativeOwnerAndOriginalDatabaseInvariance': native_owner_pin,
    'precedingFixedNativeContainsOldClientCommonNotNewSecurityCandidate': True,
    'previousFixed48ActualFullCi': old_full_pin, 'fixedA653CiProgress': ci_progress_pin,
    'currentSecurityCandidateFixedFullAndPatchedDesktopArtifactReadback': 'OPEN_AFTER_COMMIT',
    'currentSecurityCandidateVisibleNativeAndPhysicalWindows': 'OPEN',
    'adoptedGameSourceRegion': 'CN', 'adoptedGameSourceLanguage': 'zh-CN', 'adoptedCoreEffectiveDate': '2026-10-16',
    'newGameSourceDelta': False, 'sixOriginalGameSourceDeltasUnchanged': True,
    'actualExploitOrAllDeploymentImmunityNotClaimed': True,
    'wholePrintingFamilyOrGlobalSemanticsCertified': False,
    'onlyLatestUsableA653NativePairAndOnePackagePerOs': True, 'noNewSdkWholeCheckoutOrDatabase': True}
write(evidence / 'source-manifest.json', source_manifest)
manifest_pin = pin(evidence / 'source-manifest.json', 'source-manifest')
document_path = root / 'docs/NATIVE_SIGNALR_RUNTIME_PATCH_AUDIT_2026-10-20.md'
assert not document_path.exists()
document = (work / 'native-signalr-runtime-patch-audit-draft-v1.md').read_text()
document = document.replace('@CHECK_CASES@', str(check['totalCases'])).replace('@CHECK_METHODS@', str(check['uniqueMethods'])).replace('@A653_CI@', ci_text)
assert '@' not in document
document_path.write_text(document)
reviews = copy.deepcopy(old_reviews)
reviews['reviews'].append({'id': identity, 'scope': source_manifest['scope'],
    'status': 'BOUNDED_DEPENDENCY_PATCH_ACTUAL_RUNTIME_NETWORK_CHECK_PASS_NEW_FIXED_FULL_PATCHED_ARTIFACTS_NATIVE_WINDOWS_OPEN',
    'subjects': [], 'ruleRecords': [], 'pendingRuleRecords': [], 'sourceManifest': manifest_pin,
    'auditDocument': str(document_path.relative_to(root)),
    'validation': {'focusCases': 309, 'focusMethods': 260, 'soleCheckCases': 13139, 'soleCheckMethods': 7479,
        'actualPatchedNetworkIdentityRejects': 15, 'originalAssertionsRetained': True,
        'precedingFixedNativeOriginalCommands': 105, 'precedingFixedNativeOriginalEvents': 718},
    'exclusions': ['ACTUAL_EXPLOIT_OR_BLANKET_RUNTIME_IMMUNITY', 'NEW_SECURITY_FIXED_FULL',
        'NEW_SECURITY_DESKTOP_ARTIFACTS_AND_VISIBLE_PRODUCT', 'PHYSICAL_WINDOWS', 'WHOLE_CARD_AND_ALL_ORIGINAL_GAME_SOURCE_OBLIGATIONS']})
reviews_path.write_text(json.dumps(reviews, ensure_ascii=False, indent=2) + '\n')
spec = importlib.util.spec_from_file_location('governance', root / 'scripts/audit/check-project-governance.py')
checker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checker)
revision = checker.digest(checker.gameplay_inputs(root))
manifest = copy.deepcopy(prior)
prior_pin = archived('prior-original-current-manifest.json.gz', 'previous-entire-current-manifest')
rebindings = []
for key, context in manifest['reviewContexts'].items():
    changes = []
    for field in ['implementation', 'verificationSources']:
        for ref in context.get(field, []):
            actual = sha(root / ref['path'])
            if actual != ref['sha256']:
                changes.append({'field': field, 'path': ref['path'], 'previousSha256': ref['sha256'], 'currentSha256': actual})
                ref['sha256'] = actual
    previous = {field: context.get(field) for field in ['currentInputRevision', 'currentImplementationCommit',
                'currentImplementationIncludesUncommittedChanges', 'ciState']}
    context.setdefault('implementationPinUpdates', []).append({'batch': identity, 'changes': changes,
        'previousCurrentMetadata': previous, 'previousEntireContextPreservedIn': prior_pin,
        'scope': 'Four dependency/build inputs only. All original rules/modules, scopes, source versions and evidence retained; new fixed full/product separately required.'})
    context.update(currentInputRevision=revision, currentImplementationCommit=base,
                   currentImplementationIncludesUncommittedChanges=True, ciState='PENDING',
                   revalidationReason='Explicit all-transitive audit, SignalR patched dependencies and minimum API shared runtime; no gameplay source change.')
    rebindings.append({'review': key, 'previousEntireContextSha256': checker.digest(prior['reviewContexts'][key]), 'changedPins': changes})
manifest['inputs']['reviews'] = pin(reviews_path, prior['inputs']['reviews'].get('role', 'reviews'))
manifest['reviewContexts'][identity] = {'evidenceCommit': base, 'currentImplementationCommit': base,
    'currentImplementationIncludesUncommittedChanges': True, 'currentInputRevision': revision,
    'evidenceCommitScope': 'Basea653 plus four declared dependency/build changes; separate preceding native candidate remains exact a653.',
    'ciState': 'PENDING', 'ciReceipts': [], 'region': 'CROSS_PLATFORM_SOFTWARE', 'language': 'en-US',
    'applicableAsOf': '2026-10-20', 'sourceManifest': manifest_pin,
    'implementation': source_manifest['implementation'], 'verificationSources': [pin(root / 'tests/Riftbound.NativeNetworkSmoke/Program.cs', 'unchanged-original-network-assertions')],
    'evidence': [sources_pin, check_pin, network_pin, runtime_pin, default_pin, default_start_pin,
        negative_pin, old_host_pin, native_pin, native_reader_pin, native_owner_pin, old_full_pin, ci_progress_pin], 'branches': []}
for gate in manifest['acceptanceGates']:
    if gate['id'] == 'NATIVE_SIGNALR_COMMON_CVE_2026_70159_ACTUAL_DEPENDENCY_PATCH_RUNTIME_AND_NETWORK_ACCEPTANCE':
        gate['currentBoundedPatchReadback'] = {'sourceManifest': manifest_pin, 'actualPatchedNetwork': network_pin,
            'soleCheck': check_pin, 'actualOldHostRejected': old_host_pin,
            'newFixedFullPatchedArtifactsNativeAndWindowsRemainOpen': True, 'allOriginalRequirementsRetained': True}
    if gate['id'] == 'CONDITIONAL_COUNTER_PAYMENT_CURRENT_FIXED_FULL_NATIVE_PAIRED_RECONNECT_SCORE_REPLAY_AND_WINDOWS':
        gate['postCommitFixedA653ActualVisibleProduct'] = {'fixedCommit': base, 'visibleNative': native_pin,
            'independentOriginalFullReplay': native_reader_pin, 'originalDatabaseInvariantAndNormalStop': native_owner_pin,
            'fixedCiProgress': ci_progress_pin, 'physicalWindowsStillOpen': True,
            'newSecurityPatchCandidateNotCovered': True, 'allOriginalRequirementsRetained': True}
    if gate['id'] == 'NATIVE_OFFLINE_START_SAME_SERVER_DECK_RETRY_NEW_FIXED_NATIVE_FULL_AND_WINDOWS':
        gate['postCommitFixed48ActualFullCiTerminal'] = {'fixedCommit': old_full['fixedCommit'], 'actualFull': old_full_pin,
            'physicalWindowsStillOpen': True, 'newA653AndSecurityPatchNotCovered': True,
            'allOriginalRequirementsRetained': True}
manifest['currentNativeSignalrDependencyRuntimePatch'] = manifest_pin
manifest['currentFixedA653VisiblePaymentNormalScoreReadback'] = native_pin
manifest['previousFixed48ActualFullCiReadback'] = old_full_pin
result = checker.current_audit(root, manifest)
assert result['governanceValid'], result['errors']
ids = {row['id'] for row in result['remainingObligations']}
assert ids == original_ids and reviews['reviews'][:-1] == old_reviews['reviews']
assert manifest['laterSourceDeltas'] == prior['laterSourceDeltas'] and len(prior['laterSourceDeltas']) == 6
for old_gate, new_gate in zip(prior['acceptanceGates'], manifest['acceptanceGates']):
    assert all(new_gate[key] == value for key, value in old_gate.items())
assert len(manifest['reviewContexts']) == 61 and len(manifest['acceptanceGates']) == 239
manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
write(evidence / 'remaining-obligation-ids.json', sorted(ids))
write(evidence / 'current-context-rebindings.json', {'priorEntireManifest': prior_pin,
    'allOriginal60ContextsAndScopesPreserved': True, 'newInputRevision': revision,
    'changedContexts': [row for row in rebindings if row['changedPins']]})
write(evidence / 'unified-obligation-retention.json', {'priorReviews': 145, 'currentReviews': 146,
    'priorContexts': 60, 'currentContexts': 61, 'priorGates': 239, 'currentGates': 239,
    'priorObligations': 16918, 'currentObligations': len(ids), 'allOriginalIdsExactlyRetained': True,
    'allOriginal145Reviews239GateKeyValuesAndSixGameSourceDeltasRetained': True,
    'allOriginal1740Printings14293RuleBlocksEn8GapsCn236DispositionsRemain': True,
    'noSoftwarePatchAsGameSourceDelta': True, 'semanticCoverageCertified': False})
compact = {key: value for key, value in result.items() if key not in ['inputManifest', 'reviewView', 'remainingObligations', 'laterSourceDeltas']}
compact['remainingObligationCount'] = len(ids)
write(evidence / 'governance-validation.json', compact)
status_path = root / 'docs/PROJECT_STATUS.md'
status = status_path.read_text(); marker = '# 当前项目状态\n\n'
assert status.startswith(marker)
lead = (work / 'project-status-lead-draft-v1.md').read_text()
lead = lead.replace('@CHECK_CASES@', str(check['totalCases'])).replace('@CHECK_METHODS@', str(check['uniqueMethods'])).replace('@A653_CI@', ci_text)
assert '@' not in lead
status_path.write_text(marker + lead + '\n' + status[len(marker):])
assert all(sha(root / p) == h for p, h in publication['sourceInputHashes'].items())
print(json.dumps({'status': 'PUBLISHED_BOUNDED_SOFTWARE_PATCH_AND_SEPARATE_FIXED_NATIVE_SCORE',
    'reviews': 146, 'contexts': 61, 'gates': 239, 'obligations': len(ids), 'archiveRecords': len(archive),
    'newFixedFullArtifactsCurrentNativeAndPhysicalWindowsOpen': True}))
