import ast
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import plistlib
import socket
import subprocess
import time
import urllib.request

os.umask(0o077)
work = Path(__file__).resolve().parent
root = work.parents[2]
pg = Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin')
cluster = root / 'var/qa/permanent-play-here-base-20261017/postgres'
sock = Path('/tmp/rft-here-family-20261018-55486')
tables = ['matches', 'match_players', 'command_log', 'game_events', 'state_snapshots', 'snapshots', 'action_prompts']
read_env = dict(os.environ, PGOPTIONS='-c default_transaction_read_only=on')
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source = root / 'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes = [node for node in ast.parse(source.read_text()).body if isinstance(node, ast.FunctionDef)
         and node.name in {'query', 'rooms', 'digests', 'observe_lock'}]
assert len(nodes) == 4
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(source), 'exec'), globals())
publication = json.loads((work / 'patched-production-runtime-publication-v1.json').read_text())
original = json.loads((root / 'var/qa/conditional-counter-payment-audit-20261020/after-eight-writers-before-readonly-baseline-v3.json').read_text())
output = work / 'actual-real-patched-network-verification-v1.json'
assert not output.exists()
api_rt = work / publication['runtimeFolders']['api']
net_rt = work / publication['runtimeFolders']['nativeNetwork']
runtime = work / publication['runtimeFolders']['privateRuntime']
hook = work / publication['runtimeFolders']['observer'] / 'probe.dll'


def save(value):
    temporary = output.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(output)


def frozen():
    assert all(sha(root / p) == h for p, h in publication['sourceInputHashes'].items())
    for key, folder in publication['runtimeFolders'].items():
        assert all(sha(work / folder / p) == h for p, h in publication['runtimeFiles'][key].items())
    assert all(sha(work / p) == h for p, h in publication['observerSourceHashes'].items())


frozen()
guard = (root / 'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a')
fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
proof = {'status': 'STARTING_PATCHED_RUNTIME_REAL_DATABASE_NETWORK', 'startedAtUtc': now(),
         'baseCommit': publication['baseCommit'], 'includesFourUncommittedBuildInputChanges': True,
         'actualRuleInputs': publication['actualRuleInputs'], 'lockAtStart': observe_lock(),
         'scope': 'Original native network/authentication/reconnect gate with real existing PostgreSQL and actual loaded assembly observation; no visible or Windows claim.'}
save(proof)
started = False
api = client = power = None
before_audit = before_native = None
try:
    assert subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), 'status'], capture_output=True).returncode == 3
    with socket.socket() as port:
        assert port.connect_ex(('127.0.0.1', 15848)) != 0
    power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())])
    proof.update(ownRunnerPid=os.getpid(), boundIdleAssertionPid=power.pid)
    sock.mkdir(exist_ok=True)
    subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-l', str(work / 'actual-network-postgres-v1.log'),
                    '-o', f'-p 55486 -h 127.0.0.1 -k {sock}', '-w', 'start'], capture_output=True, check=True)
    started = True
    assert rooms('riftbound_acceptance') == original['auditRooms'] and len(original['auditRooms']) == 209
    assert rooms('riftbound_here_native') == original['nativeRooms'] and len(original['nativeRooms']) == 42
    before_audit = digests('riftbound_acceptance', original['auditRooms'])
    before_native = digests('riftbound_here_native', original['nativeRooms'])
    assert before_audit == original['auditSevenTables'] and before_native == original['nativeSevenTables']
    api_observed = work / 'actual-api-loaded-assemblies-v1.ndjson'
    client_observed = work / 'actual-native-network-loaded-assemblies-v1.ndjson'
    assert not api_observed.exists() and not client_observed.exists()
    environment = dict(os.environ, ASPNETCORE_ENVIRONMENT='Production', ASPNETCORE_URLS='http://127.0.0.1:15848',
        ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit',
        DOTNET_STARTUP_HOOKS=str(hook), RIFTBOUND_ASSEMBLY_AUDIT=str(api_observed))
    with (work / 'actual-patched-api-network-v1.log').open('xb') as log:
        api = subprocess.Popen([str(runtime / 'dotnet'), str(api_rt / 'Riftbound.Api.dll')], cwd=api_rt,
                               stdout=log, stderr=subprocess.STDOUT, env=environment, start_new_session=True)
    for attempt in range(150):
        assert api.poll() is None
        try:
            with urllib.request.urlopen('http://127.0.0.1:15848/health', timeout=.5) as response:
                health = json.load(response)
            assert health['persistenceMode'] == 'postgres' and health['environment'] == 'Production'
            break
        except OSError:
            time.sleep(.1)
    else:
        raise AssertionError('Owned patched API did not become ready.')
    assert set(subprocess.check_output(['/usr/sbin/lsof', '-tiTCP:15848', '-sTCP:LISTEN'], text=True).splitlines()) == {str(api.pid)}
    proof.update(ownApiPid=api.pid, actualHealth=health)
    negotiations = []
    for requested in [False, True]:
        url = 'http://127.0.0.1:15848/hubs/game/negotiate?negotiateVersion=1' + ('&useStatefulReconnect=true' if requested else '')
        with urllib.request.urlopen(urllib.request.Request(url, data=b'', method='POST'), timeout=5) as response:
            raw = response.read()
        body = json.loads(raw)
        assert body.get('useStatefulReconnect', False) is False
        negotiations.append({'requestedStatefulReconnect': requested, 'actualGrantedStatefulReconnect': body.get('useStatefulReconnect', False),
             'negotiateVersion': body.get('negotiateVersion'), 'availableTransports': body.get('availableTransports'),
             'originalResponseSha256': hashlib.sha256(raw).hexdigest(), 'transportIdAndTokenNotRetained': True})
    proof['actualNegotiationFeatureReadback'] = negotiations
    save(proof)
    with (work / 'actual-patched-native-network-v1.log').open('xb') as log:
        client = subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet', str(net_rt / 'Riftbound.NativeNetworkSmoke.dll')], cwd=net_rt,
              stdout=log, stderr=subprocess.STDOUT, start_new_session=True,
              env=dict(os.environ, RIFTBOUND_SERVER_URL='http://127.0.0.1:15848', DOTNET_STARTUP_HOOKS=str(hook),
                       RIFTBOUND_ASSEMBLY_AUDIT=str(client_observed)))
        proof['ownNativeNetworkPid'] = client.pid
        save(proof)
        code = client.wait(timeout=100)
    assert code == 0, ('Original network gate failed', code)
    log = (work / 'actual-patched-native-network-v1.log').read_text()
    assert '15 rejected actions, three independent connection identities, real-token possession rejected' in log
    assert 'socket loss, authenticated room restore, fresh snapshot, rejected-token guard.' in log
    server_rows = [json.loads(line) for line in api_observed.read_text().splitlines()]
    client_rows = [json.loads(line) for line in client_observed.read_text().splitlines()]
    server_common = next(row for row in server_rows if row['name'] == 'Microsoft.AspNetCore.SignalR.Common')
    client_common = next(row for row in client_rows if row['name'] == 'Microsoft.AspNetCore.SignalR.Common')
    assert server_common['informationalVersion'].startswith('10.0.13') and server_common['sha256'] == sha(runtime / 'shared/Microsoft.AspNetCore.App/10.0.13/Microsoft.AspNetCore.SignalR.Common.dll')
    assert client_common['informationalVersion'].startswith('8.0.32') and client_common['sha256'] == sha(net_rt / 'Microsoft.AspNetCore.SignalR.Common.dll')
    assert server_common['processId'] == api.pid and client_common['processId'] == client.pid
    core = next(row for row in server_rows if row['name'] == 'System.Private.CoreLib')
    assert core['sha256'] == sha(runtime / 'shared/Microsoft.NETCore.App/10.0.13/System.Private.CoreLib.dll')
    added = sorted(set(rooms('riftbound_here_native')) - set(original['nativeRooms']))
    assert len(added) == 1 and added[0].startswith('NETWORK-')
    assert digests('riftbound_acceptance', original['auditRooms']) == before_audit
    assert digests('riftbound_here_native', original['nativeRooms']) == before_native
    proof.update(status='PASS_PATCHED_ACTUAL_COMMON8_0_32_AND_SERVER10_0_13_REAL_DB_ORIGINAL15_REJECTS_AUTH_SOCKET_RECOVERY',
                 clientExitCode=code, actualServerCommon=server_common, actualClientCommon=client_common,
                 actualServerCoreRuntime=core, nativeIdentityRejects=15, actualTokenPossessionRejected=True,
                 originalSocketLossAuthenticatedRestoreFreshSnapshotInvalidTokenGuardPassed=True,
                 actualNewRoom=added[0], allOriginal209Audit42NativeSevenTablesExact=True,
                 newRoomSevenTableDigests=digests('riftbound_here_native', added),
                 sourceOnlyOrVersionStringOnlyNotUsedAsRuntimeProof=True,
                 visibleNativeCurrentFixedFullAndPhysicalWindows='OPEN')
except BaseException as error:
    proof.update(status='FAILED_OR_INTERRUPTED_PATCHED_NETWORK_ORIGINAL_ROOM_RETAINED',
                 errorType=type(error).__name__, errorMessage=str(error))
    raise
finally:
    if client is not None and client.poll() is None:
        client.terminate()
        client.wait(timeout=20)
    if api is not None and api.poll() is None:
        api.terminate()
        proof['ownApiGracefulExitCode'] = api.wait(timeout=30)
    if started:
        if before_audit is not None:
            proof['allPrior209AuditSevenTablesStillExactAtStop'] = digests('riftbound_acceptance', original['auditRooms']) == before_audit
            proof['allPrior42NativeSevenTablesStillExactAtStop'] = digests('riftbound_here_native', original['nativeRooms']) == before_native
        proof['ownPostgresSmartStopped'] = subprocess.run([str(pg / 'pg_ctl'), '-D', str(cluster), '-m', 'smart', '-w', '-t', '20', 'stop'], capture_output=True).returncode == 0
    if power is not None:
        if power.poll() is None:
            power.terminate()
            power.wait(timeout=10)
        proof['boundIdleAssertionEnded'] = power.poll() is not None
    frozen()
    proof.update(finishedAtUtc=now(), lockAtEnd=observe_lock(), frozenSourcesAllRuntimeAndObserverInputsExact=True, originalDatabaseRetained=True)
    save(proof)
    fcntl.flock(guard, fcntl.LOCK_UN)
print(proof['status'], flush=True)
