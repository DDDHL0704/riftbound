using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;

public static class StartupHook
{
    private static readonly object Gate = new();
    private static readonly HashSet<string> Seen = new(StringComparer.Ordinal);

    public static void Initialize()
    {
        AppDomain.CurrentDomain.AssemblyLoad += (_, args) => Record(args.LoadedAssembly);
        foreach (var assembly in AppDomain.CurrentDomain.GetAssemblies()) Record(assembly);
    }

    private static void Record(Assembly assembly)
    {
        var name = assembly.GetName().Name ?? "";
        if (!(name.StartsWith("Riftbound.", StringComparison.Ordinal)
            || name.StartsWith("Microsoft.AspNetCore.SignalR.", StringComparison.Ordinal)
            || name == "System.Private.CoreLib")) return;
        var output = Environment.GetEnvironmentVariable("RIFTBOUND_ASSEMBLY_AUDIT");
        if (string.IsNullOrEmpty(output)) throw new InvalidOperationException("Exact private assembly-observer output required.");
        lock (Gate)
        {
            if (!Seen.Add(name)) return;
            var path = assembly.Location;
            if (string.IsNullOrEmpty(path)) throw new InvalidOperationException("Original file-backed assembly required: " + name);
            var record = new
            {
                observedAtUtc = DateTimeOffset.UtcNow,
                processId = Environment.ProcessId,
                name,
                assemblyVersion = assembly.GetName().Version?.ToString(),
                informationalVersion = assembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>()?.InformationalVersion,
                mvid = assembly.ManifestModule.ModuleVersionId,
                path,
                sha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path))).ToLowerInvariant()
            };
            File.AppendAllText(output, JsonSerializer.Serialize(record) + "\n");
        }
    }
}
