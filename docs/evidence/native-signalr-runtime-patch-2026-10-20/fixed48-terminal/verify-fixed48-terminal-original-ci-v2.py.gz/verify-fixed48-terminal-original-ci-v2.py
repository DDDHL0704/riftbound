import collections
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

work = Path(__file__).resolve().parent
root = work.parents[2]
fixed = '48e7ff8702dc43a1b5a3991365d87068506ae137'
run = 39365877913
sha = lambda b: hashlib.sha256(b).hexdigest()
ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
terminal = json.loads((work / 'ci-progress-during-following-security-batch-v6.json').read_text())
assert terminal['headSha'] == fixed and terminal['status'] == 'completed' and terminal['conclusion'] == 'success'
assert len(terminal['jobs']) == 11 and all(j['status'] == 'completed' and j['conclusion'] == 'success' for j in terminal['jobs'])
metadata = {a['name']: a for a in json.loads((work / 'fixed48-terminal-artifacts-v1.json').read_text())['artifacts']}
verified_artifacts = {}

def original(name):
    path = work / 'ci-originals' / (str(run) + '-' + name + '.zip')
    data = path.read_bytes()
    assert len(data) == metadata[name]['size_in_bytes'] and 'sha256:' + sha(data) == metadata[name]['digest']
    z = zipfile.ZipFile(path)
    assert z.testzip() is None
    verified_artifacts[name] = {'path': str(path.relative_to(root)), 'sha256': sha(data), 'bytes': len(data)}
    return z

def parse_cases(archive, require_plan):
    cases = collections.Counter()
    methods = set()
    trx_hashes = {}
    matrices = []
    plan = json.loads(archive.read('ci-rules/plan.json'))
    summary = json.loads(archive.read('ci-rules/summary.json'))
    assert summary['status'] == 'PASSED' and summary['profile'] == 'full'
    assert all(s['total'] == s['passed'] and s['failed'] == s['notExecuted'] == 0 for s in summary['shards'])
    planned = [m for s in plan['shards'] for m in s['methods']]
    assert len(planned) == len(set(planned)) == plan['discoveredMethods']
    for name in archive.namelist():
        if not name.endswith('/results.trx'):
            continue
        raw = archive.read(name)
        trx_hashes[name] = sha(raw)
        tree = ET.fromstring(raw)
        defs = {d.attrib['id']: d.find('t:TestMethod', ns).attrib for d in tree.findall('.//t:UnitTest', ns)}
        shard_methods = set()
        for row in tree.findall('.//t:UnitTestResult', ns):
            assert row.attrib['outcome'] == 'Passed'
            d = defs[row.attrib['testId']]
            method = d['className'] + '.' + d['name']
            methods.add(method)
            shard_methods.add(method)
            cases[row.attrib['testName']] += 1
            for stdout in row.findall('.//t:StdOut', ns):
                for line in (stdout.text or '').splitlines():
                    if line.startswith('PRECONSTRUCTED_MATRIX '):
                        matrices.append(json.loads(line[len('PRECONSTRUCTED_MATRIX '):]))
        assert shard_methods == set(next(s['methods'] for s in plan['shards'] if s['name'] == name.split('/')[-2]))
    assert methods == set(planned) and sum(cases.values()) == summary['total']
    assert len(matrices) == 1
    return cases, methods, trx_hashes, matrices[0], plan, summary

with original('conformance-results') as z:
    assert z.read('ci-rule-suite-commit.txt').decode().strip() == fixed
    cases, methods, trx_hashes, matrix, plan, summary = parse_cases(z, True)
assert sum(cases.values()) == 13256 and len(methods) == 7608
with zipfile.ZipFile(root / 'var/qa/native-offline-deck-retry-20261020/ci-originals/39352144607-conformance-results.zip') as z:
    old_cases, old_methods, _, _, _, _ = parse_cases(z, True)
assert cases == old_cases and methods == old_methods
added = cases - old_cases
full_sources = sorted((root / 'tests/Riftbound.ConformanceTests').glob('FullGameEndToEndTests*.cs'))
expected_full = {'Riftbound.ConformanceTests.FullGameEndToEndTests.' + n for p in full_sources
                 for n in re.findall(r'\bpublic\s+(?:async\s+)?(?:Task|void)\s+(\w+)\s*\(', p.read_text())}
assert len(full_sources) == 9 and len(expected_full) == 143
assert {m for m in methods if m.startswith('Riftbound.ConformanceTests.FullGameEndToEndTests.')} == expected_full
decks = json.loads(gzip.decompress((work.parent / 'graveyard-source-fixed-candidate-20261020/native-visible-v1/live-api-eleven-preconstructed-decks-original.json.gz').read_bytes()))
deck_ids = [d['id'] for d in decks]
assert len(deck_ids) == len(set(deck_ids)) == 11
expected_pairs = {a + '-vs-' + b for a in deck_ids for b in deck_ids if a != b}
assert matrix['seed'] == 424242 and matrix['deckCount'] == 11 and matrix['pairCount'] == 110
assert len(matrix['completed']) == 110 and set(matrix['completed']) == expected_pairs
assert all(re.fullmatch('[0-9a-f]{64}', v) for v in matrix['completed'].values())

manifest_bytes = subprocess.check_output(['git','show',fixed+':tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'], cwd=root)
ids = [c['id'] for c in json.loads(manifest_bytes)['cases']]
assert len(ids) == len(set(ids)) == 45
parts = []
for i in range(4):
    with original('postgres-partition-' + str(i)) as z:
        receipt_raw = z.read('ci-postgres/partition-receipt.json')
        d = json.loads(receipt_raw)
        assert d['status'] == 'REAL_POSTGRES_PARTITION_COMPLETE' and d['fixedCommit'] == fixed
        assert d['manifestSha256'] == sha(manifest_bytes) and d['orderedDefaultCases'] == ids
        assert d['partitionIndex'] == i and d['partitionCount'] == 4
        assert d['expectedCases'] == d['completedCases'] == [e['id'] for e in d['executions']] == ids[i::4]
        assert [e['ordinal'] for e in d['executions']] == list(range(i, len(ids), 4))
        assert all(e['status'] == 'PASSED' for e in d['executions'])
        for row in d['outputFiles']:
            data = z.read('ci-postgres/' + row['path'])
            assert len(data) == row['bytes'] and sha(data) == row['sha256']
        parts.append({'partitionIndex': i, 'cases': ids[i::4], 'receiptSha256': sha(receipt_raw),
                      'outputs': len(d['outputFiles']), 'actualRuleInputs': d['actualRuleInputs'], 'runtimeAssemblies': d['runtimeAssemblies']})
assert len({json.dumps(p['actualRuleInputs'], sort_keys=True) for p in parts}) == 1
assert len({json.dumps(p['runtimeAssemblies'], sort_keys=True) for p in parts}) == 1
with original('postgres-results') as z:
    gate = json.loads(z.read('result.json'))
    assert gate['status'] == 'FIXED_COMMIT_ALL_SQL_PARTITIONS_AND_NATIVE_NETWORK_PASS' and gate['fixedCommit'] == fixed
    assert gate['manifestSha256'] == sha(manifest_bytes) and gate['caseCount'] == 45 and gate['orderedDefaultCases'] == ids
    assert all(v == 'success' for v in gate['jobs'].values())
    for g, p in zip(gate['partitions'], parts):
        assert all(g[k] == p[k] for k in ['partitionIndex', 'cases', 'receiptSha256', 'actualRuleInputs', 'runtimeAssemblies'])
with original('native-network-results') as z:
    network_logs = {n: sha(z.read(n)) for n in z.namelist()}
    log_name = next(n for n in z.namelist() if n.endswith('native-network.log'))
    network_log = z.read(log_name).decode()
    assert '15 rejected actions, three independent connection identities, real-token possession rejected' in network_log
    assert 'socket loss, authenticated room restore, fresh snapshot, rejected-token guard.' in network_log
with original('full-verification-gate') as z:
    full_gate = json.loads(z.read('result.json'))
    assert full_gate['status'] == 'FIXED_COMMIT_FULL_CHILD_JOBS_ALL_SUCCEEDED' and full_gate['commit'] == fixed
    assert all(v == 'success' for v in full_gate['jobs'].values())
out = work / 'fixed48-full-ci-terminal-independent-original-readback-v1.json'
assert not out.exists()
result = {'status': 'PASS_FIXED48_ACTUAL_FULL_CI_ORIGINAL_TRX_143_FULLGAME_METHODS_110_PAIRS_45_SQL',
          'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'fixedCommit': fixed, 'runId': run,
          'actualCompletedSuccessfulJobs': len(terminal['jobs']), 'actualCases': sum(cases.values()), 'actualUniqueMethods': len(methods),
          'allPrior13256CaseMultisetAnd7608MethodsExactlyEqual': True, 'addedCases': dict(added),
          'addedMethods': sorted(methods - old_methods), 'fullGameMethods': sorted(expected_full),
          'preconstructedMatrix': matrix, 'allOriginalTrxHashes': trx_hashes, 'testAssemblySha256': plan['testAssemblySha256'],
          'partitions': parts, 'actualSqlOutputFileCount': sum(p['outputs'] for p in parts),
          'verifiedOriginalArtifacts': verified_artifacts, 'networkOriginalFileHashes': network_logs,
          'priorIndependentNetworkReadbackSha256': sha((work / 'current48-original-network-content-independent-readback-v1.json').read_bytes()),
          'fixed48MacReleaseIdentityIsSeparate': True, 'newA653AndDirtySecurityBatchNotCovered': True,
          'wholeCardSemanticOrPhysicalWindowsCertification': False}
out.write_text(json.dumps(result, indent=2) + '\n')
print(result['status'], result['actualCases'], result['actualUniqueMethods'], result['actualSqlOutputFileCount'], flush=True)
