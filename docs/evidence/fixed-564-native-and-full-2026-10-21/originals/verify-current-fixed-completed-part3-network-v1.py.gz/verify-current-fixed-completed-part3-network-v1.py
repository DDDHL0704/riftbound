import datetime
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import time
import zipfile

root = Path('/Users/dinghaolin/MyProjects/riftbound')
work = Path(__file__).resolve().parent
out = work / 'ci-fixed564'
out.mkdir(exist_ok=True)
fixed = '564e433d54d47f98b405787eed97cbdd48b7c394'
run = 39442248507
sha = lambda b: hashlib.sha256(b).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
index_raw = subprocess.check_output(['gh','api',f'repos/DDDHL0704/riftbound/actions/runs/{run}/artifacts?per_page=100'])
with (out/'part3-network-artifact-metadata-v1.json').open('xb') as f: f.write(index_raw)
index = {r['name']:r for r in json.loads(index_raw)['artifacts']}
archives = {}
for name in ('postgres-partition-3','native-network-results'):
    meta = index[name]
    assert not meta['expired'] and meta['workflow_run']['head_sha'] == fixed
    dest = out/(name+'.zip'); assert not dest.exists()
    for attempt in range(1,4):
        temp = out/(name+'.download-'+str(attempt))
        with temp.open('xb') as f:
            p = subprocess.run(['gh','api',f'repos/DDDHL0704/riftbound/actions/artifacts/{meta["id"]}/zip'],stdout=f,stderr=subprocess.PIPE,timeout=55)
        raw = temp.read_bytes()
        if p.returncode == 0 and len(raw) == meta['size_in_bytes'] and 'sha256:'+sha(raw) == meta['digest']:
            with zipfile.ZipFile(temp) as z: assert z.testzip() is None
            temp.rename(dest)
            break
        failed = out/(name+'-failed-'+str(attempt)+'.original.gz')
        failed.write_bytes(gzip.compress(raw,mtime=0))
        failed.with_suffix('.receipt.json').write_text(json.dumps({'atUtc':now(),'exitCode':p.returncode,
            'rawBytes':len(raw),'rawSha256':sha(raw),'stderr':p.stderr.decode(errors='replace'),
            'originalFailedBytesGzip':str(failed.relative_to(root)),'notAValidResultArtifact':True},indent=2)+'\n')
        temp.unlink()
        if attempt == 3: raise RuntimeError('Cannot verify original '+name)
        time.sleep(3)
    archives[name] = {'path':str(dest.relative_to(root)),'sha256':sha(raw),'bytes':len(raw),
        'artifactId':meta['id'],'backendSizeDigestAndZipCrcVerified':True}

manifest = subprocess.check_output(['git','show',fixed+':tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'],cwd=root)
ids = [c['id'] for c in json.loads(manifest)['cases']]
assert len(ids) == len(set(ids)) == 47
with zipfile.ZipFile(out/'postgres-partition-3.zip') as z:
    receipt_raw = z.read('ci-postgres/partition-receipt.json'); d = json.loads(receipt_raw)
    assert d['status'] == 'REAL_POSTGRES_PARTITION_COMPLETE' and d['fixedCommit'] == fixed
    assert d['manifestSha256'] == sha(manifest) and d['orderedDefaultCases'] == ids
    assert d['partitionIndex'] == 3 and d['partitionCount'] == 4
    assert d['expectedCases'] == d['completedCases'] == [e['id'] for e in d['executions']] == ids[3::4]
    assert [e['ordinal'] for e in d['executions']] == list(range(3,len(ids),4))
    assert all(e['status'] == 'PASSED' for e in d['executions'])
    for r in d['outputFiles']:
        raw = z.read('ci-postgres/'+r['path']); assert len(raw) == r['bytes'] and sha(raw) == r['sha256']
    part = {'partitionIndex':3,'cases':ids[3::4],'receiptSha256':sha(receipt_raw),'outputs':len(d['outputFiles']),
        'actualRuleInputs':d['actualRuleInputs'],'runtimeAssemblies':d['runtimeAssemblies']}
with zipfile.ZipFile(out/'native-network-results.zip') as z:
    files = {n:sha(z.read(n)) for n in z.namelist()}
    log = z.read(next(n for n in z.namelist() if n.endswith('native-network.log'))).decode()
    line = next(l for l in log.splitlines() if l.startswith('NATIVE_ROOM_IDENTITY_EVIDENCE '))
    evidence = json.loads(line[len('NATIVE_ROOM_IDENTITY_EVIDENCE '):])
    assert evidence['rejectedActions'] == 15 and evidence['leakedPrivateMessages'] == 0
    assert evidence['validReconnectTokenWasSupplied'] is True
    assert evidence['identities'] == ['ANONYMOUS','FAILED_KEY','OTHER_HANDLE']
    commit_files = [n for n in z.namelist() if n.endswith('commit.txt')]
    assert len(commit_files) == 1 and z.read(commit_files[0]).decode().strip() == fixed
    assert '15 rejected actions, three independent connection identities, real-token possession rejected' in log
    assert 'socket loss, authenticated room restore, fresh snapshot, rejected-token guard.' in log
result = {'atUtc':now(),'status':'PASS_FIXED564_ORIGINAL_COMPLETED_SQL_PART3_AND_NETWORK_ONLY',
    'fixedCommit':fixed,'runId':run,'part3':part,'network':evidence,'originalNetworkFileHashes':files,
    'verifiedArtifacts':archives,'remainingSqlPartitionsAndRulesAndWholeFullNotInferred':True,
    'currentMacVisibleControlsAndWindowsPhysicalStillSeparate':True,'wholePrintingOrGlobalCertification':False}
with (work/'fixed564-completed-part3-network-original-independent-readback-v1.json').open('x') as f:
    f.write(json.dumps(result,indent=2)+'\n')
print(result['status'],len(part['cases']),part['outputs'],flush=True)
