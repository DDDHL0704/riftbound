import ast
import collections
import datetime
import fcntl
import gzip
import hashlib
import json
import os
from pathlib import Path
import plistlib
import re
import socket
import subprocess
import time
import urllib.request

os.umask(0o077)
work=Path(__file__).resolve().parent;root=work.parents[2]
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();load=lambda p:json.loads(p.read_text())
source=load(work/'clean-fixed564e433-source-baseline-v1.json');pub=load(work/'fixed-api-and-readonly-runtime-publication-v1.json');native=load(work/'clean-fixed-native-debug-build-v2-restored.json');prefix_pub=load(work/'native-reversal-prefix-safe-v1-publication.json')
score_pub=load(work/'normal-bandle-score-safe-v1-publication.json');score_runtime=work/'normal-bandle-score-safe-v1-runtime';runtime=work/'fixed-api-v1';reader=work/'read-only-runtime-v1';prefix=work/'native-reversal-prefix-safe-v1-runtime'
entry=load(work/'actual-safe-native-prefix-v1/pending-original-native-prefix-receipt.json');room=entry['room'];a,b=entry['players'];n=entry['acceptedCommands']
original=load(work/'actual-safe-native-main-v1/original213-audit46-native-including67-room-seven-table-baseline-v1.json')
assert len(original['nativeRooms'])==46 and room not in original['nativeRooms']
for source_path,names in [(root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py',{'query','rooms','digests','observe_lock'}),(work/'run-fixed-native-main-paired-reconnect-v1.py',{'checkpoint','frozen','start_api','export'}),(work/'resume-fixed-native-original-priority-v2.py',{'history_hashes'})]:
    nodes=[v for v in ast.parse(source_path.read_text()).body if isinstance(v,ast.FunctionDef) and v.name in names];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source_path),'exec'),globals())
evidence=work/'actual-safe-normal-score-v1';assert not evidence.exists();evidence.mkdir()
terminal=work/'actual-safe-normal-score-terminal-v1.json';ready=work/'actual-safe-normal-score-ready-v1.json';stop=work/'actual-safe-normal-score-stop-v1.json';assert not any(p.exists() for p in [terminal,ready,stop])
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof={'status':'STARTING_SAME_SAFE_NATIVE_ROOM_BANDLE_NORMAL_SCORE','startedAtUtc':now(),'fixedCommit':source['fixedCommit'],'room':room,'actualRuleInputs':pub['actualRuleInputs'],'originalNativeFourCommands':4,'originalPrefixCommands':n,'ownedApiProcesses':[],'old67RoomAmong46ProtectedOriginalNativeRooms':True,'lockAtStart':observe_lock(),'visibleCiExportedAndPhysicalWindowsAcceptance':False}
api=power=driver=None;started=False

def subset(before,after):
    for table,values in before.items():
        expected=collections.Counter(values);actual=collections.Counter(after[table]);assert all(actual.get(key,0)>=amount for key,amount in expected.items()),table

try:
    frozen();assert all(sha(score_runtime/p)==h for p,h in score_pub['runtimeHashes'].items())
    assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
    with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
    power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof.update(ownPid=os.getpid(),boundIdleAssertionPid=power.pid);checkpoint('safe-normal-owner-start-v1.json',proof)
    subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(work/'actual-owned-postgres-safe-normal-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
    assert rooms('riftbound_acceptance')==original['auditRooms'] and rooms('riftbound_here_native')==sorted(original['nativeRooms']+[room])
    assert digests('riftbound_acceptance',original['auditRooms'])==original['auditSevenTables'] and digests('riftbound_here_native',original['nativeRooms'])==original['nativeSevenTables']
    before,metadata=export('before-safe-native-normal-score-frame-v1');saved=json.loads(gzip.decompress((work/'actual-safe-native-main-v1/owner-final-original-frame-v1.json.gz').read_bytes()));assert before==saved and len(before['commands'])==n+4
    before_history=history_hashes();checkpoint('allOriginalNativeCheckpointFiveHistoryTableRowHashes-v1.json',before_history)
    start_api(8);print('SAFE_NATIVE_ROOM_BANDLE_SCORE_GATEWAY_READY',room,'originalCommands',n+4,flush=True)
    output=work/'actual-safe-normal-score-gateway-v1'
    with (work/'actual-safe-normal-score-gateway-v1.log').open('xb') as out:
        driver=subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet',str(score_runtime/'Fixed564SafeBandleScore.dll'),'http://127.0.0.1:15847',str(output),str(work)],cwd=score_runtime,stdout=out,stderr=subprocess.STDOUT)
        assert driver.wait(timeout=330)==0,'Safe original normal score continuation failed; latest current private tokens remain saved.'
    result=load(output/'normal-original-score-continuation-receipt.json');assert result['continuationCommands']==17 and result['expectedFinalCommands']==n+21 and result['winningScore']==8
    final,metadata=export('after-safe-normal-score-final-original-frame-v1');state=final['authoritativeState'];assert len(final['commands'])==n+21 and state['status']=='FINISHED' and state['winnerPlayerId']==a and state['playerScores']=={a:8,b:0}
    assert final['commands'][:n+4]==saved['commands'] and final['events'][:len(saved['events'])]==saved['events'] and final['openingSeed']==saved['openingSeed'] and final['replayInitialState']==saved['replayInitialState']
    after_history=history_hashes();subset(before_history,after_history)
    checkpoint('allOriginalNativeCheckpointHistoricalRowsRetainedAfterNormalWin-v1.json',{'atUtc':now(),'allOriginalFiveTablesRowsByteSha256AndMultiplicityRetained':True,'beforeCounts':{k:len(v) for k,v in before_history.items()},'afterCounts':{k:len(v) for k,v in after_history.items()}})
    proof.update(status='SAFE_NATIVE_AND_NORMAL_SCORE_READY_FOR_INDEPENDENT_SQL_HISTORY_AND_FULL_REPLAY',totalCommands=len(final['commands']),events=len(final['events']),winningScore=8,losingScore=0,finalTurn=state['turnNumber'],normalGatewayCommands=17,actualNativeButtonCommands=4,originalNativeCheckpointCommandsEventsAndPrivateSeedExact=True,originalFiveHistoryTableRowsUnchanged=True)
    with ready.open('x') as out:json.dump({**proof,'apiPid':api.pid,'rawFrame':str((evidence/'after-safe-normal-score-final-original-frame-v1.json.gz').relative_to(root)),'actualDatabase':'riftbound_here_native'},out,ensure_ascii=False,indent=2)
    print(proof['status'],room,proof['totalCommands'],proof['events'],'score8:0',flush=True)
    deadline=time.monotonic()+900
    while not stop.exists():assert api.poll() is None and time.monotonic()<deadline;time.sleep(.2)
    completion=load(stop);assert completion['originalRoom']==room and completion['independentReadOnlyHistoryAndFullReplayPass']
    proof['status']='PASS_SAME_SAFE_NATIVE_ROOM_NORMAL_SCORE_AND_INDEPENDENT_SQL_READ_STOP_REQUESTED'
except BaseException as error:
    proof.update(status='FAILED_OR_INTERRUPTED_SAFE_NATIVE_ROOM_NORMAL_SCORE_ORIGINAL_RETAINED',errorType=type(error).__name__,errorMessage=str(error));print(proof['status'],type(error).__name__,str(error),flush=True);raise
finally:
    if driver is not None and driver.poll() is None:driver.terminate();driver.wait(timeout=20)
    if started:
        try:export('owner-final-safe-normal-score-original-frame-v1');proof['latestOriginalFrameRetainedBeforeStop']=True
        except BaseException as error:proof['finalExportErrorType']=type(error).__name__
    if api is not None and api.poll() is None:api.terminate();proof['ownApiGracefulExitCode']=api.wait(timeout=30)
    if started:
        proof['allOriginal213AuditSevenTablesExactAtStop']=digests('riftbound_acceptance',original['auditRooms'])==original['auditSevenTables']
        proof['allOriginal46NativeSevenTablesExactAtStop']=digests('riftbound_here_native',original['nativeRooms'])==original['nativeSevenTables']
        proof['same47NativeRoomIdsRetained']=rooms('riftbound_here_native')==sorted(original['nativeRooms']+[room])
        proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
    if power is not None:
        if power.poll() is None:power.terminate();power.wait(timeout=10)
        proof['boundIdleAssertionEnded']=power.poll() is not None
    try:frozen();assert all(sha(score_runtime/p)==h for p,h in score_pub['runtimeHashes'].items());proof['allFixedSourceModesApiReaderSafePrefixNativeAndScoreRuntimeHashesStable']=True
    except BaseException as error:proof.update(status='FAILED_SAFE_SCORE_FINAL_INPUT_INTEGRITY',allFixedSourceModesApiReaderSafePrefixNativeAndScoreRuntimeHashesStable=False,inputIntegrityErrorType=type(error).__name__)
    proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),originalDatabaseRetained=True)
    with terminal.open('x') as out:json.dump(proof,out,ensure_ascii=False,indent=2)
    fcntl.flock(guard,fcntl.LOCK_UN)
assert proof['allFixedSourceModesApiReaderSafePrefixNativeAndScoreRuntimeHashesStable'] and proof.get('ownPostgresSmartStopped') and proof.get('boundIdleAssertionEnded')
assert proof.get('allOriginal213AuditSevenTablesExactAtStop') and proof.get('allOriginal46NativeSevenTablesExactAtStop')
