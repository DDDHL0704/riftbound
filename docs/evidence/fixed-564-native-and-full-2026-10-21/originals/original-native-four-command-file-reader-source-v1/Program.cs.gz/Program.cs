using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

var json=new JsonSerializerOptions(JsonSerializerDefaults.Web){WriteIndented=true};
if(args.Length!=3)throw new Exception("Original working directory, exact saved frame and fresh receipt path required.");
var work=Path.GetFullPath(args[0]);var input=Path.GetFullPath(args[1]);var output=Path.GetFullPath(args[2]);Check(!File.Exists(output),"Do not replace original reader evidence.");
using var original=JsonDocument.Parse(File.ReadAllText(Path.Combine(work,"actual-ordinary-native-prefix-v1/pending-original-native-prefix-receipt.json")));
var entry=original.RootElement;var actors=entry.GetProperty("players").EnumerateArray().Select(x=>x.GetString()!).ToArray();var a=actors[0];var b=actors[1];var n=entry.GetProperty("acceptedCommands").GetInt32();
using var raw=Read(input);var frame=raw.RootElement.Deserialize<MatchRecoveryFrame>(json)!;
Check(JsonNode.DeepEquals(JsonNode.Parse(raw.RootElement.GetRawText()),JsonSerializer.SerializeToNode(frame,json)),"Entire original typed frame fields/null and omitted conditional fields round trip exactly.");
Check(frame.IsConsistent&&frame.ValidationErrors.Count==0&&frame.Commands.Count==n+4&&frame.Commands.All(c=>c.Accepted&&c.RuleInputs==RuleInputIdentity.Current)&&frame.AuthoritativeState!.RuleInputs==RuleInputIdentity.Current,"All original62 accepted commands and current exact runtime identities.");
Check(frame.OpeningSeed!=0&&frame.ReplayInitialState is{Tick:0,CardObjects.Count:0},"Original nonzero private seed and normal blank initial required.");
using var prefix=JsonDocument.Parse(File.ReadAllText(Path.Combine(work,"actual-ordinary-native-prefix-v1/original-accepted-native-prefix-intents.json")));
for(var i=0;i<n;i++){var old=prefix.RootElement[i];Check(frame.Commands[i].PlayerId==old.GetProperty("actor").GetString()&&JsonNode.DeepEquals(JsonNode.Parse(old.GetProperty("rawCommand").GetRawText()),JsonNode.Parse(frame.Commands[i].RawCommand!.Value.GetRawText())),"Every original prefix actor/raw field exact.");}
var expectedFiles=new[]{("actual-ordinary-native-main-v1/before-native-original-frame-v1.json.gz",b),("actual-ordinary-native-main-v1/after-native-edit-before-cold-original-frame-v1.json.gz",b),("actual-native-original-priority-resume-v2/before-original-priority-resume-frame-v1.json.gz",b),("actual-native-original-priority-resume-v2/after-original-native-priority-1-frame-v1.json.gz",a)};
using var plan=JsonDocument.Parse(File.ReadAllText(Path.Combine(work,"actual-ordinary-native-main-v1/native-target-choices-control-plan-v1.json")));var edit=plan.RootElement.GetProperty("editChoiceId").GetString()!;
for(var i=0;i<4;i++)
{
 using var before=Read(Path.Combine(work,expectedFiles[i].Item1));var prompt=before.RootElement.GetProperty("playerViews").GetProperty(expectedFiles[i].Item2).GetProperty("prompt");
 var command=new JsonObject{["cmdType"]=i<2?"PAY_COST":"PASS_PRIORITY",["promptId"]=prompt.GetProperty("promptId").GetString(),["snapshotTick"]=prompt.GetProperty("snapshotTick").GetInt64()};
 if(i<2){var meta=prompt.GetProperty("candidates").EnumerateArray().Single(c=>c.GetProperty("action").GetString()=="PAY_COST").GetProperty("metadata");command["paymentId"]=meta.GetProperty("paymentId").GetString();command["paymentWindow"]="RULE_REPLACEMENT";command["paymentChoiceIds"]=new JsonArray(i==0?edit:"CONFIRM");}
 Check(frame.Commands[n+i].PlayerId==expectedFiles[i].Item2&&JsonNode.DeepEquals(command,JsonNode.Parse(frame.Commands[n+i].RawCommand!.Value.GetRawText())),"Each entire original native intent matches its exact preceding real prompt, actor and tick.");
}
using var first=Read(Path.Combine(work,"actual-ordinary-native-main-v1/before-native-original-frame-v1.json.gz"));var initial=first.RootElement.GetProperty("authoritativeState").Deserialize<MatchState>(json)!;var state=frame.AuthoritativeState!;
var target=entry.GetProperty("newTargetObjectId").GetString()!;var other=entry.GetProperty("originalTargetObjectId").GetString()!;var spell=entry.GetProperty("targetSourceObjectId").GetString()!;var control=entry.GetProperty("sourceObjectId").GetString()!;
Check(state.Status==MatchStatuses.InProgress&&state.StackItems.Count==0&&state.PendingRuleChoice is null&&state.PendingPayment is null,"Original control spell and choices completely resolved.");
Check(state.CardObjects[target].Power==Math.Max(1,initial.CardObjects[target].Power-1)&&state.CardObjects[other].Power==initial.CardObjects[other].Power,"Only the exact newly chosen actual unit loses one power to minimum one.");
Check(state.PlayerZones[a].Graveyard.Contains(spell)&&!state.PlayerZones[b].Graveyard.Contains(spell)&&state.PlayerZones[b].Graveyard.Contains(control)&&state.PlayerZones[b].Hand.Count==initial.PlayerZones[b].Hand.Count+1,"Physical original source ownership and new-controller draw exact.");
Check(state.CardPlays.Resolved.Single(c=>c.Source.ObjectId==spell).PlayerId==b&&state.CardPlays.Finalized.Single(c=>c.Source.ObjectId==spell).PlayerId==a,"Resolver versus original finalizer remains distinct.");
var later=frame.Events.Skip(first.RootElement.GetProperty("events").GetArrayLength()).ToArray();
Check(later.Count(e=>e.Event.Kind=="STACK_ITEM_CONTROL_GAINED")==1&&later.Count(e=>e.Event.Kind=="SPELL_CHOICES_REMADE")==1&&!later.Any(e=>e.Event.Kind=="STACK_ITEM_COUNTERED"||e.Event.Kind=="COST_PAID"),"Exactly one control and one confirmed remake; no counter or cost replay.");
var draws=later.Where(e=>e.Event.Kind=="CARD_DRAWN").ToArray();Check(draws.Length==1&&JsonSerializer.SerializeToElement(draws[0].Event.Payload,json).GetProperty("playerId").GetString()==b,"One actual new-controller draw after original passes.");
var errors=await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame,new CoreRuleEngine(),default);Check(errors.Count==0,"Entire original normal-opening action/event/state replay: "+string.Join(';',errors));
var result=new{status="PASS_INDEPENDENT_FILE_ORIGINAL_NATIVE_FOUR_INTENTS_LITERAL_OUTCOME_AND_ENTIRE_NORMAL_REPLAY",room=entry.GetProperty("room").GetString(),commands=frame.Commands.Count,events=frame.Events.Count,originalPrefix=n,actualNativeCommands=4,actualBackendRuleInputs=RuleInputIdentity.Current,allOriginalRawFieldsNullConditionalOmissionsPreserved=true,originalPrivateSeedAndBlankInitialRetainedNotPrinted=true,literalTargetDrawControlOwnerAndNoCostCounterChecks=true,inputSha256=Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(input))),historicalSqlRowsNotReadInThisFileOnlyProof=true,visibleCiExportedPhysicalWindowsAndNormalEightScoreOpen=true};
await File.WriteAllTextAsync(output,JsonSerializer.Serialize(result,json));Console.WriteLine(JsonSerializer.Serialize(result,json));
static JsonDocument Read(string path){using var z=new GZipStream(File.OpenRead(path),CompressionMode.Decompress);return JsonDocument.Parse(z);}
static void Check(bool value,string text){if(!value)throw new Exception(text);}
