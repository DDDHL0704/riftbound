using System.Collections.Concurrent;
using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Nodes;
using Riftbound.Contracts;
using Riftbound.GodotClient;

if(args.Length!=3||args[0]!="http://127.0.0.1:15847")throw new Exception("Only own API, fresh output and current original profiles.");
var server=args[0];var output=Path.GetFullPath(args[1]);var work=Path.GetFullPath(args[2]);if(Directory.Exists(output))throw new Exception("Original output cannot be overwritten.");Directory.CreateDirectory(output);
using var limit=new CancellationTokenSource(TimeSpan.FromMinutes(5));var ct=limit.Token;var json=new JsonSerializerOptions(JsonSerializerDefaults.Web){WriteIndented=true};
using var original=JsonDocument.Parse(File.ReadAllText(Path.Combine(work,"actual-ordinary-native-prefix-v1/pending-original-native-prefix-receipt.json")));var room=original.RootElement.GetProperty("room").GetString()!;
using var zip=new GZipStream(File.OpenRead(Path.Combine(work,"actual-same-original-room-normal-score-v1/owner-final-original-normal-score-frame-v1.json.gz")),CompressionMode.Decompress);using var before=JsonDocument.Parse(zip);
var originalCount=before.RootElement.GetProperty("commands").GetArrayLength();Check(originalCount==67,"Exact original movement/conquest/two turns already accepted; do not repeat them.");var tick=before.RootElement.GetProperty("authoritativeState").GetProperty("tick").GetInt64();
var profiles=new[]{"a","b"}.Select(role=>JsonNode.Parse(File.ReadAllText(Path.Combine(work,"session-"+role+".json")))!).ToArray();
using var trace=new WireTrace(Path.Combine(output,"original-private-held-skill-score-wire.ndjson.gz"));await using var a=new Side(server,room,profiles[0],trace,ct);await using var b=new Side(server,room,profiles[1],trace,ct);var sides=new[]{a,b};await a.Connect();await b.Connect();
Check(sides.All(s=>s.Snapshot.GetProperty("tick").GetInt64()==tick)&&a.Snapshot.GetProperty("turnNumber").GetInt32()==36&&Score(a,a.Handle)==2&&Score(a,b.Handle)==0,"Resume exact original67 tick and2:0 atturn36.");
var accepted=new List<object>();var turns=0;var priorityPasses=0;
while(a.Snapshot.GetProperty("timing").GetProperty("roomStatus").GetString()!="FINISHED")
{
 var responders=sides.Where(s=>s.Enabled("PASS_PRIORITY")).ToArray();
 if(responders.Length>0){Check(responders.Length==1&&priorityPasses<14,"Only the actual current held-skill responder can pass.");await Submit(responders[0],new(){["cmdType"]="PASS_PRIORITY"});priorityPasses++;continue;}
 var active=sides.Where(s=>s.Enabled("END_TURN")).ToArray();Check(active.Length==1&&turns<12,"Respect every live skill/turn phase; no bypass of pending choices.");await Submit(active[0],new(){["cmdType"]="END_TURN"});turns++;
}
Check(turns==12&&priorityPasses%2==0&&Score(a,a.Handle)==8&&Score(a,b.Handle)==0&&a.Snapshot.GetProperty("turnNumber").GetInt32()==48,"The original remaining twelve turn endings must produce normal8:0 atturn48.");
Check(a.Snapshot.GetProperty("timing").GetProperty("winnerPlayerId").GetString()==a.Handle&&sides.All(s=>s.Snapshot.GetProperty("players").GetProperty(s.Handle).GetProperty("zones").GetProperty("mainDeckCount").GetInt32()>0),"Ordinary current winner and both nonempty decks.");
var receipt=new{status="PASS_SAME_ORIGINAL67_ROOM_HELD_SKILL_PRIORITY_AND_NORMAL_SCORE_WIN",room,originalCommands=originalCount,continuationCommands=accepted.Count,finalCommands=originalCount+accepted.Count,normalEndTurns=turns,heldSkillPriorityPasses=priorityPasses,winningScore=8,losingScore=0,finalTurn=48,originalFourNativeCommandsAndFirstConquestNotRepeated=true,acceptedActionsAreProductionGatewayNotGodotButtons=true,visibleCiExportedOrPhysicalWindowsAcceptance=false};await File.WriteAllTextAsync(Path.Combine(output,"normal-original-score-continuation-receipt.json"),JsonSerializer.Serialize(receipt,json),ct);Console.WriteLine(JsonSerializer.Serialize(receipt,json));
async Task Submit(Side actor,JsonObject command)
{
 var receipt=await actor.Submit(command);accepted.Add(new{actor=actor.Handle,rawCommand=command,receipt});
 await File.WriteAllTextAsync(Path.Combine(output,"all-original-normal-score-continuation-intents.json"),JsonSerializer.Serialize(accepted,json),ct);
 while(!sides.All(s=>s.Snapshot.GetProperty("tick").GetInt64()==receipt.ServerTick&&s.Prompt.TryGetProperty("snapshotTick",out var pt)&&pt.GetInt64()==receipt.ServerTick)){foreach(var side in sides)side.CheckErrors();await Task.Delay(20,ct);}
}
static int Score(Side side,string actor)=>side.Snapshot.GetProperty("players").GetProperty(actor).GetProperty("score").GetInt32();
static void Check(bool value,string reason){if(!value)throw new Exception(reason);}

sealed class WireTrace : IDisposable
{
    readonly StreamWriter writer; readonly object gate = new();
    public WireTrace(string path) => writer = new StreamWriter(new GZipStream(new FileStream(path, FileMode.CreateNew), CompressionLevel.SmallestSize));
    public void Record(string actor, string kind, JsonElement payload)
    { lock (gate) { writer.WriteLine(JsonSerializer.Serialize(new { actor, kind, payload })); writer.Flush(); } }
    public void Dispose() { lock (gate) writer.Dispose(); }
}
sealed class Side : IAsyncDisposable
{
    readonly string key; readonly string room; readonly CancellationToken ct;
    readonly ConcurrentQueue<string> errors = new(); readonly object gate = new();
    JsonElement snapshot, prompt;
    public string Handle { get; }
    public string? ReconnectToken { get; private set; }
    public int SnapshotCount, PromptCount;
    public RiftboundGameHubClient Hub { get; }
    public JsonElement Snapshot { get { lock (gate) return snapshot; } }
    public JsonElement Prompt { get { lock (gate) return prompt; } }
    public Side(string server, string room, JsonNode profile, WireTrace trace, CancellationToken token)
    {
        this.room = room; ct = token; Handle = profile["handle"]!.GetValue<string>(); key = profile["playerKey"]!.GetValue<string>(); ReconnectToken = profile["reconnectToken"]!.GetValue<string>();
        Hub = new(server);
        Hub.ServerMessageReceived += (kind, message) => {
            if (message.Payload is not JsonElement payload) return;
            lock (gate) {
                if (kind == "Joined") ReconnectToken = payload.GetProperty("reconnectToken").GetString();
                if (kind == "Snapshot") { snapshot = payload.Clone(); SnapshotCount++; trace.Record(Handle, kind, payload); }
                if (kind == "Prompt") { prompt = payload.Clone(); PromptCount++; trace.Record(Handle, kind, payload); }
                if (kind == "Error") errors.Enqueue("Actual server error " + payload.GetProperty("code").GetString());
            }
        };
        Hub.RestoreSession += async () => {
            var auth = await Hub.AuthenticateAsync(Handle, key, ct); if (!auth.Authenticated) throw new Exception("Actual restore authentication failed.");
            await Hub.ReconnectAsync(room, Handle, ReconnectToken!, ct); await Hub.RequestSnapshotAsync(room, Handle, ct);
        };
    }
    public async Task Connect()
    {
        await Hub.StartAsync(ct); var auth = await Hub.AuthenticateAsync(Handle, key, ct);
        if (!auth.Authenticated) throw new Exception("Existing own native identity authentication failed.");
        await Hub.ReconnectAsync(room, Handle, ReconnectToken!, ct); await Hub.RequestSnapshotAsync(room, Handle, ct);
        while (ReconnectToken is null || SnapshotCount == 0 || PromptCount == 0) { CheckErrors(); await Task.Delay(20, ct); }
    }
    public bool Enabled(string action) => Prompt.ValueKind == JsonValueKind.Object && Prompt.GetProperty("actionable").GetBoolean()
        && Prompt.GetProperty("candidates").EnumerateArray().Any(c => c.GetProperty("action").GetString() == action && c.GetProperty("enabled").GetBoolean());
    public async Task<CommandReceiptDto> Submit(JsonObject command)
    {
        command["promptId"] = Prompt.GetProperty("promptId").GetString(); command["snapshotTick"] = Prompt.GetProperty("snapshotTick").GetInt64();
        var receipt = await Hub.SubmitIntentAsync(room, Handle, "native-counter-prefix-" + Guid.NewGuid().ToString("N"), JsonSerializer.SerializeToElement(command), ct);
        if (!receipt.Accepted) throw new Exception("Actual ordinary native prefix rejected: " + receipt.CmdType + " " + receipt.ErrorCode);
        return receipt;
    }
    public void CheckErrors() { if (errors.TryPeek(out var error)) throw new Exception(error); }
    public ValueTask DisposeAsync() => Hub.DisposeAsync();
}
