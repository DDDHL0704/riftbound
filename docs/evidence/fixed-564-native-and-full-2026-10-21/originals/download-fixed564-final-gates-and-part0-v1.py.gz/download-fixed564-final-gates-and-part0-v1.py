import datetime
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import time
import zipfile

root=Path('/Users/dinghaolin/MyProjects/riftbound');work=Path(__file__).resolve().parent;out=work/'ci-fixed564'
sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
status_path=sorted(out.glob('actual-run-jobs-*.json'))[-1];status=json.loads(status_path.read_bytes())
meta_path=sorted(out.glob('actual-artifact-index-*.json'))[-1];index={a['name']:a for a in json.loads(meta_path.read_bytes())['artifacts']}
fixed='564e433d54d47f98b405787eed97cbdd48b7c394'
assert status['headSha']==fixed and status['status']=='completed' and status['conclusion']=='success'
assert len(status['jobs'])==11 and all(j['status']=='completed' and j['conclusion']=='success' for j in status['jobs'])
records=[]
for name in ('postgres-partition-0','postgres-results','full-verification-gate'):
    m=index[name];assert not m['expired'] and m['workflow_run']['head_sha']==fixed
    dest=out/(name+'.zip');assert not dest.exists()
    for attempt in range(1,4):
        temp=out/(name+'.final-download-'+str(attempt))
        with temp.open('xb') as f:p=subprocess.run(['gh','api',f'repos/DDDHL0704/riftbound/actions/artifacts/{m["id"]}/zip'],stdout=f,stderr=subprocess.PIPE,timeout=55)
        raw=temp.read_bytes()
        if p.returncode==0 and len(raw)==m['size_in_bytes'] and 'sha256:'+sha(raw)==m['digest']:
            with zipfile.ZipFile(temp) as z:assert z.testzip() is None
            temp.rename(dest);break
        failed=out/(name+'.final-failed-'+str(attempt)+'.original.gz');failed.write_bytes(gzip.compress(raw,mtime=0))
        write(out/(name+'.final-failed-'+str(attempt)+'.receipt.json'),{'atUtc':now(),'exitCode':p.returncode,'stderr':p.stderr.decode(errors='replace'),'originalRawBytes':len(raw),'originalRawSha256':sha(raw),'notValidArtifact':True})
        temp.unlink()
        if attempt==3:raise RuntimeError('Failed to verify original '+name)
        time.sleep(2)
    records.append({'name':name,'path':str(dest.relative_to(root)),'sha256':sha(raw),'bytes':len(raw),'artifactId':m['id'],'backendDigestSizeAndZipCrcVerified':True})
write(work/'fixed564-final-three-original-artifact-download-v1.json',{'atUtc':now(),'status':'ACTUAL_COMPLETE_11_SUCCESS_ORIGINAL_FINAL_ARTIFACTS_VERIFIED_NOT_YET_SEMANTIC_CERTIFICATION','runId':39442248507,'fixedCommit':fixed,'statusReceipt':str(status_path.relative_to(root)),'metadataReceipt':str(meta_path.relative_to(root)),'records':records})
for name in ('postgres-results','full-verification-gate'):
    with zipfile.ZipFile(out/(name+'.zip')) as z:
        print('ARTIFACT',name,[(n,len(z.read(n))) for n in z.namelist()],flush=True)
        for n in z.namelist():
            if n.endswith('.json') or n.endswith('commit.txt'):print(n,z.read(n).decode()[:9000],flush=True)
