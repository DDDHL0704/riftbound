import ast
import datetime
import fcntl
import gzip
import hashlib
import json
import os
from pathlib import Path
import plistlib
import re
import shutil
import socket
import subprocess
import time
import urllib.request

os.umask(0o077)
work=Path(__file__).resolve().parent;root=work.parents[2]
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin')
cluster=root/'var/qa/permanent-play-here-base-20261017/postgres'
sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts']
read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
load=lambda p:json.loads(p.read_text())
guard_source=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes=[n for n in ast.parse(guard_source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}]
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(guard_source),'exec'),globals())
source=load(work/'clean-fixed564e433-source-baseline-v1.json')
pub=load(work/'fixed-api-and-readonly-runtime-publication-v1.json')
native=load(work/'clean-fixed-native-debug-build-v2-restored.json')
prefix_pub=load(work/'clean-fixed-native-reversal-prefix-publication-v3-corrected-assembly.json')
original=load(root/'var/qa/native-spell-choice-presentation-20261020/focused-clairvoyance-original213-audit45-native-baseline-v1.json')
assert len(original['auditRooms'])==213 and len(original['nativeRooms'])==45
runtime=work/'fixed-api-v1';reader=work/'read-only-runtime-v1';prefix=work/'native-reversal-prefix-v1'
evidence=work/'actual-ordinary-native-main-v1'
assert not evidence.exists();evidence.mkdir()
terminal=work/'actual-ordinary-native-main-owner-terminal-v1.json';assert not terminal.exists()
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof={'status':'STARTING_FIXED_CURRENT_HEADLESS_ORIGINAL_MAIN_PAIR','startedAtUtc':now(),'fixedCommit':source['fixedCommit'],'actualRuleInputs':pub['actualRuleInputs'],'actualNativeClientSha256':native['actualClientAssemblySha256'],'actualSignalRCommonSha256':native['actualSignalRCommonSha256'],'lockAtStart':observe_lock(),'ownedApiProcesses':[],'ownedNativeProcesses':[],'visibleCiExportedOrPhysicalWindowsAcceptance':False,'original213Audit45NativeDatabasePreserved':True}
started=False;api=power=driver=None;clients=[];room=None;baseline=None

def checkpoint(name,value):
    target=evidence/name
    with target.open('x') as out:json.dump(value,out,ensure_ascii=False,indent=2)

def frozen():
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==source['fixedCommit']
    assert all(sha(root/p)==h for p,h in source['sourceInputHashes'].items())
    assert all(oct((root/p).stat().st_mode&0o777)==m for p,m in source['sourceInputModes'].items())
    assert all(sha(root/p)==h for p,h in native['nativeRuntimeFileHashes'].items())
    assert all(sha(runtime/p)==h for p,h in pub['apiRuntimeHashes'].items())
    assert all(sha(reader/p)==h for p,h in pub['readerRuntimeHashes'].items())
    assert all(sha(prefix/p)==h for p,h in prefix_pub['runtimeHashes'].items())

def start_api(index):
    global api
    frozen();log=work/('actual-owned-fixed-api-'+str(index)+'-v1.log')
    env=dict(os.environ,ASPNETCORE_ENVIRONMENT='Production',ASPNETCORE_URLS='http://127.0.0.1:15847',ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit')
    env.pop('DOTNET_STARTUP_HOOKS',None)
    with log.open('xb') as out:api=subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet',str(runtime/'Riftbound.Api.dll')],cwd=runtime,stdout=out,stderr=subprocess.STDOUT,env=env,start_new_session=True)
    for _ in range(150):
        assert api.poll() is None
        try:
            with urllib.request.urlopen('http://127.0.0.1:15847/health',timeout=.5) as response:health=json.load(response)
            assert health['persistenceMode']=='postgres' and health['environment']=='Production'
            assert set(subprocess.check_output(['/usr/sbin/lsof','-tiTCP:15847','-sTCP:LISTEN'],text=True).splitlines())=={str(api.pid)}
            proof['ownedApiProcesses'].append({'pid':api.pid,'index':index,'log':log.name,'health':health,'atUtc':now()})
            return
        except OSError:time.sleep(.1)
    raise AssertionError('Owned API not ready.')

def export(name):
    target=evidence/(name+'.json.gz')
    args=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(reader/'Riftbound.Api.deps.json'),'--runtimeconfig',str(reader/'Riftbound.Api.runtimeconfig.json'),str(reader/'FixedNativeFrameExport.dll'),room,str(target)]
    output=subprocess.check_output(args,cwd=reader,env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit'))
    metadata=json.loads(output);assert metadata['actualRuleInputs']==pub['actualRuleInputs'];checkpoint(name+'-metadata.json',metadata)
    frame=json.loads(gzip.decompress(target.read_bytes()));assert frame['isConsistent'] and frame['validationErrors']==[]
    assert frame['authoritativeState']['ruleInputs']==pub['actualRuleInputs']
    return frame,metadata

def wait(predicate,why,seconds=120):
    limit=time.monotonic()+seconds
    while not predicate():
        assert time.monotonic()<limit,why
        assert api is None or api.poll() is None,why+' API exit'
        assert all(p.poll() is None for _,p in clients),why+' native exit'
        for role,_ in clients:
            failure=evidence/(role+'-original-main-controls-failure-v1.json')
            assert not failure.exists(),why+' native helper failure'
        time.sleep(.1)

def count():
    assert room is not None and re.fullmatch('N26-RETARGET-[0-9A-F]{10}',room)
    return int(query('riftbound_here_native',"select count(*) from command_log where match_id='"+room+"'"))

def expected(prompt,choice=None):
    action='PAY_COST' if choice is not None else 'PASS_PRIORITY'
    candidate=next(c for c in prompt['candidates'] if c['action']==action and c['enabled'])
    value={'cmdType':action,'promptId':prompt['promptId'],'snapshotTick':prompt['snapshotTick']}
    if choice is not None:value.update(paymentId=candidate['metadata']['paymentId'],paymentWindow=candidate['metadata']['paymentWindow'],paymentChoiceIds=[choice])
    return value

def last(frame,actor,command):
    row=frame['commands'][-1]
    assert row['accepted'] and row['playerId']==actor and row['rawCommand']==command and row['ruleInputs']==pub['actualRuleInputs']

try:
    frozen();assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
    with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
    power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof.update(ownPid=os.getpid(),boundIdleAssertionPid=power.pid)
    checkpoint('original-owner-start-v1.json',proof)
    sock.mkdir(exist_ok=True)
    subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(work/'actual-owned-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
    assert rooms('riftbound_acceptance')==original['auditRooms'] and rooms('riftbound_here_native')==original['nativeRooms']
    assert digests('riftbound_acceptance',original['auditRooms'])==original['auditSevenTables'] and digests('riftbound_here_native',original['nativeRooms'])==original['nativeSevenTables']
    baseline=original;checkpoint('original213-audit45-native-seven-tables-before-v1.json',{'atUtc':now(),'allExact':True,'baselineSha256':sha(root/'var/qa/native-spell-choice-presentation-20261020/focused-clairvoyance-original213-audit45-native-baseline-v1.json')})
    for role in ['a','b']:
        target=work/('session-'+role+'.json');assert not target.exists();shutil.copy2(root/'var/qa/native-signalr-runtime-patch-fixed-43d5b84e-20261020'/target.name,target);target.chmod(0o600)
    start_api(0);print('FIXED_CURRENT_REAL_PG_AND_API_READY_STARTING_ORDINARY_PREFIX',flush=True)
    prefix_out=work/'actual-ordinary-native-prefix-v1'
    with (work/'actual-ordinary-native-prefix-writer-v1.log').open('xb') as out:
        driver=subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet',str(prefix/'Fixed564NativeReversalPrefix.dll'),'http://127.0.0.1:15847',str(prefix_out),str(work)],cwd=prefix,stdout=out,stderr=subprocess.STDOUT)
        assert driver.wait(timeout=780)==0,'Actual ordinary original native prefix failed; retain partial room.'
    entry=load(prefix_out/'pending-original-native-prefix-receipt.json');room=entry['room'];proof['room']=room
    assert sorted(set(rooms('riftbound_here_native'))-set(original['nativeRooms']))==[room]
    n=entry['acceptedCommands'];a,b=entry['players'];before,meta=export('before-native-original-frame-v1');assert len(before['commands'])==n and meta['priorAnswers']==0
    assert before['replayInitialState']['tick']==0 and before['replayInitialState']['cardObjects']=={} and before['openingSeed']!=0
    prefix_commands=load(prefix_out/'original-accepted-native-prefix-intents.json')
    assert len(prefix_commands)==n and all(x['actor']==y['playerId'] and x['rawCommand']==y['rawCommand'] for x,y in zip(prefix_commands,before['commands']))
    prompt=before['playerViews'][b]['prompt'];candidate=next(c for c in prompt['candidates'] if c['action']=='PAY_COST' and c['enabled'])
    choices=next(s['choices'] for s in candidate['selectionSteps'] if s['role']=='target')
    selected=[(i,c) for i,c in enumerate(choices) if c['id'].startswith('EDIT:0:') and entry['newTargetObjectId'] in c.get('objectIds',[]) and '重选目标' in c['label']];assert len(selected)==1
    index,choice=selected[0];label=choice['label'].strip();short=label if len(label)<=24 else label[:23]+'…'
    plan={'fixedCommit':source['fixedCommit'],'room':room,'editChoiceIndex':index,'editChoiceId':choice['id'],'editChoiceShortLabel':short,'originalTargetObjectId':entry['originalTargetObjectId'],'newTargetObjectId':entry['newTargetObjectId'],'originalPromptId':prompt['promptId'],'originalSnapshotTick':prompt['snapshotTick'],'actualRuleInputs':pub['actualRuleInputs'],'originalRawEditExpected':expected(prompt,choice['id']),'noGameStateOrAcceptedHistoryInjection':True}
    checkpoint('native-target-choices-control-plan-v1.json',plan)
    for role in ['a','b']:
        shutil.copy2(prefix_out/('session-native-'+role+'.json'),work/('session-'+role+'.json'))
        args=['/Users/dinghaolin/.local/share/riftbound-tools/godot-4.7.2/Godot_mono.app/Contents/MacOS/Godot','--headless','--path',str(root/'clients/godot'),str(work/'live-original-main-target-controls-v5.tscn'),'--','--riftbound-server=http://127.0.0.1:15847','--riftbound-session-file='+str(work/('session-'+role+'.json')),'--qa-evidence='+str(evidence),'--qa-role='+role]
        with (work/('actual-original-main-'+role+'-v1.log')).open('xb') as out:child=subprocess.Popen(args,cwd='/tmp',stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
        clients.append((role,child));proof['ownedNativeProcesses'].append({'role':role,'pid':child.pid,'args':args})
    wait(lambda:count()>=n+1,'Real native edit must reach the SQL journal');assert count()==n+1
    edited,em=export('after-native-edit-before-cold-original-frame-v1');last(edited,b,expected(prompt,choice['id']))
    pending=edited['authoritativeState']['pendingRuleChoice'];assert em['priorAnswers']==1 and pending['answers'][0]['optionId']==choice['id'] and entry['newTargetObjectId'] in pending['request']['reason']
    draft_prompt=edited['playerViews'][b]['prompt'];draft_choices=next(c for c in draft_prompt['candidates'] if c['action']=='PAY_COST')['metadata']['paymentChoices'];assert draft_choices[1]['id']=='CONFIRM'
    checkpoint('actual-original-edit-accepted-v1.json',{'atUtc':now(),'commands':n+1,'originalEditCommandExact':True,'lock':observe_lock()})
    api.terminate();assert api.wait(timeout=30)==0;proof['originalApiGracefulExitCode']=0;api=None
    wait(lambda:all((evidence/(r+'-actual-disconnected-scene-v1.json')).exists() for r in ['a','b']),'Both actual Main disconnected scenes',30)
    start_api(1)
    wait(lambda:all((evidence/(r+'-actual-cold-restored-scene-v1.json')).exists() for r in ['a','b']),'Both actual Main cold restored scenes',90)
    restored,rm=export('after-cold-recovered-edit-original-frame-v1');assert restored==edited and rm['authoritativeStateBytesSha256']==em['authoritativeStateBytesSha256'] and count()==n+1
    checkpoint('actual-cold-recovered-edit-ready-for-confirm-v1.json',{'atUtc':now(),'allOriginalFrameFieldsNullAndHistoryValuesExact':True,'bothActualNativeDisconnectedAndRestoredSceneReceipts':True,'sameFixedInputsAndApiFiles':True,'lock':observe_lock()})
    wait(lambda:count()>=n+2,'Real native confirm must reach SQL');assert count()==n+2
    confirmed,cm=export('after-native-confirm-original-frame-v1');last(confirmed,b,expected(draft_prompt,'CONFIRM'))
    state=confirmed['authoritativeState'];assert state['pendingRuleChoice'] is None
    spell=next(s for s in state['stackItems'] if s['sourceObjectId']==entry['targetSourceObjectId']);assert spell['controllerId']==b and spell['targetObjectIds']==[entry['newTargetObjectId']]
    assert state['cardObjects'][entry['targetSourceObjectId']]['ownerId']==a and entry['sourceObjectId'] in state['playerZones'][b]['graveyard']
    checkpoint('actual-original-confirm-accepted-v1.json',{'atUtc':now(),'commands':n+2,'originalCompleteRawConfirmExact':True,'newTargetAndOriginalPhysicalOwnerControllerLiteralChecks':True})
    current=confirmed
    for offset in [3,4]:
        priority=current['authoritativeState']['priorityPlayerId'];role='a' if priority==a else 'b';assert priority in [a,b]
        pass_prompt=current['playerViews'][priority]['prompt'];want=expected(pass_prompt)
        checkpoint(role+'-allow-original-priority-pass-v1.json',{'atUtc':now(),'originalPromptId':pass_prompt['promptId'],'snapshotTick':pass_prompt['snapshotTick'],'rawCommandExpected':want})
        wait(lambda:count()>=n+offset,'Real native priority pass must reach SQL');assert count()==n+offset
        current,_=export('after-native-priority-pass-'+str(offset-2)+'-original-frame-v1');last(current,priority,want)
    final=current['authoritativeState'];assert final['status']=='IN_PROGRESS' and final['stackItems']==[] and final['pendingRuleChoice'] is None
    assert entry['targetSourceObjectId'] in final['playerZones'][a]['graveyard'] and entry['targetSourceObjectId'] not in final['playerZones'][b]['graveyard']
    assert len(current['commands'])==n+4 and all(x['rawCommand']==y['rawCommand'] and x['playerId']==y['playerId'] for x,y in zip(before['commands'],current['commands'][:n]))
    checkpoint('stop-original-main-controls-v1.json',{'atUtc':now(),'allFourActualNativeCommandsAcceptedAndOriginalPrefixExact':True})
    for role,child in clients:assert child.wait(timeout=25)==0,role+' actual native helper exit'
    proof.update(status='PASS_FIXED_CURRENT_REAL_PG_ORIGINAL_MAIN_PAIR_EDIT_COLD_CONFIRM_AND_BOTH_NATIVE_PASSES',ordinaryPrefixCommands=n,totalCommands=n+4,events=len(current['events']),actualNativeCommands=4,originalPrefixEveryActorAndFullRawCommandExact=True,wholeOriginalColdFrameEveryFieldExact=True,bothOriginalMainDisconnectedAndRestoredScenes=True,actualNativeFinalFrame='actual-ordinary-native-main-v1/after-native-priority-pass-2-original-frame-v1.json.gz',normalEightScoreAndFullIndependentHistoricalReplayStillOpen=True)
    print(proof['status'],room,'prefix',n,'native',4,'events',len(current['events']),flush=True)
except BaseException as error:
    proof.update(status='FAILED_OR_INTERRUPTED_CURRENT_NATIVE_MAIN_PAIR_ORIGINAL_ROOM_RETAINED',errorType=type(error).__name__,errorMessage=str(error));print(proof['status'],type(error).__name__,str(error),flush=True);raise
finally:
    if driver is not None and driver.poll() is None:driver.terminate();driver.wait(timeout=30)
    for role,child in clients:
        if child.poll() is None:child.terminate();child.wait(timeout=15)
        proof.setdefault('nativeExitCodes',{})[role]=child.returncode
    if started and baseline is not None:
        proof['actualNewNativeRoomsAtStop']=sorted(set(rooms('riftbound_here_native'))-set(baseline['nativeRooms']))
        if room is None and len(proof['actualNewNativeRoomsAtStop'])==1:room=proof['actualNewNativeRoomsAtStop'][0];proof['room']=room
        if room is not None and not (evidence/'owner-final-original-frame-v1.json.gz').exists():
            try:export('owner-final-original-frame-v1');proof['latestOriginalFrameRetainedBeforeStop']=True
            except BaseException as error:proof['finalExportErrorType']=type(error).__name__
    if api is not None and api.poll() is None:api.terminate();proof['ownFinalApiGracefulExitCode']=api.wait(timeout=30)
    if started:
        if baseline is not None:
            proof['allOriginal213AuditSevenTablesExactAtStop']=digests('riftbound_acceptance',baseline['auditRooms'])==baseline['auditSevenTables']
            proof['allOriginal45NativeSevenTablesExactAtStop']=digests('riftbound_here_native',baseline['nativeRooms'])==baseline['nativeSevenTables']
        proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
    if power is not None:
        if power.poll() is None:power.terminate();power.wait(timeout=10)
        proof['boundIdleAssertionEnded']=power.poll() is not None
    try:
        frozen();proof['allFixedSourceModesApiReaderPrefixAndNativeRuntimeHashesStable']=True
    except BaseException as integrity_error:
        proof.update(status='FAILED_FIXED_NATIVE_OWNER_FINAL_INPUT_INTEGRITY',allFixedSourceModesApiReaderPrefixAndNativeRuntimeHashesStable=False,inputIntegrityErrorType=type(integrity_error).__name__)
    proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),originalDatabaseRetained=True)
    with terminal.open('x') as out:json.dump(proof,out,ensure_ascii=False,indent=2)
    fcntl.flock(guard,fcntl.LOCK_UN)

assert proof["allFixedSourceModesApiReaderPrefixAndNativeRuntimeHashesStable"] and proof.get("ownPostgresSmartStopped") and proof.get("boundIdleAssertionEnded")
assert proof.get("allOriginal213AuditSevenTablesExactAtStop") and proof.get("allOriginal45NativeSevenTablesExactAtStop")
