import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import zipfile

root=Path('/Users/dinghaolin/MyProjects/riftbound');work=Path(__file__).resolve().parent
out=root/'docs/evidence/fixed-564-native-and-full-2026-10-21'
sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(p.read_bytes())
assert not out.exists()
def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
def pin(path,role):return {'path':str(path.relative_to(root)),'sha256':sha(path.read_bytes()),'role':role}
full=load(work/'fixed564-entire-full-ci-original-independent-verification-v1.json')
native=load(work/'combined-fixed564-locked-native-sql-cold-score-original-replay-v1.json')
assert full['status']=='FIXED_COMMIT_FULL_CI_AND_PARITY_VERIFIED' and len(full['jobs'])==11 and full['sqlOriginalOutputs']==271
assert native['totalCommands']==54 and native['events']==306 and native['normalScore']=='8:0' and native['finalTurn']==23
assert native['actualOriginalMainNativeButtonCommands']==4 and native['visiblePairedCiExportedLiveControlsAndPhysicalWindows']=='OPEN'
secrets=[]
for folder in (work,root/'var/qa/native-signalr-runtime-patch-fixed-43d5b84e-20261020'):
    for p in folder.rglob('session*.json'):
        if any(part in {'bin','obj'} or part.endswith('.app') for part in p.parts):continue
        d=load(p)
        for k in ('playerKey','reconnectToken'):
            if isinstance(d,dict) and isinstance(d.get(k),str) and len(d[k])>=8:secrets.append(d[k].encode())
assert len(secrets)>=4
allowed_folders={p.name for p in work.iterdir() if p.is_dir() and (
    p.name.startswith('actual-') or p.name in {'ci-fixed564','ci-fixed0366-terminal','current-clean-fixed-native6-v1'}
    or p.name.endswith(('-source-v1','-source-v2')))}
text={'.py','.cs','.csproj','.log','.txt','.trx'};raw_types={'.json','.gz','.zip'}
selected=[];excluded=[]
for p in sorted(work.rglob('*')):
    if not p.is_file():continue
    rel=p.relative_to(work)
    if len(rel.parts)>1 and rel.parts[0] not in allowed_folders:continue
    if any(part in {'bin','obj','__pycache__'} or part.endswith('.app') for part in rel.parts):continue
    if p.name.startswith('session') or 'wire' in p.name.lower() or p.name.endswith(('.deps.json','.runtimeconfig.json')):
        excluded.append({'path':str(p.relative_to(root)),'reason':'Private profile/raw realtime wire or redundant loader metadata retained locally only'});continue
    if p.suffix not in text|raw_types:continue
    raw=p.read_bytes()
    if p.suffix=='.gz':blocks=[gzip.decompress(raw)]
    elif p.suffix=='.zip':
        assert rel.parts[0] in {'ci-fixed564','ci-fixed0366-terminal'}
        with zipfile.ZipFile(p) as z:
            assert z.testzip() is None;blocks=[z.read(n) for n in z.namelist() if not n.endswith('/')]
    else:blocks=[raw]
    private=any(s in b for s in secrets for b in blocks)
    def private_fields(value):
        if isinstance(value,dict):return any(k.lower() in {'playerkey','reconnecttoken','accesstoken'} and isinstance(v,str) and len(v)>=8 or private_fields(v) for k,v in value.items())
        if isinstance(value,list):return any(private_fields(v) for v in value)
        return False
    if p.suffix=='.json':private=private or private_fields(json.loads(raw))
    if private:
        excluded.append({'path':str(p.relative_to(root)),'reason':'Contains actual private authentication values; original remains locally protected, no value published'});continue
    assert len(raw)<10*2**20,str(rel)
    selected.append((p,rel,raw))
records=[]
for p,rel,raw in selected:
    compressed=p.suffix in text;dest=out/'originals'/rel
    if compressed:dest=dest.with_name(dest.name+'.gz')
    dest.parent.mkdir(parents=True,exist_ok=True)
    if compressed:dest.write_bytes(gzip.compress(raw,mtime=0))
    else:os.link(p,dest)
    assert (gzip.decompress(dest.read_bytes()) if compressed else dest.read_bytes())==raw
    records.append({'originalPath':str(p.relative_to(root)),'originalSha256':sha(raw),'originalBytes':len(raw),
        'canonical':pin(dest,'fixed564-original-acceptance-evidence'),'gzipOriginalBytes':compressed,'samePhysicalFileHardlinked':not compressed})
mapping={r['originalPath']:r['canonical'] for r in records}
def archived(name,role):
    p=work/name;ref=mapping[str(p.relative_to(root))];return {**ref,'role':role}
for name,h in native['refs'].items():
    assert sha((work/name).read_bytes())==h and str((work/name).relative_to(root)) in mapping
for p in full['originalArtifacts']:
    assert p['path'] in mapping and mapping[p['path']]['sha256']==p['sha256']
write(out/'archive-map.json',{'recordedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'records':records,'allOriginalBytesHashesAndHardlinkInodesVerified':True,'actualPrivateAuthValuesScannedWithoutDisclosure':True,
    'privateProfilesAndWireRemainLocallyRetained':excluded,'runtimeAppsSdksAndOriginalDatabaseNotCopiedOrDeleted':True,
    'onlyLatestPairAndBothVerifiedPlatformPackagesRetainedLocally':True})
manifest={'recordedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fixedCommit':full['commit'],
    'sourceRoundApplicableAsOfAtNativeExecution':'2026-10-20','region':'CN','language':'zh-CN','adoptedCoreEffectiveDate':'2026-10-16',
    'sourceManifestAtExecution':native['sourceManifest'],
    'actualCompleteFixedCi':archived('fixed564-entire-full-ci-original-independent-verification-v1.json','fixed-complete-ci'),
    'actual11JobsAnd13315Cases7631Methods143FullMethods110Pairs47Sql271Outputs':True,
    'actualLockedHeadlessNativeSqlColdNormalScoreFullOriginalReplay':archived('combined-fixed564-locked-native-sql-cold-score-original-replay-v1.json','bounded-actual-locked-native-original-main'),
    'actualNativeCommands':4,'ordinaryOpeningGatewayCommands':33,'normalScoreGatewayCommands':17,'allCommands':54,'events':306,'normalScore':'8:0','finalTurn':23,
    'nativeAcceptanceAuthoritativeStates':54,'nativeAcceptanceBothPlayersCombinedPrivateSnapshots':104,'nativeAcceptanceBothPlayersCombinedPrivatePrompts':104,
    'actualNativeReleaseRuleInputs':native['actualRuleInputs'],'actualSqlCiRuleInputs':full['actualSqlRuleInputs'],
    'differentRuntimeBuildInputsNotFalselyEquated':True,'allOriginalFieldNullAndConditionalOmissionsAndCompleteActionEventStateReplayVerified':True,
    'separateActualLocalGodotToolMainControlsAndCiExportedDefaultHeadlessBootScopes':True,
    'latestMacAndWindowsPatchedBytesAndBoot':archived('latest-fixed-both-platform-actual-patched-byte-proof-v1.json','actual-latest-packaged-bytes'),
    'supersededFixed43AppsAndPackagesActuallyRetired':archived('latest-only-superseded-fixed43-retirement-v1.json','actual-old-package-retirement'),
    'old0366WholeCiFailureAndOriginalRulePass':archived('fixed0366-complete-rule-original-retention-whole-failure-readback-v1.json','previous0366-rule-pass-whole-failure'),
    'previous0366FailureNotRelabelled':True,'originalPartial67RoomAndFailureReceiptsRetainedNotNormalWin':True,
    'original213AuditAnd47NativeBaselineRetainedForFollowingN27':True,'currentN27ZeroTargetAndIntrinsicNoDeclarationChangesNotCovered':True,
    'newCandidateVisiblePairedLiveProductAndPhysicalWindows':'OPEN','wholePrintingAndGlobalSemanticCertification':False}
write(out/'source-manifest.json',manifest)
print('PUBLISHED_FIXED564_BOUNDED_NATIVE_AND_WHOLE11_SUCCESS_ORIGINALS',len(records),len(excluded),flush=True)
