import ast
import collections
import datetime
import fcntl
import gzip
import hashlib
import json
import os
from pathlib import Path
import plistlib
import socket
import subprocess
import time
import urllib.request

os.umask(0o077)
work=Path(__file__).resolve().parent;root=work.parents[2]
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();load=lambda p:json.loads(p.read_text())
source=load(work/'clean-fixed564e433-source-baseline-v1.json');pub=load(work/'fixed-api-and-readonly-runtime-publication-v1.json');native=load(work/'clean-fixed-native-debug-build-v2-restored.json');prefix_pub=load(work/'clean-fixed-native-reversal-prefix-publication-v3-corrected-assembly.json')
runtime=work/'fixed-api-v1';reader=work/'read-only-runtime-v1';prefix=work/'native-reversal-prefix-v1'
entry=load(work/'actual-ordinary-native-prefix-v1/pending-original-native-prefix-receipt.json');room=entry['room'];a,b=entry['players'];n=entry['acceptedCommands']
partial=load(work/'independent-original-two-native-decisions-and-cold-readback-v1.json');assert partial['room']==room and partial['actualNativePayCostCommands']==2
original=load(root/'var/qa/native-spell-choice-presentation-20261020/focused-clairvoyance-original213-audit45-native-baseline-v1.json')
guard_source=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes=[v for v in ast.parse(guard_source.read_text()).body if isinstance(v,ast.FunctionDef) and v.name in {'query','rooms','digests','observe_lock'}];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(guard_source),'exec'),globals())
owner=work/'run-fixed-native-main-paired-reconnect-v1.py';names={'checkpoint','frozen','start_api','export','wait','count','expected','last'}
nodes=[v for v in ast.parse(owner.read_text()).body if isinstance(v,ast.FunctionDef) and v.name in names];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(owner),'exec'),globals())
evidence=work/'actual-native-original-priority-resume-v1';assert not evidence.exists();evidence.mkdir()
terminal=work/'actual-native-original-priority-resume-terminal-v1.json';assert not terminal.exists()
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof={'status':'STARTING_SAME_ORIGINAL_ROOM_TWO_NATIVE_PRIORITY_BUTTONS','startedAtUtc':now(),'fixedCommit':source['fixedCommit'],'room':room,'actualRuleInputs':pub['actualRuleInputs'],'originalPrefixCommands':n,'originalNativePayCostCommandsAlreadyAccepted':2,'originalOwnerFailureAndBothColdFramesRetained':True,'noOpeningSeedOrRoomReplayRestart':True,'ownedApiProcesses':[],'ownedNativeProcesses':[],'lockAtStart':observe_lock(),'visibleCiExportedAndPhysicalWindowsAcceptance':False}
api=power=None;started=False;clients=[];before_history=None

def history_hashes():
    result={}
    for table in ['command_log','game_events','state_snapshots','snapshots','action_prompts']:
        rows=query('riftbound_here_native',"select row_to_json(t)::text from "+table+" t where match_id='"+room+"' order by row_to_json(t)::text").splitlines()
        result[table]=[hashlib.sha256(r.encode()).hexdigest() for r in rows]
    return result

try:
    frozen();assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
    with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
    power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof.update(ownPid=os.getpid(),boundIdleAssertionPid=power.pid)
    checkpoint('same-original-room-owner-start-v1.json',proof)
    subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(work/'actual-owned-postgres-resume-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
    assert rooms('riftbound_acceptance')==original['auditRooms'] and rooms('riftbound_here_native')==sorted(original['nativeRooms']+[room])
    assert digests('riftbound_acceptance',original['auditRooms'])==original['auditSevenTables'] and digests('riftbound_here_native',original['nativeRooms'])==original['nativeSevenTables']
    current,metadata=export('before-original-priority-resume-frame-v1')
    old=json.loads(gzip.decompress((work/'actual-ordinary-native-main-v1/owner-final-original-frame-v1.json.gz').read_bytes()));assert current==old and count()==n+2
    before_history=history_hashes();checkpoint('original60-command-room-five-history-table-row-hashes-v1.json',before_history)
    checkpoint('same-original-room-resume-plan-v1.json',{'atUtc':now(),'fixedCommit':source['fixedCommit'],'room':room,'originalCurrentCommandCount':n+2,'sameEntireOriginalFrameBeforeResume':True,'actualRuleInputs':pub['actualRuleInputs']})
    start_api(2);print('SAME_ORIGINAL_ROOM_REAL_PG_AND_FIXED_API_RESUMED',room,'originalCommands',n+2,flush=True)
    for role in ['a','b']:
        args=['/Users/dinghaolin/.local/share/riftbound-tools/godot-4.7.2/Godot_mono.app/Contents/MacOS/Godot','--headless','--path',str(root/'clients/godot'),str(work/'resume-original-main-priority-only-v1.tscn'),'--','--riftbound-server=http://127.0.0.1:15847','--riftbound-session-file='+str(work/('session-'+role+'.json')),'--qa-evidence='+str(evidence),'--qa-role='+role]
        with (work/('actual-original-main-priority-resume-'+role+'-v1.log')).open('xb') as out:child=subprocess.Popen(args,cwd='/tmp',stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
        clients.append((role,child));proof['ownedNativeProcesses'].append({'role':role,'pid':child.pid,'args':args})
    wait(lambda:all((evidence/(role+'-same-original-room-native-ready-v1.json')).exists() for role in ['a','b']),'Both original Main scenes restored same room',60)
    for offset in [3,4]:
        priority=current['authoritativeState']['priorityPlayerId'];assert priority in [a,b];role='a' if priority==a else 'b';prompt=current['playerViews'][priority]['prompt'];want=expected(prompt)
        checkpoint(role+'-allow-original-priority-pass-v1.json',{'atUtc':now(),'rawCommandExpected':want,'currentRecordedPriorityOwner':priority})
        wait(lambda:count()>=n+offset,'Actual native original priority pass must reach SQL',60);assert count()==n+offset
        current,metadata=export('after-original-native-priority-'+str(offset-2)+'-frame-v1');last(current,priority,want)
    final=current['authoritativeState'];assert final['status']=='IN_PROGRESS' and final['stackItems']==[] and final.get('pendingRuleChoice') is None
    assert current['commands'][:n+2]==old['commands'] and current['events'][:len(old['events'])]==old['events']
    assert entry['targetSourceObjectId'] in final['playerZones'][a]['graveyard'] and entry['targetSourceObjectId'] not in final['playerZones'][b]['graveyard']
    original_new=old['authoritativeState']['cardObjects'][entry['newTargetObjectId']]['power'];original_other=old['authoritativeState']['cardObjects'][entry['originalTargetObjectId']]['power']
    assert final['cardObjects'][entry['newTargetObjectId']]['power']==max(1,original_new-1) and final['cardObjects'][entry['originalTargetObjectId']]['power']==original_other
    assert len(final['playerZones'][b]['hand'])==len(old['authoritativeState']['playerZones'][b]['hand'])+1
    after_history=history_hashes();assert all(collections.Counter(rows)<=collections.Counter(after_history[table]) for table,rows in before_history.items())
    checkpoint('allOriginal60CommandRoomFiveHistoryTablesRetained-v1.json',{'atUtc':now(),'everyOriginalRowSha256AndMultiplicityRetained':True,'beforeCounts':{k:len(v) for k,v in before_history.items()},'afterCounts':{k:len(v) for k,v in after_history.items()}})
    checkpoint('stop-original-main-controls-v1.json',{'atUtc':now(),'bothActualNativePriorityPassCommandsAndLiteralTargetPowerDrawOwnerChecks':True})
    for role,child in clients:assert child.wait(timeout=25)==0,role+' native resume must finish normally'
    proof.update(status='PASS_SAME_ORIGINAL_ROOM_BOTH_NATIVE_PRIORITY_PASSES_AND_ORIGINAL_HISTORY_RETENTION',originalCommandsAtResume=n+2,totalCommands=n+4,totalNativeCommandsAcrossOriginalRunAndResume=4,actualResumeNativeCommands=2,totalEvents=len(current['events']),allOriginal60CommandsAndEventsExact=True,allOriginalFiveHistoricalTableRowBytesRetainedByShaAndMultiplicity=True,literalNewTargetReducedOtherTargetUnchangedNewControllerDrawAndOriginalSourceOwnerChecks=True,normalEightScoreAndFullIndependentHistoricalReplayStillOpen=True)
    print(proof['status'],room,'commands',n+4,'events',len(current['events']),flush=True)
except BaseException as error:
    proof.update(status='FAILED_OR_INTERRUPTED_SAME_ORIGINAL_ROOM_PRIORITY_RESUME_RETAINED',errorType=type(error).__name__,errorMessage=str(error));print(proof['status'],type(error).__name__,str(error),flush=True);raise
finally:
    for role,child in clients:
        if child.poll() is None:child.terminate();child.wait(timeout=15)
        proof.setdefault('nativeExitCodes',{})[role]=child.returncode
    if started:
        try:export('owner-final-same-original-room-frame-v1');proof['latestOriginalFrameRetainedBeforeStop']=True
        except BaseException as error:proof['finalExportErrorType']=type(error).__name__
    if api is not None and api.poll() is None:api.terminate();proof['ownApiGracefulExitCode']=api.wait(timeout=30)
    if started:
        proof['allOriginal213AuditSevenTablesExactAtStop']=digests('riftbound_acceptance',original['auditRooms'])==original['auditSevenTables']
        proof['allOriginal45NativeSevenTablesExactAtStop']=digests('riftbound_here_native',original['nativeRooms'])==original['nativeSevenTables']
        proof['same46NativeRoomIdsRetained']=rooms('riftbound_here_native')==sorted(original['nativeRooms']+[room])
        proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
    if power is not None:
        if power.poll() is None:power.terminate();power.wait(timeout=10)
        proof['boundIdleAssertionEnded']=power.poll() is not None
    try:frozen();proof['allFixedSourceModesApiReaderPrefixAndNativeRuntimeHashesStable']=True
    except BaseException as error:proof.update(status='FAILED_FINAL_FIXED_NATIVE_RESUME_INPUT_INTEGRITY',allFixedSourceModesApiReaderPrefixAndNativeRuntimeHashesStable=False,inputIntegrityErrorType=type(error).__name__)
    proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),originalDatabaseRetained=True)
    with terminal.open('x') as out:json.dump(proof,out,ensure_ascii=False,indent=2)
    fcntl.flock(guard,fcntl.LOCK_UN)
assert proof['allFixedSourceModesApiReaderPrefixAndNativeRuntimeHashesStable'] and proof.get('ownPostgresSmartStopped') and proof.get('boundIdleAssertionEnded')
assert proof.get('allOriginal213AuditSevenTablesExactAtStop') and proof.get('allOriginal45NativeSevenTablesExactAtStop') and proof.get('same46NativeRoomIdsRetained')
