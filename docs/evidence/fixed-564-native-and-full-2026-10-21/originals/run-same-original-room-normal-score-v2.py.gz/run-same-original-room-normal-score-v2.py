import ast
import collections
import datetime
import fcntl
import gzip
import hashlib
import json
import os
from pathlib import Path
import plistlib
import re
import socket
import subprocess
import time
import urllib.request

os.umask(0o077)
work=Path(__file__).resolve().parent;root=work.parents[2]
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();load=lambda p:json.loads(p.read_text())
source=load(work/'clean-fixed564e433-source-baseline-v1.json');pub=load(work/'fixed-api-and-readonly-runtime-publication-v1.json');native=load(work/'clean-fixed-native-debug-build-v2-restored.json');prefix_pub=load(work/'clean-fixed-native-reversal-prefix-publication-v3-corrected-assembly.json')
score_pub=load(work/'same-original-room-normal-score-publication-v2.json');score_runtime=work/'same-original-room-normal-score-runtime-v2'
runtime=work/'fixed-api-v1';reader=work/'read-only-runtime-v1';prefix=work/'native-reversal-prefix-v1'
entry=load(work/'actual-ordinary-native-prefix-v1/pending-original-native-prefix-receipt.json');room=entry['room'];a,b=entry['players']
original=load(root/'var/qa/native-spell-choice-presentation-20261020/focused-clairvoyance-original213-audit45-native-baseline-v1.json')
for source_path,names in [(root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py',{'query','rooms','digests','observe_lock'}),(work/'run-fixed-native-main-paired-reconnect-v1.py',{'checkpoint','frozen','start_api','export','count'}),(work/'resume-fixed-native-original-priority-v2.py',{'history_hashes'})]:
    nodes=[v for v in ast.parse(source_path.read_text()).body if isinstance(v,ast.FunctionDef) and v.name in names];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source_path),'exec'),globals())
evidence=work/'actual-same-original-room-normal-score-v2';assert not evidence.exists();evidence.mkdir()
terminal=work/'actual-same-original-room-normal-score-terminal-v2.json';assert not terminal.exists()
ready=work/'actual-same-original-room-normal-score-ready-v2.json';stop=work/'actual-same-original-room-normal-score-stop-v2.json';assert not ready.exists() and not stop.exists()
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof={'status':'STARTING_ORIGINAL67_ROOM_NORMAL_SCORE_CONTINUATION','startedAtUtc':now(),'fixedCommit':source['fixedCommit'],'room':room,'actualRuleInputs':pub['actualRuleInputs'],'originalFourNativeButtonCommandsAlreadyAccepted':True,'allOwnerWrapperFailuresPreserved':True,'noOriginalOpeningSeedCommandHistoryOrNativeDecisionsReplayed':True,'ownedApiProcesses':[],'lockAtStart':observe_lock(),'visibleCiExportedOrPhysicalWindowsAcceptance':False}
api=power=driver=None;started=False

def subset(before,after):
    for table,values in before.items():
        wanted=collections.Counter(values);actual=collections.Counter(after[table])
        assert all(actual.get(key,0)>=amount for key,amount in wanted.items()),table+' original historical row changed'

try:
    frozen();assert all(sha(score_runtime/p)==h for p,h in score_pub['runtimeHashes'].items())
    assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
    with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
    power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof.update(ownPid=os.getpid(),boundIdleAssertionPid=power.pid);checkpoint('normal-score-owner-start-v1.json',proof)
    subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(work/'actual-owned-postgres-normal-score-v2.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
    assert rooms('riftbound_acceptance')==original['auditRooms'] and rooms('riftbound_here_native')==sorted(original['nativeRooms']+[room])
    assert digests('riftbound_acceptance',original['auditRooms'])==original['auditSevenTables'] and digests('riftbound_here_native',original['nativeRooms'])==original['nativeSevenTables']
    current,_=export('before-original67-held-score-frame-v1');saved=json.loads(gzip.decompress((work/'actual-same-original-room-normal-score-v1/owner-final-original-normal-score-frame-v1.json.gz').read_bytes()));assert current==saved and count()==67
    before=history_hashes();old60=load(work/'actual-same-original-room-normal-score-v1/original62-five-history-table-row-hashes-v1.json');subset(old60,before)
    checkpoint('original62-and67-five-history-tables-actual-retention-v1.json',{'atUtc':now(),'original62EveryRowAndMultiplicityActuallyVerified':True,'actual67BeforeCounts':{k:len(v) for k,v in before.items()},'originalCounterPython39FailureNotRelabelled':True})
    checkpoint('original67-five-history-table-row-hashes-v1.json',before)
    start_api(5);print('SAME_ORIGINAL67_ROOM_HELD_SKILL_AND_SCORE_READY',room,flush=True)
    output=work/'actual-original-normal-score-gateway-v2'
    with (work/'actual-original-normal-score-gateway-v2.log').open('xb') as out:
        driver=subprocess.Popen(['/Users/dinghaolin/.dotnet/dotnet',str(score_runtime/'Fixed564OriginalHeldScoreContinuation.dll'),'http://127.0.0.1:15847',str(output),str(work)],cwd=score_runtime,stdout=out,stderr=subprocess.STDOUT)
        assert driver.wait(timeout=330)==0,'Original ordinary score gateway continuation failed; retain exact checkpoint.'
    receipt=load(output/'normal-original-score-continuation-receipt.json');assert receipt['normalEndTurns']==12 and receipt['winningScore']==8 and receipt['finalTurn']==48 and count()==receipt['finalCommands']
    final,fm=export('after-original-final-held-score-frame-v1');state=final['authoritativeState'];assert state['status']=='FINISHED' and state['winnerPlayerId']==a and state['playerScores'][a]==8 and state['playerScores'][b]==0
    assert final['commands'][:67]==saved['commands'] and final['events'][:len(saved['events'])]==saved['events'] and final['openingSeed']==saved['openingSeed'] and final['replayInitialState']==saved['replayInitialState']
    after=history_hashes();subset(before,after)
    checkpoint('allOriginal62And67FiveHistoryRowsRetainedAfterWin-v1.json',{'atUtc':now(),'allOriginal62And67RowBytesSha256AndMultiplicityRetained':True,'beforeCounts':{k:len(v) for k,v in before.items()},'afterCounts':{k:len(v) for k,v in after.items()}})
    proof.update(status='NORMAL_SCORE_READY_FOR_INDEPENDENT_ORIGINAL_SQL_HISTORY_AND_REPLAY_READ',totalCommands=count(),events=len(final['events']),winningScore=8,losingScore=0,finalTurn=48,allOriginal67CommandsEventsPrivateSeedAndBlankInitialExact=True,allOriginalFiveHistoryTableRowsRetained=True,normalContinuationCommandsAreProductionGatewayNotNativeButtons=True)
    with ready.open('x') as out:json.dump({**proof,'apiPid':api.pid,'actualDatabase':'riftbound_here_native','rawFrame':str((evidence/'after-original-final-held-score-frame-v1.json.gz').relative_to(root)),'onlyThisOwnerMayStopItsServices':True},out,ensure_ascii=False,indent=2)
    print(proof['status'],room,str(count())+' commands',len(final['events']),'events','score8:0 turn48',flush=True)
    limit=time.monotonic()+900
    while not stop.exists():
        assert api.poll() is None and time.monotonic()<limit,'Owned normal-score read window expired.'
        time.sleep(.2)
    stop_receipt=load(stop);assert stop_receipt['originalRoom']==room and stop_receipt['independentReadOnlyHistoryAndFullReplayPass']
    proof['status']='PASS_ORIGINAL_NORMAL_HELD_SCORE_AND_INDEPENDENT_SQL_READ_STOP_REQUESTED'
except BaseException as error:
    proof.update(status='FAILED_OR_INTERRUPTED_ORIGINAL_ROOM_NORMAL_SCORE_RETAINED',errorType=type(error).__name__,errorMessage=str(error));print(proof['status'],type(error).__name__,str(error),flush=True);raise
finally:
    if driver is not None and driver.poll() is None:driver.terminate();driver.wait(timeout=20)
    if started:
        try:export('owner-final-original-normal-score-frame-v1');proof['latestOriginalFrameRetainedBeforeStop']=True
        except BaseException as error:proof['finalExportErrorType']=type(error).__name__
    if api is not None and api.poll() is None:api.terminate();proof['ownApiGracefulExitCode']=api.wait(timeout=30)
    if started:
        proof['allOriginal213AuditSevenTablesExactAtStop']=digests('riftbound_acceptance',original['auditRooms'])==original['auditSevenTables']
        proof['allOriginal45NativeSevenTablesExactAtStop']=digests('riftbound_here_native',original['nativeRooms'])==original['nativeSevenTables']
        proof['same46NativeRoomIdsRetained']=rooms('riftbound_here_native')==sorted(original['nativeRooms']+[room])
        proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
    if power is not None:
        if power.poll() is None:power.terminate();power.wait(timeout=10)
        proof['boundIdleAssertionEnded']=power.poll() is not None
    try:
        frozen();assert all(sha(score_runtime/p)==h for p,h in score_pub['runtimeHashes'].items());proof['allFixedSourceModesApiReaderPrefixNativeAndScoreRuntimeHashesStable']=True
    except BaseException as error:proof.update(status='FAILED_FINAL_ORIGINAL_SCORE_FIXED_INPUT_INTEGRITY',allFixedSourceModesApiReaderPrefixNativeAndScoreRuntimeHashesStable=False,inputIntegrityErrorType=type(error).__name__)
    proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),originalDatabaseRetained=True)
    with terminal.open('x') as out:json.dump(proof,out,ensure_ascii=False,indent=2)
    fcntl.flock(guard,fcntl.LOCK_UN)
assert proof['allFixedSourceModesApiReaderPrefixNativeAndScoreRuntimeHashesStable'] and proof.get('ownPostgresSmartStopped') and proof.get('boundIdleAssertionEnded')
assert proof.get('allOriginal213AuditSevenTablesExactAtStop') and proof.get('allOriginal45NativeSevenTablesExactAtStop')
