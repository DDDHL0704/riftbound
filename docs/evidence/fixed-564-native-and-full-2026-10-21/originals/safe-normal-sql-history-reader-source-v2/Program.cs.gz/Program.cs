using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

var json=new JsonSerializerOptions(JsonSerializerDefaults.Web){WriteIndented=true};
Check(args.Length==2,"Exact current evidence directory and new receipt path required.");var work=Path.GetFullPath(args[0]);var output=Path.GetFullPath(args[1]);Check(!File.Exists(output),"Preserve original reader results.");
using var entryDoc=JsonDocument.Parse(File.ReadAllText(Path.Combine(work,"actual-safe-native-prefix-v1/pending-original-native-prefix-receipt.json")));var entry=entryDoc.RootElement;var room=entry.GetProperty("room").GetString()!;var actors=entry.GetProperty("players").EnumerateArray().Select(x=>x.GetString()!).ToArray();var a=actors[0];var b=actors[1];var n=entry.GetProperty("acceptedCommands").GetInt32();
using var ready=JsonDocument.Parse(File.ReadAllText(Path.Combine(work,"actual-safe-normal-score-ready-v1.json")));Check(ready.RootElement.GetProperty("room").GetString()==room&&ready.RootElement.GetProperty("fixedCommit").GetString()=="564e433d54d47f98b405787eed97cbdd48b7c394","Exact current fixed-candidate room.");
var settings=new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));Check(settings.Host=="127.0.0.1"&&settings.Port==55486&&settings.Database=="riftbound_here_native"&&settings.Username=="codex_riftbound_audit","Only own existing original native database.");settings.Options="-c default_transaction_read_only=on";
await using var source=NpgsqlDataSource.Create(settings.ConnectionString);var frame=await new PostgresMatchRecoveryStore(source).LoadAsync(room,default)??throw new Exception("Actual SQL frame required.");
using var original=Read(Path.Combine(work,"actual-safe-normal-score-v1/after-safe-normal-score-final-original-frame-v1.json.gz"));Check(JsonNode.DeepEquals(JsonNode.Parse(original.RootElement.GetRawText()),JsonSerializer.SerializeToNode(frame,json)),"Every original final frame field/null equals actual SQL.");
Check(frame.IsConsistent&&frame.Commands.Count==54&&frame.Events.Count==306&&n==33&&frame.Commands.All(c=>c.Accepted&&c.RuleInputs==RuleInputIdentity.Current)&&frame.AuthoritativeState!.RuleInputs==RuleInputIdentity.Current&&frame.OpeningSeed!=0&&frame.ReplayInitialState is{Tick:0,CardObjects.Count:0},"Exact54 commands306 events, all current inputs, original private nonzero seed and blank opening.");
using var prefix=JsonDocument.Parse(File.ReadAllText(Path.Combine(work,"actual-safe-native-prefix-v1/original-accepted-native-prefix-intents.json")));for(var i=0;i<n;i++)Check(frame.Commands[i].PlayerId==prefix.RootElement[i].GetProperty("actor").GetString()&&Same(frame.Commands[i].RawCommand!.Value,prefix.RootElement[i].GetProperty("rawCommand")),"Every original gateway prefix actor/raw field.");
using var nativeDoc=Read(Path.Combine(work,"actual-safe-native-main-v1/after-native-priority-pass-2-original-frame-v1.json.gz"));var nativeFrame=nativeDoc.RootElement.Deserialize<MatchRecoveryFrame>(json)!;Check(nativeFrame.Commands.Count==37&&nativeFrame.Events.Count==143&&Same(JsonSerializer.SerializeToElement(frame.Commands.Take(37),json),nativeDoc.RootElement.GetProperty("commands"))&&Same(JsonSerializer.SerializeToElement(frame.Events.Take(143),json),nativeDoc.RootElement.GetProperty("events")),"Every original native37 command and143 event field remains unchanged before normal score.");
using var plan=JsonDocument.Parse(File.ReadAllText(Path.Combine(work,"actual-safe-native-main-v1/native-target-choices-control-plan-v1.json")));var edit=plan.RootElement.GetProperty("editChoiceId").GetString()!;
var prior=new[]{("before-native-original-frame-v1",b),("after-native-edit-before-cold-original-frame-v1",b),("after-native-confirm-original-frame-v1",b),("after-native-priority-pass-1-original-frame-v1",a)};
for(var i=0;i<4;i++)
{
 using var saved=Read(Path.Combine(work,"actual-safe-native-main-v1",prior[i].Item1+".json.gz"));var prompt=saved.RootElement.GetProperty("playerViews").GetProperty(prior[i].Item2).GetProperty("prompt");var expected=new JsonObject{["cmdType"]=i<2?"PAY_COST":"PASS_PRIORITY",["promptId"]=prompt.GetProperty("promptId").GetString(),["snapshotTick"]=prompt.GetProperty("snapshotTick").GetInt64()};
 if(i<2){var metadata=prompt.GetProperty("candidates").EnumerateArray().Single(c=>c.GetProperty("action").GetString()=="PAY_COST").GetProperty("metadata");expected["paymentId"]=metadata.GetProperty("paymentId").GetString();expected["paymentWindow"]="RULE_REPLACEMENT";expected["paymentChoiceIds"]=new JsonArray(i==0?edit:"CONFIRM");}
 Check(frame.Commands[n+i].PlayerId==prior[i].Item2&&JsonNode.DeepEquals(expected,JsonNode.Parse(frame.Commands[n+i].RawCommand!.Value.GetRawText())),"All four exact genuine native raw intents use their original actor/prompt/tick/choice.");
}
var initialDoc=Read(Path.Combine(work,"actual-safe-native-main-v1/before-native-original-frame-v1.json.gz"));using(initialDoc)
{
 var initial=initialDoc.RootElement.GetProperty("authoritativeState").Deserialize<MatchState>(json)!;var state=nativeFrame.AuthoritativeState!;var target=entry.GetProperty("newTargetObjectId").GetString()!;var other=entry.GetProperty("originalTargetObjectId").GetString()!;var spell=entry.GetProperty("targetSourceObjectId").GetString()!;
 Check(state.CardObjects[target].Power==Math.Max(1,initial.CardObjects[target].Power-1)&&state.CardObjects[other].Power==initial.CardObjects[other].Power&&state.PlayerZones[b].Hand.Count==initial.PlayerZones[b].Hand.Count+1,"Literal native newly chosen target only and new-controller draw.");
 Check(state.CardPlays.Resolved.Single(c=>c.Source.ObjectId==spell).PlayerId==b&&state.CardPlays.Finalized.Single(c=>c.Source.ObjectId==spell).PlayerId==a&&state.PlayerZones[a].Graveyard.Contains(spell)&&!state.PlayerZones[b].Graveyard.Contains(spell),"Resolver, finalizer and physical source owner remain distinct.");
}
using var continuation=JsonDocument.Parse(File.ReadAllText(Path.Combine(work,"actual-safe-normal-score-gateway-v1/all-original-normal-score-continuation-intents.json")));Check(continuation.RootElement.GetArrayLength()==17,"All17 real production gateway score commands retained.");for(var i=0;i<17;i++)Check(frame.Commands[37+i].PlayerId==continuation.RootElement[i].GetProperty("actor").GetString()&&Same(frame.Commands[37+i].RawCommand!.Value,continuation.RootElement[i].GetProperty("rawCommand")),"Each full original gateway continuation actor and raw command exact.");
Check(frame.Commands.Skip(37).Select(c=>c.CommandType).SequenceEqual(new[]{"MOVE_UNIT","PASS_FOCUS","PASS_FOCUS"}.Concat(Enumerable.Repeat("END_TURN",14))),"One actual move,two focus passes,fourteen turn endings.");
var final=frame.AuthoritativeState!;Check(final.Status==MatchStatuses.Finished&&final.WinnerPlayerId==a&&final.PlayerScores[a]==8&&final.PlayerScores[b]==0&&final.TurnNumber==23&&final.PlayerZones.Values.All(z=>z.MainDeck.Count>0),"Normal8:0 atturn23 with both original nonempty decks.");
Check(frame.Events.Count(e=>e.Event.Kind=="MATCH_WON")==1&&frame.Events.All(e=>e.Event.Kind is not("PLAYER_SURRENDERED" or "MATCH_SURRENDERED" or "DECK_OUT" or "DECK_EXHAUSTED_LOSS")),"One normal win and no surrender or exhaustion.");var scores=frame.Events.Where(e=>e.Event.Kind=="SCORE_GAINED").Select(e=>JsonSerializer.SerializeToElement(e.Event.Payload,json)).ToArray();Check(scores.Length==8&&scores.Select(x=>x.GetProperty("score").GetInt32()).SequenceEqual(Enumerable.Range(1,8))&&scores.All(x=>x.GetProperty("playerId").GetString()==a&&x.GetProperty("amount").GetInt32()==1)&&scores[0].GetProperty("reason").GetString()=="BATTLEFIELD_CONQUERED_SCORE"&&scores.Skip(1).All(x=>x.GetProperty("reason").GetString()=="BATTLEFIELD_HELD_SCORE"),"Exactly one conquest and seven holds supply all eight points.");
var states=new Dictionary<(long Tick,long Sequence),MatchState>();var counts=new Dictionary<string,int>();var pending=0;var draft=0;
await using(var connection=await source.OpenConnectionAsync())
{
 Check((string)(await new NpgsqlCommand("show transaction_read_only",connection).ExecuteScalarAsync())! =="on","Actual read-only transaction required.");
 await using(var q=new NpgsqlCommand("select last_event_sequence,payload::text from state_snapshots where match_id=@room order by id",connection))
 {
  q.Parameters.AddWithValue("room",room);await using var rows=await q.ExecuteReaderAsync();while(await rows.ReadAsync())
  {
   var sequence=rows.GetInt64(0);var text=rows.GetString(1);var state=JsonSerializer.Deserialize<MatchState>(text,json)!;Check(JsonNode.DeepEquals(JsonNode.Parse(text),JsonSerializer.SerializeToNode(state,json))&&state.RuleInputs==RuleInputIdentity.Current,"Every historical authoritative state field/null/conditional omission and rule identity exact.");Check(states.TryAdd((state.Tick,sequence),state),"Unique original accepted state tick plus journal event sequence.");
   if(state.PendingRuleChoice is{} choice){pending++;Check(choice.Request.PlayerId==b&&choice.Request.Kind=="SPELL_CHOICE_REMAKE"&&choice.Request.Options.Any(o=>o.Id=="KEEP_ALL")&&!choice.Request.Options.Any(o=>o.Label.Contains("模式 ")||o.Label.Contains("目的地")),"Original historical target-only owner/scope retained.");if(choice.Answers.Count==1){draft++;Check(choice.Answers[0].OptionId==edit&&choice.Request.Options.Any(o=>o.Id=="CONFIRM"),"Original draft edit before confirm.");}else Check(choice.Answers.Count==0,"Only the two actual original choice checkpoints.");}
  }
 }
 counts["state_snapshots"]=states.Count;
 foreach(var table in new[]{"snapshots","action_prompts"})
 {
  await using var q=new NpgsqlCommand($"select player_id,last_event_sequence,payload::text from {table} where match_id=@room order by id",connection);q.Parameters.AddWithValue("room",room);await using var rows=await q.ExecuteReaderAsync();var total=0;
  while(await rows.ReadAsync())
  {
   var actor=rows.GetString(0);var sequence=rows.GetInt64(1);var text=rows.GetString(2);using var doc=JsonDocument.Parse(text);var tick=doc.RootElement.GetProperty(table=="snapshots"?"tick":"snapshotTick").GetInt64();Check(states.TryGetValue((tick,sequence),out var state),"Original private row binds an actual persisted historical state.");var typed=table=="snapshots"?JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<SnapshotDto>(text,json),json):JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<ActionPromptDto>(text,json),json);Check(JsonNode.DeepEquals(JsonNode.Parse(text),typed),"Every original historical private field/null survives independent typed read.");var expected=table=="snapshots"?JsonSerializer.SerializeToNode(ResolutionResult.BuildSnapshots(state!)[actor],json):JsonSerializer.SerializeToNode(ResolutionResult.BuildPrompts(state!)[actor],json);Check(JsonNode.DeepEquals(JsonNode.Parse(text),expected),"Every original private snapshot/prompt matches the entire projection of its exact historical state.");total++;
  }
  counts[table]=total;
 }
}
Check(counts["state_snapshots"]==54&&counts["snapshots"]==104&&counts["action_prompts"]==104&&pending==2&&draft==1,"All54 states104 private views104 prompts and two explicit original target checkpoints.");var errors=await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame,new CoreRuleEngine(),default);Check(errors.Count==0,"Entire original normal blank-opening action/event/state replay: "+string.Join(';',errors));
var result=new{status="PASS_INDEPENDENT_ACTUAL_SQL_ALL_HISTORY_FIELDS_PRIVATE_PROJECTIONS_AND_FULL_ORIGINAL_NORMAL_SCORE_REPLAY",room,commands=54,events=306,originalPrefix=33,actualNativeButtonCommands=4,actualProductionGatewayScoreCommands=17,winningScore=8,losingScore=0,finalTurn=23,actualHistoricalPayloads=counts,originalPendingStates=pending,originalDraftStates=draft,allOriginalFieldsNullConditionalOmissionsAndPrivateProjectionValuesExact=true,literalNativeTargetDrawOwnerAndNormalConquestHoldWinChecks=true,originalNonzeroPrivateSeedAndBlankOpeningPreservedNotPrinted=true,actualRuleInputs=RuleInputIdentity.Current,visibleCiExportedAndPhysicalWindowsAcceptance=false};
await File.WriteAllTextAsync(output,JsonSerializer.Serialize(result,json));Console.WriteLine(JsonSerializer.Serialize(result,json));
bool Same(JsonElement x,JsonElement y)=>JsonNode.DeepEquals(JsonNode.Parse(x.GetRawText()),JsonNode.Parse(y.GetRawText()));
static JsonDocument Read(string path){using var z=new GZipStream(File.OpenRead(path),CompressionMode.Decompress);return JsonDocument.Parse(z);}
static void Check(bool value,string reason){if(!value)throw new Exception(reason);}
