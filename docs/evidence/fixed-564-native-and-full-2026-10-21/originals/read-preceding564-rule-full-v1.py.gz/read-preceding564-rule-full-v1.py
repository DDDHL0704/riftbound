import collections
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time
import xml.etree.ElementTree as ET
import zipfile

root = Path('/Users/dinghaolin/MyProjects/riftbound')
work = Path(__file__).resolve().parent
out = work / 'ci-fixed564'
fixed = '564e433d54d47f98b405787eed97cbdd48b7c394'
run = 39442248507
sha = lambda b: hashlib.sha256(b).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(path, value):
    with path.open('x') as f: json.dump(value, f, ensure_ascii=False, indent=2); f.write('\n')

status_raw = subprocess.check_output(['gh','run','view',str(run),'--json','databaseId,headSha,status,conclusion,jobs'])
(out/'rule-completed-whole-still-pending-status-v1.json').write_bytes(status_raw)
status = json.loads(status_raw)
assert status['headSha'] == fixed
assert next(j for j in status['jobs'] if j['name']=='rule_suite')['conclusion']=='success'
index_raw = subprocess.check_output(['gh','api',f'repos/DDDHL0704/riftbound/actions/runs/{run}/artifacts?per_page=100'])
(out/'rule-completed-artifact-metadata-v1.json').write_bytes(index_raw)
meta = next(r for r in json.loads(index_raw)['artifacts'] if r['name']=='conformance-results')
assert not meta['expired'] and meta['workflow_run']['head_sha']==fixed
dest = out/'conformance-results.zip'
assert not dest.exists()
for attempt in range(1,4):
    temp = out/f'conformance-results.download-{attempt}'
    with temp.open('xb') as f:
        p = subprocess.run(['gh','api',f'repos/DDDHL0704/riftbound/actions/artifacts/{meta["id"]}/zip'],stdout=f,stderr=subprocess.PIPE,timeout=55)
    raw = temp.read_bytes()
    if p.returncode==0 and len(raw)==meta['size_in_bytes'] and 'sha256:'+sha(raw)==meta['digest']:
        with zipfile.ZipFile(temp) as z: assert z.testzip() is None
        temp.rename(dest)
        break
    failed=out/f'conformance-results-failed-{attempt}.original.gz'
    failed.write_bytes(gzip.compress(raw,mtime=0))
    write(out/f'conformance-results-failed-{attempt}-receipt.json',{'atUtc':now(),'exitCode':p.returncode,'rawBytes':len(raw),'rawSha256':sha(raw),'stderr':p.stderr.decode(errors='replace'),'notValidArtifact':True})
    temp.unlink()
    if attempt==3: raise RuntimeError('Original conformance artifact not verified')
    time.sleep(2)

def read_rules(path):
    cases=collections.Counter();methods=set();trx={};matrix=[]
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        summary=json.loads(z.read('ci-rules/summary.json'));plan=json.loads(z.read('ci-rules/plan.json'))
        assert summary['status']=='PASSED' and summary['profile']=='full'
        for name in z.namelist():
            if not name.endswith('.trx'): continue
            raw=z.read(name);trx[name]=sha(raw);r=ET.fromstring(raw);ns={'t':r.tag.split('}')[0][1:]}
            for u in r.findall('.//t:UnitTest',ns):
                m=u.find('t:TestMethod',ns)
                assert m is not None
                methods.add(m.attrib['className']+'.'+m.attrib['name'])
            for result in r.findall('.//t:UnitTestResult',ns):
                assert result.attrib['outcome']=='Passed'
                cases[result.attrib['testName']]+=1
                for output in result.findall('.//t:StdOut',ns):
                    for line in (output.text or '').splitlines():
                        if line.startswith('PRECONSTRUCTED_MATRIX '): matrix.append(json.loads(line.removeprefix('PRECONSTRUCTED_MATRIX ')))
        assert summary['total']==sum(cases.values())==13315 and len(methods)==7631
        assert all(s['failed']==s['notExecuted']==0 and s['passed']==s['total'] for s in summary['shards'])
        return cases,methods,trx,matrix,plan

old_cases,old_methods,old_trx,old_matrix,old_plan=read_rules(work/'ci-fixed0366-terminal/conformance-results.zip')
cases,methods,trx,matrix,plan=read_rules(dest)
assert cases==old_cases and methods==old_methods
assert len(matrix)==len(old_matrix)==1
m=matrix[0];old=old_matrix[0]
assert m['seed']==old['seed']==424242 and m['deckCount']==old['deckCount']==11 and m['pairCount']==old['pairCount']==110
assert set(m['completed'])==set(old['completed']) and len(m['completed'])==110
assert all(re.fullmatch('[0-9a-f]{64}',v) for v in m['completed'].values())
full_methods={m for m in methods if '.FullGameEndToEndTests.' in m}
assert len(full_methods)==143
with zipfile.ZipFile(dest) as z:
    assert z.read('ci-rule-suite-commit.txt').decode().strip()==fixed
    source_hashes={}
    old_receipt=json.loads((work/'fixed0366-complete-rule-original-retention-whole-failure-readback-v1.json').read_text())
    for path,expected in old_receipt['allNineOriginalFullGameSourcesByteExact'].items():
        actual=subprocess.check_output(['git','show',fixed+':'+path],cwd=root)
        assert sha(actual)==expected
        source_hashes[path]=expected
result={'atUtc':now(),'status':'PASS_FIXED564_FULL_RULE_ORIGINALS_ONLY_SQL0_AND_WHOLE_GATE_SEPARATE',
    'fixedCommit':fixed,'runId':run,'actualCases':sum(cases.values()),'actualUniqueMethods':len(methods),
    'exactSameCaseMultisetAndMethodSetAsPrevious0366':True,'all143OriginalFullGameMethods':sorted(full_methods),
    'preconstructedMatrix':m,'allNineOriginalFullGameSourcesByteExact':source_hashes,
    'originalTrxHashes':trx,'testAssemblySha256':plan.get('testAssemblySha256'),
    'artifact':{'path':str(dest.relative_to(root)),'sha256':sha(dest.read_bytes()),'bytes':dest.stat().st_size,'backendSizeDigestCrcVerified':True,'id':meta['id']},
    'original0366WholeCiFailureUnchanged':True,'currentN27UncommittedChangesNotCovered':True,
    'visiblePairedProductAndPhysicalWindowsStillOpen':True,'wholePrintingOrGlobalCertification':False}
write(work/'fixed564-complete-rule-original-retention-readback-v1.json',result)
print(result['status'],result['actualCases'],result['actualUniqueMethods'],len(m['completed']),flush=True)
