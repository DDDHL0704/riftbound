import datetime
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import zipfile

root=Path('/Users/dinghaolin/MyProjects/riftbound');work=Path(__file__).resolve().parent;out=work/'ci-fixed564'
fixed='564e433d54d47f98b405787eed97cbdd48b7c394';run=39442248507
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_bytes())
def pin(p,role):return {'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes()),'role':role}
def write(path,value):
    with path.open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
status_path=sorted(out.glob('actual-run-jobs-*.json'))[-1];status=load(status_path)
metadata_path=sorted(out.glob('actual-artifact-index-*.json'))[-1];metadata={a['name']:a for a in load(metadata_path)['artifacts']}
assert status['headSha']==fixed and status['status']=='completed' and status['conclusion']=='success'
jobs={j['name']:j['conclusion'] for j in status['jobs']}
assert len(jobs)==11 and set(jobs.values())=={'success'} and all(j['status']=='completed' for j in status['jobs'])
manifest_raw=subprocess.check_output(['git','show',fixed+':tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'],cwd=root)
ids=[c['id'] for c in json.loads(manifest_raw)['cases']]
assert len(ids)==len(set(ids))==47
artifacts=[]
for name in ('conformance-results','postgres-partition-0','postgres-partition-1','postgres-partition-2','postgres-partition-3','postgres-results','native-network-results','full-verification-gate'):
    p=out/(name+'.zip');raw=p.read_bytes();m=metadata[name]
    assert len(raw)==m['size_in_bytes'] and 'sha256:'+sha(raw)==m['digest'] and m['workflow_run']['head_sha']==fixed and not m['expired']
    with zipfile.ZipFile(p) as z:assert z.testzip() is None
    artifacts.append({**pin(p,'original-ci-artifact'),'name':name,'bytes':len(raw),'artifactId':m['id'],'backendSizeDigestCrcVerified':True})
with zipfile.ZipFile(out/'postgres-results.zip') as z:aggregate=json.loads(z.read('result.json'))
assert aggregate['status']=='FIXED_COMMIT_ALL_SQL_PARTITIONS_AND_NATIVE_NETWORK_PASS' and aggregate['fixedCommit']==fixed
assert aggregate['manifestSha256']==sha(manifest_raw) and aggregate['caseCount']==47 and aggregate['orderedDefaultCases']==ids and aggregate['partitionCount']==4
parts=[];all_cases=[];identity=assemblies=None
for i in range(4):
    with zipfile.ZipFile(out/f'postgres-partition-{i}.zip') as z:
        raw=z.read('ci-postgres/partition-receipt.json');d=json.loads(raw)
        assert d['status']=='REAL_POSTGRES_PARTITION_COMPLETE' and d['fixedCommit']==fixed and d['manifestSha256']==sha(manifest_raw)
        assert d['orderedDefaultCases']==ids and d['partitionIndex']==i and d['partitionCount']==4
        assert d['expectedCases']==d['completedCases']==[e['id'] for e in d['executions']]==ids[i::4]
        assert [e['ordinal'] for e in d['executions']]==list(range(i,len(ids),4)) and all(e['status']=='PASSED' for e in d['executions'])
        for f in d['outputFiles']:
            data=z.read('ci-postgres/'+f['path']);assert len(data)==f['bytes'] and sha(data)==f['sha256']
        old=next(p for p in aggregate['partitions'] if p['partitionIndex']==i)
        assert old['receiptSha256']==sha(raw) and old['cases']==ids[i::4] and old['runtimeAssemblies']==d['runtimeAssemblies'] and old['actualRuleInputs']==d['actualRuleInputs']
        if identity is None:identity=d['actualRuleInputs'];assemblies=d['runtimeAssemblies']
        else:assert identity==d['actualRuleInputs'] and assemblies==d['runtimeAssemblies']
        all_cases+=d['completedCases']
        parts.append({'partition':i,'cases':d['completedCases'],'outputs':len(d['outputFiles']),'originalReceiptSha256':sha(raw)})
assert set(all_cases)==set(ids) and len(all_cases)==47
with zipfile.ZipFile(out/'native-network-results.zip') as z:
    assert z.read(next(n for n in z.namelist() if n.endswith('commit.txt'))).decode().strip()==fixed
    log=z.read(next(n for n in z.namelist() if n.endswith('native-network.log'))).decode()
    line=next(l for l in log.splitlines() if l.startswith('NATIVE_ROOM_IDENTITY_EVIDENCE '));network=json.loads(line.removeprefix('NATIVE_ROOM_IDENTITY_EVIDENCE '))
    assert network['rejectedActions']==15 and network['leakedPrivateMessages']==0 and network['validReconnectTokenWasSupplied'] is True
    assert network['identities']==['ANONYMOUS','FAILED_KEY','OTHER_HANDLE']
    assert 'socket loss, authenticated room restore, fresh snapshot, rejected-token guard.' in log
with zipfile.ZipFile(out/'full-verification-gate.zip') as z:
    gate=json.loads(z.read('result.json'))
    assert gate['status']=='FIXED_COMMIT_FULL_CHILD_JOBS_ALL_SUCCEEDED' and gate['commit']==fixed and gate['jobs']=={'scope':'success','rule_suite':'success','postgres':'success'}
rule_path=work/'fixed564-complete-rule-original-retention-readback-v2.json';rule=load(rule_path)
assert rule['actualCases']==13315 and rule['actualUniqueMethods']==7631 and rule['exactSameCaseMultisetAndMethodSetAsPrevious0366']
assert len(rule['all143OriginalFullGameMethods'])==143 and len(rule['preconstructedMatrix']['completed'])==110
assert rule['preconstructedMatrix']['seed']==424242 and rule['artifact']['sha256']==sha((out/'conformance-results.zip').read_bytes())
spec=importlib.util.spec_from_file_location('gov',root/'scripts/audit/check-project-governance.py');gov=importlib.util.module_from_spec(spec);spec.loader.exec_module(gov)
tree=subprocess.check_output(['git','ls-tree','-rz','--full-tree',fixed],cwd=root)
inputs=[]
for entry in tree.split(b'\0'):
    if not entry:continue
    head,path=entry.split(b'\t',1);mode,kind,oid=head.decode().split();path=path.decode()
    if kind=='blob' and gov.gameplay_path(path):inputs.append((path,oid))
assert inputs
batch=subprocess.check_output(['git','cat-file','--batch'],input=''.join(oid+'\n' for _,oid in inputs).encode(),cwd=root)
stream=io.BytesIO(batch);files={}
for path,oid in inputs:
    actual,kind,size=stream.readline().decode().strip().split();assert actual==oid and kind=='blob'
    raw=stream.read(int(size));assert len(raw)==int(size) and stream.read(1)==b'\n';files[path]=sha(raw)
assert not stream.read()
result={'status':'FIXED_COMMIT_FULL_CI_AND_PARITY_VERIFIED','verifiedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'commit':fixed,'runId':run,'url':f'https://github.com/DDDHL0704/riftbound/actions/runs/{run}',
    'jobs':jobs,'actualCases':13315,'actualMethods':7631,'fullGameMethods':143,'preconstructedPairs':110,'decks':11,'seed':424242,
    'allCasesAndMethodsExactAgainstPrevious0366RulePassWhole0366FailureRetained':True,
    'sqlCases':47,'sqlOriginalOrderedCases':ids,'sqlOriginalOutputs':sum(p['outputs'] for p in parts),'sqlPartitions':parts,
    'actualSqlRuleInputs':identity,'actualSqlRuntimeAssemblies':assemblies,'network':network,
    'actualConformanceAssemblySha256':rule['testAssemblySha256'],'ruleOriginalRetention':pin(rule_path,'original-rule-trx-and-pair-readback'),
    'gameplaySourceInputs':{'commit':fixed,'files':files,'derivedFromExactGitBlobsNoCheckoutOrBuildCreated':True},
    'originalCompleteStatus':pin(status_path,'actual-completed-eleven-jobs'),'originalArtifactMetadata':pin(metadata_path,'backend-original-artifact-metadata'),
    'originalArtifacts':artifacts,'nativeMacAndWindowsPackages':{'verifiedLatestOriginalArtifactIds':[metadata['native-macos-latest']['id'],metadata['native-windows-latest']['id']],
        'actualByteAndBootProof':pin(work/'latest-fixed-both-platform-actual-patched-byte-proof-v1.json','original-package-all-architectures-patched-bytes-and-headless-default-boot'),
        'packagingAndHeadlessBootDoNotProveVisiblePairedOrPhysicalWindows':True},
    'currentN27UncommittedChangesNotCovered':True,'visibleCurrentPairedProductAndPhysicalWindows':'OPEN','wholePrintingOrGlobalCertification':False}
write(work/'fixed564-entire-full-ci-original-independent-verification-v1.json',result)
print(result['status'],len(jobs),result['actualCases'],result['actualMethods'],result['sqlCases'],result['sqlOriginalOutputs'],len(files),flush=True)
