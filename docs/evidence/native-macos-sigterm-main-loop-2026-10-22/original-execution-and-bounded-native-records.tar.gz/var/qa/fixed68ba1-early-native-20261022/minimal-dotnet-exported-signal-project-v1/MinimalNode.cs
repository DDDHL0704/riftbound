using Godot;
using System.Runtime.InteropServices;
using System.Threading;

public partial class MinimalNode : Node
{
    private PosixSignalRegistration? _term;
    private int _terminationRequested;
    public override void _Ready()
    {
        _term = PosixSignalRegistration.Create(PosixSignal.SIGTERM, context =>
        {
            context.Cancel = true;
            Interlocked.Exchange(ref _terminationRequested, 1);
        });
        GD.Print("MINIMAL_NET_RUNTIME:" + RuntimeInformation.FrameworkDescription);
        GD.Print("MINIMAL_NATIVE_SIGNAL_READY");
    }
    public override void _Process(double delta)
    {
        if (Interlocked.Exchange(ref _terminationRequested, 0) != 0)
        {
            GD.Print("MINIMAL_TERMINATION_ON_MAIN_LOOP");
            GetTree().Quit();
        }
    }
    public override void _ExitTree() => _term?.Dispose();
}
