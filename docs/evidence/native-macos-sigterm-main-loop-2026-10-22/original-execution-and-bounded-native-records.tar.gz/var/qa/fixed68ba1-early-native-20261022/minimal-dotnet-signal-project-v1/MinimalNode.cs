using Godot;

public partial class MinimalNode : Node
{
    public override void _Ready() => GD.Print("MINIMAL_NATIVE_SIGNAL_READY");
}
