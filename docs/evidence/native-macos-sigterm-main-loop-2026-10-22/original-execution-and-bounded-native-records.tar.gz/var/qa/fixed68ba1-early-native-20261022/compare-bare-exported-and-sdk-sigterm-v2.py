import errno
import hashlib
import json
import os
from pathlib import Path
import pty
import select
import signal
import subprocess
import time
from datetime import datetime, timezone

qa = Path(__file__).resolve().parent
manifest = json.loads((qa / 'bare-exported-minimal-inputs-v2.json').read_text())
project = qa / 'minimal-dotnet-exported-signal-project-v1'
receipt = qa / 'bare-exported-and-sdk-natural-versus-sigterm-v2.json'
assert not receipt.exists(), 'Preserve existing observations; never overwrite a completed attempt'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
now = lambda: datetime.now(timezone.utc).isoformat()
app = Path(manifest['app'])
inputs = {str(p.relative_to(app)): sha(p) for p in app.rglob('*') if p.is_file()}
result = {'startedAtUtc': now(), 'status': 'RUNNING', 'inputManifestSha256': sha(qa / 'bare-exported-minimal-inputs-v2.json'),
          'noGameNetworkDatabaseOrDesktopInput': True, 'observations': []}
receipt.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
for target in ['exported', 'sdk']:
    for mode in ['natural', 'sigterm']:
        command = ([manifest['executable']] if target == 'exported' else [manifest['sdk'], '--path', str(project)])
        command += ['--headless', '--max-fps', '60', '--quit-after', '120' if mode == 'natural' else '6000']
        entry = {'target': target, 'mode': mode, 'command': command, 'startedAtUtc': now()}
        log = qa / f'bare-{target}-minimal-{mode}-comparison-v2.log'
        assert not log.exists()
        master, slave = pty.openpty()
        proc = None
        raw = bytearray()
        eof = False
        try:
            proc = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=slave, stderr=slave, start_new_session=True)
            os.close(slave)
            slave = -1
            entry['ownPid'] = proc.pid
            started = time.monotonic()
            signalled = False
            while not eof:
                if select.select([master], [], [], 0.1)[0]:
                    try:
                        block = os.read(master, 65536)
                        if block:
                            raw.extend(block)
                        else:
                            eof = True
                    except OSError as ex:
                        if ex.errno == errno.EIO:
                            eof = True
                        else:
                            raise
                if mode == 'sigterm' and not signalled and b'MINIMAL_NATIVE_SIGNAL_READY' in raw:
                    assert proc.poll() is None
                    entry['beforeSignalGodotError'] = b'ERROR:' in raw
                    entry['signalAtUtc'] = now()
                    os.kill(proc.pid, signal.SIGTERM)
                    signalled = True
                if time.monotonic() - started > 35:
                    raise TimeoutError(f'{target} {mode} readiness or exit exceeded 35 seconds')
                if proc.poll() is not None and eof:
                    break
            entry['exitCode'] = proc.wait(timeout=2)
            entry['ptyFullyDrained'] = eof
            entry['readyMarker'] = b'MINIMAL_NATIVE_SIGNAL_READY' in raw
            assert entry['readyMarker']
            if mode == 'sigterm':
                assert signalled
            entry['completedAtUtc'] = now()
        except Exception as ex:
            entry['observationFailure'] = repr(ex)
            result['status'] = 'OBSERVATION_FAILED'
            result['failedAtUtc'] = now()
            raise
        finally:
            if proc and proc.poll() is None:
                entry['ownProbeForcedKillForFailedObservation'] = True
                proc.kill()
                proc.wait(timeout=5)
            if slave >= 0:
                os.close(slave)
            os.close(master)
            log.write_bytes(raw)
            lines = raw.decode('utf-8', errors='replace').splitlines()
            entry['frameworkLines'] = [s for s in lines if 'MINIMAL_NET_RUNTIME:' in s]
            entry['hasGodotError'] = b'ERROR:' in raw
            entry['hasUnreferencedStaticString'] = b'Unreferenced static string' in raw
            entry['hasMutexAbort'] = b'mutex lock failed' in raw
            entry['logSha256'] = sha(log)
            result['observations'].append(entry)
            receipt.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
            print(json.dumps(entry, ensure_ascii=False), flush=True)
assert inputs == {str(p.relative_to(app)): sha(p) for p in app.rglob('*') if p.is_file()}
result['allExportedPayloadsStillExact'] = len(inputs)
result['finishedAtUtc'] = now()
result['status'] = 'BARE_SAME_PROJECT_SDK_AND_EXPORTED_DOTNET_EXIT_MODES_OBSERVED_NO_CAUSAL_ATTRIBUTION'
receipt.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
