import ast,datetime,errno,fcntl,gzip,hashlib,json,os,plistlib,pty,re,resource,socket,subprocess,threading,time,urllib.request
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;old=root/'var/qa/fixed267ab-early-native-20261022'
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486');tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts'];read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();load=lambda p:json.loads(p.read_text())
source=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py';nodes=[n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),globals());functions=w/'controlled-lab-native-owner-functions-v3.py';exec(compile(functions.read_text(),str(functions),'exec'),globals())
pub=load(w/'frozen-fixed68ba1-native-composition-v1.json');previous=load(w/'controlled-lab-native-three-cold-owner-terminal-v2.json');assert previous['ownPostgresSmartStopped'] and previous['allOriginal345AuditSevenTablesExact'] and previous['allOriginal80NativeSevenTablesExact']
api_runtime=Path(pub['apiRuntimeRoot']);helpers=Path(pub['helperRuntimeRoot']);profiles=w/'controlled-lab-native-prefix-v1';assert profiles.is_dir();evidence=w/'controlled-lab-native-raw-v3';evidence.mkdir(exist_ok=False)
driver_dll=old/'executed-own-native-readers-and-drivers-v1/Fixed267abControlledLabPrepareV1.dll';driver_source=old/'controlled-lab-native-driver-source-v1';assert driver_dll.is_file()
own_inputs={str(p):sha(p) for p in [driver_dll,driver_dll.with_suffix('.pdb'),driver_source/'Program.cs',driver_source/'probe.csproj',functions,Path(__file__)]};terminal=w/'controlled-lab-native-three-cold-owner-terminal-v3.json';assert not terminal.exists()
def checkpoint(name,value):
 with (evidence/name).open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2)
def rows(name):
 data={t:json.loads(query('riftbound_here_native',f"select coalesce(json_agg(t order by row_to_json(t)::text),'[]'::json)::text from (select * from {t} where match_id='{room}')t")) for t in tables};p=evidence/name;p.write_bytes(gzip.compress(json.dumps({'room':room,'originalRows':data},ensure_ascii=False,indent=2).encode(),mtime=0));return {'path':str(p),'sha256':sha(p),'counts':{t:len(r) for t,r in data.items()}}
def same_game_frame(actual,expected):
 for name in ['commands','events','authoritativeState','openingSeed','replayInitialState']:assert actual[name]==expected[name],name
 return True
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
proof={'status':'RUNNING_CURRENT_FIXED68BA1_ACTUAL_CI_DEFAULT_MAIN_LAB_THREE_COLD_RESTORES_NOT_VISIBLE_OR_WINDOWS','startedAtUtc':now(),'fixedCommit':pub['fixedCommit'],'fixedCiRun':pub['fixedCiRun'],'actualRuleInputs':pub['actualRuleInputs'],'existingScenario':'battlefield-turn-start-destroy-draw','ownedApiProcesses':[],'ownedNativeProcesses':[],'ownExactDriverAndOwnerInputs':own_inputs,'lockAtStart':observe_lock(),'newRoomRequiredNoOldWrongVersionRoomMigration':True,'original267abNativeColdFailureRemainsFailed':True,'coldRestoreCycles':[],'ordinaryFullGameVisibleAndWindowsNotClaimed':True}
api=driver=power=None;clients=[];pumps={};started=False;room=previous['room'];proof.update(room=room,noNewRoomOrReseedOrOriginalFourInputResubmission=True,noPreparationDriverRerun=True,originalInterruptedOwnerSha256=sha(w/'controlled-lab-native-three-cold-owner-terminal-v2.json'));audit=native=before_audit=before_native=None
try:
 frozen();assert all(sha(Path(p))==digest for p,digest in own_inputs.items())
 assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid;sock.mkdir(exist_ok=True)
 subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'controlled-lab-postgres-v1.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 audit=rooms('riftbound_acceptance');all_native=rooms('riftbound_here_native');assert audit==previous['actualAuditRoomsAtStop'] and all_native==previous['actualNativeRoomsAtStop'];native=[x for x in all_native if x!=room];assert len(audit)==345 and len(native)==80 and native==load(old/'controlled-lab-native-independent-owner-terminal-v1.json')['actualNativeRoomsAtStop']
 before_audit=digests('riftbound_acceptance',audit);before_native=digests('riftbound_here_native',native);checkpoint('original345-audit80-native-seven-table-baseline-v1.json',{'auditRooms':audit,'nativeRooms':native,'auditSevenTables':before_audit,'nativeSevenTables':before_native})
 start_api(1)
 entry=load(profiles/'controlled-lab-original-entry-v1.json');assert entry['room']==room;a,b=entry['players'];proof['players']=[a,b]
 before=export('before-cold-controlled-lab-original-frame-v1');initial=before['authoritativeState'];original_frame=json.loads(gzip.decompress((w/'controlled-lab-native-raw-v1/owner-final-controlled-lab-original-frame-v1.json.gz').read_bytes()));same_game_frame(before,original_frame)
 assert len(before['commands'])==4 and [c['commandType'] for c in before['commands']]==['ROOM_SEAT','ROOM_SEAT','DEV_SEED_SCENARIO:battlefield-turn-start-destroy-draw','END_TURN']
 assert initial['turnPlayerId']==b and initial['pendingCardChoice']['playerId']==b and initial['pendingCardChoice']['legalObjectIds']==['P2-BATTLEFIELD-ROSE-SACRIFICE'] and len(initial['stackItems'])==1 and initial['stackItems'][0]['controllerId']==b and initial['pendingCardChoice']['resolvingStackItemId']==initial['stackItems'][0]['stackItemId'] and initial['stackItems'][0]['triggerCost'] is None
 assert 'P2-OTHER' in initial['cardObjects'] and initial['objectLocations']['P2-OTHER']['battlefieldObjectId']=='P2-OTHER';proof['originalAllSevenTablesBeforeNative']=rows('original-all-seven-tables-before-native-v1.json.gz')
 observers=[launch('a','lab-observe-a',6000),launch('b','lab-observe-b',6000)]
 native_wait(lambda:all(all(log_count(item[2],k)>=1 for k in ['Joined','Snapshot','Prompt']) for item in observers),'Both actual CI default Main original Lab views.',40,[item[0] for item in observers])
 for cycle in range(1,4):
  counts=[{k:log_count(item[2],k) for k in ['Joined','Snapshot','Prompt']} for item in observers];restores=[item[2].read_text(errors='replace').count('Connection and session restored.') for item in observers]
  owned_pid=api.pid;assert api.poll() is None and set(subprocess.check_output(['/usr/sbin/lsof','-tiTCP:15847','-sTCP:LISTEN'],text=True).splitlines())=={str(owned_pid)}
  proof.setdefault('actualOwnedApiFaultInjections',[]).append({'cycle':cycle,'ownedPid':owned_pid,'signal':'SIGKILL','atUtc':now(),'onlyOwnedTestApiProcessNoClientOrPostgresKilled':True});api.kill();api.wait(timeout=10);assert api.returncode==-9;start_api(cycle+1)
  native_wait(lambda:all(all(log_count(item[2],k)>counts[i][k] for k in ['Joined','Snapshot','Prompt']) and item[2].read_text(errors='replace').count('Connection and session restored.')>restores[i] for i,item in enumerate(observers)),'Same two default Main processes restore fresh authenticated views, cycle '+str(cycle),45,[item[0] for item in observers])
  cold=export('after-cold-cycle-'+str(cycle)+'-original-frame-v1');same_game_frame(cold,before)
  proof['coldRestoreCycles'].append({'cycle':cycle,'bothSameNativePids':[item[0].pid for item in observers],'freshJoinedSnapshotPromptAndRestoreCompleteObserved':True,'allOriginalFourCommandsTenEventsWholeStatePrivateSeedAndEmptyInitialExact':True,'actualLockObservation':observe_lock()})
 for item in observers:
  wait_exit(item,120);assert 'Session recovery failed:' not in item[2].read_text(errors='replace')
 proof['actualObsoleteInitialRequestDiscardMarkerObserved']={item[1]['role']:'连接或房间已更新，结束先前的快照请求。' in item[2].read_text(errors='replace') for item in observers}
 chosen=launch('b','lab-choice-b',600,'CHOOSE_CARDS');native_wait(lambda:count()==5,'Actual B selects the original local sacrifice.',30,[chosen[0]])
 paid=export('after-native-lab-local-cost-original-frame-v1');ps=paid['authoritativeState'];stack=ps['stackItems'][0]
 assert paid['commands'][-1]['playerId']==b and paid['commands'][-1]['commandType']=='CHOOSE_CARDS' and paid['commands'][-1]['rawCommand']['chosenObjectIds']==['P2-BATTLEFIELD-ROSE-SACRIFICE'] and len(ps['stackItems'])==1 and ps['priorityPlayerId']==b and stack['controllerId']==b and stack['battlefieldStart']['controllerId']==b and stack['battlefieldStart']['cardNo']=='UNL-209/219' and stack['battlefieldStart']['drawCount']==1 and stack['triggerCost']['destructionTarget']['objectId']=='P2-BATTLEFIELD-ROSE-SACRIFICE' and 'P2-BATTLEFIELD-ROSE-SACRIFICE' in ps['playerZones'][b]['graveyard'] and not ps['playerZones'][b]['hand']
 wait_exit(chosen,30);own_a=launch('a','lab-pass-a',1800,'PASS_PRIORITY');own_b=launch('b','lab-pass-b',600,'PASS_PRIORITY');native_wait(lambda:count()==7,'Actual B then A close paid Lab skill.',35,[own_a[0],own_b[0]])
 for item in [own_a,own_b]:wait_exit(item,45);assert 'UI smoke staged PASS_PRIORITY' in item[2].read_text(errors='replace')
 final=export('final-controlled-lab-original-frame-v1');fs=final['authoritativeState'];assert len(final['commands'])==7 and final['commands'][:4]==before['commands'] and final['events'][:len(before['events'])]==before['events'] and final['openingSeed']==before['openingSeed'] and final['replayInitialState']==before['replayInitialState']
 assert [c['playerId'] for c in final['commands'][4:]]==[b,b,a] and [c['commandType'] for c in final['commands'][4:]]==['CHOOSE_CARDS','PASS_PRIORITY','PASS_PRIORITY'] and fs['phase']=='MAIN' and fs['turnPlayerId']==b and not fs['stackItems'] and fs['pendingCardChoice'] is None and len(fs['playerZones'][b]['hand'])==2 and not fs['playerZones'][a]['hand'] and 'P2-BATTLEFIELD-ROSE-SACRIFICE' in fs['playerZones'][b]['graveyard'] and fs['cardObjects']['P2-BATTLEFIELD-AAA-OFFSITE']['damage']==0 and 'P2-OTHER' in fs['cardObjects']
 resolved=[e for e in final['events'] if e['event']['kind']=='BATTLEFIELD_TRIGGER_RESOLVED'];assert len(resolved)==1 and resolved[0]['event']['payload']['playerId']==b and final['openingSeed']!=0 and final['replayInitialState']['status']=='EMPTY' and not final['replayInitialState']['seats']
 proof.update(status='PASS_FIXED68BA1_ACTUAL_CI_DEFAULT_MAIN_THREE_COLD_RESTORES_AND_PAID_LAB_NATIVE7_COMMANDS24_EVENTS_INDEPENDENT_REPLAY_PENDING',totalCommands=7,events=len(final['events']),nativeAcceptedGameplayCommands=3,rawFinalFrame=str(evidence/'final-controlled-lab-original-frame-v1.json.gz'),originalFinalSevenTables=rows('original-final-all-seven-tables-v1.json.gz'),independentReadOnlyFullOriginalReplayPending=True,paidSingleBranchOnlyNoDeclineCertification=True)
except BaseException as e:proof.update(status='FAILED_OR_INTERRUPTED_CURRENT_FIXED68BA1_CONTROLLED_LAB_ORIGINAL_PREFIX_RETAINED',errorType=type(e).__name__,error=str(e));raise
finally:
 if driver is not None and driver.poll() is None:driver.terminate();driver.wait(timeout=20)
 for p,record,log in clients:
  if p.poll() is None:p.terminate();p.wait(timeout=20);record['terminatedOnlyForOwnedFailureCleanup']=True
  pumps[p.pid].join(timeout=10);record.update(exitCode=p.returncode,logSha256=sha(log),ptyFullyDrained=not pumps[p.pid].is_alive())
 if started and room is not None:
  try:export('owner-final-controlled-lab-original-frame-v1');proof['originalLatestFrameRetainedAtStop']=True
  except BaseException as e:proof['finalFrameExportErrorType']=type(e).__name__
 if api is not None and api.poll() is None:api.terminate();api.wait(timeout=25)
 proof['ownApiStopped']=api is None or api.poll() is not None
 if started:
  if before_audit is not None:proof.update(allOriginal345AuditSevenTablesExact=digests('riftbound_acceptance',audit)==before_audit,allOriginal80NativeSevenTablesExact=digests('riftbound_here_native',native)==before_native,actualAuditRoomsAtStop=rooms('riftbound_acceptance'),actualNativeRoomsAtStop=rooms('riftbound_here_native'))
  proof['ownPostgresSmartStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','smart','-w','-t','20','stop'],capture_output=True).returncode==0
 if power is not None and power.poll() is None:power.terminate();power.wait(timeout=10)
 frozen();proof.update(finishedAtUtc=now(),lockAtEnd=observe_lock(),allFrozenApiHelpersNetwork373NativeAndOwnDriverBitsStable=all(sha(Path(p))==digest for p,digest in own_inputs.items()))
 with terminal.open('x') as f:json.dump(proof,f,indent=2)
 fcntl.flock(guard,fcntl.LOCK_UN)
print(proof['status'],flush=True)
