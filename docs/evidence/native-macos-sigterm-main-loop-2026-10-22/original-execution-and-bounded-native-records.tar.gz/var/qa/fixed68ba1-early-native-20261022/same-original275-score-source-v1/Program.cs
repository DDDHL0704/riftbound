using System.Collections.Concurrent;
using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Nodes;
using Riftbound.Contracts;
using Riftbound.GodotClient;

if (args.Length != 6 || args[0] != "http://127.0.0.1:15847") throw new Exception("Only own original API, fresh output and original profile directory.");
var server=args[0];var output=Path.GetFullPath(args[1]);var work=Path.GetFullPath(args[2]);
if (Directory.Exists(output)) throw new Exception("Do not overwrite original score continuation evidence.");
Directory.CreateDirectory(output);
using var timeout=new CancellationTokenSource(TimeSpan.FromMinutes(5));var ct=timeout.Token;
var json=new JsonSerializerOptions(JsonSerializerDefaults.Web){WriteIndented=true};
using var original=JsonDocument.Parse(File.ReadAllText(Path.GetFullPath(args[3])));
var room=original.RootElement.GetProperty("room").GetString()!;
var unit=original.RootElement.GetProperty("newTargetObjectId").GetString()!;
using var zip=new GZipStream(File.OpenRead(Path.GetFullPath(args[4])),CompressionMode.Decompress);
using var checkpoint=JsonDocument.Parse(zip);var initialTick=checkpoint.RootElement.GetProperty("authoritativeState").GetProperty("tick").GetInt64();var originalCount=checkpoint.RootElement.GetProperty("commands").GetArrayLength();var expectedTurn=checkpoint.RootElement.GetProperty("authoritativeState").GetProperty("turnNumber").GetInt32()+14;
var profiles=new[]{"a","b"}.Select(role=>JsonNode.Parse(File.ReadAllText(Path.Combine(work,"session-"+role+".json")))!).ToArray();
using var trace=new WireTrace(Path.Combine(output,"original-private-score-gateway-wire.ndjson.gz"));
await using var a=new Side(server,room,profiles[0],trace,ct,Path.Combine(work,"session-a.json"));await using var b=new Side(server,room,profiles[1],trace,ct,Path.Combine(work,"session-b.json"));var sides=new[]{a,b};
await a.Connect();await b.Connect();
Check(sides.All(s=>s.Snapshot.GetProperty("tick").GetInt64()==initialTick),"Both actual gateways must resume the exact saved recorded original native state.");
Check(a.Enabled("MOVE_UNIT")&&a.Enabled("END_TURN"),"Same original active player and enabled movement must resume.");
var accepted=new List<object>();
var move=a.Prompt.GetProperty("candidates").EnumerateArray().Single(c=>c.GetProperty("action").GetString()=="MOVE_UNIT"&&c.GetProperty("enabled").GetBoolean());
Check(move.GetProperty("sources").EnumerateArray().Any(c=>c.GetProperty("id").GetString()==unit),"Original target's actual ready Poro must be a legal source.");
var exactDestination=args[5];
Check(exactDestination.StartsWith("BATTLEFIELD:",StringComparison.Ordinal)&&checkpoint.RootElement.GetProperty("authoritativeState").GetProperty("cardObjects").GetProperty(exactDestination["BATTLEFIELD:".Length..]).GetProperty("cardNo").GetString()=="OGN·275/298","The exact destination is the original recorded OGN275 physical battlefield, independently of its owner.");
var destination=move.GetProperty("destinations").EnumerateArray().Single(c=>c.GetProperty("id").GetString()==exactDestination).GetProperty("id").GetString()!;
await Submit(a,new(){["cmdType"]="MOVE_UNIT",["sourceObjectId"]=unit,["origin"]="BASE",["destination"]=destination});
var focusPasses=0;
while(sides.Any(s=>s.Enabled("PASS_FOCUS")))
{
 Check(focusPasses<2,"Only the actual two normal empty-field focus passes.");
 await Submit(sides.Single(s=>s.Enabled("PASS_FOCUS")),new(){["cmdType"]="PASS_FOCUS"});focusPasses++;
}
Check(focusPasses==2&&Score(a,a.Handle)==1&&Score(a,b.Handle)==0,"One normal conquest must produce exactly the first point.");
var turns=0;var priorityPasses=0;
while(a.Snapshot.GetProperty("timing").GetProperty("roomStatus").GetString()!="FINISHED")
{
 var responders=sides.Where(side=>side.Enabled("PASS_PRIORITY")).ToArray();
 if(responders.Length>0){Check(responders.Length==1&&priorityPasses<12,"Only actual original Court mandatory held responder, at most six complete two-player windows.");await Submit(responders[0],new(){["cmdType"]="PASS_PRIORITY"});priorityPasses++;continue;}
 Check(turns<16,"Original remaining nonempty decks must permit ordinary held-field score completion.");
 await Submit(sides.Single(s=>s.Enabled("END_TURN")),new(){["cmdType"]="END_TURN"});turns++;
}
Check(turns==14&&priorityPasses==12&&accepted.Count==29&&Score(a,a.Handle)==8&&Score(a,b.Handle)==0,"Exactly one move, two focus passes and fourteen normal turn endings plus twelve actual mandatory held priority passes produce all eight points.");
Check(a.Snapshot.GetProperty("timing").GetProperty("winnerPlayerId").GetString()==a.Handle&&a.Snapshot.GetProperty("turnNumber").GetInt32()==expectedTurn,"Original ordinary winner and recorded turn plus fourteen must agree.");
Check(sides.All(s=>s.Snapshot.GetProperty("players").GetProperty(s.Handle).GetProperty("zones").GetProperty("mainDeckCount").GetInt32()>0),"Neither original deck may be exhausted.");
await File.WriteAllTextAsync(Path.Combine(output,"all-original-normal-score-continuation-intents.json"),JsonSerializer.Serialize(accepted,json),ct);
var result=new{status="PASS_SAME_ORIGINAL_ROOM_NORMAL_GATEWAY_ONE_CONQUEST_SEVEN_HOLDS_NO_SURRENDER",room,originalCommands=originalCount,continuationCommands=accepted.Count,originalNormalContinuationCommands=17,heldSkillPriorityPasses=priorityPasses,expectedFinalCommands=originalCount+29,focusPasses,normalEndTurns=turns,winner=a.Handle,winningScore=8,losingScore=0,finalTurn=expectedTurn,originalBlankOpeningAndRandomSeedUnmodified=true,originalNativeThreeDecisionsNotReplayed=true,actualProductionGatewaySource=true,actualGodotButtonsForThese17Commands=false,visibleOrPhysicalWindowsAcceptance=false};
await File.WriteAllTextAsync(Path.Combine(output,"normal-original-score-continuation-receipt.json"),JsonSerializer.Serialize(result,json),ct);Console.WriteLine(JsonSerializer.Serialize(result,json));
async Task Submit(Side actor,JsonObject command)
{
 var receipt=await actor.Submit(command);accepted.Add(new{actor=actor.Handle,rawCommand=command,receipt});
 await File.WriteAllTextAsync(Path.Combine(output,"original-accepted-continuation-progress.json"),JsonSerializer.Serialize(accepted,json),ct);
 while(!sides.All(s=>s.Snapshot.GetProperty("tick").GetInt64()==receipt.ServerTick&&s.Prompt.TryGetProperty("snapshotTick",out var tick)&&tick.GetInt64()==receipt.ServerTick))
 {foreach(var side in sides)side.CheckErrors();await Task.Delay(20,ct);}
}
static int Score(Side side,string actor)=>side.Snapshot.GetProperty("players").GetProperty(actor).GetProperty("score").GetInt32();
static void Check(bool value,string message){if(!value)throw new Exception(message);}

sealed class WireTrace : IDisposable
{
    readonly StreamWriter writer; readonly object gate = new();
    public WireTrace(string path) => writer = new StreamWriter(new GZipStream(new FileStream(path, FileMode.CreateNew), CompressionLevel.SmallestSize));
    public void Record(string actor, string kind, JsonElement payload)
    { lock (gate) { writer.WriteLine(JsonSerializer.Serialize(new { actor, kind, payload })); writer.Flush(); } }
    public void Dispose() { lock (gate) writer.Dispose(); }
}
sealed class Side : IAsyncDisposable
{
    readonly string key; readonly string room; readonly CancellationToken ct;
    readonly ConcurrentQueue<string> errors = new(); readonly object gate = new();
    JsonElement snapshot, prompt;
    public string Handle { get; }
    public string? ReconnectToken { get; private set; }
    public int SnapshotCount, PromptCount;
    public RiftboundGameHubClient Hub { get; }
    public JsonElement Snapshot { get { lock (gate) return snapshot; } }
    public JsonElement Prompt { get { lock (gate) return prompt; } }
    public Side(string server, string room, JsonNode profile, WireTrace trace, CancellationToken token, string sessionFile)
    {
        this.room = room; ct = token; Handle = profile["handle"]!.GetValue<string>(); key = profile["playerKey"]!.GetValue<string>(); ReconnectToken = profile["reconnectToken"]!.GetValue<string>();
        Hub = new(server);
        Hub.ServerMessageReceived += (kind, message) => {
            if (message.Payload is not JsonElement payload) return;
            lock (gate) {
                if (kind == "Joined")
                {
                    ReconnectToken = payload.GetProperty("reconnectToken").GetString();
                    var current = new JsonObject { ["handle"] = Handle, ["roomId"] = room,
                        ["playerKey"] = key, ["reconnectToken"] = ReconnectToken,
                        ["lastDeckId"] = "lillia-lowcurve", ["serverUrl"] = server };
                    var temporary = sessionFile + ".rotating-next";
                    File.WriteAllText(temporary, current.ToJsonString(new JsonSerializerOptions { WriteIndented = true }));
                    if (!OperatingSystem.IsWindows()) File.SetUnixFileMode(temporary, UnixFileMode.UserRead | UnixFileMode.UserWrite);
                    File.Move(temporary, sessionFile, true);
                }
                if (kind == "Snapshot") { snapshot = payload.Clone(); SnapshotCount++; trace.Record(Handle, kind, payload); }
                if (kind == "Prompt") { prompt = payload.Clone(); PromptCount++; trace.Record(Handle, kind, payload); }
                if (kind == "Error") errors.Enqueue("Actual server error " + payload.GetProperty("code").GetString());
            }
        };
        Hub.RestoreSession += async () => {
            var auth = await Hub.AuthenticateAsync(Handle, key, ct); if (!auth.Authenticated) throw new Exception("Actual restore authentication failed.");
            await Hub.ReconnectAsync(room, Handle, ReconnectToken!, ct); await Hub.RequestSnapshotAsync(room, Handle, ct);
        };
    }
    public async Task Connect()
    {
        await Hub.StartAsync(ct); var auth = await Hub.AuthenticateAsync(Handle, key, ct);
        if (!auth.Authenticated) throw new Exception("Existing own native identity authentication failed.");
        await Hub.ReconnectAsync(room, Handle, ReconnectToken!, ct); await Hub.RequestSnapshotAsync(room, Handle, ct);
        while (ReconnectToken is null || SnapshotCount == 0 || PromptCount == 0) { CheckErrors(); await Task.Delay(20, ct); }
    }
    public bool Enabled(string action) => Prompt.ValueKind == JsonValueKind.Object && Prompt.GetProperty("actionable").GetBoolean()
        && Prompt.GetProperty("candidates").EnumerateArray().Any(c => c.GetProperty("action").GetString() == action && c.GetProperty("enabled").GetBoolean());
    public async Task<CommandReceiptDto> Submit(JsonObject command)
    {
        command["promptId"] = Prompt.GetProperty("promptId").GetString(); command["snapshotTick"] = Prompt.GetProperty("snapshotTick").GetInt64();
        var receipt = await Hub.SubmitIntentAsync(room, Handle, "native-counter-prefix-" + Guid.NewGuid().ToString("N"), JsonSerializer.SerializeToElement(command), ct);
        if (!receipt.Accepted) throw new Exception("Actual ordinary native prefix rejected: " + receipt.CmdType + " " + receipt.ErrorCode);
        return receipt;
    }
    public void CheckErrors() { if (errors.TryPeek(out var error)) throw new Exception(error); }
    public ValueTask DisposeAsync() => Hub.DisposeAsync();
}
