using System.IO.Compression;
using System.Reflection;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

if(args.SequenceEqual(new[]{"--loaded-inputs"})){
 var assemblies=new[]{typeof(CoreRuleEngine).Assembly,typeof(GameCommand).Assembly,typeof(Riftbound.CardCatalog.OfficialCardCatalog).Assembly,typeof(PostgresMatchJournal).Assembly};
 Console.WriteLine(JsonSerializer.Serialize(new{baseDirectory=AppContext.BaseDirectory,actualRuleInputs=RuleInputIdentity.Current,hasRoomSeatReplay=typeof(MatchSession).GetMethod("ReplayRoomSeatAsync",BindingFlags.Instance|BindingFlags.NonPublic)is not null,hasAtomicSeatCommit=typeof(IMatchPlayerStore).GetMethod("CommitRoomSeatAsync")is not null,assemblies=assemblies.Select(a=>new{name=a.GetName().Name,path=a.Location,mvid=a.ManifestModule.ModuleVersionId,sha256=Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(a.Location))).ToLowerInvariant()})},new JsonSerializerOptions(JsonSerializerDefaults.Web)));return;
}
Check(args.Length==2&&!File.Exists(args[1]),"Original real-network evidence and new independent result required.");
var work=Path.GetFullPath(args[0]);var json=new JsonSerializerOptions(JsonSerializerDefaults.Web){WriteIndented=true};
using var receipt=JsonDocument.Parse(File.ReadAllText(Path.Combine(work,"controlled-lab-native-three-cold-owner-terminal-v3.json")));
Check(receipt.RootElement.GetProperty("fixedCommit").GetString()=="68ba1c5b63f52266323928da85bd75060e7e8fee"&&Same(receipt.RootElement.GetProperty("actualRuleInputs"),JsonSerializer.SerializeToElement(RuleInputIdentity.Current,json)),"Exact fixed current candidate and original controlled native inputs.");
var controlledRoom=receipt.RootElement.GetProperty("room").GetString()!;var players=receipt.RootElement.GetProperty("players").EnumerateArray().Select(x=>x.GetString()!).ToArray();Check(players.Length==2,"Literal two original actors.");var firstActor=players[0];var secondActor=players[1];var expectedEvents=receipt.RootElement.GetProperty("events").GetInt32();
var settings=new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
Check(settings.Host=="127.0.0.1"&&settings.Port==55486&&settings.Database=="riftbound_here_native"&&settings.Username=="codex_riftbound_audit","Only own native SQL database.");settings.Options="-c default_transaction_read_only=on";
await using var source=NpgsqlDataSource.Create(settings.ConnectionString);var outcomes=new List<object>();var totals=new Dictionary<string,int>{{"commands",0},{"events",0},{"authority",0},{"snapshots",0},{"prompts",0}};
foreach(var room in new[]{controlledRoom}){
 var actors=players;
 using var saved=Read(receipt.RootElement.GetProperty("rawFinalFrame").GetString()!);
 var frame=await new PostgresMatchRecoveryStore(source).LoadAsync(room,default)??throw new Exception("Actual original frame required.");
 Check(Same(saved.RootElement,JsonSerializer.SerializeToElement(frame,json))&&frame.IsConsistent&&frame.ValidationErrors.Count==0,"Every saved original frame field/null/omission equals independent SQL read.");
 Check(frame.Commands.Count==7&&frame.Events.Count==expectedEvents&&frame.OpeningSeed!=0&&frame.ReplayInitialState is{Status:"EMPTY",Seats.Count:0,Tick:0}&&frame.AuthoritativeState!.RuleInputs==RuleInputIdentity.Current,"Exact original EMPTY origin, private seed, current rules and expected server-only inputs.");
 var states=new Dictionary<(long,long),MatchState>();var counts=new Dictionary<string,int>();
 await using(var connection=await source.OpenConnectionAsync()){
  Check((string)(await new NpgsqlCommand("show transaction_read_only",connection).ExecuteScalarAsync())! =="on","Independent connection actually read-only.");
  using var raw=Read(receipt.RootElement.GetProperty("originalFinalSevenTables").GetProperty("path").GetString()!);
  foreach(var table in new[]{"matches","match_players","command_log","game_events","state_snapshots","snapshots","action_prompts"}){
   await using var q=Query(connection,$"select coalesce(jsonb_agg(to_jsonb(t)),'[]'::jsonb)::text from (select * from {table} where match_id=@room)t");
   using var current=JsonDocument.Parse((string)(await q.ExecuteScalarAsync())!);
   var expected=raw.RootElement.GetProperty("originalRows").GetProperty(table);
   Check(expected.GetArrayLength()==current.RootElement.GetArrayLength()&&expected.EnumerateArray().All(e=>current.RootElement.EnumerateArray().Count(v=>Same(e,v))==1),"Every original complete seven-table row retained, independent of SQL member/row ordering.");counts[table]=expected.GetArrayLength();
  }
  await using(var q=Query(connection,"select last_event_sequence,payload::text from state_snapshots where match_id=@room order by state_tick,last_event_sequence"))
  await using(var rows=await q.ExecuteReaderAsync())while(await rows.ReadAsync()){
   var text=rows.GetString(1);var state=JsonSerializer.Deserialize<MatchState>(text,json)!;Check(JsonNode.DeepEquals(JsonNode.Parse(text),JsonSerializer.SerializeToNode(state,json))&&state.RuleInputs==RuleInputIdentity.Current&&states.TryAdd((state.Tick,rows.GetInt64(0)),state),"All authoritative history fields/nulls/omissions and exact current input binding.");
  }
  Check(states.Count==7&&states[(1,1)].Seats.Count==1&&states[(1,1)].Seats[firstActor]=="P1"&&!states[(1,1)].Seats.ContainsKey(secondActor),"Literal first-player-only origin is retained; no later player is invented in earlier history.");
  var expectedPrivate=states.SelectMany(s=>s.Value.Seats.Keys.Select(actor=>(actor,s.Key.Item1,s.Key.Item2))).ToHashSet();
  foreach(var table in new[]{"snapshots","action_prompts"}){
   var seen=new HashSet<(string,long,long)>();await using var q=Query(connection,$"select player_id,last_event_sequence,payload::text from {table} where match_id=@room order by id");await using var rows=await q.ExecuteReaderAsync();
   while(await rows.ReadAsync()){
    var actor=rows.GetString(0);var text=rows.GetString(2);using var document=JsonDocument.Parse(text);var tick=document.RootElement.GetProperty(table=="snapshots"?"tick":"snapshotTick").GetInt64();var seq=rows.GetInt64(1);
    Check(states.TryGetValue((tick,seq),out var state)&&seen.Add((actor,tick,seq))&&state.Seats.ContainsKey(actor),"Every private key binds the actual original authority and existing viewer.");
    var typed=table=="snapshots"?JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<SnapshotDto>(text,json),json):JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<ActionPromptDto>(text,json),json);
    var projected=table=="snapshots"?JsonSerializer.SerializeToNode(ResolutionResult.BuildSnapshots(state!)[actor],json):JsonSerializer.SerializeToNode(ResolutionResult.BuildPrompts(state!)[actor],json);
    Check(JsonNode.DeepEquals(JsonNode.Parse(text),typed)&&JsonNode.DeepEquals(JsonNode.Parse(text),projected),"Complete private values/nulls/omissions and original projection exact.");
    Check(!document.RootElement.TryGetProperty("openingSeed",out _)&&!document.RootElement.TryGetProperty("reconnectToken",out _)&&!document.RootElement.TryGetProperty("playerKey",out _),"Original private views contain no private seed or credential field.");
   }
   Check(seen.SetEquals(expectedPrivate),"All actual viewers at all original ticks retained under existing private key, with no fabricated second-player tick1.");totals[table=="snapshots"?"snapshots":"prompts"]+=seen.Count;
  }
 }
 var replay=new MatchSession(frame.ReplayInitialState!,new CoreRuleEngine(),NoopMatchJournal.Instance);var method=typeof(MatchActionLogReplayer).GetMethod("ReplayCommandAsync",BindingFlags.Static|BindingFlags.NonPublic)!;
 var types=new[]{"ROOM_SEAT","ROOM_SEAT","DEV_SEED_SCENARIO:battlefield-turn-start-destroy-draw","END_TURN","CHOOSE_CARDS","PASS_PRIORITY","PASS_PRIORITY"};var literalActors=new[]{firstActor,secondActor,firstActor,firstActor,secondActor,secondActor,firstActor};
 for(var i=0;i<7;i++){
  var command=frame.Commands[i];var raw=command.RawCommand!.Value;
  Check(command.Accepted&&command.ErrorMessage is null&&command.CommandType==types[i]&&command.PlayerId==literalActors[i]&&raw.GetProperty("cmdType").GetString()==(i==2?"DEV_SEED_SCENARIO":types[i]),"All seven original exact accepted inputs: A starts B turn, B chooses and responds, then A responds.");
  if(i<2){var slot=i==0?"P1":"P2";Check(command.ClientIntentId=="room-seat:"+slot&&command.StartedTick==i&&command.CompletedTick==i+1&&command.StartedEventSequence==i&&command.CompletedEventSequence==i+1&&raw.EnumerateObject().Count()==3&&raw.GetProperty("playerId").GetString()==literalActors[i]&&raw.GetProperty("seat").GetString()==slot,"Both literal original atomic server seats remain unchanged.");}
  if(i==2)Check(raw.EnumerateObject().Count()==2&&raw.GetProperty("scenarioId").GetString()=="battlefield-turn-start-destroy-draw","One explicitly declared original existing controlled scenario, not an ordinary game.");
  var result=await(ValueTask<ResolutionResult>)method.Invoke(null,new object[]{replay,command,CancellationToken.None})!;
  Check(result.Accepted&&result.ErrorMessage is null&&Same(JsonSerializer.SerializeToElement(result.State,json),JsonSerializer.SerializeToElement(states[(command.CompletedTick,command.CompletedEventSequence)],json)),"Every original accepted command replays to its entire original historical state.");
  var events=frame.Events.Where(e=>e.Sequence>command.StartedEventSequence&&e.Sequence<=command.CompletedEventSequence).Select(e=>e.Event).ToArray();Check(events.Length==result.Events.Count&&events.Select(EventNode).Zip(result.Events.Select(EventNode)).All(pair=>JsonNode.DeepEquals(pair.First,pair.Second)),"Every original event kind, description and full payload replays exactly; only actor sets have no order.");
 }
 var before=states[(frame.Commands[3].CompletedTick,frame.Commands[3].CompletedEventSequence)];var originalItem=before.StackItems.Single();var choice=before.PendingCardChoice!;
 Check(before.TurnPlayerId==secondActor&&choice.PlayerId==secondActor&&choice.ResolvingStackItemId==originalItem.StackItemId&&choice.LegalObjectIds.SequenceEqual(new[]{"P2-BATTLEFIELD-ROSE-SACRIFICE"})&&originalItem.TriggerCost is null&&originalItem.ControllerId==secondActor&&originalItem.BattlefieldStart is{CardNo:"UNL-209/219",Damage:0,DrawCount:1}&&originalItem.BattlefieldStart.ControllerId==secondActor,"Literal original B Lab skill waits for B's local optional cost, with original pending stack present.");
 Check(before.CardObjects["P2-OTHER"].CardNo=="OGN·278/298"&&before.CardObjects["P2-OTHER"].OwnerId==secondActor&&before.ObjectLocations["P2-OTHER"].BattlefieldObjectId=="P2-OTHER"&&before.ObjectLocations["P2-BATTLEFIELD-AAA-OFFSITE"].BattlefieldObjectId=="P2-OTHER","Original referenced offsite battlefield is physically registered, its owner/location and offsite unit literal.");
 var cost=frame.Commands[4];var costRaw=cost.RawCommand!.Value;var paid=states[(cost.CompletedTick,cost.CompletedEventSequence)];var captured=paid.StackItems.Single();
 Check(costRaw.GetProperty("choiceId").GetString()==choice.ChoiceId&&costRaw.GetProperty("choiceWindow").GetString()==choice.ChoiceWindow&&costRaw.GetProperty("chosenObjectIds").EnumerateArray().Select(x=>x.GetString()).SequenceEqual(new[]{"P2-BATTLEFIELD-ROSE-SACRIFICE"})&&paid.PlayerZones[secondActor].Graveyard.Contains("P2-BATTLEFIELD-ROSE-SACRIFICE")&&paid.PlayerZones[secondActor].Hand.Count==0&&paid.PendingCardChoice is null,"Actual native local cost is selected and destroyed before response, with no early draw.");
 Check(paid.PriorityPlayerId==secondActor&&captured.StackItemId==originalItem.StackItemId&&captured.ControllerId==secondActor&&captured.BattlefieldStart!.ControllerId==secondActor&&captured.TriggerCost!.DestructionTarget!.ObjectId=="P2-BATTLEFIELD-ROSE-SACRIFICE","Original captured B source/controller persists through paid local destruction.");
 var afterFirst=states[(frame.Commands[5].CompletedTick,frame.Commands[5].CompletedEventSequence)];Check(afterFirst.PriorityPlayerId==firstActor&&afterFirst.StackItems.Single().ControllerId==secondActor,"First actual native B pass gives A priority without transferring the original skill.");
 var final=frame.AuthoritativeState!;Check(final.Phase==MatchPhases.Main&&final.TurnPlayerId==secondActor&&final.StackItems.Count==0&&final.PendingCardChoice is null&&final.PlayerZones[secondActor].Graveyard.Contains("P2-BATTLEFIELD-ROSE-SACRIFICE")&&final.PlayerZones[secondActor].Hand.Count==2&&final.PlayerZones[firstActor].Hand.Count==0&&final.CardObjects["P2-BATTLEFIELD-AAA-OFFSITE"].Damage==0,"Native choice and responses draw exactly one Lab plus one ordinary card for B; offsite original remains undamaged.");
 var resolved=frame.Events.Where(e=>e.Event.Kind=="BATTLEFIELD_TRIGGER_RESOLVED").ToArray();var destroyed=frame.Events.Single(e=>e.Event.Kind=="UNIT_DESTROYED");var called=frame.Events.Single(e=>e.Event.Kind=="RUNES_CALLED");
 Check(resolved.Length==1&&JsonSerializer.SerializeToElement(resolved[0].Event.Payload,json).GetProperty("playerId").GetString()==secondActor&&destroyed.Sequence>cost.StartedEventSequence&&destroyed.Sequence<=cost.CompletedEventSequence&&resolved[0].Sequence>cost.CompletedEventSequence&&resolved[0].Sequence<called.Sequence,"Literal sacrifice is paid inside the original native cost input, before both responses, printed draw and B rune call.");
 Check(frame.Commands.All(c=>c.CommandType!="SURRENDER")&&frame.Events.All(e=>e.Event.Kind!="MATCH_WON"),"This controlled native case does not claim a normal full game victory.");
 await using(var connection=await source.OpenConnectionAsync()){
  foreach(var c in frame.Commands.Skip(4)){
   await using var q=new NpgsqlCommand("select payload::text from action_prompts where match_id=@room and player_id=@actor and prompt_tick=@tick and last_event_sequence=@seq",connection);q.Parameters.AddWithValue("room",room);q.Parameters.AddWithValue("actor",c.PlayerId);q.Parameters.AddWithValue("tick",c.StartedTick);q.Parameters.AddWithValue("seq",c.StartedEventSequence);var text=(string)(await q.ExecuteScalarAsync())!;using var p=JsonDocument.Parse(text);var raw=c.RawCommand!.Value;
   Check(raw.GetProperty("promptId").GetString()==p.RootElement.GetProperty("promptId").GetString()&&raw.GetProperty("snapshotTick").GetInt64()==c.StartedTick&&p.RootElement.GetProperty("actionable").GetBoolean()&&p.RootElement.GetProperty("candidates").EnumerateArray().Any(x=>x.GetProperty("action").GetString()==c.CommandType&&x.GetProperty("enabled").GetBoolean()),"Each actual native response stamps its literal previously persisted current actor prompt and tick.");
  }
 }
 Check((await MatchActionLogReplayer.ValidateRecoveryFrameAsync(frame,new CoreRuleEngine(),default)).Count==0,"Complete strict original recovery and replay pass, without a live room action.");
 totals["commands"]+=frame.Commands.Count;totals["events"]+=frame.Events.Count;totals["authority"]+=states.Count;outcomes.Add(new{room,actualAllSevenTableCounts=counts,allOriginalFieldsAndEveryHistoryAndReplayExact=true});
 NpgsqlCommand Query(NpgsqlConnection c,string sql){var q=new NpgsqlCommand(sql,c);q.Parameters.AddWithValue("room",room);return q;}
}
Check(totals["commands"]==7&&totals["events"]==expectedEvents&&totals["authority"]==7&&totals["snapshots"]==13&&totals["prompts"]==13,"Exact controlled seven original histories and thirteen actual private rows per type; no full-game claim.");
var output=new{status="PASS_INDEPENDENT_CURRENT_CONTROLLED_LAB_SEVEN_ORIGINAL_NATIVE_HISTORY_THIRTEEN_PRIVATE_VIEWS_AND_FULL_REPLAY",actualRuleInputs=RuleInputIdentity.Current,totals,rooms=outcomes,literalNativeBCostBPassAPassAndCapturedBControllerOnBTurn=true,ordinaryFullGameAnd15NetworkGuardsHaveSeparateOriginalEvidence=true,actualReadOnlyConnection=true,noWriterRerunOrMatchMigration=true,notAdditionalFullGameVisibleOrPhysicalWindowsAcceptance=true};await File.WriteAllTextAsync(args[1],JsonSerializer.Serialize(output,json));Console.WriteLine(output.status);
bool Same(JsonElement a,JsonElement b)=>JsonNode.DeepEquals(JsonNode.Parse(a.GetRawText()),JsonNode.Parse(b.GetRawText()));
static JsonDocument Read(string path){using var zip=new GZipStream(File.OpenRead(path),CompressionMode.Decompress);return JsonDocument.Parse(zip);}
static void Check(bool value,string reason){if(!value)throw new Exception(reason);}

JsonNode EventNode(GameEvent value){var node=JsonSerializer.SerializeToNode(value,json)!;if(value.Kind=="RUNE_POOL_CLEARED"&&node["payload"]?["playerIds"] is JsonArray ids)node["payload"]!["playerIds"]=new JsonArray(ids.Select(i=>i!.GetValue<string>()).Order(StringComparer.Ordinal).Select(i=>JsonValue.Create(i)).ToArray());return node;}
