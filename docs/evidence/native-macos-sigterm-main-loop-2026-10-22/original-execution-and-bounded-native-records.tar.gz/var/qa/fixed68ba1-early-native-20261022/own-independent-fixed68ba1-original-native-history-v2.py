# -*- coding: utf-8 -*-
from pathlib import Path
import datetime,hashlib,json,os,re,resource,subprocess,time
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;old=root/'var/qa/fixed3f2dc-early-native-20261022'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
pub=load(w/'frozen-fixed68ba1-native-composition-v1.json');runtime=Path(pub['apiRuntimeRoot']);helpers=Path(pub['helperRuntimeRoot'])
receipt=w/'independent-fixed68ba1-native-history-run-v2.json';result=w/'independent-fixed68ba1-native-history-result-v2.json';stop=w/'live-current-ci-main-stop-v3.json'
assert not any(p.exists() for p in [receipt,result,stop]);proof={'startedAtUtc':now(),'fixedCommit':pub['fixedCommit'],'runId':pub['fixedCiRun'],'status':'WAITING_OWN_FIXED_NATIVE_ORIGINAL_SCORE_AND_NETWORK_READY','actualRuleInputs':pub['actualRuleInputs'],'existingApi46RuntimeReusedWithoutNewCopy':True}
try:
 ready_path=w/'live-current-ci-main-ready-v3.json';state_path=w/'live-current-ci-owner-state-v2.json';until=time.monotonic()+1200
 while True:
  assert time.monotonic()<until and not (w/'live-current-ci-main-owner-terminal-v3.json').exists()
  if ready_path.exists() and state_path.exists() and load(state_path).get('stage')=='WAITING_INDEPENDENT_CURRENT_ORIGINAL_SQL_HISTORY_AND_FULL_REPLAY':break
  time.sleep(.5)
 ready=load(ready_path);card=ready['actualScoreFieldCardNo'];assert card in {'OGN·275/298','OGN·278/298','OGN·277/298'}
 variant=2 if card=='OGN·275/298' else 1;gateway=29 if variant==2 else 17
 original=old/('fixed3f2dc-native-history-reader-source-v'+str(variant));source=w/'selected-actual-native-history-reader-source-v2';source.mkdir()
 assembly='Fixed68ba1NativeHistoryReaderV'+str(variant);records=[]
 for p in original.iterdir():
  if not p.is_file():continue
  raw=p.read_bytes();s=raw.decode()
  if p.name=='Program.cs':
   assert s.count('3f2dc4025834ec649d786646c2d2e72f3483a1d5')==1;s=s.replace('3f2dc4025834ec649d786646c2d2e72f3483a1d5',pub['fixedCommit']).replace('3f2dc','68ba1')
   actual_ready_names=re.findall(r'Path.Combine\(work,"(live-current-ci-main-ready-v[0-9]+\.json)"\)',s)
   assert len(actual_ready_names)==1 and s.count(actual_ready_names[0])==1
   s=s.replace(actual_ready_names[0],'live-current-ci-main-ready-v3.json',1)
   if card=='OGN·277/298':
    extra='var actualMove=frame.Commands.Skip(n+3).Single(c=>c.CommandType=="MOVE_UNIT");var actualDestination=actualMove.RawCommand!.Value.GetProperty("destination").GetString()!;Check(actualDestination.StartsWith("BATTLEFIELD:",StringComparison.Ordinal),"Exact actual field destination.");var actualField=actualDestination["BATTLEFIELD:".Length..];Check(initial.CardObjects[actualField].CardNo=="OGN·277/298"&&initial.CardObjects[actualField].OwnerId==a&&initial.PlayerZones[a].Battlefields.Contains(actualField)&&actualMove.RawCommand!.Value.GetProperty("origin").GetString()=="BASE"&&actualMove.RawCommand!.Value.GetProperty("sourceObjectId").GetString()==otherTarget,"Actual own physical277, one base-to-field movement; outgoing277 skill not executed or certified.");\n'
    assert s.count('var replaySession=new MatchSession')==1;s=s.replace('var replaySession=new MatchSession',extra+'var replaySession=new MatchSession',1)
  elif p.suffix=='.csproj':
   names=re.findall(r'<HintPath>[^<]*/([^/<]+\.dll)</HintPath>',s);assert names and all((runtime/name).is_file() for name in names);s=re.sub(r'<HintPath>[^<]*/([^/<]+\.dll)</HintPath>',lambda m:'<HintPath>'+str(runtime/m.group(1))+'</HintPath>',s).replace('Fixed3f2dcNativeHistoryReaderV'+str(variant),assembly);assert '<AssemblyName>'+assembly+'</AssemblyName>' in s
  else:assert p.suffix in {'.cs','.json'}
  target=source/p.name;target.write_text(s);records.append({'originalPath':str(p.relative_to(root)),'originalSha256':sha(p),'newPath':str(target.relative_to(root)),'newSha256':sha(target)})
 with (w/'build-selected-native-history-reader-v2.log').open('xb') as log:subprocess.run(['/Users/dinghaolin/.dotnet/dotnet','build',str(source/'probe.csproj'),'--configuration','Release','--nologo'],cwd=source,stdout=log,stderr=subprocess.STDOUT,check=True)
 dll=source/'bin/Release/net10.0'/(assembly+'.dll');bits={str(p.relative_to(w)):sha(p) for p in [dll,dll.with_suffix('.pdb')]}
 prefix=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(runtime/'Riftbound.Api.deps.json'),'--runtimeconfig',str(runtime/'Riftbound.Api.runtimeconfig.json'),str(dll)]
 measurement=json.loads(subprocess.check_output(prefix+['--loaded-inputs'],cwd=runtime,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0')))
 assert Path(measurement['baseDirectory'])==runtime and measurement['actualRuleInputs']==pub['actualRuleInputs'] and len(measurement['assemblies'])==4
 for a in measurement['assemblies']:assert Path(a['path'])==runtime/(a['name']+'.dll') and a['sha256']==pub['runtimeFiles'][a['name']+'.dll'] and a['mvid']
 proof.update(selectedActualPhysicalFieldCardNo=card,originalReaderVariant=variant,allOriginalIndependentHistoryPrivacySeatRawCommandEventStatePrefixAndVictoryReplayAssertionsRetainedExceptExactCandidateAndReadyFilenameBindings=True,sourceDerivation=records,actualLoadedFourAssemblies=measurement,ownReaderBits=bits)
 command=prefix+[str(w),str(result)];proof['command']=command
 with (w/'independent-fixed68ba1-native-history-v2.log').open('xb') as log:code=subprocess.run(command,cwd=runtime,env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_here_native;Username=codex_riftbound_audit',DOTNET_DbgEnableMiniDump='0'),stdout=log,stderr=subprocess.STDOUT,timeout=300).returncode
 proof['exitCode']=code;assert code==0;d=load(result)
 assert d['status'].startswith('PASS_INDEPENDENT_FIXED68ba1_') and d['room']==ready['room'] and d['commands']==ready['totalCommands']==ready['originalGatewayPrefixCommands']+2+3+gateway
 assert d['events']==ready['events'] and d['actualRuleInputs']==pub['actualRuleInputs'] and d['nativeAcceptedGameplayCommands']==3 and d['gatewayContinuationCommands']==gateway and d['winningScore']==8
 if variant==2:assert d['originalNormalContinuationCommands']==17 and d['heldSkillPriorityPasses']==12
 assert all(sha(runtime/p)==h for p,h in pub['runtimeFiles'].items()) and all(sha(helpers/p)==h for p,h in pub['helperRuntimeFiles'].items()) and all(sha(w/p)==h for p,h in bits.items())
 proof.update(status=d['status'],allFrozenApiAndOriginalHelperHashesStable=True,actualAllHistoryCounts=d['actualHistoricalPayloads'],resultSha256=sha(result))
 completion={'atUtc':now(),'room':ready['room'],'independentReadOnlyHistoryAndFullReplayPass':True,'result':str(result),'resultSha256':sha(result),'commands':d['commands'],'events':d['events'],'normalGatewayContinuationCommands':gateway,'originalNormalContinuationCommands':17,'heldSkillPriorityPasses':gateway-17,'nativeAcceptedGameplayCommands':3,'currentWholeFullCiVisibleAndPhysicalWindowsAcceptance':'OPEN'}
 temp=stop.with_suffix('.tmp');temp.write_text(json.dumps(completion,indent=2));temp.replace(stop)
except BaseException as e:
 proof.update(status='FAILED_INDEPENDENT_FIXED68BA1_READER_ORIGINAL_ROOM_RETAINED_NO_ACTION_RESUBMITTED',errorType=type(e).__name__,error=str(e));raise
finally:
 proof['finishedAtUtc']=now();receipt.write_text(json.dumps(proof,indent=2))
print(proof['status'],flush=True)
