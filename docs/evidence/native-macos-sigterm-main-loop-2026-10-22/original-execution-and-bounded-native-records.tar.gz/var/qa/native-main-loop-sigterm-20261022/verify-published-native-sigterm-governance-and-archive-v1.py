from pathlib import Path
import copy, datetime, gzip, hashlib, json, tarfile

root = Path('/Users/dinghaolin/MyProjects/riftbound'); qa = Path(__file__).resolve().parent
ev = root/'docs/evidence/native-macos-sigterm-main-loop-2026-10-22'
load = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
old = json.loads(gzip.decompress((qa/'prior-publication-v1/current-manifest.json.gz').read_bytes()))
current = load(root/'docs/audit/current-manifest.json')
prep = load(qa/'macos-sigterm-product-gate-publication-preparation-v1.json')
assert hashlib.sha256(gzip.decompress((qa/'prior-publication-v1/current-manifest.json.gz').read_bytes())).hexdigest() == prep['currentManifestSha256']
assert current['certificationScope'] == old['certificationScope'] and current['inputs'] == old['inputs']
assert current['laterSourceDeltas'] == old['laterSourceDeltas'] and len(current['laterSourceDeltas']) == 7
assert current['acceptanceGates'][:251] == old['acceptanceGates'] and len(current['acceptanceGates']) == 252
assert current['acceptanceGates'][-1]['id'] == 'NATIVE_MACOS_SIGTERM_MAIN_LOOP_EXIT' and current['acceptanceGates'][-1]['state'] == 'OPEN'
assert set(current['reviewContexts']) == set(old['reviewContexts']) and len(current['reviewContexts']) == 80
source_manifest = current['currentMacosSigtermMainLoopInputChange']['sourceManifest']
assert source_manifest['path'] == str((ev/'source-manifest.json').relative_to(root)) and source_manifest['sha256'] == sha(ev/'source-manifest.json')
changed = []
for identity, before in old['reviewContexts'].items():
    after = current['reviewContexts'][identity]
    if after == before: continue
    changed.append(identity); expected = copy.deepcopy(before)
    for ref in expected['implementation']:
        if ref['path'] == 'clients/godot/scripts/Main.cs': ref['sha256'] = sha(root/ref['path'])
    expected.update(currentImplementationCommit=prep['baseCommit'], currentImplementationIncludesUncommittedChanges=True,
                    ciState='PENDING', currentMacosSigtermMainLoopInputRefresh={'sourceManifest': source_manifest, 'onlyCurrentImplementationPinRefreshNotSemanticCertification': True, 'newFixedFullRequired': True})
    assert after == expected
    assert after.get('verificationSources') == before.get('verificationSources') and ('verificationSources' in after) == ('verificationSources' in before)
assert sorted(changed) == sorted(prep['fourMainContextPinsRequireExplicitRefresh']) and len(changed) == 4
reviews_path = root/old['inputs']['reviews']['path']
assert sha(reviews_path) == prep['oldReviewsPin']['sha256'] and len(load(reviews_path)['reviews']) == 165
old_governance = json.loads(gzip.decompress((root/prep['oldGovernancePin']['path']).read_bytes()))
assert sha(root/prep['oldGovernancePin']['path']) == prep['oldGovernancePin']['sha256']
governance_path = qa/'final-governance-v1.json'; governance = load(governance_path)
assert governance['governanceValid'] and not governance['semanticCoverageCertified'] and governance['errors'] == [] and governance['currentReviewCount'] == 165
before_ids = {v['id'] for v in old_governance['remainingObligations']}; after_ids = {v['id'] for v in governance['remainingObligations']}
assert len(before_ids) == 17182 and len(after_ids) == 17183 and before_ids <= after_ids
added_ids = after_ids-before_ids; assert len(added_ids) == 1 and 'NATIVE_MACOS_SIGTERM_MAIN_LOOP_EXIT' in next(iter(added_ids))
archive_map = load(ev/'archive-map.json'); archive = root/archive_map['archive']['path']
assert sha(archive) == archive_map['archive']['sha256']
with tarfile.open(archive) as tar:
    names = set(tar.getnames()); expected = {r['archiveMember'] for r in archive_map['originalPathsWithExactCanonicalMember']}
    assert names == expected
    for row in archive_map['originalPathsWithExactCanonicalMember']:
        raw = tar.extractfile(row['archiveMember']).read()
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
assert all(not name.endswith(('.zip', '.html', '.html.gz')) and not any(part.endswith('.app') for part in Path(name).parts) for name in expected)
final = load(ev/'final-original-test-and-input-retention.json')
assert final['actualCases'] == 13449 and final['actualMethods'] == 7550 and final['originalCaseNameMultisetAndMethodSetExactNoAddedOrRemovedConformanceTests']
assert final['originalCheckControllerInterruptedNotRelabeledNormalExit'] and final['originalOneTestProcessKernelExitZeroAndUnchangedOriginalReportVerifyGuardsActuallyResumed'] and final['originalToolSummaryMissingNotFabricatedNoSecondCheck']
source = load(ev/'source-manifest.json')
assert source['scopeKind'] == 'NATIVE_MACOS_PROCESS_LIFECYCLE_ONLY_NOT_CARD_OR_CLAUSE_SEMANTIC_REVIEW' and not source['semanticCoverageCertified']
assert source['expectedRemainingObligations'] == 17183 and source['currentFixedFullExpectedCases'] == 13598 and source['currentFixedFullExpectedMethods'] == 7691
assert source['gameCardRuleFaqSourceDatesUniverseAndSevenDeltasRetained'] and not source['newGameSourceVersionOrRuntimeCatalogAdopted']
compressed = ev/'final-governance.json.gz'
assert not compressed.exists(); compressed.write_bytes(gzip.compress(governance_path.read_bytes(), mtime=0))
assert gzip.decompress(compressed.read_bytes()) == governance_path.read_bytes()
result = {'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'status': 'NATIVE_MACOS_SIGTERM_PUBLICATION_165_REVIEWS80_CONTEXTS252_GATES7_DELTAS17183_OBLIGATIONS_INDEPENDENTLY_VERIFIED_NO_SEMANTIC_CERTIFICATION',
          'all165OriginalReviewsBytesExact': True, 'all80OldContextIdentitiesAnd76WholeContextsExact': True,
          'fourMainSourcePinRefreshesExplicitPendingWithCompleteOldContextsArchived': changed,
          'allOldOptionalVerificationSourcesPresenceAndValuesExact': True, 'all251OldGateObjectsAndSevenSourceDeltaObjectsAndCertificationScopeExact': True,
          'all17182OriginalRemainingIdsRetained': True, 'onlyAddedRemainingId': next(iter(added_ids)), 'currentRemainingCount': 17183,
          'originalCheckControllerInterruptionAndMissingToolSummaryPreservedNotNormalExitClaim': True,
          'originalSameDotnetTestKernelExitAndOriginalPostvalidationActuallyExecutedNoSecondCheck': True,
          'wholeOriginalCaseMultisetAnd1804Files143Full151Cases110Pairs11Decks424242AndAssertionsRetained': True,
          'allArchiveMembersExactAndEqualPayloadAliasesDeduplicated': True, 'archiveBytes': archive.stat().st_size, 'archiveSha256': sha(archive),
          'newFixedFullCiNativeVisibleAndPhysicalWindows': 'OPEN', 'wholePrintingOrGoalCertified': False,
          'finalGovernanceRawSha256': sha(governance_path), 'finalGovernanceCompressedSha256': sha(compressed)}
output = ev/'independent-final-retention-and-publication-proof.json'; assert not output.exists(); output.write_text(json.dumps(result, indent=2)+'\n')
print('PASS165reviews80contexts252gates7deltas;17182oldIDs+oneproductgate=17183;4Mainpins76wholecontexts;wholeoldtests retained;original interrupted check transparently resumed;archiveexact;semanticfalse', flush=True)
