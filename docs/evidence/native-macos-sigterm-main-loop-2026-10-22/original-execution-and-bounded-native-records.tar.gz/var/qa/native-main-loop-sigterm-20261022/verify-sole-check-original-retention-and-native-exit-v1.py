from pathlib import Path
import collections
import datetime
import gzip
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET

root = Path('/Users/dinghaolin/MyProjects/riftbound')
qa = Path(__file__).resolve().parent
load = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
start_path = qa/'sole-check-start-inputs-v1.json.gz'
start = json.loads(gzip.decompress(start_path.read_bytes()))
end = load(qa/'resumed-original-check-postvalidation-terminal-v1.json')
assert end['exitCode'] == 0 and all(end[k] for k in ['all3344SourcesAndModesStable', 'all1804OriginalConformanceFilesStable', 'all1419ConformanceAnd23NativeRuntimeInputsStable'])
assert end['startManifestSha256'] == sha(start_path)
for p, record in start['all3344SourceHashesAndModes'].items():
    assert sha(root/p) == record['sha256'] and oct((root/p).stat().st_mode & 0o777) == record['mode']
for p, record in start['all1804OriginalConformanceFilesIncludingTheoryAndNineFullSources'].items():
    assert sha(root/p) == record['sha256'] and oct((root/p).stat().st_mode & 0o777) == record['mode']
for group in start['actualRuntimeInputs'].values():
    assert all(sha(root/p) == h for p, h in group.items())
ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def read(path):
    doc = ET.parse(path)
    definitions = {d.get('id'): d.find('t:TestMethod', ns).attrib for d in doc.findall('.//t:UnitTest', ns)}
    rows = doc.findall('.//t:UnitTestResult', ns)
    return collections.Counter(r.get('testName') for r in rows), {definitions[r.get('testId')]['className']+'.'+definitions[r.get('testId')]['name'] for r in rows}, collections.Counter(r.get('outcome') for r in rows)
original_trx = root/start['originalBaselineTrx']
assert sha(original_trx) == start['originalBaselineTrxSha256']
trx = qa/'sole-check-v1/check/results.trx'
before = read(original_trx); current = read(trx)
assert current == before and sum(current[0].values()) == 13449 and len(current[1]) == 7550 and current[2] == {'Passed': 13449}
assert end['status'].startswith('ORIGINAL_SOLE_CHECK_TEST_PROCESS_KERNEL_EXIT0_TRX_AND_UNCHANGED_ORIGINAL_POSTVALIDATION_PASS')
assert end['profile'] == 'check' and end['total'] == 13449 and end['methods'] == 7550
assert end['originalControllerInterruptedNotAssumedSuccessful'] and end['originalTestRulesToolSummaryAbsentNotFabricatedOrOverwritten']
assert end['oneOriginalTestExecutionNoBuildOrTestRestart']
focus = read(qa/'native-hub-identity-focus-v1/focus/results.trx')
assert sum(focus[0].values()) == 668 and len(focus[1]) == 380 and focus[2] == {'Passed': 668} and not (focus[0]-current[0])
assert '0 个警告' in (qa/'candidate-native-debug-build-v1.log').read_text() and '0 个错误' in (qa/'candidate-native-debug-build-v1.log').read_text()
assert 'Ran 74 tests' in (qa/'tooling-tests-v1.log').read_text() and (qa/'tooling-tests-v1.log').read_text().rstrip().endswith('OK')
red = load(qa/'original-exported-main-sigterm-regression-red-v2.json')
assert red['status'] == 'EXPECTED_ORIGINAL_EXPORTED_MAIN_SIGTERM_RED' and red['cppStaticStringErrorPresent'] and 'exit -6' in red['error']
local = load(qa/'local-exported-main-sigterm-candidate-v1.json')
assert local['status'].startswith('LOCAL_MACOS_EXPORTED_MAIN_SIGTERM_AND_NATURAL_CLEAN') and local['originalProjectConfigExactlyRestored']
paired = load(qa/'local-connected-pair-sigterm-owner-terminal-v1.json')
assert paired['status'].startswith('PASS_LOCAL_MACOS_DEFAULT_MAIN_PAIR_REAL_PG_COLD_RESTORE')
assert all(paired[k] for k in ['bothSameProcessAuthenticatedColdRestore', 'bothSigtermExitZeroAndPtyFullyDrainedNoErrors', 'originalHistorySeedEmptyInitialAuthorityAndFiveHistoryTablesExact', 'allOriginal345AuditSevenTablesExact', 'allOther83NativeSevenTablesExact', 'allLocalNativePayloadsStable', 'ownApiStopped', 'ownPostgresSmartStopped'])
for record in paired['ownedNativeProcesses']:
    assert record['exitCode'] == 0 and record['ptyFullyDrained']
    log = qa/record['log']; text = log.read_text(errors='replace')
    assert sha(log) == record['logSha256'] and 'Termination requested; exiting through Godot.' in text and 'ERROR:' not in text
assert paired['originalCommands'] == 7 and paired['originalEvents'] == 24
for path in ['tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json', 'tests/Riftbound.PostgresAcceptance/Program.cs', 'tests/Riftbound.NativeNetworkSmoke/Program.cs']:
    assert (root/path).read_bytes() == subprocess.check_output(['git', 'show', start['baseCommit']+':'+path], cwd=root)
result = {'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': 'SOLE_MACOS_SIGTERM_CHECK13449_CASES7550_METHODS_ALL_PASS_EXACT_ORIGINAL_TEST_IDENTITIES_AND_NATIVE_INTEGRATION_VERIFIED',
          'baseCommit': start['baseCommit'], 'actualCases': 13449, 'actualMethods': 7550, 'actualOutcomes': dict(current[2]),
          'originalCaseNameMultisetAndMethodSetExactNoAddedOrRemovedConformanceTests': True,
          'all1804OriginalConformanceFilesAndTheoryRowsNineFullSources143Methods151Cases110Pairs11Decks424242AndVictoryReplayAssertionsRetained': True,
          'checkDoesNotClaimAll143FullGamesExecuted': True, 'focusCases': 668, 'focusMethods': 380, 'toolingTests': 74,
          'nativeBuildZeroWarningsErrors': True, 'originalRealExportedMainRegressionExit': -6, 'localExportedMainNaturalAndSigtermPassed': True,
          'originalCheckControllerInterruptedNotRelabeledNormalExit': True,
          'originalOneTestProcessKernelExitZeroAndUnchangedOriginalReportVerifyGuardsActuallyResumed': True,
          'originalToolSummaryMissingNotFabricatedNoSecondCheck': True,
          'originalCheckPostvalidation': {'path': str((qa/'resumed-original-check-postvalidation-terminal-v1.json').relative_to(root)), 'sha256': sha(qa/'resumed-original-check-postvalidation-terminal-v1.json')},
          'localPairRealPgColdRestoreAndBothSigtermClean': True, 'originalLabCommands': 7, 'originalLabEvents': 24,
          'original345AuditAndOther83NativeSevenTablesExact': True, 'original59SqlObjectsOrderProgramAnd15NetworkGuardsSourceExact': True,
          'all3344SourceModes1419Conformance23NativeStable': True, 'actualFourLoadedAssembliesAndRuleInputs': start['actualFourLoadedAssembliesAndRuleInputs'],
          'soleCheckTrx': {'path': str(trx.relative_to(root)), 'sha256': sha(trx)},
          'originalBaselineTrx': {'path': str(original_trx.relative_to(root)), 'sha256': sha(original_trx)},
          'nativeCandidateIsExplicitlyLocalUncommittedNotNewFixedCiPackage': True,
          'newFixedFullActualCiNativeVisiblePairAndPhysicalWindows': 'OPEN', 'noNewGameSemanticReviewOrSourceUniverseChange': True, 'wholePrintingOrGoalCertified': False}
out = qa/'final-sole-check-original-retention-and-native-exit-v1.json'
assert not out.exists(); out.write_text(json.dumps(result, indent=2)+'\n')
print('PASS sole13449/7550 exact original identities;668/380focus;74tools;1804 original files9full143/151/110/11/424242;3344/1419/23stable;local native standalone and realPG pair exit clean;newfixedfull/productsOPEN', flush=True)
