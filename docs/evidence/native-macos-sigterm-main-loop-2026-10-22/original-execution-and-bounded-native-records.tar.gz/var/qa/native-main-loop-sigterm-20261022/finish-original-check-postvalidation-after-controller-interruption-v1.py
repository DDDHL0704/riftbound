from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
root = Path('/Users/dinghaolin/MyProjects/riftbound'); qa = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
start = json.loads(gzip.decompress((qa/'sole-check-start-inputs-v1.json.gz').read_bytes()))
observer = json.loads((qa/'original-live-check-exit-observer-terminal-v1.json').read_text())
assert observer['status'] == 'ORIGINAL_CHECK_DOTNET_TEST_EXIT_CAPTURED_FROM_KERNEL_NOT_RERUN'
assert observer['originalExitedNormally'] and observer['originalExitCode'] == 0 and observer['originalTermSignal'] is None
assert observer['originalDotnetTestPid'] == 76527 and any(e['pid'] == 76527 and e['rawWaitStatus'] == 0 for e in observer['kernelEvents'])
assert observer['originalControllerExitStatusUnavailableNotAssumedZero'] and observer['noBuildTestOrGameplayCommandRestarted']
assert all(observer[k] for k in ['all3344SourcesAndModesStable', 'all1804OriginalConformanceFilesStable', 'all1419ConformanceAnd23NativeRuntimeInputsStable'])
source = root/'scripts/test-rules.py'; assert sha(source) == start['all3344SourceHashesAndModes']['scripts/test-rules.py']['sha256']
spec = importlib.util.spec_from_file_location('unchanged_original_check_postvalidation', source)
module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
plan_path = qa/'sole-check-v1/plan.json'; plan = json.loads(plan_path.read_text())
assert sha(plan_path) == observer['originalPlanSha256'] and plan['profile'] == 'check' and len(plan['shards']) == 1
shard = plan['shards'][0]; assert shard['name'] == 'check' and len(shard['methods']) == 7550
assert plan['testAssemblySha256'] == sha(root/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0/Riftbound.ConformanceTests.dll')
trx = qa/'sole-check-v1/check/results.trx'
rows, counters = module.report(trx)
module.verify(rows, counters, set(shard['methods']))
assert counters == {'total': 13449, 'passed': 13449, 'failed': 0, 'notExecuted': 0}
result = {'atUtc': datetime.now(timezone.utc).isoformat(),
          'status': 'ORIGINAL_SOLE_CHECK_TEST_PROCESS_KERNEL_EXIT0_TRX_AND_UNCHANGED_ORIGINAL_POSTVALIDATION_PASS_CONTROLLER_INTERRUPTION_RETAINED',
          'profile': 'check', 'baseCommit': start['baseCommit'], 'originalDotnetTestPid': observer['originalDotnetTestPid'],
          'exitCode': observer['originalExitCode'], 'originalKernelExitObserverSha256': sha(qa/'original-live-check-exit-observer-terminal-v1.json'),
          'startManifestSha256': sha(qa/'sole-check-start-inputs-v1.json.gz'), 'originalPlanSha256': sha(plan_path),
          'originalTestRulesVerifierSourceSha256': sha(source), 'originalReportAndVerifyFunctionsActuallyExecuted': True,
          'total': counters['total'], 'methods': len(shard['methods']), 'counters': counters,
          'trxSha256': sha(trx), 'originalControllerInterruptedNotAssumedSuccessful': True,
          'originalTestRulesToolSummaryAbsentNotFabricatedOrOverwritten': not (qa/'sole-check-v1/summary.json').exists(),
          'oneOriginalTestExecutionNoBuildOrTestRestart': True,
          'all3344SourcesAndModesStable': observer['all3344SourcesAndModesStable'],
          'all1804OriginalConformanceFilesStable': observer['all1804OriginalConformanceFilesStable'],
          'all1419ConformanceAnd23NativeRuntimeInputsStable': observer['all1419ConformanceAnd23NativeRuntimeInputsStable']}
assert result['originalTestRulesToolSummaryAbsentNotFabricatedOrOverwritten']
target = qa/'resumed-original-check-postvalidation-terminal-v1.json'
assert not target.exists(); target.write_text(json.dumps(result, indent=2)+'\n')
print('ORIGINAL one check payload exit0 and all13449/7550 original postvalidation guards PASS; interrupted controller retained; no second check or fabricated tool summary.', flush=True)
