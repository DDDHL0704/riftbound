import ast, datetime, errno, fcntl, gzip, hashlib, json, os, plistlib, pty, re, resource, shutil, signal, socket, subprocess, threading, time, urllib.request
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CORE, (0, 0)); os.umask(0o077)
root = Path('/Users/dinghaolin/MyProjects/riftbound'); w = Path(__file__).resolve().parent
old = root/'var/qa/fixed68ba1-early-native-20261022'
pg = Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin'); cluster = root/'var/qa/permanent-play-here-base-20261017/postgres'
sock = Path('/tmp/rft-here-family-20261018-55486'); tables = ['matches', 'match_players', 'command_log', 'game_events', 'state_snapshots', 'snapshots', 'action_prompts']
read_env = dict(os.environ, PGOPTIONS='-c default_transaction_read_only=on')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest(); now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat(); load = lambda p: json.loads(p.read_text())
source = root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes = [n for n in ast.parse(source.read_text()).body if isinstance(n, ast.FunctionDef) and n.name in {'query', 'rooms', 'digests', 'observe_lock'}]
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(source), 'exec'), globals())
functions = old/'controlled-lab-native-owner-functions-v3.py'
exec(compile(functions.read_text(), str(functions), 'exec'), globals())
pub = load(old/'frozen-fixed68ba1-native-composition-v1.json'); api_runtime = Path(pub['apiRuntimeRoot']); helpers = Path(pub['helperRuntimeRoot'])
candidate = load(w/'local-exported-main-sigterm-candidate-v1.json'); app = Path(candidate['app']); executable = Path(candidate['executable'])
assert candidate['status'].startswith('LOCAL_MACOS_EXPORTED_MAIN_SIGTERM_AND_NATURAL_CLEAN')
assert all(sha(app/p) == h for p, h in candidate['appFiles'].items())
profiles = w/'private-connected-pair-profiles-v1'; profiles.mkdir(exist_ok=False)
for role in ['a', 'b']: shutil.copy2(old/'controlled-lab-native-prefix-v1'/('session-'+role+'.json'), profiles/('session-'+role+'.json'))
entry = load(old/'controlled-lab-native-prefix-v1/controlled-lab-original-entry-v1.json'); room = entry['room']
evidence = w/'connected-pair-original-frames-v1'; evidence.mkdir(exist_ok=False)
def checkpoint(name, value):
    with (evidence/name).open('x') as f: json.dump(value, f, ensure_ascii=False, indent=2)
guard = (root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a'); fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
proof = {'startedAtUtc': now(), 'status': 'RUNNING', 'baseCommit': pub['fixedCommit'], 'serverFixedCiRun': pub['fixedCiRun'],
         'clientIsLocalUncommittedSigtermCandidateNotCiExport': True, 'clientInputManifestSha256': sha(w/'local-exported-main-sigterm-candidate-v1.json'),
         'actualRuleInputs': pub['actualRuleInputs'], 'room': room, 'noNewRoomReseedOrGameplayInput': True,
         'ownedApiProcesses': [], 'ownedNativeProcesses': [], 'lockAtStart': observe_lock(), 'visibleOrWindowsClaimed': False}
api = power = None; clients = []; pumps = {}; started = False; before_audit = before_native = None
def launch_local(role):
    log = w/('local-candidate-connected-'+role+'-sigterm-v1.log')
    command = [str(executable), '--headless', '--max-fps', '60', '--quit-after', '6000', '--', '--riftbound-server=http://127.0.0.1:15847', '--riftbound-session-file='+str(profiles/('session-'+role+'.json')), '--riftbound-smoke-connect-only']
    master, slave = pty.openpty(); stream = log.open('xb', buffering=0)
    environment = dict(os.environ, DOTNET_DbgEnableMiniDump='0'); environment.pop('DOTNET_STARTUP_HOOKS', None)
    p = subprocess.Popen(command, cwd='/tmp', env=environment, stdin=subprocess.DEVNULL, stdout=slave, stderr=slave, start_new_session=True); os.close(slave)
    def drain():
        try:
            while True:
                try: data = os.read(master, 65536)
                except OSError as ex:
                    if ex.errno == errno.EIO: break
                    raise
                if not data: break
                stream.write(data)
        finally: os.close(master); stream.close()
    pump = threading.Thread(target=drain, daemon=True); pumps[p.pid] = pump; pump.start()
    record = {'role': role, 'ownPid': p.pid, 'actualCommand': command, 'log': log.name, 'localCandidateNotCiPayload': True}
    proof['ownedNativeProcesses'].append(record); clients.append((p, record, log)); return clients[-1]
try:
    frozen()
    assert subprocess.run([str(pg/'pg_ctl'), '-D', str(cluster), 'status'], capture_output=True).returncode == 3
    with socket.socket() as s: assert s.connect_ex(('127.0.0.1', 15847)) != 0
    power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())]); sock.mkdir(exist_ok=True)
    subprocess.run([str(pg/'pg_ctl'), '-D', str(cluster), '-l', str(w/'connected-sigterm-postgres-v1.log'), '-o', f'-p 55486 -h 127.0.0.1 -k {sock}', '-w', 'start'], check=True, capture_output=True); started = True
    audit = rooms('riftbound_acceptance'); original_native = rooms('riftbound_here_native'); others = [r for r in original_native if r != room]
    assert len(audit) == 345 and len(original_native) == 84 and len(others) == 83
    before_audit = digests('riftbound_acceptance', audit); before_native = digests('riftbound_here_native', others)
    start_api(1)
    before = export('original-seven-input-lab-before-connected-exit-v1')
    expected = json.loads(gzip.decompress((old/'controlled-lab-native-raw-v3/final-controlled-lab-original-frame-v1.json.gz').read_bytes()))
    for field in ['commands', 'events', 'authoritativeState', 'openingSeed', 'replayInitialState']: assert before[field] == expected[field], field
    assert len(before['commands']) == 7 and len(before['events']) == 24
    original_history_tables = digests('riftbound_here_native', [room])
    for role in ['a', 'b']: launch_local(role)
    native_wait(lambda: all(all(log_count(item[2], k) >= 1 for k in ['Joined', 'Snapshot', 'Prompt']) for item in clients), 'Both local default Main processes must restore original authenticated Lab views', 40, [item[0] for item in clients])
    counts = [{k: log_count(item[2], k) for k in ['Joined', 'Snapshot', 'Prompt']} for item in clients]
    assert set(subprocess.check_output(['/usr/sbin/lsof', '-tiTCP:15847', '-sTCP:LISTEN'], text=True).splitlines()) == {str(api.pid)}
    proof['ownApiFault'] = {'ownPid': api.pid, 'signal': 'SIGKILL', 'atUtc': now()}; api.kill(); api.wait(timeout=10); start_api(2)
    native_wait(lambda: all(all(log_count(item[2], k) > counts[i][k] for k in ['Joined', 'Snapshot', 'Prompt']) and 'Connection and session restored.' in item[2].read_text(errors='replace') for i, item in enumerate(clients)), 'Same local Main processes restore after actual owned API cold fault', 45, [item[0] for item in clients])
    for p, record, log in clients:
        assert p.poll() is None and 'ERROR:' not in log.read_text(errors='replace')
        record.update(signal='SIGTERM', signalAtUtc=now()); p.send_signal(signal.SIGTERM)
        wait_exit((p, record, log), 20)
        assert 'Termination requested; exiting through Godot.' in log.read_text(errors='replace')
    after = export('original-seven-input-lab-after-connected-exit-v1')
    for field in ['commands', 'events', 'authoritativeState', 'openingSeed', 'replayInitialState']: assert after[field] == before[field], field
    final_history_tables = digests('riftbound_here_native', [room])
    for table in ['command_log', 'game_events', 'state_snapshots', 'snapshots', 'action_prompts']:
        assert original_history_tables[table] == final_history_tables[table], table
    proof.update(status='PASS_LOCAL_MACOS_DEFAULT_MAIN_PAIR_REAL_PG_COLD_RESTORE_AND_BOTH_SIGTERM_CLEAN_ORIGINAL7_COMMANDS24_EVENTS_EXACT',
                 originalCommands=7, originalEvents=24, bothSameProcessAuthenticatedColdRestore=True, bothSigtermExitZeroAndPtyFullyDrainedNoErrors=True,
                 originalHistorySeedEmptyInitialAuthorityAndFiveHistoryTablesExact=True, beforeRoomSevenTables=original_history_tables, afterRoomSevenTables=final_history_tables,
                 fixedNewCiVisiblePairAndPhysicalWindowsStillOpen=True)
except BaseException as ex:
    proof.update(status='FAILED_LOCAL_CONNECTED_NATIVE_SIGTERM_ORIGINAL_HISTORY_RETAINED', errorType=type(ex).__name__, error=str(ex)); raise
finally:
    for p, record, log in clients:
        if p.poll() is None: p.send_signal(signal.SIGTERM); p.wait(timeout=20); record['stoppedOnlyForOwnedFailureCleanup'] = True
        pumps[p.pid].join(timeout=10); record.update(exitCode=p.returncode, logSha256=sha(log), ptyFullyDrained=not pumps[p.pid].is_alive())
    if api is not None and api.poll() is None:
        api.terminate()
        try: api.wait(timeout=25)
        except subprocess.TimeoutExpired: api.kill(); api.wait(timeout=10); proof['ownApiForcedStopAfterGracefulTimeout'] = True
    proof['ownApiStopped'] = api is None or api.poll() is not None
    if started:
        if before_audit is not None:
            proof.update(allOriginal345AuditSevenTablesExact=digests('riftbound_acceptance', audit) == before_audit,
                         allOther83NativeSevenTablesExact=digests('riftbound_here_native', others) == before_native,
                         actualAuditRoomsAtStop=rooms('riftbound_acceptance'), actualNativeRoomsAtStop=rooms('riftbound_here_native'))
        proof['ownPostgresSmartStopped'] = subprocess.run([str(pg/'pg_ctl'), '-D', str(cluster), '-m', 'smart', '-w', '-t', '20', 'stop'], capture_output=True).returncode == 0
    if power is not None and power.poll() is None: power.terminate(); power.wait(timeout=10)
    frozen(); proof.update(finishedAtUtc=now(), lockAtEnd=observe_lock(), allLocalNativePayloadsStable=all(sha(app/p) == h for p, h in candidate['appFiles'].items()))
    with (w/'local-connected-pair-sigterm-owner-terminal-v1.json').open('x') as f: json.dump(proof, f, indent=2)
    fcntl.flock(guard, fcntl.LOCK_UN)
print(proof['status'], flush=True)
