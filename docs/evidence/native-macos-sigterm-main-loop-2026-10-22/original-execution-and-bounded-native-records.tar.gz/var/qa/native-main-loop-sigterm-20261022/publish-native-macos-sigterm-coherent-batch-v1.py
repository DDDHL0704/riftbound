# -*- coding: utf-8 -*-
from pathlib import Path
import copy, datetime, gzip, hashlib, io, json, re, subprocess, tarfile

root = Path('/Users/dinghaolin/MyProjects/riftbound'); w = Path(__file__).resolve().parent
native = root/'var/qa/fixed68ba1-early-native-20261022'
load = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p, value):
    with p.open('x') as f: json.dump(value, f, ensure_ascii=False, indent=2)
def pin(p, role=None):
    value = {'path': str(p.relative_to(root)), 'sha256': sha(p)}
    if role: value['role'] = role
    return value

final = load(w/'final-sole-check-original-retention-and-native-exit-v1.json')
assert final['actualCases'] == 13449 and final['actualMethods'] == 7550 and final['actualOutcomes'] == {'Passed': 13449}
start = json.loads(gzip.decompress((w/'sole-check-start-inputs-v1.json.gz').read_bytes()))
assert all(sha(root/p) == v['sha256'] for p, v in start['all3344SourceHashesAndModes'].items())
base = '68ba1c5b63f52266323928da85bd75060e7e8fee'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == base
prep = load(w/'macos-sigterm-product-gate-publication-preparation-v1.json')
mp = root/'docs/audit/current-manifest.json'; m = load(mp); old = copy.deepcopy(m)
assert sha(mp) == prep['currentManifestSha256']
reviews_path = root/m['inputs']['reviews']['path']; reviews_before = reviews_path.read_bytes()
assert (len(load(reviews_path)['reviews']), len(m['reviewContexts']), len(m['acceptanceGates']), len(m['laterSourceDeltas'])) == (165, 80, 251, 7)
contexts = json.loads(gzip.decompress((w/'all-original80-contexts-before-macos-sigterm-refresh-v1.json.gz').read_bytes()))
assert contexts == m['reviewContexts']
paired = load(w/'local-connected-pair-sigterm-owner-terminal-v1.json')
assert paired['status'].startswith('PASS_') and paired['ownApiStopped'] and paired['ownPostgresSmartStopped']
assert paired['allOriginal345AuditSevenTablesExact'] and paired['allOther83NativeSevenTablesExact']
old_full_path = root/'var/qa/main-initial-snapshot-reconnect-race-20261022/ci267ab-entire-full-independent-verification-v1.json'
old_full = load(old_full_path)
assert (old_full['actualCases'], old_full['actualMethods'], old_full['sql']['caseCount']) == (13585, 7684, 59)
closure_path = native/'fixed68ba1-early-native-original-replay-and-open-sigterm-closure-v1.json'
closure = load(closure_path); assert closure['fixedCommit'] == base
full_path = native/'ci68ba1-entire-full-independent-verification-v1.json'
full = load(full_path) if full_path.exists() else None
if full:
    assert (full['actualCases'], full['actualMethods'], full['sql']['caseCount']) == (13598, 7691, 59)
    assert len(full['jobs']) == 11 and all(x == 'success' for x in full['jobs'].values())
ev = root/'docs/evidence/native-macos-sigterm-main-loop-2026-10-22'; ev.mkdir(exist_ok=False)
prior = w/'prior-publication-v1'; prior.mkdir(exist_ok=False)
for p in [mp, root/'docs/PROJECT_STATUS.md']:
    (prior/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(), mtime=0))
pub = load(native/'frozen-fixed68ba1-native-composition-v1.json')
runtime_roots = [Path(pub[k]) for k in ['apiRuntimeRoot', 'helperRuntimeRoot', 'networkRuntimeRoot']]
paths = sorted({p for folder in [w, native] for p in folder.rglob('*') if p.is_file()})
def excluded_path(p):
    return any(p.is_relative_to(folder) for folder in runtime_roots) or any(x in {'bin', 'obj', '__pycache__', 'native-current', '.godot'} or x.endswith('.app') for x in p.parts)
secrets = set()
def collect(v):
    if isinstance(v, dict):
        for k, item in v.items():
            if k.lower() in {'playerkey', 'reconnecttoken'} and isinstance(item, str) and len(item) >= 16: secrets.add(item.encode())
            else: collect(item)
    elif isinstance(v, list):
        for item in v: collect(item)
for p in paths:
    if excluded_path(p): continue
    if p.name.endswith(('.json', '.json.gz', '.ndjson', '.ndjson.gz')):
        try:
            raw = p.read_bytes(); raw = gzip.decompress(raw) if p.suffix == '.gz' else raw
            if '.ndjson' in p.name:
                for line in raw.decode().splitlines():
                    if line.strip(): collect(json.loads(line))
            else: collect(json.loads(raw))
        except (ValueError, OSError, UnicodeDecodeError): pass
canonical = {}; members = {}; rows = []; excluded = []
for p in paths:
    name = str(p.relative_to(root)); reason = None
    if excluded_path(p): reason = 'EXISTING_CURRENT_APP_SDK_DEPENDENCY_OR_GENERATED_BUILD_NOT_DUPLICATED'
    elif p.suffix == '.zip': reason = 'SINGLE_ORIGINAL_BACKEND_ZIP_LOCAL_ONLY_HASH_RECORDED'
    elif p.name.endswith(('.html', '.html.gz')): reason = 'PRIMARY_FULL_HTML_LOCAL_ONLY_METADATA_PUBLISHED'
    elif p.suffix == '.env' or any('profile' in x.lower() for x in p.parts) or p.name.startswith('session-'): reason = 'PRIVATE_QA_SESSION_LOCAL_ONLY'
    raw = p.read_bytes(); inspect = raw
    if p.suffix == '.gz':
        try: inspect = gzip.decompress(raw)
        except OSError: pass
    if any(secret in inspect for secret in secrets): reason = 'PRIVATE_SESSION_AUTH_VALUE_LOCAL_ONLY'
    digest = hashlib.sha256(raw).hexdigest()
    if reason:
        excluded.append({'path': name, 'bytes': len(raw), 'sha256': digest, 'reason': reason}); continue
    member = canonical.get(digest)
    if member is None: canonical[digest] = name; member = name; members[member] = p
    rows.append({'path': name, 'bytes': len(raw), 'sha256': digest, 'archiveMember': member})
archive = ev/'original-execution-and-bounded-native-records.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=9) as tar:
    for name, p in sorted(members.items()):
        raw = p.read_bytes(); info = tarfile.TarInfo(name); info.size = len(raw); info.mtime = 0; tar.addfile(info, io.BytesIO(raw))
with tarfile.open(archive) as tar:
    assert set(tar.getnames()) == set(members)
    for row in rows:
        raw = tar.extractfile(row['archiveMember']).read(); assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
write(ev/'archive-map.json', {'atUtc': now(), 'archive': pin(archive), 'originalPathsWithExactCanonicalMember': rows, 'localOnlyExclusions': excluded, 'allMemberBytesHashesAndClosedSetVerified': True, 'equalPayloadsStoredOnlyOnce': True, 'noInstallerSdkDependencyProfileOrFullHtmlCopies': True})
copies = {
    'final-original-test-and-input-retention.json': w/'final-sole-check-original-retention-and-native-exit-v1.json',
    'local-connected-pair-real-postgres-cold-restore-and-sigterm.json': w/'local-connected-pair-sigterm-owner-terminal-v1.json',
    'local-exported-main-natural-and-sigterm.json': w/'local-exported-main-sigterm-candidate-v1.json',
    'original-fixed68-exported-main-regression-red.json': w/'original-exported-main-sigterm-regression-red-v2.json',
    'primary-runtime-software-source-readback.json': w/'primary-runtime-and-engine-exit-source-manifest-v1.json',
    'preceding-fixed267ab-complete-full.json': old_full_path,
    'preceding-fixed68ba1-native-normal-score-original-replay-and-open-sigterm.json': closure_path,
    'original80-complete-contexts-before-refresh.json.gz': w/'all-original80-contexts-before-macos-sigterm-refresh-v1.json.gz',
    'native-issue90-local-followup-receipt.json': w/'issue90-local-followup-receipt-v1.json'}
if full: copies['preceding-fixed68ba1-complete-full.json'] = full_path
for name, p in copies.items(): (ev/name).write_bytes(p.read_bytes())
implementation = [pin(root/'clients/godot/scripts/Main.cs', 'implementation')]
verification = [pin(root/'clients/godot/tools/ci-desktop.py', 'verification-source')]
source = {'schemaVersion': 1, 'id': 'native-macos-sigterm-main-loop-2026-10-22', 'atUtc': now(), 'scopeKind': 'NATIVE_MACOS_PROCESS_LIFECYCLE_ONLY_NOT_CARD_OR_CLAUSE_SEMANTIC_REVIEW',
          'region': 'CN', 'language': 'zh-CN', 'applicableAsOf': '2026-10-22', 'adoptedCoreEffectiveDate': '2026-10-16',
          'baseCommit': base, 'issue': 'https://github.com/DDDHL0704/riftbound/issues/90', 'implementation': implementation, 'verificationSources': verification,
          'existingOfficialGameSourceManifest': old['currentNativeInitialSnapshotReconnectInputChange']['sourceManifest'],
          'gameCardRuleFaqSourceDatesUniverseAndSevenDeltasRetained': True, 'newGameSourceVersionOrRuntimeCatalogAdopted': False,
          'softwarePrimaryDocumentation': pin(ev/'primary-runtime-software-source-readback.json'),
          'originalRealMainFailure': pin(ev/'original-fixed68-exported-main-regression-red.json'),
          'localStandaloneNaturalAndSigterm': pin(ev/'local-exported-main-natural-and-sigterm.json'),
          'localConnectedRealPgPair': pin(ev/'local-connected-pair-real-postgres-cold-restore-and-sigterm.json'),
          'finalSoleCheck': pin(ev/'final-original-test-and-input-retention.json'),
          'precedingFixed267abCompleteFull': pin(ev/'preceding-fixed267ab-complete-full.json'),
          'precedingFixed68ba1BoundedNative': pin(ev/'preceding-fixed68ba1-native-normal-score-original-replay-and-open-sigterm.json'),
          'currentFixedFullExpectedCases': 13598, 'currentFixedFullExpectedMethods': 7691, 'currentFixedSqlCases': 59,
          'noNewConformanceMethodsCasesOrDeletedTheoryRows': True, 'newExportedMacosSigtermIntegrationGate': True,
          'originalCheckControllerInterruptedNotRelabeledNormalExit': True,
          'oneOriginalTestProcessKernelExitZeroAndOriginalReportVerifyPostvalidationResumed': True,
          'missingOriginalToolSummaryNotFabricatedAndNoSecondCheck': True,
          'newFixedFullActualCiNativeVisibleAndPhysicalWindows': 'OPEN', 'all165Reviews80ContextIdentities251GatesSevenDeltas17182ObligationsRetained': True,
          'expectedRemainingObligations': 17183, 'all1740Printings14293Rules705OutsideEightEnglishGap139CnNewsAndKdaGatesRemain': True,
          'archive': pin(archive), 'archiveMap': pin(ev/'archive-map.json'), 'semanticCoverageCertified': False}
if full: source['precedingFixed68ba1CompleteFull'] = pin(ev/'preceding-fixed68ba1-complete-full.json')
write(ev/'source-manifest.json', source); sp = pin(ev/'source-manifest.json', 'source-manifest')
refresh = []
for identity, context in m['reviewContexts'].items():
    changes = []
    for ref in context['implementation']:
        digest = sha(root/ref['path'])
        if digest != ref['sha256']:
            assert ref['path'] == 'clients/godot/scripts/Main.cs'; changes.append({'path': ref['path'], 'before': ref['sha256'], 'after': digest}); ref['sha256'] = digest
    if changes:
        refresh.append({'id': identity, 'changes': changes, 'oldCompleteContext': old['reviewContexts'][identity]})
        context.update(currentImplementationCommit=base, currentImplementationIncludesUncommittedChanges=True, ciState='PENDING', currentMacosSigtermMainLoopInputRefresh={'sourceManifest': sp, 'onlyCurrentImplementationPinRefreshNotSemanticCertification': True, 'newFixedFullRequired': True})
assert len(refresh) == 4
for identity, context in m['reviewContexts'].items():
    assert context.get('verificationSources') == old['reviewContexts'][identity].get('verificationSources')
    assert ('verificationSources' in context) == ('verificationSources' in old['reviewContexts'][identity])
    if identity not in {r['id'] for r in refresh}: assert context == old['reviewContexts'][identity]
(ev/'four-main-input-refreshes-with-complete-old-contexts.json.gz').write_bytes(gzip.compress(json.dumps(refresh, ensure_ascii=False, indent=2).encode(), mtime=0))
m['acceptanceGates'].append({'id': 'NATIVE_MACOS_SIGTERM_MAIN_LOOP_EXIT', 'state': 'OPEN', 'region': 'CN', 'language': 'zh-CN', 'sourceManifest': sp,
    'issue': 'https://github.com/DDDHL0704/riftbound/issues/90', 'requirement': 'After default Main is ready, route macOS SIGTERM through the Godot main loop. Verify real exported runtime standalone and connected paired cold restore, complete logs and clean exit; preserve original accepted history. New fixed full and actual CI export, visible controls, paired windows and physical Windows remain separate.',
    'semanticReview': 'CLIENT_PROCESS_LIFECYCLE_ONLY_NO_NEW_CARD_OR_CLAUSE_CERTIFICATION', 'implementation': implementation, 'verificationSources': verification,
    'testExecution': {'actualOriginalExportedMainSigtermExit': -6, 'localExportedNaturalAndSigtermClean': True, 'localPairedRealPgColdRestoreAndBothSigtermClean': True, 'focusCases': 668, 'focusMethods': 380, 'onlyCheckCases': 13449, 'onlyCheckMethods': 7550, 'oldExactCaseNameMultisetAndAllAssertionsRetained': True},
    'fixedCommitCi': 'PENDING_NEW_FIXED_FULL', 'productAcceptance': 'OPEN_NEW_FIXED_CI_NATIVE_VISIBLE_AND_WINDOWS', 'wholePrintingCertified': False})
assert m['acceptanceGates'][:251] == old['acceptanceGates'] and m['laterSourceDeltas'] == old['laterSourceDeltas'] and m['certificationScope'] == old['certificationScope'] and reviews_path.read_bytes() == reviews_before
m['currentMacosSigtermMainLoopInputChange'] = {'sourceManifest': sp, 'auditDocument': 'docs/NATIVE_MACOS_SIGTERM_MAIN_LOOP_AUDIT_2026-10-22.md', 'onlyOneNewProductGateNoNewSemanticReview': True, 'all165OldReviews80ContextIdentities251GatesSevenDeltasAnd17182ObligationsRetained': True, 'fourMainImplementationPinRefreshes76WholeContextsExact': True, 'expectedRemainingObligations': 17183, 'newFixedFullActualCiNativeVisibleAndPhysicalWindows': 'OPEN', 'wholePrintingOrGoalComplete': False}
m['precedingFixed267abActualCompleteFullCiReadback'] = pin(ev/'preceding-fixed267ab-complete-full.json')
m['precedingFixed68ba1BoundedNativeMainAndOriginalHistoryReplay'] = pin(ev/'preceding-fixed68ba1-native-normal-score-original-replay-and-open-sigterm.json')
if full: m['precedingFixed68ba1ActualCompleteFullCiReadback'] = pin(ev/'preceding-fixed68ba1-complete-full.json')
assert (len(m['reviewContexts']), len(m['acceptanceGates']), len(m['laterSourceDeltas'])) == (80, 252, 7)
mp.write_text(json.dumps(m, ensure_ascii=False, indent=2)+'\n')
write(ev/'publication-original-governance-retention.json', {'atUtc': now(), 'oldReviews': 165, 'oldContexts': 80, 'oldGates': 251, 'oldSourceDeltas': 7, 'oldRemainingIds': 17182, 'onlyOneNewProductGate': True, 'noNewSemanticReviewOrBehaviorCaseCount': True, 'fourCompleteOldContextsArchived76WholeObjectsExact': True, 'allOldOptionalVerificationSourcesPresenceAndValuesExact': True, 'allOldReviewsGatesDeltasCertificationScopeExact': True, 'expectedRemainingObligations': 17183, 'semanticCoverageCertified': False})
full_sentence = '前固定68ba1完整CI39729791774实际11项success，独立13598/7691及59SQL；原13585/7684精确加13/7，143完整151例、110配对十一牌组424242和网络15拒绝零泄露完整。' if full else '前固定68ba1完整CI39729791774仍待实际整次终态；子任务成功不代替完整通过。'
document = '''# macOS终止信号交回原生主循环的限定修复

本批仅修复macOS客户端进程生命周期，CN/zh-CN验收轮次为2026-10-22，既有10-16核心、全部来源日期与全量范围保留。没有新增卡牌或条款语义审查。[精确来源与输入](evidence/native-macos-sigterm-main-loop-2026-10-22/source-manifest.json)包含执行原件、软件来源与每项哈希。Goal active / NOT READY。

[#90](https://github.com/DDDHL0704/riftbound/issues/90)的原固定68ba1实际CI默认Main，在无API、无数据库、无对局时SIGTERM仍exit -6，出现StringName和mutex错误。相同SDK/模板的有效最小C#导出包不包含游戏代码，实际.NET8.0.28，自然退出0、SIGTERM后-6；SDK运行同一项目实际.NET10.0.13，自然退出0、SIGTERM为-15且无原生错误。这与Microsoft记录的.NET10默认信号处理变化一致，但不把底层原因唯一归给某段上游代码。最初无.sln的无托管导出包与选错QA启动器的工具失败完整保留，不作为有效产品对照。

修正只在macOS注册SIGTERM，回调取消默认终止并设置原子标记，由既有_Process主循环调用SceneTree.Quit，退出树时释放注册；不在信号线程调用Godot、断网或提交游戏动作。原关闭流程、GC、认证、历史及Windows行为不改。最小对照两运行环境、两退出方式共四项全部0且无ERROR。Main本地导出自然/SIGTERM与原符文控件生命周期通过；新增打包检查直接运行实际macOS导出默认Main，等待启动与目录、发送SIGTERM、排空PTY并拒绝彩色ERROR和非零退出。它对原固定68ba1实际红测-6，对新本地导出通过。

本地新Main双端在真实PostgreSQL恢复同一原Lab局，一次精确自有API冷故障后，同进程双方重新认证取得Joined/Snapshot/Prompt，再各自SIGTERM，全部0、完整日志排空无ERROR。原7指令24事件、状态、私有种子和EMPTY初态、五张历史表精确不变；345原审计及其他83原生局七表不变，API/PG停止。该应用明确是未提交本地候选，不等同新固定CI包或可见双窗。

原生Debug编译零警告零错误，定向668/380和74工具测试通过。唯一check的外层控制器因对话中断退出，原dotnet test/VSTest/testhost仍持续执行；接续使用macOS内核kqueue捕获同一原测试PID的真实正常退出0，随后实际执行未改动test-rules.py的report和verify，校验原计划7550方法及13449例全过零跳过。外层控制器退出码不可得、原工具summary缺失均明确保留，未补写伪造原summary、未重启第二次check。旧精确用例名多重集合与方法集合相同，无新增或移除Conformance测试。全部1804原测试文件、Theory、九完整源码、143完整方法151例、110配对十一牌组424242及胜利/回放断言保留。3344源/模式、1419Conformance与23原生Debug运行文件在开始、接续及终态稳定，实际四规则程序集路径/SHA/MVID和输入身份另记。59SQL执行身份/顺序/Program与15网络守卫源码逐字未变。本地check未声称执行全部143完整局，也无数据库连接；真实数据库证据单列。

'''+full_sentence+'''

前固定267ab整次11项成功独立13585/7684、59SQL；原Main冷重连错误仍保持失败。固定68ba1实际CI默认Main三次同进程冷重连、原Lab7/24及独立7/13/13；普通局正常8:0共93原输入588事件、独立93权威181快照181提示及全原回放；两网络局原15拒绝零泄露、双方无刷新无重试即tick2、独立3/4/4及全原回放均按原范围保留。原始中断、超时及SIGTERM失败不改写；一个旧独立读者的状态字符串仍带旧267标签，真实当前68提交/四加载程序集/5fe98规则身份单独实测，不能据标签说跑了旧引擎。这些证据不覆盖本批新固定候选、可见控件或Windows实机。

保留165审查、80上下文身份、251旧门禁、七增量与17182旧义务；四Main绑定显式刷新待新full，76上下文整对象及全部旧可选验证引用原样，完整旧对象归档。只新增一个进程生命周期产品门禁至252/17183，semanticCoverageCertified=false。1740印次14293规则、705目录外、八英文、139中文新闻与K/DA门禁全部保留。两最小程序临时应用/ZIP与482份构建缓存176353596逻辑字节、已完成本地重复ZIP142475878字节按用途和哈希清理，原源码/实际自有程序集/失败/来源/库保留；只留当前可用双端、每平台一包及必要的待固定CI替换测试应用，不推定APFS物理回收。

新固定full预期13598/7691、59SQL并包括新增实际导出SIGTERM门禁；新固定CI默认Main双端、正常得分与全原回放、可见控件/双窗和Windows实机分别OPEN。锁屏继续后台审计，不要求解锁，不把无界面证据升级为可见验收。只有全量来源、行为、测试和全部必要产品义务闭合才可完成Goal。
'''
(root/'docs/NATIVE_MACOS_SIGTERM_MAIN_LOOP_AUDIT_2026-10-22.md').write_text(document)
status_path = root/'docs/PROJECT_STATUS.md'; before_status = gzip.decompress((prior/'PROJECT_STATUS.md.gz').read_bytes()).decode(); heading = '# 当前项目状态\n\n'; assert before_status.startswith(heading)
status = '2026-10-22 本批：[macOS终止信号与主循环退出](NATIVE_MACOS_SIGTERM_MAIN_LOOP_AUDIT_2026-10-22.md)。原固定68ba1真实导出与无游戏最小.NET8包SIGTERM均-6，SDK实际.NET10为-15；源与宿主差异分别记录，#90保持打开。只在macOS捕获SIGTERM并由既有主循环正常退出；实际导出回归先原版本红测，再本地修复通过，自然退出/符文生命周期通过。真实PG本地双端同进程冷恢复后均SIGTERM正常，原7/24、种子初态五历史表及345审计/其他83原生七表不变，API/库停止。\n\n定向668/380、74工具、原生零警告错误；唯一check13449/7550精确原用例集合全过，1804原文件九完整143/151/110/11/424242与断言保留，3344/1419/23稳定。59SQL与原15网络源码不变。'+full_sentence+'前267完整13585/7684、59SQL和固定68原生普通93/588正常8:0/独立93/181/181、Lab7/24/独立7/13/13、网络3/4/4及原完整回放限定保留；原中断和SIGTERM失败不回填。\n\n原165审查80上下文251门禁七增量17182义务完整；四Main显式待新full、76整对象原样，只加一个产品门禁至252/17183，语义false，全1740/14293/705/八英文/139新闻/KDA范围不减。清理完成最小对照缓存与重复ZIP，保留最新双端/每平台一包及必要测试应用。新固定full/CI原生、可见双窗、Windows和全量Goal OPEN / NOT READY。\n\n以下原批按原范围与当时终态保留。\n\n'
status_path.write_text(heading+status+before_status[len(heading):])
print('PUBLISHED bounded macOS lifecycle;165reviews80contexts252gates7deltas;17182oldIDs+onegate expected17183;fourMainpins76wholecontexts;independentgovernance pending', flush=True)
