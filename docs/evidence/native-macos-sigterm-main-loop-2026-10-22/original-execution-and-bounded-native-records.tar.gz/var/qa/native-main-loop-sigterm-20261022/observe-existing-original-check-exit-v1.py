from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
import select
import subprocess
import time

root = Path('/Users/dinghaolin/MyProjects/riftbound'); qa = Path(__file__).resolve().parent
now = lambda: datetime.now(timezone.utc).isoformat()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
start_path = qa/'sole-check-start-inputs-v1.json.gz'
start = json.loads(gzip.decompress(start_path.read_bytes()))
parent = 76527
targets = [parent, 76528, 76530]
raw = {}
for pid in targets:
    raw[str(pid)] = subprocess.check_output(['ps', '-p', str(pid), '-o', 'pid=,ppid=,lstart=,stat=,command='], text=True).strip()
assert 'dotnet test ' in raw[str(parent)] and str(qa/'sole-check-v1/check') in raw[str(parent)]
assert 'vstest.console.dll' in raw['76528'] and 'testhost.dll' in raw['76530']
assert all(sha(root/p) == v['sha256'] for p, v in start['all3344SourceHashesAndModes'].items())
assert all(sha(root/p) == h for group in start['actualRuntimeInputs'].values() for p, h in group.items())
kernel = select.kqueue()
# Native SDK sys/event.h: NOTE_EXITSTATUS is valid for a child or a process we may signal.
NOTE_EXITSTATUS = 0x04000000
for pid in targets:
    os.kill(pid, 0)
    event = select.kevent(pid, filter=select.KQ_FILTER_PROC, flags=select.KQ_EV_ADD | select.KQ_EV_ENABLE | select.KQ_EV_ONESHOT,
                         fflags=select.KQ_NOTE_EXIT | NOTE_EXITSTATUS)
    kernel.control([event], 0, 0)
receipt = {'startedAtUtc': now(), 'status': 'ATTACHED_TO_ORIGINAL_LIVE_CHECK_TEST_CHAIN_NO_RESTART',
           'ownObserverPid': os.getpid(), 'originalDotnetTestPid': parent, 'originalLiveProcesses': raw,
           'originalStartManifestSha256': sha(start_path), 'originalPlanSha256': sha(qa/'sole-check-v1/plan.json'),
           'originalControllerWasInterruptedDuringTurnAbort': True, 'originalControllerExitStatusUnavailableNotAssumedZero': True,
           'originalTestRulesToolSummaryMissingUntilExplicitRecoveredVerification': True,
           'noBuildTestOrGameplayCommandRestarted': True, 'sourceAndRuntimeExactAtObserverAttach': True,
           'noteExitStatusConstant': NOTE_EXITSTATUS, 'kernelEvents': []}
attachment = qa/'original-live-check-exit-observer-attachment-v1.json'
with attachment.open('x') as f: json.dump(receipt, f, indent=2)
print('ATTACHED_ORIGINAL_DOTNET_TEST76527_VSTEST76528_TESTHOST76530_WITH_MACOS_KERNEL_EXIT_STATUS', flush=True)
power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())])
deadline = time.monotonic() + 10800
try:
    while not any(e['pid'] == parent for e in receipt['kernelEvents']):
        assert time.monotonic() < deadline, 'Observation deadline; never kill or restart the original test process'
        for event in kernel.control(None, 3, 30):
            record = {'pid': int(event.ident), 'filter': int(event.filter), 'flags': int(event.flags), 'fflags': int(event.fflags),
                      'rawWaitStatus': int(event.data), 'atUtc': now()}
            assert event.filter == select.KQ_FILTER_PROC and event.fflags & select.KQ_NOTE_EXIT
            receipt['kernelEvents'].append(record)
            print(json.dumps(record), flush=True)
    original = next(e for e in receipt['kernelEvents'] if e['pid'] == parent)
    status = original['rawWaitStatus']
    receipt.update(status='ORIGINAL_CHECK_DOTNET_TEST_EXIT_CAPTURED_FROM_KERNEL_NOT_RERUN',
                   originalExitedNormally=os.WIFEXITED(status), originalExitCode=os.WEXITSTATUS(status) if os.WIFEXITED(status) else None,
                   originalTermSignal=os.WTERMSIG(status) if os.WIFSIGNALED(status) else None)
except BaseException as ex:
    receipt.update(status='ORIGINAL_CHECK_OBSERVATION_FAILED_NOT_A_TEST_RESTART_OR_PASS', errorType=type(ex).__name__, error=str(ex)); raise
finally:
    receipt.update(finishedAtUtc=now(), all3344SourcesAndModesStable=all(sha(root/p) == v['sha256'] and oct((root/p).stat().st_mode & 0o777) == v['mode'] for p, v in start['all3344SourceHashesAndModes'].items()),
                   all1804OriginalConformanceFilesStable=all(sha(root/p) == v['sha256'] and oct((root/p).stat().st_mode & 0o777) == v['mode'] for p, v in start['all1804OriginalConformanceFilesIncludingTheoryAndNineFullSources'].items()),
                   all1419ConformanceAnd23NativeRuntimeInputsStable=all(sha(root/p) == h for group in start['actualRuntimeInputs'].values() for p, h in group.items()))
    kernel.close()
    if power.poll() is None: power.terminate(); power.wait(timeout=10)
    with (qa/'original-live-check-exit-observer-terminal-v1.json').open('x') as f: json.dump(receipt, f, indent=2)
print(receipt['status'], flush=True)
