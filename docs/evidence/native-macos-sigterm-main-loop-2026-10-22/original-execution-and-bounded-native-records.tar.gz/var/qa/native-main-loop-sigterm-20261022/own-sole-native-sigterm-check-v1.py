from pathlib import Path
from datetime import datetime, timezone
import collections
import gzip
import hashlib
import json
import os
import resource
import subprocess
import xml.etree.ElementTree as ET

resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
root = Path('/Users/dinghaolin/MyProjects/riftbound')
qa = Path(__file__).resolve().parent
prior = root/'var/qa/main-initial-snapshot-reconnect-race-20261022'
base = '68ba1c5b63f52266323928da85bd75060e7e8fee'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.now(timezone.utc).isoformat()
load = lambda p: json.loads(p.read_text())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == base
baseline = load(prior/'only-check-start-inputs-v1.json')
changed = {p for p, h in baseline['sourceInputHashes'].items() if sha(root/p) != h}
assert changed == {'clients/godot/scripts/Main.cs', 'clients/godot/tools/ci-desktop.py'}
assert set(subprocess.check_output(['git', 'diff', '--name-only'], cwd=root, text=True).splitlines()) == changed
source = {p: {'sha256': sha(root/p), 'mode': oct((root/p).stat().st_mode & 0o777)} for p in baseline['sourceInputHashes']}
assert len(source) == 3344
test_files = subprocess.check_output(['git', 'ls-files', '-z', '--', 'tests/Riftbound.ConformanceTests'], cwd=root).decode().rstrip('\0').split('\0')
assert len(test_files) == 1804
tests = {p: {'sha256': sha(root/p), 'mode': oct((root/p).stat().st_mode & 0o777)} for p in test_files}
assert len([p for p in test_files if Path(p).name.startswith('FullGameEndToEndTests') and p.endswith('.cs')]) == 9
subprocess.run(['git', 'diff', '--exit-code', base, '--', 'tests', 'src', 'data/official'], cwd=root, check=True, stdout=subprocess.DEVNULL)
focus = qa/'native-hub-identity-focus-v1'
assert load(focus/'summary.json')['status'] == 'PASSED' and load(focus/'summary.json')['total'] == 668
plan = load(focus/'plan.json')
assert plan['discoveredMethods'] == 7691 and sum(len(s['methods']) for s in plan['shards']) == 380
native = load(qa/'local-exported-main-sigterm-candidate-v1.json')
assert native['status'].startswith('LOCAL_MACOS_EXPORTED_MAIN_SIGTERM_AND_NATURAL_CLEAN')
assert 'Ran 74 tests' in (qa/'tooling-tests-v1.log').read_text() and (qa/'tooling-tests-v1.log').read_text().rstrip().endswith('OK')
runtime = {}
for label, folder in [('Conformance', root/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0'), ('Native', root/'clients/godot/.godot/mono/temp/bin/Debug')]:
    runtime[label] = {str(p.relative_to(root)): sha(p) for p in folder.rglob('*') if p.is_file() and not str(p.relative_to(root)).startswith(baseline['excludedGeneratedOutputDirectory']+'/')}
assert len(runtime['Conformance']) == 1419 and len(runtime['Native']) == 23
conformance = root/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0'
probe = root/'var/qa/fixed267ab-early-native-20261022/executed-own-native-readers-and-drivers-v1/IndependentFixed267abControlledLabV1.dll'
actual = json.loads(subprocess.check_output([str(Path.home()/'.dotnet/dotnet'), 'exec', '--depsfile', str(conformance/'Riftbound.ConformanceTests.deps.json'), '--runtimeconfig', str(conformance/'Riftbound.ConformanceTests.runtimeconfig.json'), str(probe), '--loaded-inputs'], cwd=conformance, env=dict(os.environ, DOTNET_DbgEnableMiniDump='0')))
assert Path(actual['baseDirectory']) == conformance and len(actual['assemblies']) == 4
for a in actual['assemblies']:
    assert Path(a['path']) == conformance/(a['name']+'.dll') and a['sha256'] == runtime['Conformance'][str(Path(a['path']).relative_to(root))] and a['mvid']
start = {'atUtc': now(), 'baseCommit': base, 'onlyChangedPaths': sorted(changed), 'all3344SourceHashesAndModes': source,
         'all1804OriginalConformanceFilesIncludingTheoryAndNineFullSources': tests, 'actualRuntimeInputs': runtime,
         'actualFourLoadedAssembliesAndRuleInputs': actual, 'expectedCases': 13449, 'expectedMethods': 7550,
         'originalBaselineTrx': str((prior/'only-check-v1/check/results.trx').relative_to(root)),
         'originalBaselineTrxSha256': sha(prior/'only-check-v1/check/results.trx'), 'focus668Cases380Methods': True,
         'soleCheckNoDatabaseConnection': True, 'naturalAndSigtermNativeIntegrationPassedSeparately': True,
         'doesNotClaimAll143FullGamesExecutedLocally': True, 'wholePrintingOrGoalCertified': False}
start_path = qa/'sole-check-start-inputs-v1.json.gz'
assert not start_path.exists()
start_path.write_bytes(gzip.compress(json.dumps(start, indent=2).encode(), mtime=0))
out = qa/'sole-check-v1'
assert not out.exists()
command = ['python3', 'scripts/test-rules.py', 'check', '--output', str(out)]
environment = dict(os.environ)
environment.pop('ConnectionStrings__Riftbound', None)
terminal = {'startedAtUtc': now(), 'baseCommit': base, 'command': command, 'startManifestSha256': sha(start_path)}
print('SOLE_CHECK_STARTED_EXPECT13449_CASES7550_METHODS_3344_SOURCES_1804_ORIGINAL_TEST_FILES_1419_CONFORMANCE_23_NATIVE', flush=True)
try:
    with (qa/'sole-check-console-v1.log').open('xb') as log:
        child = subprocess.Popen(command, cwd=root, stdout=log, stderr=subprocess.STDOUT, env=environment)
        power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(child.pid)])
        terminal['exitCode'] = child.wait()
        power.wait(timeout=10)
finally:
    terminal.update(finishedAtUtc=now(), all3344SourcesAndModesStable=all(sha(root/p) == v['sha256'] and oct((root/p).stat().st_mode & 0o777) == v['mode'] for p, v in source.items()),
                    all1804OriginalConformanceFilesStable=all(sha(root/p) == v['sha256'] and oct((root/p).stat().st_mode & 0o777) == v['mode'] for p, v in tests.items()),
                    all1419ConformanceAnd23NativeRuntimeInputsStable=all(sha(root/p) == h for group in runtime.values() for p, h in group.items()))
    with (qa/'sole-check-owner-terminal-v1.json').open('x') as f:
        json.dump(terminal, f, indent=2)
print(json.dumps(terminal), flush=True)
assert terminal['exitCode'] == 0 and all(terminal[k] for k in ['all3344SourcesAndModesStable', 'all1804OriginalConformanceFilesStable', 'all1419ConformanceAnd23NativeRuntimeInputsStable'])
