from pathlib import Path
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
import plistlib
import subprocess
import zipfile

root = Path('/Users/dinghaolin/MyProjects/riftbound')
qa = Path(__file__).resolve().parent
project = root / 'clients/godot'
sdk = Path.home() / '.local/share/riftbound-tools/godot-4.7.2/Godot_mono.app/Contents/MacOS/Godot'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
spec = importlib.util.spec_from_file_location('desktop_gate', project / 'tools/ci-desktop.py')
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
os.environ['PATH'] = str(Path.home() / '.dotnet') + os.pathsep + os.environ['PATH']
os.environ.pop('DOTNET_STARTUP_HOOKS', None)
inputs = {str(p.relative_to(root)): sha(p) for p in [project/'scripts/Main.cs', project/'tools/ci-desktop.py', project/'project.godot', project/'export_presets.cfg']}
package = qa / 'temporary-local-candidate-macos-v1.zip'
assert not package.exists()
receipt = {'startedAtUtc': datetime.now(timezone.utc).isoformat(), 'status': 'RUNNING', 'sourceInputs': inputs,
           'sdk': str(sdk), 'sdkSha256': sha(sdk), 'newSdkTemplateWorktreeOrDatabaseCreated': False}
try:
    with gate.packaging_without_editor_plugins(project):
        gate.run([sdk, '--headless', '--editor', '--path', project, '--import'], qa/'candidate-import-v1.log', timeout=180)
        life = gate.run([sdk, '--headless', '--path', project, 'res://scenes/debug/RuneTableLifecycleProof.tscn'], qa/'candidate-rune-table-lifecycle-v1.log', timeout=90)
        assert 'RUNE_TABLE_LIFECYCLE_PASS: 2 freed-control transitions, 4 native signals' in life
        exported = gate.run([sdk, '--headless', '--path', project, '--export-release', 'macOS', package], qa/'candidate-export-release-v1.log', timeout=240)
        assert 'ERROR:' not in exported
    assert inputs == {str(p.relative_to(root)): sha(p) for p in [root/p for p in inputs]}
    with zipfile.ZipFile(package) as z:
        assert z.testzip() is None
        assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in z.namelist())
    unpacked = qa/'temporary-local-candidate-macos-v1'
    subprocess.run(['ditto', '-xk', str(package), str(unpacked)], check=True)
    apps = list(unpacked.glob('*.app'))
    assert len(apps) == 1
    app = apps[0]
    info = plistlib.loads((app/'Contents/Info.plist').read_bytes())
    executable = app/'Contents/MacOS'/info['CFBundleExecutable']
    assert executable.is_file()
    subprocess.run(['codesign', '--verify', '--deep', '--strict', str(app)], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    gate.verify_macos_sigterm_shutdown(executable, qa/'candidate-exported-main-sigterm-v1.log', qa)
    boot = gate.run([executable, '--headless', '--max-fps', '60', '--quit-after', '120', '--', '--riftbound-ephemeral-session', '--riftbound-server=http://127.0.0.1:1'], qa/'candidate-exported-main-natural-v1.log', timeout=45, cwd=qa)
    assert 'Client booted.' in boot and 'Official catalog loaded: 1035 cards.' in boot and 'ERROR:' not in boot
    assert inputs == {str(p.relative_to(root)): sha(p) for p in [root/p for p in inputs]}
    receipt.update(status='LOCAL_MACOS_EXPORTED_MAIN_SIGTERM_AND_NATURAL_CLEAN_LIFECYCLE_PASS_NOT_FIXED_CI_OR_VISIBLE_ACCEPTANCE',
                   app=str(app), executable=str(executable), archive=str(package), archiveSha256=sha(package),
                   allArchiveCrcVerified=True, strictCodeSignatureVerified=True,
                   appFiles={str(p.relative_to(app)): sha(p) for p in app.rglob('*') if p.is_file()})
except BaseException as ex:
    receipt.update(status='LOCAL_NATIVE_CANDIDATE_OBSERVATION_FAILED', errorType=type(ex).__name__, error=str(ex))
    raise
finally:
    receipt['finishedAtUtc'] = datetime.now(timezone.utc).isoformat()
    receipt['originalProjectConfigExactlyRestored'] = inputs['clients/godot/project.godot'] == sha(project/'project.godot')
    (qa/'local-exported-main-sigterm-candidate-v1.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2)+'\n')
print(receipt['status'], flush=True)
