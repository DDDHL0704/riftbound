from pathlib import Path
from urllib.request import Request, urlopen
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor
import gzip
import hashlib
import importlib.util
import json

Q = Path(__file__).resolve().parent
TOOL = Path('/Users/dinghaolin/MyProjects/.worktrees/riftbound-parallel-official-audit-20261023/scripts/audit/gallery_gap_diagnostics.py')
spec = importlib.util.spec_from_file_location('gap', TOOL)
gap = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gap)
BASE = 'https://content.publishing.riotgames.com/publishing-content/v2.0/public/channel/riftbound_website/list/riftbound_gallery_cards?locale=en_US'
NOW = lambda: datetime.now(timezone.utc).isoformat()
budget = 49
attempts = []


def acquire(window):
    start, limit = window
    label = f'window-{start:04}-{limit:04}'
    existing = Q / (label + '.json.gz')
    if existing.exists():
        return json.loads(gzip.decompress(existing.read_bytes()))
    url = f'{BASE}&limit={limit}&from={start}'
    record = dict(url=url, startedAtUtc=NOW())
    try:
        with urlopen(Request(url, headers={'User-Agent': 'Mozilla/5.0 Riftbound source audit'}), timeout=25) as r:
            raw = r.read()
            record.update(httpStatus=r.status, resolvedUrl=r.url,
                          responseHeaders={k: v for k, v in r.headers.items() if k.lower() in
                                           ('date', 'content-type', 'x-riot-mapper-version')})
        record.update(receivedAtUtc=NOW(), rawSha256=hashlib.sha256(raw).hexdigest(), rawBytes=len(raw))
        existing.write_bytes(gzip.compress(raw, mtime=0))
        record.update(archivePath=existing.name, archiveSha256=hashlib.sha256(existing.read_bytes()).hexdigest())
        data = json.loads(raw)
        assert (data['metadata']['from'], data['metadata']['limit']) == window
        record.update(metadata=data['metadata'], returnedRows=len(data['data']))
    except Exception as e:
        record.update(failedAtUtc=NOW(), error=type(e).__name__ + ': ' + str(e))
        data = None
    receipt = Q / (label + '.continuation-receipt.json')
    with receipt.open('x') as stream:
        json.dump(record, stream, indent=2)
    attempts.append(record)
    return data


parent = json.loads(gzip.decompress((Q / 'whole-list.gz').read_bytes()))
pages = [acquire((n, 200)) for n in range(0, parent['metadata']['totalItems'], 200)]
assert all(p is not None for p in pages), 'Original page acquisition remains incomplete'
partition = gap.diagnose_partition(parent, pages)
checks = [dict(parent=(0, 2000), result=partition)]
pending = [p for p in pages if gap.inspect_window(p)['unreturnedRowCount']]
empty_positions = []
unstable = []
if not partition['supportsStableWindowObservation']:
    unstable.append(checks[0])
    pending = []

with ThreadPoolExecutor(max_workers=2) as pool:
    while pending and len(attempts) < budget and not unstable:
        current = pending.pop(0)
        summary = gap.inspect_window(current)
        start, size = summary['offset'], summary['capacity']
        if size == 1:
            empty_positions.append(start)
            continue
        half = size // 2
        windows = [(start, half), (start + half, size - half)]
        if len(attempts) + len(windows) > budget:
            pending.insert(0, current)
            break
        children = list(pool.map(acquire, windows))
        if any(child is None for child in children):
            pending.insert(0, current)
            break
        checked = gap.diagnose_partition(current, children)
        entry = dict(parent=(start, size), result=checked)
        checks.append(entry)
        print(start, size, summary['unreturnedRowCount'], checked['interpretation'], flush=True)
        if not checked['supportsStableWindowObservation']:
            unstable.append(entry)
            break
        pending.extend(child for child in children if gap.inspect_window(child)['unreturnedRowCount'])

report = dict(atUtc=NOW(), status='BOUNDED_OBSERVATION_ONLY_NOT_SOURCE_GAP_CLOSURE',
              toolSha256=hashlib.sha256(TOOL.read_bytes()).hexdigest(),
              newRequestCount=len(attempts), requestBudget=budget,
              checks=checks, emptySingletonOffsets=empty_positions, unstablePartitions=unstable,
              remainingWindows=[gap.inspect_window(p) for p in pending], attempts=attempts,
              sourceGapClosed=False, missingPrintingIdentities=None,
              providerRootCause='UNKNOWN', semanticCoverageCertified=False)
with (Q / 'bounded-sparse-continuation.json').open('x') as stream:
    json.dump(report, stream, indent=2)
print(json.dumps({k: report[k] for k in ['newRequestCount', 'emptySingletonOffsets', 'sourceGapClosed']}), flush=True)
