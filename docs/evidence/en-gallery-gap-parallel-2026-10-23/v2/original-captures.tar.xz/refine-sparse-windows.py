"""Bounded public-source observations; empty positions do not identify cards."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen
import gzip
import hashlib
import importlib.util
import json

Q = Path(__file__).resolve().parent
OLD = Q.parent
TOOL = Path('/Users/dinghaolin/MyProjects/.worktrees/riftbound-parallel-official-audit-20261023/scripts/audit/gallery_gap_diagnostics.py')
spec = importlib.util.spec_from_file_location('gap', TOOL)
gap = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gap)
BASE = 'https://content.publishing.riotgames.com/publishing-content/v2.0/public/channel/riftbound_website/list/riftbound_gallery_cards?locale=en_US'
NOW = lambda: datetime.now(timezone.utc).isoformat()
LIMIT = 64
attempts, checks, changes, leaves = [], [], [], []
stop = []


def acquire(window, phase='refine'):
    start, limit = window
    label = f'{phase}-{start:04}-{limit:04}'
    receipt = Q / (label + '.receipt.json')
    if receipt.exists():
        raise RuntimeError('Refusing to replace an existing observation: ' + label)
    url = f'{BASE}&limit={limit}&from={start}'
    record = dict(url=url, requestedFrom=start, requestedLimit=limit, startedAtUtc=NOW())
    data = None
    try:
        with urlopen(Request(url, headers={'User-Agent': 'Mozilla/5.0 Riftbound source audit'}), timeout=20) as response:
            raw = response.read()
            record.update(httpStatus=response.status, resolvedUrl=response.url,
                          responseHeaders={k: v for k, v in response.headers.items() if k.lower() in
                                           ('date', 'content-type', 'x-riot-mapper-version')})
        target = Q / (label + '.json.gz')
        packed = gzip.compress(raw, mtime=0)
        with target.open('xb') as stream:
            stream.write(packed)
        record.update(receivedAtUtc=NOW(), rawSha256=hashlib.sha256(raw).hexdigest(), rawBytes=len(raw),
                      archivePath=target.name, archiveSha256=hashlib.sha256(packed).hexdigest())
        candidate = json.loads(raw)
        assert (candidate['metadata']['from'], candidate['metadata']['limit']) == window
        record.update(summary=gap.inspect_window(candidate), metadata=candidate['metadata'])
        data = candidate
    except Exception as error:
        record.update(failedAtUtc=NOW(), error=type(error).__name__ + ': ' + str(error))
    with receipt.open('x') as stream:
        json.dump(record, stream, indent=2)
    attempts.append(record)
    return data


def diff(before, after):
    result = gap.compare_rows(before['data'], after['data'])
    result['orderedRowsEqual'] = gap.canonical(before['data']) == gap.canonical(after['data'])
    result['sameScopeAndTotal'] = all(before['metadata'][k] == after['metadata'][k]
                                    for k in gap.SCOPE_FIELDS + ('from', 'limit', 'totalItems'))
    return result


prior = json.loads((OLD / 'bounded-sparse-continuation.json').read_text())
windows = [(r['offset'], r['limit']) for r in prior['remainingWindows']]
with ThreadPoolExecutor(max_workers=2) as pool:
    parents = list(pool.map(lambda w: acquire(w, 'parent-before'), windows))
    pending = []
    for window, parent in zip(windows, parents):
        if parent is None:
            stop.append(dict(window=window, reason='PARENT_ACQUISITION_FAILED'))
            continue
        old = json.loads(gzip.decompress((OLD / f'window-{window[0]:04}-{window[1]:04}.json.gz').read_bytes()))
        observed = diff(old, parent)
        changes.append(dict(window=window, comparedWith='v1', result=observed))
        if not observed['orderedRowsEqual'] or not observed['sameScopeAndTotal']:
            stop.append(dict(window=window, reason='PARENT_CHANGED_SINCE_V1'))
        else:
            pending.append(parent)
    while pending and not stop:
        parent = pending.pop(0)
        summary = gap.inspect_window(parent)
        start, size = summary['offset'], summary['capacity']
        if size == 1:
            leaves.append(summary)
            continue
        if len(attempts) + 2 + len(windows) > LIMIT:
            pending.insert(0, parent)
            stop.append(dict(reason='REQUEST_BUDGET_EXHAUSTED'))
            break
        half = size // 2
        pairs = [(start, half), (start + half, size-half)]
        children = list(pool.map(acquire, pairs))
        if any(child is None for child in children):
            pending.insert(0, parent)
            stop.append(dict(window=(start, size), reason='CHILD_ACQUISITION_FAILED'))
            break
        result = gap.diagnose_partition(parent, children)
        checks.append(dict(window=(start, size), result=result))
        print(start, size, result['interpretation'], flush=True)
        if not result['supportsStableWindowObservation']:
            stop.append(dict(window=(start, size), reason='PARTITION_NOT_CONSERVED'))
            break
        pending.extend(child for child in children if gap.inspect_window(child)['unreturnedRowCount'])
    afters = list(pool.map(lambda w: acquire(w, 'parent-after'), windows))
    for window, before, after in zip(windows, parents, afters):
        if before is None or after is None:
            stop.append(dict(window=window, reason='SANDWICH_ACQUISITION_INCOMPLETE'))
            continue
        observed = diff(before, after)
        changes.append(dict(window=window, comparedWith='same-run-before', result=observed))
        if not observed['orderedRowsEqual'] or not observed['sameScopeAndTotal']:
            stop.append(dict(window=window, reason='PARENT_CHANGED_DURING_RUN'))

report = dict(schemaVersion=1, completedAtUtc=NOW(), status='BOUNDED_OBSERVATION_ONLY',
              requestBudget=LIMIT, requestCount=len(attempts), inputPriorReportSha256=hashlib.sha256(
                  (OLD / 'bounded-sparse-continuation.json').read_bytes()).hexdigest(),
              toolSha256=hashlib.sha256(TOOL.read_bytes()).hexdigest(),
              parentComparisons=changes, partitions=checks, emptySingletonObservations=leaves,
              remainingWindows=[gap.inspect_window(p) for p in pending], stops=stop,
              attempts=attempts, missingPrintingIdentities=None, providerRootCause='UNKNOWN',
              sourceGapClosed=False, semanticCoverageCertified=False,
              caveat='Offsets describe these response windows only, not stable card positions or missing printing identities.')
with (Q / 'singleton-refinement-report.json').open('x') as stream:
    json.dump(report, stream, indent=2)
print(json.dumps({k: report[k] for k in ['requestCount', 'emptySingletonObservations', 'stops', 'sourceGapClosed']}), flush=True)
