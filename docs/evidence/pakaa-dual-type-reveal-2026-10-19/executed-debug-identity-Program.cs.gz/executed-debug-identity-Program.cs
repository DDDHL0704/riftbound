using System.Reflection;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.Text.Json;

if (args.Length != 1) throw new Exception("Explicit frozen check runtime folder required.");
var folder = Path.GetFullPath(args[0]);
AssemblyLoadContext.Default.Resolving += (context, name) => {
    var path = Path.Combine(folder, name.Name + ".dll");
    return File.Exists(path) ? context.LoadFromAssemblyPath(path) : null;
};
var assembly = AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.Combine(folder, "Riftbound.Engine.dll"));
var type = assembly.GetType("Riftbound.Engine.RuleInputIdentity", throwOnError: true)!;
var identity = type.GetProperty("Current", BindingFlags.Public | BindingFlags.Static)!.GetValue(null)!;
var modules = new[] { "Riftbound.Contracts.dll", "Riftbound.CardCatalog.dll", "Riftbound.Engine.dll", "Riftbound.Persistence.dll", "Riftbound.Api.dll" }
    .ToDictionary(file => file, file => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(Path.Combine(folder, file)))).ToLowerInvariant());
Console.WriteLine(JsonSerializer.Serialize(new { actualRuleInputs = identity, actualModuleHashes = modules,
    loadedEnginePath = assembly.Location, currentCheckAssembliesLoadedReadOnly = true, rebuiltCheckOrGodotProject = false },
    new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true }));
