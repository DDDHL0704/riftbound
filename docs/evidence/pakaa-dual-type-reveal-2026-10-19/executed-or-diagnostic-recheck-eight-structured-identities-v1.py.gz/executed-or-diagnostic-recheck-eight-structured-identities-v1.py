import datetime
import gzip
import hashlib
import json
import re
import urllib.request
from pathlib import Path

n = Path(__file__).resolve().parent
r = n.parents[2]
sha = lambda value: hashlib.sha256(value).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
url = 'https://content.publishing.riotgames.com/publishing-content/v2.0/public/channel/riftbound_website/list/riftbound_gallery_cards?locale=en_US&limit=2000&from=0'
output = n / 'eight-structured-identity-readback-v1.json'
assert not output.exists()
record = {'startedAtUtc': now(), 'url': url, 'language': 'en-US', 'region': 'GLOBAL',
          'publicationDate': None, 'effectiveDate': None, 'status': 'RUNNING',
          'scope': 'One actual whole-list API response only. Earlier pagination/SSR receipts retained separately; neither fresh pagination nor fresh SSR claimed.'}
try:
    with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'RiftboundOfficialAudit/1.0'}), timeout=45) as response:
        raw = response.read(8 * 1024 * 1024 + 1)
        assert len(raw) <= 8 * 1024 * 1024
        record.update(httpStatus=response.status, resolvedUrl=response.url, httpDate=response.headers.get('Date'), lastModified=response.headers.get('Last-Modified'))
    path = n / 'actual-en-whole-list-v1.json.gz'
    assert not path.exists()
    path.write_bytes(gzip.compress(raw, mtime=0))
    record.update(receivedAtUtc=now(), rawSha256=sha(raw), path=str(path.relative_to(r)), gzipSha256=sha(path.read_bytes()))
    current = json.loads(raw)
    baseline_path = r / 'docs/evidence/source-reconfirmation-2026-10-17/gallery-api-full.json'
    baseline = json.loads(baseline_path.read_text())
    old = {row['id']: row for row in baseline['data']}
    rows = {row['id']: row for row in current['data']}
    assert len(rows) == len(current['data'])
    changes = [{'officialId': identity, 'before': old.get(identity), 'after': rows.get(identity)}
               for identity in sorted(old.keys() | rows.keys()) if old.get(identity) != rows.get(identity)]
    norm = lambda value: re.sub(r'[^A-Z0-9/]', '', value.upper())
    targets = ['RAD-110a/167'] + [f'RAD-R{i:02}b' for i in range(1, 7)] + ['RAD-T02']
    matches = [{'printedLookupCandidate': value, 'exactNormalizedPublicCodeMatches':
                [{'officialApiId': row['id'], 'publicCode': row['publicCode']} for row in rows.values() if norm(row['publicCode']) == norm(value)],
                'notAnInventedOfficialApiId': True, 'disposition': 'OPEN_SOURCE_MAPPING_REGION_EFFECTIVE_DATE_AND_SEMANTICS'} for value in targets]
    token_rows = [{'id': row['id'], 'publicCode': row['publicCode'], 'name': row['name']} for row in rows.values()
                  if re.fullmatch(r'[a-z]+-t\d+', row['id'])]
    known_rad = [row for row in rows.values() if row['id'].startswith('rad-') and
                 (re.fullmatch(r'rad-r0[1-6]a?', row['id']) or row['id'] == 'rad-110-167')]
    record.update(status='OBSERVED_CURRENT_STRUCTURED_ROW_IDENTITY_GAPS_NOT_RESOLVED',
                  baselinePath=str(baseline_path.relative_to(r)), baselineSha256=sha(baseline_path.read_bytes()),
                  reportedTotal=current['metadata']['totalItems'], exactReturnedRows=len(rows),
                  reportedButUnreturnedGap=current['metadata']['totalItems'] - len(rows),
                  exactUnchangedFullRows=sum(rows.get(key) == value for key, value in old.items()), rowChanges=changes,
                  printingLookups=matches, returnedTokenExamples=token_rows,
                  knownNearbyRadRows=known_rad,
                  conclusions={'notAllTokensExcludedFromTheReturnedApi': bool(token_rows),
                               'articleEightCandidatesNotEquatedWithUnreturnedEight': True,
                               'missingMappingsNotCertifiedNonexistentOrIneligible': True,
                               'sameNamesOrNearbyNumbersDoNotMergePhysicalPrintings': True,
                               'noNewRuntimeRowOrOfficialApiIdInvented': True},
                  semanticCoverageCertified=False, wholePrintingCertified=False)
except BaseException as error:
    record.update(status='FAILED_READBACK_PREFIX_RETAINED', errorType=type(error).__name__, errorMessage=str(error))
    raise
finally:
    record['finishedAtUtc'] = now()
    output.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({key: record[key] for key in ['status', 'reportedTotal', 'exactReturnedRows', 'reportedButUnreturnedGap', 'exactUnchangedFullRows']}), flush=True)
