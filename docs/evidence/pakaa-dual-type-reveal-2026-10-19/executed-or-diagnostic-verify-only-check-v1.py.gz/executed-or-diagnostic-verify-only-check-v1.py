import collections
import datetime
import gzip
import hashlib
import json
import os
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

n = Path(__file__).resolve().parent
r = n.parents[2]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
proof_path = n / 'only-check-verification-v1.json'
assert not proof_path.exists()
summary_path = n / 'only-check/summary.json'
summary = load(summary_path)
assert summary['status'] == 'PASSED' and summary['profile'] == 'check'
inputs = load(n / 'only-check-start-inputs-v1.json')
assert all(sha(r / p) == h for p, h in inputs['inputHashes'].items())
assert all(sha(r / p) == h for p, h in inputs['compiledCheckModuleHashes'].items())
ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def extract(raw):
    root = ET.fromstring(raw)
    rows = root.findall('.//t:UnitTestResult', ns)
    assert rows and all(row.attrib['outcome'] == 'Passed' for row in rows)
    tests = root.findall('.//t:UnitTest', ns)
    methods = set()
    for test in tests:
        method = test.find('t:TestMethod', ns)
        if method is not None:
            methods.add(method.attrib['className'].split(',')[0] + '.' + method.attrib['name'])
    return collections.Counter(row.attrib['testName'] for row in rows), methods
baseline = r / 'docs/evidence/empty-reveal-followup-2026-10-19/single-check-check.trx.gz'
old, old_methods = extract(gzip.decompress(baseline.read_bytes()))
current = n / 'only-check/check/results.trx'
new, methods = extract(current.read_bytes())
assert sum(old.values()) == 12969 and sum(new.values()) == 12975
assert len(old_methods) == 7425 and len(methods) == 7427
assert not old - new and old_methods <= methods
added = new - old
assert sum(added.values()) == 6 and all('PakaaDualTypeRevealTests.' in name for name in added)
assert len(methods - old_methods) == 2
debug = load(n / 'current-check-debug-identity-v1.json')
proof = {'recordedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'status': 'CHECK_AND_EXACT_CASE_METHOD_PARITY_PASS', 'profile': 'check',
         'passed': 12975, 'failed': 0, 'skipped': 0, 'methods': 7427,
         'oldCaseCount': 12969, 'oldMethodCount': 7425, 'oldCasesPreserved': True,
         'oldMethodsPreserved': True, 'frozenInputsUnchanged': True,
         'all3035DeclaredPrecheckInputsStableThroughoutExecution': True,
         'all42CheckModuleCopiesStableThroughoutExecution': True,
         'actualDebugRuleInputs': debug['actualRuleInputs'],
         'allOriginalModuleHashes': inputs['compiledCheckModuleHashes'],
         'newMethodNames': sorted(methods - old_methods), 'newCaseNames': sorted(added.elements()),
         'summarySha256': sha(summary_path), 'rawTrxSha256': sha(current),
         'baselineGzipTrxSha256': sha(baseline), 'inputManifestSha256': sha(n / 'only-check-start-inputs-v1.json'),
         'noSecondCheckForThisBatch': True,
         'localOptionalPostgresSmokes': 'ConnectionStrings__Riftbound absent; their early returns are not claimed as database validation. The separate actual two-case SQL gate and fixed CI real PostgreSQL remain independently recorded.' if not os.environ.get('ConnectionStrings__Riftbound') else 'Environment configured; no database claim inferred solely from this check.',
         'sqlHelperPublicationScope': 'The isolated corrected SQL helper has separately passed actual frozen797f Release SQL and independent readback. It is not compiled by Conformance. Its byte-exact canonical publication occurs only after this check has terminated; no tested source/bin was edited while executing.',
         'newFixedFull': 'PENDING', 'visibleAndPhysicalWindows': 'OPEN', 'wholePrintingCertified': False}
proof_path.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
print({'status': proof['status'], 'passed': proof['passed'], 'methods': proof['methods'], 'oldCasesRetained': True}, flush=True)
