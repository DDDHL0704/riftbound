import concurrent.futures
import datetime
import gzip
import hashlib
import json
import os
import urllib.request
from pathlib import Path

os.umask(0o077)
n = Path(__file__).resolve().parent
r = n.parents[2]
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
catalog = json.loads((r / 'data/official/card-catalog.zh-CN.json').read_text())
cards = {row['id']: row for row in catalog['cards'] if row['id'] in (37721, 37943)}
core = r / 'var/qa/colorless-token-haste-20261016/DOC-01-current.pdf'
core_hash = 'd6fd7140f106f9b5b3dc0d5817fd040110fe870a6da9ee335ba7f4f70f892d11'
assert sha(core.read_bytes()) == core_hash
receipt = {'startedAtUtc': now(), 'region': 'CN', 'language': 'zh-CN', 'applicableAsOf': '2026-10-16',
           'observationDate': '2026-10-19', 'status': 'RUNNING', 'records': {},
           'semanticCoverageCertified': False, 'wholePrintingCertified': False,
           'runtimeSourceOrOldIntentsChanged': False}

def save():
    (n / 'source-intake-v1.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')

def fetch(key, url, query=None, expected=None, filename=None):
    record = {'url': url, 'request': query, 'startedAtUtc': now(), 'publicationDate': None, 'effectiveDate': None}
    request = urllib.request.Request(url, None if query is None else json.dumps(query, ensure_ascii=False).encode(),
                                     {'Content-Type': 'application/json', 'User-Agent': 'RiftboundOfficialAudit/1.0'})
    try:
        with urllib.request.urlopen(request, timeout=50) as response:
            record.update(httpStatus=response.status, resolvedUrl=response.url, httpDate=response.headers.get('Date'), lastModified=response.headers.get('Last-Modified'))
            digest = hashlib.sha256()
            parts = []
            size = 0
            while chunk := response.read(1024 * 1024):
                size += len(chunk)
                assert size <= 50 * 1024 * 1024
                digest.update(chunk)
                if filename is not None:
                    parts.append(chunk)
        record.update(receivedAtUtc=now(), rawBytes=size, rawSha256=digest.hexdigest())
        if expected is not None:
            assert record['rawSha256'] == expected, 'Fresh source differs from the retained authoritative version'
        if filename is not None:
            raw = b''.join(parts)
            path = n / filename
            assert not path.exists()
            path.write_bytes(gzip.compress(raw, mtime=0) if path.suffix == '.gz' else raw)
            record.update(path=str(path.relative_to(r)), storedSha256=sha(path.read_bytes()))
            if query is not None:
                parsed = json.loads(raw)
                rows = parsed['data']['records']
                row = next(row for row in rows if row['id'] == key)
                assert row == cards[key], 'Exact current official row differs; analyze before changing expectations'
                record.update(apiId=key, cardNo=row['cardNo'], wholeRowExactCurrentCatalog=True,
                              cardQaList=row['cardQaList'], isPreview=row['isPreview'])
        else:
            record.update(retainedCanonicalSource=str(core.relative_to(r)), noAdditionalSourceCopy=True,
                          publicationDate='2026-10-10', effectiveDate='2026-10-16')
    except BaseException as error:
        record.update(errorType=type(error).__name__, errorMessage=str(error), failedAtUtc=now())
    return key, record

save()
url = 'https://lol-api.playloltcg.com/xcx/card/searchCardCraftWeb'
jobs = []
for identity, row in cards.items():
    query = {'pageNum': 1, 'pageSize': 100, 'searchContent': row['cardName'],
             'cardCategoryList': [], 'cardColorList': [], 'rarityList': [], 'productCodeList': []}
    jobs.append((identity, url, query, None, f'official-cn-{identity}.json.gz'))
jobs.append(('porobotFace', cards[37943]['frontImage'], None, None, 'porobot-cn-official.png'))
jobs.append(('currentCnCore', 'https://cdn.playloltcg.com/lol/2026/10/2026-10-10/a21ead876c6b44d6abe386b6ae54ea28.pdf', None, core_hash, None))
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    for key, record in pool.map(lambda args: fetch(*args), jobs):
        receipt['records'][str(key)] = record
        save()
failed = [key for key, record in receipt['records'].items() if 'errorType' in record]
receipt.update(finishedAtUtc=now(), status='FAILED_SOURCE_PREFIX_RETAINED' if failed else 'PASS_EXACT_CN_ROWS_AND_CURRENT_PRIMARY_HASH', failedRecords=failed)
save()
print(json.dumps({'status': receipt['status'], 'failedRecords': failed, 'recordCount': len(receipt['records'])}), flush=True)
assert not failed
