import concurrent.futures
import datetime
import hashlib
import json
import urllib.request
from pathlib import Path

n = Path(__file__).resolve().parent
r = n.parents[2]
source = n / 'eight-structured-identity-readback-v1.json'
rows = json.loads(source.read_text())['knownNearbyRadRows']
selected = [row for row in rows if row['id'] in ['rad-110-167', 'rad-r01a', 'rad-r01']]
assert len(selected) == 3
folder = n / 'actual-neighbor-gallery-faces'
assert not folder.exists()
folder.mkdir()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
records = []
def fetch(row):
    item = {'officialApiId': row['id'], 'publicCode': row['publicCode'], 'url': row['cardImage']['url'],
            'region': 'GLOBAL', 'language': 'en-US', 'startedAtUtc': now(), 'publicationDate': None, 'effectiveDate': None}
    try:
        with urllib.request.urlopen(urllib.request.Request(item['url'], headers={'User-Agent': 'RiftboundOfficialAudit/1.0'}), timeout=40) as response:
            raw = response.read(3 * 1024 * 1024 + 1)
            assert len(raw) <= 3 * 1024 * 1024 and raw.startswith(b'\x89PNG\r\n\x1a\n')
            item.update(httpStatus=response.status, resolvedUrl=response.url, httpDate=response.headers.get('Date'), lastModified=response.headers.get('Last-Modified'))
        path = folder / (row['id'] + '.png')
        assert not path.exists()
        path.write_bytes(raw)
        item.update(receivedAtUtc=now(), rawBytes=len(raw), rawSha256=sha(raw), path=str(path.relative_to(r)))
    except BaseException as error:
        item.update(errorType=type(error).__name__, errorMessage=str(error), failedAtUtc=now())
    return item
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    records = list(pool.map(fetch, selected))
out = n / 'neighbor-gallery-image-acquisition-v1.json'
assert not out.exists()
failed = [item['officialApiId'] for item in records if 'errorType' in item]
out.write_text(json.dumps({'recordedAtUtc': now(), 'sourceApiReceiptPath': str(source.relative_to(r)),
    'sourceApiReceiptSha256': sha(source.read_bytes()), 'status': 'FAILED_PREFIX_RETAINED' if failed else 'ACQUIRED_NOT_YET_VISUALLY_INTERPRETED',
    'records': records, 'failedRecords': failed, 'articleOriginal39AndAllEightObligationsNotOverwritten': True}, ensure_ascii=False, indent=2) + '\n')
print({'acquired': len(records) - len(failed), 'failed': failed}, flush=True)
assert not failed
