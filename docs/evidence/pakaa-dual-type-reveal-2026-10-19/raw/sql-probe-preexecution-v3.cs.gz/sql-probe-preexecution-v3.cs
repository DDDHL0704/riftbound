using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

var json = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };
if (args.SequenceEqual(new[] { "identity-print" }))
{ Console.WriteLine(JsonSerializer.Serialize(RuleInputIdentity.Current, json)); return; }
var settings = new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));
if (settings.Host != "127.0.0.1" || settings.Port != 55486 || settings.Database != "riftbound_acceptance"
    || settings.Username != "codex_riftbound_audit") throw new Exception("Only the existing dedicated audit SQL database.");
var work = Path.GetFullPath(Environment.GetEnvironmentVariable("RIFTBOUND_DUAL_TYPE_WORK") ?? throw new Exception("Explicit evidence folder required."));
using var publication = JsonDocument.Parse(File.ReadAllText(Path.Combine(work, "../empty-reveal-followup-20261019/fixed-release-publication-inputs-v1.json")));
if (!JsonNode.DeepEquals(JsonSerializer.SerializeToNode(RuleInputIdentity.Current, json),
        JsonNode.Parse(publication.RootElement.GetProperty("actualRuleInputs").GetRawText())))
    throw new Exception("Actual modules differ from fixed797f Release identity.");
if (args.Length == 3 && args[0] == "retain-failed-prefix")
{
    settings.Options = "-c default_transaction_read_only=on";
    await using var reader = NpgsqlDataSource.Create(settings.ConnectionString);
    var original = await new PostgresMatchRecoveryStore(reader).LoadAsync(args[1], default)
        ?? throw new Exception("The first original failed SQL prefix must still exist.");
    if (!original.IsConsistent || original.OpeningSeed != 0 || original.AuthoritativeState is not { } state
        || state.RuleInputs != RuleInputIdentity.Current || state.FocusPlayerId != "P2")
        throw new Exception("Original failure must retain the opponent focus, original seed and current identity.");
    var rejected = original.Commands.Where(c => !c.Accepted).ToArray();
    if (rejected.Length != 1 || rejected[0].CommandType != CommandTypes.EndTurn || rejected[0].PlayerId != "P1"
        || rejected[0].StartedTick != rejected[0].CompletedTick || rejected[0].StartedEventSequence != rejected[0].CompletedEventSequence)
        throw new Exception("The retained premature EndTurn must be rejected atomically.");
    var errors = await MatchActionLogReplayer.ValidateRecoveryFrameAsync(original, new CoreRuleEngine(), default);
    if (errors.Count != 0) throw new Exception("The first original accepted/rejected prefix must replay: " + string.Join(';', errors));
    var path = Path.GetFullPath(args[2]);
    if (!path.StartsWith(work + Path.DirectorySeparatorChar, StringComparison.Ordinal) || File.Exists(path))
        throw new Exception("A new bounded original evidence file is required.");
    await using (var file = File.Create(path)) await using (var zip = new GZipStream(file, CompressionLevel.SmallestSize))
        await JsonSerializer.SerializeAsync(zip, original, json);
    Console.WriteLine(JsonSerializer.Serialize(new { status = "PASS_RETAINED_ORIGINAL_PREMATURE_ENDTURN_REJECTION_READONLY",
        room = original.RoomId, commands = original.Commands.Count, accepted = original.Commands.Count(c => c.Accepted),
        rejected = 1, events = original.Events.Count, pendingOpponentFocus = state.FocusPlayerId,
        rejectedTickAndEventSequenceAtomic = true, originalAcceptedAndRejectedFullReplayMatched = true,
        actualRuleInputs = state.RuleInputs, originalDatabaseStateSeedAndHistoryUnmodified = true }, json)); return;
}
if (args.SequenceEqual(new[] { "run-sql" }))
{
    await using var writer = NpgsqlDataSource.Create(settings.ConnectionString);
    await PakaaDualTypeRevealSqlAcceptance.RunAsync(writer, Path.Combine(work, "actual-fixed797f-sql-v1"));
    Console.WriteLine("REAL_ORIGINAL_DUAL_TYPE_SQL_COMPLETE"); return;
}
if (!args.SequenceEqual(new[] { "independent-readonly" })) throw new Exception("Exact bounded mode required.");
settings.Options = "-c default_transaction_read_only=on";
await using var source = NpgsqlDataSource.Create(settings.ConnectionString);
var checks = new List<object>();
using var recipe = JsonDocument.Parse(File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "Fixtures/pakaa-dual-type-openings.json")));
var host = recipe.RootElement.GetProperty("host").GetString()!;
foreach (var format in new[] { "CoreRules", "ChinaStandard20260724" })
{
    var path = Path.Combine(work, "actual-fixed797f-sql-v1/dual-type-paka-" + format + "-original-frame.json.gz");
    using var zip = new GZipStream(File.OpenRead(path), CompressionMode.Decompress);
    var original = await JsonSerializer.DeserializeAsync<MatchRecoveryFrame>(zip, json) ?? throw new Exception("Original SQL receipt frame required.");
    var actual = await new PostgresMatchRecoveryStore(source).LoadAsync(original.RoomId, default) ?? throw new Exception("Actual persisted original room required.");
    if (!JsonNode.DeepEquals(JsonSerializer.SerializeToNode(original, json), JsonSerializer.SerializeToNode(actual, json)))
        throw new Exception("Actual original fields/nulls/command order/events/both private views differ.");
    if (!actual.IsConsistent || actual.OpeningSeed != 0 || actual.ReplayInitialState is not { Tick: 0 } blank
        || blank.CardObjects.Count != 0 || actual.AuthoritativeState is not { } state || state.RuleInputs != RuleInputIdentity.Current
        || actual.Commands.Any(c => !c.Accepted || c.RuleInputs != RuleInputIdentity.Current))
        throw new Exception("Original ordinary blank seed0 and exact current identities required.");
    var deckInput = actual.Commands.Single(c => c.PlayerId == "P1" && c.CommandType == CommandTypes.SubmitDeck);
    if (deckInput.RawCommand is not { } submitted
        || submitted.GetProperty("legendCardNo").GetString() != "OGN·255/298"
        || submitted.GetProperty("mainDeck").EnumerateArray().Count(v => v.GetString() == "VEN·058") != 3)
        throw new Exception("Original submitted green/blue deck must contain the three real Porobots.");
    var move = actual.Commands.Single(c => c.CommandType == CommandTypes.MoveUnit);
    var resolvedThrough = actual.Commands.Last(c => c.CommandType == CommandTypes.PassPriority).CompletedEventSequence;
    var events = actual.Events.Where(e => e.Sequence > move.StartedEventSequence && e.Sequence <= resolvedThrough).Select(e => e.Event).ToArray();
    var reveal = events.Single(e => e.Kind == "CARDS_REVEALED");
    var ids = JsonSerializer.SerializeToElement(reveal.Payload).GetProperty("cardIds").EnumerateArray().Select(v => v.GetString()).ToArray();
    if (ids.Length != 1 || ids[0] is not { } top || state.CardObjects[top].CardNo != "VEN·058"
        || !state.CardObjects[top].Tags.Contains(CardObjectTags.UnitCard) || !state.CardObjects[top].Tags.Contains(CardObjectTags.EquipmentCard)
        || !state.PlayerZones["P1"].Hand.Contains(top) || state.PlayerZones["P1"].MainDeck.Contains(top)
        || events.Count(e => e.Kind == "CARD_DRAWN") != 1
        || events.Any(e => e.Kind is "CARDS_MILLED" or "BURNOUT_APPLIED" or "UNIT_PLAYED_TO_BASE"))
        throw new Exception("Independent expected: reveal the original dual type, draw it once, do not play/mill it or draw a replacement.");
    foreach (var view in actual.PlayerViews.Values)
    {
        var snapshot = JsonSerializer.SerializeToElement(view.Snapshot, json);
        if (snapshot.GetProperty("players").GetProperty("P1").GetProperty("objects").GetProperty(host).GetProperty("effectivePower").GetInt32() != 4)
            throw new Exception("Independent source expected Paka Might4 in both actual stored player views.");
    }
    var errors = await MatchActionLogReplayer.ValidateRecoveryFrameAsync(actual, new CoreRuleEngine(), default);
    if (errors.Count != 0) throw new Exception("Original complete replay failed: " + string.Join(';', errors));
    checks.Add(new { room = actual.RoomId, format, commands = actual.Commands.Count, events = actual.Events.Count,
        allStoredFieldsAndNullsAndBothPrivateViewsExact = true, originalSeed = 0, independentDraws = 1,
        independentExpectedMight = 4, bothPrintedTypes = true, originalFullReplayMatched = true });
}
Console.WriteLine(JsonSerializer.Serialize(new { status = "PASS_ACTUAL_INDEPENDENT_READONLY_DUAL_TYPE_ORIGINAL_FRAMES", checks,
    actualRuleInputs = RuleInputIdentity.Current, noNewRoomStateSeedOrHistoryRewrite = true, visibleAndPhysicalWindows = "OPEN" }, json));
