import fcntl
import json
import os
import pathlib
import subprocess
import sys

os.umask(0o077)
work = pathlib.Path(__file__).resolve().parent
r = work.parents[2]
sys.path.insert(0, str(r / 'var/qa/empty-reveal-followup-20261019'))
import fixed_n13_common as c

manifest = c.load(work / 'fixed-sql-probe-build-v2.json')
runtime = work / 'sql-probe-runtime'
out = work / 'fixed-sql-verification-v1.json'
assert not out.exists()
def frozen():
    c.verify_frozen()
    assert all(c.sha(runtime / p) == h for p, h in manifest['runtimeFiles'].items())
    assert all(c.sha(r / p) == h for p, h in manifest['sources'].items())
frozen()
guard = (r / 'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a')
fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
proof = {'startedAtUtc': c.now(), 'status': 'RUNNING_NOT_ACCEPTANCE',
         'fixedCoreCommit': c.fixed, 'actualRuleInputs': c.identity,
         'newSqlHarnessInputsSha256': c.sha(work / 'fixed-sql-probe-build-v2.json'),
         'runnerSourceSha256': c.sha(pathlib.Path(__file__)), 'lockAtStart': c.locked(),
         'visibleNativeAndPhysicalWindows': 'OPEN',
         'scope': 'Two new ordinary blank seed0 green/blue Paka unit/gear-top matches in the existing real SQL database. Reuse frozen797f Release core modules; source/test-only new harness. No previous history, seed, database or runtime relabeled.'}
c.write(out, proof)
started = False
power = None
process = None
audit = native = None
before_audit = before_native = None
try:
    assert subprocess.run([str(c.pg / 'pg_ctl'), '-D', str(c.cluster), 'status'], capture_output=True).returncode == 3
    power = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-w', str(os.getpid())], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    proof.update(ownRunnerPid=os.getpid(), boundIdleSleepAssertionPid=power.pid)
    subprocess.run([str(c.pg / 'pg_ctl'), '-D', str(c.cluster), '-l', str(work / 'own-postgres-v1.log'), '-o',
                    f'-p 55486 -h 127.0.0.1 -k {c.sock}', '-w', 'start'], check=True, capture_output=True)
    started = True
    audit = c.rooms('riftbound_acceptance'); native = c.rooms('riftbound_here_native')
    assert len(audit) == 160 and len(native) == 31
    before_audit = c.digests('riftbound_acceptance', audit)
    before_native = c.digests('riftbound_here_native', native)
    proof.update(priorAuditRooms=audit, priorNativeRooms=native, priorAuditSevenTables=before_audit, priorNativeSevenTables=before_native)
    c.write(out, proof)
    env = dict(os.environ, ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit', RIFTBOUND_DUAL_TYPE_WORK=str(work))
    def run(mode, name):
        global process
        with (work / name).open('x') as log:
            process = subprocess.Popen([c.dotnet, str(runtime / 'probe.dll'), mode], cwd=runtime, env=env, stdout=log, stderr=subprocess.STDOUT)
            proof['ownAcceptancePid'] = process.pid; c.write(out, proof)
            code = process.wait(timeout=900)
        assert code == 0, (mode, code, str(work / name))
    run('run-sql', 'actual-sql-writer-v1.log')
    receipt_path = work / 'actual-fixed797f-sql-v1/receipt.json'
    receipt = c.load(receipt_path)
    assert receipt['status'] == 'REAL_POSTGRES_ORIGINAL_DUAL_TYPE_REVEAL_TWO_ENGINE_FORMATS_COLD_REPLAY_PASS'
    rows = receipt['results']; assert len(rows) == 2
    assert {x['format'] for x in rows} == {'CoreRules', 'ChinaStandard20260724'}
    assert all(x['commands'] == 23 and x['events'] == 106 and x['originalBlankSeed'] == 0
               and x['initialObservedCards'] == 1 and x['expectedDraws'] == 1 and x['expectedFinalMight'] == 4
               and x['originalFullReplayMatched'] and x['originalPrivateViewsAndPromptsExact']
               and x['noStateSeedOrHistoryInjection'] and x['ruleInputs'] == c.identity
               and x['coldRestores'] >= 5 and x['originalNextCommandsMatched'] >= 4 and x['atomicRejections'] == 2 for x in rows)
    added = sorted(set(c.rooms('riftbound_acceptance')) - set(audit))
    assert added == sorted(x['room'] for x in rows) and len(c.rooms('riftbound_acceptance')) == 162
    assert c.rooms('riftbound_here_native') == native
    assert c.digests('riftbound_acceptance', audit) == before_audit
    assert c.digests('riftbound_here_native', native) == before_native
    all_audit = c.rooms('riftbound_acceptance'); all_audit_before_read = c.digests('riftbound_acceptance', all_audit)
    run('independent-readonly', 'independent-actual-sql-reader-v1.log')
    reader = json.loads((work / 'independent-actual-sql-reader-v1.log').read_text())
    assert reader['status'] == 'PASS_ACTUAL_INDEPENDENT_READONLY_DUAL_TYPE_ORIGINAL_FRAMES' and len(reader['checks']) == 2
    assert reader['actualRuleInputs'] == c.identity
    assert c.rooms('riftbound_acceptance') == all_audit and c.rooms('riftbound_here_native') == native
    assert c.digests('riftbound_acceptance', all_audit) == all_audit_before_read
    assert c.digests('riftbound_here_native', native) == before_native
    c.write(work / 'independent-actual-sql-reader-result-v1.json', reader)
    proof.update(status='PASS_REAL_SQL_TWO_DUAL_TYPE_ORIGINALS_AND_INDEPENDENT_READONLY_FULL_REPLAY',
                 branches=2, commands=sum(x['commands'] for x in rows), events=sum(x['events'] for x in rows),
                 coldRestores=sum(x['coldRestores'] for x in rows), originalNextCommandsMatched=sum(x['originalNextCommandsMatched'] for x in rows),
                 atomicRejections=sum(x['atomicRejections'] for x in rows), originalReceiptSha256=c.sha(receipt_path),
                 newOriginalRooms=added, all160PriorAuditAnd31NativeRoomsSevenTablesExact=True,
                 independentAll162AuditAnd31NativeRoomsSevenTablesUnchanged=True,
                 newRoomSevenTables=c.digests('riftbound_acceptance', added), observedAuditRooms=162, observedNativeRooms=31,
                 originalFrameHashes={p.name: c.sha(p) for p in (work / 'actual-fixed797f-sql-v1').glob('*.json.gz')})
except BaseException as error:
    proof.update(status='FAILED_OR_INTERRUPTED_ORIGINAL_PREFIX_RETAINED', errorType=type(error).__name__, errorMessage=str(error))
    raise
finally:
    if process is not None and process.poll() is None:
        process.terminate(); process.wait(timeout=30)
    if started:
        proof['ownPostgresSmartStopped'] = subprocess.run([str(c.pg / 'pg_ctl'), '-D', str(c.cluster), '-m', 'smart', '-w', '-t', '20', 'stop'], capture_output=True).returncode == 0
    if power is not None:
        if power.poll() is None: power.terminate(); power.wait(timeout=10)
        proof['boundIdleSleepAssertionEnded'] = power.poll() is not None
    frozen()
    proof.update(finishedAtUtc=c.now(), lockAtEnd=c.locked(), allFrozenRuntimeAndHarnessInputsStillExact=True, originalDatabaseRetained=c.cluster.exists())
    c.write(out, proof)
    fcntl.flock(guard, fcntl.LOCK_UN)
print(proof['status'], flush=True)
