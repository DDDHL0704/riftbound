from pathlib import Path
from urllib.request import Request,urlopen
from concurrent.futures import ThreadPoolExecutor
import datetime,gzip,hashlib,json,math,re,sys
sys.dont_write_bytecode=True
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;rawdir=w/'card-originals-v1';rawdir.mkdir();baseline=root/'data/official/upstream/2026-10-16/source-refresh-20261015T160523Z'
sys.path.insert(0,str(root/'scripts/audit'));from gallery_coverage import merge_gallery_views
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda b:hashlib.sha256(b).hexdigest();receipts=[]
def get(url,name,body=None):
 start=now();req=Request(url,json.dumps(body).encode() if body is not None else None,{'Content-Type':'application/json','User-Agent':'Mozilla/5.0','Cache-Control':'no-cache'})
 with urlopen(req,timeout=35) as r:raw=r.read();headers={k:r.headers[k] for k in ['Date','ETag','Age','Cache-Control','Last-Modified','Content-Type'] if k in r.headers};status=r.status;resolved=r.url
 path=rawdir/(name+'.gz');assert not path.exists();path.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(path.read_bytes())==raw
 receipt={'url':url,'request':body,'startedAtUtc':start,'receivedAtUtc':now(),'httpStatus':status,'resolvedUrl':resolved,'responseHeaders':headers,'originalRawBytes':len(raw),'originalRawSha256':sha(raw),'losslessCompressedOriginal':str(path.relative_to(root)),'compressedSha256':sha(path.read_bytes())};receipts.append(receipt);(rawdir/(name+'.receipt.json')).write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');return json.loads(raw) if name.endswith('.json') else raw

def diff(old,new):
 previous={x['id']:x for x in old};current={x['id']:x for x in new};assert len(current)==len(new)
 changed=[{'id':id,'changedFields':sorted(k for k in set(previous[id])|set(current[id]) if previous[id].get(k)!=current[id].get(k) or (k in previous[id])!=(k in current[id])),'oldCanonicalRowSha256':sha(json.dumps(previous[id],ensure_ascii=False,sort_keys=True).encode()),'currentCanonicalRowSha256':sha(json.dumps(current[id],ensure_ascii=False,sort_keys=True).encode())} for id in sorted(previous.keys()&current.keys()) if previous[id]!=current[id]]
 return {'previous':len(previous),'current':len(current),'addedIds':sorted(current.keys()-previous.keys()),'unreturnedPreviousIds':sorted(previous.keys()-current.keys()),'changedCompleteRows':changed,'allPreviousKeysValuesAndNullsExact':not(changed or previous.keys()-current.keys()),'currentCanonicalRowsSha256':sha(json.dumps(sorted(new,key=lambda x:x['id']),ensure_ascii=False,sort_keys=True).encode())}
proof={'status':'RUNNING_WHOLE_CURRENT_CARD_SOURCE_READ_NOT_ADOPTED','startedAtUtc':now(),'primarySourcesOnly':True,'activeInputsAndExistingScopeDatesAndManifestsUnchanged':True,'firstPublicationAndEffectiveDatesNotInferredFromFetchTime':True}
try:
 url='https://lol-api.playloltcg.com/xcx/card/searchCardCraftWeb';body={'pageNum':1,'pageSize':100,'searchContent':'','cardCategoryList':[],'cardColorList':[],'rarityList':[],'productCodeList':[]};first=get(url,'cn-page-01.json',body)['result'];total=first['total']
 with ThreadPoolExecutor(max_workers=4) as pool:pages=[first]+list(pool.map(lambda i:get(url,f'cn-page-{i:02}.json',{**body,'pageNum':i})['result'],range(2,math.ceil(total/100)+1)))
 cards=[c for page in pages for c in page['list']];assert all(page['total']==total for page in pages) and len(cards)==len({c['id'] for c in cards})==total
 old=json.loads((baseline/'card-catalog.zh-CN.json').read_text());proof['CN']={'language':'zh-CN','region':'CN','reportedTotal':total,'returnedUnique':len(cards),'pages':len(pages),'diff':diff(old['cards'],cards),'nonnullApiQaRows':sum(bool(c.get('cardQaList')) for c in cards)};print('CN',total,'rows;',len(proof['CN']['diff']['changedCompleteRows']),'changed;',len(proof['CN']['diff']['addedIds']),'new',flush=True)
 base='https://content.publishing.riotgames.com/publishing-content/v2.0/public/channel/riftbound_website/list/riftbound_gallery_cards?locale=en_US&limit=200&from=';first=get(base+'0','en-page-0000.json');total=first['metadata']['totalItems']
 with ThreadPoolExecutor(max_workers=4) as pool:pages=[first]+list(pool.map(lambda offset:get(base+str(offset),f'en-page-{offset:04}.json'),range(200,total,200)))
 assert all(p['metadata']['totalItems']==total for p in pages);whole=get(base.replace('limit=200','limit='+str(max(2000,total)))+'0','en-whole.json');html=get('https://playriftbound.com/en-us/card-gallery/','en-gallery.html').decode();next_data=json.loads(re.search(r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>',html,re.S).group(1));gallery=next(b for b in next_data['props']['pageProps']['page']['blades'] if b['type']=='riftboundCardGallery')
 rows,comparison=merge_gallery_views([{'name':'currentPagination','reportedTotal':total,'records':[c for p in pages for c in p['data']]},{'name':'currentWholeList','reportedTotal':whole['metadata']['totalItems'],'records':whole['data']},{'name':'currentSsr','reportedTotal':gallery['cards']['async']['metadata']['totalItems'],'records':gallery['cards']['items']}]);old=json.loads((baseline/'card-gallery.en-US.json').read_text());proof['GLOBAL_EN']={'region':'GLOBAL','language':'en-US','reportedTotal':total,'returnedUnique':len(rows),'reportedButUnreturned':total-len(rows),'viewComparison':comparison,'diff':diff(old['cards'],rows)}
 print('EN',total,'reported;',len(rows),'unique;',len(proof['GLOBAL_EN']['diff']['changedCompleteRows']),'changed;',len(proof['GLOBAL_EN']['diff']['addedIds']),'new',flush=True)
 try:
  default=get(base.replace('locale=en_US&','').replace('limit=200','limit=2000')+'0','default-locale-whole.json');ids={c['id'] for c in rows};default_ids={c['id'] for c in default['data']};proof['newBoundedGapStrategyDefaultLocale']={'actualMetadata':default['metadata'],'returnedRows':len(default['data']),'distinctIds':len(default_ids),'idsNotInCurrentExplicitEnglishViews':sorted(default_ids-ids),'explicitEnglishIdsNotReturned':sorted(ids-default_ids),'notMergedIntoEnglishWithoutLocaleEvidence':True,'backendCauseNotInferred':True}
 except Exception as error:proof['newBoundedGapStrategyDefaultLocale']={'errorType':type(error).__name__,'error':str(error),'gapNotClosed':True}
 proof['status']='COMPLETE_CURRENT_CN_AND_EN_PUBLIC_CARD_VIEWS_SOURCE_DIFF_ONLY_NOT_SEMANTIC_OR_RUNTIME_CERTIFICATION'
except BaseException as error:
 proof.update(status='SOURCE_READ_INCOMPLETE_OR_NONATOMIC_ALL_ORIGINAL_RESPONSES_RETAINED',errorType=type(error).__name__,error=str(error));raise
finally:
 proof.update(finishedAtUtc=now(),originalResponseReceipts=sorted(receipts,key=lambda r:r['losslessCompressedOriginal']));(w/'whole-current-card-view-source-diff-v1.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print(proof['status'],flush=True)
