from pathlib import Path
from urllib.request import Request,urlopen
from urllib.error import HTTPError
from concurrent.futures import ThreadPoolExecutor
import datetime,gzip,hashlib,json,urllib.parse
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;output=w/'cn-rule-conditional-originals-v1';output.mkdir();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda b:hashlib.sha256(b).hexdigest()
corpus=json.loads((root/'docs/evidence/rules-reaudit-2026-10-11/official-corpus.json').read_text());prior_root=root/'docs/evidence/source-round-2026-10-21/originals/rules'
def fetch(doc):
 prior=json.loads((prior_root/(doc['id']+'.pdf.receipt.json')).read_text());saved=root/prior['path'];assert saved.is_file() and sha(saved.read_bytes())==prior['sha256'];etag=prior.get('responseHeaders',{}).get('ETag');headers={'User-Agent':'Mozilla/5.0'}
 if etag:headers['If-None-Match']=etag
 started=now();row={'id':doc['id'],'region':'CN','language':'zh-CN','url':doc['url'],'startedAtUtc':started,'conditionalIfNoneMatch':etag,'originalSourceTitleAndDates':{k:doc.get(k) for k in ['title','updated','effectiveDate']},'publicationAndNewEffectiveDatesNotInferred':True,'existingOriginal':{'path':prior['path'],'sha256':prior['sha256']},'semanticCertification':False}
 try:
  request=Request(urllib.parse.quote(doc['url'],safe=':/?=&%'),headers=headers)
  try:
   with urlopen(request,timeout=40) as r:raw=r.read();status=r.status;resolved=r.url;response_headers=dict(r.headers)
  except HTTPError as error:
   if error.code!=304:raise
   raw=None;status=304;resolved=error.url;response_headers=dict(error.headers)
  row.update(receivedAtUtc=now(),httpStatus=status,resolvedUrl=resolved,responseHeaders={k:v for k,v in response_headers.items() if k.lower() in {'date','etag','age','cache-control','last-modified','content-type'}})
  if status==304:
   assert etag;row.update(status='OFFICIAL_CONDITIONAL_NOT_MODIFIED_EXISTING_RAW_BYTES_VERIFIED',sha256=prior['sha256'],bytes=prior['bytes'],unchanged=True,actualCurrentPayloadDownloaded=False)
  else:
   assert raw.startswith(b'%PDF');same=sha(raw)==prior['sha256'];row.update(status='FRESH_PDF_BYTES_SAME_EXISTING_OR_NEW_VERSION',sha256=sha(raw),bytes=len(raw),unchanged=same,actualCurrentPayloadDownloaded=True)
   if not same:
    p=output/(doc['id']+'-new-original.pdf');p.write_bytes(raw);row['newOriginalPath']=str(p.relative_to(root))
   else:row['identicalNewPayloadNotDuplicatedOnDisk']=True
 except Exception as error:row.update(status='CURRENT_SOURCE_ACCESS_OR_IDENTITY_GAP',errorType=type(error).__name__,error=str(error),receivedAtUtc=now())
 (output/(doc['id']+'.receipt.json')).write_text(json.dumps(row,ensure_ascii=False,indent=2)+'\n');return row
with ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(fetch,corpus['documents']))
url='https://lol-api.playloltcg.com/xcx/gameRule/getGameRuleList';body={'pageNum':1,'pageSize':1000};started=now()
with urlopen(Request(url,json.dumps(body).encode(),{'Content-Type':'application/json','User-Agent':'Mozilla/5.0'}),timeout=35) as r:raw=r.read();status=r.status
path=output/'current-rule-directory-original.json.gz';path.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(path.read_bytes())==raw;current=json.loads(raw);old=json.loads((root/'var/qa/cn16-runtime-adoption-20261016/source-readback/rules-api.json').read_text());directory={'url':url,'request':body,'startedAtUtc':started,'receivedAtUtc':now(),'httpStatus':status,'sha256':sha(raw),'original':str(path.relative_to(root)),'compressedSha256':sha(path.read_bytes()),'currentListedRows':len(current['result']),'allDirectoryRowsFieldsNullsAndOrderExactlyPreviousRecordedVersion':current['result']==old['result'],'newListedUrls':sorted({c['ruleDocUrl'] for c in current['result']}-{c['url'] for c in corpus['documents']})}
proof={'atUtc':now(),'status':'CURRENT_CN_RULE_DIRECTORY_AND_SIXTEEN_RETAINED_SOURCE_CONDITIONAL_VERSION_OBSERVATIONS','directory':directory,'documents':rows,'sourceUniverseKeptEvenIfNotCurrentlyListed':len(rows)==16,'unchangedKnownDocuments':sum(r.get('unchanged',False) for r in rows),'conditionalNotModifiedResponses':sum(r.get('httpStatus')==304 for r in rows),'freshPayloadBytesRead':sum(r.get('bytes',0) for r in rows if r.get('actualCurrentPayloadDownloaded')),'noEqualPdfPayloadCopiesCreated':True,'oldPublicationEffectiveAndConfirmationDatesNeverRewritten':True,'runtimeCatalogAuthorityAndTrackedManifestNotChanged':True,'wholeRuleOrGlobalSourceSemanticCertification':False};(w/'current-cn-rule-directory-and-known-source-versions-v1.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');print('CN rules:',directory['currentListedRows'],'listed;16 retained;',proof['unchangedKnownDocuments'],'unchanged;',proof['conditionalNotModifiedResponses'],'HTTP304;new URLs',len(directory['newListedUrls']))
