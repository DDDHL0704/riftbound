using System.Reflection;
using System.Runtime.Loader;
using System.Text.Json;
using Riftbound.Contracts;
using Riftbound.Engine;

AssemblyLoadContext.Default.Resolving+=(_,name)=>{
    var path=Path.Combine(AppContext.BaseDirectory,name.Name+".dll");
    return File.Exists(path)?AssemblyLoadContext.Default.LoadFromAssemblyPath(path):null;
};
var tests=AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.Combine(AppContext.BaseDirectory,"Riftbound.ConformanceTests.dll"));
var build=tests.GetType("Riftbound.ConformanceTests.StandbyDefendTeemoTests")!.GetMethod("BuildState",BindingFlags.Static|BindingFlags.NonPublic)!;
var json=new JsonSerializerOptions(JsonSerializerDefaults.Web){WriteIndented=true};
var rows=new List<object>();var matched=0;var positiveFailures=0;
foreach(var printing in new[]{"OGN·121/298","OGN·121a/298","SFD·230/221","SFD·230*/221"})
foreach(var count in new[]{0,1})
{
    const string attacker="P1-TEEMO-DEFEND-ATTACKER";
    const string defender="P2-TEEMO-FACE-UP-DEFENDER";
    const string field="P1-TEEMO-DEFEND-BATTLEFIELD";
    var state=(MatchState)build.Invoke(null,[printing,false,false,"OGN·296/298","P2",7,false])!;
    var cards=state.CardObjects.ToDictionary(p=>p.Key,p=>p.Value,StringComparer.Ordinal);
    foreach(var id in new[]{"P2-MAIN-STANDBY-001","P2-MAIN-STANDBY-002"})
        if(count==0||id.EndsWith("002",StringComparison.Ordinal))
            cards[id]=cards[id] with {CardNo="SFD·125/221",Tags=[CardObjectTags.UnitCard]};
    var zones=state.PlayerZones.ToDictionary(p=>p.Key,p=>p.Value,StringComparer.Ordinal);
    zones["P1"]=zones["P1"] with {Battlefields=zones["P1"].Battlefields.Where(x=>x!=attacker).ToArray(),Base=[attacker]};
    var locations=state.ObjectLocations.ToDictionary(p=>p.Key,p=>p.Value,StringComparer.Ordinal);
    locations[attacker]=new("P1","BASE");
    state=state with {Tick=0,CardObjects=cards,PlayerZones=zones,ObjectLocations=locations};
    var original=state;var events=new List<GameEvent>();var actions=new List<object>();var engine=new CoreRuleEngine();
    await Act("P1",new MoveUnitCommand(attacker,"BASE","BATTLEFIELD:"+field,[]));
    if(state.PendingCardChoice is not {PlayerId:"P2",RequiredCount:1} choice||!choice.LegalObjectIds.SequenceEqual(new[]{attacker}))
        throw new Exception("Original actual defense must capture and require the one real enemy target before reveal.");
    if(events.Any(e=>e.Kind is "MAIN_DECK_CARDS_REVEALED" or "DAMAGE_APPLIED"))throw new Exception("No premature reveal or damage.");
    await Act("P2",new ChooseCardsCommand(choice.ChoiceId,choice.ChoiceWindow,[attacker]));
    await Act(state.PriorityPlayerId!,new PassPriorityCommand());
    await Act(state.PriorityPlayerId!,new PassPriorityCommand());
    var damage=events.Where(e=>e.Kind=="DAMAGE_APPLIED"&&Equals(e.Payload["sourceObjectId"],defender)).ToArray();
    var actual=damage.Sum(e=>Convert.ToInt32(e.Payload["damage"]));
    var expected=count==0?0:2;
    var pass=actual==expected&&damage.Length==(count==0?0:1);
    if(pass)matched++;else if(count==1)positiveFailures++;
    rows.Add(new{printing,printedStandbyCards=count,expectedDamage=expected,actualDamage=actual,damageActions=damage.Length,sourceGroundedExpectationMatches=pass,actualRuleInputs=state.RuleInputs,allAcceptedOriginalActions=actions,originalControlledInitial=original,final=state,events});
    async Task Act(string actor,GameCommand command){
        var result=await engine.ResolveAsync(state,new("teemo-void-probe-"+actions.Count,actor,command.CmdType),command,default);
        if(!result.Accepted)throw new Exception(result.ErrorMessage);
        actions.Add(new{actor,command=JsonSerializer.SerializeToElement(command,command.GetType(),json),result});events.AddRange(result.Events);state=result.State;
    }
}
if(matched!=4||positiveFailures!=4)throw new Exception("Do not infer the expected counterexample pattern before all eight actual branches are observed.");
await File.WriteAllTextAsync(args[0],JsonSerializer.Serialize(new{status="COUNTEREXAMPLE_FOUR_CURRENT_TEEMO_DEFEND_PRINTINGS_ONE_REVEALED_STANDBY_DEALS1_OMITS_VOID_BONUS_ZERO_REVEALED_CORRECTLY_NO_DAMAGE_ACTION",actualRuleInputs=RuleInputIdentity.Current,actualCases=8,acceptedCommands=32,zeroCountCasesMatch=4,positiveCountMissingBonusCounterexamples=4,isolatedOfflineActualMovementChoiceAndTwoPriorityCommands=true,noRootMutationOrDatabaseOrOldMatchChanged=true,wholePrintingOrAnyFixCertification=false,rows},json));
Console.WriteLine("COUNTEREXAMPLE_OBSERVED: four positive count1 cases damage1 expected2;four zero-count cases correctly no damage action;all32 original commands retained.");
