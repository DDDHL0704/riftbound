using System.Collections.Concurrent;
using System.Reflection;
using System.Runtime.Loader;
using System.Text.Json;
using Riftbound.CardCatalog;
using Riftbound.Contracts;
using Riftbound.Engine;

if (args.Length != 1 || File.Exists(args[0])) throw new Exception("Unused result path required.");
AssemblyLoadContext.Default.Resolving += (context, name) => {
    var path = Path.Combine(AppContext.BaseDirectory, name.Name + ".dll");
    return File.Exists(path) ? context.LoadFromAssemblyPath(path) : null;
};
var assembly = AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.Combine(AppContext.BaseDirectory, "Riftbound.ConformanceTests.dll"));
var type = assembly.GetType("Riftbound.ConformanceTests.FullGameEndToEndTests", throwOnError: true)!;
var seed = Convert.ToInt64(type.GetField("LowCurveReplaySeed", BindingFlags.NonPublic | BindingFlags.Static)!.GetRawConstantValue());
if (seed != 424242) throw new Exception("Original seed must remain unchanged.");
var method = type.GetMethod("AssertFullGameScoreVictoryActionLogReplaysToFinalStateHashAsync", BindingFlags.NonPublic | BindingFlags.Static)
    ?? throw new Exception("Exact original full-game assertion helper required.");
var catalog = await OfficialCardCatalog.LoadDefaultAsync();
var decks = PreconstructedDeckCatalog.Build(catalog);
var pairs = decks.SelectMany(a => decks.Where(b => a.Id != b.Id).Select(b => (A: a, B: b, Id: a.Id + "-vs-" + b.Id))).ToArray();
var teemoPrintings = new[]{"OGN·121/298","OGN·121a/298","SFD·230/221","SFD·230*/221"};
var affectedDecks = decks.Where(d => d.Decklist.Battlefields.Contains("OGN·296/298", StringComparer.Ordinal) || d.Decklist.MainDeck.Any(teemoPrintings.Contains)).Select(d => d.Id).ToHashSet(StringComparer.Ordinal);
var affected = pairs.Where(p => affectedDecks.Contains(p.A.Id) || affectedDecks.Contains(p.B.Id)).ToArray();
if (decks.Count != 11 || pairs.Length != 110 || !affectedDecks.Contains("kaisa-red-control") || affected.Length < 20 || affected.Length > 110) throw new Exception("Original eleven-deck/110-pair universe and exact Teemo-or-Void affected direction set required.");
await File.WriteAllTextAsync(args[0]+".plan.json", JsonSerializer.Serialize(new { seed, decks = decks.Select(d => new { d.Id, exactBattlefields = d.Decklist.Battlefields, exactMainDeck = d.Decklist.MainDeck }), originalAll110Pairs = pairs.Select(p => p.Id).Order().ToArray(), actualAffectedPairs = affected.Select(p => p.Id).Order().ToArray(), originalVictoryReplayAndSeedAssertionsUnchanged = true }, new JsonSerializerOptions { WriteIndented=true }));
var completed = new ConcurrentDictionary<string, string>(StringComparer.Ordinal);
try
{
    await Parallel.ForEachAsync(affected, new ParallelOptions { MaxDegreeOfParallelism = Math.Min(2, Environment.ProcessorCount) }, async (pair, _) => {
        var original = method.Invoke(null, new object[] {
            "b0-full-game-preconstructed-catalog-replay-room-" + pair.Id,
            "b0-full-preconstructed-catalog-replay-score-" + pair.Id, pair.A.Decklist, pair.B.Decklist });
        var hash = await (ValueTask<string>)original!;
        if (!completed.TryAdd(pair.Id, hash)) throw new Exception("Duplicate affected original pair.");
        Console.WriteLine("AFFECTED_ORIGINAL_PAIR_PASS " + JsonSerializer.Serialize(new { pair = pair.Id, finalHash = hash, completed = completed.Count, expected = affected.Length }));
    });
    if (!affected.Select(p => p.Id).Order(StringComparer.Ordinal).SequenceEqual(completed.Keys.Order(StringComparer.Ordinal))) throw new Exception("Missing original affected pair.");
    var result = new { status = "PASS_CURRENT_AFFECTED_ORIGINAL_TEEMO_OR_VOID_PAIR_HELPERS_NOT_ALL110_PUBLIC_METHOD_OR_FULL_CI",
        seed, originalDeckCount = decks.Count, originalFullMatrixPairCount = pairs.Length, affectedDecks = affectedDecks.Order().ToArray(),
        affectedPairs = affected.Select(p => p.Id).Order().ToArray(), completed = completed.OrderBy(p => p.Key).ToDictionary(p => p.Key, p => p.Value),
        actualRuleInputs = RuleInputIdentity.Current, originalVictoryReplayInitialDeckRoomIntentAndSeedAssertionsExecutedUnchanged = true,
        all110MatrixAnd143PublicFullGameMethodSourcesRetained = true, sourceCardPrintingOrWholeFamilyCertification = false };
    await File.WriteAllTextAsync(args[0], JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }));
    Console.WriteLine(result.status);
}
catch (Exception e)
{
    await File.WriteAllTextAsync(args[0] + ".failure.json", JsonSerializer.Serialize(new { status = "FAILED_ADDITIONAL_AFFECTED_ORIGINAL_PAIR_RUN_NOT_FULL_PASS",
        completed, expectedPairs = affected.Select(p => p.Id).ToArray(), error = (e is TargetInvocationException t ? t.InnerException : e)?.ToString() }, new JsonSerializerOptions { WriteIndented = true }));
    throw;
}
