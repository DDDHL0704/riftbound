from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import datetime,hashlib,json,os,subprocess,zipfile
os.umask(0o077);w=Path(__file__).resolve().parent;run=39564582452;fixed='708a3558040f9acd4c66122a00db8ca085f460cf';meta=json.loads((w/'ci708-current-available-artifact-metadata-v1.json').read_text())['response'];folder=w/'ci708-complete-originals-v1';folder.mkdir();names=['postgres-partition-'+str(i) for i in range(4)]+['postgres-results','native-network-results','verification-scope'];rows=[]
def download(name):
 a=next(a for a in meta['artifacts'] if a['name']==name);assert not a['expired'] and a['workflow_run']['head_sha']==fixed;path=folder/(name+'.zip')
 with path.open('xb') as out:r=subprocess.run(['gh','api',f'repos/DDDHL0704/riftbound/actions/artifacts/{a["id"]}/zip'],stdout=out,stderr=subprocess.PIPE)
 assert r.returncode==0,r.stderr.decode()[:200];raw=path.read_bytes();digest=hashlib.sha256(raw).hexdigest();assert len(raw)==a['size_in_bytes'] and 'sha256:'+digest==a['digest']
 with zipfile.ZipFile(path) as z:assert z.testzip() is None
 return {'name':name,'id':a['id'],'path':str(path),'bytes':len(raw),'sha256':digest,'backendDigest':a['digest'],'allZipCrcVerified':True}
try:
 with ThreadPoolExecutor(max_workers=3) as pool:
  for row in pool.map(download,names):rows.append(row);print(row['name'],'ORIGINAL_BACKEND_SIZE_SHA256_CRC_PASS',flush=True)
finally:
 (w/'ci708-available-originals-download-receipt-v1.json').write_text(json.dumps({'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runId':run,'fixedCommit':fixed,'artifacts':rows,'nativePackagesNotRedownloaded':True,'rulesAndWholeRunTerminalNotInferredFromAvailableArtifacts':True},indent=2)+'\n')
