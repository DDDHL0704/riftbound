from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,d:p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
base=json.loads((w/'bounded-teemo-batch-before-source-inputs-v1.json').read_text());paths={r['path'] for r in base['trackedSourceInputs']}
paths.update(['tests/Riftbound.ConformanceTests/CurrentTeemoCountedDamageTests.cs','tests/Riftbound.PostgresAcceptance/TeemoCountedDamageSqlAcceptance.cs'])
inputs={p:sha(root/p) for p in sorted(paths)};modes={p:oct((root/p).stat().st_mode&0o777) for p in inputs}
original_tests=[r for r in base['trackedSourceInputs'] if r['path'].startswith('tests/Riftbound.ConformanceTests/') and r['path'].endswith('.cs')]
assert all(inputs[r['path']]==r['sha256'] for r in original_tests)
full=[r for r in original_tests if Path(r['path']).name.startswith('FullGameEndToEndTests')];assert len(full)==9
runtime=w/'current-counted-runtime-v1';source=root/'tests/Riftbound.PostgresAcceptance/bin/Release/net10.0'
if runtime.exists():
 assert not (w/'current-counted-frozen-runtime-inputs-v1.json').exists() and not (w/'actual-current-counted-sql-v1').exists()
 assert all(sha(runtime/str(p.relative_to(source)))==sha(p) for p in source.rglob('*') if p.is_file())
else:shutil.copytree(source,runtime)
conformance=root/'tests/Riftbound.ConformanceTests/bin/Debug/net10.0'
for name in ['Riftbound.ConformanceTests.dll','Riftbound.ConformanceTests.pdb']+[p.name for p in conformance.glob('xunit*.dll')]:
 assert not (runtime/name).exists() or sha(runtime/name)==sha(conformance/name);shutil.copy2(conformance/name,runtime/name)
references=['Riftbound.Contracts','Riftbound.Engine','Riftbound.CardCatalog','Riftbound.Persistence','Npgsql']
projects=[('current-counted-independent-reader-source-v1','CurrentTeemoCountedDamageIndependentReaderV1'),('affected-original-pair-source-v1','CurrentTeemoAffectedOriginalPairRunnerV1')]
for folder,assembly in projects:
 p=w/folder;project='<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFramework>net10.0</TargetFramework><OutputType>Exe</OutputType><AssemblyName>'+assembly+'</AssemblyName><ImplicitUsings>enable</ImplicitUsings><Nullable>enable</Nullable><UseAppHost>false</UseAppHost></PropertyGroup><ItemGroup>'
 for ref in references:project+='<Reference Include="'+ref+'"><HintPath>'+str(runtime/(ref+'.dll'))+'</HintPath><Private>false</Private></Reference>'
 project+='</ItemGroup></Project>';(p/'probe.csproj').write_text(project)
 with (w/(folder+'-build-v2.log')).open('xb') as log:subprocess.run(['/Users/dinghaolin/.dotnet/dotnet','build',str(p/'probe.csproj'),'--configuration','Release','--nologo'],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
 for suffix in ['.dll','.pdb']:shutil.copy2(p/'bin/Release/net10.0'/(assembly+suffix),runtime/(assembly+suffix))
files={str(p.relative_to(runtime)):sha(p) for p in runtime.rglob('*') if p.is_file()}
assert all(sha(root/p)==h and oct((root/p).stat().st_mode&0o777)==modes[p] for p,h in inputs.items())
assert all((runtime/p).stat().st_ino!=(source/p).stat().st_ino for p in files if (source/p).is_file())
command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(runtime/'Riftbound.PostgresAcceptance.deps.json'),'--runtimeconfig',str(runtime/'Riftbound.PostgresAcceptance.runtimeconfig.json'),str(runtime/'CurrentTeemoCountedDamageIndependentReaderV1.dll'),'--identity']
identity=json.loads(subprocess.check_output(command,cwd=runtime,env=dict(os.environ,DOTNET_DbgEnableMiniDump='0')))
assert identity['authoritySha256']=='70ccda5893a1b8b56cdceadee35e084b1e3f5b297ef64e1ce7d0cbeb141ce2d4'
assert identity['catalogSha256']!='a940e5f8bcd5e1ead68a85c7f983e530333d6179a4b8429ed1f8fe2ee20b8397'
write(w/'current-counted-frozen-runtime-inputs-v1.json',{'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parentCommit':base['head'],'runtimeRoot':str(runtime),'runtimeFiles':files,'sourceInputHashes':inputs,'sourceInputModes':modes,'actualRuleInputs':identity,'declaredUncommittedChanges':subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).splitlines(),'allOriginalConformanceCSharpSourcesByteExact':True,'allNineOriginalFullGameSourcesByteExact':full,'helperAssemblies':[a for _,a in projects],'independentRuntimeNoMutableRootInodesShared':True})
print('Frozen:',len(files),'runtime files;',len(inputs),'source inputs; actual identity',identity['identitySha256'])
