from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();old=json.loads((w/'current-counted-frozen-runtime-inputs-v1.json').read_text());previous=Path(old['runtimeRoot']);assert all(sha(previous/p)==h for p,h in old['runtimeFiles'].items())
source=root/'tests/Riftbound.PostgresAcceptance/bin/Release/net10.0';runtime=w/'current-counted-runtime-v2';runtime.mkdir();replaced=[];links=[]
for p in source.rglob('*'):
 if not p.is_file():continue
 name=str(p.relative_to(source));target=runtime/name;target.parent.mkdir(parents=True,exist_ok=True)
 if name in ['Riftbound.PostgresAcceptance.dll','Riftbound.PostgresAcceptance.pdb']:
  shutil.copy2(p,target);replaced.append(name)
 else:
  assert sha(p)==old['runtimeFiles'][name],name
  target.symlink_to(previous/name);links.append({'path':name,'target':str(previous/name),'sha256':sha(target)})
reader=w/'current-counted-independent-reader-source-v2';assembly='CurrentTeemoCountedDamageIndependentReaderV2'
with (w/'current-counted-independent-reader-source-v2-build-v1.log').open('xb') as log:subprocess.run(['/Users/dinghaolin/.dotnet/dotnet','build',str(reader/'probe.csproj'),'--configuration','Release','--nologo'],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
for suffix in ['.dll','.pdb']:shutil.copy2(reader/'bin/Release/net10.0'/(assembly+suffix),runtime/(assembly+suffix))
inputs={p:sha(root/p) for p in old['sourceInputHashes']};changed=[p for p,h in old['sourceInputHashes'].items() if inputs[p]!=h];assert changed==['tests/Riftbound.PostgresAcceptance/TeemoCountedDamageSqlAcceptance.cs'],changed
files={str(p.relative_to(runtime)):sha(p) for p in runtime.rglob('*') if p.is_file()};cmd=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(runtime/'Riftbound.PostgresAcceptance.deps.json'),'--runtimeconfig',str(runtime/'Riftbound.PostgresAcceptance.runtimeconfig.json'),str(runtime/(assembly+'.dll')),'--identity'];identity=json.loads(subprocess.check_output(cmd,cwd=runtime));assert identity==old['actualRuleInputs']
proof={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parentCommit':old['parentCommit'],'runtimeRoot':str(runtime),'runtimeFiles':files,'sourceInputHashes':inputs,'sourceInputModes':old['sourceInputModes'],'actualRuleInputs':identity,'onlyChangedRootSourceSinceV1':changed,'onlySqlWriterAndIndependentReaderJsonbNumericOracleFixed':True,'allGameplayCatalogConformanceAndOriginalFullGameInputsExactV1':True,'immutablePriorRuntimeLinks':links,'runtimeInodesNotLinkedToMutableRootBuildOutputs':True,'physicalNewRuntimePayloads':replaced+[assembly+'.dll',assembly+'.pdb'],'independentReaderSourceHashes':{p.name:sha(p) for p in reader.iterdir() if p.is_file()},'oldFailedActualCaseAndRuntimeRetained':True}
(w/'current-counted-frozen-runtime-inputs-v2.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');print('Frozen V2',len(files),'runtime entries;',len(links),'links to pinned immutable V1; only4 new payload files; same gameplay identity',identity['identitySha256'])
