from pathlib import Path
import ast,datetime,fcntl,hashlib,json,os,plistlib,resource,socket,subprocess
resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.umask(0o077)
root=Path('/Users/dinghaolin/MyProjects/riftbound');w=Path(__file__).resolve().parent
pg=Path('/opt/homebrew/Cellar/postgresql@16/16.13/bin');cluster=root/'var/qa/permanent-play-here-base-20261017/postgres';sock=Path('/tmp/rft-here-family-20261018-55486')
tables=['matches','match_players','command_log','game_events','state_snapshots','snapshots','action_prompts']
read_env=dict(os.environ,PGOPTIONS='-c default_transaction_read_only=on')
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
definition=root/'var/qa/graveyard-source-fixed-candidate-20261020/run-visible-native-api-v1.py'
nodes=[n for n in ast.parse(definition.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'query','rooms','digests','observe_lock'}];exec(compile(ast.Module(body=nodes,type_ignores=[]),str(definition),'exec'),globals())
frozen=load(w/'current-counted-frozen-runtime-inputs-v2.json');runtime=Path(frozen['runtimeRoot'])
old=load(w/'actual-current-counted-sql-owner-terminal-v2.json');old_audit=old['actualAuditRoomsAtStop'];old_native=old['actualNativeRoomsAtStop'];assert len(old_audit)==276 and len(old_native)==60
stable=lambda:all(sha(runtime/p)==h for p,h in frozen['runtimeFiles'].items()) and all(sha(root/p)==h and oct((root/p).stat().st_mode&0o777)==frozen['sourceInputModes'][p] for p,h in frozen['sourceInputHashes'].items())
guard=(root/'var/qa/ravenbloom-paired-20261018/without-desktop.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
terminal=w/'actual-current-counted-sql-owner-terminal-v3.json';assert not terminal.exists()
proof={'status':'RUNNING_CURRENT_TEEMO_COUNTED_SQL','startedAtUtc':now(),'parentCommit':frozen['parentCommit'],'actualRuleInputs':frozen['actualRuleInputs'],'declaredUncommittedBoundedBatch':True,'lockAtStart':observe_lock(),'allOriginalRoomsActionsAndReplayMetadataRetained':True,'original53SqlIdentitiesAndOrderRetainedOnly54thAppended':True}
started=False;power=writer=independent=None;before_audit=before_native=None
try:
 assert stable();assert subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 with socket.socket() as s:assert s.connect_ex(('127.0.0.1',15847))!=0
 power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())]);proof['boundIdleAssertionPid']=power.pid;sock.mkdir(exist_ok=True)
 subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-l',str(w/'current-counted-postgres-v3.log'),'-o',f'-p 55486 -h 127.0.0.1 -k {sock}','-w','start'],capture_output=True,check=True);started=True
 assert rooms('riftbound_acceptance')==old_audit and rooms('riftbound_here_native')==old_native
 before_audit=digests('riftbound_acceptance',old_audit);before_native=digests('riftbound_here_native',old_native)
 (w/'original276-audit60-native-seven-table-baseline-v1.json').write_text(json.dumps({'atUtc':now(),'auditRooms':old_audit,'nativeRooms':old_native,'auditSevenTables':before_audit,'nativeSevenTables':before_native},indent=2)+'\n')
 output=w/'actual-current-counted-sql-v3';assert not output.exists()
 env=dict(os.environ,ConnectionStrings__Riftbound='Host=127.0.0.1;Port=55486;Database=riftbound_acceptance;Username=codex_riftbound_audit',RIFTBOUND_POSTGRES_EVIDENCE=str(output),DOTNET_DbgEnableMiniDump='0')
 command=['/Users/dinghaolin/.dotnet/dotnet',str(runtime/'Riftbound.PostgresAcceptance.dll'),'--teemo-counted-damage-only'];proof['actualWriterCommand']=command
 with (w/'actual-current-counted-writer-v3.log').open('xb') as log:writer=subprocess.Popen(command,cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT);proof['writerExitCode']=writer.wait(timeout=300)
 assert proof['writerExitCode']==0
 receipts=[load(p) for p in (output/'teemo-counted-damage').rglob('receipt.json')];assert len(receipts)==12
 expected={(p,c) for p in ['OGN·121/298','OGN·121a/298','SFD·230/221','SFD·230*/221'] for c in range(3)};assert {(r['printing'],r['printedCount']) for r in receipts}==expected
 assert all(r['commands']==r['coldRecoveries']==4 and r['directAtomicRejections']==r['independentStructuralRejections']==4 and r['rootIntegration'] and r['actualRuleInputs']==frozen['actualRuleInputs'] for r in receipts)
 added={r['room'] for r in receipts};assert len(added)==12 and set(rooms('riftbound_acceptance'))==set(old_audit)|added and rooms('riftbound_here_native')==old_native
 proof.update(writerCases=12,receipts=receipts,commands=48,events=sum(r['events'] for r in receipts),coldRecoveries=48,directAtomicRejections=48,writerIndependentStructuralRejections=48,newRooms=sorted(added));print('CURRENT_COUNTED_SQL_WRITER_PASS12cases48commands',flush=True)
 result=w/'independent-current-counted-all-history-v3.json';command=['/Users/dinghaolin/.dotnet/dotnet','exec','--depsfile',str(runtime/'Riftbound.PostgresAcceptance.deps.json'),'--runtimeconfig',str(runtime/'Riftbound.PostgresAcceptance.runtimeconfig.json'),str(runtime/'CurrentTeemoCountedDamageIndependentReaderV2.dll'),str(output/'teemo-counted-damage'),str(result)];proof['actualReadOnlyReaderCommand']=command
 with (w/'independent-current-counted-all-history-v3.log').open('xb') as log:independent=subprocess.Popen(command,cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT);proof['independentExitCode']=independent.wait(timeout=300)
 assert proof['independentExitCode']==0
 actual=load(result);proof['independentReadback']=actual;assert actual['cases']==12 and actual['commands']==actual['authoritativeHistoricalStates']==48 and actual['independentStructuralRejections']==48 and actual['events']==proof['events'] and set(actual['rooms'])==added and actual['actualRuleInputs']==frozen['actualRuleInputs'] and actual['actualReadOnlyConnection']
 proof['status']='PASS_CURRENT_TEEMO_TWELVE_COUNTED_DEFENSES_REAL_SQL_COLD_DEDUP_INDEPENDENT_ALL_HISTORY_ORIGINAL_REPLAY';print(proof['status'],flush=True)
except BaseException as error:
 proof.update(status='FAILED_CURRENT_TEEMO_COUNTED_SQL_OR_INDEPENDENT_READBACK_ORIGINALS_RETAINED',errorType=type(error).__name__,error=str(error));raise
finally:
 for process in [writer,independent]:
  if process and process.poll() is None:process.terminate();process.wait(timeout=20)
 if started:
  try:
   if before_audit is not None:proof['allOriginal276AuditSevenTablesExactAtStop']=digests('riftbound_acceptance',old_audit)==before_audit
   if before_native is not None:proof['allOriginal60NativeSevenTablesExactAtStop']=digests('riftbound_here_native',old_native)==before_native
   proof['actualAuditRoomsAtStop']=rooms('riftbound_acceptance');proof['actualNativeRoomsAtStop']=rooms('riftbound_here_native')
  except BaseException as cleanup_error:proof['cleanupReadError']=str(cleanup_error)
  finally:
   stop=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'-m','fast','-w','stop'],capture_output=True,text=True);proof['ownPostgresNormalStopExitCode']=stop.returncode;proof['ownPostgresStopped']=subprocess.run([str(pg/'pg_ctl'),'-D',str(cluster),'status'],capture_output=True).returncode==3
 if power:
  if power.poll() is None:power.terminate()
  power.wait(timeout=10)
 proof.update(finishedAtUtc=now(),lockAtStop=observe_lock(),allFrozenInputsStable=stable());terminal.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
