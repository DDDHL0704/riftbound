from pathlib import Path
import datetime,hashlib,json,subprocess,types,zipfile
w=Path(__file__).resolve().parent;root=w.parents[2];fixed='708a3558040f9acd4c66122a00db8ca085f460cf';run=json.loads(subprocess.check_output(['gh','run','view','39564582452','--json','headSha,status,conclusion,jobs'],cwd=root,text=True,timeout=35));assert run['headSha']==fixed
jobs={j['name']:j['conclusion'] for j in run['jobs']};assert all(jobs[k]=='success' for k in ['scope','native_network','postgres']+['postgres_partitions ('+str(i)+')' for i in range(4)])
d=json.loads((w/'ci708-seven-complete-available-originals-recovery-v2.json').read_text());artifacts={a['name']:a for a in d['artifacts']};folder=w/'ci708-independent-sql-members-v1';folder.mkdir()
for i in range(4):
 a=artifacts['postgres-partition-'+str(i)];p=Path(a['path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==a['sha256'];target=folder/str(i);target.mkdir()
 with zipfile.ZipFile(p) as z:
  assert z.testzip() is None
  for name in z.namelist():
   assert not Path(name).is_absolute() and '..' not in Path(name).parts
   if name.endswith('/'):continue
   output=target/name;output.parent.mkdir(parents=True,exist_ok=True);output.write_bytes(z.read(name))
manifest=w/'exact-fixed708-sql-manifest-original-v1.json';raw=subprocess.check_output(['git','show',fixed+':tests/Riftbound.PostgresAcceptance/SqlAcceptanceCases.json'],cwd=root);manifest.write_bytes(raw);data=json.loads(raw);assert len(data['cases'])==52 and data['cases'][-1]['id']=='battlefield-spell-damage'
source=subprocess.check_output(['git','show',fixed+':scripts/sql-ci-gate.py'],cwd=root);module=types.ModuleType('exact_fixed708_sql_gate');exec(compile(source,'<exact-fixed708-sql-gate>','exec'),module.__dict__);sql=module.verify(fixed,manifest,folder,{'scope':jobs['scope'],'postgres_partitions':jobs['postgres'],'native_network':jobs['native_network']});assert sql['caseCount']==52
with zipfile.ZipFile(artifacts['postgres-results']['path']) as z:assert json.loads(z.read('result.json'))==sql
with zipfile.ZipFile(artifacts['native-network-results']['path']) as z:
 assert z.read('commit.txt').decode().strip()==fixed;log=z.read('native-network.log').decode();e=next(json.loads(line[len('NATIVE_ROOM_IDENTITY_EVIDENCE '):]) for line in log.splitlines() if line.startswith('NATIVE_ROOM_IDENTITY_EVIDENCE '));assert e['rejectedActions']==15 and e['leakedPrivateMessages']==0 and e['validReconnectTokenWasSupplied'];assert 'Native network recovery passed: socket loss, authenticated room restore, fresh snapshot, rejected-token guard.' in log
proof={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'FIXED708_COMPLETE52_SQL_AND_NETWORK_ORIGINALS_INDEPENDENT_GATE_PASS_RULES_FULL_TERMINAL_SEPARATE','runId':39564582452,'fixedCommit':fixed,'actualRunAtRead':run,'sql':sql,'network':e,'exactOld52ManifestSha256':hashlib.sha256(raw).hexdigest(),'exactFixedSqlGateSourceSha256':hashlib.sha256(source).hexdigest(),'originalSevenVerificationArtifacts':d['artifacts'],'currentRoot54ManifestNotSubstituted':True,'nativeInstallersNotRedownloaded':True,'currentN36FullOrWholePrintingCertification':False};(w/'ci708-complete52-sql-network-independent-verification-v1.json').write_text(json.dumps(proof,indent=2)+'\n');print('PASS fixed708 all52 SQL, original four partitions+stable postgres+network; current54 manifest not substituted;whole rules run',run['status'],run['conclusion'])
