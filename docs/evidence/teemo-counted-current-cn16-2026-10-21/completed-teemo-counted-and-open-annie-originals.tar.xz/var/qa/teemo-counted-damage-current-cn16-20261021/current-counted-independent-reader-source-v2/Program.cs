using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Nodes;
using Npgsql;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.Persistence;

if(args.SequenceEqual(new[]{"--identity"})){Console.WriteLine(JsonSerializer.Serialize(RuleInputIdentity.Current,new JsonSerializerOptions(JsonSerializerDefaults.Web){WriteIndented=true}));return;}
Check(args.Length==2&&!File.Exists(args[1]),"Exact evidence directory and fresh independent output required.");
var work=Path.GetFullPath(args[0]);var output=Path.GetFullPath(args[1]);var json=new JsonSerializerOptions(JsonSerializerDefaults.Web){WriteIndented=true};
var settings=new NpgsqlConnectionStringBuilder(Environment.GetEnvironmentVariable("ConnectionStrings__Riftbound"));Check(settings.Host=="127.0.0.1"&&settings.Port==55486&&settings.Database=="riftbound_acceptance"&&settings.Username=="codex_riftbound_audit","Only own audit database.");settings.Options="-c default_transaction_read_only=on";await using var source=NpgsqlDataSource.Create(settings.ConnectionString);
var results=new List<object>();var rooms=new List<string>();var totalStates=0;var totalSnapshots=0;var totalPrompts=0;var totalCommands=0;var totalEvents=0;var rejections=0;
foreach(var receiptPath in Directory.GetFiles(work,"receipt.json",SearchOption.AllDirectories).Order(StringComparer.Ordinal))
{
    var directory=Path.GetDirectoryName(receiptPath)!;using var receipt=JsonDocument.Parse(File.ReadAllText(receiptPath));
    var printing=receipt.RootElement.GetProperty("printing").GetString()!;var printedCount=receipt.RootElement.GetProperty("printedCount").GetInt32();var room=receipt.RootElement.GetProperty("room").GetString()!;rooms.Add(room);
    Check(receipt.RootElement.GetProperty("rootIntegration").GetBoolean()&&printedCount is >=0 and <=2,"Exact integrated printing/count receipt.");
    var initial=JsonSerializer.Deserialize<MatchState>(File.ReadAllText(Path.Combine(directory,"explicit-original-controlled-initial.json")),json)!;
    var frame=await new PostgresMatchRecoveryStore(source).LoadAsync(room,default)??throw new Exception("Real retained SQL frame required.");using var original=Read(Path.Combine(directory,"step-04-original-frame.json.gz"));
    Check(Same(original.RootElement,JsonSerializer.SerializeToElement(frame,json)),"Every original final SQL frame field/null/omission equals the independent read.");
    Check(frame.IsConsistent&&frame.Commands.Count==4&&frame.Commands.Count==receipt.RootElement.GetProperty("commands").GetInt32()&&frame.Events.Count==receipt.RootElement.GetProperty("events").GetInt32()&&initial.RoomId==room&&initial.Tick==0&&initial.RuleInputs==RuleInputIdentity.Current&&frame.AuthoritativeState!.RuleInputs==RuleInputIdentity.Current,"Exact original controlled initial and actual current input identity.");
    Check(frame.ReplayInitialState is {Tick:0,CardObjects.Count:0}&&!Same(JsonSerializer.SerializeToElement(initial,json),JsonSerializer.SerializeToElement(frame.ReplayInitialState,json)),"Original blank replay metadata is retained separately from the explicit original controlled initial.");
    using var intents=JsonDocument.Parse(File.ReadAllText(Path.Combine(directory,"all-original-accepted-intents.json")));Check(intents.RootElement.GetArrayLength()==frame.Commands.Count,"All original accepted intents retained.");
    for(var i=0;i<frame.Commands.Count;i++)Check(frame.Commands[i].Accepted&&frame.Commands[i].RuleInputs==RuleInputIdentity.Current&&frame.Commands[i].PlayerId==intents.RootElement[i].GetProperty("actor").GetString()&&Same(frame.Commands[i].RawCommand!.Value,intents.RootElement[i].GetProperty("rawCommand")),"Every original actor, complete raw intent and input identity exact.");
    var states=new Dictionary<(long,long),MatchState>();var counts=new Dictionary<string,int>();
    await using(var connection=await source.OpenConnectionAsync())
    {
        Check((string)(await new NpgsqlCommand("show transaction_read_only",connection).ExecuteScalarAsync())! =="on","Actual read-only SQL session.");
        await using(var q=new NpgsqlCommand("select last_event_sequence,payload::text from state_snapshots where match_id=@room order by id",connection))
        {
            q.Parameters.AddWithValue("room",room);await using var rows=await q.ExecuteReaderAsync();
            while(await rows.ReadAsync())
            {
                var raw=rows.GetString(1);var state=JsonSerializer.Deserialize<MatchState>(raw,json)!;
                Check(JsonNode.DeepEquals(JsonNode.Parse(raw),JsonSerializer.SerializeToNode(state,json))&&state.RuleInputs==RuleInputIdentity.Current&&states.TryAdd((state.Tick,rows.GetInt64(0)),state),"All original authority fields/nulls, current identity and tick/event-sequence identity survive independent read.");
                Check(state.CardObjects["DEFENDER"].CardNo==printing&&state.CardObjects["FIELD"].CardNo=="OGN·296/298"&&state.CardObjects["ATTACKER"].Damage is >=0&&state.CardObjects["ATTACKER"].Damage==(state.CardObjects["ATTACKER"].Damage==0?0:printedCount+1),"Literal counted-defense identities and bounded damage in every retained state.");
                Check(printedCount>0||state.CardObjects["ATTACKER"].Damage==0,"Zero printed count never creates damage.");
                Check(Same(JsonSerializer.SerializeToElement(state.RunePools,json),JsonSerializer.SerializeToElement(initial.RunePools,json)),"Original resources never change during the no-cost defense skill.");
                if(state.PendingCardChoice is { } choice)Check(choice.PlayerId=="P2"&&choice.RequiredCount==1&&choice.LegalObjectIds.SequenceEqual(new[]{"ATTACKER"})&&state.PlayerZones["P2"].MainDeck.SequenceEqual(new[]{"TOP1","TOP2","TOP3","TOP4","TOP5","LOWER"}),"Exactly one enemy target is confirmed before the original five cards are revealed.");
            }
        }
        Check(states.Count==frame.Commands.Count&&frame.Commands.All(c=>states.ContainsKey((c.CompletedTick,c.CompletedEventSequence))),"Each accepted command retains its exact authoritative historical row.");
        var latest=frame.Commands.GroupBy(c=>c.CompletedTick).Select(g=>g.OrderBy(c=>c.CompletedEventSequence).Last()).ToArray();var expected=latest.SelectMany(c=>new[]{"P1","P2"}.Select(p=>(c.CompletedTick,c.CompletedEventSequence,p))).ToHashSet();
        foreach(var table in new[]{"snapshots","action_prompts"})
        {
            var column=table=="snapshots"?"snapshot_tick":"prompt_tick";await using(var constraint=new NpgsqlCommand($"select pg_get_constraintdef(oid) from pg_constraint where conrelid='{table}'::regclass and contype='u'",connection))Check((string)(await constraint.ExecuteScalarAsync())! ==$"UNIQUE (match_id, player_id, {column})","Actual existing private storage key is viewer/tick.");
            await using var q=new NpgsqlCommand($"select player_id,last_event_sequence,payload::text from {table} where match_id=@room order by id",connection);q.Parameters.AddWithValue("room",room);await using var rows=await q.ExecuteReaderAsync();var actual=new HashSet<(long,long,string)>();
            while(await rows.ReadAsync())
            {
                var actor=rows.GetString(0);var sequence=rows.GetInt64(1);var raw=rows.GetString(2);using var doc=JsonDocument.Parse(raw);var tick=doc.RootElement.GetProperty(table=="snapshots"?"tick":"snapshotTick").GetInt64();Check(states.TryGetValue((tick,sequence),out var state)&&actual.Add((tick,sequence,actor)),"Each private original row binds its original authority, sequence, tick and viewer.");
                var typed=table=="snapshots"?JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<SnapshotDto>(raw,json),json):JsonSerializer.SerializeToNode(JsonSerializer.Deserialize<ActionPromptDto>(raw,json),json);Check(JsonNode.DeepEquals(JsonNode.Parse(raw),typed),"Every private field/null and conditional omission survives typed read.");
                var projection=table=="snapshots"?JsonSerializer.SerializeToNode(ResolutionResult.BuildSnapshots(state!)[actor],json):JsonSerializer.SerializeToNode(ResolutionResult.BuildPrompts(state!)[actor],json);Check(JsonNode.DeepEquals(JsonNode.Parse(raw),projection),"Every original private value equals its exact historical state projection.");
                var other=actor=="P1"?"P2":"P1";var visible=state!.PendingEffectPlay?.RevealedHand?.Cards.Keys.ToHashSet()??new HashSet<string>();
                foreach(var id in state.PlayerZones[other].MainDeck.Concat(state.PlayerZones[other].Hand).Except(visible))Check(!raw.Contains("\""+id+"\"",StringComparison.Ordinal),"Literal opponent hidden identity absent outside the original reveal window.");
                Check(!raw.Contains("\"HIDDEN_DECK\"",StringComparison.Ordinal)&&!doc.RootElement.TryGetProperty("openingSeed",out _),"Unrelated original deck identity and private opening seed never leak.");

            }
            Check(actual.SetEquals(expected),"Both players retain exactly the latest original projection at each tick according to the actual existing key; no missing historical authority.");counts[table]=actual.Count;
        }
    }
    foreach(var pair in states)
    {
        var commands=frame.Commands.Where(c=>c.CompletedEventSequence<=pair.Key.Item2).ToArray();var events=frame.Events.Where(e=>e.Sequence<=pair.Key.Item2).ToArray();
        var verified=await MatchActionLogReplayer.VerifyFinalStateAsync(initial,commands,pair.Value,new CoreRuleEngine(),default,events);Check(verified.IsMatch,"Every original authority history independently replays from its exact original controlled initial: "+string.Join(';',verified.Errors));
    }
    using var pendingDocument=Read(Path.Combine(directory,"step-01-original-frame.json.gz"));var pending=pendingDocument.RootElement.Deserialize<MatchRecoveryFrame>(json)!;var pendingState=pending.AuthoritativeState!;var capturedChoice=pendingState.PendingCardChoice!;
    Check(pending.Commands.Count==1&&pending.Events.All(e=>e.Event.Kind is not("MAIN_DECK_CARDS_REVEALED" or "DAMAGE_APPLIED" or "CARDS_RECYCLED")),"Real movement captures the target choice before any reveal, damage or recycling.");
    foreach(var bad in new[]{capturedChoice with {PlayerId="P1"},capturedChoice with {LegalObjectIds=["DEFENDER"]},capturedChoice with {SourceObjectId="ATTACKER"},capturedChoice with {RequiredCount=0}})
    {
        var forged=pendingState with {PendingCardChoice=bad};Check(MatchRecoveryValidator.Validate(room,pending.LastEventSequence,pending.Commands,pending.Events,pending.PlayerViews,forged,pending.CurrentTick,pending.SpectatorReplayFrame).Count>0,"Independent actor/target/source/mandatory-count substitution rejects with all original frame inputs.");rejections++;
    }
    var revealed=frame.Events.Where(e=>e.Event.Kind=="MAIN_DECK_CARDS_REVEALED").ToArray();var damage=frame.Events.Where(e=>e.Event.Kind=="DAMAGE_APPLIED").ToArray();
    Check(revealed.Length==1&&JsonSerializer.SerializeToElement(revealed[0].Event.Payload["damageAmount"],json).GetInt32()==printedCount&&damage.Length==(printedCount==0?0:1),"Literal independent reveal count and zero/one damage action.");
    Check(printedCount==0||JsonSerializer.SerializeToElement(damage.Single().Event.Payload["damage"],json).GetInt32()==printedCount+1,"A positive counted Deal action receives the one Void Gate bonus.");
    Check(frame.AuthoritativeState!.CardObjects["ATTACKER"].Damage==(printedCount==0?0:printedCount+1)&&frame.AuthoritativeState.PlayerZones["P2"].MainDeck[0]=="LOWER"&&frame.AuthoritativeState.PlayerZones["P2"].MainDeck.Skip(1).Order().SequenceEqual(new[]{"TOP1","TOP2","TOP3","TOP4","TOP5"}),"Original target damage, untouched lower card and all five recycled identities.");
    totalStates+=states.Count;totalSnapshots+=counts["snapshots"];totalPrompts+=counts["action_prompts"];totalCommands+=frame.Commands.Count;totalEvents+=frame.Events.Count;results.Add(new{printing,printedCount,room,commands=frame.Commands.Count,events=frame.Events.Count,states=states.Count,snapshots=counts["snapshots"],prompts=counts["action_prompts"],allFieldsAndEveryOriginalHistoricalReplayExact=true});
}
Check(results.Count==12&&rooms.Distinct().Count()==12&&totalCommands==48,"Every four-printing/three-count case must execute exactly once.");
await File.WriteAllTextAsync(output,JsonSerializer.Serialize(new{status="PASS_INDEPENDENT_CURRENT_TEEMO_FOUR_PRINTINGS_THREE_COUNTS_ALL_HISTORY_ORIGINAL_REPLAY",rooms,cases=12,commands=totalCommands,events=totalEvents,authoritativeHistoricalStates=totalStates,privateSnapshots=totalSnapshots,privatePrompts=totalPrompts,independentStructuralRejections=rejections,actualRuleInputs=RuleInputIdentity.Current,results,actualReadOnlyConnection=true,originalBlankReplayMetadataNotRewritten=true,rootIntegration=true,wholePrintingOrProductCertification=false},json));
Console.WriteLine($"CURRENT_TEEMO_INDEPENDENT_PASS {totalCommands} commands {totalEvents} events {totalStates} states {totalSnapshots} snapshots {totalPrompts} prompts {rejections} structural rejects");
static JsonDocument Read(string path){using var zip=new GZipStream(File.OpenRead(path),CompressionMode.Decompress);return JsonDocument.Parse(zip);}
static void Check(bool value,string message){if(!value)throw new Exception(message);}

bool Same(JsonElement left,JsonElement right)=>JsonNode.DeepEquals(JsonNode.Parse(left.GetRawText()),JsonNode.Parse(right.GetRawText()));
