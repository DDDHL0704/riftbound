using System.Reflection;
using System.Runtime.Loader;
using System.Text.Json;
using Riftbound.Contracts;
using Riftbound.Engine;

AssemblyLoadContext.Default.Resolving+=(_,name)=>{
    var path=Path.Combine(AppContext.BaseDirectory,name.Name+".dll");
    return File.Exists(path)?AssemblyLoadContext.Default.LoadFromAssemblyPath(path):null;
};
var tests=AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.Combine(AppContext.BaseDirectory,"Riftbound.ConformanceTests.dll"));
var build=tests.GetType("Riftbound.ConformanceTests.StandbyDefendTeemoTests")!.GetMethod("BuildState",BindingFlags.Static|BindingFlags.NonPublic)!;
var json=new JsonSerializerOptions(JsonSerializerDefaults.Web){WriteIndented=true};
var rows=new List<object>();var matched=0;var positiveFailures=0;
const string printing="OGN·121/298";
foreach(var variant in new[]{"own-base","other-base","own-hand"})
foreach(var count in new[]{0,1})
{
    const string attacker="P1-TEEMO-DEFEND-ATTACKER";
    const string defender="P2-TEEMO-FACE-UP-DEFENDER";
    const string field="P1-TEEMO-DEFEND-BATTLEFIELD";
    var state=(MatchState)build.Invoke(null,[printing,false,false,"OGN·278/298","P2",7,false])!;
    var cards=state.CardObjects.ToDictionary(p=>p.Key,p=>p.Value,StringComparer.Ordinal);
    foreach(var id in new[]{"P2-MAIN-STANDBY-001","P2-MAIN-STANDBY-002"})
        if(count==0||id.EndsWith("002",StringComparison.Ordinal))
            cards[id]=cards[id] with {CardNo="SFD·125/221",Tags=[CardObjectTags.UnitCard]};
    var zones=state.PlayerZones.ToDictionary(p=>p.Key,p=>p.Value,StringComparer.Ordinal);
    zones["P1"]=zones["P1"] with {Battlefields=zones["P1"].Battlefields.Where(x=>x!=attacker).ToArray(),Base=[attacker]};
    var locations=state.ObjectLocations.ToDictionary(p=>p.Key,p=>p.Value,StringComparer.Ordinal);
    locations[attacker]=new("P1","BASE");
    state=state with {Tick=0,CardObjects=cards,PlayerZones=zones,ObjectLocations=locations};
    var bonusController=variant=="other-base"?"P1":"P2";
    cards["ANNIE_BONUS_SOURCE"]=new("ANNIE_BONUS_SOURCE",cardNo:"OGS·001/024",power:4,tags:[CardObjectTags.UnitCard],ownerId:bonusController,controllerId:bonusController);
    zones[bonusController]=variant=="own-hand"?zones[bonusController] with {Hand=zones[bonusController].Hand.Append("ANNIE_BONUS_SOURCE").ToArray()}:zones[bonusController] with {Base=zones[bonusController].Base.Append("ANNIE_BONUS_SOURCE").ToArray()};
    locations["ANNIE_BONUS_SOURCE"]=new(bonusController,variant=="own-hand"?"HAND":"BASE");
    state=state with {CardObjects=cards,PlayerZones=zones,ObjectLocations=locations};
    var original=state;var events=new List<GameEvent>();var actions=new List<object>();var engine=new CoreRuleEngine();
    await Act("P1",new MoveUnitCommand(attacker,"BASE","BATTLEFIELD:"+field,[]));
    if(state.PendingCardChoice is not {PlayerId:"P2",RequiredCount:1} choice||!choice.LegalObjectIds.SequenceEqual(new[]{attacker}))
        throw new Exception("Original actual defense must capture and require the one real enemy target before reveal.");
    if(events.Any(e=>e.Kind is "MAIN_DECK_CARDS_REVEALED" or "DAMAGE_APPLIED"))throw new Exception("No premature reveal or damage.");
    await Act("P2",new ChooseCardsCommand(choice.ChoiceId,choice.ChoiceWindow,[attacker]));
    await Act(state.PriorityPlayerId!,new PassPriorityCommand());
    await Act(state.PriorityPlayerId!,new PassPriorityCommand());
    var damage=events.Where(e=>e.Kind=="DAMAGE_APPLIED"&&Equals(e.Payload["sourceObjectId"],defender)).ToArray();
    var actual=damage.Sum(e=>Convert.ToInt32(e.Payload["damage"]));
    var expected=count==0?0:variant=="own-base"?2:1;
    var pass=actual==expected&&damage.Length==(count==0?0:1);
    if(pass)matched++;else if(count==1)positiveFailures++;
    rows.Add(new{variant,printing,printedStandbyCards=count,expectedDamage=expected,actualDamage=actual,damageActions=damage.Length,sourceGroundedExpectationMatches=pass,actualRuleInputs=state.RuleInputs,allAcceptedOriginalActions=actions,originalControlledInitial=original,final=state,events});
    async Task Act(string actor,GameCommand command){
        var result=await engine.ResolveAsync(state,new("teemo-void-probe-"+actions.Count,actor,command.CmdType),command,default);
        if(!result.Accepted)throw new Exception(result.ErrorMessage);
        actions.Add(new{actor,command=JsonSerializer.SerializeToElement(command,command.GetType(),json),result});events.AddRange(result.Events);state=result.State;
    }
}
if(matched!=5||positiveFailures!=1)throw new Exception("Do not infer the expected counterexample pattern before all eight actual branches are observed.");
await File.WriteAllTextAsync(args[0],JsonSerializer.Serialize(new{status="COUNTEREXAMPLE_CURRENT_TEEMO_ONE_COUNT_WITH_OWN_ON_FIELD_ANNIE_OMITS_GLOBAL_SKILL_BONUS_ZERO_OTHER_CONTROLLER_AND_HAND_CONTROLS_MATCH",actualRuleInputs=RuleInputIdentity.Current,actualCases=6,acceptedCommands=24,matchingControls=5,positiveOwnFaceUpAnnieMissingBonusCounterexamples=1,neutralBandleTreeAvoidsVoidConfounder=true,isolatedOfflineActualMovementChoiceAndTwoPriorityCommands=true,noRootMutationOrDatabaseOrOldMatchChanged=true,wholePrintingOrAnyFixCertification=false,rows},json));
Console.WriteLine("COUNTEREXAMPLE_OBSERVED: one own-on-field Annie count1 case damage1 expected2;five zero/other-controller/hand controls match;all24 original commands retained.");
