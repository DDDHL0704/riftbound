let params = {
    pageNum: 1,
    pageSize: 20,
    searchContent: '',
    cardCategoryList: [],
    cardColorList: [],
    rarityList: [],
    productCodeList: []
}
let totalPages = 0;

// 页面初始化时加载数据
document.addEventListener('DOMContentLoaded', function () {
    getCardTypeList();
    getCardColorList();
    getCardRarityList();
    getProductList();
    getCardCraftList();

    const filterToggle = document.getElementById('filterToggle');
    const filterContent = document.getElementById('filterContent');
    const bottomIcon = document.querySelector('.bottom-icon');
    const topIcon = document.querySelector('.top-icon');

    filterToggle.addEventListener('click', function () {
        if (filterContent.style.display === 'none') {
            // 展开状态
            filterContent.style.display = 'block';
            bottomIcon.style.display = 'none';
            topIcon.style.display = 'block';
        } else {
            // 收起状态
            filterContent.style.display = 'none';
            bottomIcon.style.display = 'block';
            topIcon.style.display = 'none';
        }
    });


});

// 卡牌种类
function getCardTypeList() {
    const requestData = {
        pageNum: 1,
        pageSize: 100,
        type: 'card_category'
    };
    sendPostRequest('/xcx/dict/getDictList', requestData)
        .then(data => {
            // console.log('POST 请求成功', data);
            if (data.code == 0) {
                renderCardTypes(data.result);
            }
        })
        .catch(error => {
            console.error('There was an error:', error);
        });
}

// 渲染卡牌种类
function renderCardTypes(cardTypes) {
    const container = document.getElementById('cardTypeContainer');
    container.innerHTML = '';

    cardTypes.forEach(item => {
        const itemElement = document.createElement('div');
        itemElement.className = 'card-type-item';
        itemElement.textContent = item.name;
        itemElement.dataset.value = item.code;

        // 初始化选中状态（如果已在cardCategoryList中）
        if (params.cardCategoryList.includes(item.code)) {
            itemElement.classList.add('card-type-item-selected');
        }

        itemElement.addEventListener('click', () => {
            toggleCardTypeSelection(item.code, itemElement);
        });

        container.appendChild(itemElement);
    });
}

// 切换选中状态
function toggleCardTypeSelection(code, element) {
    const index = params.cardCategoryList.indexOf(code);

    // 如果已选中，则取消选中
    if (index > -1) {
        params.cardCategoryList.splice(index, 1); // 从数组移除
        element.classList.remove('card-type-item-selected');
    }
    // 如果未选中，则添加选中
    else {
        params.cardCategoryList.push(code); // 添加到数组
        element.classList.add('card-type-item-selected');
    }

    console.log('当前选中种类:', params.cardCategoryList);
}

// 颜色
function getCardColorList() {
    const requestData = {
        pageNum: 1,
        pageSize: 100,
        type: 'card_color'
    };
    sendPostRequest('/xcx/dict/getDictList', requestData)
        .then(data => {
            // console.log('POST 请求成功', data);
            if (data.code == 0) {
                renderCardColor(data.result);
            }
        })
        .catch(error => {
            console.error('There was an error:', error);
        });
}

// 渲染卡牌颜色
function renderCardColor(cardTypes) {
    const container = document.getElementById('cardColorContainer');
    container.innerHTML = '';

    cardTypes.forEach(item => {
        const itemElement = document.createElement('div');
        itemElement.className = 'card-type-item';
        itemElement.textContent = item.name;
        itemElement.dataset.value = item.code;

        // 初始化选中状态（如果已在cardColorList中）
        if (params.cardColorList.includes(item.code)) {
            itemElement.classList.add('card-type-item-selected');
        }

        itemElement.addEventListener('click', () => {
            toggleCardColorSelection(item.code, itemElement);
        });

        container.appendChild(itemElement);
    });
}

// 切换选中状态
function toggleCardColorSelection(code, element) {
    const index = params.cardColorList.indexOf(code);

    // 如果已选中，则取消选中
    if (index > -1) {
        params.cardColorList.splice(index, 1); // 从数组移除
        element.classList.remove('card-type-item-selected');
    }
    // 如果未选中，则添加选中
    else {
        params.cardColorList.push(code); // 添加到数组
        element.classList.add('card-type-item-selected');
    }

    console.log('当前选中种类:', params.cardColorList);
}

// 稀有度
function getCardRarityList() {
    const requestData = {
        pageNum: 1,
        pageSize: 100,
        type: 'card_rarity'
    };
    sendPostRequest('/xcx/dict/getDictList', requestData)
        .then(data => {
            // console.log('POST 请求成功', data);
            if (data.code == 0) {
                renderCardRarity(data.result);
            }
        })
        .catch(error => {
            console.error('There was an error:', error);
        });
}

// 渲染稀有度
function renderCardRarity(cardTypes) {
    const container = document.getElementById('cardRarityContainer');
    container.innerHTML = '';

    cardTypes.forEach(item => {
        const itemElement = document.createElement('div');
        itemElement.className = 'card-rarity-item';

        // 创建图片元素
        const imgElement = document.createElement('img');
        imgElement.className = 'card-rarity-item-img';
        imgElement.src = `https://cdn.playloltcg.com/lol/battle/card-rarity-${item.code}.webp`;

        // 初始化选中状态（如果已在rarityList中）
        if (params.rarityList.includes(item.code)) {
            itemElement.classList.add('card-rarity-item-selected');
        }

        itemElement.addEventListener('click', () => {
            toggleCardRaritySelection(item.code, itemElement);
        });

        // 将图片添加到稀有度项中
        itemElement.appendChild(imgElement);
        container.appendChild(itemElement);
    });
}

// 切换选中状态
function toggleCardRaritySelection(code, element) {
    const index = params.rarityList.indexOf(code);

    // 如果已选中，则取消选中
    if (index > -1) {
        params.rarityList.splice(index, 1); // 从数组移除
        element.classList.remove('card-rarity-item-selected');
    }
    // 如果未选中，则添加选中
    else {
        params.rarityList.push(code); // 添加到数组
        element.classList.add('card-rarity-item-selected');
    }

    console.log('当前选中种类:', params.rarityList);
}

// 商品列表
function getProductList() {
    const requestData = {
        pageNum: 1,
        pageSize: 1000,
    };
    sendPostRequest('/xcx/product/getProductList', requestData)
        .then(data => {
            // console.log('POST 请求成功', data);
            if (data.code == 0) {
                renderProductSelect(data.result);
            }
        })
        .catch(error => {
            console.error('There was an error:', error);
        });
}

// 渲染商品下拉框
function renderProductSelect(products) {
    const select = document.getElementById('productSelect');

    // 清空现有选项 disabled hidden
    select.innerHTML = '<option value="" selected>请选择</option>';

    // 添加商品选项
    products.forEach(product => {
        const option = document.createElement('option');
        option.value = product.code; // 假设接口返回id字段
        option.textContent = product.name; // 假设接口返回name字段
        select.appendChild(option);
    });

    // 添加事件监听（可选）
    select.addEventListener('change', handleProductSelectChange);
}

function handleProductSelectChange(event) {
    const selectedProductId = event.target.value;
    params.productCodeList = []
    params.productCodeList.push(selectedProductId)
}

// 获取输入框和按钮的 DOM
const searchInput = document.getElementById('searchInput');
const searchBtn = document.getElementById('searchBtn');

// 监听搜索按钮点击
searchBtn.addEventListener('click', handleSearch);

// 监听输入框回车键（可选）
searchInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        handleSearch();
    }
});

// 搜索处理函数
function handleSearch() {
    params.searchContent = searchInput.value.trim();
    params.pageNum = 1;
    getCardCraftList()
}

// 获取卡牌列表 /card/searchCardCraftWeb   card/searchCardCraft
function getCardCraftList() {
    sendPostRequest('/xcx/card/searchCardCraftWeb', { ...params })
        .then(data => {
            if (data.code == 0) {
                totalPages = Math.ceil(data.result.total / params.pageSize);
                renderCardList(data.result.list);
                updatePaginationControls(); // 更新分页控件
            }
        })
        .catch(error => {
            console.error('Error:', error);

        })
}

// 渲染卡牌列表
function renderCardList(cards) {
    const container = document.getElementById('cardListContainer');
    container.innerHTML = ''; // 清空现有内容

    cards.forEach(card => {
        const cardElement = document.createElement('div');
        cardElement.className = 'card-item';

        const imgElement = document.createElement('img');
        imgElement.className = 'card-img';
        imgElement.src = card.frontImage;
        imgElement.alt = '';

        cardElement.appendChild(imgElement);
        container.appendChild(cardElement);

         // 添加点击事件
        cardElement.addEventListener('click', function() {
            showCardPopup(card);
        });
    });
}

// 显示卡牌弹窗
function showCardPopup(card) {
    const modalBox = document.querySelector('.modal-box');
    const cardPopup = document.querySelector('.card-popup');
    const popupImg = document.querySelector('.card-popup-img');
    
    // 设置弹窗图片
    popupImg.src = card.frontImage;
    
    // 显示弹窗
    modalBox.style.display = 'flex';
    
    // 添加关闭事件
    document.querySelector('.close-icon').addEventListener('click', function() {
        modalBox.style.display = 'none';
    });
    
    // 点击弹窗外部关闭
    modalBox.addEventListener('click', function(e) {
        if (e.target === modalBox || e.target === cardPopup) {
            modalBox.style.display = 'none';
        }
    });
}

// 更新分页控件状态，并包括数字按钮
function updatePaginationControls() {
    const paginationNumbers = document.getElementById('pagination-numbers');

    const prevPage = document.getElementById('prev-page');
    const nextPage = document.getElementById('next-page');

    // 按钮始终可见，通过添加或移除`disabled`类来指示是否可点击
    if (params.pageNum > 1) {
        prevPage.classList.remove('disabled');
    } else {
        prevPage.classList.add('disabled');
    }

    if (params.pageNum < totalPages) {
        nextPage.classList.remove('disabled');
    } else {
        nextPage.classList.add('disabled');
    }

    // 更新前一页和后一页的可见性
    // prevPage.style.visibility = params.pageNum > 1 ? 'visible' : 'hidden';
    // nextPage.style.visibility = params.pageNum < totalPages ? 'visible' : 'hidden';

    // 清除旧的分页数字
    paginationNumbers.innerHTML = '';

    // 计算显示的数字页码范围
    let startPage = Math.max(params.pageNum - 2, 1);
    let endPage = Math.min(startPage + 4, totalPages);

    // 调整开始页码，确保总是显示5个数字，前提是总页数大于5
    if (endPage - startPage < 4) {
        startPage = Math.max(endPage - 4, 1);
    }

    // 添加第一页和前置省略号
    if (startPage > 1) {
        paginationNumbers.appendChild(createPageButton(1));
        if (startPage > 2) {
            paginationNumbers.appendChild(document.createTextNode('...'));
        }
    }

    // 生成中间页码
    for (let pageNum = startPage; pageNum <= endPage; pageNum++) {
        paginationNumbers.appendChild(createPageButton(pageNum));
    }

    // 添加末页和后置省略号
    if (endPage < totalPages) {
        if (endPage < totalPages - 1) {
            paginationNumbers.appendChild(document.createTextNode('...'));
        }
        paginationNumbers.appendChild(createPageButton(totalPages));
    }
}

// 创建页码按钮
function createPageButton(pageNum) {
    const button = document.createElement('a');
    button.href = '#';
    button.textContent = pageNum;
    button.classList.add('pagination-btn'); // 应用默认样式
    if (pageNum === params.pageNum) {
        button.classList.add('page-active'); // 当前页码激活样式
    }
    button.addEventListener('click', (e) => {
        e.preventDefault();
        params.pageNum = pageNum;
        getCardCraftList();
    });
    return button;
}
// 更新分页数字按钮
function updatePaginationNumbers() {
    const container = document.getElementById('pagination-numbers');
    container.innerHTML = ''; // 清除旧的分页数字

    // 确定分页数字的范围
    const startPage = Math.max(params.pageNum - 2, 1);
    const endPage = Math.min(startPage + 4, totalPages);

    // 如果当前页码较小，确保显示足够的页码
    const range = endPage - startPage;
    if (range < 4) {
        endPage = Math.min(startPage + (4 - range), totalPages);
    }

    // 添加第一页和前置省略号
    if (startPage > 1) {
        addPageButton(1);
        if (startPage > 2) {
            container.appendChild(document.createTextNode('…'));
        }
    }

    // 添加中间页码按钮
    for (let i = startPage; i <= endPage; i++) {
        addPageButton(i);
    }

    // 添加最后一页和后置省略号
    if (endPage < totalPages) {
        if (endPage < totalPages - 1) {
            container.appendChild(document.createTextNode('…'));
        }
        addPageButton(totalPages);
    }

    // 辅助函数：添加页码按钮
    function addPageButton(page) {
        const button = document.createElement('a');
        button.href = '#';
        button.textContent = page;
        button.className = 'page-number';
        if (page === params.pageNum) {
            button.classList.add('active'); // 标记当前页码
        }
        button.addEventListener('click', (e) => {
            e.preventDefault();
            params.pageNum = page;
            getCardCraftList();
        });
        container.appendChild(button);
    }
}

// 绑定事件
document.getElementById('prev-page').addEventListener('click', function (e) {
    e.preventDefault();
    if (params.pageNum > 1) {
        params.pageNum--;
        getCardCraftList();
    }
});

document.getElementById('next-page').addEventListener('click', function (e) {
    e.preventDefault();
    if (params.pageNum < totalPages) {
        params.pageNum++;
        getCardCraftList();
    }
});

document.getElementById('page-size').addEventListener('change', function () {
    params.pageSize = this.value;
    params.pageNum = 1; // 重置回第一页
    getCardCraftList();
});

function jumpToPage() {
    const pageNum = parseInt(document.getElementById('page-input').value, 10);
    if (pageNum >= 1 && pageNum <= totalPages) {
        params.pageNum = pageNum;
        getCardCraftList();
    } else {
        alert("请输入有效的页码");
    }
}

document.querySelector('.page-jump button').addEventListener('click', jumpToPage);