using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using Riftbound.Contracts;
using Riftbound.Engine;

if (args.Length != 1) throw new Exception("New evidence folder required.");
var root = Path.GetFullPath(args[0]);
if (Directory.Exists(root)) throw new Exception("Original evidence must not be overwritten.");
Directory.CreateDirectory(root);
var summaries = new List<object>();
foreach (var cardNo in new[] { "UNL-080/219", "VEN·033" })
{
    Require(CardBehaviorRegistry.TryGetByCardNo(cardNo, out var definition), "Exact registered printing missing.");
    var cards = new Dictionary<string, CardObjectState> {
        ["F"] = new("F", cardNo: "OGN·278/298", tags: [P6TokenFactoryCatalog.BattlefieldCardTag], ownerId: "P1", controllerId: "P1"),
        ["OTHER"] = new("OTHER", cardNo: "OGN·294/298", tags: [P6TokenFactoryCatalog.BattlefieldCardTag], ownerId: "P2", controllerId: "P2"),
        ["HOST"] = new("HOST", cardNo: cardNo, manaCost: definition.ManaCost, power: definition.SourceUnitPower,
            tags: definition.SourceUnitTags.Split('|', StringSplitOptions.RemoveEmptyEntries).Append(CardObjectTags.UnitCard).ToArray(), ownerId: "P1", controllerId: "P1"),
        ["HAND"] = new("HAND", cardNo: "VEN·058", manaCost: 2, power: 2,
            tags: [CardObjectTags.EquipmentCard, CardObjectTags.UnitCard], ownerId: "P1", controllerId: "P1"),
        ["D0"] = new("D0", cardNo: "VEN·058", manaCost: 2, power: 2,
            tags: [CardObjectTags.EquipmentCard, CardObjectTags.UnitCard], ownerId: "P1", controllerId: "P1"),
        ["D1"] = new("D1", cardNo: "OGN·096/298", manaCost: 2, power: 1,
            tags: [CardObjectTags.UnitCard], ownerId: "P1", controllerId: "P1") };
    var positions = new Dictionary<string,ObjectLocationState> { ["F"] = new("P1", "BATTLEFIELD", "F"),
        ["OTHER"] = new("P2", "BATTLEFIELD", "OTHER"), ["HOST"] = new("P1", "BASE"), ["HAND"] = new("P1", "HAND"),
        ["D0"] = new("P1", "MAIN_DECK"), ["D1"] = new("P1", "MAIN_DECK") };
    var initial = new MatchState("CONTROLLED-HWEI-MOVEMENT-" + summaries.Count, 0, 5, "P1",
        new Dictionary<string,string> { ["P1"] = "P1", ["P2"] = "P2" }, status: MatchStatuses.InProgress,
        phase: MatchPhases.Main, timingState: TimingStates.NeutralOpen, cardObjects: cards, objectLocations: positions,
        playerZones: new Dictionary<string,PlayerZones> { ["P1"] = PlayerZones.Empty with { Base = ["HOST"], Hand = ["HAND"], MainDeck = ["D0", "D1"], Battlefields = ["F"] },
            ["P2"] = PlayerZones.Empty with { Battlefields = ["OTHER"] } }) { CardPlays = new(5, [], []) };
    Require(MatchStateHasher.Hash(initial) == MatchStateHasher.Hash(JsonSerializer.Deserialize<MatchState>(JsonSerializer.Serialize(initial))!), "Initial fixture roundtrip differs.");
    var journal = new Journal();
    var session = new MatchSession(initial, new CoreRuleEngine(), journal);
    var state = initial;
    var initialErrors = Validate(state, journal);
    Require(initialErrors.Count == 0, string.Join(";", initialErrors));
    await Act("P1", new MoveUnitCommand("HOST", "BASE", "BATTLEFIELD:F"));
    var afterMove = state;
    Require(state.ObjectLocations["HOST"].BattlefieldObjectId == "F", "Move did not actually occur.");
    for (var i = 0; i < 12 && (state.TriggerQueue.Count > 0 || state.StackItems.Count > 0); i++) {
        if (state.TriggerQueue.Count > 0) await Act(state.TriggerQueue[0].ControllerId,
            new OrderTriggersCommand(OrderedTriggerIds: state.TriggerQueue.Select(t => t.TriggerId).ToArray()));
        else if (state.PriorityPlayerId is { } priority) await Act(priority, new PassPriorityCommand());
        else throw new Exception("Unexpected pending window; retain original prefix.");
    }
    Require(state.TriggerQueue.Count == 0 && state.StackItems.Count == 0, "Probe did not finish its pending stack.");
    var commands = journal.Commands(); var events = journal.Events();
    var replay = await MatchActionLogReplayer.VerifyFinalStateAsync(initial, commands, state, new CoreRuleEngine(), default, events);
    Require(replay.IsMatch, string.Join(";", replay.Errors));
    var draws = events.Count(e => e.Event.Kind == "CARD_DRAWN");
    var candidate = cardNo == "UNL-080/219";
    var path = Path.Combine(root, candidate ? "hwei-original-controlled-frame.json.gz" : "pakaa-positive-control-original-frame.json.gz");
    await using (var file = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None))
    await using (var zip = new GZipStream(file, CompressionLevel.SmallestSize))
        await JsonSerializer.SerializeAsync(zip, new { controlledFixture = true, ordinaryBlankOpening = false, initial, afterMove,
            finalState = state, commands, events, replay, actualRuleInputs = RuleInputIdentity.Current }, Journal.Options);
    summaries.Add(new { cardNo, controlledFixture = true, ordinaryBlankOpening = false, originalSeed = initial.Seed,
        acceptedCommands = commands.Count, eventCount = events.Count, afterMoveQueuedTriggers = afterMove.TriggerQueue.Count,
        afterMoveStackItems = afterMove.StackItems.Count,
        cardDrawnEvents = draws, finalHand = state.PlayerZones["P1"].Hand, finalDeck = state.PlayerZones["P1"].MainDeck,
        sourceMovementCount = state.CardObjects["HOST"].MovementCountThisTurn, originalFullReplayMatched = replay.IsMatch,
        evidencePath = path, evidenceSha256 = Sha(path), ruleExpectedInitialDraw = 1,
        classification = candidate ? "CONFIRMED_CONTROLLED_MISSING_HWEI_MOVEMENT_TRIGGER_AND_DRAW" : "POSITIVE_PAKAA_MOVEMENT_CONTROL" });
    Require(candidate ? afterMove.TriggerQueue.Count == 0 && afterMove.StackItems.Count == 0 && draws == 0
        : afterMove.TriggerQueue.Count + afterMove.StackItems.Count == 1 && draws == 1,
        "Observed behavior differs from the specifically diagnosed gap/control; inspect retained raw evidence.");

    async Task Act(string player, GameCommand command) {
        var prompt = session.PromptFor(player);
        var fields = JsonSerializer.Deserialize<Dictionary<string,JsonElement>>(JsonSerializer.Serialize(command, command.GetType(), Journal.Options), Journal.Options)!;
        fields["promptId"] = JsonSerializer.SerializeToElement(prompt.PromptId);
        fields["snapshotTick"] = JsonSerializer.SerializeToElement(state.Tick);
        var raw = JsonSerializer.SerializeToElement(fields);
        var result = await session.SubmitAsync(player, "original-" + journal.Entries.Count, command, raw, default);
        Require(result.Accepted, result.ErrorMessage ?? "Authority rejected original command."); state = result.State;
        var errors = Validate(state, journal); Require(errors.Count == 0, string.Join(";", errors));
        Require(MatchStateHasher.Hash(state) == MatchStateHasher.Hash(JsonSerializer.Deserialize<MatchState>(JsonSerializer.Serialize(state))!), "State roundtrip differs.");
    }
}
var moduleHashes = new[] { typeof(CoreRuleEngine).Assembly, typeof(GameCommand).Assembly, typeof(Riftbound.CardCatalog.OfficialCardCatalog).Assembly }
    .ToDictionary(a => Path.GetFileName(a.Location), a => Sha(a.Location));
Console.WriteLine(JsonSerializer.Serialize(new { status = "CONTROLLED_RULE_COUNTEREXAMPLE_WITH_POSITIVE_MOVEMENT_CONTROL_NOT_ORDINARY_MATCH_OR_PRODUCT_CERTIFICATION",
    acquiredAt = DateTimeOffset.UtcNow, actualRuleInputs = RuleInputIdentity.Current, actualLoadedModuleHashes = moduleHashes,
    noCoreProjectOrGodotBuild = true, noOriginalDatabaseSeedOrHistoryModified = true, cases = summaries }, Journal.Options));

static IReadOnlyList<string> Validate(MatchState state, Journal journal) {
    var snapshots = ResolutionResult.BuildSnapshots(state); var prompts = ResolutionResult.BuildPrompts(state);
    var sequence = journal.Entries.LastOrDefault()?.CompletedEventSequence ?? 0;
    var views = state.Seats.Keys.ToDictionary(id => id, id => new RecoveredPlayerView(id, state.Tick, sequence, snapshots[id], state.Tick, sequence, prompts[id]));
    var spectator = MatchReplayRedactor.BuildSpectatorFrame(state.RoomId, state.Tick, sequence, [], state);
    return MatchRecoveryValidator.Validate(state.RoomId, sequence, journal.Commands(), journal.Events(), views, state, state.Tick, spectator);
}
static void Require(bool condition, string message) { if (!condition) throw new Exception(message); }
static string Sha(string path) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path))).ToLowerInvariant();
sealed class Journal : IMatchJournal {
    public static readonly JsonSerializerOptions Options = new(JsonSerializerDefaults.Web) { WriteIndented = true };
    public List<MatchJournalEntry> Entries { get; } = [];
    public ValueTask RecordAsync(MatchJournalEntry entry, CancellationToken token) { Entries.Add(entry); return ValueTask.CompletedTask; }
    public IReadOnlyList<RecoveredCommand> Commands() => Entries.Select(e => new RecoveredCommand(e.PlayerId, e.ClientIntentId, e.CommandType, e.RawCommand,
        e.StartedTick, e.CompletedTick, e.StartedEventSequence, e.CompletedEventSequence, e.Accepted, e.ErrorMessage) { RuleInputs = e.RuleInputs }).ToArray();
    public IReadOnlyList<RecoveredEvent> Events() => Entries.SelectMany(e => e.Events.Select((ev, i) => new RecoveredEvent(e.StartedEventSequence + i + 1, e.CompletedTick, i, ev))).ToArray();
}
