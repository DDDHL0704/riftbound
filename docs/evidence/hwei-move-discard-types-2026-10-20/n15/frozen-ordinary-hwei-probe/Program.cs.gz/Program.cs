using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using Riftbound.Contracts;
using Riftbound.Engine;
using Riftbound.CardCatalog;

if (args.Length == 2 && args[0] == "verify-failed") {
    using var zip = new GZipStream(File.OpenRead(args[1]), CompressionMode.Decompress);
    using var original = await JsonDocument.ParseAsync(zip);
    var initialState = original.RootElement.GetProperty("initial").Deserialize<MatchState>(Journal.Options)!;
    var finalState = original.RootElement.GetProperty("state").Deserialize<MatchState>(Journal.Options)!;
    var entries = original.RootElement.GetProperty("entries").Deserialize<List<MatchJournalEntry>>(Journal.Options)!;
    var journal = new Journal(); journal.Entries.AddRange(entries);
    var replay = await MatchActionLogReplayer.VerifyFinalStateAsync(initialState, journal.Commands(), finalState, new CoreRuleEngine(), default, journal.Events());
    Require(replay.IsMatch && entries.Count == 15 && entries.Count(e => e.Accepted) == 14 && !entries[^1].Accepted
        && entries[^1].CompletedTick == entries[^1].StartedTick && entries[^1].StartedEventSequence == entries[^1].CompletedEventSequence,
        "Original failed prefix replay or rejection invariance differs.");
    Console.WriteLine(JsonSerializer.Serialize(new { status = "PASS_INDEPENDENT_READONLY_ORIGINAL_FAILED_POWER_PAYMENT_PREFIX",
        originalSeed = initialState.Seed, commands = entries.Count, accepted = entries.Count(e => e.Accepted), rejected = 1,
        events = journal.Events().Length, originalAcceptedAndRejectedFullReplayMatched = replay.IsMatch,
        rejectedTickAndEventSequenceAtomic = true, actualRuleInputs = finalState.RuleInputs, noOriginalHistoryOrStateModified = true }, Journal.Options)); return;
}
if (args.Length != 2) throw new Exception("Original recipe and new evidence folder required.");
var recipePath = Path.GetFullPath(args[0]); var root = Path.GetFullPath(args[1]);
if (Directory.Exists(root)) throw new Exception("Do not overwrite original evidence.");
Directory.CreateDirectory(root);
using var recipe = JsonDocument.Parse(File.ReadAllText(recipePath));
var results = new List<object>();
var catalog = await OfficialCardCatalog.LoadDefaultAsync();
foreach (var format in new[] { OfficialDeckFormat.CoreRules, OfficialDeckFormat.ChinaStandard20260724 }) {
    var initial = MatchReplayInitialStateBuilder.FromSeats("new-ordinary-hwei-missing-trigger-" + format,
        new Dictionary<string,string> { ["P1"] = "P1", ["P2"] = "P2" });
    Require(initial.Tick == 0 && initial.Seed == 0 && initial.CardObjects.Count == 0, "Original blank initial state required.");
    var options = new MatchSessionOptions(AllowLegacyReadyWithoutDeck: false, DeckFormat: format);
    var journal = new Journal(); var engine = new CoreRuleEngine(); var state = initial;
    IMatchSession session = new MatchSession(initial, engine, journal, NoopMatchPlayerStore.Instance, options);
    var coldCount = 0; var nextMatches = 0; var afterCold = false;
    try {
        // This authors a different legal deck before submitting a new blank match.
        // No accepted command, old fixture, old match, seed or history is edited.
        foreach (var entry in recipe.RootElement.GetProperty("openingIntents").EnumerateArray()) {
            var actor = entry.GetProperty("playerId").GetString()!;
            var command = GameCommandJsonMapper.Map(entry.GetProperty("rawCommand"));
            if (actor == "P1" && command is SubmitDeckCommand deck)
                command = deck with { MainDeck = deck.MainDeck.Select(c => c == "VEN·033" ? "UNL-080/219" : c).ToArray() };
            if (actor == "P1" && command is PlayCardCommand play && play.CardNo == "VEN·033") {
                var blueRune = state.PlayerZones["P1"].Base.First(id => state.CardObjects[id].Tags.Contains(CardObjectTags.RuneCard)
                    && state.CardObjects[id].Tags.Contains("COLOR:blue"));
                await Submit("P1", new RecycleRuneCommand(blueRune));
                command = play with { CardNo = "UNL-080/219", SourceObjectId = state.PlayerZones["P1"].Hand.First(id => state.CardObjects[id].CardNo == "UNL-080/219") };
            }
            await Submit(actor, command);
        }
        var host = state.PlayerZones["P1"].Base.Single(id => state.CardObjects[id].CardNo == "UNL-080/219");
        var before = state; await Cold();
        var sequence = journal.Entries.Last().CompletedEventSequence;
        var move = new MoveUnitCommand(host, "BASE", "BATTLEFIELD:" + state.PlayerZones["P1"].Battlefields.First(state.BattlefieldStates.ContainsKey));
        var invalid = await engine.ResolveAsync(state, new("independent-invalid-actor", "P2", move.CmdType), move, default);
        Require(!invalid.Accepted && invalid.Events.Count == 0 && MatchStateHasher.Hash(invalid.State) == MatchStateHasher.Hash(state), "Invalid actor changed state.");
        await Submit("P1", move); var afterMove = state; await Cold();
        // Close the original movement duel without ending the turn. This rules
        // out a delayed implementation appearing only when focus is passed.
        for (var i = 0; i < 16 && (state.TriggerQueue.Count > 0 || state.StackItems.Count > 0
            || state.FocusPlayerId is not null || state.PriorityPlayerId is not null); i++) {
            if (state.TriggerQueue.Count > 0) await Submit(state.TriggerQueue[0].ControllerId,
                new OrderTriggersCommand(OrderedTriggerIds: state.TriggerQueue.Select(t => t.TriggerId).ToArray()));
            else if (state.PriorityPlayerId is { } priority) await Submit(priority, new PassPriorityCommand());
            else if (state.FocusPlayerId is { } focus) await Submit(focus, new PassFocusCommand());
            else throw new Exception("Unexpected pending movement stack.");
        }
        Require(state.FocusPlayerId is null && state.PriorityPlayerId is null && state.TimingState == TimingStates.NeutralOpen,
            "Original movement duel has not returned to neutral open.");
        await Cold();
        var frame = Frame(); var moveEvents = frame.Events.Where(e => e.Sequence > sequence).ToArray();
        await Save(Path.Combine(root, "hwei-" + format + "-original-frame.json.gz"), frame);
        await Save(Path.Combine(root, "hwei-" + format + "-before-move-state.json.gz"), before);
        await Save(Path.Combine(root, "hwei-" + format + "-after-move-state.json.gz"), afterMove);
        var drawCount = moveEvents.Count(e => e.Event.Kind == "CARD_DRAWN");
        Require(state.ObjectLocations[host].Zone == "BATTLEFIELD", "Actual legal movement required.");
        Require(drawCount == 0 && state.TriggerQueue.Count == 0 && state.StackItems.Count == 0
            && before.PlayerZones["P1"].Hand.SequenceEqual(state.PlayerZones["P1"].Hand)
            && before.PlayerZones["P1"].MainDeck.SequenceEqual(state.PlayerZones["P1"].MainDeck), "Inspect retained originals; diagnosed gap differs.");
        var replay = await MatchActionLogReplayer.VerifyFinalStateAsync(initial, frame.Commands, state, engine, default, frame.Events);
        Require(replay.IsMatch, string.Join(';', replay.Errors));
        results.Add(new { format = format.ToString(), originalSeed = initial.Seed, originalBlankInitial = true,
            originalAcceptedCommands = frame.Commands.Count, originalEvents = frame.Events.Count, coldCount, nextMatches,
            independentInvalidActorRejectedAtomically = true, host, actualCardNo = state.CardObjects[host].CardNo,
            actualMoveEvents = moveEvents.Select(e => e.Event.Kind).ToArray(), observedDraws = drawCount,
            expectedInitialDraw = 1, movementDuelClosedBeforeAnyEndTurn = true, finalTimingState = state.TimingState,
            originalFullReplayMatched = replay.IsMatch,
            classification = "CONFIRMED_ORDINARY_BLANK_OPENING_MISSING_HWEI_MOVE_TRIGGER_AND_DRAW_NOT_COMPLETE_GAME_OR_PRODUCT_ACCEPTANCE" });
    } catch (Exception ex) {
        await Save(Path.Combine(root, "hwei-" + format + "-failed-original-prefix.json.gz"), new { initial, state, journal.Entries, error = ex.ToString() });
        throw;
    }

    async Task Submit(string actor, GameCommand command) {
        if (command is SubmitDeckCommand deck) {
            var valid = OfficialDeckValidator.Validate(new(deck.LegendCardNo, deck.ChampionCardNo, deck.MainDeck, deck.RuneDeck, deck.Battlefields), catalog, format);
            Require(valid.IsValid, string.Join(';', valid.Errors));
        }
        var raw = JsonSerializer.SerializeToNode(command, command.GetType(), Journal.Options)!.AsObject();
        raw["promptId"] = session.PromptFor(actor).PromptId; raw["snapshotTick"] = state.Tick;
        var encoded = JsonSerializer.SerializeToElement(raw); var intent = "new-hwei-original-" + journal.Entries.Count;
        var expected = afterCold ? await engine.ResolveAsync(state, new(intent, actor, command.CmdType), command, default) : null;
        var result = command switch { SubmitDeckCommand submitted => await session.SubmitDeckAsync(actor, intent, submitted, encoded, default),
            ReadyCommand => await session.ReadyAsync(actor, intent, encoded, default), _ => await session.SubmitAsync(actor, intent, command, encoded, default) };
        Require(result.Accepted, result.ErrorMessage ?? "Original new match command rejected.");
        if (afterCold) { Require(expected!.Accepted && MatchStateHasher.Hash(expected.State) == MatchStateHasher.Hash(result.State)
            && JsonNode.DeepEquals(JsonSerializer.SerializeToNode(expected.Events), JsonSerializer.SerializeToNode(result.Events)), "Original next command differs after cold restore."); nextMatches++; }
        state = result.State; afterCold = false;
    }
    MatchRecoveryFrame Frame() {
        var commands = journal.Commands(); var events = journal.Events(); var seq = journal.Entries.Last().CompletedEventSequence;
        var snapshots = ResolutionResult.BuildSnapshots(state); var prompts = ResolutionResult.BuildPrompts(state);
        var views = initial.Seats.Keys.ToDictionary(id => id, id => new RecoveredPlayerView(id, state.Tick, seq, snapshots[id], state.Tick, seq, prompts[id]));
        var spectator = MatchReplayRedactor.BuildSpectatorFrame(initial.RoomId, state.Tick, seq, [], state);
        var errors = MatchRecoveryValidator.Validate(initial.RoomId, seq, commands, events, views, state, state.Tick, spectator);
        Require(errors.Count == 0, string.Join(';', errors));
        return new(initial.RoomId, state.Tick, seq, commands, events, views, errors, state, initial, spectator);
    }
    async Task Cold() {
        var original = Frame(); var restored = JsonSerializer.Deserialize<MatchRecoveryFrame>(JsonSerializer.Serialize(original, Journal.Options), Journal.Options)!;
        var errors = await MatchActionLogReplayer.ValidateRecoveryFrameAsync(restored, engine, default);
        Require(errors.Count == 0, string.Join(';', errors));
        var previous = session; session = MatchSession.Restore(restored, engine, journal, NoopMatchPlayerStore.Instance, options);
        foreach (var id in initial.Seats.Keys) {
            Require(JsonNode.DeepEquals(JsonSerializer.SerializeToNode(previous.SnapshotFor(id)), JsonSerializer.SerializeToNode(session.SnapshotFor(id))), "Cold private snapshot differs.");
            Require(JsonNode.DeepEquals(JsonSerializer.SerializeToNode(previous.PromptFor(id)), JsonSerializer.SerializeToNode(session.PromptFor(id))), "Cold private prompt differs.");
        }
        coldCount++; afterCold = true;
    }
}
Console.WriteLine(JsonSerializer.Serialize(new { status = "ACTUAL_NEW_LEGAL_ORDINARY_OPENING_COUNTEREXAMPLES_ONLY", actualRuleInputs = RuleInputIdentity.Current,
    originalRecipe = recipePath, originalRecipeSha256 = Sha(recipePath), newDeckAuthoredBeforeNewMatch = true,
    noOldSeedOrAcceptedHistoryRewrite = true, noCoreGodotOrDatabaseBuildOrMutation = true, cases = results,
    actualModules = new[] { typeof(CoreRuleEngine).Assembly, typeof(GameCommand).Assembly, typeof(OfficialCardCatalog).Assembly }
        .ToDictionary(a => Path.GetFileName(a.Location), a => Sha(a.Location)) }, Journal.Options));
static void Require(bool ok, string message) { if (!ok) throw new Exception(message); }
static string Sha(string path) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path))).ToLowerInvariant();
static async Task Save(string path, object value) {
    await using var f = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None);
    await using var zip = new GZipStream(f, CompressionLevel.SmallestSize); await JsonSerializer.SerializeAsync(zip, value, Journal.Options);
}
sealed class Journal : IMatchJournal {
    public static readonly JsonSerializerOptions Options = new(JsonSerializerDefaults.Web) { WriteIndented = true };
    public List<MatchJournalEntry> Entries { get; } = [];
    public ValueTask RecordAsync(MatchJournalEntry entry, CancellationToken token) { Entries.Add(entry); return ValueTask.CompletedTask; }
    public RecoveredCommand[] Commands() => Entries.Select(e => new RecoveredCommand(e.PlayerId, e.ClientIntentId, e.CommandType, e.RawCommand,
        e.StartedTick, e.CompletedTick, e.StartedEventSequence, e.CompletedEventSequence, e.Accepted, e.ErrorMessage) { RuleInputs = e.RuleInputs }).ToArray();
    public RecoveredEvent[] Events() => Entries.SelectMany(e => e.Events.Select((ev, i) => new RecoveredEvent(e.StartedEventSequence + i + 1, e.CompletedTick, i, ev))).ToArray();
}
