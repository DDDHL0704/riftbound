document.addEventListener('DOMContentLoaded', function () {
    fetchDataAndUpdate();

    const playButton = document.getElementById('play-btn');
    const video = document.getElementById('my-vedio');
    const cover = document.getElementById('img-content');

    playButton.addEventListener('click', playVideo);

    function playVideo() {
        video.style.display = 'block';
        video.play();
        cover.style.display = 'none';
        playButton.style.display = 'none';
    }
});



// 处理分页数据更新
function fetchDataAndUpdate() {
    // 构造请求的参数，这里假设后端API需要pageNum和pageSize参数
    const requestData = {
        pageNum: 1,
        pageSize: 3
    };

    sendPostRequest('/xcx/information/page', requestData)
        .then(data => {
            updatePageContent(data.result.list); // 更新页面内容
        })
        .catch(error => {
            console.error('There was an error:', error);
        });
}

function updatePageContent(list) {
    const infomationBox = document.querySelector('.infomation-list');
    infomationBox.innerHTML = ''; // 清空当前内容

    list.forEach(item => {
        // 创建新闻项的容器
        const infoItemBox = document.createElement('div');
        infoItemBox.className = 'info-item';
        const infoItemImgBox = document.createElement('div');
        infoItemImgBox.className = 'info-item-img-box';

        const img = document.createElement('img');
        img.src = item.image; // 使用数据中的图片URL
        img.className = 'info-img';
        img.alt = item.name; // 使用新闻标题作为图片的alt属性
        infoItemImgBox.appendChild(img);
        infoItemBox.appendChild(infoItemImgBox);

        infoItemImgBox.addEventListener('click', () => {
            window.open(item.jumpUrl, '_blank'); // 在新标签页打开链接
        });

        const infoItemNameBox = document.createElement('div');
        infoItemNameBox.className = 'info-name';
        infoItemNameBox.textContent = item.name;

        const infoItemTimeBox = document.createElement('div');
        infoItemTimeBox.className = 'info-time';
        infoItemTimeBox.textContent = item.pushDate;

        infoItemBox.appendChild(infoItemNameBox);
        infoItemBox.appendChild(infoItemTimeBox);

        infomationBox.appendChild(infoItemBox);
    });
}
