using System.Collections;
using System.Reflection;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.Text.Json;

if (args.Length != 2) throw new Exception("Exact existing frozen core folder and printing required.");
var folder = Path.GetFullPath(args[0]);
AssemblyLoadContext.Default.Resolving += (context, name) => {
    var path = Path.Combine(folder, name.Name + ".dll");
    return File.Exists(path) ? context.LoadFromAssemblyPath(path) : null;
};
var catalogAssembly = AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.Combine(folder, "Riftbound.CardCatalog.dll"));
var engineAssembly = AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.Combine(folder, "Riftbound.Engine.dll"));
var catalogType = catalogAssembly.GetType("Riftbound.CardCatalog.OfficialCardCatalog", true)!;
var task = (Task)catalogType.GetMethod("LoadDefaultAsync")!.Invoke(null, new object[] { CancellationToken.None })!;
await task;
var catalog = task.GetType().GetProperty("Result")!.GetValue(task)!;
var cards = (IEnumerable)catalogType.GetProperty("Cards")!.GetValue(catalog)!;
var card = cards.Cast<object>().Single(c => (string)c.GetType().GetProperty("CardNo")!.GetValue(c)! == args[1]);
var parser = catalogAssembly.GetType("Riftbound.CardCatalog.RuleTextParser", true)!;
var parsed = parser.GetMethod("Parse", new[] { card.GetType() })!.Invoke(null, new[] { card })!;
var current = engineAssembly.GetType("Riftbound.Engine.RuleInputIdentity", true)!.GetProperty("Current")!.GetValue(null)!;
var registry = engineAssembly.GetType("Riftbound.Engine.CardBehaviorRegistry", true)!;
var arguments = new object?[] { args[1], null };
var registered = (bool)registry.GetMethod("TryGetByCardNo")!.Invoke(null, arguments)!;
var modules = new[] { "Riftbound.Contracts.dll", "Riftbound.CardCatalog.dll", "Riftbound.Engine.dll", "Riftbound.Persistence.dll" }
    .ToDictionary(file => file, file => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(Path.Combine(folder, file)))).ToLowerInvariant());
Console.WriteLine(JsonSerializer.Serialize(new { status = "ACTUAL_FROZEN_PARSER_AND_REGISTRY_READONLY_INSPECTION_NOT_GAMEPLAY_CERTIFICATION",
    cardNo = args[1], registered, currentRuntimeCard = card, parsedRules = parsed, registeredDefinition = arguments[1],
    actualRuleInputs = current, frozenModuleHashes = modules, noGameStateSeedHistoryOrRuntimeSourceModified = true,
    noCoreProjectOrGodotSdkRebuild = true }, new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true }));
