import collections
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent
NS = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_original(path):
    cases = collections.Counter()
    methods = set()
    full_methods = set()
    trx_hashes = {}
    matrices = []
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        trxs = [name for name in archive.namelist() if name.endswith('.trx')]
        assert len(trxs) == 5
        for name in trxs:
            raw = archive.read(name)
            trx_hashes[name] = sha(raw)
            root = ET.fromstring(raw)
            definitions = {
                node.attrib['id']: node.find('t:TestMethod', NS).attrib
                for node in root.findall('t:TestDefinitions/t:UnitTest', NS)
            }
            results = root.findall('t:Results/t:UnitTestResult', NS)
            assert results
            for result in results:
                assert result.attrib['outcome'] == 'Passed'
                definition = definitions[result.attrib['testId']]
                class_name = definition['className'].split(',')[0]
                method = (class_name, definition['name'])
                cases[method + (result.attrib['testName'],)] += 1
                methods.add(method)
                if class_name.endswith('FullGameEndToEndTests'):
                    full_methods.add(method)
            for output in root.findall('.//t:StdOut', NS):
                text = output.text or ''
                for match in re.finditer(r'PRECONSTRUCTED_MATRIX\s+', text):
                    value, _ = json.JSONDecoder().raw_decode(text[match.end():].lstrip())
                    matrices.append(value)
        assert len(matrices) == 1
        summary = json.loads(archive.read('ci-rules/summary.json'))
        plan = json.loads(archive.read('ci-rules/plan.json'))
        assert summary['status'] == 'PASSED' and summary['profile'] == 'full'
        assert summary['total'] == sum(cases.values())
        assert plan['profile'] == 'full' and plan['discoveredMethods'] == len(methods)
        sql_receipts = [name for name in archive.namelist()
                        if name.startswith('ci-postgres/') and name.endswith('receipt.json')]
        return cases, methods, full_methods, trx_hashes, matrices[0], summary, sql_receipts


previous = read_original(ROOT.parent / 'dual-type-reveal-20261019/cancelled-full-conformance-results.zip')
current = read_original(ROOT / 'old07ac-original-conformance-results.zip')
old_cases, old_methods, old_full, _, old_matrix, _, _ = previous
cases, methods, full_methods, trx_hashes, matrix, summary, sql_receipts = current
assert sum(old_cases.values()) == 13068 and len(old_methods) == 7561
assert sum(cases.values()) == 13112 and len(methods) == 7564
assert not (old_cases - cases) and not (old_methods - methods)
assert sum((cases - old_cases).values()) == 44 and len(methods - old_methods) == 3
assert full_methods == old_full and len(full_methods) == 143
assert matrix['seed'] == old_matrix['seed'] == 424242
assert matrix['deckCount'] == old_matrix['deckCount'] == 11
assert matrix['pairCount'] == old_matrix['pairCount'] == 110
assert set(matrix['completed']) == set(old_matrix['completed'])
assert len(matrix['completed']) == 110
assert all(re.fullmatch('[a-f0-9]{64}', value) for value in matrix['completed'].values())


def original_full_source_blobs(commit):
    output = subprocess.check_output([
        'git', 'ls-tree', '-r', '--format=%(objectname) %(path)', commit,
        'tests/Riftbound.ConformanceTests'
    ], text=True)
    return {
        path: object_id
        for object_id, path in (line.split(' ', 1) for line in output.splitlines())
        if Path(path).name.startswith('FullGameEndToEndTests') and path.endswith('.cs')
    }


old_commit = '6d9aee51e5259313b319ad555f8f44572563b3df'
fixed_commit = '07ac3ac93098c476179297ad755b18e9aa3f2e95'
current_commit = 'b294bb150d877b3399cd9e120bbaec5c75e353cf'
sources = original_full_source_blobs(fixed_commit)
assert len(sources) == 8
assert sources == original_full_source_blobs(old_commit) == original_full_source_blobs(current_commit)
matrix_path = ROOT / 'old07ac-matrix-original-v1.json'
assert not matrix_path.exists()
matrix_path.write_text(json.dumps(matrix, ensure_ascii=False, indent=2) + '\n')
result = {
    'observedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'ACTUAL_OLD07AC_RULE_TRXS_INDEPENDENTLY_VERIFIED_NOT_FULL_ACCEPTANCE',
    'runId': 39236312099,
    'fixedCommit': fixed_commit,
    'actualRuleCases': sum(cases.values()),
    'actualRuleMethods': len(methods),
    'all13068PreviousCaseMultisetRetained': True,
    'additionalCases': 44,
    'all7561PreviousMethodsRetained': True,
    'additionalMethods': 3,
    'originalSummaryCaseParityVerifiedFlagRetained': summary['caseParityVerified'],
    'independentRawCaseMultisetComparisonActuallyExecuted': True,
    'all143OriginalFullGameMethodsExact': sorted('.'.join(value) for value in full_methods),
    'allEightOriginalFullGameSourceBlobsExactAt6d9_07ac_b294': sources,
    'all110DirectedPairsAcross11DecksExact': True,
    'originalMatrixSeed': matrix['seed'],
    'all110ActualFinalStateHashesRetained': True,
    'rawTrxSha256': trx_hashes,
    'matrixSha256': sha(matrix_path.read_bytes()),
    'partialSqlReceiptFilesPresent': len(sql_receipts),
    'partialSqlReceiptPresenceDoesNotCertifyScenariosOrSuite': True,
    'sqlOverallComplete': False,
    'nativeNetworkExecutedAndPassed': False,
    'fullRunAndJobActualTerminalStillUnconfirmed': True,
    'apiJobCompleteStepAndUploadedArtifactDoNotReplaceActualTerminal': True,
    'fullAcceptancePassed': False,
    'noNativeArchiveDownloadedAndNoWholeZipExtracted': True,
}
output = ROOT / 'old07ac-rule-parity-independent-verification-v1.json'
assert not output.exists()
output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({key: result[key] for key in [
    'status', 'actualRuleCases', 'actualRuleMethods', 'additionalCases', 'additionalMethods',
    'all110DirectedPairsAcross11DecksExact', 'originalMatrixSeed', 'partialSqlReceiptFilesPresent',
    'fullAcceptancePassed'
]}))
