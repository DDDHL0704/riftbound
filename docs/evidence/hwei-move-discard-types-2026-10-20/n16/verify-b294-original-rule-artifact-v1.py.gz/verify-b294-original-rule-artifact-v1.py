import collections
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent
NS = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_original(path):
    cases = collections.Counter()
    methods = set()
    full_methods = set()
    trx_hashes = {}
    matrices = []
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        trxs = [name for name in archive.namelist() if name.endswith('.trx')]
        assert len(trxs) == 5
        for name in trxs:
            raw = archive.read(name)
            trx_hashes[name] = sha(raw)
            root = ET.fromstring(raw)
            definitions = {
                node.attrib['id']: node.find('t:TestMethod', NS).attrib
                for node in root.findall('t:TestDefinitions/t:UnitTest', NS)
            }
            results = root.findall('t:Results/t:UnitTestResult', NS)
            assert results
            for result in results:
                assert result.attrib['outcome'] == 'Passed'
                definition = definitions[result.attrib['testId']]
                class_name = definition['className'].split(',')[0]
                method = (class_name, definition['name'])
                cases[method + (result.attrib['testName'],)] += 1
                methods.add(method)
                if class_name.endswith('FullGameEndToEndTests'):
                    full_methods.add(method)
            for output in root.findall('.//t:StdOut', NS):
                text = output.text or ''
                for match in re.finditer(r'PRECONSTRUCTED_MATRIX\s+', text):
                    value, _ = json.JSONDecoder().raw_decode(text[match.end():].lstrip())
                    matrices.append(value)
        assert len(matrices) == 1
        summary = json.loads(archive.read('ci-rules/summary.json'))
        plan = json.loads(archive.read('ci-rules/plan.json'))
        assert summary['status'] == 'PASSED' and summary['profile'] == 'full'
        assert summary['total'] == sum(cases.values())
        assert plan['profile'] == 'full' and plan['discoveredMethods'] == len(methods)
        sql_receipts = [name for name in archive.namelist()
                        if name.startswith('ci-postgres/') and name.endswith('receipt.json')]
        return cases, methods, full_methods, trx_hashes, matrices[0], summary, sql_receipts


path = ROOT / 'b294-original-rule-results.zip'
assert path.stat().st_size == 3830561 and sha(path.read_bytes()) == 'ab4c6833d3b0fe0cd27613ab42c57dc0eaa9f5e1e92c672f714814dbf937fae3'
previous = read_original(ROOT / '797f-original-conformance-results.zip')
current = read_original(path)
old_cases, old_methods, old_full, _, old_matrix, _, _ = previous
cases, methods, full_methods, trx_hashes, matrix, summary, sql_receipts = current
assert sum(old_cases.values()) == 13118 and len(old_methods) == 7566
assert sum(cases.values()) == 13124 and len(methods) == 7568
assert not (old_cases - cases) and old_methods <= methods
assert sum((cases - old_cases).values()) == 6 and len(methods - old_methods) == 2
assert full_methods == old_full and len(full_methods) == 143
assert matrix['seed'] == old_matrix['seed'] == 424242
assert matrix['deckCount'] == old_matrix['deckCount'] == 11 and matrix['pairCount'] == old_matrix['pairCount'] == 110
assert set(matrix['completed']) == set(old_matrix['completed']) and len(matrix['completed']) == 110
assert all(re.fullmatch('[a-f0-9]{64}', h) for h in matrix['completed'].values())
run = json.loads((ROOT / 'b294-ci-after-797f-terminal-v2.json').read_text())
job = next(j for j in run['jobs'] if j['name'] == 'rule_suite')
assert job['status'] == 'completed' and job['conclusion'] == 'success'
assert run['status'] == 'in_progress' and next(j for j in run['jobs'] if j['name'] == 'postgres')['status'] == 'in_progress'
p = ROOT / 'b294-matrix-original-v1.json'; assert not p.exists(); p.write_text(json.dumps(matrix,indent=2)+'\n')
result = {'status':'ACTUAL_FIXED_B294_RULE_SUITE_TRXS_PASS_OVERALL_SQL_NETWORK_PENDING', 'runId':39275773327,
 'fixedCommit':run['headSha'], 'actualRuleCases':sum(cases.values()), 'actualRuleMethods':len(methods),
 'all13118PreviousCaseMultisetRetained':True,'all7566PreviousMethodsRetained':True,
 'newCaseNames':sorted((cases-old_cases).elements()), 'all143OriginalFullGameMethodsRetained':True,
 'all110DirectedPairs11DecksSeed424242Retained':True,'all110ActualTerminalHashesRetained':True,
 'rawTrxSha256':trx_hashes,'originalSummaryCaseParityVerified':summary['caseParityVerified'],
 'independentRawCaseMultisetActuallyCompared':True,'fullAcceptancePassed':False,
 'currentUncommittedHweiNotCovered':True,'sqlAndNetworkStillPending':True,
 'onlyOriginalRulesArchiveDownloadedNoNativePackage':True}
p = ROOT / 'b294-rule-parity-and-overall-disposition-v1.json'; assert not p.exists(); p.write_text(json.dumps(result,indent=2)+'\n')
print({k:result[k] for k in ['status','actualRuleCases','actualRuleMethods','all143OriginalFullGameMethodsRetained']})
