import datetime
import hashlib
import json
import os
import pathlib
import plistlib
import subprocess

work = pathlib.Path(__file__).resolve().parent
root = work.parents[2]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
def locked():
    values = plistlib.loads(subprocess.check_output(['/usr/sbin/ioreg', '-n', 'Root', '-d', '1', '-a']))
    return {'atUtc': now(), 'roots': [{'rootLocked': x.get('IOConsoleLocked'),
            'sessions': [u['CGSSessionScreenIsLocked'] for u in x.get('IOConsoleUsers', []) if 'CGSSessionScreenIsLocked' in u]}
            for x in values if isinstance(x, dict)]}

assert not (work / 'only-check').exists()
assert not (work / 'only-check-start-inputs-v1.json').exists()
paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '--',
    'src', 'clients/godot', 'tests', 'scripts', 'data', 'Directory.Build.props', 'Directory.Build.targets',
    'Directory.Packages.props', 'global.json', 'NuGet.Config'], cwd=root, text=True).splitlines()
inputs = {p: sha(root / p) for p in sorted(set(paths)) if (root / p).is_file() and not {'bin','obj','.godot'} & set(pathlib.Path(p).parts)}
runtime = root / 'tests/Riftbound.ConformanceTests/bin/Debug/net10.0'
modules = {str(p.relative_to(root)): sha(p) for p in sorted(runtime.rglob('*')) if p.is_file()
           and (p.suffix in {'.dll', '.pdb'} or p.name.endswith(('.deps.json', '.runtimeconfig.json'))
                or p.is_relative_to(runtime / 'data') or p.is_relative_to(runtime / 'Fixtures'))}
record = {'recordedAtUtc': now(), 'baseCommit': subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
          'inputHashes': inputs, 'actualConformanceRuntimeFileHashes': modules, 'sourceInputCount': len(inputs),
          'actualConformanceRuntimeFileCount': len(modules), 'onlyOneCheckForThisBatch': True, 'prebuildFinished': True,
          'noGodotSdkOrProjectBuild': True, 'optionalSqlConnectionConfigured': bool(os.environ.get('ConnectionStrings__Riftbound')),
          'lockedAtStart': locked()}
write(work / 'only-check-start-inputs-v1.json', record)
power = subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
try:
    env = dict(os.environ, RIFTBOUND_HWEI_TYPED_EVIDENCE=str(work / 'only-check-frames'))
    with (work / 'only-check-runner.log').open('x') as log:
        code = subprocess.run(['python3',str(root/'scripts/test-rules.py'),'check','--output',str(work/'only-check')],
                              cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
finally:
    if power.poll() is None: power.terminate(); power.wait(timeout=10)
sources_changed = [p for p,h in inputs.items() if sha(root/p) != h]
modules_changed = [p for p,h in modules.items() if sha(root/p) != h]
write(work / 'only-check-terminal-integrity-v1.json', {'finishedAtUtc':now(),'checkExitCode':code,
    'inputManifestSha256':sha(work/'only-check-start-inputs-v1.json'),'changedSourceInputs':sources_changed,
    'changedConformanceRuntimeFiles':modules_changed,'allDeclaredInputsAndRuntimeFilesStable':not sources_changed and not modules_changed,
    'lockedAtEnd':locked(),'boundIdleSleepAssertionEnded':power.poll() is not None,
    'databaseClaimNotInferredFromOptionalSmokeReturn':True,'noSecondCheck':True})
assert code == 0 and not sources_changed and not modules_changed
print('SOLE_CHECK_FINISHED_WITH_STABLE_INPUTS_AND_RUNTIME',flush=True)
