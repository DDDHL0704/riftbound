import collections
import copy
import datetime
import difflib
import gzip
import hashlib
import importlib.util
import json
import os
import pathlib
import re
import subprocess
import xml.etree.ElementTree as ET

r = pathlib.Path.cwd()
w = pathlib.Path(__file__).resolve().parent
old = r / 'var/qa/cn-qa-source-trace-20261019'
e = r / 'docs/evidence/hwei-move-discard-types-2026-10-20'
base = 'b294bb150d877b3399cd9e120bbaec5c75e353cf'
identity = 'hwei-move-draw-discard-all-printed-types-2026-10-20'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
def write(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def pin(p,role=None): return {'path':str(p.relative_to(r)),'sha256':sha(p),'role':role or p.stem}
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == base
assert not e.exists()
check = load(w/'only-check-retention-and-failure-disposition-v1.json')
closure = load(w/'postcheck-diagnostic-closure-verification-v1.json')
sql = load(w/'real-sql-verification-v2.json')
assert check['cases']==13027 and check['failed']==4 and check['all52NewHweiCasesPassed']
assert closure['status']=='PASS_FOUR_ORIGINAL_DIAGNOSTICS_AND_52_HWEI_CASES_AFTER_EXPECTED_LITERAL_UPDATE'
assert sql['status']=='PASS_REAL_SQL_FOUR_HWEI_ORIGINALS_AND_INDEPENDENT_READONLY_FULL_REPLAY' and sql['ownPostgresSmartStopped']
assert (sql['commands'],sql['events'],sql['coldRestores'],sql['originalNextCommandsMatched'],sql['atomicRejections'])==(132,524,36,32,20)
mp=r/'docs/audit/current-manifest.json';rp=r/'docs/evidence/rules-reaudit-2026-10-11/review-decisions.json'
prior=load(mp);reviews=load(rp);prior_reviews=copy.deepcopy(reviews)
prior_governance=load(r/'var/qa/dual-type-reveal-20261019/final-governance-v5.json')
assert prior_governance['governanceValid'] and len(prior_governance['remainingObligations'])==16885
assert len(prior['reviewContexts'])==55 and len(prior['acceptanceGates'])==231 and len(reviews['reviews'])==140
baseline=load(w/'prechange-retention-baseline-v1.json')
assert sha(mp)==baseline['governanceManifestSha256']
# Preserve every original context before any explicit current-source rebind.
(w/'pre-hwei-original-current-manifest.json.gz').write_bytes(gzip.compress(mp.read_bytes(),mtime=0))
(w/'pre-hwei-original-review-decisions.json.gz').write_bytes(gzip.compress(rp.read_bytes(),mtime=0))
e.mkdir(parents=True)
text=(w/'HWEI_MOVE_DISCARD_TYPES_AUDIT_2026-10-20.md').read_text().replace('@CHECK_CASES@','13027').replace('@CHECK_METHODS@','7440')
assert '@CHECK_' not in text
(r/'docs/HWEI_MOVE_DISCARD_TYPES_AUDIT_2026-10-20.md').write_text(text)
archives=[]
def archive(path,relative,compress=False):
    target=e/relative;target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists()
    if compress: target.write_bytes(gzip.compress(path.read_bytes(),mtime=0))
    else: os.link(path,target)
    archives.append({'originalPath':str(path.relative_to(r)),'canonical':pin(target),
        'originalBytes':path.stat().st_size,'originalSha256':sha(path),'gzipOriginalBytes':compress,'samePhysicalFileHardlinked':not compress})
    return target
# No native package, runtime assembly, duplicate PDF, database or build tree is copied.
for source,prefix in [(old,'n15'),(w,'n16')]:
    for path in sorted(source.rglob('*')):
        if not path.is_file(): continue
        rel=path.relative_to(source)
        if any(part in {'bin','obj','__pycache__','reader-build','reader-build-v2','reader-build-v3','sql-fixed-runtime','sql-fixed-runtime-v2','sql-probe-runtime','frozen-runtime'} for part in rel.parts):continue
        if path.suffix in {'.json','.jsonl','.gz','.zip','.png','.webp','.jpg','.jpeg'}:
            archive(path,str(pathlib.Path(prefix)/rel))
        elif path.suffix in {'.py','.cs','.csproj','.trx','.log','.js','.html','.txt'}:
            archive(path,str(pathlib.Path(prefix)/rel)+'.gz',True)
# Every original line and assertion remains; a single new private guard call was inserted.
changed=[]
for path,h in baseline['testAndToolFiles'].items():
    if sha(r/path)!=h:changed.append(path)
assert set(changed)=={'tests/Riftbound.ConformanceTests/FullGameEndToEndTests.cs',
    'tests/Riftbound.ConformanceTests/MatchRecoveryTests.cs','tests/Riftbound.PostgresAcceptance/Program.cs',
    'tests/Riftbound.PostgresAcceptance/Riftbound.PostgresAcceptance.csproj'}
full_sources=baseline['allEightOriginalFullGameSourceFiles']
for path,h in full_sources.items():
    before=subprocess.check_output(['git','show',base+':'+path])
    after=(r/path).read_bytes()
    if path.endswith('/FullGameEndToEndTests.cs'):
        assert after.replace(b'            CheckHistoricalMovementDiscardSources(snapshot, result.State);\n',b'',1)==before
    else:assert after==before and sha(r/path)==h
full_methods=[]
for path in full_sources:
    full_methods += re.findall(r'public\s+(?:async\s+)?(?:Task|void)\s+(\w+)\s*\(', (r/path).read_text())
assert len(full_methods)==143
old_program=subprocess.check_output(['git','show',base+':tests/Riftbound.PostgresAcceptance/Program.cs'],text=True)
new_program=(r/'tests/Riftbound.PostgresAcceptance/Program.cs').read_text()
calls=lambda text:re.findall(r'(?m)^await (\w+)\.RunAsync\(dataSource, Path\.Combine\(output, "([^"]+)"\)\);',text)
assert len(calls(old_program))==42 and calls(new_program)[:-1]==calls(old_program) and len(calls(new_program))==43
write(e/'test-preservation.json',{'all1840OldTestAndToolPathsRetained':True,'onlyChangedOldPaths':changed,
 'allOriginalMethodsAndTheoryRowsRetained':True,'all143OriginalFullGameMethodNames':sorted(full_methods),
 'all110Pairs11DecksOriginalSeedsAndWinReplayAssertionsRetained':True,
 'originalEightFullGameSourceHashes':full_sources,'onlyOriginalFullGameChange':'One independently checked historical movement-source privacy guard invocation; every original line remains.',
 'newPartialHelperHasNoFullGameTestMethods':True,'all42DefaultSqlCallsInOriginalOrder':calls(old_program),'newDefaultSqlCount':43,
 'postCheckChangeOnlyIndependentExpectedDiagnosticLiteral':pin(e/'n16/postcheck-diagnostic-closure-verification-v1.json')})
write(e/'single-check.json',{**check,'focusedClosure':pin(e/'n16/postcheck-diagnostic-closure-verification-v1.json'),
 'currentActualDebugRuleInputs':closure['actualDebugRuleInputs'],'soleCheckNotRelabeledAllGreen':True,
 'noSecondCheck':True,'newFixedFull':'PENDING','visibleAndPhysicalWindows':'OPEN'})
source_manifest={'recordedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'region':'CN','language':'zh-CN',
 'rulesEffectiveBaseline':'2026-10-16','observedAtAsiaShanghai':'2026-10-20','applicableAsOf':'2026-10-16',
 'baseCommit':base,'includesExplicitUncommittedImplementation':True,
 'scope':'Exact Hwei UNL-080/219 movement draw-before-discard, each printed type inline; Porobot unit/gear both orders; bounded supporting reaction source return only.',
 'freshCurrentFiveSourceIntake':pin(e/'n16/fresh-source-intake-v1.json'),
 'sourceAndFrozenNegativeManifest':pin(e/'n15/source-and-frozen-counterexample-manifest-v2.json'),
 'currentCoreCitationCorrection':pin(e/'n15/current-core-draw-discard-clause-lookup-correction-v1.json'),
 'currentClauses':['388.1.b inline triggers','389.1-2 trigger ordering','414 draw','423 discard','432 burnout','178 unit/gear types'],
 'faqExactRecords':['CN-59bd828207564540-P008-B00'+str(i) for i in range(1,5)],
 'faqPageAndImageCoverage':pin(e/'n15/vendetta-faq-page-and-image-coverage-v2.json'),
 'all22PagesAnd54ImageOccurrencesActuallyViewedNot54UniquePrintings':True,
 'all161OriginalFaqBlocksStillRequireIndividualPrintingAndCurrentCoreSemanticClosure':True,
 'boundedRawRuntimeConsumerInventory':pin(e/'n16/current-known-printed-type-consumer-disposition-v1.json'),
 'hypotheticalThreeTypeQaNotPromotedOrRemovedByRuntimeInventory':True,
 'allThreeVisualReadbackCorrectionsRetained':'n15/vendetta-faq-visual-readback-v1.jsonl',
 'nullCardQaListNotAbsenceOfFaq':True,'specificFrontendScriptInspectionNotGlobalQaAbsence':True,
 'sourceBytesUnchangedNotNewTemporalDelta':True,'unknownIndividualPublicationAndEffectiveDatesRemainNull':True,
 'currentConformanceDebugInputs':closure['actualDebugRuleInputs'],'actualFrozenReleaseSqlInputs':sql['actualRuleInputs'],
 'older797fNativeAndReleaseInputsNotRelabeledAsThisImplementation':True,
 'sixLimitedBranchesOnlyNotWholePrintingOrFamily':True,'newFixedFull':'PENDING','visibleAndPhysicalWindows':'OPEN',
 'all1740Printings36HistoricalDocuments14293BlocksOriginalDatesGlobal8AndCn236DispositionsRetained':True,
 'wholePrintingCertified':False,'regionalTournamentEligibilityCertified':False,'semanticCoverageCertified':False}
write(e/'source-manifest.json',source_manifest)
source_pin=pin(e/'source-manifest.json')
new_branches=[]
scopes=[
 ('HWEI_MOVE_DRAW_THEN_REQUIRED_DISCARD','One ordinary draw occurs before choosing any current hand card, including the new draw; initial burnout may refill or finish before discard.'),
 ('HWEI_DISCARDED_SPELL_INLINE_DRAW','The reviewed actual spell discard produces a separate one-card draw; further spell-child burnout branches remain open.'),
 ('HWEI_DISCARDED_GEAR_INLINE_ZERO_ONE_TWO_RUNE_TARGETS','Gear discard confirms zero, one or two original legal rune targets; recycled target incarnations are not readied.'),
 ('HWEI_DISCARDED_UNIT_INLINE_SELF_MIGHT_UNTIL_END_TURN','Unit discard gives the original field source +3 only for this turn; actual ordinary turn end removes it and a returned hand incarnation receives no modifier.'),
 ('HWEI_REAL_UNIT_GEAR_BOTH_INLINE_TRIGGERS_BOTH_ORDERS','Actual Porobot is both unit and gear outside field: create both separate inlines, retain either controller order, do not play the discarded card or reveal a substitute top.'),
 ('HWEI_CAPTURED_SOURCE_CONTROLLER_GENERATION_AND_PRIVATE_CHOICE_RECOVERY','Retain captured source/controller and private hand choice across cold recovery; reject forged roles, type/card/version/window/generation and duplicate bindings, plus coordinated historical-tick tampering by original journal.')]
refs=['UNL-080/219','VEN-058']+source_manifest['faqExactRecords']
for branch,detail in scopes:
 new_branches.append({'id':branch,'sourceRefs':refs,'sourceManifest':source_pin,'state':'RECORDED',
  'decision':{'state':'OPEN','reason':'Bounded semantic/implementation/scoped test and real SQL proof; sole check has a preserved four-diagnostic failure closed only by focused rerun. New fixed full and current product gates remain open.'},
  'branchScope':detail,'semanticReview':'LIMITED_CURRENT_CN_PRINTED_ABILITY_FAQ_AND_CURRENT_CORE_REVIEW',
  'implementation':'IMPLEMENTED_SHARED_MOVEMENT_DRAW_DISCARD_TYPES_AND_RUNE_CONFIRMATION',
  'testExecution':'FOCUS103_SQL4_CHECK13027_WITH_FOUR_DIAGNOSTIC_FAILURES_CLOSED_BY56_FOCUS',
  'fixedCommitCi':'PENDING_NEW_FIXED_FULL','productAcceptance':'OPEN','wholePrintingCertified':False,
  'remaining':['NEW_FIXED_FULL_ALL143_METHODS110_PAIRS_ORIGINAL_SEEDS_AND43_DEFAULT_SQL_HELPERS',
   'VISIBLE_CURRENT_NATIVE_PAIRED_SQL_NETWORK_NORMAL_SCORE_FULL_REPLAY','PHYSICAL_WINDOWS',
   'WHOLE_PRINTING_OTHER_SOURCE_QA_CONTROL_FORCED_SIMULTANEOUS_MOVEMENT_AND_OTHER_LIFECYCLE_BRANCHES']})
evidence_files=[e/'single-check.json',e/'test-preservation.json',e/'n16/focus-and-default-sql-retention-v1.json',
 e/'n16/postcheck-diagnostic-closure-verification-v1.json',e/'n16/real-sql-verification-v2.json',
 e/'n16/independent-actual-sql-reader-result-v2.json',e/'n16/first-failed-prefix-independent-reader-result-v1.json']
reviews['reviews'].append({'id':identity,'scope':'CN/zh-CN rules effective baseline2026-10-16; current20Oct exact Hwei move draw/discard/all printed type inline branches only.',
 'status':'LIMITED_IMPLEMENTATION_FOCUS103_SQL4_SOLECHECK_FOUR_DIAGNOSTICS_FOCUSED_CLOSURE_FIXEDFULL_PRODUCT_OPEN',
 'subjects':['UNL-080/219','VEN·058'],'ruleRecords':source_manifest['faqExactRecords'],'pendingRuleRecords':[],
 'sourceManifest':source_pin,'validation':{'focus103':pin(e/'n16/final-focus-v13/summary.json'),
  'soleCheck':pin(e/'single-check.json'),'focusedDiagnosticClosure':pin(e/'n16/postcheck-diagnostic-closure-verification-v1.json'),
  'actualSql':pin(e/'n16/real-sql-verification-v2.json'),'newFixedFull':'PENDING','visibleCurrentNativeProduct':'OPEN','physicalWindows':'OPEN'},
 'exclusions':['ALL_OTHER_HWEI_COPY_LEGITIMATE_CONTROL_CHANGE_FORCED_SIMULTANEOUS_MOVEMENT_AND_CHILD_BURNOUT_BRANCHES',
  'WHOLE_PRINTING_QA_AND_GLOBAL_SOURCE_GAPS','NEW_FIXED_FULL','VISIBLE_NATIVE_PRODUCT','PHYSICAL_WINDOWS'],
 'auditDocument':'docs/HWEI_MOVE_DISCARD_TYPES_AUDIT_2026-10-20.md','evidence':[str(p.relative_to(r)) for p in evidence_files]})
assert reviews['reviews'][:-1]==prior_reviews['reviews']
write(rp,reviews)
m=copy.deepcopy(prior)
spec=importlib.util.spec_from_file_location('governance',r/'scripts/audit/check-project-governance.py')
checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
revision=checker.digest(checker.gameplay_inputs(r))
rebindings=[]
for key,context in m['reviewContexts'].items():
 changes=[]
 for field in ['implementation','verificationSources']:
  for ref in context.get(field,[]):
   path=r/ref['path']
   current=sha(path)
   if current==ref['sha256']:continue
   if field=='verificationSources' and ref['path'] not in changed:continue
   changes.append({'field':field,'path':ref['path'],'previousSha256':ref['sha256'],'currentSha256':current})
   ref['sha256']=current
 before={'currentInputRevision':context.get('currentInputRevision'),'currentImplementationCommit':context.get('currentImplementationCommit'),
         'currentImplementationIncludesUncommittedChanges':context.get('currentImplementationIncludesUncommittedChanges')}
 context.setdefault('implementationPinUpdates',[]).append({'batch':identity,'changes':changes,
  'previousCurrentMetadata':before,'previousEntireContextPreservedIn':'docs/evidence/hwei-move-discard-types-2026-10-20/n16/pre-hwei-original-current-manifest.json.gz',
  'scope':'Explicit current implementation/input rebind only. All previous evidenceCommit, CI receipts, semantic branches and exclusions remain; the changed global engine input requires a new fixed full.'})
 context.update(currentInputRevision=revision,currentImplementationCommit=base,currentImplementationIncludesUncommittedChanges=True,
  ciState='PENDING',revalidationReason='Hwei shared draw/discard/type inline, rune-target extraction and recovery causal-role changes; limited new evidence does not re-certify historical reviews. New full pending.')
 rebindings.append({'review':key,'oldContextSha256':checker.digest(prior['reviewContexts'][key]),'currentInputRevision':revision,'pinChanges':changes})
m['inputs']['reviews']=pin(rp,prior['inputs']['reviews'].get('role','reviews'))
m['reviewContexts'][identity]={'evidenceCommit':base,'currentImplementationCommit':base,'currentImplementationIncludesUncommittedChanges':True,
 'evidenceCommitScope':'Baseb294 plus declared uncommitted Hwei sources/tests/SQL. Actual local Debugdb884 and Releasef4a are separate from older797f native and future fixed commit modules.',
 'currentInputRevision':revision,'ciState':'PENDING','ciReceipts':[],'region':'CN','language':'zh-CN','applicableAsOf':'2026-10-16',
 'sourceManifest':source_pin,'implementation':[pin(r/p,'implementation') for p in [
 'src/Riftbound.Contracts/BehaviorSpecs.cs','src/Riftbound.CardCatalog/RuleTextParsers.cs',
 'src/Riftbound.Engine/UnitMovedTriggerSpecRules.cs','src/Riftbound.Engine/CoreRuleEngine.MovementObservers.cs',
 'src/Riftbound.Engine/CoreRuleEngine.MovementDiscardTypes.cs','src/Riftbound.Engine/CoreRuleEngine.EndStep.cs',
 'src/Riftbound.Engine/CoreRuleEngine.FieldTriggers.cs','src/Riftbound.Engine/CoreRuleEngine.cs','src/Riftbound.Engine/MatchRecovery.cs']],
 'verificationSources':[pin(r/p,'verification') for p in [
 'tests/Riftbound.ConformanceTests/HweiMoveDiscardTypesTests.cs','tests/Riftbound.ConformanceTests/HweiMoveDiscardOrdinaryTests.cs',
 'tests/Riftbound.ConformanceTests/HweiMoveDiscardRecoveryTests.cs','tests/Riftbound.ConformanceTests/FullGameEndToEndTests.MovementDiscard.cs',
 'tests/Riftbound.ConformanceTests/FullGameEndToEndTests.cs','tests/Riftbound.ConformanceTests/MatchRecoveryTests.cs',
 'tests/Riftbound.ConformanceTests/Fixtures/hwei-move-discard-openings.json','tests/Riftbound.PostgresAcceptance/HweiMoveDiscardTypesSqlAcceptance.cs',
 'tests/Riftbound.PostgresAcceptance/Program.cs','tests/Riftbound.PostgresAcceptance/Riftbound.PostgresAcceptance.csproj']],
 'evidence':[pin(p) for p in evidence_files],'branches':new_branches}
m['acceptanceGates'].append({'id':'HWEI_MOVE_DISCARD_TYPES_NEW_FIXED_FULL_VISIBLE_AND_WINDOWS','state':'OPEN',
 'region':'CN','language':'zh-CN','sourceManifest':source_pin,
 'requirement':'New fixed full must cover every original method/Theory/full game,143 full methods,110 directed pairs,original seeds and43 default SQL helpers. Current native visible paired real SQL/network/normal-score/full-replay and physical Windows remain separate.',
 'semanticReview':'LIMITED_SOURCE_AND_SIX_BEHAVIOR_BRANCHES_ONLY','implementation':'SHARED_FLOW_IMPLEMENTED_WITHOUT_OLD_MATCH_MIGRATION',
 'testExecution':'SCOPED103_SQL4_SOLECHECK4_DIAGNOSTICS_FOCUSED_CLOSURE56','fixedCommitCi':'PENDING','productAcceptance':'OPEN','wholePrintingCertified':False})
assert m['acceptanceGates'][:-1]==prior['acceptanceGates'] and m['laterSourceDeltas']==prior['laterSourceDeltas']
write(e/'current-context-rebindings.json',{'previousEntireContextSnapshot':pin(e/'n16/pre-hwei-original-current-manifest.json.gz'),
 'all55OldContextsRetainedAsOriginalSnapshot':True,'allOldEvidenceCommitsCiReceiptsSemanticBranchesAndExclusionsRetained':True,
 'currentInputRevision':revision,'explicitRebindings':rebindings,'newCurrentReview':identity,'all56CurrentContextsAwaitNewFull':True})
m['currentHweiMoveDiscardTypesInputChange']=pin(e/'source-manifest.json')
write(mp,m)
result=checker.current_audit(r,m)
assert result['governanceValid'],result['errors']
old_ids={row['id'] for row in prior_governance['remainingObligations']};new_ids={row['id'] for row in result['remainingObligations']}
assert old_ids<=new_ids and len(new_ids-old_ids)==7 and len(new_ids)==16892
assert reviews['reviews'][:-1]==prior_reviews['reviews'] and m['laterSourceDeltas']==prior['laterSourceDeltas']
write(e/'unified-obligation-retention.json',{'previousManifestCommit':base,'priorRemainingObligations':16885,
 'currentRemainingObligations':len(new_ids),'all16885OriginalIdsRetained':True,'newObligationIds':sorted(new_ids-old_ids),
 'all140OriginalSemanticReviewDictionariesExact':True,'all55OriginalContextsPreservedBeforeExplicitCurrentPinRebind':True,
 'all231OriginalGateDictionariesExact':True,'allFiveTemporalDeltaDictionariesExact':True,
 'currentReviews':141,'currentContexts':56,'currentGates':232,
 'allOriginal1740Printings36Documents14293BlocksSourceDateAndGapDispositionsRetained':True,'semanticCoverageCertified':False})
(e/'remaining-obligation-ids.json.gz').write_bytes(gzip.compress(json.dumps(sorted(new_ids),ensure_ascii=False,indent=2).encode()+b'\n',mtime=0))
write(e/'governance-validation.json',{'governanceValid':result['governanceValid'],'errors':result['errors'],
 'remainingObligationCount':len(new_ids),'allRemainingIds':pin(e/'remaining-obligation-ids.json.gz'),
 'semanticCoverageCertified':False,'currentInputRevision':revision})
write(e/'archive-map.json',{'records':archives,'noNativeBinaryPackagesRuntimeAssembliesWholeCheckoutDatabaseOrDuplicatePdfCopied':True})
text=(w/'HWEI_MOVE_DISCARD_TYPES_AUDIT_2026-10-20.md').read_text().replace('@CHECK_CASES@','13027').replace('@CHECK_METHODS@','7440')
assert '@CHECK_' not in text
(r/'docs/HWEI_MOVE_DISCARD_TYPES_AUDIT_2026-10-20.md').write_text(text)
p=r/'docs/PROJECT_STATUS.md';body=p.read_text();assert body.startswith('# 当前项目状态\n')
intro='''
2026-10-20 当前批次：[彗移动抽弃牌和多类型内嵌触发](HWEI_MOVE_DISCARD_TYPES_AUDIT_2026-10-20.md)。CN/zh-CN、规则生效基线10-16；当前14项目录、API34614、实际卡面、核心及FAQ重新取得且哈希未变。修复共享先抽后弃、所有适用印刷类型分别内嵌触发、两种顺序、最多两枚符文代际确认及原实例本回合战力，保留服务端权威和原日志审计，无旧局迁移或DSL扩张。

限定focus103含受影响原完整对局、真实SQL4共132命令524事件/36冷恢复、32原下一命令、20拒绝及独立只读原帧/完整回放通过。唯一check13027例/7440方法为13023过、4旧诊断期待失败，全部原12975例/7427方法保留；仅补独立预期常量CARD_DISCARDED后，原4拒绝和52彗用例56条定向全过，原失败保留，无第二次check。3285源码输入/1398载荷文件在check期间稳定，生产模块在诊断预期修正前后字节不变，65工具检查通过。143原完整方法、110配对、原种子/胜利/回放断言保留，42默认SQL助手原序不改，新增第43个。

SQL首轮助手JsonElement字符串比较错误的32命令119事件原局独立只读完整回放通过，未改历史；原163审计/31原生及该失败原局保留，当前168/31只读后七表不变，专用库正常停止。Debugdb884、实际Releasef4a与旧797f Release07cb/原生包分别绑定。FAQ22页/54图像出现已实看，原161块和三条读图纠正保留，其他印次绑定和当前核心协调仍OPEN。统一保留140审查/55上下文快照/231门禁/16885原义务及五来源增量；现141审查/56上下文/232门禁/16892义务，治理0错误，全量语义未认证。

旧797f完整CI39248538363已实际因官方六小时上限cancelled；原13118例/7566方法、143原完整方法/110配对424242原TRX核实完整，SQL取消、网络skipped，不计全轮通过。b294的39275773327独立规则作业已实际success，原13124例/7568方法及全部原方法/配对/种子核实；SQL/网络和整体仍待终态，且不覆盖本批彗。新固定full和当前可见原生/双端/Windows实机分别OPEN；锁屏下继续，只有最新可用797f A/B及两平台各一规范包，无新Godot构建、整份工作树或数据库。Goal active / NOT READY。

以下保留此前批次原始限定记录；当前来源、实现和验收以上述精确收据为准。
'''
p.write_text('# 当前项目状态\n'+intro+body[len('# 当前项目状态\n'):])
write(w/'canonical-publication-v1.json',{'status':'CANONICAL_HWEI_BOUNDED_IMPLEMENTATION_EVIDENCE_AND_REMAINING_OBLIGATIONS_WRITTEN',
 'reviews':141,'contexts':56,'gates':232,'remainingObligations':16892,'newFixedFull':'PENDING','visibleAndPhysicalWindows':'OPEN'})
print('CANONICAL_HWEI_REVIEW_WRITTEN_141_56_232_16892',flush=True)
