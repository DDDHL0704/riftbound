import datetime
import gzip
import hashlib
import json
import os
import pathlib
import subprocess
import time
import xml.etree.ElementTree as ET

work=pathlib.Path(__file__).resolve().parent
root=work.parents[2]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
output=work/'postcheck-diagnostic-closure-verification-v1.json'
assert not output.exists() and not(work/'postcheck-focus-v14').exists()
deadline=time.monotonic()+4500
while not(work/'only-check-terminal-integrity-v1.json').exists():
    assert time.monotonic()<deadline,'Original check has not reached a terminal state; source remains unchanged.'
    time.sleep(5)
subprocess.run(['python3',str(work/'verify-only-check-retention-v1.py')],cwd=root,check=True)
inputs=json.loads((work/'only-check-start-inputs-v1.json').read_text())
path=root/'tests/Riftbound.ConformanceTests/MatchRecoveryTests.cs'
original=path.read_bytes()
assert sha(path)==inputs['inputHashes'][str(path.relative_to(root))]
old=b'"[CARDS_RECYCLED, RUNE_RECYCLED,'
new=b'"[CARD_DISCARDED, CARDS_RECYCLED, RUNE_RECYCLED,'
assert original.count(old)==1 and new not in original
(work/'precheck-original-MatchRecoveryTests.cs.gz').write_bytes(gzip.compress(original,mtime=0))
changed=original.replace(old,new,1);assert changed.replace(new,old,1)==original
path.write_bytes(changed)
power=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
try:
    arguments=['python3',str(root/'scripts/test-rules.py'),'focus','--match','HweiMoveDiscard']
    names=[
      'RecoveryValidatorRejectsSnapshotTimingTriggerQueueTriggeredEventKindDrift',
      'RecoveryValidatorRejectsAuthoritativeStateTriggerQueueTriggeredEventKindDrift',
      'RecoveryValidatorRejectsSpectatorReplayTimingTriggerQueueKeyedKnownValueCanonicalityWithCountMismatch',
      'RecoveryValidatorRejectsSpectatorReplayTimingTriggerQueueKeyedVisibleSourceTriggeredEventKindInvalidValueWithoutCountMismatch']
    for name in names:arguments+=['--match',name]
    arguments+=['--output',str(work/'postcheck-focus-v14')]
    env=dict(os.environ,RIFTBOUND_HWEI_TYPED_EVIDENCE=str(work/'postcheck-focus-frames'))
    with(work/'postcheck-focus-v14-runner.log').open('x') as log:
        code=subprocess.run(arguments,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
    assert code==0,'Focused closure failed; preserve originals and inspect new raw TRX.'
finally:
    if power.poll() is None:power.terminate();power.wait(timeout=10)
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
trx=work/'postcheck-focus-v14/focus/results.trx';tree=ET.parse(trx).getroot()
rows=tree.findall('.//t:UnitTestResult',ns)
assert len(rows)==56 and all(x.attrib['outcome']=='Passed' for x in rows)
assert {x.attrib['testName'].split('.')[-1] for x in rows if '.MatchRecoveryTests.'in x.attrib['testName']}==set(names)
changed_sources=[p for p,h in inputs['inputHashes'].items() if sha(root/p)!=h]
changed_runtime=[p for p,h in inputs['actualConformanceRuntimeFileHashes'].items() if sha(root/p)!=h]
assert changed_sources==['tests/Riftbound.ConformanceTests/MatchRecoveryTests.cs']
assert set(changed_runtime)=={
 'tests/Riftbound.ConformanceTests/bin/Debug/net10.0/Riftbound.ConformanceTests.dll',
 'tests/Riftbound.ConformanceTests/bin/Debug/net10.0/Riftbound.ConformanceTests.pdb'}
frames=list((work/'postcheck-focus-frames').glob('*.json.gz'));assert len(frames)==20
identities=[json.loads(gzip.decompress(p.read_bytes()))['authoritativeState']['ruleInputs'] for p in frames]
assert all(x==identities[0] for x in identities)
assert identities[0]['identitySha256']=='db88471abeae4cf4d20885e5cfd0b6d4d30b3ea607658fe2e3df41d037e77f0f'
proof={'recordedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'status':'PASS_FOUR_ORIGINAL_DIAGNOSTICS_AND_52_HWEI_CASES_AFTER_EXPECTED_LITERAL_UPDATE',
 'focusedCases':56,'focusedMethods':17,'failed':0,'skipped':0,'originalFourRejectingCasesStillPass':True,
 'all52HweiValidAndForgedCapturedDiscardRoleCasesPass':True,
 'onlyChangedPrecheckSourcePaths':changed_sources,'onlyChangedPrecheckRuntimePaths':changed_runtime,
 'onlyIndependentExpectedDiagnosticLiteralChanged':True,'expectedLiteralStillIndependentOfProductionAllowlist':True,
 'allOriginalPublicMethodsTheoryRowsAndRejectAssertionsUnchanged':True,'allProductionModuleCopiesByteExactToSoleCheck':True,
 'actualDebugRuleInputs':identities[0],'rawFocusedTrxSha256':sha(trx),
 'precheckDiagnosticSourceGzipSha256':sha(work/'precheck-original-MatchRecoveryTests.cs.gz'),
 'soleFailedCheckRetainedUnchanged':True,'secondCheck':False,'newFixedFull':'PENDING',
 'visibleAndPhysicalWindows':'OPEN','boundIdleSleepAssertionEnded':power.poll() is not None}
output.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print(proof['status'],flush=True)
