import collections
import gzip
import hashlib
import json
import pathlib
import xml.etree.ElementTree as ET

work = pathlib.Path(__file__).resolve().parent
root = work.parents[2]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
ns = {'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
expected_failures = {
    'RecoveryValidatorRejectsSnapshotTimingTriggerQueueTriggeredEventKindDrift',
    'RecoveryValidatorRejectsAuthoritativeStateTriggerQueueTriggeredEventKindDrift',
    'RecoveryValidatorRejectsSpectatorReplayTimingTriggerQueueKeyedKnownValueCanonicalityWithCountMismatch',
    'RecoveryValidatorRejectsSpectatorReplayTimingTriggerQueueKeyedVisibleSourceTriggeredEventKindInvalidValueWithoutCountMismatch'}
def read(path):
    raw = gzip.decompress(path.read_bytes()) if path.suffix == '.gz' else path.read_bytes()
    tree = ET.fromstring(raw)
    rows = tree.findall('.//t:UnitTestResult', ns)
    methods = {m.attrib['className'].split(',')[0]+'.'+m.attrib['name']
               for m in tree.findall('.//t:UnitTest/t:TestMethod',ns)}
    return tree, rows, collections.Counter(r.attrib['testName'] for r in rows), methods

terminal = json.loads((work/'only-check-terminal-integrity-v1.json').read_text())
assert terminal['checkExitCode'] == 1 and terminal['allDeclaredInputsAndRuntimeFilesStable']
inputs = json.loads((work/'only-check-start-inputs-v1.json').read_text())
assert all(sha(root/p) == h for p,h in inputs['inputHashes'].items())
assert all(sha(root/p) == h for p,h in inputs['actualConformanceRuntimeFileHashes'].items())
baseline = root/'var/qa/dual-type-reveal-20261019/only-check/check/results.trx'
_, old_rows, old, old_methods = read(baseline)
path = work/'only-check/check/results.trx'
tree, rows, cases, methods = read(path)
assert len(old_rows) == 12975 and len(old_methods) == 7427 and all(r.attrib['outcome']=='Passed' for r in old_rows)
assert len(rows) == 13027 and len(methods) == 7440
assert not old-cases and old_methods <= methods
assert sum((cases-old).values()) == 52 and len(methods-old_methods) == 13
assert all('HweiMoveDiscard' in name for name in cases-old)
failed = [r for r in rows if r.attrib['outcome'] != 'Passed']
assert len(failed) == 4 and {r.attrib['testName'].split('.')[-1] for r in failed} == expected_failures
assert all(r.attrib['outcome']=='Failed' for r in failed)
failures = []
for row in failed:
    message = row.find('.//t:Message',ns).text
    assert 'CARD_DISCARDED' in message and 'FORGED_EVENT' in message
    failures.append({'name':row.attrib['testName'],'message':message,
                     'stackTrace':row.find('.//t:StackTrace',ns).text})
proof = {'status':'SOLE_CHECK_13027_CASES_RETAINED_13023_PASS_FOUR_OLD_DIAGNOSTIC_EXPECTATIONS_FAIL',
    'profile':'check','cases':len(rows),'methods':len(methods),'passed':len(rows)-4,'failed':4,'skipped':0,
    'all12975OldCaseMultisetRetained':True,'all7427OldMethodsRetained':True,
    'newCases':sorted((cases-old).elements()),'newMethodNames':sorted(methods-old_methods),
    'all52NewHweiCasesPassed':all(r.attrib['outcome']=='Passed' for r in rows if 'HweiMoveDiscard' in r.attrib['testName']),
    'failures':failures,'sourceInputsStable':True,'compiledRuntimeAndFixturesStable':True,
    'declaredSourceInputCount':len(inputs['inputHashes']),'runtimeFileCount':len(inputs['actualConformanceRuntimeFileHashes']),
    'rawTrxSha256':sha(path),'baselineTrxSha256':sha(baseline),'summaryNotWrittenByRunnerOnFailure':not(work/'only-check/summary.json').exists(),
    'originalFailedCheckRetained':True,'secondCheck':False,'requiredFocusedClosure':'Four independent diagnostic expectations plus Hwei valid/invalid captured discard roles',
    'fixedFullRequired':True,'visibleAndPhysicalWindows':'OPEN'}
p=work/'only-check-retention-and-failure-disposition-v1.json';assert not p.exists();p.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print({k:proof[k] for k in ['status','cases','methods','passed','failed','all52NewHweiCasesPassed']})
